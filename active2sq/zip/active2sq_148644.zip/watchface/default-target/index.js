try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.FILL_RECT, {
                    x: 0,
                    y: 0,
                    w: 390,
                    h: 450,
                    color: '0xFFd3d3d3',
                    radius: 86,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 105,
                    hour_centerY: 106,
                    hour_posX: 71,
                    hour_posY: 71,
                    hour_path: '2.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 105,
                    minute_centerY: 344,
                    minute_posX: 71,
                    minute_posY: 71,
                    minute_path: '3.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    second_centerX: 285,
                    second_centerY: 106,
                    second_posX: 71,
                    second_posY: 71,
                    second_path: '4.png',
                    second_cover_x: 0,
                    second_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_val: new Date().getHours(),
                    hour_zero: 1,
                    hour_startX: 88,
                    hour_startY: 194,
                    hour_array: [
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png'
                    ],
                    hour_space: -5,
                    hour_align: hmUI.align.CENTER_H,
                    minute_zero: 1,
                    minute_startX: 88,
                    minute_startY: 230,
                    minute_array: [
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png'
                    ],
                    minute_space: -5,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    second_zero: 1,
                    second_startX: 267,
                    second_startY: 194,
                    second_array: [
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png'
                    ],
                    second_space: -5,
                    second_align: hmUI.align.LEFT,
                    second_follow: 0,
                    am_x: 181,
                    am_y: 211,
                    am_en_path: '15.png',
                    pm_x: 181,
                    pm_y: 210,
                    pm_en_path: '16.png',
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 267,
                    y: 230,
                    type: hmUI.data_type.BATTERY,
                    font_array: [
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: -5,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 294,
                    y: 225,
                    w: 30,
                    h: 30,
                    src: '17.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: '18.png',
                    center_x: 290,
                    center_y: 349,
                    x: 76,
                    y: 76,
                    type: hmUI.data_type.BATTERY,
                    start_angle: 0,
                    end_angle: 360,
                    cover_x: 0,
                    cover_y: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 105,
                    hour_centerY: 106,
                    hour_posX: 76,
                    hour_posY: 76,
                    hour_path: '19.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 105,
                    minute_centerY: 344,
                    minute_posX: 76,
                    minute_posY: 76,
                    minute_path: '20.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: '21.png',
                    center_x: 286,
                    center_y: 345,
                    x: 76,
                    y: 76,
                    type: hmUI.data_type.BATTERY,
                    start_angle: 0,
                    end_angle: 360,
                    cover_x: 0,
                    cover_y: 0,
                    show_level: hmUI.show_level.ONLY_AOD
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}