try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
                    edit_id: 1,
                    x: 0,
                    y: 0,
                    bg_config: [
                        {
                            'id': 1,
                            'path': '4.png',
                            'preview': '5.png'
                        },
                        {
                            'id': 2,
                            'path': '6.png',
                            'preview': '7.png'
                        },
                        {
                            'id': 3,
                            'path': '8.png',
                            'preview': '9.png'
                        },
                        {
                            'id': 4,
                            'path': '10.png',
                            'preview': '11.png'
                        },
                        {
                            'id': 5,
                            'path': '12.png',
                            'preview': '13.png'
                        },
                        {
                            'id': 6,
                            'path': '14.png',
                            'preview': '15.png'
                        }
                    ],
                    count: 6,
                    default_id: 1,
                    fg: '3.png',
                    tips_x: 0,
                    tips_y: 0,
                    tips_bg: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 136,
                    hour_startY: 156,
                    hour_array: [
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png'
                    ],
                    hour_space: 4,
                    hour_align: hmUI.align.RIGHT,
                    minute_zero: 1,
                    minute_startX: 181,
                    minute_startY: 156,
                    minute_array: [
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png'
                    ],
                    minute_space: 4,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    am_x: 227,
                    am_y: 160,
                    am_en_path: '26.png',
                    pm_x: 227,
                    pm_y: 160,
                    pm_en_path: '27.png',
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    year_startX: 285,
                    year_startY: 119,
                    year_sc_array: [
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png'
                    ],
                    year_tc_array: [
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png'
                    ],
                    year_en_array: [
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png'
                    ],
                    year_align: hmUI.align.RIGHT,
                    year_zero: 1,
                    year_space: 4,
                    year_is_character: false,
                    month_startX: 70,
                    month_startY: 119,
                    month_en_array: [
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png'
                    ],
                    month_align: hmUI.align.LEFT,
                    month_zero: 0,
                    month_follow: 0,
                    month_space: 0,
                    month_is_character: true,
                    day_startX: 240,
                    day_startY: 119,
                    day_sc_array: [
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png'
                    ],
                    day_tc_array: [
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png'
                    ],
                    day_en_array: [
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png'
                    ],
                    day_align: hmUI.align.RIGHT,
                    day_zero: 0,
                    day_follow: 0,
                    day_space: 4,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 154,
                    y: 248,
                    type: hmUI.data_type.STEP,
                    font_array: [
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 4,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 130,
                    y: 327,
                    image_array: [
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png'
                    ],
                    image_length: 10,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 170,
                    y: 300,
                    type: hmUI.data_type.BATTERY,
                    font_array: [
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 4,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 390,
                    h: 450,
                    src: '50.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 25,
                    hour_startY: 180,
                    hour_array: [
                        '51.png',
                        '52.png',
                        '53.png',
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png',
                        '58.png',
                        '59.png',
                        '60.png'
                    ],
                    hour_space: 20,
                    hour_align: hmUI.align.RIGHT,
                    minute_zero: 1,
                    minute_startX: 220,
                    minute_startY: 180,
                    minute_array: [
                        '51.png',
                        '52.png',
                        '53.png',
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png',
                        '58.png',
                        '59.png',
                        '60.png'
                    ],
                    minute_space: 20,
                    minute_align: hmUI.align.RIGHT,
                    minute_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}