try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_cc79ac9bca234437871180a61886b27b = '';
        let normal$_$text_17e4c901df0045cab6ae69cfab45624b = '';
        let dateFormat = '';
        let dateFormatMap = '';
        let normal$_$text_ff3e42518d124d1e996116c4d86e7243 = '';
        let normal$_$text_0d94c5fec39a4af78d58b94577273a47 = '';
        let normal$_$text_1355db85538f43668944107048bd818e = '';
        let idle$_$text_f9cd5652636c4464862decbb4e1dc0a7 = '';
        let idle$_$text_da61c7e3396c46a39b113c863260f959 = '';
        let idle$_$text_10abb7046b1c4ef9a7996842c871f02f = '';
        let idle$_$text_d7eb4a4553dc46108659e145172d4385 = '';
        let idle$_$text_bf645ffc9ae14663b943ca89da355421 = '';
        let timeSensor = '';
        let batterySensor = '';
        let stepSensor = '';
        let heartSensor = '';
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
                    edit_id: 1,
                    x: 0,
                    y: 0,
                    bg_config: [
                        {
                            'id': 1,
                            'path': '4.png',
                            'preview': '4.png'
                        },
                        {
                            'id': 2,
                            'path': '5.png',
                            'preview': '5.png'
                        }
                    ],
                    count: 2,
                    default_id: 1,
                    fg: '3.png',
                    tips_x: 0,
                    tips_y: 0,
                    tips_bg: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                });
                normal$_$text_cc79ac9bca234437871180a61886b27b = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 12,
                    y: 227,
                    w: 100,
                    h: 40,
                    text: '[WEEK_EN_S]',
                    color: '0xFFffffff',
                    text_size: 20,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_17e4c901df0045cab6ae69cfab45624b = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 270,
                    y: 182,
                    w: 100,
                    h: 40,
                    text: '[DAY_Z]-[MON_Z]',
                    color: '0xFFffffff',
                    text_size: 17,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_ff3e42518d124d1e996116c4d86e7243 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 40,
                    y: 390,
                    w: 80,
                    h: 40,
                    text: '[BATT_PER]%',
                    color: '0xFFffffff',
                    text_size: 20,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_0d94c5fec39a4af78d58b94577273a47 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 155,
                    y: 390,
                    w: 80,
                    h: 40,
                    text: '[SC]',
                    color: '0xFFffffff',
                    text_size: 20,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_1355db85538f43668944107048bd818e = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 264,
                    y: 390,
                    w: 80,
                    h: 40,
                    text: '[HR]',
                    color: '0xFFffffff',
                    text_size: 20,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.RIGHT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 17,
                    y: 399,
                    src: '6.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 350,
                    y: 400,
                    src: '7.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 170,
                    y: 6,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: [
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: -8,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '20.png',
                    unit_tc: '20.png',
                    unit_en: '20.png',
                    negative_image: '19.png',
                    invalid_image: '18.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 203,
                    y: 4,
                    w: 32,
                    h: 32,
                    src: '21.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_val: new Date().getHours(),
                    hour_zero: 1,
                    hour_startX: 43,
                    hour_startY: 62,
                    hour_array: [
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png'
                    ],
                    hour_space: -80,
                    hour_align: hmUI.align.CENTER_H,
                    minute_zero: 1,
                    minute_startX: 106,
                    minute_startY: 200,
                    minute_array: [
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png'
                    ],
                    minute_space: -90,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 184,
                    y: 40,
                    image_array: [
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png',
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png',
                        '58.png',
                        '59.png',
                        '60.png',
                        '61.png',
                        '62.png',
                        '63.png',
                        '64.png',
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png'
                    ],
                    image_length: 29,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                idle$_$text_f9cd5652636c4464862decbb4e1dc0a7 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 155,
                    y: 390,
                    w: 80,
                    h: 40,
                    text: '[SC]',
                    color: '0xFF686868',
                    text_size: 20,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                idle$_$text_da61c7e3396c46a39b113c863260f959 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 39,
                    y: 390,
                    w: 80,
                    h: 40,
                    text: '[BATT_PER]%',
                    color: '0xFF686868',
                    text_size: 20,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                idle$_$text_10abb7046b1c4ef9a7996842c871f02f = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 12,
                    y: 227,
                    w: 100,
                    h: 40,
                    text: '[WEEK_EN_S]',
                    color: '0xFF686868',
                    text_size: 17,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_val: new Date().getHours(),
                    hour_zero: 1,
                    hour_startX: 43,
                    hour_startY: 62,
                    hour_array: [
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png'
                    ],
                    hour_space: -80,
                    hour_align: hmUI.align.CENTER_H,
                    minute_zero: 1,
                    minute_startX: 106,
                    minute_startY: 200,
                    minute_array: [
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png'
                    ],
                    minute_space: -90,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 175,
                    y: 6,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: [
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: -8,
                    show_level: hmUI.show_level.ONLY_AOD,
                    unit_sc: '20.png',
                    unit_tc: '20.png',
                    unit_en: '20.png',
                    negative_image: '19.png',
                    invalid_image: '71.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 203,
                    y: 4,
                    w: 32,
                    h: 32,
                    src: '72.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                idle$_$text_d7eb4a4553dc46108659e145172d4385 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 264,
                    y: 390,
                    w: 100,
                    h: 40,
                    text: '[HR]',
                    color: '0xFF686868',
                    text_size: 20,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.RIGHT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                idle$_$text_bf645ffc9ae14663b943ca89da355421 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 270,
                    y: 182,
                    w: 100,
                    h: 40,
                    text: '[DAY_Z]-[MON_Z]',
                    color: '0xFF686868',
                    text_size: 17,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 184,
                    y: 40,
                    image_array: [
                        '73.png',
                        '74.png',
                        '75.png',
                        '76.png',
                        '77.png',
                        '78.png',
                        '79.png',
                        '80.png',
                        '81.png',
                        '82.png',
                        '83.png',
                        '84.png',
                        '85.png',
                        '86.png',
                        '87.png',
                        '88.png',
                        '89.png',
                        '90.png',
                        '91.png',
                        '92.png',
                        '93.png',
                        '94.png',
                        '95.png',
                        '96.png',
                        '97.png',
                        '98.png',
                        '99.png',
                        '100.png',
                        '101.png'
                    ],
                    image_length: 29,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                if (!timeSensor) {
                    timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                }
                if (!batterySensor) {
                    batterySensor = hmSensor.createSensor(hmSensor.id.BATTERY);
                }
                if (!stepSensor) {
                    stepSensor = hmSensor.createSensor(hmSensor.id.STEP);
                }
                if (!heartSensor) {
                    heartSensor = hmSensor.createSensor(hmSensor.id.HEART);
                }
                timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
                    const WEEK_EN_S = function (val) {
                        const valueMap = {
                            '1': 'Mon',
                            '2': 'Tue',
                            '3': 'Wed',
                            '4': 'Thu',
                            '5': 'Fri',
                            '6': 'Sat',
                            '7': 'Sun'
                        };
                        return valueMap[val];
                    };
                    normal$_$text_cc79ac9bca234437871180a61886b27b.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_S(timeSensor.week) }` });
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_17e4c901df0045cab6ae69cfab45624b.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }-${ String(timeSensor.day).padStart(2, '0') }` });
                        },
                        () => {
                            normal$_$text_17e4c901df0045cab6ae69cfab45624b.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }-${ String(timeSensor.month).padStart(2, '0') }` });
                        },
                        () => {
                            normal$_$text_17e4c901df0045cab6ae69cfab45624b.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }-${ String(timeSensor.day).padStart(2, '0') }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                    idle$_$text_10abb7046b1c4ef9a7996842c871f02f.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_S(timeSensor.week) }` });
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            idle$_$text_bf645ffc9ae14663b943ca89da355421.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }-${ String(timeSensor.day).padStart(2, '0') }` });
                        },
                        () => {
                            idle$_$text_bf645ffc9ae14663b943ca89da355421.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }-${ String(timeSensor.month).padStart(2, '0') }` });
                        },
                        () => {
                            idle$_$text_bf645ffc9ae14663b943ca89da355421.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }-${ String(timeSensor.day).padStart(2, '0') }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                }), batterySensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_ff3e42518d124d1e996116c4d86e7243.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }%` });
                    idle$_$text_da61c7e3396c46a39b113c863260f959.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }%` });
                }), stepSensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_0d94c5fec39a4af78d58b94577273a47.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                    idle$_$text_f9cd5652636c4464862decbb4e1dc0a7.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                }), heartSensor.addEventListener(heartSensor.event.LAST, function () {
                    normal$_$text_1355db85538f43668944107048bd818e.setProperty(hmUI.prop.MORE, { text: `${ heartSensor.last }` });
                    idle$_$text_d7eb4a4553dc46108659e145172d4385.setProperty(hmUI.prop.MORE, { text: `${ heartSensor.last }` });
                });
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        const WEEK_EN_S = function (val) {
                            const valueMap = {
                                '1': 'Mon',
                                '2': 'Tue',
                                '3': 'Wed',
                                '4': 'Thu',
                                '5': 'Fri',
                                '6': 'Sat',
                                '7': 'Sun'
                            };
                            return valueMap[val];
                        };
                        normal$_$text_cc79ac9bca234437871180a61886b27b.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_S(timeSensor.week) }` });
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                normal$_$text_17e4c901df0045cab6ae69cfab45624b.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }-${ String(timeSensor.day).padStart(2, '0') }` });
                            },
                            () => {
                                normal$_$text_17e4c901df0045cab6ae69cfab45624b.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }-${ String(timeSensor.month).padStart(2, '0') }` });
                            },
                            () => {
                                normal$_$text_17e4c901df0045cab6ae69cfab45624b.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }-${ String(timeSensor.day).padStart(2, '0') }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                        normal$_$text_ff3e42518d124d1e996116c4d86e7243.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }%` });
                        normal$_$text_0d94c5fec39a4af78d58b94577273a47.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                        normal$_$text_1355db85538f43668944107048bd818e.setProperty(hmUI.prop.MORE, { text: `${ heartSensor.last }` });
                        idle$_$text_f9cd5652636c4464862decbb4e1dc0a7.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                        idle$_$text_da61c7e3396c46a39b113c863260f959.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }%` });
                        idle$_$text_10abb7046b1c4ef9a7996842c871f02f.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_S(timeSensor.week) }` });
                        idle$_$text_d7eb4a4553dc46108659e145172d4385.setProperty(hmUI.prop.MORE, { text: `${ heartSensor.last }` });
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                idle$_$text_bf645ffc9ae14663b943ca89da355421.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }-${ String(timeSensor.day).padStart(2, '0') }` });
                            },
                            () => {
                                idle$_$text_bf645ffc9ae14663b943ca89da355421.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }-${ String(timeSensor.month).padStart(2, '0') }` });
                            },
                            () => {
                                idle$_$text_bf645ffc9ae14663b943ca89da355421.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }-${ String(timeSensor.day).padStart(2, '0') }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}