try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_88b6861850cd45218ad831e59b478995 = '';
        let normal$_$text_0a2d416b405947e7abacfb9128a90a61 = '';
        let normal$_$text_3b2e61edc46340c4a3b26c0bbf546899 = '';
        let normal$_$text_3c9aa821f563488eb75cd049aaf2dd1d = '';
        let dateFormat = '';
        let dateFormatMap = '';
        let timeSensor = '';
        let stepSensor = '';
        let heartSensor = '';
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                normal$_$text_88b6861850cd45218ad831e59b478995 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 0,
                    y: 180,
                    w: 194,
                    h: 60,
                    text: '[WEEK_EN_S]',
                    color: '0xFFffffff',
                    text_size: 57,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_0a2d416b405947e7abacfb9128a90a61 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 10,
                    y: 300,
                    w: 184,
                    h: 60,
                    text: '[SC]',
                    color: '0xFF00ff00',
                    text_size: 60,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.RIGHT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 240,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_3b2e61edc46340c4a3b26c0bbf546899 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 70,
                    y: 240,
                    w: 124,
                    h: 60,
                    text: '[HR]',
                    color: '0xFFff0000',
                    text_size: 60,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.RIGHT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 300,
                    src: '3.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 0,
                    hour_startY: 0,
                    hour_array: [
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png'
                    ],
                    hour_space: 0,
                    hour_align: hmUI.align.LEFT,
                    minute_val: new Date().getMinutes(),
                    minute_zero: 1,
                    minute_startX: 42,
                    minute_startY: 90,
                    minute_array: [
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png'
                    ],
                    minute_space: 0,
                    minute_align: hmUI.align.CENTER_H,
                    minute_follow: 0,
                    second_zero: 1,
                    second_startX: 150,
                    second_startY: 0,
                    second_array: [
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png'
                    ],
                    second_space: 0,
                    second_align: hmUI.align.LEFT,
                    second_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_3c9aa821f563488eb75cd049aaf2dd1d = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 0,
                    y: 180,
                    w: 194,
                    h: 60,
                    text: '[DAY]',
                    color: '0xFFffffff',
                    text_size: 57,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.RIGHT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 150,
                    y: 0,
                    src: '24.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                if (!timeSensor) {
                    timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                }
                if (!stepSensor) {
                    stepSensor = hmSensor.createSensor(hmSensor.id.STEP);
                }
                if (!heartSensor) {
                    heartSensor = hmSensor.createSensor(hmSensor.id.HEART);
                }
                timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
                    const WEEK_EN_S = function (val) {
                        const valueMap = {
                            '1': 'Mon',
                            '2': 'Tue',
                            '3': 'Wed',
                            '4': 'Thu',
                            '5': 'Fri',
                            '6': 'Sat',
                            '7': 'Sun'
                        };
                        return valueMap[val];
                    };
                    normal$_$text_88b6861850cd45218ad831e59b478995.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_S(timeSensor.week) }` });
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_3c9aa821f563488eb75cd049aaf2dd1d.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                        },
                        () => {
                            normal$_$text_3c9aa821f563488eb75cd049aaf2dd1d.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                        },
                        () => {
                            normal$_$text_3c9aa821f563488eb75cd049aaf2dd1d.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                }), stepSensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_0a2d416b405947e7abacfb9128a90a61.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                }), heartSensor.addEventListener(heartSensor.event.LAST, function () {
                    normal$_$text_3b2e61edc46340c4a3b26c0bbf546899.setProperty(hmUI.prop.MORE, { text: `${ heartSensor.last }` });
                });
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        const WEEK_EN_S = function (val) {
                            const valueMap = {
                                '1': 'Mon',
                                '2': 'Tue',
                                '3': 'Wed',
                                '4': 'Thu',
                                '5': 'Fri',
                                '6': 'Sat',
                                '7': 'Sun'
                            };
                            return valueMap[val];
                        };
                        normal$_$text_88b6861850cd45218ad831e59b478995.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_S(timeSensor.week) }` });
                        normal$_$text_0a2d416b405947e7abacfb9128a90a61.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                        normal$_$text_3b2e61edc46340c4a3b26c0bbf546899.setProperty(hmUI.prop.MORE, { text: `${ heartSensor.last }` });
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                normal$_$text_3c9aa821f563488eb75cd049aaf2dd1d.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                            },
                            () => {
                                normal$_$text_3c9aa821f563488eb75cd049aaf2dd1d.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                            },
                            () => {
                                normal$_$text_3c9aa821f563488eb75cd049aaf2dd1d.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}