try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_934d0a586dc14acc8529a740fc2e9b38 = '';
        let dateFormat = '';
        let dateFormatMap = '';
        let normal$_$text_0b8172eecb154e3cb33929aa645863aa = '';
        let normal$_$text_9386a6009e134cf79360c52dab8f3afa = '';
        let normal$_$text_52a8c4d0bbe44807b1f2261673f503a4 = '';
        let idle$_$text_5e6e7a0324864d61bbcf8aeef9cbe5a7 = '';
        let timeSensor = '';
        let stepSensor = '';
        let batterySensor = '';
        const logger = Logger.getLogger('watchface6');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 194,
                    h: 368,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 97,
                    center_y: 211,
                    radius: 83,
                    start_angle: 0,
                    end_angle: 360,
                    color: 4280982927,
                    line_width: 9,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 97,
                    center_y: 211,
                    radius: 72,
                    start_angle: 0,
                    end_angle: 360,
                    color: 4294222433,
                    line_width: 7,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 45,
                    hour_startY: 20,
                    hour_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    hour_space: 0,
                    hour_align: hmUI.align.RIGHT,
                    minute_zero: 1,
                    minute_startX: 105,
                    minute_startY: 20,
                    minute_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    minute_space: 0,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 92,
                    y: 20,
                    src: '13.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 96,
                    hour_centerY: 211,
                    hour_posX: 4,
                    hour_posY: 56,
                    hour_path: '14.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 97,
                    minute_centerY: 211,
                    minute_posX: 3,
                    minute_posY: 72,
                    minute_path: '15.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_934d0a586dc14acc8529a740fc2e9b38 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 10,
                    y: 78,
                    w: 60,
                    h: 25,
                    text: '[MON]/[DAY]',
                    color: '0xFF999999',
                    text_size: 21,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_0b8172eecb154e3cb33929aa645863aa = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 123,
                    y: 80,
                    w: 60,
                    h: 25,
                    text: '[WEEK_EN_S]',
                    color: '0xFF999999',
                    text_size: 21,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.RIGHT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 10,
                    y: 326,
                    src: '16.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_9386a6009e134cf79360c52dab8f3afa = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 37,
                    y: 326,
                    w: 55,
                    h: 24,
                    text: '[SC]',
                    color: '0xFF2A9D8F',
                    text_size: 21,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 162,
                    y: 326,
                    src: '17.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_52a8c4d0bbe44807b1f2261673f503a4 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 105,
                    y: 326,
                    w: 55,
                    h: 24,
                    text: '[BATT_PER]%',
                    color: '0xFFF4A261',
                    text_size: 21,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.RIGHT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 194,
                    h: 368,
                    src: '18.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 97,
                    hour_centerY: 211,
                    hour_posX: 5,
                    hour_posY: 56,
                    hour_path: '19.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 97,
                    minute_centerY: 211,
                    minute_posX: 3,
                    minute_posY: 72,
                    minute_path: '20.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                idle$_$text_5e6e7a0324864d61bbcf8aeef9cbe5a7 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 47,
                    y: 37,
                    w: 100,
                    h: 40,
                    text: '[HOUR_24]:[MIN_Z]',
                    color: '0xFF999999',
                    text_size: 28,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                if (!timeSensor) {
                    timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                }
                if (!stepSensor) {
                    stepSensor = hmSensor.createSensor(hmSensor.id.STEP);
                }
                if (!batterySensor) {
                    batterySensor = hmSensor.createSensor(hmSensor.id.BATTERY);
                }
                timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_934d0a586dc14acc8529a740fc2e9b38.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.month }/${ timeSensor.day }` });
                        },
                        () => {
                            normal$_$text_934d0a586dc14acc8529a740fc2e9b38.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }/${ timeSensor.month }` });
                        },
                        () => {
                            normal$_$text_934d0a586dc14acc8529a740fc2e9b38.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.month }/${ timeSensor.day }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                    const WEEK_EN_S = function (val) {
                        const valueMap = {
                            '1': 'Mon',
                            '2': 'Tue',
                            '3': 'Wed',
                            '4': 'Thu',
                            '5': 'Fri',
                            '6': 'Sat',
                            '7': 'Sun'
                        };
                        return valueMap[val];
                    };
                    normal$_$text_0b8172eecb154e3cb33929aa645863aa.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_S(timeSensor.week) }` });
                }), stepSensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_9386a6009e134cf79360c52dab8f3afa.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                }), batterySensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_52a8c4d0bbe44807b1f2261673f503a4.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }%` });
                }), timeSensor.addEventListener(timeSensor.event.MINUTEEND, function () {
                    idle$_$text_5e6e7a0324864d61bbcf8aeef9cbe5a7.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.hour }:${ String(timeSensor.minute).padStart(2, '0') }` });
                });
                idle$_$text_5e6e7a0324864d61bbcf8aeef9cbe5a7.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.hour }:${ String(timeSensor.minute).padStart(2, '0') }` });
                timer.createTimer(0, 1000, function (timeSensor2) {
                    idle$_$text_5e6e7a0324864d61bbcf8aeef9cbe5a7.setProperty(hmUI.prop.MORE, { text: `${ timeSensor2.hour }:${ String(timeSensor2.minute).padStart(2, '0') }` });
                }, timeSensor);
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                normal$_$text_934d0a586dc14acc8529a740fc2e9b38.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.month }/${ timeSensor.day }` });
                            },
                            () => {
                                normal$_$text_934d0a586dc14acc8529a740fc2e9b38.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }/${ timeSensor.month }` });
                            },
                            () => {
                                normal$_$text_934d0a586dc14acc8529a740fc2e9b38.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.month }/${ timeSensor.day }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                        const WEEK_EN_S = function (val) {
                            const valueMap = {
                                '1': 'Mon',
                                '2': 'Tue',
                                '3': 'Wed',
                                '4': 'Thu',
                                '5': 'Fri',
                                '6': 'Sat',
                                '7': 'Sun'
                            };
                            return valueMap[val];
                        };
                        normal$_$text_0b8172eecb154e3cb33929aa645863aa.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_S(timeSensor.week) }` });
                        normal$_$text_9386a6009e134cf79360c52dab8f3afa.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                        normal$_$text_52a8c4d0bbe44807b1f2261673f503a4.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }%` });
                        idle$_$text_5e6e7a0324864d61bbcf8aeef9cbe5a7.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.hour }:${ String(timeSensor.minute).padStart(2, '0') }` });
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}