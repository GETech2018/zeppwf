try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_dfc8d3afd2b84d01b353c2c2d2faea88 = '';
        let normal$_$text_39a9c5c0437e4dcba8c4ebe33f2461e1 = '';
        let dateFormat = '';
        let dateFormatMap = '';
        let normal$_$text_a72846b238f94e9ab753dee4f2366ce8 = '';
        let normal$_$text_219c10ad54b84ca4a67038f399e805b7 = '';
        let normal$_$text_e553f25bc5e445f5b9cd798be5fb14ae = '';
        let normal$_$text_919b68df4ccb42ab8a0d2e35799ae38e = '';
        let timeSensor = '';
        let batterySensor = '';
        let stepSensor = '';
        let heartSensor = '';
        const logger = Logger.getLogger('watchface6');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 194,
                    h: 368,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_dfc8d3afd2b84d01b353c2c2d2faea88 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 130,
                    y: 145,
                    w: 84,
                    h: 40,
                    text: '[HOUR_24_Z]:[MIN_Z]:[SEC_Z]',
                    color: '0xFFffffff',
                    text_size: 14,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_39a9c5c0437e4dcba8c4ebe33f2461e1 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 130,
                    y: 166,
                    w: 100,
                    h: 40,
                    text: '[DAY]/[MON]/[YEAR]',
                    color: '0xFFffffff',
                    text_size: 14,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_a72846b238f94e9ab753dee4f2366ce8 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 130,
                    y: 186,
                    w: 100,
                    h: 40,
                    text: '%[BATT_PER]',
                    color: '0xFFffffff',
                    text_size: 14,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_219c10ad54b84ca4a67038f399e805b7 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 122,
                    y: 206,
                    w: 100,
                    h: 40,
                    text: '[SC]',
                    color: '0xFFffffff',
                    text_size: 14,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_e553f25bc5e445f5b9cd798be5fb14ae = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 122,
                    y: 227,
                    w: 100,
                    h: 40,
                    text: '[HR]',
                    color: '0xFFffffff',
                    text_size: 14,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_919b68df4ccb42ab8a0d2e35799ae38e = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 122,
                    y: 247,
                    w: 100,
                    h: 30,
                    text: '[WEEK_EN_S]',
                    color: '0xFFffffff',
                    text_size: 14,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                if (!timeSensor) {
                    timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                }
                if (!batterySensor) {
                    batterySensor = hmSensor.createSensor(hmSensor.id.BATTERY);
                }
                if (!stepSensor) {
                    stepSensor = hmSensor.createSensor(hmSensor.id.STEP);
                }
                if (!heartSensor) {
                    heartSensor = hmSensor.createSensor(hmSensor.id.HEART);
                }
                timeSensor.addEventListener(timeSensor.event.MINUTEEND, function () {
                    normal$_$text_dfc8d3afd2b84d01b353c2c2d2faea88.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }:${ String(timeSensor.minute).padStart(2, '0') }:${ String(timeSensor.second).padStart(2, '0') }` });
                }), timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_39a9c5c0437e4dcba8c4ebe33f2461e1.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }/${ timeSensor.month }/${ timeSensor.day }` });
                        },
                        () => {
                            normal$_$text_39a9c5c0437e4dcba8c4ebe33f2461e1.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }/${ timeSensor.month }/${ timeSensor.year }` });
                        },
                        () => {
                            normal$_$text_39a9c5c0437e4dcba8c4ebe33f2461e1.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.month }/${ timeSensor.day }/${ timeSensor.year }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                    const WEEK_EN_S = function (val) {
                        const valueMap = {
                            '1': 'Mon',
                            '2': 'Tue',
                            '3': 'Wed',
                            '4': 'Thu',
                            '5': 'Fri',
                            '6': 'Sat',
                            '7': 'Sun'
                        };
                        return valueMap[val];
                    };
                    normal$_$text_919b68df4ccb42ab8a0d2e35799ae38e.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_S(timeSensor.week) }` });
                }), batterySensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_a72846b238f94e9ab753dee4f2366ce8.setProperty(hmUI.prop.MORE, { text: `%${ batterySensor.current }` });
                }), stepSensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_219c10ad54b84ca4a67038f399e805b7.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                }), heartSensor.addEventListener(heartSensor.event.LAST, function () {
                    normal$_$text_e553f25bc5e445f5b9cd798be5fb14ae.setProperty(hmUI.prop.MORE, { text: `${ heartSensor.last }` });
                });
                normal$_$text_dfc8d3afd2b84d01b353c2c2d2faea88.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }:${ String(timeSensor.minute).padStart(2, '0') }:${ String(timeSensor.second).padStart(2, '0') }` });
                timer.createTimer(0, 1000, function (timeSensor2) {
                    normal$_$text_dfc8d3afd2b84d01b353c2c2d2faea88.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor2.hour).padStart(2, '0') }:${ String(timeSensor2.minute).padStart(2, '0') }:${ String(timeSensor2.second).padStart(2, '0') }` });
                }, timeSensor);
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        normal$_$text_dfc8d3afd2b84d01b353c2c2d2faea88.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }:${ String(timeSensor.minute).padStart(2, '0') }:${ String(timeSensor.second).padStart(2, '0') }` });
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                normal$_$text_39a9c5c0437e4dcba8c4ebe33f2461e1.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }/${ timeSensor.month }/${ timeSensor.day }` });
                            },
                            () => {
                                normal$_$text_39a9c5c0437e4dcba8c4ebe33f2461e1.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }/${ timeSensor.month }/${ timeSensor.year }` });
                            },
                            () => {
                                normal$_$text_39a9c5c0437e4dcba8c4ebe33f2461e1.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.month }/${ timeSensor.day }/${ timeSensor.year }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                        normal$_$text_a72846b238f94e9ab753dee4f2366ce8.setProperty(hmUI.prop.MORE, { text: `%${ batterySensor.current }` });
                        normal$_$text_219c10ad54b84ca4a67038f399e805b7.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                        normal$_$text_e553f25bc5e445f5b9cd798be5fb14ae.setProperty(hmUI.prop.MORE, { text: `${ heartSensor.last }` });
                        const WEEK_EN_S = function (val) {
                            const valueMap = {
                                '1': 'Mon',
                                '2': 'Tue',
                                '3': 'Wed',
                                '4': 'Thu',
                                '5': 'Fri',
                                '6': 'Sat',
                                '7': 'Sun'
                            };
                            return valueMap[val];
                        };
                        normal$_$text_919b68df4ccb42ab8a0d2e35799ae38e.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_S(timeSensor.week) }` });
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}