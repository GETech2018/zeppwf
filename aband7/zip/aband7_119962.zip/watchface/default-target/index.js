try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_a172cc630746423bbb71b37736d701f1 = '';
        let dateFormat = '';
        let dateFormatMap = '';
        let normal$_$text_283f514bf97044658d4fc7f4dad656ba = '';
        let timeSensor = '';
        const logger = Logger.getLogger('watchface6');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 194,
                    h: 368,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 50,
                    center_y: 306,
                    radius: 39,
                    start_angle: 0,
                    end_angle: 360,
                    color: 4278245480,
                    line_width: 8,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 29,
                    hour_startY: 68,
                    hour_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    hour_space: 4,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 29,
                    minute_startY: 165,
                    minute_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    minute_space: 4,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 144,
                    center_y: 307,
                    radius: 40,
                    start_angle: 0,
                    end_angle: 360,
                    color: 4294905936,
                    line_width: 8,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 144,
                    center_y: 307,
                    radius: 29,
                    start_angle: 0,
                    end_angle: 360,
                    color: 4288216064,
                    line_width: 8,
                    type: hmUI.data_type.CAL,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 144,
                    center_y: 307,
                    radius: 18,
                    start_angle: 0,
                    end_angle: 360,
                    color: 4278245624,
                    line_width: 8,
                    type: hmUI.data_type.PAI_WEEKLY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_a172cc630746423bbb71b37736d701f1 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 100,
                    y: 0,
                    w: 87,
                    h: 47,
                    text: '[MON_Z] / [DAY_Z]',
                    color: '0xFFffffff',
                    text_size: 23,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_283f514bf97044658d4fc7f4dad656ba = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 0,
                    y: 0,
                    w: 100,
                    h: 47,
                    text: '[WEEK_EN_S]',
                    color: '0xFFff0000',
                    text_size: 27,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 29,
                    hour_startY: 68,
                    hour_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    hour_space: 4,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 29,
                    minute_startY: 165,
                    minute_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    minute_space: 4,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                if (!timeSensor) {
                    timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                }
                timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_a172cc630746423bbb71b37736d701f1.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') } / ${ String(timeSensor.day).padStart(2, '0') }` });
                        },
                        () => {
                            normal$_$text_a172cc630746423bbb71b37736d701f1.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') } / ${ String(timeSensor.month).padStart(2, '0') }` });
                        },
                        () => {
                            normal$_$text_a172cc630746423bbb71b37736d701f1.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') } / ${ String(timeSensor.day).padStart(2, '0') }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                    const WEEK_EN_S = function (val) {
                        const valueMap = {
                            '1': 'Mon',
                            '2': 'Tue',
                            '3': 'Wed',
                            '4': 'Thu',
                            '5': 'Fri',
                            '6': 'Sat',
                            '7': 'Sun'
                        };
                        return valueMap[val];
                    };
                    normal$_$text_283f514bf97044658d4fc7f4dad656ba.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_S(timeSensor.week) }` });
                });
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                normal$_$text_a172cc630746423bbb71b37736d701f1.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') } / ${ String(timeSensor.day).padStart(2, '0') }` });
                            },
                            () => {
                                normal$_$text_a172cc630746423bbb71b37736d701f1.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') } / ${ String(timeSensor.month).padStart(2, '0') }` });
                            },
                            () => {
                                normal$_$text_a172cc630746423bbb71b37736d701f1.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') } / ${ String(timeSensor.day).padStart(2, '0') }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                        const WEEK_EN_S = function (val) {
                            const valueMap = {
                                '1': 'Mon',
                                '2': 'Tue',
                                '3': 'Wed',
                                '4': 'Thu',
                                '5': 'Fri',
                                '6': 'Sat',
                                '7': 'Sun'
                            };
                            return valueMap[val];
                        };
                        normal$_$text_283f514bf97044658d4fc7f4dad656ba.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_S(timeSensor.week) }` });
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}