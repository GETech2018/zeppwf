try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_11729f65230c4f0a8d3315f3a668f9a9 = '';
        let normal$_$text_74124d79b4d340cc99a26f0bd7a2d071 = '';
        let dateFormat = '';
        let dateFormatMap = '';
        let normal$_$text_ebd00bd5bca641e1a30678d7ddd806dd = '';
        let normal$_$text_434de65874ef4c15a3ed4ce045658c2b = '';
        let normal$_$text_79b7d326b10a427e9ea113440255399f = '';
        let normal$_$text_bc9282fd5ed94979a1aea8ee5d1ea23f = '';
        let timeSensor = '';
        let batterySensor = '';
        let stepSensor = '';
        const logger = Logger.getLogger('watchface6');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                normal$_$text_11729f65230c4f0a8d3315f3a668f9a9 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 70,
                    y: 158,
                    w: 100,
                    h: 40,
                    text: '[WEEK_EN_S].',
                    color: '0xFFb0b0b0',
                    text_size: 17,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.RIGHT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_74124d79b4d340cc99a26f0bd7a2d071 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 21,
                    y: 158,
                    w: 100,
                    h: 40,
                    text: '[MON_Z]/[DAY_Z]',
                    color: '0xFFb0b0b0',
                    text_size: 17,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_ebd00bd5bca641e1a30678d7ddd806dd = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 18,
                    y: 101,
                    w: 154,
                    h: 67,
                    text: '[HOUR_24_Z]:[MIN_Z]',
                    color: '0xFFffffff',
                    text_size: 60,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_434de65874ef4c15a3ed4ce045658c2b = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 47,
                    y: 6,
                    w: 100,
                    h: 40,
                    text: '[BATT_PER] %',
                    color: '0xFF059b01',
                    text_size: 25,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_79b7d326b10a427e9ea113440255399f = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 47,
                    y: 318,
                    w: 100,
                    h: 40,
                    text: '[SC]',
                    color: '0xFFffffff',
                    text_size: 25,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.BOTTOM,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_bc9282fd5ed94979a1aea8ee5d1ea23f = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 48,
                    y: 297,
                    w: 100,
                    h: 40,
                    text: 'Steps',
                    color: '0xFFb0b0b0',
                    text_size: 15,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                if (!timeSensor) {
                    timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                }
                if (!batterySensor) {
                    batterySensor = hmSensor.createSensor(hmSensor.id.BATTERY);
                }
                if (!stepSensor) {
                    stepSensor = hmSensor.createSensor(hmSensor.id.STEP);
                }
                timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
                    const WEEK_EN_S = function (val) {
                        const valueMap = {
                            '1': 'Mon',
                            '2': 'Tue',
                            '3': 'Wed',
                            '4': 'Thu',
                            '5': 'Fri',
                            '6': 'Sat',
                            '7': 'Sun'
                        };
                        return valueMap[val];
                    };
                    normal$_$text_11729f65230c4f0a8d3315f3a668f9a9.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_S(timeSensor.week) }.` });
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_74124d79b4d340cc99a26f0bd7a2d071.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }/${ String(timeSensor.day).padStart(2, '0') }` });
                        },
                        () => {
                            normal$_$text_74124d79b4d340cc99a26f0bd7a2d071.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }/${ String(timeSensor.month).padStart(2, '0') }` });
                        },
                        () => {
                            normal$_$text_74124d79b4d340cc99a26f0bd7a2d071.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }/${ String(timeSensor.day).padStart(2, '0') }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                }), timeSensor.addEventListener(timeSensor.event.MINUTEEND, function () {
                    normal$_$text_ebd00bd5bca641e1a30678d7ddd806dd.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }:${ String(timeSensor.minute).padStart(2, '0') }` });
                }), batterySensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_434de65874ef4c15a3ed4ce045658c2b.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current } %` });
                }), stepSensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_79b7d326b10a427e9ea113440255399f.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                });
                normal$_$text_ebd00bd5bca641e1a30678d7ddd806dd.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }:${ String(timeSensor.minute).padStart(2, '0') }` });
                timer.createTimer(0, 1000, function (timeSensor2) {
                    normal$_$text_ebd00bd5bca641e1a30678d7ddd806dd.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor2.hour).padStart(2, '0') }:${ String(timeSensor2.minute).padStart(2, '0') }` });
                }, timeSensor);
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        const WEEK_EN_S = function (val) {
                            const valueMap = {
                                '1': 'Mon',
                                '2': 'Tue',
                                '3': 'Wed',
                                '4': 'Thu',
                                '5': 'Fri',
                                '6': 'Sat',
                                '7': 'Sun'
                            };
                            return valueMap[val];
                        };
                        normal$_$text_11729f65230c4f0a8d3315f3a668f9a9.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_S(timeSensor.week) }.` });
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                normal$_$text_74124d79b4d340cc99a26f0bd7a2d071.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }/${ String(timeSensor.day).padStart(2, '0') }` });
                            },
                            () => {
                                normal$_$text_74124d79b4d340cc99a26f0bd7a2d071.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }/${ String(timeSensor.month).padStart(2, '0') }` });
                            },
                            () => {
                                normal$_$text_74124d79b4d340cc99a26f0bd7a2d071.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }/${ String(timeSensor.day).padStart(2, '0') }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                        normal$_$text_ebd00bd5bca641e1a30678d7ddd806dd.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }:${ String(timeSensor.minute).padStart(2, '0') }` });
                        normal$_$text_434de65874ef4c15a3ed4ce045658c2b.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current } %` });
                        normal$_$text_79b7d326b10a427e9ea113440255399f.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                        normal$_$text_bc9282fd5ed94979a1aea8ee5d1ea23f.setProperty(hmUI.prop.MORE, { text: `Steps` });
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}