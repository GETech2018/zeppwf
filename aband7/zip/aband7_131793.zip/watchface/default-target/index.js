try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_4c3806b83d744a0cb737b26089421d87 = '';
        let idle$_$text_f3890c772ad748d8ba45335d07d80bd0 = '';
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                    x: 0,
                    y: 83,
                    anim_path: '',
                    anim_prefix: 'first_anim_tghnl',
                    anim_ext: 'png',
                    anim_fps: 37,
                    anim_size: 30,
                    display_on_restart: false,
                    repeat_count: 0,
                    anim_status: hmUI.anim_status.START,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 0,
                    hour_startX: 43,
                    hour_startY: 57,
                    hour_array: [
                        '2.png',
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png'
                    ],
                    hour_space: 0,
                    hour_align: hmUI.align.RIGHT,
                    minute_zero: 1,
                    minute_startX: 92,
                    minute_startY: 57,
                    minute_array: [
                        '2.png',
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png'
                    ],
                    minute_space: 0,
                    minute_align: hmUI.align.RIGHT,
                    minute_follow: 0,
                    second_zero: 1,
                    second_startX: 141,
                    second_startY: 57,
                    second_array: [
                        '2.png',
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png'
                    ],
                    second_space: 0,
                    second_align: hmUI.align.RIGHT,
                    second_follow: 0,
                    am_x: 10,
                    am_y: 57,
                    am_en_path: '12.png',
                    pm_x: 10,
                    pm_y: 57,
                    pm_en_path: '13.png',
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 106,
                    y: 10,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: [
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: -2,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '26.png',
                    unit_tc: '26.png',
                    unit_en: '26.png',
                    negative_image: '25.png',
                    invalid_image: '24.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 44,
                    y: 125,
                    type: hmUI.data_type.STEP,
                    font_array: [
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: -2,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 9,
                    y: 127,
                    w: 30,
                    h: 30,
                    src: '27.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 44,
                    y: 164,
                    type: hmUI.data_type.HEART,
                    font_array: [
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: -2,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '28.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 9,
                    y: 165,
                    w: 30,
                    h: 30,
                    src: '29.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 44,
                    y: 202,
                    type: hmUI.data_type.SPO2,
                    font_array: [
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: -2,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '30.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 14,
                    y: 202,
                    w: 19,
                    h: 30,
                    src: '31.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 8,
                    y: 10,
                    type: hmUI.data_type.BATTERY,
                    font_array: [
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: -2,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 72,
                    y: 11,
                    w: 16,
                    h: 30,
                    src: '32.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 29,
                    y: 276,
                    type: hmUI.data_type.DISTANCE,
                    font_array: [
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -2,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '34.png',
                    unit_tc: '34.png',
                    unit_en: '34.png',
                    dot_image: '33.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 57,
                    month_startY: 315,
                    month_sc_array: [
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png'
                    ],
                    month_tc_array: [
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png'
                    ],
                    month_en_array: [
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png'
                    ],
                    month_align: hmUI.align.CENTER_H,
                    month_zero: 0,
                    month_follow: 0,
                    month_space: -2,
                    month_is_character: false,
                    day_startX: 9,
                    day_startY: 315,
                    day_sc_array: [
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png'
                    ],
                    day_tc_array: [
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png'
                    ],
                    day_en_array: [
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png'
                    ],
                    day_align: hmUI.align.CENTER_H,
                    day_zero: 0,
                    day_follow: 0,
                    day_space: -2,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 105,
                    y: 314,
                    week_en: [
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png'
                    ],
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_4c3806b83d744a0cb737b26089421d87 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 45,
                    y: 338,
                    w: 100,
                    h: 40,
                    text: 'AAA',
                    color: '0xFF0900ff',
                    text_size: 18,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 44,
                    y: 240,
                    type: hmUI.data_type.CAL,
                    font_array: [
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: -2,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 13,
                    y: 240,
                    w: 24,
                    h: 30,
                    src: '42.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                idle$_$text_f3890c772ad748d8ba45335d07d80bd0 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 0,
                    y: 336,
                    w: 194,
                    h: 39,
                    text: 'qazzaqplmmlp999@gmail.com',
                    color: '0xFF0900ff',
                    text_size: 18,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 11,
                    hour_startY: 20,
                    hour_array: [
                        '2.png',
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png'
                    ],
                    hour_space: 0,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 11,
                    minute_startY: 83,
                    minute_array: [
                        '2.png',
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png'
                    ],
                    minute_space: 0,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        normal$_$text_4c3806b83d744a0cb737b26089421d87.setProperty(hmUI.prop.MORE, { text: `AAA` });
                        idle$_$text_f3890c772ad748d8ba45335d07d80bd0.setProperty(hmUI.prop.MORE, { text: `qazzaqplmmlp999@gmail.com` });
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}