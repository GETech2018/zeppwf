try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                    x: 0,
                    y: 0,
                    anim_path: '',
                    anim_prefix: 'first_anim_mcxpg',
                    anim_ext: 'png',
                    anim_fps: 34,
                    anim_size: 46,
                    display_on_restart: false,
                    repeat_count: 0,
                    anim_status: hmUI.anim_status.START,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 194,
                    h: 368,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 98,
                    hour_centerY: 184,
                    hour_posX: 9,
                    hour_posY: 54,
                    hour_path: '3.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 97,
                    minute_centerY: 184,
                    minute_posX: 11,
                    minute_posY: 89,
                    minute_path: '4.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    second_centerX: 97,
                    second_centerY: 184,
                    second_posX: 11,
                    second_posY: 100,
                    second_path: '6.png',
                    second_cover_path: '5.png',
                    second_cover_x: 89,
                    second_cover_y: 177,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 0,
                    hour_startX: 36,
                    hour_startY: 46,
                    hour_array: [
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png'
                    ],
                    hour_space: 2,
                    hour_align: hmUI.align.RIGHT,
                    minute_zero: 1,
                    minute_startX: 36,
                    minute_startY: 101,
                    minute_array: [
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png'
                    ],
                    minute_space: 2,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}