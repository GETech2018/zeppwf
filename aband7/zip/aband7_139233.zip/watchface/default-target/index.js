try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_d1ed7ada96094cdeab8e07ff6a20bc53 = '';
        let normal$_$text_9b69669b393048f2a925dec836988927 = '';
        let normal$_$text_7d150ef4f2374f7f9e0cd1a2f719413a = '';
        let normal$_$text_66275a45cac045b1b6b197fd084a38d2 = '';
        let normal$_$text_acc8a652974a42db808d8d6a84f71446 = '';
        let dateFormat = '';
        let dateFormatMap = '';
        let normal$_$text_f535a899769847059a76e877d8f0af7f = '';
        let stepSensor = '';
        let batterySensor = '';
        let calorieSensor = '';
        let timeSensor = '';
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.FILL_RECT, {
                    x: 0,
                    y: 0,
                    w: 194,
                    h: 368,
                    color: '0xFF141414',
                    radius: 25,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 329,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_PROGRESS, {
                    x: [
                        4,
                        4,
                        42,
                        42,
                        80,
                        80,
                        118,
                        118,
                        156,
                        156
                    ],
                    y: [
                        329,
                        329,
                        329,
                        329,
                        329,
                        329,
                        329,
                        329,
                        329,
                        329
                    ],
                    image_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    image_length: 10,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 329,
                    src: '13.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                    x: 0,
                    y: 0,
                    anim_path: '',
                    anim_prefix: 'first_anim_limek',
                    anim_ext: 'png',
                    anim_fps: 1000,
                    anim_size: 25,
                    display_on_restart: false,
                    repeat_count: 0,
                    anim_status: hmUI.anim_status.START,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                    x: 6,
                    y: 290,
                    anim_path: '',
                    anim_prefix: 'second_anim_wboru',
                    anim_ext: 'png',
                    anim_fps: 2,
                    anim_size: 13,
                    display_on_restart: false,
                    repeat_count: 0,
                    anim_status: hmUI.anim_status.START,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_val: new Date().getHours(),
                    hour_zero: 1,
                    hour_startX: 4,
                    hour_startY: 153,
                    hour_array: [
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png'
                    ],
                    hour_space: 0,
                    hour_align: hmUI.align.CENTER_H,
                    minute_val: new Date().getMinutes(),
                    minute_zero: 1,
                    minute_startX: 26,
                    minute_startY: 211,
                    minute_array: [
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png'
                    ],
                    minute_space: 0,
                    minute_align: hmUI.align.CENTER_H,
                    minute_follow: 0,
                    second_zero: 1,
                    second_startX: 145,
                    second_startY: 221,
                    second_array: [
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png'
                    ],
                    second_space: 0,
                    second_align: hmUI.align.LEFT,
                    second_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 128,
                    y: 293,
                    type: hmUI.data_type.HEART,
                    font_array: [
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 5,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '54.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 25,
                    y: 7,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: [
                        '55.png',
                        '56.png',
                        '57.png',
                        '58.png',
                        '59.png',
                        '60.png',
                        '61.png',
                        '62.png',
                        '63.png',
                        '64.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 1,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    negative_image: '66.png',
                    invalid_image: '65.png',
                    padding: false,
                    isCharacter: false
                });
                normal$_$text_d1ed7ada96094cdeab8e07ff6a20bc53 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 69,
                    y: 351,
                    w: 64,
                    h: 14,
                    text: '[SC]',
                    color: '0xFF1a5e14',
                    text_size: 14,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_9b69669b393048f2a925dec836988927 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 132,
                    y: 4,
                    w: 47,
                    h: 22,
                    text: '[BATT_PER]',
                    color: '0xFF419241',
                    text_size: 17,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_7d150ef4f2374f7f9e0cd1a2f719413a = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 134,
                    y: 69,
                    w: 46,
                    h: 32,
                    text: '[CAL]',
                    color: '0xFF713d16',
                    text_size: 17,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_66275a45cac045b1b6b197fd084a38d2 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 124,
                    y: 161,
                    w: 67,
                    h: 24,
                    text: '[WEEK_EN_S]',
                    color: '0xFF6f6f6f',
                    text_size: 15,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_acc8a652974a42db808d8d6a84f71446 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 125,
                    y: 177,
                    w: 38,
                    h: 31,
                    text: '[DAY_Z]/',
                    color: '0xFF6f6f6f',
                    text_size: 17,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.RIGHT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_f535a899769847059a76e877d8f0af7f = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 162,
                    y: 177,
                    w: 28,
                    h: 31,
                    text: '[MON_Z]',
                    color: '0xFF6f6f6f',
                    text_size: 17,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                if (!stepSensor) {
                    stepSensor = hmSensor.createSensor(hmSensor.id.STEP);
                }
                if (!batterySensor) {
                    batterySensor = hmSensor.createSensor(hmSensor.id.BATTERY);
                }
                if (!calorieSensor) {
                    calorieSensor = hmSensor.createSensor(hmSensor.id.CALORIE);
                }
                if (!timeSensor) {
                    timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                }
                stepSensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_d1ed7ada96094cdeab8e07ff6a20bc53.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                }), batterySensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_9b69669b393048f2a925dec836988927.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }` });
                }), calorieSensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_7d150ef4f2374f7f9e0cd1a2f719413a.setProperty(hmUI.prop.MORE, { text: `${ calorieSensor.current }` });
                }), timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
                    const WEEK_EN_S = function (val) {
                        const valueMap = {
                            '1': 'Mon',
                            '2': 'Tue',
                            '3': 'Wed',
                            '4': 'Thu',
                            '5': 'Fri',
                            '6': 'Sat',
                            '7': 'Sun'
                        };
                        return valueMap[val];
                    };
                    normal$_$text_66275a45cac045b1b6b197fd084a38d2.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_S(timeSensor.week) }` });
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_acc8a652974a42db808d8d6a84f71446.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }/` });
                        },
                        () => {
                            normal$_$text_acc8a652974a42db808d8d6a84f71446.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }/` });
                        },
                        () => {
                            normal$_$text_acc8a652974a42db808d8d6a84f71446.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }/` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_f535a899769847059a76e877d8f0af7f.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }` });
                        },
                        () => {
                            normal$_$text_f535a899769847059a76e877d8f0af7f.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }` });
                        },
                        () => {
                            normal$_$text_f535a899769847059a76e877d8f0af7f.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 0,
                    y: 282,
                    w: 194,
                    h: 83,
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 1,
                    y: 1,
                    w: 191,
                    h: 63,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        normal$_$text_d1ed7ada96094cdeab8e07ff6a20bc53.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                        normal$_$text_9b69669b393048f2a925dec836988927.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }` });
                        normal$_$text_7d150ef4f2374f7f9e0cd1a2f719413a.setProperty(hmUI.prop.MORE, { text: `${ calorieSensor.current }` });
                        const WEEK_EN_S = function (val) {
                            const valueMap = {
                                '1': 'Mon',
                                '2': 'Tue',
                                '3': 'Wed',
                                '4': 'Thu',
                                '5': 'Fri',
                                '6': 'Sat',
                                '7': 'Sun'
                            };
                            return valueMap[val];
                        };
                        normal$_$text_66275a45cac045b1b6b197fd084a38d2.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_S(timeSensor.week) }` });
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                normal$_$text_acc8a652974a42db808d8d6a84f71446.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }/` });
                            },
                            () => {
                                normal$_$text_acc8a652974a42db808d8d6a84f71446.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }/` });
                            },
                            () => {
                                normal$_$text_acc8a652974a42db808d8d6a84f71446.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }/` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                normal$_$text_f535a899769847059a76e877d8f0af7f.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }` });
                            },
                            () => {
                                normal$_$text_f535a899769847059a76e877d8f0af7f.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }` });
                            },
                            () => {
                                normal$_$text_f535a899769847059a76e877d8f0af7f.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}