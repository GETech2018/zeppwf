try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_4fff766c596d440589dd704dc1d36fe6 = '';
        let normal$_$text_ed0453258fd34cf6b3b8c0d5fcd37402 = '';
        let normal$_$text_7d2144f2d6bf4cb88e3e7df69ca2474e = '';
        let dateFormat = '';
        let dateFormatMap = '';
        let normal$_$text_eab9173d6bfa45db859167b7051061cb = '';
        let timeSensor = '';
        let heartSensor = '';
        let batterySensor = '';
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 194,
                    h: 368,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_4fff766c596d440589dd704dc1d36fe6 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 8,
                    y: 290,
                    w: 185,
                    h: 40,
                    text: '[WEEK_EN_F]',
                    color: '0xFF000a0d',
                    text_size: 31,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 0,
                    hour_startX: 6,
                    hour_startY: 233,
                    hour_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    hour_space: -4,
                    hour_align: hmUI.align.RIGHT,
                    minute_zero: 1,
                    minute_startX: 99,
                    minute_startY: 234,
                    minute_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    minute_space: -4,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 80,
                    y: 231,
                    src: '23.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_ed0453258fd34cf6b3b8c0d5fcd37402 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 0,
                    y: 77,
                    w: 48,
                    h: 52,
                    text: '[HR]',
                    color: '0xFF000000',
                    text_size: 20,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_7d2144f2d6bf4cb88e3e7df69ca2474e = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 48,
                    y: 12,
                    w: 100,
                    h: 40,
                    text: '[MON]/[DAY]',
                    color: '0xFF0a000b',
                    text_size: 33,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_eab9173d6bfa45db859167b7051061cb = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 156,
                    y: 88,
                    w: 42,
                    h: 30,
                    text: '[BATT_PER]',
                    color: '0xFF5c03fa',
                    text_size: 23,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                if (!timeSensor) {
                    timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                }
                if (!heartSensor) {
                    heartSensor = hmSensor.createSensor(hmSensor.id.HEART);
                }
                if (!batterySensor) {
                    batterySensor = hmSensor.createSensor(hmSensor.id.BATTERY);
                }
                timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
                    const WEEK_EN_F = function (val) {
                        const valueMap = {
                            '1': 'Monday',
                            '2': 'Tuesday',
                            '3': 'Wednesday',
                            '4': 'Thursday',
                            '5': 'Friday',
                            '6': 'Saturday',
                            '7': 'Sunday'
                        };
                        return valueMap[val];
                    };
                    normal$_$text_4fff766c596d440589dd704dc1d36fe6.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_F(timeSensor.week) }` });
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_7d2144f2d6bf4cb88e3e7df69ca2474e.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.month }/${ timeSensor.day }` });
                        },
                        () => {
                            normal$_$text_7d2144f2d6bf4cb88e3e7df69ca2474e.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }/${ timeSensor.month }` });
                        },
                        () => {
                            normal$_$text_7d2144f2d6bf4cb88e3e7df69ca2474e.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.month }/${ timeSensor.day }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                }), heartSensor.addEventListener(heartSensor.event.LAST, function () {
                    normal$_$text_ed0453258fd34cf6b3b8c0d5fcd37402.setProperty(hmUI.prop.MORE, { text: `${ heartSensor.last }` });
                }), batterySensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_eab9173d6bfa45db859167b7051061cb.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }` });
                });
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        const WEEK_EN_F = function (val) {
                            const valueMap = {
                                '1': 'Monday',
                                '2': 'Tuesday',
                                '3': 'Wednesday',
                                '4': 'Thursday',
                                '5': 'Friday',
                                '6': 'Saturday',
                                '7': 'Sunday'
                            };
                            return valueMap[val];
                        };
                        normal$_$text_4fff766c596d440589dd704dc1d36fe6.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_F(timeSensor.week) }` });
                        normal$_$text_ed0453258fd34cf6b3b8c0d5fcd37402.setProperty(hmUI.prop.MORE, { text: `${ heartSensor.last }` });
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                normal$_$text_7d2144f2d6bf4cb88e3e7df69ca2474e.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.month }/${ timeSensor.day }` });
                            },
                            () => {
                                normal$_$text_7d2144f2d6bf4cb88e3e7df69ca2474e.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }/${ timeSensor.month }` });
                            },
                            () => {
                                normal$_$text_7d2144f2d6bf4cb88e3e7df69ca2474e.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.month }/${ timeSensor.day }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                        normal$_$text_eab9173d6bfa45db859167b7051061cb.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }` });
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}