try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface6');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.FILL_RECT, {
                    x: 0,
                    y: 0,
                    w: 416,
                    h: 416,
                    color: '0xFF000000',
                    radius: 208,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 208,
                    hour_centerY: 208,
                    hour_posX: 35,
                    hour_posY: 208,
                    hour_path: '2.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 208,
                    minute_centerY: 208,
                    minute_posX: 35,
                    minute_posY: 208,
                    minute_path: '3.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    second_centerX: 208,
                    second_centerY: 208,
                    second_posX: 35,
                    second_posY: 208,
                    second_path: '4.png',
                    second_cover_x: 0,
                    second_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 208,
                    hour_centerY: 208,
                    hour_posX: 35,
                    hour_posY: 208,
                    hour_path: '5.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 208,
                    minute_centerY: 208,
                    minute_posX: 35,
                    minute_posY: 208,
                    minute_path: '6.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}