try {
    (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;

        var __$$module$$__ = __$$app$$__.current;
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        /*
         * huamiOS bundle tool v1.0.17
         * Copyright © Huami. All Rights Reserved
         */
        'use strict';

        console.log("----->>>current");
        console.log(__$$hmAppManager$$__.currentApp.pid);
        console.log(__$$hmAppManager$$__.currentApp.current);
        const rootPath = "images/"
        const clock_timer = null
        const weekArray_en = []
        const weekArray_sc = []
        const weekArray_tc = []
        const timeArray = []
        const dateArray = []
        let num = 0.86
        for (let i = 0; i < 10; i++) {
            timeArray.push(rootPath + "time/time_" + i + ".png");
            dateArray.push(rootPath + "date/date_number_" + i + ".png");
        }
        for (let i = 1; i < 8; i++) {
            weekArray_en.push(rootPath + "week_en/week_en_" + i + ".png");
            weekArray_sc.push(rootPath + "week_sc/week_sc_" + i + ".png");
            weekArray_tc.push(rootPath + "week_tc/week_sc_" + i + ".png");
        }

        const logger = DeviceRuntimeCore.HmLogger.getLogger("default2");
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({



            init_view() {

                var screenType = hmSetting.getScreenType();
                if (screenType == hmSetting.screen_type.AOD) {

                    // bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
                    //     x: 0,
                    //     y: 0,
                    //     w: 416,
                    //     h: 416,
                    //     color: 0x000000,
                    // });

                } else {
                    bg = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 0,
                        y: 0,
                        w: 416,
                        h: 416,
                        src: rootPath + "img/_0.png",
                    });
                    animCreate = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                        x: 0,
                        y: 0,
                        anim_path: rootPath + "bg_animte",
                        anim_prefix: "",
                        anim_ext: "png",
                        anim_fps: 10,
                        anim_size: 22,
                        anim_repeat: false,
                        repeat_count: 1,
                        anim_status: 1,
                        display_on_restart: true, //从息屏到亮屏是否自动重复播放
                    });
                }

                let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 113 * num,
                    hour_startY: 272 * num,
                    hour_array: timeArray,
                    hour_space: 0,
                    hour_unit_sc: rootPath + "img/colon.png", //单位
                    hour_unit_tc: rootPath + "img/colon.png",
                    hour_unit_en: rootPath + "img/colon.png",
                    hour_align: hmUI.align.LEFT,

                    minute_zero: 1, //是否补零 1为补零
                    minute_startX: 300 * num,
                    minute_startY: 272 * num,
                    minute_array: timeArray,
                    minute_space: 0, //两个图片间隔 对应GT2的interval
                    minute_follow: 1, //是否跟随
                    minute_align: hmUI.align.LEFT,


                    am_x: 200 * num,
                    am_y: 74 * num,
                    am_sc_path: rootPath + "img/am_cn.png",
                    am_en_path: rootPath + "img/am_en.png",
                    pm_x: 200 * num,
                    pm_y: 74 * num,
                    pm_sc_path: rootPath + "img/pm_cn.png",
                    pm_en_path: rootPath + "img/pm_en.png",
                    show_level: hmUI.show_level.ALL,
                });

                let week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 135 * num,
                    y: 396 * num,
                    week_en: weekArray_en,
                    week_tc: weekArray_tc,
                    week_sc: weekArray_sc,
                    show_level: hmUI.show_level.ALL,
                });

                let status = hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 224 * num,
                    month_startY: 399 * num,
                    month_unit_sc: rootPath + "img/point.png",
                    month_unit_tc: rootPath + "img/point.png",
                    month_unit_en: rootPath + "img/point.png",
                    month_align: hmUI.align.LEFT,
                    month_space: -1,
                    month_zero: 1,
                    month_follow: 0,
                    month_en_array: dateArray,
                    month_sc_array: dateArray,
                    month_tc_array: dateArray,
                    //month_is_character: true, //年份此字段无效  默认为true  为false时 传入的图片为月份12张 日31张
                    //月日同上 需要替换前缀为month/day

                    day_startX: 300 * num,
                    day_startY: 399 * num,
                    day_align: hmUI.align.LEFT,
                    day_space: -1,
                    day_zero: 1,
                    day_follow: 1,
                    day_en_array: dateArray,
                    day_sc_array: dateArray,
                    day_tc_array: dateArray,
                    // day_is_character: true, 

                    show_level: hmUI.show_level.ALL,
                });
            },

            onInit() {
                console.log('index page.js on init invoke');
                this.init_view();
            },

            onReady() {
                console.log('index page.js on ready invoke')
            },

            onShow() {
                console.log('index page.js on show invoke')
            },

            onHide() {
                console.log('index page.js on hide invoke')
            },

            onDestory() {
                console.log('index page.js on destory invoke')
                timer.stopTimer(clock_timer);
            },
        });
        /*
         * end js
         */
    })()
} catch (e) {
    console.log(e)
}