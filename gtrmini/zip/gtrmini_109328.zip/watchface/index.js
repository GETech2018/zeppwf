try {
    (() => {

    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

    /*
    * huamiOS bundle tool v1.0.17
    * Copyright © Huami. All Rights Reserved
    */
    'use strict';

    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let strRootPath = "images/"
    let nW = 416
    let nH = 416
    let timeArray = []
    let timeArray_xp = []
    let dateArray = []
    let arrEnMonth =[]
    let arrScMonth =[]

    let objAodBg = {
        x: 0,
        y: 0,
        w: nW,
        h: nH,
        color: 0x000000,
        show_level: hmUI.show_level.ONAL_AOD,
    }
    let objNorBg ={
        x: 0,
        y: 0,
        w: nW,
        h: nH,
        src:  strRootPath + "img/bg.png",
        show_level: hmUI.show_level.ONLY_NORMAL
    }
    let objAnim = {
        x: 0,
        y: 0,
        anim_path: strRootPath + "bg_animte",
        anim_prefix: "bgAnimate",
        anim_ext: "png",
        anim_fps: 6,
        anim_size: 21,
        anim_repeat: false,
        repeat_count: 0,
        anim_status: 1,
        anim_complete_call:this._animNext,
        show_level: hmUI.show_level.ONLY_NORMAL
    }
    let objAodTime = {
        hour_zero: 1,
        hour_startX: 66*0.8667,
        hour_startY: 190*0.8667,
        hour_array: timeArray_xp,
        hour_space: 8,
        hour_unit_sc: strRootPath+"img/colon_xp.png", //单位
        hour_unit_tc: strRootPath+"img/colon_xp.png",
        hour_unit_en: strRootPath+"img/colon_xp.png",
        hour_align: hmUI.align.LEFT,

        minute_zero: 1,
        minute_startX: 274*0.8667,
        minute_startY: 190*0.8667,
        minute_array: timeArray_xp,
        minute_space: 8,
        minute_follow: 1,
        minute_align: hmUI.align.LEFT,
        show_level: hmUI.show_level.ONAL_AOD,
    }
    let objTime = {
        hour_zero: 1,
        hour_startX: 66*0.8667,
        hour_startY: 190*0.8667,
        hour_array: timeArray,
        hour_space: 8,
        hour_unit_sc: strRootPath+"img/colon.png", //单位
        hour_unit_tc: strRootPath+"img/colon.png",
        hour_unit_en: strRootPath+"img/colon.png",
        hour_align: hmUI.align.LEFT,
        minute_zero: 1,
        minute_startX: 274*0.8667,
        minute_startY: 190*0.8667,
        minute_array: timeArray,
        minute_space: 8,
        minute_follow: 1,
        minute_align: hmUI.align.LEFT,
        show_level: hmUI.show_level.ONLY_NORMAL,
        }
    let objMonth = {
        month_startX: 186*0.8667,
        month_startY: 123*0.8667,
        month_align: hmUI.align.LEFT,
        month_space: 0,
        month_zero: 0,
        month_follow: 0,
        month_en_array: arrEnMonth,
        month_sc_array: arrScMonth,
        month_tc_array: arrScMonth,
        month_is_character: true,
        show_level: hmUI.show_level.ONLY_NORMAL,

    }
    let objDate ={
        day_startX: 260*0.8667,
        day_startY: 127*0.8667,
        day_align: hmUI.align.LEFT,
        day_space: 0,
        day_zero: 1,
        day_follow: 0,
        day_en_array: dateArray,
        day_sc_array: dateArray,
        day_tc_array: dateArray,
        ///day_is_character: true,
        show_level: hmUI.show_level.ONLY_NORMAL,
    }
    let objStep = {
        x: 182*0.8667,
        y: 314*0.8667,
        type: hmUI.data_type.STEP,
        font_array:  dateArray ,
        h_space: -1,
        align_h: hmUI.align.LEFT,
        invalid_image: strRootPath+"img/invalid.png",
        padding:false,
        show_level: hmUI.show_level.ONLY_NORMAL,

    }
    let objPower = {
        x: 280*0.8667,
        y: 314*0.8667,
        type: hmUI.data_type.BATTERY,
        font_array:  dateArray ,
        h_space: -1,
        align_h: hmUI.align.LEFT,
        unit_sc: strRootPath+"img/per.png",
        unit_tc: strRootPath+"img/per.png",
        unit_en: strRootPath+"img/per.png",
        invalid_image: strRootPath+"img/invalid.png",
        padding:false,
        show_level: hmUI.show_level.ONLY_NORMAL,
    }

    for (i = 0; i < 13; i++) {
        if(i < 10){
            timeArray.push(strRootPath+"time/"+i+".png")
            timeArray_xp.push(strRootPath+"time_xp/"+i+".png")
            dateArray.push(strRootPath+"num/"+i+".png")
        }
        if(i < 13 && i > 0){
            arrScMonth.push(strRootPath+"month_sc/"+i+".png")
            arrEnMonth.push(strRootPath+"month_en/"+i+".png")
        }
    }


    // const logger = DeviceRuntimeCore.HmLogger.getLogger("default2");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({

        init_view() {


            let aodBg = hmUI.createWidget(hmUI.widget.FILL_RECT, objAodBg);

            let timeText_xp = hmUI.createWidget(hmUI.widget.IMG_TIME, objAodTime);

            let bg = hmUI.createWidget(hmUI.widget.IMG, objNorBg);

            let animCreate = hmUI.createWidget(hmUI.widget.IMG_ANIM, objAnim);

            let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, objTime);

            let month = hmUI.createWidget(hmUI.widget.IMG_DATE, objMonth);

            let dayImg = hmUI.createWidget(hmUI.widget.IMG_DATE, objDate);

            let stepTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG, objStep);

            let batTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG, objPower);

            //点击步数组件跳转
            let step_click = hmUI.createWidget(hmUI.widget.IMG_CLICK,{
                x: 157*0.8667,
                y: 314*0.8667,
                w: 90,
                h: 30,
                type: hmUI.data_type.STEP,
            })
            //点击电量组件跳转
            let bat_click = hmUI.createWidget(hmUI.widget.IMG_CLICK,{
                x: 260*0.8667,
                y: 314*0.8667,
                w: 60,
                h: 30,
                type: hmUI.data_type.BATTERY,
            })

        },

        onInit() {
            console.log('index page.js on init invoke');
            this.init_view();
        },

        onReady() {
            console.log('index page.js on ready invoke')
        },

        onShow() {
            console.log('index page.js on show invoke')
        },

        onHide() {
            console.log('index page.js on hide invoke')
        },

        onDestory() {
            console.log('index page.js on destory invoke')
            timer.stopTimer(clock_timer);
        },
    });
    /*
    * end js
    */
        })()
    } catch (e) {
        console.log(e)
    }
