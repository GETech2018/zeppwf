try {
    (() => {
        var n = __$$hmAppManager$$__.currentApp;
        const g = n.current,
            {
                px: p
            } = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(n, g)), n.app.__globals__);

        g.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                var time_day = null;
                var time_days = null;
                var jstime = hmSensor.createSensor(hmSensor.id.TIME);
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 416,
                    h: 416,
                    src: "2.png",
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 198,
                    y: 57,
                    week_en: ["3.png", "4.png", "5.png", "6.png", "7.png", "8.png", "9.png"],
                    week_tc: ["3.png", "4.png", "5.png", "6.png", "7.png", "8.png", "9.png"],
                    week_sc: ["3.png", "4.png", "5.png", "6.png", "7.png", "8.png", "9.png"],
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 198,
                    month_startY: 276,
                    month_sc_array: ["14.png", "15.png", "16.png", "17.png", "18.png", "19.png", "20.png", "21.png", "22.png", "23.png", "24.png", "25.png"],
                    month_tc_array: ["14.png", "15.png", "16.png", "17.png", "18.png", "19.png", "20.png", "21.png", "22.png", "23.png", "24.png", "25.png"],
                    month_en_array: ["14.png", "15.png", "16.png", "17.png", "18.png", "19.png", "20.png", "21.png", "22.png", "23.png", "24.png", "25.png"],
                    month_align: hmUI.align.LEFT,
                    month_zero: 0,
                    month_follow: 0,
                    month_space: 0,
                    month_is_character: !0,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }),hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 416,
                    h: 416,
                    src: "36.png",
                    show_level: hmUI.show_level.ONLY_AOD
                }), hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 198,
                    y: 57,
                    week_en: ["3.png", "4.png", "5.png", "6.png", "7.png", "8.png", "9.png"],
                    week_tc: ["3.png", "4.png", "5.png", "6.png", "7.png", "8.png", "9.png"],
                    week_sc: ["3.png", "4.png", "5.png", "6.png", "7.png", "8.png", "9.png"],
                    show_level: hmUI.show_level.ONLY_AOD
                }),hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 198,
                    month_startY: 276,
                    month_sc_array: ["14.png", "15.png", "16.png", "17.png", "18.png", "19.png", "20.png", "21.png", "22.png", "23.png", "24.png", "25.png"],
                    month_tc_array: ["14.png", "15.png", "16.png", "17.png", "18.png", "19.png", "20.png", "21.png", "22.png", "23.png", "24.png", "25.png"],
                    month_en_array: ["14.png", "15.png", "16.png", "17.png", "18.png", "19.png", "20.png", "21.png", "22.png", "23.png", "24.png", "25.png"],
                    month_align: hmUI.align.LEFT,
                    month_zero: 0,
                    month_follow: 0,
                    month_space: 0,
                    month_is_character: !0,
                    show_level: hmUI.show_level.ONLY_AOD
                }),
                time_day = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 198,
                    y: 346,
                    w: 50,
                    h: 50,
                    src: ['27.png']
                })
                time_days = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 198,
                    y: 358,
                    w: 50,
                    h: 50,
                    src: ['27.png']
                }),hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 208,
                    hour_centerY: 208,
                    hour_posX: 17,
                    hour_posY: 208,
                    hour_path: "10.png",
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 208,
                    minute_centerY: 208,
                    minute_posX: 17,
                    minute_posY: 208,
                    minute_path: "11.png",
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    second_centerX: 208,
                    second_centerY: 208,
                    second_posX: 17,
                    second_posY: 207,
                    second_path: "13.png",
                    // second_cover_path: "12.png",
                    // second_cover_x: 198,
                    // second_cover_y: 198,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }),hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 208,
                    hour_centerY: 208,
                    hour_posX: 17,
                    hour_posY: 208,
                    hour_path: "10.png",
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 208,
                    minute_centerY: 208,
                    minute_posX: 18,
                    minute_posY: 208,
                    minute_path: "11.png",
                    // minute_cover_path: "37.png",
                    // minute_cover_x: 198,
                    // minute_cover_y: 198,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_AOD
                })

                /* 获取日期 */
                getTime();

                /* 时间传感器监听 */
                jstime.addEventListener(jstime.event.DAYCHANGE, function() {
                if( jstime.day < 10 ){
                    time_day.setProperty(hmUI.prop.MORE,{src: ['day/'+jstime.day+'.png']})
                    time_days.setProperty(hmUI.prop.VISIBLE, false);
                }else{
                    let fist = parseInt((jstime.day % 100) / 10);
                    let sec = parseInt(jstime.day % 10);
                    time_days.setProperty(hmUI.prop.VISIBLE, true)
                    time_day.setProperty(hmUI.prop.MORE,{src: ['day/'+fist+'.png']})
                    time_days.setProperty(hmUI.prop.MORE,{src: ['day/'+sec+'.png']})
                }
                });

                /* 滑屏幕事件 */
                let widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: (function(){
                        getTime();
                    }),
                    pause_call: (function () {
                        console.log('ui pause');
                    }),
                });
                function getTime() {

                    if( jstime.day < 10 ){
                        time_day.setProperty(hmUI.prop.MORE,{src: ['day/'+jstime.day+'.png']})
                        time_days.setProperty(hmUI.prop.VISIBLE, false);
                    }else{
                        let fist = parseInt((jstime.day % 100) / 10);
                        let sec = parseInt(jstime.day % 10);
                        time_days.setProperty(hmUI.prop.VISIBLE, true)
                        time_day.setProperty(hmUI.prop.MORE,{src: ['day/'+fist+'.png']})
                        time_days.setProperty(hmUI.prop.MORE,{src: ['day/'+sec+'.png']})
                    }

                }

            },
            onInit() {
                e.log("index page.js on init invoke")
            },
            build() {
                this.init_view(), e.log("index page.js on ready invoke")
            },
            onDestroy() {
                e.log("index page.js on destroy invoke")
            }
        })
    })()
} catch (n) {
    console.log(n)
}