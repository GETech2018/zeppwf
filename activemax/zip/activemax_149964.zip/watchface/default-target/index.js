try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_aa48e12909de4aaabf61bf7646489d90 = '';
        let normal$_$text_581b5b6932ac4d839cd08fcef1356836 = '';
        let normal$_$text_6eaa78ea46164107af5501926f364fd0 = '';
        let normal$_$text_9e3bd8ed9cb8452784e123929f43260a = '';
        let normal$_$text_1e6778acceb24e678b549c85ac716ab6 = '';
        let normal$_$text_58243f71873d4517bea74ae077907fdb = '';
        let normal$_$text_2c3dfdabac3f4fde87a71739ac375076 = '';
        let normal$_$text_9a16fdabe1fb4e05b0914377b18ba848 = '';
        let normal$_$text_3b14ae99cfab4a3b8bd188d0f1fccbe4 = '';
        let normal$_$text_5217e27243f4484f8f44a62602196f13 = '';
        let normal$_$text_94ae371327ef4b84acb4a0009583e5e7 = '';
        let normal$_$text_1ea5fde317844e8cacf78f6744f0be54 = '';
        let normal$_$text_302cbba4287b4ca6aeed6ca8fee0ec9b = '';
        let normal$_$text_c497ac0e5bf94c4e88e1616744b0f591 = '';
        let normal$_$text_329cd98c6ce945679bb55d6d304a59c1 = '';
        let idle$_$text_7d1711fea0474a7ca990b2387c3ed56a = '';
        let idle$_$text_50be6e6767c54093a79a30db438b8009 = '';
        let idle$_$text_f1a6557e5d5b41149af334cdbef5a569 = '';
        let idle$_$text_23684a7d880843fabf99c10d76e1dd04 = '';
        let idle$_$text_f699f3c6002e4f3c939722f3cd6d2526 = '';
        let idle$_$text_bf0d08ec85094301a49bfd77b28a68e9 = '';
        let idle$_$text_97e8bcb8b5c440c99069b1db7428fb46 = '';
        let idle$_$text_a6083a5aab9b4eecaa26ae79e9b15ac3 = '';
        let idle$_$text_ea74a294232747818c4cb8cbe6ddc6ae = '';
        let idle$_$text_b1cd1a99687d4af0a0529566c76b0a63 = '';
        let idle$_$text_14192ae47e6d460eae4b1638a02b27ce = '';
        let idle$_$text_4c2250414812447dbf70c04b684d5dba = '';
        let idle$_$text_327f77df2d5d41e0b7222087330c595d = '';
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                normal$_$text_aa48e12909de4aaabf61bf7646489d90 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 0,
                    y: 215,
                    w: 50,
                    h: 50,
                    text: '9',
                    color: '0xFF4ab0db',
                    text_size: 40,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_581b5b6932ac4d839cd08fcef1356836 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 215,
                    y: 10,
                    w: 50,
                    h: 50,
                    text: '12',
                    color: '0xFF5edf2a',
                    text_size: 40,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_6eaa78ea46164107af5501926f364fd0 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 400,
                    y: 320,
                    w: 50,
                    h: 50,
                    text: '4',
                    color: '0xFFee0b33',
                    text_size: 40,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_9e3bd8ed9cb8452784e123929f43260a = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 400,
                    y: 110,
                    w: 50,
                    h: 50,
                    text: '2',
                    color: '0xFFdd9435',
                    text_size: 40,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_1e6778acceb24e678b549c85ac716ab6 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 320,
                    y: 35,
                    w: 50,
                    h: 50,
                    text: '1',
                    color: '0xFFdae440',
                    text_size: 40,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_58243f71873d4517bea74ae077907fdb = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 110,
                    y: 405,
                    w: 50,
                    h: 50,
                    text: '7',
                    color: '0xFF9762e1',
                    text_size: 40,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_2c3dfdabac3f4fde87a71739ac375076 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 35,
                    y: 320,
                    w: 50,
                    h: 50,
                    text: '8',
                    color: '0xFF1958df',
                    text_size: 40,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_9a16fdabe1fb4e05b0914377b18ba848 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 435,
                    y: 215,
                    w: 50,
                    h: 50,
                    text: '3',
                    color: '0xFFe1845f',
                    text_size: 40,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_3b14ae99cfab4a3b8bd188d0f1fccbe4 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 110,
                    y: 35,
                    w: 50,
                    h: 50,
                    text: '11',
                    color: '0xFF6ec38e',
                    text_size: 40,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_5217e27243f4484f8f44a62602196f13 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 320,
                    y: 405,
                    w: 50,
                    h: 50,
                    text: '5',
                    color: '0xFFe125b0',
                    text_size: 40,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_94ae371327ef4b84acb4a0009583e5e7 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 35,
                    y: 110,
                    w: 50,
                    h: 50,
                    text: '10',
                    color: '0xFF64ddd2',
                    text_size: 40,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_1ea5fde317844e8cacf78f6744f0be54 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 215,
                    y: 430,
                    w: 50,
                    h: 50,
                    text: '6',
                    color: '0xFFc81ef0',
                    text_size: 40,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 10,
                    y: 10,
                    src: '3.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 377,
                    month_startY: 226,
                    month_sc_array: [
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png'
                    ],
                    month_tc_array: [
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png'
                    ],
                    month_en_array: [
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png'
                    ],
                    month_align: hmUI.align.CENTER_H,
                    month_zero: 1,
                    month_follow: 0,
                    month_space: 0,
                    month_is_character: false,
                    day_startX: 315,
                    day_startY: 226,
                    day_sc_array: [
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png'
                    ],
                    day_tc_array: [
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png'
                    ],
                    day_en_array: [
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png'
                    ],
                    day_align: hmUI.align.CENTER_H,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 0,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 132,
                    y: 285,
                    type: hmUI.data_type.DISTANCE,
                    font_array: [
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    dot_image: '35.png',
                    invalid_image: '34.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 132,
                    y: 323,
                    type: hmUI.data_type.CAL,
                    font_array: [
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '46.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 215,
                    y: 167,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: [
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png',
                        '54.png',
                        '55.png',
                        '56.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    negative_image: '58.png',
                    invalid_image: '57.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 256,
                    y: 163,
                    w: 11,
                    h: 23,
                    src: '59.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 263,
                    y: 167,
                    type: hmUI.data_type.WEATHER_HIGH,
                    font_array: [
                        '60.png',
                        '61.png',
                        '62.png',
                        '63.png',
                        '64.png',
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    negative_image: '71.png',
                    invalid_image: '70.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 302,
                    y: 163,
                    w: 11,
                    h: 23,
                    src: '72.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 170,
                    y: 167,
                    type: hmUI.data_type.WEATHER_LOW,
                    font_array: [
                        '73.png',
                        '74.png',
                        '75.png',
                        '76.png',
                        '77.png',
                        '78.png',
                        '79.png',
                        '80.png',
                        '81.png',
                        '82.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    negative_image: '84.png',
                    invalid_image: '83.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 201,
                    y: 163,
                    w: 11,
                    h: 23,
                    src: '85.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 132,
                    y: 247,
                    type: hmUI.data_type.STEP,
                    font_array: [
                        '86.png',
                        '87.png',
                        '88.png',
                        '89.png',
                        '90.png',
                        '91.png',
                        '92.png',
                        '93.png',
                        '94.png',
                        '95.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '96.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 245,
                    y: 231,
                    week_en: [
                        '97.png',
                        '98.png',
                        '99.png',
                        '100.png',
                        '101.png',
                        '102.png',
                        '103.png'
                    ],
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_302cbba4287b4ca6aeed6ca8fee0ec9b = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 230,
                    y: 98,
                    w: 20,
                    h: 40,
                    text: ':',
                    color: '0xFF16d5be',
                    text_size: 40,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_c497ac0e5bf94c4e88e1616744b0f591 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 125,
                    y: 160,
                    w: 40,
                    h: 40,
                    text: 'L:',
                    color: '0xFF5be1d3',
                    text_size: 17,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 205,
                    y: 377,
                    type: hmUI.data_type.BATTERY,
                    font_array: [
                        '104.png',
                        '105.png',
                        '106.png',
                        '107.png',
                        '108.png',
                        '109.png',
                        '110.png',
                        '111.png',
                        '112.png',
                        '113.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 273,
                    y: 383,
                    w: 19,
                    h: 17,
                    src: '114.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_329cd98c6ce945679bb55d6d304a59c1 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 314,
                    y: 160,
                    w: 40,
                    h: 40,
                    text: ':H',
                    color: '0xFF5be1d3',
                    text_size: 17,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 126,
                    hour_startY: 93,
                    hour_array: [
                        '115.png',
                        '116.png',
                        '117.png',
                        '118.png',
                        '119.png',
                        '120.png',
                        '121.png',
                        '122.png',
                        '123.png',
                        '124.png'
                    ],
                    hour_space: 0,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 239,
                    minute_startY: 93,
                    minute_array: [
                        '125.png',
                        '126.png',
                        '127.png',
                        '128.png',
                        '129.png',
                        '130.png',
                        '131.png',
                        '132.png',
                        '133.png',
                        '134.png'
                    ],
                    minute_space: 0,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    second_zero: 1,
                    second_startX: 346,
                    second_startY: 124,
                    second_array: [
                        '135.png',
                        '136.png',
                        '137.png',
                        '138.png',
                        '139.png',
                        '140.png',
                        '141.png',
                        '142.png',
                        '143.png',
                        '144.png'
                    ],
                    second_space: 0,
                    second_align: hmUI.align.LEFT,
                    second_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 286,
                    y: 334,
                    type: hmUI.data_type.HUMIDITY,
                    font_array: [
                        '145.png',
                        '146.png',
                        '147.png',
                        '148.png',
                        '149.png',
                        '150.png',
                        '151.png',
                        '152.png',
                        '153.png',
                        '154.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '155.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 281,
                    y: 274,
                    type: hmUI.data_type.SUN_RISE,
                    font_array: [
                        '156.png',
                        '157.png',
                        '158.png',
                        '159.png',
                        '160.png',
                        '161.png',
                        '162.png',
                        '163.png',
                        '164.png',
                        '165.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    dot_image: '167.png',
                    invalid_image: '166.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 281,
                    y: 305,
                    type: hmUI.data_type.SUN_SET,
                    font_array: [
                        '168.png',
                        '169.png',
                        '170.png',
                        '171.png',
                        '172.png',
                        '173.png',
                        '174.png',
                        '175.png',
                        '176.png',
                        '177.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    dot_image: '179.png',
                    invalid_image: '178.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 361,
                    y: 231,
                    src: '180.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 133,
                    y: 213,
                    type: hmUI.data_type.HEART,
                    font_array: [
                        '181.png',
                        '182.png',
                        '183.png',
                        '184.png',
                        '185.png',
                        '186.png',
                        '187.png',
                        '188.png',
                        '189.png',
                        '190.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '191.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 71,
                    y: 198,
                    src: '192.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 240,
                    y: 204,
                    src: '193.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 101,
                    y: 215,
                    src: '194.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 102,
                    y: 247,
                    src: '195.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 103,
                    y: 284,
                    src: '196.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 248,
                    y: 331,
                    src: '197.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 101,
                    y: 320,
                    src: '198.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 104,
                    y: 164,
                    src: '199.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 247,
                    y: 298,
                    src: '200.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 247,
                    y: 269,
                    src: '201.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                idle$_$text_7d1711fea0474a7ca990b2387c3ed56a = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 320,
                    y: 35,
                    w: 50,
                    h: 50,
                    text: '1',
                    color: '0xFFdae440',
                    text_size: 40,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                idle$_$text_50be6e6767c54093a79a30db438b8009 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 400,
                    y: 110,
                    w: 50,
                    h: 50,
                    text: '2',
                    color: '0xFFdd9435',
                    text_size: 40,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                idle$_$text_f1a6557e5d5b41149af334cdbef5a569 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 435,
                    y: 215,
                    w: 50,
                    h: 50,
                    text: '3',
                    color: '0xFFe1845f',
                    text_size: 40,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                idle$_$text_23684a7d880843fabf99c10d76e1dd04 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 110,
                    y: 405,
                    w: 50,
                    h: 50,
                    text: '7',
                    color: '0xFF9762e1',
                    text_size: 40,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                idle$_$text_f699f3c6002e4f3c939722f3cd6d2526 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 0,
                    y: 215,
                    w: 50,
                    h: 50,
                    text: '9',
                    color: '0xFF4ab0db',
                    text_size: 40,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                idle$_$text_bf0d08ec85094301a49bfd77b28a68e9 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 215,
                    y: 430,
                    w: 50,
                    h: 50,
                    text: '6',
                    color: '0xFFc81ef0',
                    text_size: 40,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                idle$_$text_97e8bcb8b5c440c99069b1db7428fb46 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 35,
                    y: 110,
                    w: 50,
                    h: 50,
                    text: '10',
                    color: '0xFF64ddd2',
                    text_size: 40,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                idle$_$text_a6083a5aab9b4eecaa26ae79e9b15ac3 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 110,
                    y: 35,
                    w: 50,
                    h: 50,
                    text: '11',
                    color: '0xFF6ec38e',
                    text_size: 40,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                idle$_$text_ea74a294232747818c4cb8cbe6ddc6ae = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 302,
                    y: 405,
                    w: 50,
                    h: 50,
                    text: '5',
                    color: '0xFFe125b0',
                    text_size: 40,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                idle$_$text_b1cd1a99687d4af0a0529566c76b0a63 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 400,
                    y: 320,
                    w: 50,
                    h: 50,
                    text: '4',
                    color: '0xFFee0b33',
                    text_size: 40,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                idle$_$text_14192ae47e6d460eae4b1638a02b27ce = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 215,
                    y: 10,
                    w: 50,
                    h: 50,
                    text: '12',
                    color: '0xFF5edf2a',
                    text_size: 40,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                idle$_$text_4c2250414812447dbf70c04b684d5dba = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 35,
                    y: 320,
                    w: 50,
                    h: 50,
                    text: '8',
                    color: '0xFF1958df',
                    text_size: 40,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                idle$_$text_327f77df2d5d41e0b7222087330c595d = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 141,
                    y: 145,
                    w: 200,
                    h: 35,
                    text: 'Improve 1%',
                    color: '0xFF53a71e',
                    text_size: 30,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 370,
                    month_startY: 257,
                    month_sc_array: [
                        '202.png',
                        '203.png',
                        '204.png',
                        '205.png',
                        '206.png',
                        '207.png',
                        '208.png',
                        '209.png',
                        '210.png',
                        '211.png'
                    ],
                    month_tc_array: [
                        '202.png',
                        '203.png',
                        '204.png',
                        '205.png',
                        '206.png',
                        '207.png',
                        '208.png',
                        '209.png',
                        '210.png',
                        '211.png'
                    ],
                    month_en_array: [
                        '202.png',
                        '203.png',
                        '204.png',
                        '205.png',
                        '206.png',
                        '207.png',
                        '208.png',
                        '209.png',
                        '210.png',
                        '211.png'
                    ],
                    month_align: hmUI.align.CENTER_H,
                    month_zero: 1,
                    month_follow: 0,
                    month_space: 0,
                    month_is_character: false,
                    day_startX: 370,
                    day_startY: 215,
                    day_sc_array: [
                        '212.png',
                        '213.png',
                        '214.png',
                        '215.png',
                        '216.png',
                        '217.png',
                        '218.png',
                        '219.png',
                        '220.png',
                        '221.png'
                    ],
                    day_tc_array: [
                        '212.png',
                        '213.png',
                        '214.png',
                        '215.png',
                        '216.png',
                        '217.png',
                        '218.png',
                        '219.png',
                        '220.png',
                        '221.png'
                    ],
                    day_en_array: [
                        '212.png',
                        '213.png',
                        '214.png',
                        '215.png',
                        '216.png',
                        '217.png',
                        '218.png',
                        '219.png',
                        '220.png',
                        '221.png'
                    ],
                    day_align: hmUI.align.CENTER_H,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 0,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 205,
                    y: 370,
                    type: hmUI.data_type.BATTERY,
                    font_array: [
                        '222.png',
                        '223.png',
                        '224.png',
                        '225.png',
                        '226.png',
                        '227.png',
                        '228.png',
                        '229.png',
                        '230.png',
                        '231.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_AOD,
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 273,
                    y: 375,
                    w: 19,
                    h: 17,
                    src: '114.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 296,
                    y: 221,
                    week_en: [
                        '232.png',
                        '233.png',
                        '234.png',
                        '235.png',
                        '236.png',
                        '237.png',
                        '238.png'
                    ],
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 208,
                    y: 60,
                    src: '239.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 240,
                    hour_centerY: 240,
                    hour_posX: 25,
                    hour_posY: 227,
                    hour_path: '240.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 240,
                    minute_centerY: 240,
                    minute_posX: 25,
                    minute_posY: 227,
                    minute_path: '241.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 89,
                    y: 285,
                    w: 140,
                    h: 70,
                    type: hmUI.data_type.DISTANCE,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 165,
                    y: 162,
                    w: 150,
                    h: 33,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 81,
                    y: 249,
                    w: 140,
                    h: 30,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 211,
                    y: 376,
                    w: 78,
                    h: 30,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 310,
                    y: 393,
                    w: 155,
                    h: 31,
                    type: hmUI.data_type.SUN_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 90,
                    y: 209,
                    w: 90,
                    h: 36,
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        normal$_$text_aa48e12909de4aaabf61bf7646489d90.setProperty(hmUI.prop.MORE, { text: `9` });
                        normal$_$text_581b5b6932ac4d839cd08fcef1356836.setProperty(hmUI.prop.MORE, { text: `12` });
                        normal$_$text_6eaa78ea46164107af5501926f364fd0.setProperty(hmUI.prop.MORE, { text: `4` });
                        normal$_$text_9e3bd8ed9cb8452784e123929f43260a.setProperty(hmUI.prop.MORE, { text: `2` });
                        normal$_$text_1e6778acceb24e678b549c85ac716ab6.setProperty(hmUI.prop.MORE, { text: `1` });
                        normal$_$text_58243f71873d4517bea74ae077907fdb.setProperty(hmUI.prop.MORE, { text: `7` });
                        normal$_$text_2c3dfdabac3f4fde87a71739ac375076.setProperty(hmUI.prop.MORE, { text: `8` });
                        normal$_$text_9a16fdabe1fb4e05b0914377b18ba848.setProperty(hmUI.prop.MORE, { text: `3` });
                        normal$_$text_3b14ae99cfab4a3b8bd188d0f1fccbe4.setProperty(hmUI.prop.MORE, { text: `11` });
                        normal$_$text_5217e27243f4484f8f44a62602196f13.setProperty(hmUI.prop.MORE, { text: `5` });
                        normal$_$text_94ae371327ef4b84acb4a0009583e5e7.setProperty(hmUI.prop.MORE, { text: `10` });
                        normal$_$text_1ea5fde317844e8cacf78f6744f0be54.setProperty(hmUI.prop.MORE, { text: `6` });
                        normal$_$text_302cbba4287b4ca6aeed6ca8fee0ec9b.setProperty(hmUI.prop.MORE, { text: `:` });
                        normal$_$text_c497ac0e5bf94c4e88e1616744b0f591.setProperty(hmUI.prop.MORE, { text: `L:` });
                        normal$_$text_329cd98c6ce945679bb55d6d304a59c1.setProperty(hmUI.prop.MORE, { text: `:H` });
                        idle$_$text_7d1711fea0474a7ca990b2387c3ed56a.setProperty(hmUI.prop.MORE, { text: `1` });
                        idle$_$text_50be6e6767c54093a79a30db438b8009.setProperty(hmUI.prop.MORE, { text: `2` });
                        idle$_$text_f1a6557e5d5b41149af334cdbef5a569.setProperty(hmUI.prop.MORE, { text: `3` });
                        idle$_$text_23684a7d880843fabf99c10d76e1dd04.setProperty(hmUI.prop.MORE, { text: `7` });
                        idle$_$text_f699f3c6002e4f3c939722f3cd6d2526.setProperty(hmUI.prop.MORE, { text: `9` });
                        idle$_$text_bf0d08ec85094301a49bfd77b28a68e9.setProperty(hmUI.prop.MORE, { text: `6` });
                        idle$_$text_97e8bcb8b5c440c99069b1db7428fb46.setProperty(hmUI.prop.MORE, { text: `10` });
                        idle$_$text_a6083a5aab9b4eecaa26ae79e9b15ac3.setProperty(hmUI.prop.MORE, { text: `11` });
                        idle$_$text_ea74a294232747818c4cb8cbe6ddc6ae.setProperty(hmUI.prop.MORE, { text: `5` });
                        idle$_$text_b1cd1a99687d4af0a0529566c76b0a63.setProperty(hmUI.prop.MORE, { text: `4` });
                        idle$_$text_14192ae47e6d460eae4b1638a02b27ce.setProperty(hmUI.prop.MORE, { text: `12` });
                        idle$_$text_4c2250414812447dbf70c04b684d5dba.setProperty(hmUI.prop.MORE, { text: `8` });
                        idle$_$text_327f77df2d5d41e0b7222087330c595d.setProperty(hmUI.prop.MORE, { text: `Improve 1%` });
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}