try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$component_0$_$component = '';
        let normal$_$component_1$_$component = '';
        let week_days = {
               x: 42,
               y: 105,
               week_en: [
                   '40.png',
                   '41.png',
                   '42.png',
                   '43.png',
                   '44.png',
                   '45.png',
                   '46.png'
               ],
               week_tc: [
                   '47.png',
                   '48.png',
                   '49.png',
                   '50.png',
                   '51.png',
                   '52.png',
                   '53.png'
               ],
               week_sc: [
                   '54.png',
                   '55.png',
                   '56.png',
                   '57.png',
                   '58.png',
                   '59.png',
                   '60.png'
               ],
               show_level: hmUI.show_level.ONLY_NORMAL
           };
        if(hmSetting.getLanguage() == 4) week_days.week_en = [
                   '275.png',
                   '276.png',
                   '277.png',
                   '278.png',
                   '279.png',
                   '280.png',
                   '281.png'
               ];
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
                    edit_id: 1,
                    x: 0,
                    y: 0,
                    bg_config: [
                        {
                            'id': 1,
                            'path': '6.png',
                            'preview': '7.png'
                        },
                        {
                            'id': 2,
                            'path': '8.png',
                            'preview': '9.png'
                        },
                        {
                            'id': 3,
                            'path': '10.png',
                            'preview': '11.png'
                        },
                        {
                            'id': 4,
                            'path': '12.png',
                            'preview': '13.png'
                        },
                        {
                            'id': 5,
                            'path': '14.png',
                            'preview': '15.png'
                        },
                        {
                            'id': 6,
                            'path': '16.png',
                            'preview': '17.png'
                        },
                        {
                            'id': 7,
                            'path': '18.png',
                            'preview': '19.png'
                        }
                    ],
                    count: 7,
                    default_id: 2,
                    fg: '5.png',
                    tips_x: 170,
                    tips_y: 50,
                    tips_bg: '4.png',
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    year_startX: 24,
                    year_startY: 139,
                    year_sc_array: [
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png'
                    ],
                    year_tc_array: [
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png'
                    ],
                    year_en_array: [
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png'
                    ],
                    year_align: hmUI.align.LEFT,
                    year_zero: 1,
                    year_space: 3,
                    year_is_character: false,
                    month_startX: 111,
                    month_startY: 139,
                    month_sc_array: [
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png'
                    ],
                    month_tc_array: [
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png'
                    ],
                    month_en_array: [
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png'
                    ],
                    month_align: hmUI.align.LEFT,
                    month_zero: 1,
                    month_follow: 0,
                    month_space: 3,
                    month_is_character: false,
                    day_startX: 159,
                    day_startY: 129,
                    day_sc_array: [
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png'
                    ],
                    day_tc_array: [
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png'
                    ],
                    day_en_array: [
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png'
                    ],
                    day_align: hmUI.align.LEFT,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 4,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, week_days);
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 39,
                    y: 351,
                    image_array: [
                        '61.png',
                        '62.png',
                        '63.png',
                        '64.png',
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png',
                        '71.png',
                        '72.png',
                        '73.png',
                        '74.png',
                        '75.png',
                        '76.png',
                        '77.png',
                        '78.png',
                        '79.png',
                        '80.png',
                        '81.png',
                        '82.png',
                        '83.png',
                        '84.png',
                        '85.png',
                        '86.png',
                        '87.png',
                        '88.png',
                        '89.png',
                        '90.png'
                    ],
                    image_length: 30,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 209,
                    y: 309,
                    type: hmUI.data_type.STEP,
                    font_array: [
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 3,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 338,
                    y: 221,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: [
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 4,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '93.png',
                    unit_tc: '93.png',
                    unit_en: '93.png',
                    negative_image: '92.png',
                    invalid_image: '91.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 366,
                    y: 182,
                    type: hmUI.data_type.WEATHER_HIGH,
                    font_array: [
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 3,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '96.png',
                    unit_tc: '96.png',
                    unit_en: '96.png',
                    negative_image: '95.png',
                    invalid_image: '94.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 366,
                    y: 270,
                    type: hmUI.data_type.WEATHER_LOW,
                    font_array: [
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 3,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '96.png',
                    unit_tc: '96.png',
                    unit_en: '96.png',
                    negative_image: '95.png',
                    invalid_image: '94.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 53,
                    y: 309,
                    type: hmUI.data_type.DISTANCE,
                    font_array: [
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 3,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '101.png',
                    unit_tc: '101.png',
                    unit_en: '101.png',
                    imperial_unit_sc: '101.png',
                    imperial_unit_tc: '101.png',
                    imperial_unit_en: '101.png',
                    dot_image: '100.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 203,
                    y: 372,
                    type: hmUI.data_type.HEART,
                    font_array: [
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 4,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '91.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 247,
                    y: 98,
                    type: hmUI.data_type.SUN_RISE,
                    font_array: [
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 3,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    dot_image: '101.png',
                    invalid_image: '94.png',
                    padding: true,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 247,
                    y: 139,
                    type: hmUI.data_type.SUN_SET,
                    font_array: [
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 3,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    dot_image: '101.png',
                    invalid_image: '94.png',
                    padding: true,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 118,
                    y: 407,
                    type: hmUI.data_type.PAI_WEEKLY,
                    font_array: [
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: 3,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 85,
                    y: 53,
                    image_array: [
                        '108.png',
                        '109.png',
                        '110.png',
                        '111.png',
                        '112.png',
                        '113.png',
                        '114.png',
                        '115.png',
                        '116.png',
                        '117.png',
                        '118.png',
                        '119.png',
                        '120.png',
                        '121.png',
                        '122.png',
                        '123.png',
                        '124.png',
                        '125.png',
                        '126.png',
                        '127.png',
                        '128.png',
                        '129.png',
                        '130.png',
                        '131.png',
                        '132.png',
                        '133.png',
                        '134.png',
                        '135.png',
                        '136.png',
                        '137.png'
                    ],
                    image_length: 30,
                    type: hmUI.data_type.MOON,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 315,
                    y: 407,
                    type: hmUI.data_type.UVI,
                    font_array: [
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 3,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '94.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 353,
                    y: 309,
                    type: hmUI.data_type.HUMIDITY,
                    font_array: [
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: 3,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '140.png',
                    unit_tc: '140.png',
                    unit_en: '140.png',
                    invalid_image: '94.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 343,
                    y: 143,
                    type: hmUI.data_type.ALTIMETER,
                    font_array: [
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: 3,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '94.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 436,
                    y: 221,
                    image_array: [
                        '142.png',
                        '143.png',
                        '144.png',
                        '145.png',
                        '146.png',
                        '147.png',
                        '148.png',
                        '149.png',
                        '150.png',
                        '151.png',
                        '152.png',
                        '153.png',
                        '154.png',
                        '155.png',
                        '156.png',
                        '157.png',
                        '158.png',
                        '159.png',
                        '160.png',
                        '161.png',
                        '162.png',
                        '163.png',
                        '164.png',
                        '165.png',
                        '166.png',
                        '167.png',
                        '168.png',
                        '169.png',
                        '170.png'
                    ],
                    image_length: 29,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 375,
                    y: 372,
                    image_array: [
                        '171.png',
                        '172.png',
                        '173.png',
                        '174.png',
                        '175.png',
                        '176.png',
                        '177.png',
                        '178.png'
                    ],
                    image_length: 8,
                    type: hmUI.data_type.WIND_DIRECTION,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 330,
                    y: 372,
                    type: hmUI.data_type.WIND,
                    font_array: [
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: 3,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '94.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 314,
                    y: 27,
                    image_array: [
                        '184.png',
                        '185.png',
                        '186.png',
                        '187.png',
                        '188.png',
                        '189.png',
                        '190.png',
                        '191.png',
                        '192.png',
                        '193.png',
                        '265.png',
                        '266.png',
                        '267.png',
                        '268.png',
                        '269.png',
                        '270.png',
                        '271.png',
                        '272.png',
                        '273.png',
                        '274.png'
                    ],
                    image_length: 20,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 343,
                    y: 87,
                    type: hmUI.data_type.BATTERY,
                    font_array: [
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: 4,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '194.png',
                    unit_tc: '194.png',
                    unit_en: '194.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 270,
                    y: 14,
                    src: '195.png',
                    type: hmUI.system_status.DISCONNECT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 172,
                    y: 14,
                    src: '196.png',
                    type: hmUI.system_status.LOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 127,
                    y: 29,
                    src: '197.png',
                    type: hmUI.system_status.CLOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$component_0$_$component = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: 2,
                    x: 13,
                    y: 188,
                    w: 311,
                    h: 104,
                    select_image: '198.png',
                    un_select_image: '199.png',
                    default_type: hmUI.edit_type.ALTIMETER,
                    optional_types: [
                        {
                            'type': hmUI.edit_type.ALTIMETER,
                            'preview': '201.png'
                        },
                        {
                            'type': hmUI.edit_type.WIND,
                            'preview': '202.png'
                        },
                        {
                            'type': hmUI.edit_type.UVI,
                            'preview': '203.png'
                        },
                        {
                            'type': hmUI.edit_type.SUN,
                            'preview': '204.png'
                        },
                        {
                            'type': hmUI.edit_type.HUMIDITY,
                            'preview': '205.png'
                        },
                        {
                            'type': hmUI.edit_type.TEMPERATURE,
                            'preview': '206.png'
                        },
                        {
                            'type': hmUI.edit_type.AQI,
                            'preview': '207.png'
                        }
                    ],
                    count: 7,
                    tips_BG: '200.png',
                    tips_x: -13,
                    tips_y: -188,
                    tips_width: 0,
                    tips_margin: 0
                });
                editType = normal$_$component_0$_$component.getProperty(hmUI.prop.CURRENT_TYPE);
                switch (editType) {
                case hmUI.edit_type.STEP:
                    break;
                case hmUI.edit_type.BATTERY:
                    break;
                case hmUI.edit_type.HEART:
                    break;
                case hmUI.edit_type.CAL:
                    break;
                case hmUI.edit_type.PAI_DAILY:
                    break;
                case hmUI.edit_type.DISTANCE:
                    break;
                case hmUI.edit_type.AQI:
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 21,
                        y: 195,
                        src: '208.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.HUMIDITY:
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 21,
                        y: 195,
                        src: '209.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.ALTIMETER:
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 21,
                        y: 195,
                        src: '210.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.STRESS:
                    break;
                case hmUI.edit_type.WIND:
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 21,
                        y: 195,
                        src: '211.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.SPO2:
                    break;
                case hmUI.edit_type.TRAINING_LOAD:
                    break;
                case hmUI.edit_type.VO2MAX:
                    break;
                case hmUI.edit_type.UVI:
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 21,
                        y: 195,
                        src: '212.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.DATE:
                    break;
                case hmUI.edit_type.WEEK:
                    break;
                case hmUI.edit_type.WEATHER:
                    break;
                case hmUI.edit_type.TEMPERATURE:
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 21,
                        y: 195,
                        src: '213.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.SUN:
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 21,
                        y: 195,
                        src: '214.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                }
                normal$_$component_1$_$component = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: 3,
                    x: 26,
                    y: 367,
                    w: 148,
                    h: 40,
                    select_image: '215.png',
                    un_select_image: '216.png',
                    default_type: hmUI.edit_type.CAL,
                    optional_types: [
                        {
                            'type': hmUI.edit_type.CAL,
                            'preview': '218.png'
                        },
                        {
                            'type': hmUI.edit_type.SPO2,
                            'preview': '219.png'
                        },
                        {
                            'type': hmUI.edit_type.TRAINING_LOAD,
                            'preview': '220.png'
                        },
                        {
                            'type': hmUI.edit_type.VO2MAX,
                            'preview': '221.png'
                        },
                        {
                            'type': hmUI.edit_type.STRESS,
                            'preview': '222.png'
                        }
                    ],
                    count: 5,
                    select_list: {
                        title_font_size: 34,
                        title_align_h: hmUI.align.CENTER_H,
                        list_item_vspace: 8,
                        list_tips_text_font_size: 32,
                        list_tips_text_align_h: hmUI.align.LEFT
                    },
                    tips_BG: '217.png',
                    tips_x: 14,
                    tips_y: -61,
                    tips_width: 132,
                    tips_margin: 0
                });
                editType = normal$_$component_1$_$component.getProperty(hmUI.prop.CURRENT_TYPE);
                switch (editType) {
                case hmUI.edit_type.STEP:
                    break;
                case hmUI.edit_type.BATTERY:
                    break;
                case hmUI.edit_type.HEART:
                    break;
                case hmUI.edit_type.CAL:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 95,
                        y: 372,
                        type: hmUI.data_type.CAL,
                        font_array: [
                            '20.png',
                            '21.png',
                            '22.png',
                            '23.png',
                            '24.png',
                            '25.png',
                            '26.png',
                            '27.png',
                            '28.png',
                            '29.png'
                        ],
                        align_h: hmUI.align.LEFT,
                        h_space: 3,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '94.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 66,
                        y: 372,
                        w: 21,
                        h: 31,
                        src: '224.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 37,
                        y: 366,
                        w: 137,
                        h: 42,
                        type: hmUI.data_type.CAL,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.PAI_DAILY:
                    break;
                case hmUI.edit_type.DISTANCE:
                    break;
                case hmUI.edit_type.AQI:
                    break;
                case hmUI.edit_type.HUMIDITY:
                    break;
                case hmUI.edit_type.ALTIMETER:
                    break;
                case hmUI.edit_type.STRESS:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 95,
                        y: 372,
                        type: hmUI.data_type.STRESS,
                        font_array: [
                            '20.png',
                            '21.png',
                            '22.png',
                            '23.png',
                            '24.png',
                            '25.png',
                            '26.png',
                            '27.png',
                            '28.png',
                            '29.png'
                        ],
                        align_h: hmUI.align.LEFT,
                        h_space: 3,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '94.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 63,
                        y: 368,
                        w: 26,
                        h: 38,
                        src: '226.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 37,
                        y: 366,
                        w: 137,
                        h: 42,
                        type: hmUI.data_type.STRESS,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.WIND:
                    break;
                case hmUI.edit_type.SPO2:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 95,
                        y: 372,
                        type: hmUI.data_type.SPO2,
                        font_array: [
                            '20.png',
                            '21.png',
                            '22.png',
                            '23.png',
                            '24.png',
                            '25.png',
                            '26.png',
                            '27.png',
                            '28.png',
                            '29.png'
                        ],
                        align_h: hmUI.align.LEFT,
                        h_space: 3,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '94.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 63,
                        y: 372,
                        w: 26,
                        h: 31,
                        src: '228.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 37,
                        y: 366,
                        w: 137,
                        h: 42,
                        type: hmUI.data_type.SPO2,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.TRAINING_LOAD:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 95,
                        y: 372,
                        type: hmUI.data_type.TRAINING_LOAD,
                        font_array: [
                            '20.png',
                            '21.png',
                            '22.png',
                            '23.png',
                            '24.png',
                            '25.png',
                            '26.png',
                            '27.png',
                            '28.png',
                            '29.png'
                        ],
                        align_h: hmUI.align.LEFT,
                        h_space: 3,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '94.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 63,
                        y: 372,
                        w: 26,
                        h: 31,
                        src: '230.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 37,
                        y: 366,
                        w: 137,
                        h: 42,
                        type: hmUI.data_type.TRAINING_LOAD,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.VO2MAX:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 95,
                        y: 372,
                        type: hmUI.data_type.VO2MAX,
                        font_array: [
                            '20.png',
                            '21.png',
                            '22.png',
                            '23.png',
                            '24.png',
                            '25.png',
                            '26.png',
                            '27.png',
                            '28.png',
                            '29.png'
                        ],
                        align_h: hmUI.align.LEFT,
                        h_space: 3,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '94.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 64,
                        y: 371,
                        w: 32,
                        h: 39,
                        src: '232.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 37,
                        y: 366,
                        w: 137,
                        h: 42,
                        type: hmUI.data_type.VO2MAX,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.UVI:
                    break;
                case hmUI.edit_type.DATE:
                    break;
                case hmUI.edit_type.WEEK:
                    break;
                case hmUI.edit_type.WEATHER:
                    break;
                case hmUI.edit_type.TEMPERATURE:
                    break;
                case hmUI.edit_type.SUN:
                    break;
                }
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    second_centerX: 295,
                    second_centerY: 262,
                    second_posX: 25,
                    second_posY: 25,
                    second_path: '233.png',
                    second_cover_x: 0,
                    second_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 21,
                    hour_startY: 195,
                    hour_array: [
                        '234.png',
                        '235.png',
                        '236.png',
                        '237.png',
                        '238.png',
                        '239.png',
                        '240.png',
                        '241.png',
                        '242.png',
                        '243.png'
                    ],
                    hour_space: 10,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 150,
                    minute_startY: 195,
                    minute_array: [
                        '234.png',
                        '235.png',
                        '236.png',
                        '237.png',
                        '238.png',
                        '239.png',
                        '240.png',
                        '241.png',
                        '242.png',
                        '243.png'
                    ],
                    minute_space: 10,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    second_zero: 1,
                    second_startX: 271,
                    second_startY: 190,
                    second_array: [
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png'
                    ],
                    second_space: 4,
                    second_align: hmUI.align.LEFT,
                    second_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '244.png',
                    show_level: hmUI.show_level.ONLY_EDIT
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 122,
                    hour_startY: 195,
                    hour_array: [
                        '245.png',
                        '246.png',
                        '247.png',
                        '248.png',
                        '249.png',
                        '250.png',
                        '251.png',
                        '252.png',
                        '253.png',
                        '254.png'
                    ],
                    hour_space: 10,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 251,
                    minute_startY: 195,
                    minute_array: [
                        '245.png',
                        '246.png',
                        '247.png',
                        '248.png',
                        '249.png',
                        '250.png',
                        '251.png',
                        '252.png',
                        '253.png',
                        '254.png'
                    ],
                    minute_space: 10,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                const pl = hmUI.createWidget(hmUI.widget.GRADKIENT_POLYLINE, {
                  x: 190,
                  y: 419,
                  w: 100,
                  h: 52,
                  line_color: 0xff3333,
                  line_width: 2,
                  color_from: 0xff3333,
                  color_to: 0xff3333,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
               });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 120,
                    y: 0,
                    w: 50,
                    h: 90,
                    type: hmUI.data_type.ALARM_CLOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 163,
                    y: 303,
                    w: 162,
                    h: 59,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 336,
                    y: 178,
                    w: 134,
                    h: 125,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 10,
                    y: 303,
                    w: 144,
                    h: 59,
                    type: hmUI.data_type.DISTANCE,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 184,
                    y: 366,
                    w: 115,
                    h: 115,
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 220,
                    y: 91,
                    w: 117,
                    h: 84,
                    type: hmUI.data_type.SUN_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 67,
                    y: 408,
                    w: 119,
                    h: 67,
                    type: hmUI.data_type.PAI_WEEKLY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 298,
                    y: 406,
                    w: 118,
                    h: 64,
                    type: hmUI.data_type.UVI,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 337,
                    y: 304,
                    w: 132,
                    h: 38,
                    type: hmUI.data_type.HUMIDITY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 338,
                    y: 132,
                    w: 134,
                    h: 44,
                    type: hmUI.data_type.ALTIMETER,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 298,
                    y: 365,
                    w: 134,
                    h: 40,
                    type: hmUI.data_type.WIND,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                // vibration when connecting or disconnecting

                function checkConnection() {
                  hmBle.removeListener;
                  hmBle.addListener(function (status) {
                    if(!status) {
                      hmUI.showToast({text: "Bluetooth Disconnected"});
                      vibro(9);
                    }
                  });
                }

                // end vibration when connecting or disconnecting
                // vibrate function

                const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
                let timer_StopVibrate = null;


                function vibro(scene = 25) {
                  let stopDelay = 50;
                  stopVibro();
                  vibrate.stop();
                  vibrate.scene = scene;
                  if(scene < 23 || scene > 25) stopDelay = 1300;
                  vibrate.start();
                  timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
                }

                function stopVibro(){
                  vibrate.stop();
                  if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
                }

                // end vibrate function
                const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                  resume_call: (function () {
                    checkConnection();
                    stopVibro();

                  }),
                  pause_call: (function () {
                    stopVibro();

                }),
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}