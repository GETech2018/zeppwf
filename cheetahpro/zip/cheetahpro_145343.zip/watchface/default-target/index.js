try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_36f957e27eae49c1b865b98723a9bef5 = '';
        let normal$_$text_6a53bde4cba3476da14fc7af9d0b58fc = '';
        let normal$_$text_cbca3bb54a404464865aa9818ef2ed16 = '';
        let normal$_$text_d46bc8228b3f4f30b4f9ead963f0dc21 = '';
        let normal$_$text_b4ed7a7cd53a481cb8fc0bdaf711ccac = '';
        let normal$_$text_6e85a73ddca840e288dc0bcd4b91082b = '';
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 128,
                    hour_startY: 191,
                    hour_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    hour_space: 7,
                    hour_align: hmUI.align.RIGHT,
                    minute_zero: 1,
                    minute_startX: 275,
                    minute_startY: 191,
                    minute_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    minute_space: 7,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    second_zero: 1,
                    second_startX: 397,
                    second_startY: 191,
                    second_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    second_space: 7,
                    second_align: hmUI.align.LEFT,
                    second_follow: 0,
                    am_x: 399,
                    am_y: 247,
                    am_en_path: '23.png',
                    pm_x: 399,
                    pm_y: 247,
                    pm_en_path: '24.png',
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 299,
                    month_startY: 394,
                    month_sc_array: [
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png'
                    ],
                    month_tc_array: [
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png'
                    ],
                    month_en_array: [
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png'
                    ],
                    month_align: hmUI.align.CENTER_H,
                    month_zero: 1,
                    month_follow: 0,
                    month_space: 0,
                    month_is_character: false,
                    day_startX: 361,
                    day_startY: 394,
                    day_sc_array: [
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png'
                    ],
                    day_tc_array: [
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png'
                    ],
                    day_en_array: [
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png'
                    ],
                    day_align: hmUI.align.CENTER_H,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 0,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 28,
                    y: 131,
                    week_en: [
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png'
                    ],
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 159,
                    y: 46,
                    type: hmUI.data_type.AQI,
                    font_array: [
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '42.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 292,
                    y: 46,
                    type: hmUI.data_type.UVI,
                    font_array: [
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '43.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 115,
                    y: 86,
                    type: hmUI.data_type.HEART,
                    font_array: [
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '44.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 72,
                    y: 77,
                    src: '45.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 36,
                    y: 265,
                    type: hmUI.data_type.BATTERY,
                    font_array: [
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png',
                        '54.png',
                        '55.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '57.png',
                    unit_tc: '57.png',
                    unit_en: '57.png',
                    invalid_image: '56.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 31,
                    y: 216,
                    src: '58.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 131,
                    y: 312,
                    type: hmUI.data_type.HUMIDITY,
                    font_array: [
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '60.png',
                    unit_tc: '60.png',
                    unit_en: '60.png',
                    invalid_image: '59.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 156,
                    y: 395,
                    type: hmUI.data_type.STEP,
                    font_array: [
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '61.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 89,
                    y: 387,
                    src: '62.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 201,
                    y: 439,
                    type: hmUI.data_type.CAL,
                    font_array: [
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '63.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 278,
                    y: 317,
                    image_array: [
                        '64.png',
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png',
                        '71.png',
                        '72.png',
                        '73.png',
                        '74.png',
                        '75.png',
                        '76.png',
                        '77.png',
                        '78.png',
                        '79.png',
                        '80.png',
                        '81.png',
                        '82.png',
                        '83.png',
                        '84.png',
                        '85.png',
                        '86.png',
                        '87.png',
                        '88.png',
                        '89.png',
                        '90.png',
                        '91.png',
                        '92.png'
                    ],
                    image_length: 29,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 316,
                    y: 89,
                    type: hmUI.data_type.SPO2,
                    font_array: [
                        '93.png',
                        '94.png',
                        '95.png',
                        '96.png',
                        '97.png',
                        '98.png',
                        '99.png',
                        '100.png',
                        '101.png',
                        '102.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '104.png',
                    unit_tc: '104.png',
                    unit_en: '104.png',
                    invalid_image: '103.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 373,
                    y: 68,
                    src: '105.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 217,
                    y: 322,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: [
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '108.png',
                    unit_tc: '108.png',
                    unit_en: '108.png',
                    negative_image: '107.png',
                    invalid_image: '106.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 404,
                    y: 321,
                    type: hmUI.data_type.WEATHER_HIGH,
                    font_array: [
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    negative_image: '110.png',
                    invalid_image: '109.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 332,
                    y: 321,
                    type: hmUI.data_type.WEATHER_LOW,
                    font_array: [
                        '111.png',
                        '112.png',
                        '113.png',
                        '114.png',
                        '115.png',
                        '116.png',
                        '117.png',
                        '118.png',
                        '119.png',
                        '120.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    negative_image: '122.png',
                    invalid_image: '121.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 238,
                    y: 98,
                    type: hmUI.data_type.STRESS,
                    font_array: [
                        '123.png',
                        '124.png',
                        '125.png',
                        '126.png',
                        '127.png',
                        '128.png',
                        '129.png',
                        '130.png',
                        '131.png',
                        '132.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '133.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 205,
                    y: 89,
                    src: '134.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_36f957e27eae49c1b865b98723a9bef5 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 190,
                    y: 63,
                    w: 100,
                    h: 40,
                    text: 'STRESS',
                    color: '0xFF615f5f',
                    text_size: 19,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_6a53bde4cba3476da14fc7af9d0b58fc = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 5,
                    y: 191,
                    w: 100,
                    h: 40,
                    text: 'POWER',
                    color: '0xFF615f5f',
                    text_size: 17,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_cbca3bb54a404464865aa9818ef2ed16 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 195,
                    y: 287,
                    w: 100,
                    h: 40,
                    text: 'TEMP',
                    color: '0xFF615f5f',
                    text_size: 19,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_d46bc8228b3f4f30b4f9ead963f0dc21 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 345,
                    y: 287,
                    w: 100,
                    h: 40,
                    text: 'LO / HI',
                    color: '0xFF615f5f',
                    text_size: 19,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_b4ed7a7cd53a481cb8fc0bdaf711ccac = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 344,
                    y: 312,
                    w: 100,
                    h: 40,
                    text: '/',
                    color: '0xFFffffff',
                    text_size: 25,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_6e85a73ddca840e288dc0bcd4b91082b = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 298,
                    y: 385,
                    w: 100,
                    h: 40,
                    text: '/',
                    color: '0xFFffffff',
                    text_size: 28,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '135.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 128,
                    hour_startY: 191,
                    hour_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    hour_space: 7,
                    hour_align: hmUI.align.RIGHT,
                    minute_zero: 1,
                    minute_startX: 275,
                    minute_startY: 191,
                    minute_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    minute_space: 7,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    am_x: 399,
                    am_y: 247,
                    am_en_path: '136.png',
                    pm_x: 399,
                    pm_y: 247,
                    pm_en_path: '137.png',
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        normal$_$text_36f957e27eae49c1b865b98723a9bef5.setProperty(hmUI.prop.MORE, { text: `STRESS` });
                        normal$_$text_6a53bde4cba3476da14fc7af9d0b58fc.setProperty(hmUI.prop.MORE, { text: `POWER` });
                        normal$_$text_cbca3bb54a404464865aa9818ef2ed16.setProperty(hmUI.prop.MORE, { text: `TEMP` });
                        normal$_$text_d46bc8228b3f4f30b4f9ead963f0dc21.setProperty(hmUI.prop.MORE, { text: `LO / HI` });
                        normal$_$text_b4ed7a7cd53a481cb8fc0bdaf711ccac.setProperty(hmUI.prop.MORE, { text: `/` });
                        normal$_$text_6e85a73ddca840e288dc0bcd4b91082b.setProperty(hmUI.prop.MORE, { text: `/` });
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}