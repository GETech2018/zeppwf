try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_f36544d429bf46dbbbee60368acf86fe = '';
        let normal$_$component_0$_$component = '';
        let normal$_$component_2$_$component = '';
        let normal$_$component_3$_$component = '';
        let normal$_$component_1$_$component = '';
        let idle$_$text_6f37a1ca7a6f4c56bbb22741a8f94867 = '';
        let idle$_$text_610034d1212440a4aa27249033c665b0 = '';
        let idle$_$text_f7af8078997a458fac2833bc772896fa = '';
        let dateFormat = '';
        let dateFormatMap = '';
        let idle$_$text_ffc5747f8f544468a817a31d4be529a3 = '';
        let idle$_$text_e140dbb602ed4319a4f71d158e4ed1ef = '';
        let idle$_$text_ddcf51dc948c45afba336f422d150095 = '';
        let timeSensor = '';
        let batterySensor = '';
        let heartSensor = '';
        let stepSensor = '';
        let calorieSensor = '';
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.FILL_RECT, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    color: '0xFF000000',
                    radius: 240,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 247,
                    y: 371,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 244,
                    y: 19,
                    src: '3.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 335,
                    y: 94,
                    src: '4.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 335,
                    y: 300,
                    src: '5.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    minute_centerX: 52,
                    minute_centerY: 240,
                    minute_posX: 240,
                    minute_posY: 240,
                    minute_path: '6.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    second_centerX: 50,
                    second_centerY: 240,
                    second_posX: 240,
                    second_posY: 240,
                    second_path: '7.png',
                    second_cover_x: 0,
                    second_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    src: '8.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 124,
                    y: 197,
                    src: '9.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 0,
                    hour_startX: 21,
                    hour_startY: 199,
                    hour_array: [
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png'
                    ],
                    hour_space: -4,
                    hour_align: hmUI.align.RIGHT,
                    minute_val: new Date().getMinutes(),
                    minute_zero: 1,
                    minute_startX: 141,
                    minute_startY: 220,
                    minute_array: [
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png'
                    ],
                    minute_space: 0,
                    minute_align: hmUI.align.CENTER_H,
                    minute_follow: 0,
                    am_x: 44,
                    am_y: 67,
                    am_en_path: '30.png',
                    pm_x: 44,
                    pm_y: 67,
                    pm_en_path: '31.png',
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 310,
                    month_startY: 211,
                    month_en_array: [
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png'
                    ],
                    month_align: hmUI.align.LEFT,
                    month_zero: 0,
                    month_follow: 0,
                    month_space: 0,
                    month_is_character: true,
                    day_startX: 384,
                    day_startY: 220,
                    day_sc_array: [
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png'
                    ],
                    day_tc_array: [
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png'
                    ],
                    day_en_array: [
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png'
                    ],
                    day_align: hmUI.align.LEFT,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: -1,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 316,
                    y: 240,
                    src: '44.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_f36544d429bf46dbbbee60368acf86fe = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 294,
                    y: 237,
                    w: 100,
                    h: 40,
                    text: '[WEEK_EN_S]',
                    color: '0xFF000000',
                    text_size: 22,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$component_0$_$component = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: 1,
                    x: 0,
                    y: 0,
                    w: 0,
                    h: 0,
                    default_type: hmUI.edit_type.HEART,
                    optional_types: [
                        {
                            'type': hmUI.edit_type.HEART,
                            'preview': ''
                        },
                        {
                            'type': hmUI.edit_type.STEP,
                            'preview': ''
                        },
                        {
                            'type': hmUI.edit_type.BATTERY,
                            'preview': ''
                        },
                        {
                            'type': hmUI.edit_type.CAL,
                            'preview': ''
                        },
                        {
                            'type': hmUI.edit_type.TEMPERATURE,
                            'preview': ''
                        },
                        {
                            'type': hmUI.edit_type.DISTANCE,
                            'preview': ''
                        },
                        {
                            'type': hmUI.edit_type.PAI_DAILY,
                            'preview': ''
                        }
                    ],
                    count: 7,
                    select_list: {
                        title_font_size: 34,
                        title_align_h: hmUI.align.CENTER_H,
                        list_item_vspace: 8,
                        list_tips_text_font_size: 32,
                        list_tips_text_align_h: hmUI.align.LEFT
                    },
                    tips_x: 0,
                    tips_y: 0,
                    tips_width: 0,
                    tips_margin: 0
                });
                editType = normal$_$component_0$_$component.getProperty(hmUI.prop.CURRENT_TYPE);
                switch (editType) {
                case hmUI.edit_type.STEP:
                    hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                        center_x: 290,
                        center_y: 65,
                        radius: 42,
                        start_angle: 20,
                        end_angle: 340,
                        color: 4278811633,
                        line_width: 8,
                        type: hmUI.data_type.STEP,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 263,
                        y: 56,
                        type: hmUI.data_type.STEP,
                        font_array: [
                            '45.png',
                            '46.png',
                            '47.png',
                            '48.png',
                            '49.png',
                            '50.png',
                            '51.png',
                            '52.png',
                            '53.png',
                            '54.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -2,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 278,
                        y: 13,
                        src: '55.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 253,
                        y: 30,
                        w: 72,
                        h: 66,
                        type: hmUI.data_type.STEP,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.BATTERY:
                    hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                        center_x: 290,
                        center_y: 64,
                        radius: 42,
                        start_angle: 20,
                        end_angle: 340,
                        color: 4278514957,
                        line_width: 8,
                        type: hmUI.data_type.BATTERY,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 272,
                        y: 56,
                        type: hmUI.data_type.BATTERY,
                        font_array: [
                            '45.png',
                            '46.png',
                            '47.png',
                            '48.png',
                            '49.png',
                            '50.png',
                            '51.png',
                            '52.png',
                            '53.png',
                            '54.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -2,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 277,
                        y: 12,
                        src: '56.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 253,
                        y: 30,
                        w: 72,
                        h: 66,
                        type: hmUI.data_type.BATTERY,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.HEART:
                    hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                        center_x: 290,
                        center_y: 65,
                        radius: 42,
                        start_angle: 20,
                        end_angle: 340,
                        color: 4293857165,
                        line_width: 8,
                        type: hmUI.data_type.HEART,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 273,
                        y: 53,
                        type: hmUI.data_type.HEART,
                        font_array: [
                            '45.png',
                            '46.png',
                            '47.png',
                            '48.png',
                            '49.png',
                            '50.png',
                            '51.png',
                            '52.png',
                            '53.png',
                            '54.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -2,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '57.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 279,
                        y: 16,
                        src: '58.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 254,
                        y: 30,
                        w: 72,
                        h: 66,
                        type: hmUI.data_type.HEART,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.CAL:
                    hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                        center_x: 290,
                        center_y: 65,
                        radius: 42,
                        start_angle: 20,
                        end_angle: 340,
                        color: 4293295625,
                        line_width: 8,
                        type: hmUI.data_type.CAL,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 266,
                        y: 55,
                        type: hmUI.data_type.CAL,
                        font_array: [
                            '45.png',
                            '46.png',
                            '47.png',
                            '48.png',
                            '49.png',
                            '50.png',
                            '51.png',
                            '52.png',
                            '53.png',
                            '54.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -2,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 278,
                        y: 9,
                        src: '59.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 253,
                        y: 30,
                        w: 72,
                        h: 66,
                        type: hmUI.data_type.CAL,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.PAI_DAILY:
                    hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                        center_x: 290,
                        center_y: 65,
                        radius: 42,
                        start_angle: 20,
                        end_angle: 340,
                        color: 4279963102,
                        line_width: 8,
                        type: hmUI.data_type.PAI_DAILY,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 274,
                        y: 56,
                        type: hmUI.data_type.PAI_DAILY,
                        font_array: [
                            '45.png',
                            '46.png',
                            '47.png',
                            '48.png',
                            '49.png',
                            '50.png',
                            '51.png',
                            '52.png',
                            '53.png',
                            '54.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -2,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 278,
                        y: 12,
                        src: '60.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 253,
                        y: 30,
                        w: 72,
                        h: 66,
                        type: hmUI.data_type.PAI_DAILY,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.DISTANCE:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 257,
                        y: 56,
                        type: hmUI.data_type.DISTANCE,
                        font_array: [
                            '45.png',
                            '46.png',
                            '47.png',
                            '48.png',
                            '49.png',
                            '50.png',
                            '51.png',
                            '52.png',
                            '53.png',
                            '54.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -2,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        unit_sc: '62.png',
                        unit_tc: '62.png',
                        unit_en: '62.png',
                        imperial_unit_sc: '63.png',
                        imperial_unit_tc: '63.png',
                        imperial_unit_en: '63.png',
                        dot_image: '61.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 278,
                        y: 13,
                        src: '64.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 251,
                        y: 30,
                        w: 72,
                        h: 66,
                        type: hmUI.data_type.DISTANCE,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.AQI:
                    break;
                case hmUI.edit_type.HUMIDITY:
                    break;
                case hmUI.edit_type.ALTIMETER:
                    break;
                case hmUI.edit_type.STRESS:
                    break;
                case hmUI.edit_type.WIND:
                    break;
                case hmUI.edit_type.SPO2:
                    break;
                case hmUI.edit_type.TRAINING_LOAD:
                    break;
                case hmUI.edit_type.VO2MAX:
                    break;
                case hmUI.edit_type.UVI:
                    break;
                case hmUI.edit_type.DATE:
                    break;
                case hmUI.edit_type.WEEK:
                    break;
                case hmUI.edit_type.WEATHER:
                    break;
                case hmUI.edit_type.TEMPERATURE:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 274,
                        y: 56,
                        type: hmUI.data_type.WEATHER_CURRENT,
                        font_array: [
                            '45.png',
                            '46.png',
                            '47.png',
                            '48.png',
                            '49.png',
                            '50.png',
                            '51.png',
                            '52.png',
                            '53.png',
                            '54.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -2,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        unit_sc: '67.png',
                        unit_tc: '67.png',
                        unit_en: '67.png',
                        negative_image: '66.png',
                        invalid_image: '65.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 284,
                        y: 12,
                        src: '68.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                        center_x: 290,
                        center_y: 65,
                        radius: 42,
                        start_angle: 20,
                        end_angle: 340,
                        color: 4294967295,
                        line_width: 8,
                        type: hmUI.data_type.WEATHER_CURRENT,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 252,
                        y: 30,
                        w: 72,
                        h: 66,
                        type: hmUI.data_type.WEATHER_CURRENT,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.SUN:
                    break;
                }
                normal$_$component_2$_$component = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: 2,
                    x: 84,
                    y: 279,
                    w: 0,
                    h: 0,
                    default_type: hmUI.edit_type.BATTERY,
                    optional_types: [
                        {
                            'type': hmUI.edit_type.BATTERY,
                            'preview': ''
                        },
                        {
                            'type': hmUI.edit_type.STEP,
                            'preview': ''
                        },
                        {
                            'type': hmUI.edit_type.CAL,
                            'preview': ''
                        },
                        {
                            'type': hmUI.edit_type.TEMPERATURE,
                            'preview': ''
                        },
                        {
                            'type': hmUI.edit_type.DISTANCE,
                            'preview': ''
                        },
                        {
                            'type': hmUI.edit_type.HEART,
                            'preview': ''
                        },
                        {
                            'type': hmUI.edit_type.PAI_DAILY,
                            'preview': ''
                        }
                    ],
                    count: 7,
                    select_list: {
                        title_font_size: 34,
                        title_align_h: hmUI.align.CENTER_H,
                        list_item_vspace: 8,
                        list_tips_text_font_size: 32,
                        list_tips_text_align_h: hmUI.align.CENTER_H
                    },
                    tips_x: 1,
                    tips_y: 0,
                    tips_width: 0,
                    tips_margin: 0
                });
                editType = normal$_$component_2$_$component.getProperty(hmUI.prop.CURRENT_TYPE);
                switch (editType) {
                case hmUI.edit_type.STEP:
                    hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                        center_x: 380,
                        center_y: 344,
                        radius: 42,
                        start_angle: 20,
                        end_angle: 340,
                        color: 4278811633,
                        line_width: 8,
                        type: hmUI.data_type.STEP,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 353,
                        y: 335,
                        type: hmUI.data_type.STEP,
                        font_array: [
                            '45.png',
                            '46.png',
                            '47.png',
                            '48.png',
                            '49.png',
                            '50.png',
                            '51.png',
                            '52.png',
                            '53.png',
                            '54.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -2,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 368,
                        y: 291,
                        src: '55.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 342,
                        y: 309,
                        w: 72,
                        h: 66,
                        type: hmUI.data_type.STEP,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.BATTERY:
                    hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                        center_x: 380,
                        center_y: 344,
                        radius: 42,
                        start_angle: 20,
                        end_angle: 340,
                        color: 4278514957,
                        line_width: 8,
                        type: hmUI.data_type.BATTERY,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 363,
                        y: 335,
                        type: hmUI.data_type.BATTERY,
                        font_array: [
                            '45.png',
                            '46.png',
                            '47.png',
                            '48.png',
                            '49.png',
                            '50.png',
                            '51.png',
                            '52.png',
                            '53.png',
                            '54.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -2,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 368,
                        y: 294,
                        src: '56.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 342,
                        y: 309,
                        w: 74,
                        h: 66,
                        type: hmUI.data_type.BATTERY,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.HEART:
                    hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                        center_x: 380,
                        center_y: 344,
                        radius: 42,
                        start_angle: 20,
                        end_angle: 340,
                        color: 4293857165,
                        line_width: 8,
                        type: hmUI.data_type.HEART,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 363,
                        y: 335,
                        type: hmUI.data_type.HEART,
                        font_array: [
                            '45.png',
                            '46.png',
                            '47.png',
                            '48.png',
                            '49.png',
                            '50.png',
                            '51.png',
                            '52.png',
                            '53.png',
                            '54.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -2,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '69.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 368,
                        y: 295,
                        src: '58.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 342,
                        y: 309,
                        w: 72,
                        h: 66,
                        type: hmUI.data_type.HEART,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.CAL:
                    hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                        center_x: 380,
                        center_y: 344,
                        radius: 42,
                        start_angle: 20,
                        end_angle: 340,
                        color: 4293295625,
                        line_width: 8,
                        type: hmUI.data_type.CAL,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 356,
                        y: 335,
                        type: hmUI.data_type.CAL,
                        font_array: [
                            '45.png',
                            '46.png',
                            '47.png',
                            '48.png',
                            '49.png',
                            '50.png',
                            '51.png',
                            '52.png',
                            '53.png',
                            '54.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -2,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 368,
                        y: 287,
                        src: '59.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 342,
                        y: 309,
                        w: 72,
                        h: 66,
                        type: hmUI.data_type.CAL,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.PAI_DAILY:
                    hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                        center_x: 380,
                        center_y: 344,
                        radius: 42,
                        start_angle: 20,
                        end_angle: 340,
                        color: 4280357860,
                        line_width: 8,
                        type: hmUI.data_type.PAI_DAILY,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 362,
                        y: 335,
                        type: hmUI.data_type.PAI_DAILY,
                        font_array: [
                            '45.png',
                            '46.png',
                            '47.png',
                            '48.png',
                            '49.png',
                            '50.png',
                            '51.png',
                            '52.png',
                            '53.png',
                            '54.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -2,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 368,
                        y: 291,
                        src: '60.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 342,
                        y: 309,
                        w: 72,
                        h: 66,
                        type: hmUI.data_type.PAI_DAILY,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.DISTANCE:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 344,
                        y: 335,
                        type: hmUI.data_type.DISTANCE,
                        font_array: [
                            '45.png',
                            '46.png',
                            '47.png',
                            '48.png',
                            '49.png',
                            '50.png',
                            '51.png',
                            '52.png',
                            '53.png',
                            '54.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -2,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        unit_sc: '71.png',
                        unit_tc: '71.png',
                        unit_en: '71.png',
                        imperial_unit_sc: '72.png',
                        imperial_unit_tc: '72.png',
                        imperial_unit_en: '72.png',
                        dot_image: '70.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 368,
                        y: 293,
                        src: '64.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 342,
                        y: 309,
                        w: 72,
                        h: 66,
                        type: hmUI.data_type.DISTANCE,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.AQI:
                    break;
                case hmUI.edit_type.HUMIDITY:
                    break;
                case hmUI.edit_type.ALTIMETER:
                    break;
                case hmUI.edit_type.STRESS:
                    break;
                case hmUI.edit_type.WIND:
                    break;
                case hmUI.edit_type.SPO2:
                    break;
                case hmUI.edit_type.TRAINING_LOAD:
                    break;
                case hmUI.edit_type.VO2MAX:
                    break;
                case hmUI.edit_type.UVI:
                    break;
                case hmUI.edit_type.DATE:
                    break;
                case hmUI.edit_type.WEEK:
                    break;
                case hmUI.edit_type.WEATHER:
                    break;
                case hmUI.edit_type.TEMPERATURE:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 362,
                        y: 335,
                        type: hmUI.data_type.WEATHER_CURRENT,
                        font_array: [
                            '45.png',
                            '46.png',
                            '47.png',
                            '48.png',
                            '49.png',
                            '50.png',
                            '51.png',
                            '52.png',
                            '53.png',
                            '54.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -2,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        unit_sc: '67.png',
                        unit_tc: '67.png',
                        unit_en: '67.png',
                        negative_image: '66.png',
                        invalid_image: '65.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 373,
                        y: 292,
                        src: '68.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                        center_x: 380,
                        center_y: 344,
                        radius: 42,
                        start_angle: 20,
                        end_angle: 340,
                        color: 4294967295,
                        line_width: 8,
                        type: hmUI.data_type.WEATHER_CURRENT,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 342,
                        y: 309,
                        w: 72,
                        h: 66,
                        type: hmUI.data_type.WEATHER_CURRENT,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.SUN:
                    break;
                }
                normal$_$component_3$_$component = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: 3,
                    x: 0,
                    y: 0,
                    w: 0,
                    h: 0,
                    default_type: hmUI.edit_type.STEP,
                    optional_types: [
                        {
                            'type': hmUI.edit_type.STEP,
                            'preview': ''
                        },
                        {
                            'type': hmUI.edit_type.BATTERY,
                            'preview': ''
                        },
                        {
                            'type': hmUI.edit_type.CAL,
                            'preview': ''
                        },
                        {
                            'type': hmUI.edit_type.TEMPERATURE,
                            'preview': ''
                        },
                        {
                            'type': hmUI.edit_type.DISTANCE,
                            'preview': ''
                        },
                        {
                            'type': hmUI.edit_type.HEART,
                            'preview': ''
                        },
                        {
                            'type': hmUI.edit_type.PAI_DAILY,
                            'preview': ''
                        }
                    ],
                    count: 7,
                    select_list: {
                        title_font_size: 34,
                        title_align_h: hmUI.align.CENTER_H,
                        list_item_vspace: 8,
                        list_tips_text_font_size: 32,
                        list_tips_text_align_h: hmUI.align.CENTER_H
                    },
                    tips_x: 0,
                    tips_y: 0,
                    tips_width: 0,
                    tips_margin: 0
                });
                editType = normal$_$component_3$_$component.getProperty(hmUI.prop.CURRENT_TYPE);
                switch (editType) {
                case hmUI.edit_type.STEP:
                    hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                        center_x: 290,
                        center_y: 418,
                        radius: 42,
                        start_angle: 20,
                        end_angle: 340,
                        color: 4278811633,
                        line_width: 8,
                        type: hmUI.data_type.STEP,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 263,
                        y: 409,
                        type: hmUI.data_type.STEP,
                        font_array: [
                            '45.png',
                            '46.png',
                            '47.png',
                            '48.png',
                            '49.png',
                            '50.png',
                            '51.png',
                            '52.png',
                            '53.png',
                            '54.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -2,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 279,
                        y: 366,
                        src: '55.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 253,
                        y: 383,
                        w: 72,
                        h: 66,
                        type: hmUI.data_type.STEP,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.BATTERY:
                    hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                        center_x: 290,
                        center_y: 418,
                        radius: 42,
                        start_angle: 20,
                        end_angle: 340,
                        color: 4278514957,
                        line_width: 8,
                        type: hmUI.data_type.BATTERY,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 272,
                        y: 409,
                        type: hmUI.data_type.BATTERY,
                        font_array: [
                            '45.png',
                            '46.png',
                            '47.png',
                            '48.png',
                            '49.png',
                            '50.png',
                            '51.png',
                            '52.png',
                            '53.png',
                            '54.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -2,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 278,
                        y: 365,
                        src: '56.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 253,
                        y: 383,
                        w: 72,
                        h: 66,
                        type: hmUI.data_type.BATTERY,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.HEART:
                    hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                        center_x: 290,
                        center_y: 417,
                        radius: 42,
                        start_angle: 20,
                        end_angle: 340,
                        color: 4293857165,
                        line_width: 8,
                        type: hmUI.data_type.HEART,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 272,
                        y: 409,
                        type: hmUI.data_type.HEART,
                        font_array: [
                            '45.png',
                            '46.png',
                            '47.png',
                            '48.png',
                            '49.png',
                            '50.png',
                            '51.png',
                            '52.png',
                            '53.png',
                            '54.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -2,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '73.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 279,
                        y: 365,
                        src: '58.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 253,
                        y: 383,
                        w: 72,
                        h: 66,
                        type: hmUI.data_type.HEART,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.CAL:
                    hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                        center_x: 290,
                        center_y: 418,
                        radius: 42,
                        start_angle: 20,
                        end_angle: 340,
                        color: 4293295625,
                        line_width: 8,
                        type: hmUI.data_type.CAL,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 267,
                        y: 407,
                        type: hmUI.data_type.CAL,
                        font_array: [
                            '45.png',
                            '46.png',
                            '47.png',
                            '48.png',
                            '49.png',
                            '50.png',
                            '51.png',
                            '52.png',
                            '53.png',
                            '54.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -2,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 279,
                        y: 365,
                        src: '59.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 254,
                        y: 383,
                        w: 72,
                        h: 66,
                        type: hmUI.data_type.CAL,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.PAI_DAILY:
                    hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                        center_x: 290,
                        center_y: 418,
                        radius: 42,
                        start_angle: 20,
                        end_angle: 340,
                        color: 4279963102,
                        line_width: 8,
                        type: hmUI.data_type.PAI_DAILY,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 274,
                        y: 409,
                        type: hmUI.data_type.PAI_DAILY,
                        font_array: [
                            '45.png',
                            '46.png',
                            '47.png',
                            '48.png',
                            '49.png',
                            '50.png',
                            '51.png',
                            '52.png',
                            '53.png',
                            '54.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -2,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 279,
                        y: 364,
                        src: '60.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 255,
                        y: 383,
                        w: 72,
                        h: 66,
                        type: hmUI.data_type.PAI_DAILY,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.DISTANCE:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 258,
                        y: 405,
                        type: hmUI.data_type.DISTANCE,
                        font_array: [
                            '45.png',
                            '46.png',
                            '47.png',
                            '48.png',
                            '49.png',
                            '50.png',
                            '51.png',
                            '52.png',
                            '53.png',
                            '54.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -2,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        unit_sc: '75.png',
                        unit_tc: '75.png',
                        unit_en: '75.png',
                        imperial_unit_sc: '76.png',
                        imperial_unit_tc: '76.png',
                        imperial_unit_en: '76.png',
                        dot_image: '74.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 281,
                        y: 365,
                        src: '64.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 254,
                        y: 383,
                        w: 72,
                        h: 66,
                        type: hmUI.data_type.DISTANCE,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.AQI:
                    break;
                case hmUI.edit_type.HUMIDITY:
                    break;
                case hmUI.edit_type.ALTIMETER:
                    break;
                case hmUI.edit_type.STRESS:
                    break;
                case hmUI.edit_type.WIND:
                    break;
                case hmUI.edit_type.SPO2:
                    break;
                case hmUI.edit_type.TRAINING_LOAD:
                    break;
                case hmUI.edit_type.VO2MAX:
                    break;
                case hmUI.edit_type.UVI:
                    break;
                case hmUI.edit_type.DATE:
                    break;
                case hmUI.edit_type.WEEK:
                    break;
                case hmUI.edit_type.WEATHER:
                    break;
                case hmUI.edit_type.TEMPERATURE:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 274,
                        y: 409,
                        type: hmUI.data_type.WEATHER_CURRENT,
                        font_array: [
                            '45.png',
                            '46.png',
                            '47.png',
                            '48.png',
                            '49.png',
                            '50.png',
                            '51.png',
                            '52.png',
                            '53.png',
                            '54.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -2,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        unit_sc: '67.png',
                        unit_tc: '67.png',
                        unit_en: '67.png',
                        negative_image: '66.png',
                        invalid_image: '65.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 284,
                        y: 366,
                        src: '68.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                        center_x: 290,
                        center_y: 418,
                        radius: 42,
                        start_angle: 20,
                        end_angle: 340,
                        color: 4294967295,
                        line_width: 8,
                        type: hmUI.data_type.WEATHER_CURRENT,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 254,
                        y: 383,
                        w: 72,
                        h: 66,
                        type: hmUI.data_type.WEATHER_CURRENT,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.SUN:
                    break;
                }
                normal$_$component_1$_$component = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: 4,
                    x: 85,
                    y: 74,
                    w: 0,
                    h: 0,
                    default_type: hmUI.edit_type.CAL,
                    optional_types: [
                        {
                            'type': hmUI.edit_type.CAL,
                            'preview': ''
                        },
                        {
                            'type': hmUI.edit_type.STEP,
                            'preview': ''
                        },
                        {
                            'type': hmUI.edit_type.BATTERY,
                            'preview': ''
                        },
                        {
                            'type': hmUI.edit_type.TEMPERATURE,
                            'preview': ''
                        },
                        {
                            'type': hmUI.edit_type.DISTANCE,
                            'preview': ''
                        },
                        {
                            'type': hmUI.edit_type.HEART,
                            'preview': ''
                        },
                        {
                            'type': hmUI.edit_type.PAI_DAILY,
                            'preview': ''
                        }
                    ],
                    count: 7,
                    select_list: {
                        title_font_size: 34,
                        title_align_h: hmUI.align.CENTER_H,
                        list_item_vspace: 8,
                        list_tips_text_font_size: 32,
                        list_tips_text_align_h: hmUI.align.CENTER_H
                    },
                    tips_x: 0,
                    tips_y: 0,
                    tips_width: 0,
                    tips_margin: 0
                });
                editType = normal$_$component_1$_$component.getProperty(hmUI.prop.CURRENT_TYPE);
                switch (editType) {
                case hmUI.edit_type.STEP:
                    hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                        center_x: 380,
                        center_y: 139,
                        radius: 42,
                        start_angle: 20,
                        end_angle: 340,
                        color: 4278811633,
                        line_width: 8,
                        type: hmUI.data_type.STEP,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 352,
                        y: 130,
                        type: hmUI.data_type.STEP,
                        font_array: [
                            '45.png',
                            '46.png',
                            '47.png',
                            '48.png',
                            '49.png',
                            '50.png',
                            '51.png',
                            '52.png',
                            '53.png',
                            '54.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -2,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 368,
                        y: 86,
                        src: '55.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 342,
                        y: 104,
                        w: 72,
                        h: 66,
                        type: hmUI.data_type.STEP,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.BATTERY:
                    hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                        center_x: 380,
                        center_y: 139,
                        radius: 42,
                        start_angle: 20,
                        end_angle: 340,
                        color: 4278514957,
                        line_width: 8,
                        type: hmUI.data_type.BATTERY,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 361,
                        y: 130,
                        type: hmUI.data_type.BATTERY,
                        font_array: [
                            '45.png',
                            '46.png',
                            '47.png',
                            '48.png',
                            '49.png',
                            '50.png',
                            '51.png',
                            '52.png',
                            '53.png',
                            '54.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -2,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 368,
                        y: 88,
                        src: '56.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 345,
                        y: 104,
                        w: 70,
                        h: 66,
                        type: hmUI.data_type.BATTERY,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.HEART:
                    hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                        center_x: 380,
                        center_y: 139,
                        radius: 42,
                        start_angle: 20,
                        end_angle: 340,
                        color: 4293857165,
                        line_width: 8,
                        type: hmUI.data_type.HEART,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 362,
                        y: 130,
                        type: hmUI.data_type.HEART,
                        font_array: [
                            '45.png',
                            '46.png',
                            '47.png',
                            '48.png',
                            '49.png',
                            '50.png',
                            '51.png',
                            '52.png',
                            '53.png',
                            '54.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -2,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '77.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 368,
                        y: 88,
                        src: '58.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 342,
                        y: 104,
                        w: 72,
                        h: 66,
                        type: hmUI.data_type.HEART,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.CAL:
                    hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                        center_x: 380,
                        center_y: 139,
                        radius: 42,
                        start_angle: 20,
                        end_angle: 340,
                        color: 4293295625,
                        line_width: 8,
                        type: hmUI.data_type.CAL,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 358,
                        y: 130,
                        type: hmUI.data_type.CAL,
                        font_array: [
                            '45.png',
                            '46.png',
                            '47.png',
                            '48.png',
                            '49.png',
                            '50.png',
                            '51.png',
                            '52.png',
                            '53.png',
                            '54.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -2,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 370,
                        y: 83,
                        src: '59.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 342,
                        y: 104,
                        w: 72,
                        h: 66,
                        type: hmUI.data_type.CAL,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.PAI_DAILY:
                    hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                        center_x: 380,
                        center_y: 139,
                        radius: 42,
                        start_angle: 20,
                        end_angle: 340,
                        color: 4279963102,
                        line_width: 8,
                        type: hmUI.data_type.PAI_DAILY,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 364,
                        y: 130,
                        type: hmUI.data_type.PAI_DAILY,
                        font_array: [
                            '45.png',
                            '46.png',
                            '47.png',
                            '48.png',
                            '49.png',
                            '50.png',
                            '51.png',
                            '52.png',
                            '53.png',
                            '54.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -2,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 369,
                        y: 86,
                        src: '60.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 342,
                        y: 104,
                        w: 72,
                        h: 66,
                        type: hmUI.data_type.PAI_DAILY,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.DISTANCE:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 343,
                        y: 129,
                        type: hmUI.data_type.DISTANCE,
                        font_array: [
                            '45.png',
                            '46.png',
                            '47.png',
                            '48.png',
                            '49.png',
                            '50.png',
                            '51.png',
                            '52.png',
                            '53.png',
                            '54.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -1,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        unit_sc: '79.png',
                        unit_tc: '79.png',
                        unit_en: '79.png',
                        imperial_unit_sc: '80.png',
                        imperial_unit_tc: '80.png',
                        imperial_unit_en: '80.png',
                        dot_image: '78.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 368,
                        y: 87,
                        src: '64.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 342,
                        y: 104,
                        w: 72,
                        h: 66,
                        type: hmUI.data_type.DISTANCE,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.AQI:
                    break;
                case hmUI.edit_type.HUMIDITY:
                    break;
                case hmUI.edit_type.ALTIMETER:
                    break;
                case hmUI.edit_type.STRESS:
                    break;
                case hmUI.edit_type.WIND:
                    break;
                case hmUI.edit_type.SPO2:
                    break;
                case hmUI.edit_type.TRAINING_LOAD:
                    break;
                case hmUI.edit_type.VO2MAX:
                    break;
                case hmUI.edit_type.UVI:
                    break;
                case hmUI.edit_type.DATE:
                    break;
                case hmUI.edit_type.WEEK:
                    break;
                case hmUI.edit_type.WEATHER:
                    break;
                case hmUI.edit_type.TEMPERATURE:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 364,
                        y: 130,
                        type: hmUI.data_type.WEATHER_CURRENT,
                        font_array: [
                            '45.png',
                            '46.png',
                            '47.png',
                            '48.png',
                            '49.png',
                            '50.png',
                            '51.png',
                            '52.png',
                            '53.png',
                            '54.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -2,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        unit_sc: '67.png',
                        unit_tc: '67.png',
                        unit_en: '67.png',
                        negative_image: '66.png',
                        invalid_image: '65.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 374,
                        y: 87,
                        src: '68.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                        center_x: 380,
                        center_y: 139,
                        radius: 42,
                        start_angle: 20,
                        end_angle: 340,
                        color: 4294967295,
                        line_width: 8,
                        type: hmUI.data_type.WEATHER_CURRENT,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 342,
                        y: 104,
                        w: 72,
                        h: 66,
                        type: hmUI.data_type.WEATHER_CURRENT,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.SUN:
                    break;
                }
                hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '81.png',
                    show_level: hmUI.show_level.ONLY_EDIT
                });
                hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '82.png',
                    show_level: hmUI.show_level.ONLY_EDIT
                });
                idle$_$text_6f37a1ca7a6f4c56bbb22741a8f94867 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 190,
                    y: 421,
                    w: 100,
                    h: 40,
                    text: '[BATT_PER]%',
                    color: '0xFFff0000',
                    text_size: 17,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                idle$_$text_610034d1212440a4aa27249033c665b0 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 164,
                    y: 143,
                    w: 90,
                    h: 40,
                    text: '[HR]:[MIN_Z]',
                    color: '0xFFf80000',
                    text_size: 60,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                idle$_$text_f7af8078997a458fac2833bc772896fa = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 184,
                    y: 110,
                    w: 100,
                    h: 40,
                    text: '[WEEK_EN_S],[DAY_Z],[DAY_Z]',
                    color: '0xFFff0000',
                    text_size: 24,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                idle$_$text_ffc5747f8f544468a817a31d4be529a3 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 77,
                    y: 303,
                    w: 100,
                    h: 40,
                    text: '[SC] Steps',
                    color: '0xFFff0000',
                    text_size: 17,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                idle$_$text_e140dbb602ed4319a4f71d158e4ed1ef = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 316,
                    y: 303,
                    w: 100,
                    h: 40,
                    text: '[CAL] Kcal',
                    color: '0xFFff0000',
                    text_size: 17,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                idle$_$text_ddcf51dc948c45afba336f422d150095 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 198,
                    y: 303,
                    w: 100,
                    h: 40,
                    text: '[HR] Heart',
                    color: '0xFFff0000',
                    text_size: 17,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 229,
                    y: 396,
                    src: '83.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                if (!timeSensor) {
                    timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                }
                if (!batterySensor) {
                    batterySensor = hmSensor.createSensor(hmSensor.id.BATTERY);
                }
                if (!heartSensor) {
                    heartSensor = hmSensor.createSensor(hmSensor.id.HEART);
                }
                if (!stepSensor) {
                    stepSensor = hmSensor.createSensor(hmSensor.id.STEP);
                }
                if (!calorieSensor) {
                    calorieSensor = hmSensor.createSensor(hmSensor.id.CALORIE);
                }
                timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
                    const WEEK_EN_S = function (val) {
                        const valueMap = {
                            '1': 'Mon',
                            '2': 'Tue',
                            '3': 'Wed',
                            '4': 'Thu',
                            '5': 'Fri',
                            '6': 'Sat',
                            '7': 'Sun'
                        };
                        return valueMap[val];
                    };
                    normal$_$text_f36544d429bf46dbbbee60368acf86fe.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_S(timeSensor.week) }` });
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            idle$_$text_f7af8078997a458fac2833bc772896fa.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') },${ String(timeSensor.day).padStart(2, '0') },${ String(timeSensor.day).padStart(2, '0') }` });
                        },
                        () => {
                            idle$_$text_f7af8078997a458fac2833bc772896fa.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') },${ String(timeSensor.day).padStart(2, '0') },${ String(timeSensor.day).padStart(2, '0') }` });
                        },
                        () => {
                            idle$_$text_f7af8078997a458fac2833bc772896fa.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') },${ String(timeSensor.day).padStart(2, '0') },${ String(timeSensor.day).padStart(2, '0') }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                }), batterySensor.addEventListener(hmSensor.event.CHANGE, function () {
                    idle$_$text_6f37a1ca7a6f4c56bbb22741a8f94867.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }%` });
                }), heartSensor.addEventListener(heartSensor.event.LAST, function () {
                    idle$_$text_610034d1212440a4aa27249033c665b0.setProperty(hmUI.prop.MORE, { text: `${ heartSensor.last }:${ String(timeSensor.minute).padStart(2, '0') }` });
                    idle$_$text_ddcf51dc948c45afba336f422d150095.setProperty(hmUI.prop.MORE, { text: `${ heartSensor.last } Heart` });
                }), stepSensor.addEventListener(hmSensor.event.CHANGE, function () {
                    idle$_$text_ffc5747f8f544468a817a31d4be529a3.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current } Steps` });
                }), calorieSensor.addEventListener(hmSensor.event.CHANGE, function () {
                    idle$_$text_e140dbb602ed4319a4f71d158e4ed1ef.setProperty(hmUI.prop.MORE, { text: `${ calorieSensor.current } Kcal` });
                });
                idle$_$text_610034d1212440a4aa27249033c665b0.setProperty(hmUI.prop.MORE, { text: `${ heartSensor.last }:${ String(timeSensor.minute).padStart(2, '0') }` });
                timer.createTimer(0, 1000, function (timeSensor2) {
                    idle$_$text_610034d1212440a4aa27249033c665b0.setProperty(hmUI.prop.MORE, { text: `${ heartSensor.last }:${ String(timeSensor2.minute).padStart(2, '0') }` });
                }, timeSensor);
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        const WEEK_EN_S = function (val) {
                            const valueMap = {
                                '1': 'Mon',
                                '2': 'Tue',
                                '3': 'Wed',
                                '4': 'Thu',
                                '5': 'Fri',
                                '6': 'Sat',
                                '7': 'Sun'
                            };
                            return valueMap[val];
                        };
                        normal$_$text_f36544d429bf46dbbbee60368acf86fe.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_S(timeSensor.week) }` });
                        idle$_$text_6f37a1ca7a6f4c56bbb22741a8f94867.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }%` });
                        idle$_$text_610034d1212440a4aa27249033c665b0.setProperty(hmUI.prop.MORE, { text: `${ heartSensor.last }:${ String(timeSensor.minute).padStart(2, '0') }` });
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                idle$_$text_f7af8078997a458fac2833bc772896fa.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') },${ String(timeSensor.day).padStart(2, '0') },${ String(timeSensor.day).padStart(2, '0') }` });
                            },
                            () => {
                                idle$_$text_f7af8078997a458fac2833bc772896fa.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') },${ String(timeSensor.day).padStart(2, '0') },${ String(timeSensor.day).padStart(2, '0') }` });
                            },
                            () => {
                                idle$_$text_f7af8078997a458fac2833bc772896fa.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') },${ String(timeSensor.day).padStart(2, '0') },${ String(timeSensor.day).padStart(2, '0') }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                        idle$_$text_ffc5747f8f544468a817a31d4be529a3.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current } Steps` });
                        idle$_$text_e140dbb602ed4319a4f71d158e4ed1ef.setProperty(hmUI.prop.MORE, { text: `${ calorieSensor.current } Kcal` });
                        idle$_$text_ddcf51dc948c45afba336f422d150095.setProperty(hmUI.prop.MORE, { text: `${ heartSensor.last } Heart` });
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}