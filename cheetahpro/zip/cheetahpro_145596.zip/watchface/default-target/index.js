try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 85,
                    y: 131,
                    type: hmUI.data_type.HEART,
                    font_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '13.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: '14.png',
                    center_x: 109,
                    center_y: 147,
                    x: 10,
                    y: 57,
                    type: hmUI.data_type.HEART,
                    start_angle: -138,
                    end_angle: 135,
                    cover_x: 0,
                    cover_y: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 203,
                    y: 131,
                    type: hmUI.data_type.STAND,
                    font_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    dot_image: '16.png',
                    padding: true,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: '17.png',
                    center_x: 240,
                    center_y: 147,
                    x: 10,
                    y: 57,
                    type: hmUI.data_type.STAND,
                    start_angle: -137,
                    end_angle: 135,
                    cover_x: 0,
                    cover_y: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 347,
                    y: 131,
                    type: hmUI.data_type.BATTERY,
                    font_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: '19.png',
                    center_x: 369,
                    center_y: 147,
                    x: 10,
                    y: 57,
                    type: hmUI.data_type.BATTERY,
                    start_angle: -137,
                    end_angle: 135,
                    cover_x: 0,
                    cover_y: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 240,
                    center_y: 240,
                    radius: 221,
                    start_angle: 142,
                    end_angle: 217,
                    color: 4294810377,
                    line_width: 20,
                    type: hmUI.data_type.CAL,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 211,
                    y: 408,
                    type: hmUI.data_type.CAL,
                    font_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 221,
                    y: 442,
                    src: '21.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 240,
                    center_y: 240,
                    radius: 221,
                    start_angle: -38,
                    end_angle: 37,
                    color: 4278750952,
                    line_width: 20,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 204,
                    y: 50,
                    type: hmUI.data_type.STEP,
                    font_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 221,
                    y: 0,
                    src: '23.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                    x: 188,
                    y: 289,
                    anim_path: '',
                    anim_prefix: 'first_anim_fkjpr',
                    anim_ext: 'png',
                    anim_fps: 15,
                    anim_size: 38,
                    display_on_restart: false,
                    repeat_count: 0,
                    anim_status: hmUI.anim_status.START,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 50,
                    month_startY: 242,
                    month_en_array: [
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png'
                    ],
                    month_align: hmUI.align.LEFT,
                    month_zero: 0,
                    month_follow: 0,
                    month_space: 0,
                    month_is_character: true,
                    day_startX: 115,
                    day_startY: 218,
                    day_sc_array: [
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png'
                    ],
                    day_tc_array: [
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png'
                    ],
                    day_en_array: [
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png'
                    ],
                    day_align: hmUI.align.CENTER_H,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 0,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 50,
                    y: 219,
                    week_en: [
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png'
                    ],
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 195,
                    hour_startY: 220,
                    hour_array: [
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png',
                        '58.png',
                        '59.png',
                        '60.png',
                        '61.png',
                        '62.png',
                        '63.png'
                    ],
                    hour_space: 0,
                    hour_unit_sc: '64.png',
                    hour_unit_tc: '64.png',
                    hour_unit_en: '64.png',
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 322,
                    minute_startY: 220,
                    minute_array: [
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png',
                        '71.png',
                        '72.png',
                        '73.png',
                        '74.png'
                    ],
                    minute_space: 0,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 50,
                    month_startY: 242,
                    month_en_array: [
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png'
                    ],
                    month_align: hmUI.align.LEFT,
                    month_zero: 0,
                    month_follow: 0,
                    month_space: 0,
                    month_is_character: true,
                    day_startX: 115,
                    day_startY: 218,
                    day_sc_array: [
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png'
                    ],
                    day_tc_array: [
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png'
                    ],
                    day_en_array: [
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png'
                    ],
                    day_align: hmUI.align.CENTER_H,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 0,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 50,
                    y: 219,
                    week_en: [
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png'
                    ],
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 195,
                    hour_startY: 220,
                    hour_array: [
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png',
                        '58.png',
                        '59.png',
                        '60.png',
                        '61.png',
                        '62.png',
                        '63.png'
                    ],
                    hour_space: 0,
                    hour_unit_sc: '64.png',
                    hour_unit_tc: '64.png',
                    hour_unit_en: '64.png',
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 322,
                    minute_startY: 220,
                    minute_array: [
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png',
                        '71.png',
                        '72.png',
                        '73.png',
                        '74.png'
                    ],
                    minute_space: 0,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 72,
                    y: 115,
                    w: 75,
                    h: 75,
                    src: '15.png',
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 205,
                    y: 115,
                    w: 75,
                    h: 75,
                    src: '18.png',
                    type: hmUI.data_type.STAND,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 331,
                    y: 115,
                    w: 75,
                    h: 75,
                    src: '20.png',
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 200,
                    y: 404,
                    w: 80,
                    h: 70,
                    src: '22.png',
                    type: hmUI.data_type.CAL,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 202,
                    y: 53,
                    w: 80,
                    h: 40,
                    src: '24.png',
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
				
				hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 60,
              y: 220, 
              text: '',
              w: 100, 
              h: 50, 
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
               click_func: () => {
              hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
              },
               longpress_func: () => {
              hmApp.startApp({ url: 'todoListScreen', native: true });
              },
                show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 215,
              y: 215,
              w: 75,
              h: 60,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 334,
              y: 215,
              w: 75,
              h: 60,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 204,
              y: 309,
              w: 75,
              h: 75,
			  text: '',
			  normal_src: 'Empty.png',
			  press_src: 'Empty.png',
			  click_func: () => {
				hmApp.startApp({ appid: 1038314, url: 'page/gtr/home/index.page' });
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 70,
              y: 309, 
              text: '',
              w: 75, 
              h: 75, 
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
               click_func: () => {
              hmApp.startApp({ url: 'PhoneRecentCallScreen', native: true });
              },
               longpress_func: () => {
              hmApp.startApp({ url: 'PhoneContactsScreen', native: true });
              },
                show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 333,
              y: 309, 
              text: '',
              w: 75, 
              h: 75, 
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
               click_func: () => {
              hmApp.startApp({ url: 'Settings_homeScreen', native: true });
              },
               longpress_func: () => {
              hmApp.startApp({ url: 'ClubCardsScreen', native: true });
              },
                show_level: hmUI.show_level.ONLY_NORMAL,
            });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}