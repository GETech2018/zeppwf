export function onError(infoString) {
    // Not used in FOSS version.
    console.log(infoString);
}
