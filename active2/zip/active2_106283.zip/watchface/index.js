try {
  ; (() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp

    var __$$module$$__ = __$$app$$__.current
    var h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__),
      'drink'
    )

      /*
       * huamiOS bundle tool v1.0.17
       * Copyright © Huami. All Rights Reserved
       */
      ; ('use strict')

    console.log('----->>>current')
    console.log(__$$hmAppManager$$__.currentApp.pid)
    console.log(__$$hmAppManager$$__.currentApp.current)

    let bg_img = null
    let timeText = null
    let weekText = null
    let dayText = null
    let time_array = []
    let day_array = []
    let week_en_array = []
    let week_sc_array = []
    let week_tc_array = []
    let rootPath = 'images/'
    let bgPath = rootPath + 'bg/'
    let week_enPath = rootPath + 'week_en/'
    let week_scPath = rootPath + 'week_sc/'
    let week_tcPath = rootPath + 'week_tc/'
    let timePath = rootPath + 'time/'
    let amPath = rootPath + 'am/'
    let dayPath = rootPath + 'day/'
    let select_path = rootPath + 'select/'
    const logger = DeviceRuntimeCore.HmLogger.getLogger('defult')
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      // _animNext() {
      //     animResident.setProperty(hmUI.prop.ANIM_STATUS,1);
      //     animCreate.setProperty(hmUI.prop.VISIBLE,false);
      // },

      init_view() {




        for (let i = 0; i < 10; i++) {
          time_array.push(timePath + '0' + i + '.png')
          day_array.push(dayPath + '0' + i + '.png')
        }

        for (let k = 1; k < 8; k++) {
          week_en_array.push(week_enPath + '0' + k + '.png')
          week_sc_array.push(week_scPath + '0' + k + '.png')
          week_tc_array.push(week_tcPath + '0' + k + '.png')
        }

        editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
          edit_id: 103,
          x: 0,
          y: 0,
          bg_config: [
            { id: 1, preview: select_path + 'bg1.png', path: bgPath + 'bg1.png' },
            { id: 2, preview: select_path + 'bg2.png', path: bgPath + 'bg2.png' },
            { id: 3, preview: select_path + 'bg3.png', path: bgPath + 'bg3.png' },
          ],
          count: 3,
          default_id: 1,
          fg: rootPath + 'select/fg.png',
          tips_x: 187 * 0.987083,
          tips_y: 408 * 0.987083,
          tips_bg: rootPath + 'select/tips.png',
          tips_width: 106,
          tips_margin: 10,
          show_level: hmUI.show_level.ONLY_EDIT | hmUI.show_level.ONLY_NORMAL,
        })

        timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          hour_zero: 1, //是否补零
          hour_startX: 124 * 0.987083,
          hour_startY: 143 * 0.987083,
          hour_array: time_array,
          hour_space: 0,
          hour_unit_sc: timePath + '10.png',
          hour_unit_tc: timePath + '10.png',
          hour_unit_en: timePath + '10.png',
          hour_align: hmUI.align.LEFT,
          minute_zero: 1,
          minute_startX: 254 * 0.987083,
          minute_startY: 143 * 0.987083,
          minute_array: time_array,
          minute_space: 0,
          am_x: 297 * 0.987083,
          am_y: 95 * 0.987083,
          am_sc_path: amPath + 'am_sc.png',
          am_en_path: amPath + 'am.png',
          pm_x: 297 * 0.987083,
          pm_y: 95 * 0.987083,
          pm_sc_path: amPath + 'pm_sc.png',
          pm_en_path: amPath + 'pm.png',
          show_level: hmUI.show_level.ALL,
        })

        weekText = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
          x: 145 * 0.987083,
          y: 256 * 0.987083,
          week_en: week_en_array,
          week_tc: week_tc_array,
          week_sc: week_sc_array,
          show_level: hmUI.show_level.ALL,
        })

        datText = hmUI.createWidget(hmUI.widget.IMG_DATE, {
          month_startX: 197 * 0.987083,
          month_startY: 298 * 0.987083,
          month_unit_sc: dayPath + '10.png',
          month_unit_tc: dayPath + '10.png',
          month_unit_en: dayPath + '10.png',
          month_align: hmUI.align.LEFT,
          month_space: 0,
          month_zero: 1,
          month_en_array: day_array,
          month_sc_array: day_array,
          month_tc_array: day_array,
          day_startX: 247 * 0.987083,
          day_startY: 298 * 0.987083,
          day_align: hmUI.align.LEFT,
          day_space: 0,
          day_zero: 1,
          day_follow: 1,
          day_en_array: day_array,
          day_sc_array: day_array,
          day_tc_array: day_array,
          show_level: hmUI.show_level.ALL,
        })
      },

      onInit() {
        console.log('index page.js on init invoke')

        this.init_view()
      },

      onReady() {
        console.log('index page.js on ready invoke')
      },

      onShow() {
        console.log('index page.js on show invoke')
      },

      onHide() {
        console.log('index page.js on hide invoke')
      },

      onDestory() {
        console.log('index page.js on destory invoke')
      },
    })
    /*
     * end js
     */
  })()
} catch (e) {
  console.log(e)
}
