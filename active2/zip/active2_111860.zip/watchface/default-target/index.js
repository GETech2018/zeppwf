try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface6');

        let val, val2, week, day, hour, minute, second, rotH, angleH, angleM, day10v, day1v, batt, batt10;
        let bg, dialH, dialM, weekL, dayL1, dayL10, battG, timeSensor, battSensor;
        const center = 233;
        const hW = 466;
        const mW = 466;
        const xShift = 80;
        const startAng = -150;
        const wW = 80;
        const wH = 32;
        const dW = 22;
        const bW = 158;
        const iH = 32;

        function rotateDial(val) {
            const timeFormat = hmSetting.getTimeFormat();
            const screenType = hmSetting.getScreenType();
            const aod = screenType == hmSetting.screen_type.AOD;
            week = val.week;
            day = val.day;
            hour = val.hour;
            minute = val.minute;
            second = val.second;

            day10v = Math.floor(day / 10);
            day1v = day - day10v * 10;
            day10v = 'd' + day10v + '.png';
            day1v = 'd' + day1v + '.png';
            week = 'w' + week + '.png';

            if (timeFormat == 1) {
                if (hour > 11) {
                    bg.setProperty(hmUI.prop.SRC, { src: '6.png' });
                } else {
                    bg.setProperty(hmUI.prop.SRC, { src: '2.png' });
                }
            } else {
                bg.setProperty(hmUI.prop.SRC, { src: '2.png' });
            }

            if (hour > 11) { hour = hour - 12; }
            rotH = (hour + minute / 60) * 10;
            angleH = startAng + rotH;
            if (aod) {
                angleM = - (minute * 6 - rotH);
            } else {
                angleM = - ((minute + second / 60) * 6 - rotH);
            }

            dayL10.setProperty(hmUI.prop.SRC, `${ day10v }`);
            dayL1.setProperty(hmUI.prop.SRC, `${ day1v }`);
            weekL.setProperty(hmUI.prop.SRC, `${ week }`);
            dialH.setProperty(hmUI.prop.MORE, { angle: angleH });
            dialM.setProperty(hmUI.prop.MORE, { angle: angleM });
            dayL10.setProperty(hmUI.prop.MORE, { angle: - 60 + rotH });
            dayL1.setProperty(hmUI.prop.MORE, { angle: - 60 + rotH });
            weekL.setProperty(hmUI.prop.MORE, { angle: - 60 + rotH });
        }

        function setupBattery(val, val2) {
            batt = val.current;
            hour = val2.hour;
            minute = val2.minute;
            batt10 = Math.floor(batt / 10);
            if (batt10 < 2) { batt10 = 1; }
            if (hour > 11) { hour = hour - 12; }
            rotH = (hour + minute / 60) * 10;

            battG.setProperty(hmUI.prop.MORE, { angle: - 60 + rotH + (66 - batt10 * 12) });
            batt10 = 'b' + batt10 + '.png';
            battG.setProperty(hmUI.prop.SRC, `${ batt10 }`);
        }

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                if (!timeSensor) { timeSensor = hmSensor.createSensor(hmSensor.id.TIME); }
                if (!battSensor) { battSensor = hmSensor.createSensor(hmSensor.id.BATTERY); }

                bg = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 466,
                    h: 466,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                dialM = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: center * 2,
                    h: center * 2,
                    center_x: center + xShift,
                    center_y: center,
                    pos_x: center - mW / 2 + xShift,
                    pos_y: center - mW / 2,
                    angle: -150,
                    src: '4.png',
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: xShift,
                    y: 0,
                    w: center * 2,
                    h: center * 2,
                    src: '5.png',
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                battG = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: center * 2,
                    h: center * 2,
                    center_x: center + xShift,
                    center_y: center,
                    pos_x: center - bW / 2 + xShift,
                    pos_y: center - bW / 2,
                    angle: -60,
                    src: 'b1.png',
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                dialH = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: center * 2,
                    h: center * 2,
                    center_x: center + xShift,
                    center_y: center,
                    pos_x: center - hW / 2 + xShift,
                    pos_y: center - hW / 2,
                    angle: -150,
                    src: '3.png',
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                weekL = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: center * 2,
                    h: center * 2,
                    center_x: center + xShift,
                    center_y: center,
                    pos_x: center * 2 - (wW + 10),
                    pos_y: center - (wH + 8),
                    angle: -60,
                    src: 'w1.png',
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                dayL10 = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: center * 2,
                    h: center * 2,
                    center_x: center + xShift,
                    center_y: center,
                    pos_x: center * 2 - (wW + 10) + (wW / 2 - dW),
                    pos_y: center + 10,
                    angle: -60,
                    src: 'd0.png',
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                dayL1 = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: center * 2,
                    h: center * 2,
                    center_x: center + xShift,
                    center_y: center,
                    pos_x: center * 2 - (wW + 10) + wW / 2,
                    pos_y: center + 10,
                    angle: -60,
                    src: 'd0.png',
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 10,
                    y: center + 2,
                    src: '7.png',
                    type: hmUI.system_status.CLOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 10,
                    y: center - (iH + 2),
                    src: '8.png',
                    type: hmUI.system_status.DISCONNECT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });

                timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
                    rotateDial(timeSensor);
                    setupBattery(battSensor, timeSensor);
                });
                // battSensor.addEventListener(battSensor.event.CHANGE, function() {
                //     setupBattery(battSensor, timeSensor);
                // });
                timer.createTimer(0, 1000, function (timeSensor2) {
                    rotateDial(timeSensor2);
                    setupBattery(battSensor2, timeSensor2);
                }, timeSensor);
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function() {
                        rotateDial(timeSensor);
                        setupBattery(battSensor, timeSensor);
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
