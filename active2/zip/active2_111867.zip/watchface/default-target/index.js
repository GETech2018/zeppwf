try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$component_1$_$component = '';
        let normal$_$component_0$_$component = '';
        const logger = Logger.getLogger('watchface6');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
                    edit_id: 1,
                    x: 0,
                    y: 0,
                    bg_config: [
                        {
                            'id': 1,
                            'path': '6.png',
                            'preview': '7.png'
                        },
                        {
                            'id': 2,
                            'path': '8.png',
                            'preview': '9.png'
                        },
                        {
                            'id': 3,
                            'path': '10.png',
                            'preview': '11.png'
                        },
                        {
                            'id': 4,
                            'path': '12.png',
                            'preview': '13.png'
                        },
                        {
                            'id': 5,
                            'path': '14.png',
                            'preview': '15.png'
                        },
                        {
                            'id': 6,
                            'path': '16.png',
                            'preview': '17.png'
                        },
                        {
                            'id': 7,
                            'path': '18.png',
                            'preview': '19.png'
                        },
                        {
                            'id': 8,
                            'path': '20.png',
                            'preview': '21.png'
                        },
                        {
                            'id': 9,
                            'path': '22.png',
                            'preview': '23.png'
                        },
                        {
                            'id': 10,
                            'path': '24.png',
                            'preview': '25.png'
                        }
                    ],
                    count: 10,
                    default_id: 1,
                    fg: '5.png',
                    tips_x: 177,
                    tips_y: 425,
                    tips_bg: '4.png',
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 304,
                    y: 218,
                    src: '26.png',
                    type: hmUI.system_status.DISCONNECT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 335,
                    y: 180,
                    src: '27.png',
                    type: hmUI.system_status.DISTURB,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 277,
                    y: 218,
                    src: '28.png',
                    type: hmUI.system_status.LOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 335,
                    y: 258,
                    src: '29.png',
                    type: hmUI.system_status.CLOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    day_startX: 407,
                    day_startY: 220,
                    day_sc_array: [
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png'
                    ],
                    day_tc_array: [
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png'
                    ],
                    day_en_array: [
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png'
                    ],
                    day_align: hmUI.align.CENTER_H,
                    day_zero: 0,
                    day_follow: 0,
                    day_space: -6,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 341,
                    y: 218,
                    week_en: [
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png'
                    ],
                    week_tc: [
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png'
                    ],
                    week_sc: [
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png',
                        '58.png',
                        '59.png',
                        '60.png'
                    ],
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$component_1$_$component = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: 2,
                    x: 85,
                    y: 181,
                    w: 105,
                    h: 105,
                    select_image: '61.png',
                    un_select_image: '62.png',
                    default_type: hmUI.edit_type.HEART,
                    optional_types: [
                        {
                            'type': hmUI.edit_type.HEART,
                            'preview': '64.png'
                        },
                        {
                            'type': hmUI.edit_type.UVI,
                            'preview': '65.png'
                        },
                        {
                            'type': hmUI.edit_type.STEP,
                            'preview': '66.png'
                        },
                        {
                            'type': hmUI.edit_type.BATTERY,
                            'preview': '67.png'
                        },
                        {
                            'type': hmUI.edit_type.CAL,
                            'preview': '68.png'
                        },
                        {
                            'type': hmUI.edit_type.HUMIDITY,
                            'preview': '69.png'
                        },
                        {
                            'type': hmUI.edit_type.TEMPERATURE,
                            'preview': '70.png'
                        },
                        {
                            'type': hmUI.edit_type.WEATHER,
                            'preview': '71.png'
                        },
                        {
                            'type': hmUI.edit_type.DISTANCE,
                            'preview': '72.png'
                        },
                        {
                            'type': hmUI.edit_type.PAI_DAILY,
                            'preview': '73.png'
                        }
                    ],
                    count: 10,
                    tips_BG: '63.png',
                    tips_x: 0,
                    tips_y: -41,
                    tips_width: 101,
                    tips_margin: 12
                });
                editType = normal$_$component_1$_$component.getProperty(hmUI.prop.CURRENT_TYPE);
                switch (editType) {
                case hmUI.edit_type.STEP:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 99,
                        y: 244,
                        type: hmUI.data_type.STEP,
                        font_array: [
                            '74.png',
                            '75.png',
                            '76.png',
                            '77.png',
                            '78.png',
                            '79.png',
                            '80.png',
                            '81.png',
                            '82.png',
                            '83.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -2,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '84.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 116,
                        y: 193,
                        src: '85.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 86,
                        y: 183,
                        w: 103,
                        h: 103,
                        src: '86.png',
                        type: hmUI.data_type.STEP,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.BATTERY:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 105,
                        y: 244,
                        type: hmUI.data_type.BATTERY,
                        font_array: [
                            '87.png',
                            '88.png',
                            '89.png',
                            '90.png',
                            '91.png',
                            '92.png',
                            '93.png',
                            '94.png',
                            '95.png',
                            '96.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -2,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        unit_sc: '98.png',
                        unit_tc: '98.png',
                        unit_en: '98.png',
                        invalid_image: '97.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 116,
                        y: 193,
                        src: '99.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                        src: '103.png',
                        center_x: 138,
                        center_y: 233,
                        x: 9,
                        y: 43,
                        type: hmUI.data_type.BATTERY,
                        start_angle: -122,
                        end_angle: 122,
                        cover_x: 0,
                        cover_y: 0,
                        scale_x: 85,
                        scale_y: 182,
                        scale_sc: '100.png',
                        scale_tc: '101.png',
                        scale_en: '102.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 86,
                        y: 183,
                        w: 103,
                        h: 103,
                        src: '104.png',
                        type: hmUI.data_type.BATTERY,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.HEART:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 114,
                        y: 244,
                        type: hmUI.data_type.HEART,
                        font_array: [
                            '74.png',
                            '75.png',
                            '76.png',
                            '77.png',
                            '78.png',
                            '79.png',
                            '80.png',
                            '81.png',
                            '82.png',
                            '83.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -2,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '105.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 116,
                        y: 193,
                        src: '106.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                        src: '110.png',
                        center_x: 138,
                        center_y: 233,
                        x: 9,
                        y: 43,
                        type: hmUI.data_type.HEART,
                        start_angle: -122,
                        end_angle: 122,
                        cover_x: 0,
                        cover_y: 0,
                        scale_x: 85,
                        scale_y: 181,
                        scale_sc: '107.png',
                        scale_tc: '108.png',
                        scale_en: '109.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 86,
                        y: 183,
                        w: 103,
                        h: 103,
                        src: '111.png',
                        type: hmUI.data_type.HEART,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.CAL:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 107,
                        y: 244,
                        type: hmUI.data_type.CAL,
                        font_array: [
                            '74.png',
                            '75.png',
                            '76.png',
                            '77.png',
                            '78.png',
                            '79.png',
                            '80.png',
                            '81.png',
                            '82.png',
                            '83.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -2,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '112.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 116,
                        y: 193,
                        src: '113.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 86,
                        y: 183,
                        w: 103,
                        h: 103,
                        src: '114.png',
                        type: hmUI.data_type.CAL,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.PAI_DAILY:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 114,
                        y: 244,
                        type: hmUI.data_type.PAI_DAILY,
                        font_array: [
                            '74.png',
                            '75.png',
                            '76.png',
                            '77.png',
                            '78.png',
                            '79.png',
                            '80.png',
                            '81.png',
                            '82.png',
                            '83.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -2,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '115.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 116,
                        y: 193,
                        src: '116.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 86,
                        y: 183,
                        w: 103,
                        h: 103,
                        src: '117.png',
                        type: hmUI.data_type.PAI_DAILY,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.DISTANCE:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 90,
                        y: 244,
                        type: hmUI.data_type.DISTANCE,
                        font_array: [
                            '74.png',
                            '75.png',
                            '76.png',
                            '77.png',
                            '78.png',
                            '79.png',
                            '80.png',
                            '81.png',
                            '82.png',
                            '83.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -2,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        unit_sc: '120.png',
                        unit_tc: '120.png',
                        unit_en: '120.png',
                        dot_image: '119.png',
                        invalid_image: '118.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 116,
                        y: 193,
                        src: '121.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 86,
                        y: 183,
                        w: 103,
                        h: 103,
                        src: '122.png',
                        type: hmUI.data_type.DISTANCE,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.AQI:
                    break;
                case hmUI.edit_type.HUMIDITY:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 114,
                        y: 244,
                        type: hmUI.data_type.HUMIDITY,
                        font_array: [
                            '74.png',
                            '75.png',
                            '76.png',
                            '77.png',
                            '78.png',
                            '79.png',
                            '80.png',
                            '81.png',
                            '82.png',
                            '83.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -2,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '123.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 116,
                        y: 193,
                        src: '124.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 86,
                        y: 183,
                        w: 103,
                        h: 103,
                        src: '125.png',
                        type: hmUI.data_type.HUMIDITY,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.ALTIMETER:
                    break;
                case hmUI.edit_type.STRESS:
                    break;
                case hmUI.edit_type.WIND:
                    break;
                case hmUI.edit_type.SPO2:
                    break;
                case hmUI.edit_type.TRAINING_LOAD:
                    break;
                case hmUI.edit_type.VO2MAX:
                    break;
                case hmUI.edit_type.UVI:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 122,
                        y: 244,
                        type: hmUI.data_type.UVI,
                        font_array: [
                            '74.png',
                            '75.png',
                            '76.png',
                            '77.png',
                            '78.png',
                            '79.png',
                            '80.png',
                            '81.png',
                            '82.png',
                            '83.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -2,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '126.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 116,
                        y: 193,
                        src: '127.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 86,
                        y: 183,
                        w: 103,
                        h: 103,
                        src: '128.png',
                        type: hmUI.data_type.UVI,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.DATE:
                    break;
                case hmUI.edit_type.WEEK:
                    break;
                case hmUI.edit_type.WEATHER:
                    hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                        x: 112,
                        y: 209,
                        image_array: [
                            '129.png',
                            '130.png',
                            '131.png',
                            '132.png',
                            '133.png',
                            '134.png',
                            '135.png',
                            '136.png',
                            '137.png',
                            '138.png',
                            '139.png',
                            '140.png',
                            '141.png',
                            '142.png',
                            '143.png',
                            '144.png',
                            '145.png',
                            '146.png',
                            '147.png',
                            '148.png',
                            '149.png',
                            '150.png',
                            '151.png',
                            '152.png',
                            '153.png',
                            '154.png',
                            '155.png',
                            '156.png',
                            '157.png'
                        ],
                        image_length: 29,
                        type: hmUI.data_type.WEATHER_CURRENT,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.TEMPERATURE:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 114,
                        y: 244,
                        type: hmUI.data_type.WEATHER_CURRENT,
                        font_array: [
                            '74.png',
                            '75.png',
                            '76.png',
                            '77.png',
                            '78.png',
                            '79.png',
                            '80.png',
                            '81.png',
                            '82.png',
                            '83.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -2,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        unit_sc: '160.png',
                        unit_tc: '160.png',
                        unit_en: '160.png',
                        negative_image: '159.png',
                        invalid_image: '158.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 116,
                        y: 193,
                        src: '161.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 86,
                        y: 183,
                        w: 103,
                        h: 103,
                        src: '162.png',
                        type: hmUI.data_type.WEATHER_CURRENT,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.SUN:
                    break;
                }
                normal$_$component_0$_$component = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: 3,
                    x: 180,
                    y: 279,
                    w: 105,
                    h: 105,
                    select_image: '163.png',
                    un_select_image: '164.png',
                    default_type: hmUI.edit_type.BATTERY,
                    optional_types: [
                        {
                            'type': hmUI.edit_type.BATTERY,
                            'preview': '166.png'
                        },
                        {
                            'type': hmUI.edit_type.UVI,
                            'preview': '167.png'
                        },
                        {
                            'type': hmUI.edit_type.STEP,
                            'preview': '168.png'
                        },
                        {
                            'type': hmUI.edit_type.CAL,
                            'preview': '169.png'
                        },
                        {
                            'type': hmUI.edit_type.HUMIDITY,
                            'preview': '170.png'
                        },
                        {
                            'type': hmUI.edit_type.TEMPERATURE,
                            'preview': '171.png'
                        },
                        {
                            'type': hmUI.edit_type.WEATHER,
                            'preview': '172.png'
                        },
                        {
                            'type': hmUI.edit_type.DISTANCE,
                            'preview': '173.png'
                        },
                        {
                            'type': hmUI.edit_type.HEART,
                            'preview': '174.png'
                        },
                        {
                            'type': hmUI.edit_type.PAI_DAILY,
                            'preview': '175.png'
                        }
                    ],
                    count: 10,
                    tips_BG: '165.png',
                    tips_x: 0,
                    tips_y: -41,
                    tips_width: 101,
                    tips_margin: 12
                });
                editType = normal$_$component_0$_$component.getProperty(hmUI.prop.CURRENT_TYPE);
                switch (editType) {
                case hmUI.edit_type.STEP:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 193,
                        y: 339,
                        type: hmUI.data_type.STEP,
                        font_array: [
                            '74.png',
                            '75.png',
                            '76.png',
                            '77.png',
                            '78.png',
                            '79.png',
                            '80.png',
                            '81.png',
                            '82.png',
                            '83.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -2,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '176.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 211,
                        y: 290,
                        src: '177.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 180,
                        y: 280,
                        w: 103,
                        h: 103,
                        src: '178.png',
                        type: hmUI.data_type.STEP,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.BATTERY:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 201,
                        y: 339,
                        type: hmUI.data_type.BATTERY,
                        font_array: [
                            '179.png',
                            '180.png',
                            '181.png',
                            '182.png',
                            '183.png',
                            '184.png',
                            '185.png',
                            '186.png',
                            '187.png',
                            '188.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -2,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        unit_sc: '190.png',
                        unit_tc: '190.png',
                        unit_en: '190.png',
                        invalid_image: '189.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 211,
                        y: 290,
                        src: '191.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                        src: '195.png',
                        center_x: 233,
                        center_y: 329,
                        x: 9,
                        y: 43,
                        type: hmUI.data_type.BATTERY,
                        start_angle: -122,
                        end_angle: 122,
                        cover_x: 0,
                        cover_y: 0,
                        scale_x: 180,
                        scale_y: 279,
                        scale_sc: '192.png',
                        scale_tc: '193.png',
                        scale_en: '194.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 180,
                        y: 280,
                        w: 103,
                        h: 103,
                        src: '196.png',
                        type: hmUI.data_type.BATTERY,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.HEART:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 208,
                        y: 339,
                        type: hmUI.data_type.HEART,
                        font_array: [
                            '74.png',
                            '75.png',
                            '76.png',
                            '77.png',
                            '78.png',
                            '79.png',
                            '80.png',
                            '81.png',
                            '82.png',
                            '83.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -2,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '197.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 211,
                        y: 290,
                        src: '198.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                        src: '202.png',
                        center_x: 233,
                        center_y: 329,
                        x: 9,
                        y: 43,
                        type: hmUI.data_type.HEART,
                        start_angle: -122,
                        end_angle: 122,
                        cover_x: 0,
                        cover_y: 0,
                        scale_x: 180,
                        scale_y: 279,
                        scale_sc: '199.png',
                        scale_tc: '200.png',
                        scale_en: '201.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 180,
                        y: 280,
                        w: 103,
                        h: 103,
                        src: '203.png',
                        type: hmUI.data_type.HEART,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.CAL:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 201,
                        y: 339,
                        type: hmUI.data_type.CAL,
                        font_array: [
                            '74.png',
                            '75.png',
                            '76.png',
                            '77.png',
                            '78.png',
                            '79.png',
                            '80.png',
                            '81.png',
                            '82.png',
                            '83.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -2,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '204.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 211,
                        y: 290,
                        src: '205.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 180,
                        y: 280,
                        w: 103,
                        h: 103,
                        src: '206.png',
                        type: hmUI.data_type.CAL,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.PAI_DAILY:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 208,
                        y: 339,
                        type: hmUI.data_type.PAI_DAILY,
                        font_array: [
                            '74.png',
                            '75.png',
                            '76.png',
                            '77.png',
                            '78.png',
                            '79.png',
                            '80.png',
                            '81.png',
                            '82.png',
                            '83.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -2,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '207.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 211,
                        y: 290,
                        src: '208.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 180,
                        y: 280,
                        w: 103,
                        h: 103,
                        src: '209.png',
                        type: hmUI.data_type.PAI_DAILY,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.DISTANCE:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 185,
                        y: 339,
                        type: hmUI.data_type.DISTANCE,
                        font_array: [
                            '74.png',
                            '75.png',
                            '76.png',
                            '77.png',
                            '78.png',
                            '79.png',
                            '80.png',
                            '81.png',
                            '82.png',
                            '83.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -2,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        unit_sc: '212.png',
                        unit_tc: '212.png',
                        unit_en: '212.png',
                        dot_image: '211.png',
                        invalid_image: '210.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 211,
                        y: 290,
                        src: '213.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 180,
                        y: 280,
                        w: 103,
                        h: 103,
                        src: '214.png',
                        type: hmUI.data_type.DISTANCE,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.AQI:
                    break;
                case hmUI.edit_type.HUMIDITY:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 209,
                        y: 339,
                        type: hmUI.data_type.HUMIDITY,
                        font_array: [
                            '74.png',
                            '75.png',
                            '76.png',
                            '77.png',
                            '78.png',
                            '79.png',
                            '80.png',
                            '81.png',
                            '82.png',
                            '83.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -2,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '215.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 211,
                        y: 290,
                        src: '216.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 180,
                        y: 280,
                        w: 103,
                        h: 103,
                        src: '217.png',
                        type: hmUI.data_type.HUMIDITY,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.ALTIMETER:
                    break;
                case hmUI.edit_type.STRESS:
                    break;
                case hmUI.edit_type.WIND:
                    break;
                case hmUI.edit_type.SPO2:
                    break;
                case hmUI.edit_type.TRAINING_LOAD:
                    break;
                case hmUI.edit_type.VO2MAX:
                    break;
                case hmUI.edit_type.UVI:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 216,
                        y: 339,
                        type: hmUI.data_type.UVI,
                        font_array: [
                            '74.png',
                            '75.png',
                            '76.png',
                            '77.png',
                            '78.png',
                            '79.png',
                            '80.png',
                            '81.png',
                            '82.png',
                            '83.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -2,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '218.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 211,
                        y: 290,
                        src: '219.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 180,
                        y: 280,
                        w: 103,
                        h: 103,
                        src: '220.png',
                        type: hmUI.data_type.UVI,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.DATE:
                    break;
                case hmUI.edit_type.WEEK:
                    break;
                case hmUI.edit_type.WEATHER:
                    hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                        x: 208,
                        y: 307,
                        image_array: [
                            '221.png',
                            '222.png',
                            '223.png',
                            '224.png',
                            '225.png',
                            '226.png',
                            '227.png',
                            '228.png',
                            '229.png',
                            '230.png',
                            '231.png',
                            '232.png',
                            '233.png',
                            '234.png',
                            '235.png',
                            '236.png',
                            '237.png',
                            '238.png',
                            '239.png',
                            '240.png',
                            '241.png',
                            '242.png',
                            '243.png',
                            '244.png',
                            '245.png',
                            '246.png',
                            '247.png',
                            '248.png',
                            '249.png'
                        ],
                        image_length: 29,
                        type: hmUI.data_type.WEATHER_CURRENT,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.TEMPERATURE:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 208,
                        y: 339,
                        type: hmUI.data_type.WEATHER_CURRENT,
                        font_array: [
                            '74.png',
                            '75.png',
                            '76.png',
                            '77.png',
                            '78.png',
                            '79.png',
                            '80.png',
                            '81.png',
                            '82.png',
                            '83.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -2,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        unit_sc: '252.png',
                        unit_tc: '252.png',
                        unit_en: '252.png',
                        negative_image: '251.png',
                        invalid_image: '250.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 211,
                        y: 290,
                        src: '253.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 180,
                        y: 280,
                        w: 103,
                        h: 103,
                        src: '254.png',
                        type: hmUI.data_type.WEATHER_CURRENT,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.SUN:
                    break;
                }
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 232,
                    hour_centerY: 232,
                    hour_posX: 20,
                    hour_posY: 127,
                    hour_path: '255.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 232,
                    minute_centerY: 232,
                    minute_posX: 15,
                    minute_posY: 194,
                    minute_path: '256.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    second_centerX: 232,
                    second_centerY: 232,
                    second_posX: 14,
                    second_posY: 217,
                    second_path: '257.png',
                    second_cover_x: 0,
                    second_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
                    x: 0,
                    y: 0,
                    w: 466,
                    h: 466,
                    src: '258.png',
                    show_level: hmUI.show_level.ONLY_EDIT
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 466,
                    h: 466,
                    src: '259.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 232,
                    hour_centerY: 232,
                    hour_posX: 20,
                    hour_posY: 127,
                    hour_path: '260.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 232,
                    minute_centerY: 232,
                    minute_posX: 15,
                    minute_posY: 194,
                    minute_path: '261.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}