try {
    (() => {
        var n = __$$hmAppManager$$__.currentApp;
        const g = n.current,
            {
                px: p
            } = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(n, g)), n.app.__globals__),
            e = Logger.getLogger("watchface6");
        g.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 466,
                    h: 466,
                    src: "4.png",
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                let anim = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                    x: 0,
                    y: 253,
                    anim_path: "",
                    anim_prefix: "first_anim_qkkfy",
                    anim_ext: "png",
                    anim_fps: 15,
                    anim_size: 75,
                    repeat_count: 1,
                    anim_repeat: !1,
                    // display_on_restart: !0,
                    anim_status: hmUI.anim_status.START,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                let fail_anim = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                    x: 28,
                    y: 98,
                    anim_path: "",
                    anim_prefix: "second_anim_fyxyu",
                    anim_ext: "png",
                    anim_fps: 30,
                    anim_size: 120,
                    // display_on_restart: !1,
                    anim_repeat: true,
                    repeat_count: 0,
                    anim_status: hmUI.anim_status.START,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }); hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                    x: 78,
                    y: 105,
                    anim_path: "",
                    anim_prefix: "third_anim_ihnkj",
                    anim_ext: "png",
                    anim_fps: 30,
                    anim_size: 120,
                    display_on_restart: !1,
                    repeat_count: 0,
                    anim_repeat: true,
                    anim_status: hmUI.anim_status.START,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 82,
                    hour_startY: 99,
                    hour_array: ["5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png", "14.png"],
                    hour_space: 0,
                    hour_unit_sc: "15.png",
                    hour_unit_tc: "15.png",
                    hour_unit_en: "15.png",
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 249,
                    minute_startY: 99,
                    minute_array: ["5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png", "14.png"],
                    minute_space: 0,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    am_x: 218,
                    am_y: 196,
                    am_sc_path: "16.png",
                    am_en_path: "17.png",
                    pm_x: 218,
                    pm_y: 196,
                    pm_sc_path: "18.png",
                    pm_en_path: "19.png",
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 214,
                    y: 26,
                    type: hmUI.data_type.BATTERY,
                    font_array: ["20.png", "21.png", "22.png", "23.png", "24.png", "25.png", "26.png", "27.png", "28.png", "29.png"],
                    align_h: hmUI.align.LEFT,
                    h_space: -2,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: "31.png",
                    unit_tc: "31.png",
                    unit_en: "31.png",
                    invalid_image: "30.png",
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 84,
                    y: 196,
                    week_en: ["32.png", "33.png", "34.png", "35.png", "36.png", "37.png", "38.png"],
                    week_tc: ["39.png", "40.png", "41.png", "42.png", "43.png", "44.png", "45.png"],
                    week_sc: ["46.png", "47.png", "48.png", "49.png", "50.png", "51.png", "52.png"],
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 303,
                    month_startY: 198,
                    month_sc_array: ["20.png", "21.png", "22.png", "23.png", "24.png", "25.png", "26.png", "27.png", "28.png", "29.png"],
                    month_tc_array: ["20.png", "21.png", "22.png", "23.png", "24.png", "25.png", "26.png", "27.png", "28.png", "29.png"],
                    month_en_array: ["20.png", "21.png", "22.png", "23.png", "24.png", "25.png", "26.png", "27.png", "28.png", "29.png"],
                    month_unit_sc: "53.png",
                    month_unit_tc: "53.png",
                    month_unit_en: "53.png",
                    month_align: hmUI.align.LEFT,
                    month_zero: 1,
                    month_follow: 0,
                    month_space: 0,
                    month_is_character: !1,
                    day_sc_array: ["20.png", "21.png", "22.png", "23.png", "24.png", "25.png", "26.png", "27.png", "28.png", "29.png"],
                    day_tc_array: ["20.png", "21.png", "22.png", "23.png", "24.png", "25.png", "26.png", "27.png", "28.png", "29.png"],
                    day_en_array: ["20.png", "21.png", "22.png", "23.png", "24.png", "25.png", "26.png", "27.png", "28.png", "29.png"],
                    day_zero: 1,
                    day_follow: 1,
                    day_is_character: !1,
                    day_space: 0,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 0,
                    y: 419,
                    w: 466,
                    h: 26,
                    icon: "55.png",
                    icon_space: 10,//icon到文字的间隔
                    type: hmUI.data_type.STEP,
                    font_array: ["20.png", "21.png", "22.png", "23.png", "24.png", "25.png", "26.png", "27.png", "28.png", "29.png"],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: "20.png",
                    padding: !1,
                    isCharacter: !1
                }),
                // hmUI.createWidget(hmUI.widget.IMG, {
                //     x: 173,
                //     y: 419,
                //     src: "55.png",
                //     show_level: hmUI.show_level.ONLY_NORMAL
                // }),
                 hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 170,
                    y: 418,
                    w: 120,
                    h: 28,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 466,
                    h: 466,
                    src: "56.png",
                    show_level: hmUI.show_level.ONLY_AOD
                }), hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 82,
                    hour_startY: 99,
                    hour_array: ["5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png", "14.png"],
                    hour_space: 0,
                    hour_unit_sc: "15.png",
                    hour_unit_tc: "15.png",
                    hour_unit_en: "15.png",
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 249,
                    minute_startY: 99,
                    minute_array: ["5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png", "14.png"],
                    minute_space: 0,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    am_x: 218,
                    am_y: 196,
                    am_sc_path: "16.png",
                    am_en_path: "17.png",
                    pm_x: 218,
                    pm_y: 196,
                    pm_sc_path: "18.png",
                    pm_en_path: "19.png",
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_AOD
                }), hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 84,
                    y: 196,
                    week_en: ["32.png", "33.png", "34.png", "35.png", "36.png", "37.png", "38.png"],
                    week_tc: ["39.png", "40.png", "41.png", "42.png", "43.png", "44.png", "45.png"],
                    week_sc: ["46.png", "47.png", "48.png", "49.png", "50.png", "51.png", "52.png"],
                    show_level: hmUI.show_level.ONLY_AOD
                }), hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 303,
                    month_startY: 198,
                    month_sc_array: ["20.png", "21.png", "22.png", "23.png", "24.png", "25.png", "26.png", "27.png", "28.png", "29.png"],
                    month_tc_array: ["20.png", "21.png", "22.png", "23.png", "24.png", "25.png", "26.png", "27.png", "28.png", "29.png"],
                    month_en_array: ["20.png", "21.png", "22.png", "23.png", "24.png", "25.png", "26.png", "27.png", "28.png", "29.png"],
                    month_unit_sc: "53.png",
                    month_unit_tc: "53.png",
                    month_unit_en: "53.png",
                    month_align: hmUI.align.LEFT,
                    month_zero: 1,
                    month_follow: 0,
                    month_space: 0,
                    month_is_character: !1,
                    day_sc_array: ["20.png", "21.png", "22.png", "23.png", "24.png", "25.png", "26.png", "27.png", "28.png", "29.png"],
                    day_tc_array: ["20.png", "21.png", "22.png", "23.png", "24.png", "25.png", "26.png", "27.png", "28.png", "29.png"],
                    day_en_array: ["20.png", "21.png", "22.png", "23.png", "24.png", "25.png", "26.png", "27.png", "28.png", "29.png"],
                    day_zero: 1,
                    day_follow: 1,
                    day_space: 0,
                    day_is_character: !1,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_AOD
                })
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        console.log('ui resume');
                        //   anim.setProperty(
                        //     hmUI.prop.ANIM_STATUS,
                        //     hmUI.anim_status.STOP
                        //   );
                        anim.setProperty(
                            hmUI.prop.ANIM_STATUS,
                            hmUI.anim_status.START
                        );
                        fail_anim.setProperty(
                            hmUI.prop.ANIM_STATUS,
                            hmUI.anim_status.START
                        );
                    },
                    pause_call: function () {
                        console.log('ui pause');
                    },
                });
            },
            onInit() {
                e.log("index page.js on init invoke")
            },
            build() {
                this.init_view(), e.log("index page.js on ready invoke")
            },
            onDestory() {
                e.log("index page.js on destory invoke")
            }
        })
    })()
} catch (n) {
    console.log(n)
}