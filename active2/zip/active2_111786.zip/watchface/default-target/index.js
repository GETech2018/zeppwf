try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface6');

        let val, hour, minute, hHand, mHand, hAngle, mAngle, bg, timeSensor;
        const startAng = 240;
        const angRange = 240;
        const center = 233;
        const posX = 213;
        const posY = 0;

        function computeAng(val) {
            const timeFormat = hmSetting.getTimeFormat();
            if (val == 2) {
                hour = timeSensor2.hour;
                minute = timeSensor2.minute;
            } else {
                hour = timeSensor.hour;
                minute = timeSensor.minute;
            }

            if (hour > 11) {
                if (timeFormat == 1) {
                    bg.setProperty(hmUI.prop.MORE, {src: '26.png'});
                } else {
                    bg.setProperty(hmUI.prop.MORE, {src: '2.png'});
                }
                hAngle = startAng + ((hour - 12) + minute / 60) / 12 * angRange;
            } else {
                bg.setProperty(hmUI.prop.MORE, {src: '2.png'});
                hAngle = startAng + (hour + minute / 60) / 12 * angRange;
            }
            mAngle = startAng + minute / 60 * angRange;

            hHand.setProperty(hmUI.prop.MORE, {angle: hAngle});
            mHand.setProperty(hmUI.prop.MORE, {angle: mAngle});
        }

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                if (!timeSensor) { timeSensor = hmSensor.createSensor(hmSensor.id.TIME); }

                bg = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: center * 2,
                    h: center * 2,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });

                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 217,
                    y: 424,
                    src: '23.png',
                    type: hmUI.system_status.DISCONNECT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 253,
                    y: 424,
                    src: '24.png',
                    type: hmUI.system_status.LOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 181,
                    y: 424,
                    src: '25.png',
                    type: hmUI.system_status.CLOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: '3.png',
                    center_x: 233,
                    center_y: 233,
                    x: 20,
                    y: 233,
                    type: hmUI.data_type.BATTERY,
                    start_angle: 130,
                    end_angle: 230,
                    cover_x: 0,
                    cover_y: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 298,
                    y: 205,
                    week_en: [
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png'
                    ],
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    day_startX: 307,
                    day_startY: 237,
                    day_sc_array: [
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png'
                    ],
                    day_tc_array: [
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png'
                    ],
                    day_en_array: [
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png'
                    ],
                    day_align: hmUI.align.LEFT,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 0,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });

                hHand = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: center * 2,
                    h: center * 2,
                    pos_x: posX,
                    pos_y: posY,
                    angle: startAng,
                    center_x: center,
                    center_y: center,
                    src: '21.png',
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });

                mHand = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: center * 2,
                    h: center * 2,
                    pos_x: posX,
                    pos_y: posY,
                    angle: startAng,
                    center_x: center,
                    center_y: center,
                    src: '22.png',
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });

                timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
                    computeAng(1);
                });

                timer.createTimer(0, 60000, function (timeSensor2) {
                    computeAng(2);
                }, timeSensor);

                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function() {
                        computeAng(1);
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                timer.stopTimer(timeSensor);
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
