try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_27e7f463201c414d9125d41b5a22e16b = '';
        let dateFormat = '';
        let dateFormatMap = '';
        let normal$_$text_bfaaf230ca814304a6c5947cee0fa7ca = '';
        let normal$_$text_9eb9e633595e4f17ac4b9062c3822742 = '';
        let normal$_$text_451f51dc43a2459bb5e8c3d81b863ba5 = '';
        let normal$_$text_43da6531f4934e64a8fadd09933e1e9c = '';
        let normal$_$text_d680ee60346a4e93912bdafba9198e36 = '';
        let timeSensor = '';
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 71,
                    y: 275,
                    type: hmUI.data_type.PAI_DAILY,
                    font_array: [
                        '2.png',
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: false,
                    isCharacter: false
                });
                normal$_$text_27e7f463201c414d9125d41b5a22e16b = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 244,
                    y: 104,
                    w: 60,
                    h: 44,
                    text: '[MON_Z]',
                    color: '0xFFffffff',
                    text_size: 36,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 0,
                    hour_startX: 261,
                    hour_startY: 206,
                    hour_array: [
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png'
                    ],
                    hour_space: 0,
                    hour_unit_sc: '22.png',
                    hour_unit_tc: '22.png',
                    hour_unit_en: '22.png',
                    hour_align: hmUI.align.RIGHT,
                    minute_zero: 1,
                    minute_startX: 382,
                    minute_startY: 206,
                    minute_array: [
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png'
                    ],
                    minute_space: 0,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    second_val: new Date().getSeconds(),
                    second_zero: 1,
                    second_startX: 214,
                    second_startY: 223,
                    second_array: [
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png'
                    ],
                    second_space: 0,
                    second_align: hmUI.align.CENTER_H,
                    second_follow: 0,
                    am_x: 338,
                    am_y: 266,
                    am_en_path: '33.png',
                    pm_x: 338,
                    pm_y: 266,
                    pm_en_path: '34.png',
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_bfaaf230ca814304a6c5947cee0fa7ca = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 156,
                    y: 104,
                    w: 60,
                    h: 44,
                    text: '[DAY]',
                    color: '0xFFffffff',
                    text_size: 36,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.RIGHT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_9eb9e633595e4f17ac4b9062c3822742 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 129,
                    y: 276,
                    w: 60,
                    h: 20,
                    text: 'DAY',
                    color: '0xFF727272',
                    text_size: 18,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 43,
                    y: 277,
                    src: '35.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_451f51dc43a2459bb5e8c3d81b863ba5 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 219,
                    y: 104,
                    w: 20,
                    h: 44,
                    text: '/',
                    color: '0xFFffffff',
                    text_size: 34,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_43da6531f4934e64a8fadd09933e1e9c = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 188,
                    y: 57,
                    w: 90,
                    h: 42,
                    text: '[WEEK_EN_S]',
                    color: '0xFFffffff',
                    text_size: 38,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 71,
                    y: 219,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: [
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '48.png',
                    unit_tc: '48.png',
                    unit_en: '48.png',
                    negative_image: '47.png',
                    invalid_image: '46.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 219,
                    y: 409,
                    type: hmUI.data_type.BATTERY,
                    font_array: [
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png',
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png',
                        '58.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '59.png',
                    unit_tc: '59.png',
                    unit_en: '59.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 37,
                    y: 210,
                    image_array: [
                        '60.png',
                        '61.png',
                        '62.png',
                        '63.png',
                        '64.png',
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png',
                        '71.png',
                        '72.png',
                        '73.png',
                        '74.png',
                        '75.png',
                        '76.png',
                        '77.png',
                        '78.png',
                        '79.png',
                        '80.png',
                        '81.png',
                        '82.png',
                        '83.png',
                        '84.png',
                        '85.png',
                        '86.png',
                        '87.png',
                        '88.png'
                    ],
                    image_length: 29,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_d680ee60346a4e93912bdafba9198e36 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 129,
                    y: 312,
                    w: 60,
                    h: 20,
                    text: 'WEEK',
                    color: '0xFF727272',
                    text_size: 17,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.BOTTOM,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 181,
                    y: 401,
                    src: '89.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 71,
                    y: 305,
                    type: hmUI.data_type.PAI_WEEKLY,
                    font_array: [
                        '2.png',
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 0,
                    hour_startX: 261,
                    hour_startY: 206,
                    hour_array: [
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png'
                    ],
                    hour_space: 0,
                    hour_unit_sc: '22.png',
                    hour_unit_tc: '22.png',
                    hour_unit_en: '22.png',
                    hour_align: hmUI.align.RIGHT,
                    minute_zero: 1,
                    minute_startX: 382,
                    minute_startY: 206,
                    minute_array: [
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png'
                    ],
                    minute_space: 0,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    am_x: 338,
                    am_y: 266,
                    am_en_path: '33.png',
                    pm_x: 338,
                    pm_y: 266,
                    pm_en_path: '34.png',
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 71,
                    y: 219,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: [
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_AOD,
                    unit_sc: '48.png',
                    unit_tc: '48.png',
                    unit_en: '48.png',
                    negative_image: '47.png',
                    invalid_image: '46.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 37,
                    y: 210,
                    image_array: [
                        '60.png',
                        '61.png',
                        '62.png',
                        '63.png',
                        '64.png',
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png',
                        '71.png',
                        '72.png',
                        '73.png',
                        '74.png',
                        '75.png',
                        '76.png',
                        '77.png',
                        '78.png',
                        '79.png',
                        '80.png',
                        '81.png',
                        '82.png',
                        '83.png',
                        '84.png',
                        '85.png',
                        '86.png',
                        '87.png',
                        '88.png'
                    ],
                    image_length: 29,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                if (!timeSensor) {
                    timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                }
                timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_27e7f463201c414d9125d41b5a22e16b.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }` });
                        },
                        () => {
                            normal$_$text_27e7f463201c414d9125d41b5a22e16b.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }` });
                        },
                        () => {
                            normal$_$text_27e7f463201c414d9125d41b5a22e16b.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_bfaaf230ca814304a6c5947cee0fa7ca.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                        },
                        () => {
                            normal$_$text_bfaaf230ca814304a6c5947cee0fa7ca.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                        },
                        () => {
                            normal$_$text_bfaaf230ca814304a6c5947cee0fa7ca.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                    const WEEK_EN_S = function (val) {
                        const valueMap = {
                            '1': 'Mon',
                            '2': 'Tue',
                            '3': 'Wed',
                            '4': 'Thu',
                            '5': 'Fri',
                            '6': 'Sat',
                            '7': 'Sun'
                        };
                        return valueMap[val];
                    };
                    normal$_$text_43da6531f4934e64a8fadd09933e1e9c.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_S(timeSensor.week) }` });
                });
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                normal$_$text_27e7f463201c414d9125d41b5a22e16b.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }` });
                            },
                            () => {
                                normal$_$text_27e7f463201c414d9125d41b5a22e16b.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }` });
                            },
                            () => {
                                normal$_$text_27e7f463201c414d9125d41b5a22e16b.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                normal$_$text_bfaaf230ca814304a6c5947cee0fa7ca.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                            },
                            () => {
                                normal$_$text_bfaaf230ca814304a6c5947cee0fa7ca.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                            },
                            () => {
                                normal$_$text_bfaaf230ca814304a6c5947cee0fa7ca.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                        normal$_$text_9eb9e633595e4f17ac4b9062c3822742.setProperty(hmUI.prop.MORE, { text: `DAY` });
                        normal$_$text_451f51dc43a2459bb5e8c3d81b863ba5.setProperty(hmUI.prop.MORE, { text: `/` });
                        const WEEK_EN_S = function (val) {
                            const valueMap = {
                                '1': 'Mon',
                                '2': 'Tue',
                                '3': 'Wed',
                                '4': 'Thu',
                                '5': 'Fri',
                                '6': 'Sat',
                                '7': 'Sun'
                            };
                            return valueMap[val];
                        };
                        normal$_$text_43da6531f4934e64a8fadd09933e1e9c.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_S(timeSensor.week) }` });
                        normal$_$text_d680ee60346a4e93912bdafba9198e36.setProperty(hmUI.prop.MORE, { text: `WEEK` });
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}