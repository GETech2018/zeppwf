try {
    (() => {
        var n = __$$hmAppManager$$__.currentApp;
        const e = n.current,
            {
                px: g
            } = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(n, e)), n.app.__globals__),
            p = Logger.getLogger("watchface6");
        e.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                let anim = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                    x: 0,
                    y: 0,
                    anim_path: "",
                    anim_prefix: "first_anim_fcqfz",
                    anim_ext: "png",
                    anim_fps: 15,
                    anim_size: 84,
                    repeat_count: 1,
                    anim_repeat: !1,
                    // display_on_restart: !0,
                    anim_status: hmUI.anim_status.START,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }); hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 86,
                    hour_startY: 169,
                    hour_array: ["4.png", "5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png"],
                    hour_space: -2,
                    hour_unit_sc: "14.png",
                    hour_unit_tc: "14.png",
                    hour_unit_en: "14.png",
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 242,
                    minute_startY: 169,
                    minute_array: ["4.png", "5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png"],
                    minute_space: -1,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    am_x: 206,
                    am_y: 97,
                    am_sc_path: "15.png",
                    am_en_path: "16.png",
                    pm_x: 206,
                    pm_y: 97,
                    pm_sc_path: "17.png",
                    pm_en_path: "18.png",
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 194,
                    y: 131,
                    week_en: ["19.png", "20.png", "21.png", "22.png", "23.png", "24.png", "25.png"],
                    week_tc: ["26.png", "27.png", "28.png", "29.png", "30.png", "31.png", "32.png"],
                    week_sc: ["33.png", "34.png", "35.png", "36.png", "37.png", "38.png", "39.png"],
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 209,
                    y: 274,
                    type: hmUI.data_type.BATTERY,
                    font_array: ["40.png", "41.png", "42.png", "43.png", "44.png", "45.png", "46.png", "47.png", "48.png", "49.png"],
                    align_h: hmUI.align.LEFT,
                    h_space: -3,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: "50.png",
                    unit_tc: "50.png",
                    unit_en: "50.png",
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.IMG, {
                    x: 179,
                    y: 278,
                    src: "51.png",
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG, {
                    x: 135,
                    y: 312,
                    src: "52.png",
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 183,
                    y: 320,
                    w: 136,
                    type: hmUI.data_type.STEP,
                    font_array: ["53.png", "54.png", "55.png", "56.png", "57.png", "58.png", "59.png", "60.png", "61.png", "62.png"],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -3,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: "53.png",
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.IMG, {
                    x: 140,
                    y: 322,
                    src: "64.png",
                    show_level: hmUI.show_level.ONLY_NORMAL
                }),
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 140,
                        y: 317,
                        w: 160,
                        h: 38,
                        type: hmUI.data_type.STEP,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    }), hmUI.createWidget(hmUI.widget.IMG, {
                        x: 0,
                        y: 0,
                        w: 466,
                        h: 466,
                        src: "65.png",
                        show_level: hmUI.show_level.ONLY_AOD
                    }), hmUI.createWidget(hmUI.widget.IMG_TIME, {
                        hour_zero: 1,
                        hour_startX: 86,
                        hour_startY: 169,
                        hour_array: ["4.png", "5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png"],
                        hour_space: -2,
                        hour_unit_sc: "14.png",
                        hour_unit_tc: "14.png",
                        hour_unit_en: "14.png",
                        hour_align: hmUI.align.LEFT,
                        minute_zero: 1,
                        minute_startX: 242,
                        minute_startY: 169,
                        minute_array: ["4.png", "5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png"],
                        minute_space: 0,
                        minute_align: hmUI.align.LEFT,
                        minute_follow: 0,
                        enable: !1,
                        show_level: hmUI.show_level.ONLY_AOD
                    })
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        console.log('ui resume');
                        //   anim.setProperty(
                        //     hmUI.prop.ANIM_STATUS,
                        //     hmUI.anim_status.STOP
                        //   );
                        anim.setProperty(
                            hmUI.prop.ANIM_STATUS,
                            hmUI.anim_status.START
                        );
                    },
                    pause_call: function () {
                        console.log('ui pause');
                    },
                });
            },
            onInit() {
                p.log("index page.js on init invoke")
            },
            build() {
                this.init_view(), p.log("index page.js on ready invoke")
            },
            onDestory() {
                p.log("index page.js on destory invoke")
            }
        })
    })()
} catch (n) {
    console.log(n)
}