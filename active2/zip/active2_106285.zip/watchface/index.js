/*
 * =====================================================================================
 *
 *  Copyright (C) 2021. Huami Ltd, unpublished work. This computer program includes
 *  Confidential, Proprietary Information and is a Trade Secret of Huami Ltd.
 *  All use, disclosure, and/or reproduction is prohibited unless authorized in writing.
 *  All Rights Reserved.
 *
 *  Author: Huami
 *
 * =====================================================================================
 */
try {
  (() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');
    /*
     * huamiOS bundle tool v1.0.17
     * Copyright © Huami. All Rights Reserved
     */
    'use strict';
    //===============变量声明====================
    const arrTimeText = []
    const arrFont = []
    let jumpApplication
    for (let i = 0; i < 10; i++) {
      arrTimeText.push("images/time/time_" + i + ".png")
      arrFont.push("images//step/step_num_" + i + ".png")
    }
    //================定义类==========================
    //定义动画类
    class Animal {
      constructor() {
        this.widget = hmUI.createWidget(hmUI.widget.IMG_ANIM)
        this.defaultObj = null
      }
      create(option) {
        this.defaultObj = option
        this.widget.setProperty(hmUI.prop.MORE, option)
      }
    }
    //定义时间类
    class Time {
      constructor() {

      }
      //时间图片文本
      createImgTextTime(option) {
        this.widget = hmUI.createWidget(hmUI.widget.IMG_TIME, option)
      }
      //时间指针
      createPointerTime(option) {
        this.widget = hmUI.createWidget(hmUI.widget.TIME_POINTER, option)
      }
      //图片星期文本
      createImgWeek(option) {
        this.widget = hmUI.createWidget(hmUI.widget.IMG_WEEK, option)
      }
      //图片日期文本
      createImgDate(option) {
        this.widget = hmUI.createWidget(hmUI.widget.IMG_DATE, option)
      }
    }
    //定义可编辑组件类
    class Group {
      constructor(option) {
        this.option = option
        this.group = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, option)
      }
      //获取该类型单位符号
      isUnit(type) {
        for (let i = 0, len = this.option.optional_types.length; i < len; i++) {
          if (this.option.optional_types[i].type == type) {
            return this.option.optional_types[i].unit
          }
        }
      }
      //获取该类型对应的icon路径
      getIconSrc(type) {
        for (let i = 0, len = this.option.optional_types.length; i < len; i++) {
          if (this.option.optional_types[i].type == type) {
            return this.option.optional_types[i].icon
          }
        }
      }
      //获取该类型对应的dot image 路径
      getDotSrc(type) {
        for (let i = 0, arrLen = this.option.optional_types.length; i < arrLen; i++) {
          if (this.option.optional_types[i].type == type) {
            return this.option.optional_types[i].dotImg
          }
        }
      }
      getEdit() {
        let editType = this.group.getProperty(hmUI.prop.CURRENT_TYPE);
        switch (editType) {
          case hmUI.edit_type.HEART:
            this.type = hmUI.data_type.HEART
            break;
          case hmUI.edit_type.BATTERY:
            this.type = hmUI.data_type.BATTERY
            break;
          case hmUI.edit_type.STEP:
            this.type = hmUI.data_type.STEP
            break;
          case hmUI.edit_type.CAL:
            this.type = hmUI.data_type.CAL
            break;
          case hmUI.edit_type.SPO2:
            this.type = hmUI.data_type.SPO2
            break;
          case hmUI.edit_type.SLEEP:
            this.type = hmUI.data_type.SLEEP
            break;
        }
        this.unit = this.isUnit(editType)
        this.iconSrc = this.getIconSrc(editType)
        this.dotImg = this.getDotSrc(editType)
      }
      filter(option, obj) {
        for (let key in option) {
          if (key in obj) {
            obj[key] = option[key]
          }
        }
        for (let key in obj) {
          if (!obj[key]) {
            delete obj[key]
          }
        }
      }
      text(option) {
        this.createText()
        this.filter(option, this.objText)
        this.textWidget = hmUI.createWidget(hmUI.widget.TEXT_IMG, this.objText)
      }
      createText() {
        this.objText = {
          x: "",
          y: "",
          w: "",
          h: "",
          icon: this.iconSrc,
          icon_space: 5,
          type: this.type,
          font_array: "",
          h_space: "",
          align_h: hmUI.align.CENTER_H,
          unit_sc: this.unit,
          unit_tc: this.unit,
          unit_en: this.unit,
          imperial_unit_sc: "",
          imperial_unit_tc: "",
          imperial_unit_en: "",
          negative_image: "",
          dot_image: this.dotImg,
          invalid_image: "",
          padding: false,
        }
      }
    }
    //定义遮罩
    class Mask {
      constructor(option) {
        this.widget = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK, option)
      }
    }
    //==============参数对象=======================
    let objTimeText = {
      hour_startX: 112 * 0.9708,
      hour_startY: 123 * 0.9708,
      hour_array: arrTimeText,
      hour_space: -40,
      minute_startX: 158 * 0.9708,
      minute_startY: 218 * 0.9708,
      minute_array: arrTimeText,
      minute_space: -40,
      am_x: 266 * 0.9708,
      am_y: 191 * 0.9708,
      pm_x: 266 * 0.9708,
      pm_y: 191 * 0.9708,
      am_sc_path: "images/ampm/am_cn.png",
      am_en_path: "images/ampm/am_en.png",
      pm_sc_path: "images/ampm/pm_cn.png",
      pm_en_path: "images/ampm/pm_en.png",
    }
    const arrOptionTypes = [{
        type: hmUI.edit_type.HEART,
        preview: "images/preview/heart.png",
        icon: "images/icon/heart.png"
      },
      {
        type: hmUI.edit_type.BATTERY,
        preview: "images/preview/battery.png",
        icon: "images/icon/battery.png",
        unit: "images/step/baifen.png"
      },
      {
        type: hmUI.edit_type.STEP,
        preview: "images/preview/step.png",
        icon: "images/icon/step.png"
      },
      {
        type: hmUI.edit_type.CAL,
        preview: "images/preview/cal.png",
        icon: "images/icon/cal.png"
      },
      {
        type: hmUI.edit_type.SPO2,
        preview: "images/preview/spo.png",
        icon: "images/icon/spo.png",
        unit: "images/step/baifen.png"
      },
      {
        type: hmUI.edit_type.SLEEP,
        preview: "images/preview/sleep.png",
        icon: "images/icon/sleep.png",
        unit: "images/step/h.png",
        dotImg: "images/step/dot.png"
      },
    ]
    let edit_list_config = {
      title_font_size: 34,
      title_align_h: hmUI.align.CENTER_H,
      list_item_vspace: 8,
      list_bg_color: 0x0000,
      list_bg_radius: 30,
      list_group_text_font_size: 32,
      list_group_text_align_h: hmUI.align.CENTER_H,
      list_tips_text_font_size: 32,
      list_tips_text_align_h: hmUI.align.LEFT,
    };
    let objGroup = {
      edit_id: 101,
      x: 145 * 0.9708,
      y: 392 * 0.9708,
      w: 190,
      h: 64,
      select_image: "images/mask/select.png",
      un_select_image: "images/mask/select.png",
      default_type: hmUI.edit_type.HEART,
      optional_types: arrOptionTypes,
      count: 6,
      tips_BG: "images/mask/tips.png",
      tips_x: 39 * 0.9708,
      tips_y: -40 * 0.9708,
      tips_width: 112,
      tips_margin: 10,
      select_list: edit_list_config, // 新增配置选项
    }
    let objBottomText = {
      x: 150 * 0.9708,
      y: 409 * 0.9708,
      w: 160,
      font_array: arrFont,
      invalid_image: "images/step/null.png"
    }
    const objMask100 = {
      x: 0,
      y: 0,
      w: 480,
      h: 480,
      src: "images/mask/mask100.png",
      show_level: hmUI.show_level.ONLY_EDIT,
    }
    const logger = DeviceRuntimeCore.HmLogger.getLogger("default2");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({

      init_view() {
        const animal = new Animal()
        const animal2 = new Animal()
        animal.create({
          x: 0,
          y: 0,
          anim_path: "images/anim",
          anim_prefix: "anim",
          anim_ext: "png",
          anim_fps: 23,
          anim_size: 69,
          anim_repeat: false,
          repeat_count: 1,
          anim_status: 1,
          anim_complete_call: function () {
            animal2.create({
              x: 0,
              y: 0,
              anim_path: "images/anim_1",
              anim_prefix: "anim",
              anim_ext: "png",
              anim_fps: 23,
              anim_size: 45,
              anim_repeat: true,
              repeat_count: 1,
              anim_status: 1,
              show_level: hmUI.show_level.ONLY_NORMAL,
            })
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        })
        const timeText = new Time()
        timeText.createImgTextTime(objTimeText)
        const bottomGroup = new Group(objGroup)
        bottomGroup.getEdit()
        bottomGroup.text(objBottomText)
        const objMask70 = JSON.parse(JSON.stringify(objMask100))
        objMask70.src = "images/mask/mask.png"
        const mask100 = new Mask(objMask100)
        const mask70 = new Mask(objMask70)

        let editType = bottomGroup.group.getProperty(hmUI.prop.CURRENT_TYPE); //获取当前可编辑组件的类型
        switch (editType) { //匹配类型修改jumpApplication的参数
          case hmUI.edit_type.HEART:
            jumpApplication = hmUI.data_type.HEART
            break;
          case hmUI.edit_type.BATTERY:
            jumpApplication = hmUI.data_type.BATTERY
            break;
          case hmUI.edit_type.STEP:
            jumpApplication = hmUI.data_type.STEP
            break;
          case hmUI.edit_type.CAL:
            jumpApplication = hmUI.data_type.CAL
            break;
          case hmUI.edit_type.SPO2:
            jumpApplication = hmUI.data_type.SPO2
            break;
          case hmUI.edit_type.SLEEP:
            jumpApplication = hmUI.data_type.SLEEP
            break;
        }
        let bottomClick = hmUI.createWidget(hmUI.widget.IMG_CLICK, { //使用IMGCLICK控件传入组件对应类型
          x: 153,
          y: 389,
          w: 159,
          h: 45,
          type: jumpApplication,
        })



      },
      onInit() {
        this.init_view();
      },
      onReady() {
        console.log('index page.js on ready invoke')
      },
      onShow() {
        console.log('index page.js on show invoke')
      },
      onHide() {
        console.log('index page.js on hide invoke')
      },
      onDestory() {
        console.log('index page.js on destory invoke')
      },
    });
    /*
     * end js
     */
  })()
} catch (e) {}