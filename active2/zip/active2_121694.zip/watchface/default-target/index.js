try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_2ff3cf39f4d74ff9a25a4cd6ffd364b6 = '';
        let dateFormat = '';
        let dateFormatMap = '';
        let normal$_$text_a5ca3be077e5494a86345f0cf149a8ac = '';
        let normal$_$text_2bd21436e45143a6b39031572582e58d = '';
        let normal$_$text_f2dc252f255e4996beb46610fd600fe3 = '';
        let normal$_$text_187f8be8f4ee4540bce901fcf52cfc66 = '';
        let normal$_$text_84dfb0d2b27c46108a174c3c2449bba8 = '';
        let timeSensor = '';
        let stepSensor = '';
        let heartSensor = '';
        const logger = Logger.getLogger('watchface6');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 466,
                    h: 466,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    second_centerX: 233,
                    second_centerY: 233,
                    second_posX: 233,
                    second_posY: 233,
                    second_path: '3.png',
                    second_cover_x: 0,
                    second_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 466,
                    h: 466,
                    src: '4.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_val: new Date().getHours(),
                    hour_zero: 1,
                    hour_startX: 100,
                    hour_startY: 40,
                    hour_array: [
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png'
                    ],
                    hour_space: 26,
                    hour_align: hmUI.align.CENTER_H,
                    minute_val: new Date().getMinutes(),
                    minute_zero: 1,
                    minute_startX: 100,
                    minute_startY: 246,
                    minute_array: [
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png'
                    ],
                    minute_space: 26,
                    minute_align: hmUI.align.CENTER_H,
                    minute_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 396,
                    y: 216,
                    src: '15.png',
                    type: hmUI.system_status.DISCONNECT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 396,
                    y: 168,
                    src: '16.png',
                    type: hmUI.system_status.LOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 396,
                    y: 263,
                    src: '17.png',
                    type: hmUI.system_status.CLOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_2ff3cf39f4d74ff9a25a4cd6ffd364b6 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 20,
                    y: 246,
                    w: 70,
                    h: 30,
                    text: '[YEAR]',
                    color: '0xFFbdbdbd',
                    text_size: 26,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_a5ca3be077e5494a86345f0cf149a8ac = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 20,
                    y: 276,
                    w: 70,
                    h: 35,
                    text: '[MON]',
                    color: '0xFFbdbdbd',
                    text_size: 30,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_2bd21436e45143a6b39031572582e58d = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 20,
                    y: 311,
                    w: 70,
                    h: 35,
                    text: '[DAY]',
                    color: '0xFFbdbdbd',
                    text_size: 30,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 254,
                    y: 427,
                    src: '18.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_f2dc252f255e4996beb46610fd600fe3 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 150,
                    y: 426,
                    w: 100,
                    h: 35,
                    text: '[SC]',
                    color: '0xFFbdbdbd',
                    text_size: 28,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.RIGHT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 38,
                    y: 133,
                    image_array: [
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png'
                    ],
                    image_length: 10,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_187f8be8f4ee4540bce901fcf52cfc66 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 0,
                    y: 221,
                    w: 100,
                    h: 25,
                    text: '[WEEK_EN_F]',
                    color: '0xFFbdbdbd',
                    text_size: 18,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_84dfb0d2b27c46108a174c3c2449bba8 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 234,
                    y: 4,
                    w: 70,
                    h: 35,
                    text: '[HR]',
                    color: '0xFFbdbdbd',
                    text_size: 30,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 192,
                    y: 3,
                    src: '29.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 58,
                    y: 348,
                    src: '30.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                if (!timeSensor) {
                    timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                }
                if (!stepSensor) {
                    stepSensor = hmSensor.createSensor(hmSensor.id.STEP);
                }
                if (!heartSensor) {
                    heartSensor = hmSensor.createSensor(hmSensor.id.HEART);
                }
                timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_2ff3cf39f4d74ff9a25a4cd6ffd364b6.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }` });
                        },
                        () => {
                            normal$_$text_2ff3cf39f4d74ff9a25a4cd6ffd364b6.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }` });
                        },
                        () => {
                            normal$_$text_2ff3cf39f4d74ff9a25a4cd6ffd364b6.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_a5ca3be077e5494a86345f0cf149a8ac.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.month }` });
                        },
                        () => {
                            normal$_$text_a5ca3be077e5494a86345f0cf149a8ac.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.month }` });
                        },
                        () => {
                            normal$_$text_a5ca3be077e5494a86345f0cf149a8ac.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.month }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_2bd21436e45143a6b39031572582e58d.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                        },
                        () => {
                            normal$_$text_2bd21436e45143a6b39031572582e58d.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                        },
                        () => {
                            normal$_$text_2bd21436e45143a6b39031572582e58d.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                    const WEEK_EN_F = function (val) {
                        const valueMap = {
                            '1': 'Monday',
                            '2': 'Tuesday',
                            '3': 'Wednesday',
                            '4': 'Thursday',
                            '5': 'Friday',
                            '6': 'Saturday',
                            '7': 'Sunday'
                        };
                        return valueMap[val];
                    };
                    normal$_$text_187f8be8f4ee4540bce901fcf52cfc66.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_F(timeSensor.week) }` });
                }), stepSensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_f2dc252f255e4996beb46610fd600fe3.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                }), heartSensor.addEventListener(heartSensor.event.LAST, function () {
                    normal$_$text_84dfb0d2b27c46108a174c3c2449bba8.setProperty(hmUI.prop.MORE, { text: `${ heartSensor.last }` });
                });
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                normal$_$text_2ff3cf39f4d74ff9a25a4cd6ffd364b6.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }` });
                            },
                            () => {
                                normal$_$text_2ff3cf39f4d74ff9a25a4cd6ffd364b6.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }` });
                            },
                            () => {
                                normal$_$text_2ff3cf39f4d74ff9a25a4cd6ffd364b6.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                normal$_$text_a5ca3be077e5494a86345f0cf149a8ac.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.month }` });
                            },
                            () => {
                                normal$_$text_a5ca3be077e5494a86345f0cf149a8ac.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.month }` });
                            },
                            () => {
                                normal$_$text_a5ca3be077e5494a86345f0cf149a8ac.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.month }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                normal$_$text_2bd21436e45143a6b39031572582e58d.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                            },
                            () => {
                                normal$_$text_2bd21436e45143a6b39031572582e58d.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                            },
                            () => {
                                normal$_$text_2bd21436e45143a6b39031572582e58d.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                        normal$_$text_f2dc252f255e4996beb46610fd600fe3.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                        const WEEK_EN_F = function (val) {
                            const valueMap = {
                                '1': 'Monday',
                                '2': 'Tuesday',
                                '3': 'Wednesday',
                                '4': 'Thursday',
                                '5': 'Friday',
                                '6': 'Saturday',
                                '7': 'Sunday'
                            };
                            return valueMap[val];
                        };
                        normal$_$text_187f8be8f4ee4540bce901fcf52cfc66.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_F(timeSensor.week) }` });
                        normal$_$text_84dfb0d2b27c46108a174c3c2449bba8.setProperty(hmUI.prop.MORE, { text: `${ heartSensor.last }` });
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}