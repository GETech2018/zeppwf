try {
  (() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__),
      "drink"
    );

    /*
     * huamiOS bundle tool v1.0.17
     * Copyright © Huami. All Rights Reserved
     * 天气 271F
     */
    ("use strict");

    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);
    //=================变量声明=================
    const rootPath = "images/";
    const weekArray = [];
    let weekArray_cn = [];
    let timeArray = [];
    let whiteBigArr = [];
    let whiteSmallArr = [];
    let grayBigArr = [];
    let graySmallArr = [];

    const weather_smallIcon_arr = [];
    const weather_bigIcon_arr = [];

    let weekImages = new Array(4);
    let weatherIconImages = new Array(4);
    let weatherTextImages = new Array(4);
    let timeSensor = null;
    let weatherSensor = null;
    let clockTimer = null;
    let cityText = null;
    //=================循环添加路径==================
    for (i = 1; i < 8; i++) {
      weekArray.push(rootPath + "week/" + i + ".png");
      weekArray_cn.push(rootPath + "week_cn/" + i + ".png");
    }
    for (i = 0; i < 10; i++) {
      whiteBigArr.push(rootPath + "white_big_num/" + i + ".png");
      whiteSmallArr.push(rootPath + "white_small_num/" + i + ".png");
      graySmallArr.push(rootPath + "gray_small_num/" + i + ".png");
      grayBigArr.push(rootPath + "gray_big_num/" + i + ".png");
      timeArray.push(rootPath + "time/" + i + ".png");
    }

    for (i = 0; i < 29; i++) {
      weather_smallIcon_arr.push(rootPath + "weather/" + i + ".png");
      weather_bigIcon_arr.push(rootPath + "weatherBig/" + i + ".png");
    }

    //====================参数对象=====================

    let objBg = {
      x: 0,
      y: 0,
      w: 466,
      h: 466,
      color: 0x000000,
    };
    let objImgBg = {
      x: 0,
      y: 0,
      w: 466,
      h: 466,
      src: rootPath + "img/bg.png",
      show_level: hmUI.show_level.ONAL_NORMAL,
    };
    let objUviText = {
      x: 103 * 0.9708,
      y: 378 * 0.9708,
      type: hmUI.data_type.UVI,
      font_array: graySmallArr,
      h_space: -3,
      align_h: hmUI.align.LEFT,
      padding: false, //是否补零 true为补零
      isCharacter: false, //true为文字图片
      show_level: hmUI.show_level.ONAL_NORMAL,
    };
    let objTimeText = {
      hour_zero: 1,
      hour_startX: 134 * 0.9708,
      hour_startY: 371 * 0.9708,
      hour_array: timeArray,
      hour_space: 0,
      hour_unit_sc: rootPath + "img/colon.png", //单位
      hour_unit_tc: rootPath + "img/colon.png",
      hour_unit_en: rootPath + "img/colon.png",
      hour_align: hmUI.align.LEFT,

      minute_zero: 1, //是否补零 1为补零
      minute_startX: 250 * 0.9708,
      minute_startY: 371 * 0.9708,
      minute_array: timeArray,
      minute_space: 0, //两个图片间隔 对应GT2的interval
      minute_follow: 0, //是否跟随
      minute_align: hmUI.align.LEFT,

      am_x: 216 * 0.9708,
      am_y: 446 * 0.9708,
      am_sc_path: rootPath + "img/am_cn.png",
      am_en_path: rootPath + "img/am.png",
      pm_x: 216 * 0.9708,
      pm_y: 446 * 0.9708,
      pm_sc_path: rootPath + "img/pm_cn.png",
      pm_en_path: rootPath + "img/pm.png",
      show_level: hmUI.show_level.ALL,
    };
    let objCityText = {
      x: 264 * 0.9708,
      y: 35 * 0.9708,
      w: 200,
      h: 34,
      color: 0x979797,
      align_h: hmUI.align.LEFT,
      align_v: hmUI.align.CENTER_V,
    };
    let objWindText = {
      x: 344 * 0.9708,
      y: 378 * 0.9708,
      type: hmUI.data_type.WIND,
      font_array: graySmallArr,
      h_space: 0,
      align_h: hmUI.align.RIGHT,
      padding: false, //是否补零 true为补零
      isCharacter: true, //true为文字图片
      show_level: hmUI.show_level.ONAL_NORMAL,
    };
    let objWeatherLevel = {
      x: -10 * 0.9708,
      y: -38 * 0.9708,
      image_array: weather_bigIcon_arr,
      image_length: weather_bigIcon_arr.length,
      type: hmUI.data_type.WEATHER,
    };
    let objTopWeatherText = {
      x: 240,
      y: 79,
      type: hmUI.data_type.WEATHER_CURRENT,
      font_array: whiteBigArr,
      h_space: 0,
      align_h: hmUI.align.LEFT,
      unit_sc: rootPath + "img/white_big_du.png",
      unit_en: rootPath + "img/white_big_du.png",
      unit_tc: rootPath + "img/white_big_du.png",
      negative_image: rootPath + "img/white_big_fu.png", //负号图片
      invalid_image: rootPath + "img/white_big_invalid.png", // 无数据时显示的图片
      padding: false, //是否补零 true为补零
      show_level: hmUI.show_level.ONAL_NORMAL,
    };
    let objTopWeatherDown = {
      x: 268 * 0.9708,
      y: 179 * 0.9708,
      type: hmUI.data_type.WEATHER_LOW,
      font_array: grayBigArr,
      h_space: 0,
      align_h: hmUI.align.LEFT,
      unit_sc: rootPath + "img/gray_big_du.png",
      unit_en: rootPath + "img/gray_big_du.png",
      unit_tc: rootPath + "img/gray_big_du.png",
      negative_image: rootPath + "img/gray_big_fu.png", //负号图片
      invalid_image: rootPath + "img/gray_big_invalid.png", // 无数据时显示的图片
      padding: false, //是否补零 true为补零
      show_level: hmUI.show_level.ONAL_NORMAL,
    };
    let objTopWeatherHight = {
      x: 367 * 0.9708,
      y: 179 * 0.9708,
      type: hmUI.data_type.WEATHER_HIGH,
      font_array: grayBigArr,
      h_space: 0,
      align_h: hmUI.align.LEFT,
      unit_sc: rootPath + "img/gray_big_du.png",
      unit_en: rootPath + "img/gray_big_du.png",
      unit_tc: rootPath + "img/gray_big_du.png",
      negative_image: rootPath + "img/gray_big_fu.png", //负号图片
      invalid_image: rootPath + "img/gray_big_invalid.png", // 无数据时显示的图片
      padding: false, //是否补零 true为补零
      show_level: hmUI.show_level.ONAL_NORMAL,
    };
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
        weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
        let lan = hmSetting.getLanguage();
        var screenType = hmSetting.getScreenType();
        if (screenType == hmSetting.screen_type.AOD) {
          img_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, objBg);
        } else {
          img_bg = hmUI.createWidget(hmUI.widget.IMG, objImgBg);
          uviText = hmUI.createWidget(hmUI.widget.TEXT_IMG, objUviText);
        }
        timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, objTimeText);

        if (screenType == hmSetting.screen_type.WATCHFACE) {
          cityText = hmUI.createWidget(hmUI.widget.TEXT, objCityText);
          //初始化天气widget
          for (var i = 0; i < 4; i++) {
            weekImages[i] = hmUI.createWidget(hmUI.widget.IMG, {
              x: 60 + i * 100 * 0.9708,
              y: 231 * 0.9708,
              w: 60,
              h: 24,
              show_level: hmUI.show_level.ONAL_NORMAL,
            });

            weatherIconImages[i] = hmUI.createWidget(hmUI.widget.IMG, {
              x: 66 + i * 100 * 0.9708,
              y: 267 * 0.9708,
              w: 48,
              h: 48,
              src: weather_smallIcon_arr[0],
              show_level: hmUI.show_level.ONAL_NORMAL,
            });
            weatherTextImages[i] = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 60 + 100 * i * 0.9708,
              y: 325 * 0.9708,
              w: 60,
              h: 100,
              font_array: whiteSmallArr,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONAL_NORMAL,
              unit_sc: rootPath + "img/white_small_du.png",
              unit_en: rootPath + "img/white_small_du.png",
              unit_tc: rootPath + "img/white_small_du.png",
              negative_image: rootPath + "img/white_small_fu.png", //负号图片
              invalid_image: rootPath + "img/white_small_invalid.png", // 无数据时显示的图片
            });
          }
          // -------------------------------------------------10015

          windText = hmUI.createWidget(hmUI.widget.TEXT_IMG, objWindText);
          //左边大的天气
          hmUI.createWidget(hmUI.widget.IMG_LEVEL, objWeatherLevel);
          //上边当前天气
          hmUI.createWidget(hmUI.widget.TEXT_IMG, objTopWeatherText);
          //上面低温
          hmUI.createWidget(hmUI.widget.TEXT_IMG, objTopWeatherDown);
          //上面高温
          hmUI.createWidget(hmUI.widget.TEXT_IMG, objTopWeatherHight);

          setWeek();

          //获取天气信息
          const weatherData = weatherSensor.getForecastWeather();
          cityText.setProperty(hmUI.prop.TEXT, weatherData.cityName);
          //获取预报天气结构体
          const forecastData = weatherData.forecastData;
          const weatherSize = forecastData.data.length;

          //获取预报天气信息 索引为0为今天
          let iconIndex = 0;
          let weatherNum = "";
          for (var index = 0; index < 4; index++) {
            if (index + 1 >= weatherSize) {
              iconIndex = 25;
              weatherNum = "";
            } else {
              const element = forecastData.data[index + 1];

              iconIndex = element.index;
              weatherNum = element.high + "";
            }

            weatherIconImages[index].setProperty(
              hmUI.prop.SRC,
              weather_smallIcon_arr[iconIndex]
            );
            weatherTextImages[index].setProperty(hmUI.prop.TEXT, weatherNum);
          }
        }

        function setImgPath(widget, path) {
          widget.setProperty(hmUI.prop.SRC, path);
        }

        //// get week----------------------------------------10015
        function setWeek() {
          let week = timeSensor.week;
          let lan = hmSetting.getLanguage();
          if (week == 7) {
            week = 1;
          } else {
            week += 1;
          }
          for (var i = 0; i < 4; i++) {
            if (lan == 0 || lan == 1) {
              path = rootPath + "week_ch/" + week + ".png";
            } else {
              path = rootPath + "week/" + week + ".png";
            }
            setImgPath(weekImages[i], path);
            week++;
            if (week == 8) {
              week = 1;
            }
          }
        }
        clockTimer = timer.createTimer(
          500,
          1000,
          function (option) {
            setWeek();
          },
          {}
        );
        // var img_bg1 = hmUI.createWidget(hmUI.widget.IMG, {
        //     x: 0,
        //     y: 0,
        //     w: 480,
        //     h: 480,
        //     src: rootPath + "img/over.png",
        //     show_level: hmUI.show_level.ONAL_NORMAL,
        // });
        var img_bg2 = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 480,
          h: 480,
          src: rootPath + "img/overup.png",
          show_level: hmUI.show_level.ONAL_NORMAL,
        });
        if (screenType == hmSetting.screen_type.WATCHFACE) {
          hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
            resume_call: function () {
              setWeek();
              const weatherData = weatherSensor.getForecastWeather();
              cityText.setProperty(hmUI.prop.TEXT, weatherData.cityName);
              //获取预报天气结构体
              const forecastData = weatherData.forecastData;
              const weatherSize = forecastData.data.length;

              //获取预报天气信息 索引为0为今天
              let iconIndex = 0;
              let weatherNum = "";
              for (var index = 0; index < 4; index++) {
                if (index + 1 >= weatherSize) {
                  iconIndex = 25;
                  weatherNum = "";
                } else {
                  const element = forecastData.data[index + 1];

                  iconIndex = element.index;
                  weatherNum = element.high + "";
                }
                weatherIconImages[index].setProperty(
                  hmUI.prop.SRC,
                  weather_smallIcon_arr[iconIndex]
                );
                weatherTextImages[index].setProperty(
                  hmUI.prop.TEXT,
                  weatherNum
                );
              }
            },
            pause_call: function () {
              timer.stopTimer(clockTimer);
            },
          });
        }
        let humidityClick = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 0,
          y: 0,
          w: 466,
          h: 354,
          type: hmUI.data_type.HUMIDITY,
        });

        let uviClick = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 64,
          y: 365,
          w: 64,
          h: 35,
          type: hmUI.data_type.HUMIDITY,
        });

        let windClick = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 354,
          y: 365,
          w: 47,
          h: 32,
          type: hmUI.data_type.WIND,
        });
      },
      onInit() {
        console.log("index page.js on init invoke");
        this.init_view();
      },

      onReady() {
        console.log("index page.js on ready invoke");
      },

      onShow() {
        console.log("index page.js on show invoke");
      },

      onHide() {
        console.log("index page.js on hide invoke");
      },

      onDestory() {
        console.log("index page.js on destory invoke");
      },
    });
    /*
     * end js
     */
  })();
} catch (e) {
  console.log(e);
}
