
/*
** huamiOS bundle tool v1.0.17
* *huamiOS watchface js version v1.0.1
* *Copyright © Huami. All Rights Reserved
*/

try {

  (() => {

    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
    var __$$module$$__ = __$$app$$__.current;
    //drink is a name,can modify
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

    'use strict';
    let bg = null;

    let timePointer = null;
    let strRootPath = "images/";
    let nW = 466
    let nH = 466
    let arrData = []
    let arrWeekEn = []
    let arrWeekSc = []
    let arrMonthEn = []
    let arrMonthSc = []
    let objAnimBg = {
      x: 0,
      y: 0,
      w: nW,
      h: nH,
      align_h: hmUI.align.CENTER_H,
      align_v: hmUI.align.CENTER_V,
      anim_path: strRootPath + "breath_animate",
      anim_prefix: "breath",
      anim_ext: "png",
      anim_fps: 25,
      anim_size: 210,
      anim_repeat: true,
      repeat_count: 0,
      anim_status: 1,
      display_on_restart:true,
    }
    let objMask = {
      x: 0,
      y: 0,
      w: nW,
      h: nH,
      src:  strRootPath + "img/mask.png",
      show_level: hmUI.show_level.ONAL_NORMAL,
    }
    let objBg = {
      x: 0,
      y: 0,
      w: nW,
      h: nH,
      color: 0x000000,
    }

    for (i = 0; i < 13; i++) {
      if(i < 8 && i > 0){
        arrWeekEn.push(strRootPath+"week/en/"+i+".png")
        arrWeekSc.push(strRootPath+"week/cn/"+i+".png")
      }
      if(i < 10){
        arrData.push(strRootPath+"data/"+i+".png")
      }
      if(i < 13 && i > 0){
        arrMonthEn.push(strRootPath+"month/en/"+i+".png")
        arrMonthSc.push(strRootPath+"month/cn/"+i+".png")
      }
    }

    // const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({

      init_view() {

        let screenType = hmSetting.getScreenType();
        let nomalModel = screenType == hmSetting.screen_type.APP || screenType == hmSetting.screen_type.WATCHFACE;
        let aodModel = screenType == hmSetting.screen_type.AOD;

        if (nomalModel) {
          bg = hmUI.createWidget(hmUI.widget.IMG_ANIM, objAnimBg);
          let maskImg = hmUI.createWidget(hmUI.widget.IMG,objMask);
          showData();
          showNomalTime();
        } else if (aodModel) {
          bg = hmUI.createWidget(hmUI.widget.FILL_RECT, objBg);
          showData();
          showAodTime();
        }
        function showData(){
          showHeart();
          weekLevel = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
            x: 191*0.9708,
            y: 91*0.9708,
            week_sc: arrWeekSc,
            week_tc: arrWeekSc,
            week_en: arrWeekEn,
            //show_level: hmUI.show_level.ONLY_NORMAL,
          });

          day_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
            month_startX: 150*0.9708,
            month_startY: 133*0.9708,
            month_en_array: arrMonthEn,
            month_sc_array: arrMonthSc,
            month_tc_array: arrMonthSc,
            month_space: 0,
            month_zero: 1,
            month_is_character:true,

            day_startX: 252*0.9708,
            day_startY: 133*0.9708,
            day_en_array: arrData,
            day_space: 0,
            day_zero: 1,
            show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
          });
        }
        function showNomalTime() {
          timePointer  = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
            hour_centerX: 233,
            hour_centerY: 233,
            hour_posX: 18,
            hour_posY: 233,
            hour_path: strRootPath+"img/hour.png",

            minute_centerX: 233,
            minute_centerY: 233,
            minute_posX: 15,
            minute_posY: 233,
            minute_path: strRootPath+"img/min.png",

            second_centerX:  233,
            second_centerY: 233,
            second_posX: 9,
            second_posY: 233,
            second_path: strRootPath + "img/sec.png",
            show_level:hmUI.show_level.ONAL_NORMAL,
          });
         }
         function showAodTime() {
          timePointer  = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
            hour_centerX: 233,
            hour_centerY: 233,
            hour_posX: 18,
            hour_posY: 233,
            hour_path: strRootPath+"img/aod_hour.png",

            minute_centerX: 233,
            minute_centerY: 233,
            minute_posX: 15,
            minute_posY: 233,
            minute_path: strRootPath+"img/min_xp.png",
            show_level:hmUI.show_level.ONLY_AOD,
          });
         }

        function showHeart(){
          let heartTxt  = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
            x: 205*0.9708,
            y: 350*0.9708,
            w: 70,
            type: hmUI.data_type.HEART,
            font_array: arrData,
            h_space: 0,
            align_h: hmUI.align.CENTER_H,
            padding:false,
            isCharacter:true,
            invalid_image: strRootPath + "img/invalid.png",
            show_level: hmUI.show_level.ALL,
          });
          let heartImg = hmUI.createWidget(hmUI.widget.IMG,{
            x: 224*0.9708,
            y: 308*0.9708,
            w: 32,
            h: 32,
            src:  strRootPath + "img/heart.png",
            show_level: hmUI.show_level.ALL,
          });
        }
        //点击心率组件跳转
        let Heart_click = hmUI.createWidget(hmUI.widget.IMG_CLICK,{
          x: 224*0.9708,
          y: 308*0.9708,
          w: 40,
          h: 80,
          type: hmUI.data_type.HEART,
        })

      },

      onInit() {
        console.log('index page.js on init invoke')

        this.init_view()

      },

      onReady() {
        console.log('index page.js on ready invoke')
      },

      onShow() {
        console.log('index page.js on show invoke')
      },

      onHide() {
        console.log('index page.js on hide invoke')
      },

      onDestory() {
        console.log('index page.js on destory invoke')
      },
    });

  })()
} catch (e) {
  console.log(e)
}
