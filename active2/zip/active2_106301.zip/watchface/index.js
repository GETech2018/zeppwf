try {
  (() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__),
      'drink'
    );

    /*
     * huamiOS bundle tool v1.0.17
     * Copyright © Huami. All Rights Reserved
     */
    ('use strict');

    console.log('----->>>current');
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let animResident = null;
    let animCreate = null;
    let week = null;
    let month = null;
    let animLoop;
    let weekScArray = [];
    let weekTcArray = [];
    let weekEnArray = [];
    let fontArray = [];

    // 静态资源路径
    let rootPath = 'images/';
    let dontPath = rootPath + 'font/dot.png';

    // 静态资源数组
    // let weekStr = ["sun","mon","thu","wed","tue","fri","sat"];
    for (let i = 1; i < 8; i++) {
      weekScArray.push(rootPath + 'week_sc/' + i + '.png');
      weekTcArray.push(rootPath + 'week_tc/' + i + '.png');
      weekEnArray.push(rootPath + 'week/' + i + '.png');
    }
    for (let i = 0; i < 10; i++) {
      fontArray.push(rootPath + 'font/' + i + '.png');
    }

    // 开始动画
    // const objAnimCreate = ;
    // 控件对象
    // 持续动画
    let objAnim = {
      x: 0,
      y: 0,
      w: 466,
      h: 466,
      align_h: hmUI.align.CENTER_H,
      align_v: hmUI.align.CENTER_V,
      anim_path: rootPath + 'anim', //必须从0开始 可以询问君成 张莉
      anim_prefix: 'anim',
      anim_ext: 'png',
      anim_fps: 18,
      anim_size: 25,
      repeat_count: 0, // 0位无限重复
      anim_repeat: true, // 是否重复
      anim_status: hmUI.anim_status.START,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };

    const objWeek = {
      x: 198 * 0.9708,
      y: 89 * 0.9708,
      week_tc: weekTcArray,
      week_sc: weekScArray,
      week_en: weekEnArray,
      show_level: hmUI.show_level.ALL,
    };

    const objMonth = {
      month_startX: 196 * 0.9708,
      month_startY: 126 * 0.9708,
      month_zero: true,
      month_en_array: fontArray,
      month_unit_sc: dontPath,
      month_unit_tc: dontPath,
      month_unit_en: dontPath,
      day_follow: true,
      day_zero: true,
      day_en_array: fontArray,
      show_level: hmUI.show_level.ALL,
    };

    const objEditBg = {
      x: 0,
      y: 0,
      w: 466,
      h: 466,
      src: rootPath + 'edit/edit_bg.png',
      show_level: hmUI.show_level.ONLY_EDIT,
    };

    let editConfig = [
      { type: hmUI.edit_type.HEART, preview: rootPath + 'preview/heart.png' },
      {
        type: hmUI.edit_type.PAI_WEEKLY,
        preview: rootPath + 'preview/pai.png',
      },
      { type: hmUI.edit_type.STEP, preview: rootPath + 'preview/step.png' },
      { type: hmUI.edit_type.CAL, preview: rootPath + 'preview/cal.png' },
      { type: hmUI.edit_type.BATTERY, preview: rootPath + 'preview/bat.png' },
      { type: hmUI.edit_type.HUMIDITY, preview: rootPath + 'preview/hum.png' },
      { type: hmUI.edit_type.UVI, preview: rootPath + 'preview/uvi.png' },
      { type: hmUI.edit_type.STAND, preview: rootPath + 'preview/stand.png' },
      {
        type: hmUI.edit_type.SUN_SET,
        preview: rootPath + 'preview/sunset.png',
      },
      {
        type: hmUI.edit_type.SUN_RISE,
        preview: rootPath + 'preview/sunrise.png',
      },
      { type: hmUI.edit_type.WIND, preview: rootPath + 'preview/wind.png' },
    ];

    let edit_list_config = {
      title_font_size: 34,
      title_align_h: hmUI.align.CENTER_H,
      list_item_vspace: 8,
      list_bg_color: 0x000000,
      list_bg_radius: 30,
      list_group_text_font_size: 32,
      list_group_text_align_h: hmUI.align.CENTER_H,
      list_tips_text_font_size: 32,
      list_tips_text_align_h: hmUI.align.LEFT,
    };

    const objGroup = {
      edit_id: 101,
      x: 177 * 0.9708,
      y: 338 * 0.9708,
      w: 127 * 0.971,
      h: 85 * 0.971,
      select_image: rootPath + 'edit/select.png',
      un_select_image: rootPath + 'edit/un_select.png',
      default_type: hmUI.edit_type.HEART,
      optional_types: editConfig,
      count: editConfig.length,
      tips_BG: rootPath + 'edit/text_tag.png',
      tips_x: 0,
      tips_y: (288 - 328) * 0.9708,
      tips_width: 128,
      tips_margin: 10,
      select_list: edit_list_config, // 新增配置选项
      show_level: hmUI.show_level.ALL,
    };

    const objMaskCover = {
      x: 0,
      y: 0,
      w: 466,
      h: 466,
      src: rootPath + 'edit/mask_100.png',
      show_level: hmUI.show_level.ONLY_EDIT,
    };

    // 时间指针对象
    let timePointerProp = {
      hour_centerX: 240 * 0.9708, // 指针旋转中心
      hour_centerY: 240 * 0.9708,
      hour_posX: 31 * 0.9708,
      hour_posY: 180 * 0.9708,
      hour_path: rootPath + 'hour.png',
      minute_centerX: 240 * 0.9708,
      minute_centerY: 240 * 0.9708,
      minute_posX: 31 * 0.9708,
      minute_posY: 225 * 0.9708,
      minute_path: rootPath + 'min.png',
      show_level: hmUI.show_level.ALL,
    };

    const objMask = {
      x: 0,
      y: 0,
      w: 466,
      h: 466,
      src: rootPath + 'edit/mask_70.png',
      show_level: hmUI.show_level.ONLY_EDIT,
    };

    let objSec = {
      second_centerX: 240 * 0.9708,
      second_centerY: 240 * 0.9708,
      second_posX: 31 * 0.9708,
      second_posY: 234 * 0.9708,
      second_path: rootPath + 'sec.png',
    };

    const logger = DeviceRuntimeCore.HmLogger.getLogger('defult');
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        let screenType = hmSetting.getScreenType(); // 获取当前界面 Screen 信息
        // 在 js应用内 或者在 js表盘主界面
        let nomalModel =
          screenType == hmSetting.screen_type.APP ||
          screenType == hmSetting.screen_type.WATCHFACE;
        // 在 熄屏界面
        let aodModel = screenType == hmSetting.screen_type.AOD;
        // 动画部分
        //  动画回调
        // animLoop =
        animResident = hmUI.createWidget(hmUI.widget.IMG_ANIM, objAnim);
        // animResident.setProperty(hmUI.prop.VISIBLE, false);
        animCreate = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
          x: 0,
          y: 0,
          w: 466,
          h: 466,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          anim_path: rootPath + 'start',
          anim_prefix: 'anim',
          anim_ext: 'png',
          anim_fps: 18,
          anim_size: 24,
          anim_repeat: false,
          repeat_count: 1,
          anim_status: 1,
          display_on_restart: 1,
          anim_complete_call: () => {
            console.log('startAnim end++++++++++++++++++++++');
            // animResident.setProperty(hmUI.prop.MORE, );
            animCreate.setProperty(
              hmUI.prop.ANIM_STATUS,
              hmUI.anim_status.STOP
            );
            animCreate.setProperty(hmUI.prop.VISIBLE, false);
            console.log('loopAnim++++++++++++++++++++++');
          }, // 动画回调
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let btText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          show_level: hmUI.show_level.ALL,
        });
        let btIcon = hmUI.createWidget(hmUI.widget.IMG, {
          show_level: hmUI.show_level.ALL,
        });

        hmUI.createWidget(hmUI.widget.IMG_WEEK, objWeek);
        hmUI.createWidget(hmUI.widget.IMG_DATE, objMonth);
        let editBg = hmUI.createWidget(
          hmUI.widget.WATCHFACE_EDIT_MASK,
          objEditBg
        );
        let editGroup = hmUI.createWidget(
          hmUI.widget.WATCHFACE_EDIT_GROUP,
          objGroup
        );
        let editType = editGroup.getProperty(hmUI.prop.CURRENT_TYPE);
        let dataType;
        switch (editType) {
          // % --
          case hmUI.edit_type.HEART:
            dataType = hmUI.data_type.HEART;
            btText.setProperty(hmUI.prop.MORE, {
              x: 203,
              y: 381 * 0.9708,
              w: 60,
              type: hmUI.data_type.HEART,
              font_array: fontArray,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              invalid_image: rootPath + 'font/none.png',
            });
            btIcon.setProperty(hmUI.prop.MORE, {
              x: 217 * 0.9708,
              y: 333 * 0.9708,
              w: 47 * 0.971,
              h: 47 * 0.971,
              src: rootPath + 'img/heart.png',
            });
            break;
          // 5 weishu
          case hmUI.edit_type.STEP:
            dataType = hmUI.data_type.STEP;
            btText.setProperty(hmUI.prop.MORE, {
              x: 153, // 192 * 0.9708
              y: 381 * 0.9708,
              w: 160,
              type: hmUI.data_type.STEP,
              font_array: fontArray,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
            });
            btIcon.setProperty(hmUI.prop.MORE, {
              x: 217 * 0.9708,
              y: 333 * 0.9708,
              w: 47 * 0.971,
              h: 47 * 0.971,
              align_h: hmUI.align.CENTER_H,
              src: rootPath + 'img/step.png',
            });
            break;
          // --
          case hmUI.edit_type.SUN_SET:
            dataType = hmUI.data_type.SUN_SET;
            btText.setProperty(hmUI.prop.MORE, {
              x: 153, // 188 * 0.9708
              y: 381 * 0.9708,
              w: 160,
              type: hmUI.data_type.SUN_SET,
              font_array: fontArray,
              h_space: 0,
              padding: true,
              align_h: hmUI.align.CENTER_H,
              dot_image: rootPath + 'font/colon.png',
              invalid_image: rootPath + 'font/none.png',
            });
            btIcon.setProperty(hmUI.prop.MORE, {
              x: 217 * 0.9708,
              y: 333 * 0.9708,
              w: 47 * 0.971,
              h: 47 * 0.971,
              src: rootPath + 'img/sunset.png',
            });
            break;
          // dot_image  invalid_image
          case hmUI.edit_type.SUN_RISE:
            dataType = hmUI.data_type.SUN_RISE;
            btText.setProperty(hmUI.prop.MORE, {
              x: 153, // 187 * 0.9708
              y: 381 * 0.9708,
              w: 160,
              type: hmUI.data_type.SUN_RISE,
              font_array: fontArray,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              dot_image: rootPath + 'font/colon.png',
              padding: true,
              invalid_image: rootPath + 'font/none.png',
            });
            btIcon.setProperty(hmUI.prop.MORE, {
              x: 217 * 0.9708,
              y: 333 * 0.9708,
              w: 47 * 0.971,
              h: 47 * 0.971,
              src: rootPath + 'img/sunrise.png',
            });
            break;
          // zuida 12  wushuju 0
          case hmUI.edit_type.STAND:
            dataType = hmUI.data_type.STAND;
            btText.setProperty(hmUI.prop.MORE, {
              x: 153, // 192 * 0.9708
              y: 384 * 0.9708,
              w: 160,
              type: hmUI.data_type.STAND,
              font_array: fontArray,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              dot_image: rootPath + 'font/slant.png',
            });
            btIcon.setProperty(hmUI.prop.MORE, {
              x: 217 * 0.9708,
              y: 331 * 0.9708,
              w: 47 * 0.971,
              h: 47 * 0.971,
              src: rootPath + 'img/stand.png',
            });
            break;
          // [0, 525]
          case hmUI.edit_type.PAI_WEEKLY:
            dataType = hmUI.data_type.PAI_WEEKLY;
            btText.setProperty(hmUI.prop.MORE, {
              x: 211 * 0.9708,
              y: 381 * 0.9708,
              type: hmUI.data_type.PAI_WEEKLY,
              font_array: fontArray,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
            });
            btIcon.setProperty(hmUI.prop.MORE, {
              x: 217 * 0.9708,
              y: 333 * 0.9708,
              w: 47 * 0.971,
              h: 47 * 0.971,
              src: rootPath + 'img/pai.png',
            });
            break;
          // 1000 wuhsuju 0
          case hmUI.edit_type.CAL:
            dataType = hmUI.data_type.CAL;
            btText.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 381 * 0.9708,
              w: 466,
              type: hmUI.data_type.CAL,
              font_array: fontArray,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
            });
            btIcon.setProperty(hmUI.prop.MORE, {
              x: 217 * 0.9708,
              y: 333 * 0.9708,
              w: 47 * 0.971,
              h: 47 * 0.971,
              src: rootPath + 'img/cal.png',
            });
            break;
          // %
          case hmUI.edit_type.BATTERY:
            dataType = hmUI.data_type.BATTERY;
            btText.setProperty(hmUI.prop.MORE, {
              x: 198 * 0.9708,
              y: 381 * 0.9708,
              type: hmUI.data_type.BATTERY,
              font_array: fontArray,
              h_space: 0,
              unit_sc: rootPath + 'font/percent.png',
              unit_tc: rootPath + 'font/percent.png',
              unit_en: rootPath + 'font/percent.png',
              align_h: hmUI.align.CENTER_H,
            });
            btIcon.setProperty(hmUI.prop.MORE, {
              x: 217 * 0.9708,
              y: 333 * 0.9708,
              w: 47 * 0.971,
              h: 47 * 0.971,
              src: rootPath + 'img/battery.png',
            });
            break;
          //  wushuju --
          case hmUI.edit_type.UVI:
            dataType = hmUI.data_type.UVI;
            btText.setProperty(hmUI.prop.MORE, {
              x: 221 * 0.9708,
              y: 381 * 0.9708,
              type: hmUI.data_type.UVI,
              font_array: fontArray,
              h_space: 0,
              invalid_image: rootPath + 'font/none.png',
              align_h: hmUI.align.CENTER_H,
            });
            btIcon.setProperty(hmUI.prop.MORE, {
              x: 217 * 0.9708,
              y: 333 * 0.9708,
              w: 47 * 0.971,
              h: 47 * 0.971,
              src: rootPath + 'img/uvi.png',
            });
            break;
          case hmUI.edit_type.WIND:
            dataType = hmUI.data_type.WIND;
            btText.setProperty(hmUI.prop.MORE, {
              x: 221 * 0.9708,
              y: 381 * 0.9708,
              type: hmUI.data_type.WIND,
              font_array: fontArray,
              h_space: 0,
              invalid_image: rootPath + 'font/none.png',
              align_h: hmUI.align.CENTER_H,
            });
            btIcon.setProperty(hmUI.prop.MORE, {
              x: 217 * 0.9708,
              y: 333 * 0.9708,
              w: 47 * 0.971,
              h: 47 * 0.971,
              src: rootPath + 'img/wind.png',
            });
            break;
          case hmUI.edit_type.HUMIDITY:
            dataType = hmUI.data_type.HUMIDITY;
            btText.setProperty(hmUI.prop.MORE, {
              x: 198 * 0.9708,
              y: 381 * 0.9708,
              type: hmUI.data_type.HUMIDITY,
              font_array: fontArray,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              unit_sc: rootPath + 'font/percent.png',
              unit_tc: rootPath + 'font/percent.png',
              unit_en: rootPath + 'font/percent.png',
              invalid_image: rootPath + 'font/none.png',
            });
            btIcon.setProperty(hmUI.prop.MORE, {
              x: 217 * 0.9708,
              y: 333 * 0.9708,
              w: 47 * 0.971,
              h: 47 * 0.971,
              src: rootPath + 'img/hum.png',
            });
            break;
        }
        hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK, objMaskCover);
        if (!aodModel) {
          timePointerProp = {
            ...timePointerProp,
            ...objSec,
          };
        } else {
          timePointerProp.minute_path = rootPath + 'min_aod.png';
        }
        let timePointer = hmUI.createWidget(
          hmUI.widget.TIME_POINTER,
          timePointerProp
        );
        let mask = hmUI.createWidget(
          hmUI.widget.WATCHFACE_EDIT_FG_MASK,
          objMask
        );

        hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 177 * 0.9708,
          y: 338 * 0.9708,
          w: 127 * 0.971,
          h: 85 * 0.971,
          type: dataType,
        });
        hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: function () {
            console.log('ui resume');
            animCreate.setProperty(hmUI.prop.VISIBLE, true);
            animCreate.setProperty(
              hmUI.prop.ANIM_STATUS,
              hmUI.anim_status.START
            );
          },
        });
      },

      onInit() {
        console.log('index page.js on init invoke');
        this.init_view();
      },

      onReady() {
        console.log('index page.js on ready invoke');
      },

      onShow() {
        console.log('index page.js on show invoke');
      },

      onHide() {
        console.log('index page.js on hide invoke');
      },

      onDestory() {
        console.log('index page.js on destory invoke');
      },
    });
    /*
     * end js
     */
  })();
} catch (e) {
  console.log(e + '');
}
