try {
  (() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__),
      'drink'
    );

    /*
     * huamiOS bundle tool v1.0.17
     * Copyright © Huami. All Rights Reserved
     */
    ('use strict');

    console.log('----->>>current');
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let bg = null;
    let clock_timer = null;
    let timeArray = [];
    let timeArray_xp = [];
    let dateArray = [];
    let weekArr_en = [];
    let weekArr_sc = [];
    // let weekArr_tc = null;
    let animate_sec = null;
    let animate_quan = null;
    let batArray = [];
    let stepArray = [];

    const rootPath = 'images/';

    // 资源填充

    for (let i = 0; i < 10; i++) {
      if (i < 7) {
        stepArray.push(rootPath + 'step/' + i + '.png');
      }
      timeArray.push(rootPath + 'time/' + i + '.png');
      timeArray_xp.push(rootPath + 'time_xp/' + i + '.png');
      dateArray.push(rootPath + 'date/' + i + '.png');
    }

    for (let i = 1; i < 8; i++) {
      if (i < 7) {
        batArray.push(rootPath + 'bat/' + i + '.png');
      }
      weekArr_en.push(rootPath + 'week_en/' + i + '.png');
      weekArr_sc.push(rootPath + 'week_sc/' + i + '.png');
    }

    // 配置对象

    const objTime = {
      hour_zero: 1,
      hour_startX: 168 * 0.9708,
      hour_startY: 115 * 0.9708,
      hour_array: timeArray_xp,
      hour_space: 0,
      hour_align: hmUI.align.LEFT,

      minute_zero: 1, //是否补零 1为补零
      minute_startX: 168 * 0.9708,
      minute_startY: 246 * 0.9708,
      minute_array: timeArray_xp,
      minute_space: 0, //两个图片间隔 对应GT2的interval
      minute_follow: 0, //是否跟随
      minute_align: hmUI.align.LEFT,

      am_x: 314 * 0.9708,
      am_y: 186 * 0.9708,
      am_sc_path: rootPath + 'img/am/scxp.png',
      am_en_path: rootPath + 'img/am/enxp.png',
      pm_x: 314 * 0.9708,
      pm_y: 186 * 0.9708,
      pm_sc_path: rootPath + 'img/pm/scxp.png',
      pm_en_path: rootPath + 'img/pm/enxp.png',
      show_level: hmUI.show_level.ONLY_AOD,
    };

    const objBgAod = {
      x: 0,
      y: 0,
      w: 466,
      h: 466,
      src: rootPath + 'img/bg_xp.png',
    };
    const objBg = {
      x: 0,
      y: 0,
      w: 466,
      h: 466,
      src: rootPath + 'img/bg.png',
    };

    const objUp = {
      x: 84 * 0.9708,
      y: 25 * 0.9708,
      src: rootPath + 'img/bat.png',
    };

    const objDown = {
      x: 171 * 0.9708,
      y: 338 * 0.9708,
      src: rootPath + 'img/step.png',
    };

    const objBat = {
      x: 84 * 0.9708,
      y: 25 * 0.9708,
      w: 228 * 0.9708,
      h: 116 * 0.9708,
      image_array: batArray,
      image_length: batArray.length, //长度
      type: hmUI.data_type.BATTERY,
    };

    const objStep = {
      x: 171 * 0.9708,
      y: 338 * 0.9708,
      w: 228 * 0.9708,
      h: 116 * 0.9708,
      image_array: stepArray,
      image_length: stepArray.length, //长度
      type: hmUI.data_type.STEP,
    };

    const objAnimateSec = {
      x: 0,
      y: 0,
      anim_path: rootPath + 'sec',
      anim_prefix: 'anim',
      anim_ext: 'png',
      anim_fps: 11,
      anim_size: 11,
      anim_repeat: true,
      repeat_count: 0, // 秒针循环播放
      anim_status: 1, // 设置秒针开始不播放
    };

    const objTimetext = {
      hour_zero: 1,
      hour_startX: 168 * 0.9708,
      hour_startY: 115 * 0.9708,
      hour_array: timeArray,
      hour_space: 0,
      hour_align: hmUI.align.LEFT,

      minute_zero: 1, //是否补零 1为补零
      minute_startX: 168 * 0.9708,
      minute_startY: 246 * 0.9708,
      minute_array: timeArray,
      minute_space: 0, //两个图片间隔 对应GT2的interval
      minute_follow: 0, //是否跟随
      minute_align: hmUI.align.LEFT,

      am_x: 314 * 0.9708,
      am_y: 186 * 0.9708,
      am_sc_path: rootPath + 'img/am/sc.png',
      am_en_path: rootPath + 'img/am/en.png',
      pm_x: 314 * 0.9708,
      pm_y: 186 * 0.9708,
      pm_sc_path: rootPath + 'img/pm/sc.png',
      pm_en_path: rootPath + 'img/pm/en.png',
      show_level: hmUI.show_level.ONLY_NORMAL,
    };

    const objWeek = {
      x: 316 * 0.9708,
      y: 268 * 0.9708,
      week_en: weekArr_en,
      week_tc: weekArr_sc,
      week_sc: weekArr_sc,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };

    const objStatus = {
      month_startX: 328 * 0.9708,
      month_startY: 256 * 0.9708,
      month_unit_sc: rootPath + 'img/mon.png',
      month_unit_tc: rootPath + 'img/mon.png',
      month_unit_en: rootPath + 'img/mon.png',
      month_align: hmUI.align.LEFT,
      month_space: -3,
      month_zero: 1,
      // month_follow: 0,
      month_en_array: dateArray,
      month_sc_array: dateArray,
      month_tc_array: dateArray,
      //   day_startX: 398 * 0.9708,
      //   day_startY: 256 * 0.9708,
      day_align: hmUI.align.LEFT,
      day_space: -3,
      day_zero: 1,
      day_follow: 1,
      day_en_array: dateArray,
      day_sc_array: dateArray,
      day_tc_array: dateArray,
      //day_is_character: true,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    const logger = DeviceRuntimeCore.HmLogger.getLogger('default2');
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        // timeSensor = hmSensor.createSensor(hmSensor.id.TIME);

        var screenType = hmSetting.getScreenType();
        if (screenType == hmSetting.screen_type.AOD) {
          bg = hmUI.createWidget(hmUI.widget.IMG, objBgAod);
          let timeText2 = hmUI.createWidget(hmUI.widget.IMG_TIME, objTime);
        } else {
          bg = hmUI.createWidget(hmUI.widget.IMG, objBg);
          let up = hmUI.createWidget(hmUI.widget.IMG, objUp);
          let down = hmUI.createWidget(hmUI.widget.IMG, objDown);
          let bat = hmUI.createWidget(hmUI.widget.IMG_LEVEL, objBat);
          let step = hmUI.createWidget(hmUI.widget.IMG_LEVEL, objStep);

          animate_quan = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
            x: 0,
            y: 0,
            anim_path: rootPath + 'quan',
            anim_prefix: 'quan',
            anim_ext: 'png',
            anim_fps: 25,
            anim_size: 27,
            anim_repeat: false,
            repeat_count: 1,
            anim_status: 1, //
            anim_complete_call: secAnimatePlay,
          });
          animate_sec = hmUI.createWidget(hmUI.widget.IMG_ANIM, objAnimateSec);
          animate_sec.setProperty(hmUI.prop.VISIBLE, false);

          let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, objTimetext);
          let week = hmUI.createWidget(hmUI.widget.IMG_WEEK, objWeek);
          let status = hmUI.createWidget(hmUI.widget.IMG_DATE, objStatus);
        }

        function secAnimatePlay() {
          animate_sec.setProperty(hmUI.prop.VISIBLE, true);
          animate_sec.setProperty(hmUI.ANIM_STATUS, hmUI.anim_status.START);
        }
        const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: function () {
            animate_quan.setProperty(
              hmUI.prop.ANIM_STATUS,
              hmUI.anim_status.START
            );
          },
          pause_call: function () {
            animate_quan.setProperty(
              hmUI.prop.ANIM_STATUS,
              hmUI.anim_status.STOP
            );
            animate_sec.setProperty(hmUI.prop.VISIBLE, false);
          },
        });
      },

      onInit() {
        console.log('index page.js on init invoke');

        this.init_view();
      },

      onReady() {
        console.log('index page.js on ready invoke');
      },

      onShow() {
        console.log('index page.js on show invoke');
      },

      onHide() {
        console.log('index page.js on hide invoke');
      },

      onDestory() {
        console.log('index page.js on destory invoke');
        timer.stopTimer(clock_timer);
      },
    });
    /*
     * end js
     */
  })();
} catch (e) {
  console.log(e);
}
