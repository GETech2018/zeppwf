try {
    (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;

        var __$$module$$__ = __$$app$$__.current;
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        /*
         * huamiOS bundle tool v1.0.17
         * Copyright © Huami. All Rights Reserved
         */
        'use strict';
        let screenType = null
        console.log("----->>>current")
        console.log(__$$hmAppManager$$__.currentApp.pid)
        console.log(__$$hmAppManager$$__.currentApp.current)

        const WIDGET_LEFT_ID = 101;
        const WIDGET_TOP_ID = 102;
        const WIDGET_BOTTOM_ID = 103;
        const WIDGET_RIGHT_ID = 104;

        const WIDGET_TOP = 1;
        const WIDGET_LEFT = 2;
        const WIDGET_BOTTOM = 3;
        const WIDGET_RIGHT = 4;
        const WIDGET_EDIT_SIZE = 174 * 0.9708;
        // const WIDGET_TIPS_WIDTH = 106;
        const ROOTPATH = "images/";
        const WIDGET_BG_PATH = ROOTPATH + "widget/bg/";
        const WIDGET_POINTER_PATH = ROOTPATH + "root/time/data.png";

        let WIDGET_FONT_ARRAY = []
        let WEEK_ARRAY = []
        let WEATHER_ARRAY = []
        let enWeekArray = []
        let dayArray = []
        let jumpWhereTop, jumpWhereLeft, jumpWhereRight, jumpWhereBottom
        for (let i = 0; i < 10; i++) {
            WIDGET_FONT_ARRAY.push(ROOTPATH + `root/bat/${i}.png`)
        }

        for (let i = 1; i < 8; i++) {
            WEEK_ARRAY.push(ROOTPATH + `root/week/${i}.png`)
        }

        for (let i = 0; i < 29; i++) {
            WEATHER_ARRAY.push(ROOTPATH + `root/weather/${i}.png`)
        }

        for (let i = 1; i < 13; i++) {
            enWeekArray.push(ROOTPATH + `root/month/monthArr_en/${i}.png`)
        }

        for (let i = 0; i < 10; i++) {
            dayArray.push(ROOTPATH + `root/day/${i}.png`)
        }

        const WIDGET_TIPS_WIDTH = 102 * 0.9708;
        const widgetPreview = ROOTPATH + "widget_preview1/"
        const TIPS_ROOT = ROOTPATH + "tips/"
        const WIDGET_TIPS_PATH = TIPS_ROOT + "widget_tips1.png";

        let select = null
        let topWidget = null
        let leftWidget = null
        let bottomWidget = null
        let rightWidget = null

        const logger = DeviceRuntimeCore.HmLogger.getLogger("sanjiao");
        __$$module$$__.module = DeviceRuntimeCore.Page({
            parseWidgetConfig(editType) {
                let config = {
                    bgPath: null, //背景图
                    iconPath: null, //图标
                    dataType: null, //数据类型
                    nonePath: null, //无数据的图片
                    negativeImage: null,
                    unitEnPath: null, //单位
                    unitScPath: null,
                    unitTcPath: null,
                    spPath: null,
                    pointerType: null,
                    startAngle: 0, //指针开始角度
                    endAngle: 360, //指针结束角度
                };
                switch (editType) {
                    case hmUI.edit_type.STEP:
                        config.bgPath = "steps.png";
                        config.dataType = hmUI.data_type.STEP;
                        config.startAngle = -120
                        config.endAngle = 120
                        break;
                    case hmUI.edit_type.CAL:
                        config.bgPath = "cal.png";
                        config.dataType = hmUI.data_type.CAL;
                        config.startAngle = -120
                        config.endAngle = 120
                        break;
                    case hmUI.edit_type.PAI:
                        config.bgPath = "pai.png";
                        config.dataType = hmUI.data_type.PAI_WEEKLY;
                        config.startAngle = -90
                        config.endAngle = 90
                        break;
                    case hmUI.edit_type.BATTERY:
                        config.bgPath = "bat.png";
                        config.dataType = hmUI.data_type.BATTERY;
                        config.unitEnPath = ROOTPATH + "root/bat/precent.png";
                        config.unitScPath = ROOTPATH + "root/bat/precent.png";
                        config.unitTcPath = ROOTPATH + "root/bat/precent.png";
                        config.startAngle = -90
                        config.endAngle = 90
                        break;
                    case hmUI.edit_type.TIME:
                        config.bgPath = "bat.png";
                        config.dataType = hmUI.data_type.TIME;
                        break;

                    case hmUI.edit_type.HUMIDITY:
                        config.bgPath = "humi.png";
                        config.iconPath = "hum.png";
                        config.dataType = hmUI.data_type.HUMIDITY;
                        config.nonePath = ROOTPATH + "root/bat/none.png";
                        config.unitEnPath = ROOTPATH + "root/bat/precent.png";
                        config.unitScPath = ROOTPATH + "root/bat/precent.png";
                        config.unitTcPath = ROOTPATH + "root/bat/precent.png";
                        config.startAngle = -120
                        config.endAngle = 120
                        break;
                    case hmUI.edit_type.UVI:
                        config.bgPath = "uvi.png";
                        config.dataType = hmUI.data_type.UVI;
                        config.spPath = ROOTPATH + "root/bat/sp.png"; //   /
                        config.unitEnPath = ROOTPATH + "root/bat/du.png"; // du
                        config.unitScPath = ROOTPATH + "root/bat/du.png";
                        config.unitTcPath = ROOTPATH + "root/bat/du.png";
                        config.nonePath = ROOTPATH + "root/bat/none.png";
                        break;
                    // case hmUI.edit_type.AQI:
                    //     config.bgPath = "aqi.png"; 
                    //     config.dataType = hmUI.data_type.AQI;
                    //     config.spPath = ROOTPATH + "root/bat/sp.png"; //   /
                    //     config.unitEnPath = ROOTPATH + "root/bat/du.png";  // du
                    //     config.unitScPath = ROOTPATH + "root/bat/du.png";
                    //     config.unitTcPath = ROOTPATH + "root/bat/du.png"; 
                    //     config.nonePath = ROOTPATH + "root/bat/none.png";
                    //     break;
                    default:
                        // console.log("invalid editType type=" + editType);
                        return config;
                }

                if (config.bgPath != null) {
                    config.bgPath = WIDGET_BG_PATH + config.bgPath;
                }

                if (config.pointerType == null) {
                    config.pointerType = config.dataType;
                }
                return config;
            },
            drawWidget(widgetType, editType) {
                let bgX = 0;
                let bgY = 0;
                let textX = 0;
                let textY = 0;
                let pointCenterX = 0
                let pointCenterY = 0
                const bgSize = 187 * 0.9708;
                switch (widgetType) {
                    case WIDGET_TOP:
                        bgX = 153.3 * 0.9708;
                        bgY = 29.6 * 0.9708;
                        textX = bgX + 20 * 0.9708;
                        textY = bgY + 108 * 0.9708;
                        pointCenterX = 239 * 0.9708
                        pointCenterY = 117 * 0.9708

                        break;
                    case WIDGET_LEFT:
                        bgX = 30 * 0.9708;
                        bgY = 153.3 * 0.9708;
                        textX = bgX + 20 * 0.9708;
                        textY = bgY + 110 * 0.9708;
                        pointCenterX = 115 * 0.9708
                        pointCenterY = 239 * 0.9708

                        break;
                    case WIDGET_BOTTOM:
                        bgX = 153.3 * 0.9708;
                        bgY = 282 * 0.9708;
                        textX = bgX + 20 * 0.9708;
                        textY = bgY + 108 * 0.9708;
                        pointCenterX = 237.8 * 0.9708
                        pointCenterY = 370 * 0.9708

                        break;
                    case WIDGET_RIGHT:
                        bgX = 275.95 * 0.9708;
                        bgY = 153.3 * 0.9708;
                        textX = bgX + 20 * 0.9708;
                        textY = bgY + 108 * 0.9708;
                        pointCenterX = 361.8 * 0.9708
                        pointCenterY = 239 * 0.9708

                        break;
                    default:
                        // console.log("invalid widgetType type=" + widgetType);
                        return;
                }

                const textWidth = 134 * 0.9708;
                const textHeight = 34 * 0.9708;
                const config = this.parseWidgetConfig(editType);

                if (config.dataType == null) {
                    // console.log("invalid arg dataType is null");
                    return;
                }
                if (config.bgPath == null) {
                    // console.log("invalid arg bgpath is null");
                    return;
                }

                //widgetbg 
                if (config.dataType == hmUI.data_type.TIME) {
                    hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                        x: bgX,
                        y: bgY,
                        week_en: WEEK_ARRAY,
                        week_tc: WEEK_ARRAY,
                        week_sc: WEEK_ARRAY,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });

                    let monthTxt1 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
                        year_startX: bgX,
                        year_startY: bgY,
                        year_align: hmUI.align.LEFT,
                        year_space: 1,
                        year_zero: 1,
                        year_follow: 1,

                        month_startX: bgX + 55 * 0.9708,
                        month_startY: bgY + 68 * 0.9708,
                        month_align: hmUI.align.CENTER_H,
                        month_space: 1,
                        month_zero: 1,
                        month_follow: 0,
                        month_en_array: enWeekArray,
                        month_sc_array: enWeekArray,
                        month_tc_array: enWeekArray,
                        month_is_character: true,
                        show_level: hmUI.show_level.ALL,

                        show_level: hmUI.show_level.ONLY_NORMAL,
                        day_startX: bgX + 70 * 0.9708,
                        day_startY: bgY + 125 * 0.9708,
                        day_zero: true,
                        day_en_array: dayArray,
                    })
                } else if (config.dataType == hmUI.data_type.BATTERY ||
                    config.dataType == hmUI.data_type.CAL ||
                    config.dataType == hmUI.data_type.HUMIDITY ||
                    config.dataType == hmUI.data_type.PAI_WEEKLY ||
                    config.dataType == hmUI.data_type.STEP

                ) {
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: bgX,
                        y: bgY,
                        w: bgSize,
                        h: bgSize,
                        src: config.bgPath,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    //指针

                    hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                        center_x: pointCenterX,
                        center_y: pointCenterY,
                        x: 21 * 0.9708,
                        y: 60 * 0.9708,
                        src: WIDGET_POINTER_PATH,
                        type: config.dataType,
                        start_angle: config.startAngle,
                        end_angle: config.endAngle,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                } else if (config.dataType == hmUI.data_type.AQI || config.dataType == hmUI.data_type.UVI) {
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: bgX,
                        y: bgY,
                        w: bgSize,
                        h: bgSize,
                        src: config.bgPath,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    var arrayImg = []
                    if (config.dataType == hmUI.data_type.AQI) {
                        arrayImg = [
                            ROOTPATH + "root/aqi/1.png",
                            ROOTPATH + "root/aqi/2.png",
                            ROOTPATH + "root/aqi/3.png",
                            ROOTPATH + "root/aqi/4.png",
                            ROOTPATH + "root/aqi/5.png",
                        ];
                    } else {
                        arrayImg = [
                            ROOTPATH + "root/uvi/1.png",
                            ROOTPATH + "root/uvi/2.png",
                            ROOTPATH + "root/uvi/3.png",
                            ROOTPATH + "root/uvi/4.png",
                            ROOTPATH + "root/uvi/5.png",
                        ];
                    }
                    hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                        x: bgX + 8 * 0.9708,
                        y: bgY + 8 * 0.9708,
                        image_array: arrayImg,
                        image_length: arrayImg.length,
                        type: config.dataType,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });


                    let WEATHER_ICON = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                        x: bgX + 65 * 0.9708,
                        y: bgY + 40 * 0.9708,
                        image_array: WEATHER_ARRAY,
                        image_length: WEATHER_ARRAY.length,
                        type: hmUI.data_type.WEATHER,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    if (screenType != hmSetting.screen_type.AOD) {
                        var weatherLow = hmUI.createWidget(hmUI.widget.TEXT_IMG);
                        //创建低温控件
                        weatherLow.setProperty(hmUI.prop.MORE, {
                            //低温控件设置属性
                            x: bgX + 54 * 0.9708,
                            y: bgY + 100 * 0.9708,
                            // W:120,
                            // x: bgX + 100,
                            // y: bgY + 100,
                            type: hmUI.data_type.WEATHER_LOW,
                            font_array: WIDGET_FONT_ARRAY,
                            h_space: 0,
                            align_h: 0,
                            unit_sc: ROOTPATH + "root/bat/sp.png",
                            unit_en: ROOTPATH + "root/bat/sp.png",
                            unit_tc: ROOTPATH + "root/bat/sp.png",
                            // unit_sc: ROOTPATH + "root/bat/du.png",
                            // //单位
                            // unit_tc: ROOTPATH + "root/bat/du.png",
                            // //单位
                            // unit_en: ROOTPATH + "root/bat/du.png",
                            negative_image: ROOTPATH + "root/bat/fuhao.png",
                            invalid_image: ROOTPATH + "root/bat/none1.png",
                            show_level: hmUI.show_level.ONLY_NORMAL
                        });
                        var weatherHigh = hmUI.createWidget(hmUI.widget.TEXT_IMG);
                        //创建高温控件
                        weatherHigh.layoutChange(function (obj) {
                            //监听高温控件坐标大小变化 

                            var end_X = weatherLow.getProperty(hmUI.prop.END_X);
                            //获取低温控件的endX
                            // weatherLow.setProperty(hmUI.prop.X, end_X);
                            weatherHigh.setProperty(hmUI.prop.X, end_X);
                            //设置给高温
                        });
                        weatherHigh.setProperty(hmUI.prop.MORE, {
                            //高温控件设置属性
                            x: bgX + 54 * 0.9708,
                            y: bgY + 100 * 0.9708,
                            // W:120,
                            type: hmUI.data_type.WEATHER_HIGH,
                            font_array: WIDGET_FONT_ARRAY,
                            h_space: 0,
                            align_h: 0,
                            // unit_sc: ROOTPATH + "root/bat/sp.png",
                            // unit_en: ROOTPATH + "root/bat/sp.png",
                            // unit_tc: ROOTPATH + "root/bat/sp.png",
                            unit_sc: ROOTPATH + "root/bat/du.png",
                            //单位
                            unit_tc: ROOTPATH + "root/bat/du.png",
                            //单位
                            unit_en: ROOTPATH + "root/bat/du.png",
                            negative_image: ROOTPATH + "root/bat/fuhao.png",
                            invalid_image: ROOTPATH + "root/bat/none0.png",
                            show_level: hmUI.show_level.ONLY_NORMAL
                        });
                    }
                    //天气高低温演示

                }

                if (config.dataType != hmUI.data_type.TIME &&
                    config.dataType != hmUI.data_type.AQI &&
                    config.dataType != hmUI.data_type.UVI) {
                    let dataProp = {
                        x: textX,
                        y: textY,
                        w: textWidth,
                        h: textHeight,
                        align_h: hmUI.align.CENTER_H,
                        type: config.dataType,
                        h_space: 1,
                        font_array: WIDGET_FONT_ARRAY,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    };
                    if (config.unitEnPath != null) {
                        dataProp.unit_en = config.unitEnPath;
                    }
                    if (config.unitScPath != null) {
                        dataProp.unit_sc = config.unitScPath;
                    }
                    if (config.unitTcPath != null) {
                        dataProp.unit_tc = config.unitTcPath;
                    }
                    if (config.nonePath != null) {
                        dataProp.invalid_image = config.nonePath;
                    }
                    if (config.spPath != null) {
                        dataProp.dot_image = config.spPath;
                    }
                    if (config.negativeImage != null) {
                        dataProp.negative_image = config.negativeImage;
                    }
                    //数据
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, dataProp);
                }
                // hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                //     x: bgX,
                //     y: bgY,
                //     w: 150,
                //     h: 150,
                //     type:config.dataType, //必写 跳转的action
                // });
            },
            init_view() {
                screenType = hmSetting.getScreenType();
                select = ROOTPATH + "select/"
                var img_bg1 = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 466,
                    h: 466,
                    src: ROOTPATH + "bg/bg.png",
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                var img_bg2 = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 466,
                    h: 466,
                    src: ROOTPATH + "bg/xpbg.png",
                    show_level: hmUI.show_level.ONAL_AOD,
                });

                let widgetOptionalArray = [{
                    type: hmUI.edit_type.STEP,
                    preview: widgetPreview + "steps.png"
                },
                {
                    type: hmUI.edit_type.CAL,
                    preview: widgetPreview + "cal.png"
                },
                {
                    type: hmUI.edit_type.PAI,
                    preview: widgetPreview + "pai.png"
                },
                {
                    type: hmUI.edit_type.BATTERY,
                    preview: widgetPreview + "bat.png"
                },
                {
                    type: hmUI.edit_type.HUMIDITY,
                    preview: widgetPreview + "humi.png"
                },
                {
                    type: hmUI.edit_type.UVI,
                    preview: widgetPreview + "uvi.png"
                },
                // { type: hmUI.edit_type.AQI, preview: widgetPreview + "aqi.png" }, 
                {
                    type: hmUI.edit_type.TIME,
                    preview: widgetPreview + "slice.png"
                },
                ];

                let edit_list_config = {
                    title_font_size: 34,
                    title_align_h: hmUI.align.CENTER_H,
                    list_item_vspace: 8,
                    list_bg_color: 0x0000,
                    list_bg_radius: 30,
                    list_group_text_font_size: 32,
                    list_group_text_align_h: hmUI.align.CENTER_H,
                    list_tips_text_font_size: 32,
                    list_tips_text_align_h: hmUI.align.LEFT,
                };

                let groupX = 153.3 * 0.9708;
                let groupY = 29.6 * 0.9708;
                //可编辑组件
                topWidget = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: WIDGET_TOP_ID,
                    x: groupX,
                    y: groupY,
                    w: WIDGET_EDIT_SIZE,
                    h: WIDGET_EDIT_SIZE,
                    select_image: select + "select.png",
                    un_select_image: select + "unselect.png",
                    default_type: hmUI.edit_type.BATTERY,
                    optional_types: widgetOptionalArray,
                    count: widgetOptionalArray.length,
                    tips_BG: WIDGET_TIPS_PATH,
                    tips_x: 35 * 0.9708,
                    tips_y: 178 * 0.9708,
                    tips_width: WIDGET_TIPS_WIDTH,
                    tips_margin: 10 * 0.9708,
                    select_list: edit_list_config, // 新增配置选项
                });

                var editType = topWidget.getProperty(hmUI.prop.CURRENT_TYPE);
                this.drawWidget(WIDGET_TOP, editType);

                groupX = 30.66 * 0.9708;
                groupY = 153.3 * 0.9708;
                leftWidget = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: WIDGET_LEFT_ID,
                    x: groupX,
                    y: groupY,
                    w: WIDGET_EDIT_SIZE,
                    h: WIDGET_EDIT_SIZE,
                    select_image: select + "select.png",
                    un_select_image: select + "unselect.png",
                    default_type: hmUI.edit_type.STEP,
                    optional_types: widgetOptionalArray,
                    count: widgetOptionalArray.length,
                    tips_BG: WIDGET_TIPS_PATH,
                    tips_x: 35 * 0.9708,
                    tips_y: -40 * 0.9708,
                    tips_width: WIDGET_TIPS_WIDTH,
                    tips_margin: 10 * 0.9708,
                    select_list: edit_list_config, // 新增配置选项
                });

                editType = leftWidget.getProperty(hmUI.prop.CURRENT_TYPE);
                this.drawWidget(WIDGET_LEFT, editType);

                groupX = 153.3 * 0.9708;
                groupY = 277 * 0.9708;
                bottomWidget = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: WIDGET_BOTTOM_ID,
                    x: groupX,
                    y: groupY,
                    w: WIDGET_EDIT_SIZE,
                    h: WIDGET_EDIT_SIZE,
                    select_image: select + "select.png",
                    un_select_image: select + "unselect.png",
                    default_type: hmUI.edit_type.TIME,
                    optional_types: widgetOptionalArray,
                    count: widgetOptionalArray.length,
                    tips_BG: WIDGET_TIPS_PATH,
                    tips_x: 35 * 0.9708,
                    tips_y: -40 * 0.9708,
                    tips_width: WIDGET_TIPS_WIDTH,
                    tips_margin: 10 * 0.9708,
                    select_list: edit_list_config, // 新增配置选项
                });

                editType = bottomWidget.getProperty(hmUI.prop.CURRENT_TYPE);
                this.drawWidget(WIDGET_BOTTOM, editType);




                groupX = 276.95 * 0.9708;
                groupY = 153.3 * 0.9708;
                rightWidget = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: WIDGET_RIGHT_ID,
                    x: groupX,
                    y: groupY,
                    w: WIDGET_EDIT_SIZE,
                    h: WIDGET_EDIT_SIZE,
                    select_image: select + "select.png",
                    un_select_image: select + "unselect.png",
                    default_type: hmUI.edit_type.UVI,
                    optional_types: widgetOptionalArray,
                    count: widgetOptionalArray.length,
                    tips_BG: WIDGET_TIPS_PATH,
                    tips_x: 35 * 0.9708,
                    tips_y: -40 * 0.9708,
                    tips_width: WIDGET_TIPS_WIDTH,
                    tips_margin: 10 * 0.9708,
                    select_list: edit_list_config, // 新增配置选项
                });

                editType = rightWidget.getProperty(hmUI.prop.CURRENT_TYPE);
                this.drawWidget(WIDGET_RIGHT, editType);


                // 息屏状态

                var TIME_POINTER_PARAM = null
                if (screenType == hmSetting.screen_type.AOD) {
                    TIME_POINTER_PARAM = {
                        hour_centerX: 240 * 0.9708, //指针旋转中心 对应centerX
                        hour_centerY: 240 * 0.9708, //指针旋转中心 对应centerY
                        hour_posX: 35 * 0.9708, //指针自身旋转中心 对应positioin中的x
                        hour_posY: 149 * 0.9708, //指针自身旋转中心 对应positioin中的y
                        hour_path: ROOTPATH + "root/time/h.png",
                        //指针路径 
                        minute_centerX: 240 * 0.9708, //指针旋转中心 对应centerX
                        minute_centerY: 240 * 0.9708, //指针旋转中心 对应centerY
                        minute_posX: 35 * 0.9708, //指针自身旋转中心 对应positioin中的x
                        minute_posY: 225 * 0.9708, //指针自身旋转中心 对应positioin中的y
                        minute_path: ROOTPATH + "root/time/m.png",

                        //指针路径
                        minute_cover_path: ROOTPATH + "root/time/center.png",
                        //指针圆心图片
                        minute_cover_y: 224 * 0.9708,
                        minute_cover_x: 224 * 0.9708,

                    }
                } else {
                    TIME_POINTER_PARAM = {
                        hour_centerX: 240 * 0.9708, //指针旋转中心 对应centerX
                        hour_centerY: 240 * 0.9708, //指针旋转中心 对应centerY
                        hour_posX: 35 * 0.9708, //指针自身旋转中心 对应positioin中的x
                        hour_posY: 149 * 0.9708, //指针自身旋转中心 对应positioin中的y
                        hour_path: ROOTPATH + "root/time/h.png",
                        //指针路径

                        minute_centerX: 240 * 0.9708, //指针旋转中心 对应centerX
                        minute_centerY: 240 * 0.9708, //指针旋转中心 对应centerY
                        minute_posX: 35 * 0.9708, //指针自身旋转中心 对应positioin中的x
                        minute_posY: 225 * 0.9708, //指针自身旋转中心 对应positioin中的y
                        minute_path: ROOTPATH + "root/time/m.png",
                        //指针路径

                        second_centerX: 240 * 0.9708, //指针旋转中心 对应centerX
                        second_centerY: 240 * 0.9708, //指针旋转中心 对应centerY
                        second_posX: 36 * 0.9708, //指针自身旋转中心 对应positioin中的x
                        second_posY: 226 * 0.9708, //指针自身旋转中心 对应positioin中的y
                        second_path: ROOTPATH + "root/time/s.png",
                        //指针路径
                        // second_cover_path: ROOTPATH + "root/time/center.png",
                        //指针圆心图片
                        // second_cover_y: 224,
                        // second_cover_x: 224,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    }
                }
                let timePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, TIME_POINTER_PARAM);

                let mask70 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
                    x: 0,
                    y: 0,
                    w: 466,
                    h: 466,
                    src: ROOTPATH + "mask100.png",
                    show_level: hmUI.show_level.ONLY_EDIT,
                });
                let mask100 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
                    x: 0,
                    y: 0,
                    w: 466,
                    h: 466,
                    src: ROOTPATH + "mask70.png",
                    show_level: hmUI.show_level.ONLY_EDIT,
                });

                //----------------------
                let editTypeTop = topWidget.getProperty(hmUI.prop.CURRENT_TYPE)
                let editTypeLeft = leftWidget.getProperty(hmUI.prop.CURRENT_TYPE)
                let editTypeBottom = bottomWidget.getProperty(hmUI.prop.CURRENT_TYPE)
                let editTypeRight = rightWidget.getProperty(hmUI.prop.CURRENT_TYPE)
                switch (editTypeTop) {
                    case hmUI.edit_type.HEART:
                        jumpWhereTop = "heart_app_Screen";
                        break;
                    case hmUI.edit_type.STEP:
                    case hmUI.edit_type.CAL:
                    case hmUI.edit_type.FAT_BURN:
                    case hmUI.edit_type.STAND:
                        jumpWhereTop = "activityAppScreen";
                        break;
                    case hmUI.edit_type.ALARM_CLOCK:
                        jumpWhereTop = "AlarmInfoScreen";
                        break;
                    case hmUI.edit_type.STRESS:
                        jumpWhereTop = "StressHomeScreen";
                        break;
                    case hmUI.edit_type.UVI:
                    case hmUI.edit_type.WEATHER:
                    case hmUI.edit_type.HUMIDITY:
                        jumpWhereTop = "WeatherScreen";
                        break;
                }
                switch (editTypeLeft) {
                    case hmUI.edit_type.HEART:
                        jumpWhereLeft = "heart_app_Screen";
                        break;
                    case hmUI.edit_type.STEP:
                    case hmUI.edit_type.CAL:
                    case hmUI.edit_type.FAT_BURN:
                    case hmUI.edit_type.STAND:
                        jumpWhereLeft = "activityAppScreen";
                        break;
                    case hmUI.edit_type.ALARM_CLOCK:
                        jumpWhereLeft = "AlarmInfoScreen";
                        break;
                    case hmUI.edit_type.STRESS:
                        jumpWhereLeft = "StressHomeScreen";
                        break;
                    case hmUI.edit_type.UVI:
                    case hmUI.edit_type.WEATHER:
                    case hmUI.edit_type.HUMIDITY:
                        jumpWhereLeft = "WeatherScreen";
                        break;
                }
                switch (editTypeBottom) {
                    case hmUI.edit_type.HEART:
                        jumpWhereBottom = "heart_app_Screen";
                        break;
                    case hmUI.edit_type.STEP:
                    case hmUI.edit_type.CAL:
                    case hmUI.edit_type.FAT_BURN:
                    case hmUI.edit_type.STAND:
                        jumpWhereBottom = "activityAppScreen";
                        break;
                    case hmUI.edit_type.ALARM_CLOCK:
                        jumpWhereBottom = "AlarmInfoScreen";
                        break;
                    case hmUI.edit_type.STRESS:
                        jumpWhereBottom = "StressHomeScreen";
                        break;
                    case hmUI.edit_type.UVI:
                    case hmUI.edit_type.WEATHER:
                    case hmUI.edit_type.HUMIDITY:
                        jumpWhereBottom = "WeatherScreen";
                        break;
                }
                switch (editTypeRight) {
                    case hmUI.edit_type.HEART:
                        jumpWhereRight = "heart_app_Screen";
                        break;
                    case hmUI.edit_type.STEP:
                    case hmUI.edit_type.CAL:
                    case hmUI.edit_type.FAT_BURN:
                    case hmUI.edit_type.STAND:
                        jumpWhereRight = "activityAppScreen";
                        break;
                    case hmUI.edit_type.ALARM_CLOCK:
                        jumpWhereRight = "AlarmInfoScreen";
                        break;
                    case hmUI.edit_type.STRESS:
                        jumpWhereRight = "StressHomeScreen";
                        break;
                    case hmUI.edit_type.UVI:
                    case hmUI.edit_type.WEATHER:
                    case hmUI.edit_type.HUMIDITY:
                        jumpWhereRight = "WeatherScreen";
                        break;
                }
                function fnSetImg(x, y, w, h) {
                    return hmUI.createWidget(hmUI.widget.IMG, {
                        x,
                        y,
                        w,
                        h,
                        enable: true, //false不接收点击事件
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                }

                function fnJump(btn, appname) {
                    return btn.addEventListener(hmUI.event.CLICK_UP, function (info) {
                        hmApp.startApp({
                            url: appname,
                            native: true
                        });
                    });
                }
                if (editTypeTop === hmUI.edit_type.PAI) {
                    let click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 175,
                        y: 57,
                        w: 117,
                        h: 117,
                        type: hmUI.data_type.PAI_WEEKLY, //必写 跳转的action
                    });
                }
                else {
                    topClick = fnSetImg(175, 57, 117, 117)
                    fnJump(topClick, jumpWhereTop)
                }

                if (editTypeLeft === hmUI.edit_type.PAI) {
                    let click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 55,
                        y: 174,
                        w: 117,
                        h: 117,
                        type: hmUI.data_type.PAI_WEEKLY, //必写 跳转的action
                    });
                }
                else {
                    leftClick = fnSetImg(55, 174, 117, 117)
                    fnJump(leftClick, jumpWhereLeft)
                }

                if (editTypeRight === hmUI.edit_type.PAI) {
                    let click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 279,
                        y: 174,
                        w: 117,
                        h: 117,
                        type: hmUI.data_type.PAI_WEEKLY, //必写 跳转的action
                    });
                }
                else {
                    rightClick = fnSetImg(279, 174, 117, 117)
                    fnJump(rightClick, jumpWhereRight)
                }

                if (editTypeBottom === hmUI.edit_type.PAI) {
                    let click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 175,
                        y: 274,
                        w: 117,
                        h: 117,
                        type: hmUI.data_type.PAI_WEEKLY, //必写 跳转的action
                    });
                }
                else {
                    bottomClick = fnSetImg(175, 274, 117, 117)
                    fnJump(bottomClick, jumpWhereBottom)
                }

            },

            onInit() {
                console.log('index page.js on init invoke')
                this.init_view();
            },

            onReady() {
                console.log('index page.js on ready invoke')
            },

            onShow() {
                console.log('index page.js on show invoke')
            },

            onHide() {
                console.log('index page.js on hide invoke')
            },

            onDestory() {
                console.log('index page.js on destory invoke')
            },
        });
        /*
         * end js
         */
    })()
} catch (e) {
    console.log(e)
}