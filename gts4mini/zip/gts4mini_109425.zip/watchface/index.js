try {
  (() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__),
      "drink"
    );

    /*
     * huamiOS bundle tool v1.0.17
     * Copyright © Huami. All Rights Reserved
     */
    ("use strict");

    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let rootPath = "images/";
    let arrWeatherLevel = [];
    let arrWeatherNum = [];
    let timeArray = [];
    let numArray = [];
    let monthArray = [];

    for (let i = 0; i < 10; i++) {
      timeArray.push(rootPath + 'time/' + i + '.png')
      arrWeatherNum.push(rootPath + 'weatherNum/' + i + '.png')
      numArray.push(rootPath + 'num/' + i + '.png')
    }
    for (let i = 1; i < 13; i++) {
      monthArray.push(rootPath + 'month/' + i + '.png')
    }
    for (let i = 0; i < 29; i++) {
      arrWeatherLevel.push(rootPath + 'weatherLevel/' + i + '.png')
    }

    let obj_bg = {//背景
      x: 0,
      y: 0,
      // w: 336,
      // h: 387,
      src: rootPath + 'bg.png',
      show_level: hmUI.show_level.ONLY_NORMAL,
    }
    let batObj = {//电量
      x: 87,
      y: 119,
      type: hmUI.data_type.BATTERY,
      font_array: numArray,
      h_space: 0, //图片间隔
      align_h: hmUI.align.CENTER_H,
      padding: false, //是否补零 true为补零
      unit_sc: rootPath + "num/per.png",
      unit_tc: rootPath + "num/per.png",
      unit_en: rootPath + "num/per.png",
      show_level: hmUI.show_level.ONLY_NORMAL,
    };

    let stepObj = {//步数
      x: 159,
      y: 279,
      w: 60,
      type: hmUI.data_type.STEP,
      font_array: numArray,
      h_space: 0, //图片间隔
      align_h: hmUI.align.CENTER_H,
      padding: false, //是否补零 true为补零
      show_level: hmUI.show_level.ONLY_NORMAL,
    }
    const heartObj = {//心率
      x: 174,
      y: 338,
      w: 36,
      h: 16,
      type: hmUI.data_type.HEART,
      font_array: numArray,
      h_space: 0,
      align_h: hmUI.align.CENTER_H,
      invalid_image: rootPath + "num/null.png",
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    let objWeatherLevel = { //天气图标
      x: 39,
      y: 168,
      image_array: arrWeatherLevel,
      image_length: arrWeatherLevel.length,
      type: hmUI.data_type.WEATHER_CURRENT,
      show_level: hmUI.show_level.ONLY_NORMAL,
    }
    let distanceObj = {//距离
      x: 163,
      y: 308,
      // w: 95,
      type: hmUI.data_type.DISTANCE,
      font_array: numArray,
      h_space: -1, //图片间隔
      align_h: hmUI.align.LEFT,
      invalid_image: rootPath + "num/null.png", //无数据显示
      dot_image: rootPath + "num/symbol.png", //小数点
      unit_sc: "images/num/km.png", //单位
      unit_tc: "images/num/km.png", //单位
      unit_en: "images/num/km.png", //单位
      padding: false, //是否补零 true为补零
      show_level: hmUI.show_level.ONLY_NORMAL,
    }
    let weatherObj = {//温度
      x: 32,
      y: 216,
      w: 58,
      h: 30,
      type: hmUI.data_type.WEATHER_CURRENT,
      font_array: arrWeatherNum,
      h_space: 0, //图片间隔
      align_h: hmUI.align.CENTER_H,
      padding: false, //是否补零 true为补零
      invalid_image: rootPath + "weatherNum/null.png",
      negative_image: rootPath + "weatherNum/fu.png",
      unit_sc: rootPath + "weatherNum/du.png",
      unit_tc: rootPath + "weatherNum/du.png",
      unit_en: rootPath + "weatherNum/du.png",
      show_level: hmUI.show_level.ONLY_NORMAL,
    }
    let timeObj = {//时间
      hour_zero: true,
      hour_startX: 114,
      hour_startY: 160,
      hour_array: timeArray,
      hour_space: 0,
      hour_unit_sc: rootPath + "time/mao.png", //单位
      hour_unit_tc: rootPath + "time/mao.png",
      hour_unit_en: rootPath + "time/mao.png",
      hour_align: hmUI.align.LEFT,
      minute_zero: 1, //是否补零 1为补零
      minute_array: timeArray,
      minute_startX: 220,
      minute_startY: 160,
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD,
    }
    let objWeatherClick = { //使用IMGCLICK控件传入组件对应类型
      x: 28,
      y: 169,
      w: 65,
      h: 80,
      type: hmUI.data_type.WEATHER,
    }
    let objStepClick = { //使用IMGCLICK控件传入组件对应类型
      x: 82,
      y: 276,
      w: 170,
      h: 20,
      type: hmUI.data_type.STEP,
    }
    let heartClick = { //使用IMGCLICK控件传入组件对应类型
      x: 108,
      y: 337,
      w: 119,
      h: 23,
      type: hmUI.data_type.HEART,
    }
    let distanceClick = {
      x: 86,
      y: 307,
      w: 159,
      h: 23,
      type: hmUI.data_type.DISTANCE,
    }
    //日期（简体/繁体）
    let objDate = {
      month_startX: 258,
      month_startY: 118,
      month_align: hmUI.align.LEFT,
      month_zero: 0, //是否补零
      month_is_character: true,
      month_sc_array: monthArray,
      month_tc_array: monthArray,
      month_en_array: monthArray,

      day_startX: 229,
      day_startY: 119,
      day_follow: 0,//是否跟随
      day_zero: 1, //是否补零
      day_en_array: numArray,
      day_sc_array: numArray,
      day_tc_array: numArray,
      show_level: hmUI.show_level.ONLY_NORMAL,
    }

    const logger = DeviceRuntimeCore.HmLogger.getLogger("defult");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({

      init_view() {
        hmUI.createWidget(hmUI.widget.IMG, obj_bg)
        hmUI.createWidget(hmUI.widget.TEXT_IMG, heartObj);
        hmUI.createWidget(hmUI.widget.TEXT_IMG, batObj);
        hmUI.createWidget(hmUI.widget.TEXT_IMG, stepObj);
        hmUI.createWidget(hmUI.widget.TEXT_IMG, weatherObj);
        hmUI.createWidget(hmUI.widget.IMG_TIME, timeObj);
        hmUI.createWidget(hmUI.widget.IMG_DATE, objDate);
        hmUI.createWidget(hmUI.widget.IMG_LEVEL, objWeatherLevel)
        let distanceText = hmUI.createWidget(hmUI.widget.TEXT_IMG, distanceObj);

        // distanceText.layoutChange(function (obj) {
        //   // let end_X = distanceText.getProperty(hmUI.prop.END_X);
        //   // let distX = 156 + (64 - end_X) / 2
        //   distanceText.setProperty(hmUI.prop.X, distX);
        // });

        hmUI.createWidget(hmUI.widget.IMG_CLICK, objWeatherClick)
        hmUI.createWidget(hmUI.widget.IMG_CLICK, objStepClick)
        hmUI.createWidget(hmUI.widget.IMG_CLICK, heartClick)
        hmUI.createWidget(hmUI.widget.IMG_CLICK, distanceClick)
      },

      onInit() {
        console.log("index page.js on init invoke");
        this.init_view();
      },

      onReady() {
        console.log("index page.js on ready invoke");
      },

      onShow() {
        console.log("index page.js on show invoke");
      },

      onHide() {
        console.log("index page.js on hide invoke");
      },

      onDestory() {
        console.log("index page.js on destory invoke");
      },
    });
    /*
     * end js
     */
  })();
} catch (e) {
  console.log(e);
}