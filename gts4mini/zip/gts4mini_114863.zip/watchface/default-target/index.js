try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface6');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.FILL_RECT, {
                    x: 0,
                    y: 0,
                    w: 336,
                    h: 384,
                    color: '0xFF000000',
                    radius: 80,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_val: new Date().getHours(),
                    hour_zero: 1,
                    hour_startX: 95,
                    hour_startY: 85,
                    hour_array: [
                        '2.png',
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png'
                    ],
                    hour_space: -9,
                    hour_align: hmUI.align.CENTER_H,
                    minute_val: new Date().getMinutes(),
                    minute_zero: 1,
                    minute_startX: 95,
                    minute_startY: 185,
                    minute_array: [
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png'
                    ],
                    minute_space: -9,
                    minute_align: hmUI.align.CENTER_H,
                    minute_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    year_startX: 110,
                    year_startY: 290,
                    year_sc_array: [
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png'
                    ],
                    year_tc_array: [
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png'
                    ],
                    year_en_array: [
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png'
                    ],
                    year_align: hmUI.align.CENTER_H,
                    year_zero: 1,
                    year_space: 0,
                    year_is_character: false,
                    month_startX: 175,
                    month_startY: 290,
                    month_sc_array: [
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png'
                    ],
                    month_tc_array: [
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png'
                    ],
                    month_en_array: [
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png'
                    ],
                    month_unit_sc: '42.png',
                    month_unit_tc: '42.png',
                    month_unit_en: '42.png',
                    month_align: hmUI.align.CENTER_H,
                    month_zero: 1,
                    month_follow: 0,
                    month_space: 0,
                    month_is_character: false,
                    day_startX: 210,
                    day_startY: 290,
                    day_sc_array: [
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png'
                    ],
                    day_tc_array: [
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png'
                    ],
                    day_en_array: [
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png'
                    ],
                    day_align: hmUI.align.CENTER_H,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 0,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 145,
                    y: 305,
                    week_en: [
                        '53.png',
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png',
                        '58.png',
                        '59.png'
                    ],
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 62,
                    y: 12,
                    type: hmUI.data_type.HEART,
                    font_array: [
                        '60.png',
                        '61.png',
                        '62.png',
                        '63.png',
                        '64.png',
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '70.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 30,
                    y: 5,
                    src: '71.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 230,
                    y: 12,
                    type: hmUI.data_type.BATTERY,
                    font_array: [
                        '72.png',
                        '73.png',
                        '74.png',
                        '75.png',
                        '76.png',
                        '77.png',
                        '78.png',
                        '79.png',
                        '80.png',
                        '81.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '82.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 270,
                    y: 5,
                    src: '83.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 148,
                    y: 0,
                    image_array: [
                        '84.png',
                        '85.png',
                        '86.png',
                        '87.png',
                        '88.png',
                        '89.png',
                        '90.png',
                        '91.png',
                        '92.png',
                        '93.png',
                        '94.png',
                        '95.png',
                        '96.png',
                        '97.png',
                        '98.png',
                        '99.png',
                        '100.png',
                        '101.png',
                        '102.png',
                        '103.png',
                        '104.png',
                        '105.png',
                        '106.png',
                        '107.png',
                        '108.png',
                        '109.png',
                        '110.png',
                        '111.png',
                        '112.png'
                    ],
                    image_length: 29,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 152,
                    y: 50,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: [
                        '113.png',
                        '114.png',
                        '115.png',
                        '116.png',
                        '117.png',
                        '118.png',
                        '119.png',
                        '120.png',
                        '121.png',
                        '122.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '125.png',
                    unit_tc: '125.png',
                    unit_en: '125.png',
                    negative_image: '124.png',
                    invalid_image: '123.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 198,
                    y: 50,
                    type: hmUI.data_type.WEATHER_HIGH,
                    font_array: [
                        '126.png',
                        '127.png',
                        '128.png',
                        '129.png',
                        '130.png',
                        '131.png',
                        '132.png',
                        '133.png',
                        '134.png',
                        '135.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '138.png',
                    unit_tc: '138.png',
                    unit_en: '138.png',
                    negative_image: '137.png',
                    invalid_image: '136.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 102,
                    y: 50,
                    type: hmUI.data_type.WEATHER_LOW,
                    font_array: [
                        '139.png',
                        '140.png',
                        '141.png',
                        '142.png',
                        '143.png',
                        '144.png',
                        '145.png',
                        '146.png',
                        '147.png',
                        '148.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '151.png',
                    unit_tc: '151.png',
                    unit_en: '151.png',
                    negative_image: '150.png',
                    invalid_image: '149.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 70,
                    y: 355,
                    type: hmUI.data_type.STEP,
                    font_array: [
                        '152.png',
                        '153.png',
                        '154.png',
                        '155.png',
                        '156.png',
                        '157.png',
                        '158.png',
                        '159.png',
                        '160.png',
                        '161.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '162.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 150,
                    y: 348,
                    src: '163.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 185,
                    y: 355,
                    type: hmUI.data_type.DISTANCE,
                    font_array: [
                        '164.png',
                        '165.png',
                        '166.png',
                        '167.png',
                        '168.png',
                        '169.png',
                        '170.png',
                        '171.png',
                        '172.png',
                        '173.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '176.png',
                    unit_tc: '176.png',
                    unit_en: '176.png',
                    imperial_unit_sc: '177.png',
                    imperial_unit_tc: '177.png',
                    imperial_unit_en: '177.png',
                    dot_image: '175.png',
                    invalid_image: '174.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 10,
                    y: 285,
                    type: hmUI.data_type.CAL,
                    font_array: [
                        '178.png',
                        '179.png',
                        '180.png',
                        '181.png',
                        '182.png',
                        '183.png',
                        '184.png',
                        '185.png',
                        '186.png',
                        '187.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '188.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 25,
                    y: 250,
                    src: '189.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 18,
                    y: 200,
                    type: hmUI.data_type.SPO2,
                    font_array: [
                        '190.png',
                        '191.png',
                        '192.png',
                        '193.png',
                        '194.png',
                        '195.png',
                        '196.png',
                        '197.png',
                        '198.png',
                        '199.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '200.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 25,
                    y: 170,
                    src: '201.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 18,
                    y: 125,
                    type: hmUI.data_type.STRESS,
                    font_array: [
                        '202.png',
                        '203.png',
                        '204.png',
                        '205.png',
                        '206.png',
                        '207.png',
                        '208.png',
                        '209.png',
                        '210.png',
                        '211.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '212.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 25,
                    y: 90,
                    src: '213.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 275,
                    y: 125,
                    type: hmUI.data_type.UVI,
                    font_array: [
                        '214.png',
                        '215.png',
                        '216.png',
                        '217.png',
                        '218.png',
                        '219.png',
                        '220.png',
                        '221.png',
                        '222.png',
                        '223.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '224.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 275,
                    y: 90,
                    src: '225.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 270,
                    y: 200,
                    type: hmUI.data_type.HUMIDITY,
                    font_array: [
                        '226.png',
                        '227.png',
                        '228.png',
                        '229.png',
                        '230.png',
                        '231.png',
                        '232.png',
                        '233.png',
                        '234.png',
                        '235.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '236.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 275,
                    y: 170,
                    src: '237.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 270,
                    y: 285,
                    type: hmUI.data_type.AQI,
                    font_array: [
                        '238.png',
                        '239.png',
                        '240.png',
                        '241.png',
                        '242.png',
                        '243.png',
                        '244.png',
                        '245.png',
                        '246.png',
                        '247.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '248.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 275,
                    y: 250,
                    src: '249.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_val: new Date().getHours(),
                    hour_zero: 1,
                    hour_startX: 95,
                    hour_startY: 85,
                    hour_array: [
                        '2.png',
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png'
                    ],
                    hour_space: -9,
                    hour_align: hmUI.align.CENTER_H,
                    minute_val: new Date().getMinutes(),
                    minute_zero: 1,
                    minute_startX: 95,
                    minute_startY: 185,
                    minute_array: [
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png'
                    ],
                    minute_space: -9,
                    minute_align: hmUI.align.CENTER_H,
                    minute_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    year_startX: 110,
                    year_startY: 290,
                    year_sc_array: [
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png'
                    ],
                    year_tc_array: [
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png'
                    ],
                    year_en_array: [
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png'
                    ],
                    year_align: hmUI.align.CENTER_H,
                    year_zero: 1,
                    year_space: 0,
                    year_is_character: false,
                    month_startX: 175,
                    month_startY: 290,
                    month_sc_array: [
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png'
                    ],
                    month_tc_array: [
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png'
                    ],
                    month_en_array: [
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png'
                    ],
                    month_unit_sc: '42.png',
                    month_unit_tc: '42.png',
                    month_unit_en: '42.png',
                    month_align: hmUI.align.CENTER_H,
                    month_zero: 1,
                    month_follow: 0,
                    month_space: 0,
                    month_is_character: false,
                    day_startX: 210,
                    day_startY: 290,
                    day_sc_array: [
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png'
                    ],
                    day_tc_array: [
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png'
                    ],
                    day_en_array: [
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png'
                    ],
                    day_align: hmUI.align.CENTER_H,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 0,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 145,
                    y: 305,
                    week_en: [
                        '53.png',
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png',
                        '58.png',
                        '59.png'
                    ],
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 62,
                    y: 12,
                    type: hmUI.data_type.HEART,
                    font_array: [
                        '60.png',
                        '61.png',
                        '62.png',
                        '63.png',
                        '64.png',
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_AOD,
                    invalid_image: '70.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 30,
                    y: 5,
                    src: '71.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 230,
                    y: 12,
                    type: hmUI.data_type.BATTERY,
                    font_array: [
                        '72.png',
                        '73.png',
                        '74.png',
                        '75.png',
                        '76.png',
                        '77.png',
                        '78.png',
                        '79.png',
                        '80.png',
                        '81.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_AOD,
                    invalid_image: '82.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 270,
                    y: 5,
                    src: '83.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 70,
                    y: 355,
                    type: hmUI.data_type.STEP,
                    font_array: [
                        '152.png',
                        '153.png',
                        '154.png',
                        '155.png',
                        '156.png',
                        '157.png',
                        '158.png',
                        '159.png',
                        '160.png',
                        '161.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_AOD,
                    invalid_image: '162.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 150,
                    y: 348,
                    src: '163.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 185,
                    y: 355,
                    type: hmUI.data_type.DISTANCE,
                    font_array: [
                        '164.png',
                        '165.png',
                        '166.png',
                        '167.png',
                        '168.png',
                        '169.png',
                        '170.png',
                        '171.png',
                        '172.png',
                        '173.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_AOD,
                    unit_sc: '176.png',
                    unit_tc: '176.png',
                    unit_en: '176.png',
                    imperial_unit_sc: '177.png',
                    imperial_unit_tc: '177.png',
                    imperial_unit_en: '177.png',
                    dot_image: '175.png',
                    invalid_image: '174.png',
                    padding: false,
                    isCharacter: false
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}