try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_19e30da42714407f8061291ea0b00b45 = '';
        let dateFormat = '';
        let dateFormatMap = '';
        let idle$_$text_d4c1bc5865654d199a6e13e3b58374ab = '';
        let timeSensor = '';
        const logger = Logger.getLogger('watchface6');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 336,
                    h: 384,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 168,
                    hour_centerY: 192,
                    hour_posX: 8,
                    hour_posY: 102,
                    hour_path: '3.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 168,
                    minute_centerY: 192,
                    minute_posX: 8,
                    minute_posY: 149,
                    minute_path: '4.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    second_centerX: 168,
                    second_centerY: 192,
                    second_posX: 3,
                    second_posY: 157,
                    second_path: '5.png',
                    second_cover_x: 0,
                    second_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 131,
                    y: 299,
                    type: hmUI.data_type.STEP,
                    font_array: [
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 3,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: false,
                    isCharacter: false
                });
                normal$_$text_19e30da42714407f8061291ea0b00b45 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 118,
                    y: 128,
                    w: 100,
                    h: 40,
                    text: '- [DAY_Z] -',
                    color: '0xFFffffff',
                    text_size: 17,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 336,
                    h: 384,
                    src: '16.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 168,
                    hour_centerY: 192,
                    hour_posX: 8,
                    hour_posY: 102,
                    hour_path: '17.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 168,
                    minute_centerY: 192,
                    minute_posX: 8,
                    minute_posY: 149,
                    minute_path: '18.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 131,
                    y: 299,
                    type: hmUI.data_type.STEP,
                    font_array: [
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 3,
                    show_level: hmUI.show_level.ONLY_AOD,
                    padding: false,
                    isCharacter: false
                });
                idle$_$text_d4c1bc5865654d199a6e13e3b58374ab = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 118,
                    y: 128,
                    w: 100,
                    h: 40,
                    text: '- [DAY_Z] -',
                    color: '0xFF808080',
                    text_size: 17,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                if (!timeSensor) {
                    timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                }
                timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_19e30da42714407f8061291ea0b00b45.setProperty(hmUI.prop.MORE, { text: `- ${ String(timeSensor.day).padStart(2, '0') } -` });
                        },
                        () => {
                            normal$_$text_19e30da42714407f8061291ea0b00b45.setProperty(hmUI.prop.MORE, { text: `- ${ String(timeSensor.day).padStart(2, '0') } -` });
                        },
                        () => {
                            normal$_$text_19e30da42714407f8061291ea0b00b45.setProperty(hmUI.prop.MORE, { text: `- ${ String(timeSensor.day).padStart(2, '0') } -` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            idle$_$text_d4c1bc5865654d199a6e13e3b58374ab.setProperty(hmUI.prop.MORE, { text: `- ${ String(timeSensor.day).padStart(2, '0') } -` });
                        },
                        () => {
                            idle$_$text_d4c1bc5865654d199a6e13e3b58374ab.setProperty(hmUI.prop.MORE, { text: `- ${ String(timeSensor.day).padStart(2, '0') } -` });
                        },
                        () => {
                            idle$_$text_d4c1bc5865654d199a6e13e3b58374ab.setProperty(hmUI.prop.MORE, { text: `- ${ String(timeSensor.day).padStart(2, '0') } -` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                });
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                normal$_$text_19e30da42714407f8061291ea0b00b45.setProperty(hmUI.prop.MORE, { text: `- ${ String(timeSensor.day).padStart(2, '0') } -` });
                            },
                            () => {
                                normal$_$text_19e30da42714407f8061291ea0b00b45.setProperty(hmUI.prop.MORE, { text: `- ${ String(timeSensor.day).padStart(2, '0') } -` });
                            },
                            () => {
                                normal$_$text_19e30da42714407f8061291ea0b00b45.setProperty(hmUI.prop.MORE, { text: `- ${ String(timeSensor.day).padStart(2, '0') } -` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                idle$_$text_d4c1bc5865654d199a6e13e3b58374ab.setProperty(hmUI.prop.MORE, { text: `- ${ String(timeSensor.day).padStart(2, '0') } -` });
                            },
                            () => {
                                idle$_$text_d4c1bc5865654d199a6e13e3b58374ab.setProperty(hmUI.prop.MORE, { text: `- ${ String(timeSensor.day).padStart(2, '0') } -` });
                            },
                            () => {
                                idle$_$text_d4c1bc5865654d199a6e13e3b58374ab.setProperty(hmUI.prop.MORE, { text: `- ${ String(timeSensor.day).padStart(2, '0') } -` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}