try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface6');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 336,
                    h: 384,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_val: new Date().getHours(),
                    hour_zero: 1,
                    hour_startX: 18,
                    hour_startY: 83,
                    hour_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    hour_space: -3,
                    hour_align: hmUI.align.CENTER_H,
                    minute_zero: 1,
                    minute_startX: 166,
                    minute_startY: 160,
                    minute_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    minute_space: -3,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 145,
                    month_startY: 56,
                    month_sc_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    month_tc_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    month_en_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    month_align: hmUI.align.CENTER_H,
                    month_zero: 1,
                    month_follow: 0,
                    month_space: -3,
                    month_is_character: false,
                    day_startX: 111,
                    day_startY: 56,
                    day_sc_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    day_tc_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    day_en_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    day_align: hmUI.align.CENTER_H,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: -3,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 136,
                    y: 56,
                    src: '23.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 56,
                    y: 56,
                    week_en: [
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png'
                    ],
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 223,
                    y: 345,
                    type: hmUI.data_type.BATTERY,
                    font_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: -3,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '32.png',
                    unit_tc: '32.png',
                    unit_en: '32.png',
                    invalid_image: '31.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 231,
                    y: 56,
                    type: hmUI.data_type.DISTANCE,
                    font_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: -3,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '35.png',
                    unit_tc: '35.png',
                    unit_en: '35.png',
                    imperial_unit_sc: '36.png',
                    imperial_unit_tc: '36.png',
                    imperial_unit_en: '36.png',
                    dot_image: '34.png',
                    invalid_image: '33.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 106,
                    y: 345,
                    type: hmUI.data_type.HEART,
                    font_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: -3,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '37.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 100,
                    y: 12,
                    type: hmUI.data_type.STEP,
                    font_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: -3,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '38.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 76,
                    y: 301,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -3,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '41.png',
                    unit_tc: '41.png',
                    unit_en: '41.png',
                    negative_image: '40.png',
                    invalid_image: '39.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 179,
                    y: 301,
                    type: hmUI.data_type.WEATHER_HIGH,
                    font_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: -3,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '44.png',
                    unit_tc: '44.png',
                    unit_en: '44.png',
                    negative_image: '43.png',
                    invalid_image: '42.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 264,
                    y: 301,
                    type: hmUI.data_type.WEATHER_LOW,
                    font_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: -3,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '47.png',
                    unit_tc: '47.png',
                    unit_en: '47.png',
                    negative_image: '46.png',
                    invalid_image: '45.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 228,
                    y: 12,
                    type: hmUI.data_type.CAL,
                    font_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: -3,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '48.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 336,
                    h: 384,
                    src: '49.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_val: new Date().getHours(),
                    hour_zero: 1,
                    hour_startX: 18,
                    hour_startY: 83,
                    hour_array: [
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png',
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png',
                        '58.png',
                        '59.png'
                    ],
                    hour_space: -3,
                    hour_align: hmUI.align.CENTER_H,
                    minute_zero: 1,
                    minute_startX: 166,
                    minute_startY: 160,
                    minute_array: [
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png',
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png',
                        '58.png'
                    ],
                    minute_space: -3,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 164,
                    y: 338,
                    type: hmUI.data_type.BATTERY,
                    font_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: -3,
                    show_level: hmUI.show_level.ONLY_AOD,
                    unit_sc: '32.png',
                    unit_tc: '32.png',
                    unit_en: '32.png',
                    invalid_image: '31.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 157,
                    y: 20,
                    type: hmUI.data_type.STEP,
                    font_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: -3,
                    show_level: hmUI.show_level.ONLY_AOD,
                    invalid_image: '38.png',
                    padding: false,
                    isCharacter: false
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}