try {
  (() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');
    /*
  * huamiOS bundle tool v1.0.17
  * Copyright © Huami. All Rights Reserved
  */
    'use strict';
    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let nAmPmX = 233
    let nAmPmY = 210
    let nHourX = 32
    let nHourY = 238
    let nMinuteX = 174
    let nWeekX = 125
    let nWeekY = 322
    let nMonthX = 41
    let nMonthY = 321
    // let nDayX = 20
    // let nDayY = 258


    
    let arrData = [];
    let arrWeek = [];
    let arrWeekSc = [];
    let arrTime = [];
    let arrAodTime = [];
    let arrPower = [];
    for (let i = 0; i < 10; i++) {     
      arrData.push(`images/data/${i}.png`)
      arrTime.push(`images/time/${i}.png`)
      arrAodTime.push(`images/aodtime/${i}.png`)
      arrPower.push(`images/power/${i}.png`)
    }
    for (let i = 1; i < 8; i++) {
      arrWeek.push(`images/week/${i}.png`)
      arrWeekSc.push(`images/week/sc/${i}.png`)
    }
    const objWeekOption = {
      x: nWeekX,
      y: nWeekY,
      week_en: arrWeek,
      week_sc: arrWeekSc,
      week_tc: arrWeekSc,
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD
    }
    let objTime = {
      hour_zero: true,
      hour_startX: nHourX,
      hour_startY: nHourY,
      hour_array: arrTime,
      hour_align: hmUI.align.LEFT,
      hour_unit_sc: "images/time/dot.png",
      hour_unit_tc: "images/time/dot.png",
      hour_unit_en: "images/time/dot.png",
      hour_space: -5,
      minute_zero: true,
      minute_startX: nMinuteX,
      minute_startY: nHourY,
      minute_array: arrTime,
      minute_align: hmUI.align.LEFT,
      minute_space: -5,
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD,
    }   
    let objMonthOption = {
      month_startX: nMonthX,
      month_startY: nMonthY,
      month_zero: 1,
      month_en_array: arrData,
      month_sc_array: arrData,
      month_tc_array: arrData,
      month_unit_sc: "images/data/pron.png", //单位
      month_unit_tc: "images/data/pron.png",
      month_unit_en: "images/data/pron.png",
      month_space: -1,//文字间隔
      // day_startX: nDayX,
      // day_startY: nDayY,
      day_follow: 1,
      day_zero: 1,
      day_space: -1,//文字间隔
      day_en_array: arrData,
      day_sc_array: arrData,
      day_tc_array: arrData,
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD,
    }
    let objAmPm = {
      am_x: nAmPmX,
      am_y: nAmPmY,
      am_sc_path: "images/ampm/amtc.png",
      am_en_path: "images/ampm/am.png",
      pm_x: nAmPmX,
      pm_y: nAmPmY,
      pm_sc_path: "images/ampm/pmtc.png",
      pm_en_path: "images/ampm/pm.png",
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD,
    }
    let objImg = { //表盘底层背景
      x: 0,
      y: 0,
      src: "images/bg/bg.png",
      show_level: hmUI.show_level.ONLY_NORMAL,
    }
    let objHeartImg = { //表盘底层背景
      x: 223,
      y: 332,
      src: "images/data/heart.png",    
    }
    let objHeartText = {  // 心率数值
      x: 247,
      y: 320,  
      padding:true,
      type: hmUI.data_type.HEART,
      font_array: arrData,
      align_h: hmUI.align.LEFT,
      invalid_image: "images/data/invalid.png",
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD,
    }
    const logger = DeviceRuntimeCore.HmLogger.getLogger("defult");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        hmUI.createWidget(hmUI.widget.IMG, objImg)
        hmUI.createWidget(hmUI.widget.IMG, objHeartImg)
        hmUI.createWidget(hmUI.widget.IMG_WEEK, objWeekOption)
        hmUI.createWidget(hmUI.widget.IMG_TIME, objTime)
        hmUI.createWidget(hmUI.widget.IMG_TIME, objAmPm)
        hmUI.createWidget(hmUI.widget.IMG_DATE, objMonthOption)
        hmUI.createWidget(hmUI.widget.TEXT_IMG, objHeartText)  
      },
      onInit() {
        console.log('index page.js on init invoke');
        this.init_view();
      },
      onReady() {
        console.log('index page.js on ready invoke')
      },
      onShow() {
        console.log('index page.js on show invoke')
      },
      onHide() {
        console.log('index page.js on hide invoke')
      },
      onDestory() {
        console.log('index page.js on destory invoke')
      },
    });
    /*
    * end js
    */
  })()
} catch (e) {
  console.log(e)
}
