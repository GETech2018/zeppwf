try {
  (() => {
  
var __$$app$$__ = __$$hmAppManager$$__.currentApp;

  /*
* huamiOS bundle tool v1.0.17
* Copyright © Huami. All Rights Reserved
*/
'use strict';

__$$app$$__.app = DeviceRuntimeCore.App({
    globalData: {},
    onCreate(options) {
    },
    onShow(options) {
    },
    onHide(options) {
    },
    onDestory(options) {
    },
    onError(error) {
    },
    onPageNotFound(obj) {
    },
    onUnhandledRejection(obj) {
    }
});
/*
* end js
*/

  })()
} catch(e) {
  console.log(e)
  /* todo */
}