try {
  (() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');
    /*
  * huamiOS bundle tool v1.0.17
  * Copyright © Huami. All Rights Reserved
  */
    'use strict';
    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let nHourX = 22
    let nHourY = 25
    let nMinuteX = 22
    let nMinuteY = 195

   
    let arrHourLeft = [];
    let arrHourRight = [];
    let arrMinuteLeft = [];
    let arrMinuteRight = [];
    let arrAodTime = [];   
    for (let i = 0; i < 10; i++) {    
      arrHourLeft.push(`images/time/hour/left/${i}.png`)
      arrHourRight.push(`images/time/hour/right/${i}.png`)
      arrMinuteLeft.push(`images/time/minute/left/${i}.png`)
      arrMinuteRight.push(`images/time/minute/right/${i}.png`)
      arrAodTime.push(`images/aodtime/${i}.png`)     
    } 
    let objAodTime = {
      hour_zero: true,
      hour_startX: nHourX,
      hour_startY: nHourY,
      hour_array: arrAodTime,
      hour_align: hmUI.align.LEFT,
      // hour_unit_sc: "images/time/dot.png",
      // hour_unit_tc: "images/time/dot.png",
      // hour_unit_en: "images/time/dot.png",
      hour_space: 0,
      minute_zero: true,
      minute_startX: nMinuteX,
      minute_startY: nMinuteY,
      minute_array: arrAodTime,
      minute_align: hmUI.align.LEFT,
      minute_space: 0,
      show_level: hmUI.show_level.ONAL_AOD,
    }
    // let objAodTime = { ...objTime }
    // objAodTime.hour_array = arrAodTime
    // objAodTime.minute_array = arrAodTime
    // objAodTime.show_level = hmUI.show_level.ONAL_AOD   

    let objImg = { //表盘底层背景
      x: 0,
      y: 0,
      src: "images/bg/bg.png",
      show_level: hmUI.show_level.ONLY_NORMAL,
    }  
    let objPublicStyle = {
      x: 22,
      y: 25,
      w: 146,
      h: 164,
      show_level: hmUI.show_level.ONLY_NORMAL,
    }
    let objHourLeft = {
      ...objPublicStyle,
    }
    let objHourRight = {
      ...objPublicStyle,
      x: 168,
      y: 25,
    }
    let objMinuteLeft = {
      ...objPublicStyle,
      x: 22,
      y: 195,
    }
    let objMinuteRight = {
      ...objPublicStyle,
      x: 168,
      y: 195,
    } 
    const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
    function setImgPath(widget, font, index) {
      widget.setProperty(hmUI.prop.SRC, font[index]);
    }
    function fnSetTime() {
      setImgPath(objHourLeft, arrHourLeft, parseInt(timeSensor.format_hour / 10));
      setImgPath(objHourRight, arrHourRight, parseInt(timeSensor.format_hour % 10));
      setImgPath(objMinuteLeft, arrMinuteLeft, parseInt(timeSensor.minute / 10));
      setImgPath(objMinuteRight, arrMinuteRight, parseInt(timeSensor.minute % 10));
    }
    const logger = DeviceRuntimeCore.HmLogger.getLogger("defult");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        hmUI.createWidget(hmUI.widget.IMG, objImg)       
        hmUI.createWidget(hmUI.widget.IMG_TIME, objAodTime)  
        objHourRight = hmUI.createWidget(hmUI.widget.IMG, objHourRight);
        objHourLeft = hmUI.createWidget(hmUI.widget.IMG, objHourLeft);
        objMinuteRight = hmUI.createWidget(hmUI.widget.IMG, objMinuteRight);
        objMinuteLeft = hmUI.createWidget(hmUI.widget.IMG, objMinuteLeft);    
       
        fnSetTime()       
        hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: (function () {
            console.log('ui resume');
            fnSetTime()          
          }),
          pause_call: (function () {
            console.log('ui pause');
          }),
        });
        clock_timer = timer.createTimer(0, 1000, (function (option) {
          fnSetTime()         
        }));
      },
      onInit() {
        console.log('index page.js on init invoke');
        this.init_view();
      },
      onReady() {
        console.log('index page.js on ready invoke')
      },
      onShow() {
        console.log('index page.js on show invoke')
      },
      onHide() {
        console.log('index page.js on hide invoke')
      },
      onDestory() {
        console.log('index page.js on destory invoke')
      },
    });
    /*
    * end js
    */
  })()
} catch (e) {
  console.log(e)
}
