try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_8a93cc1f4b09489e85ac0129988f6166 = '';
        let normal$_$text_4f554d9149764b3dbb863e01eb750a23 = '';
        let normal$_$text_f054218405544b3185cd27a56ac35855 = '';
        let normal$_$text_a3d138494d694b3088bedc578f0b309a = '';
        let normal$_$text_d89b7b02b2fa499f82a0a0527af0a7e7 = '';
        let normal$_$text_adeb6635229d4c5db170d7b3bc3b8d5f = '';
        let idle$_$text_9fceb6c9bbb148d5889426cd31694ad4 = '';
        let idle$_$text_7d755ec88d3a43f5b0fe9e984444db37 = '';
        let batterySensor = '';
        const logger = Logger.getLogger('watchface6');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 336,
                    h: 384,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 17,
                    hour_startY: 40,
                    hour_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    hour_space: 4,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 151,
                    minute_startY: 40,
                    minute_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    minute_space: 4,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    second_zero: 1,
                    second_startX: 280,
                    second_startY: 95,
                    second_array: [
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png'
                    ],
                    second_space: 0,
                    second_align: hmUI.align.LEFT,
                    second_follow: 0,
                    am_x: 271,
                    am_y: 57,
                    am_en_path: '33.png',
                    pm_x: 271,
                    pm_y: 57,
                    pm_en_path: '34.png',
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 138,
                    y: 68,
                    w: 8,
                    h: 32,
                    src: '35.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 15,
                    y: 148,
                    type: hmUI.data_type.PAI_WEEKLY,
                    font_array: [
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 31,
                    y: 181,
                    src: '46.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 81,
                    y: 148,
                    type: hmUI.data_type.HEART,
                    font_array: [
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png',
                        '54.png',
                        '55.png',
                        '56.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '57.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 98,
                    y: 176,
                    w: 16,
                    h: 15,
                    src: '58.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 237,
                    y: 149,
                    type: hmUI.data_type.STEP,
                    font_array: [
                        '59.png',
                        '60.png',
                        '61.png',
                        '62.png',
                        '63.png',
                        '64.png',
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: false,
                    isCharacter: false
                });
                normal$_$text_8a93cc1f4b09489e85ac0129988f6166 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 132,
                    y: 163,
                    w: 100,
                    h: 40,
                    text: 'Calories',
                    color: '0xFFffffff',
                    text_size: 17,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 148,
                    y: 148,
                    type: hmUI.data_type.CAL,
                    font_array: [
                        '69.png',
                        '70.png',
                        '71.png',
                        '72.png',
                        '73.png',
                        '74.png',
                        '75.png',
                        '76.png',
                        '77.png',
                        '78.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: false,
                    isCharacter: false
                });
                normal$_$text_4f554d9149764b3dbb863e01eb750a23 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 227,
                    y: 163,
                    w: 100,
                    h: 40,
                    text: 'Steps',
                    color: '0xFFffffff',
                    text_size: 17,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    year_startX: 194,
                    year_startY: 10,
                    year_sc_array: [
                        '79.png',
                        '80.png',
                        '81.png',
                        '82.png',
                        '83.png',
                        '84.png',
                        '85.png',
                        '86.png',
                        '87.png',
                        '88.png'
                    ],
                    year_tc_array: [
                        '79.png',
                        '80.png',
                        '81.png',
                        '82.png',
                        '83.png',
                        '84.png',
                        '85.png',
                        '86.png',
                        '87.png',
                        '88.png'
                    ],
                    year_en_array: [
                        '79.png',
                        '80.png',
                        '81.png',
                        '82.png',
                        '83.png',
                        '84.png',
                        '85.png',
                        '86.png',
                        '87.png',
                        '88.png'
                    ],
                    year_align: hmUI.align.LEFT,
                    year_zero: 1,
                    year_space: 0,
                    year_is_character: false,
                    month_startX: 87,
                    month_startY: 9,
                    month_sc_array: [
                        '89.png',
                        '90.png',
                        '91.png',
                        '92.png',
                        '93.png',
                        '94.png',
                        '95.png',
                        '96.png',
                        '97.png',
                        '98.png'
                    ],
                    month_tc_array: [
                        '89.png',
                        '90.png',
                        '91.png',
                        '92.png',
                        '93.png',
                        '94.png',
                        '95.png',
                        '96.png',
                        '97.png',
                        '98.png'
                    ],
                    month_en_array: [
                        '89.png',
                        '90.png',
                        '91.png',
                        '92.png',
                        '93.png',
                        '94.png',
                        '95.png',
                        '96.png',
                        '97.png',
                        '98.png'
                    ],
                    month_unit_sc: '99.png',
                    month_unit_tc: '99.png',
                    month_unit_en: '99.png',
                    month_align: hmUI.align.LEFT,
                    month_zero: 1,
                    month_follow: 0,
                    month_space: 0,
                    month_is_character: false,
                    day_startX: 140,
                    day_startY: 9,
                    day_sc_array: [
                        '100.png',
                        '101.png',
                        '102.png',
                        '103.png',
                        '104.png',
                        '105.png',
                        '106.png',
                        '107.png',
                        '108.png',
                        '109.png'
                    ],
                    day_tc_array: [
                        '100.png',
                        '101.png',
                        '102.png',
                        '103.png',
                        '104.png',
                        '105.png',
                        '106.png',
                        '107.png',
                        '108.png',
                        '109.png'
                    ],
                    day_en_array: [
                        '100.png',
                        '101.png',
                        '102.png',
                        '103.png',
                        '104.png',
                        '105.png',
                        '106.png',
                        '107.png',
                        '108.png',
                        '109.png'
                    ],
                    day_unit_sc: '110.png',
                    day_unit_tc: '110.png',
                    day_unit_en: '110.png',
                    day_align: hmUI.align.CENTER_H,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 0,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_f054218405544b3185cd27a56ac35855 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 229,
                    y: 238,
                    w: 100,
                    h: 40,
                    text: 'Weather',
                    color: '0xFFffffff',
                    text_size: 17,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 220,
                    y: 209,
                    image_array: [
                        '111.png',
                        '112.png',
                        '113.png',
                        '114.png',
                        '115.png',
                        '116.png',
                        '117.png',
                        '118.png',
                        '119.png',
                        '120.png',
                        '121.png',
                        '122.png',
                        '123.png',
                        '124.png',
                        '125.png',
                        '126.png',
                        '127.png',
                        '128.png',
                        '129.png',
                        '130.png',
                        '131.png',
                        '132.png',
                        '133.png',
                        '134.png',
                        '135.png',
                        '136.png',
                        '137.png',
                        '138.png',
                        '139.png'
                    ],
                    image_length: 29,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 268,
                    y: 219,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: [
                        '140.png',
                        '141.png',
                        '142.png',
                        '143.png',
                        '144.png',
                        '145.png',
                        '146.png',
                        '147.png',
                        '148.png',
                        '149.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '152.png',
                    unit_tc: '152.png',
                    unit_en: '152.png',
                    negative_image: '151.png',
                    invalid_image: '150.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 132,
                    y: 218,
                    type: hmUI.data_type.DISTANCE,
                    font_array: [
                        '59.png',
                        '60.png',
                        '61.png',
                        '62.png',
                        '63.png',
                        '64.png',
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    dot_image: '154.png',
                    invalid_image: '153.png',
                    padding: false,
                    isCharacter: false
                });
                normal$_$text_a3d138494d694b3088bedc578f0b309a = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 118,
                    y: 238,
                    w: 100,
                    h: 40,
                    text: 'Distance',
                    color: '0xFFffffff',
                    text_size: 17,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_d89b7b02b2fa499f82a0a0527af0a7e7 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 118,
                    y: 336,
                    w: 100,
                    h: 40,
                    text: '[BATT_PER]%',
                    color: '0xFFffffff',
                    text_size: 24,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 34,
                    y: 218,
                    type: hmUI.data_type.STRESS,
                    font_array: [
                        '59.png',
                        '60.png',
                        '61.png',
                        '62.png',
                        '63.png',
                        '64.png',
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '155.png',
                    padding: false,
                    isCharacter: false
                });
                normal$_$text_adeb6635229d4c5db170d7b3bc3b8d5f = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 8,
                    y: 238,
                    w: 100,
                    h: 40,
                    text: 'Stress',
                    color: '0xFFffffff',
                    text_size: 17,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 336,
                    h: 384,
                    src: '156.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 44,
                    hour_startY: 40,
                    hour_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    hour_space: 4,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 179,
                    minute_startY: 40,
                    minute_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    minute_space: 4,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 165,
                    y: 68,
                    w: 8,
                    h: 32,
                    src: '35.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    year_startX: 194,
                    year_startY: 10,
                    year_sc_array: [
                        '79.png',
                        '80.png',
                        '81.png',
                        '82.png',
                        '83.png',
                        '84.png',
                        '85.png',
                        '86.png',
                        '87.png',
                        '88.png'
                    ],
                    year_tc_array: [
                        '79.png',
                        '80.png',
                        '81.png',
                        '82.png',
                        '83.png',
                        '84.png',
                        '85.png',
                        '86.png',
                        '87.png',
                        '88.png'
                    ],
                    year_en_array: [
                        '79.png',
                        '80.png',
                        '81.png',
                        '82.png',
                        '83.png',
                        '84.png',
                        '85.png',
                        '86.png',
                        '87.png',
                        '88.png'
                    ],
                    year_align: hmUI.align.LEFT,
                    year_zero: 1,
                    year_space: 0,
                    year_is_character: false,
                    month_startX: 87,
                    month_startY: 9,
                    month_sc_array: [
                        '89.png',
                        '90.png',
                        '91.png',
                        '92.png',
                        '93.png',
                        '94.png',
                        '95.png',
                        '96.png',
                        '97.png',
                        '98.png'
                    ],
                    month_tc_array: [
                        '89.png',
                        '90.png',
                        '91.png',
                        '92.png',
                        '93.png',
                        '94.png',
                        '95.png',
                        '96.png',
                        '97.png',
                        '98.png'
                    ],
                    month_en_array: [
                        '89.png',
                        '90.png',
                        '91.png',
                        '92.png',
                        '93.png',
                        '94.png',
                        '95.png',
                        '96.png',
                        '97.png',
                        '98.png'
                    ],
                    month_unit_sc: '99.png',
                    month_unit_tc: '99.png',
                    month_unit_en: '99.png',
                    month_align: hmUI.align.LEFT,
                    month_zero: 1,
                    month_follow: 0,
                    month_space: 0,
                    month_is_character: false,
                    day_startX: 140,
                    day_startY: 9,
                    day_sc_array: [
                        '100.png',
                        '101.png',
                        '102.png',
                        '103.png',
                        '104.png',
                        '105.png',
                        '106.png',
                        '107.png',
                        '108.png',
                        '109.png'
                    ],
                    day_tc_array: [
                        '100.png',
                        '101.png',
                        '102.png',
                        '103.png',
                        '104.png',
                        '105.png',
                        '106.png',
                        '107.png',
                        '108.png',
                        '109.png'
                    ],
                    day_en_array: [
                        '100.png',
                        '101.png',
                        '102.png',
                        '103.png',
                        '104.png',
                        '105.png',
                        '106.png',
                        '107.png',
                        '108.png',
                        '109.png'
                    ],
                    day_unit_sc: '110.png',
                    day_unit_tc: '110.png',
                    day_unit_en: '110.png',
                    day_align: hmUI.align.CENTER_H,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 0,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                idle$_$text_9fceb6c9bbb148d5889426cd31694ad4 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 118,
                    y: 336,
                    w: 100,
                    h: 40,
                    text: '[BATT_PER]%',
                    color: '0xFFffffff',
                    text_size: 24,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                idle$_$text_7d755ec88d3a43f5b0fe9e984444db37 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 13,
                    y: 273,
                    w: 300,
                    h: 100,
                    text: 'Always on Display',
                    color: '0xFFffffff',
                    text_size: 22,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                if (!batterySensor) {
                    batterySensor = hmSensor.createSensor(hmSensor.id.BATTERY);
                }
                batterySensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_d89b7b02b2fa499f82a0a0527af0a7e7.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }%` });
                    idle$_$text_9fceb6c9bbb148d5889426cd31694ad4.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }%` });
                });
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        normal$_$text_8a93cc1f4b09489e85ac0129988f6166.setProperty(hmUI.prop.MORE, { text: `Calories` });
                        normal$_$text_4f554d9149764b3dbb863e01eb750a23.setProperty(hmUI.prop.MORE, { text: `Steps` });
                        normal$_$text_f054218405544b3185cd27a56ac35855.setProperty(hmUI.prop.MORE, { text: `Weather` });
                        normal$_$text_a3d138494d694b3088bedc578f0b309a.setProperty(hmUI.prop.MORE, { text: `Distance` });
                        normal$_$text_d89b7b02b2fa499f82a0a0527af0a7e7.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }%` });
                        normal$_$text_adeb6635229d4c5db170d7b3bc3b8d5f.setProperty(hmUI.prop.MORE, { text: `Stress` });
                        idle$_$text_9fceb6c9bbb148d5889426cd31694ad4.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }%` });
                        idle$_$text_7d755ec88d3a43f5b0fe9e984444db37.setProperty(hmUI.prop.MORE, { text: `Always on Display` });
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}