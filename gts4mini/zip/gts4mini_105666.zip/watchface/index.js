try {
  (() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');
    /*
  * huamiOS bundle tool v1.0.17
  * Copyright © Huami. All Rights Reserved
  */
    'use strict';
    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let nAmPmX = 210
    let nAmPmY = 34
    let nHourX = 32
    let nHourY = 17
    let nMinuteX = 32
    let nMinuteY = 209
    let nWeekX = 168
    let nWeekY = 177
    // let nMonthX = 212
    // let nMonthY = 314
    let nDayX = 262
    let nDayY = 179


    let arrDate = [];
    let arrData = [];
    let arrWeek = [];
    let arrWeekSc = [];
    let arrTimeHour = [];
    let arrTimeMinute = [];
    let arrAodTime = [];

    for (let i = 0; i < 10; i++) {
      arrDate.push(`images/date/${i}.png`)
      arrData.push(`images/data/${i}.png`)
      arrTimeHour.push(`images/time/hour/${i}.png`)
      arrTimeMinute.push(`images/time/minute/${i}.png`)
      arrAodTime.push(`images/aodtime/${i}.png`)     
    }
    for (let i = 1; i < 8; i++) {
      arrWeek.push(`images/week/${i}.png`)
      arrWeekSc.push(`images/week/sc/${i}.png`)
    }
    const objWeekOption = {
      x: nWeekX,
      y: nWeekY,
      week_en: arrWeek,
      week_sc: arrWeekSc,
      week_tc: arrWeekSc,
      show_level: hmUI.show_level.ONLY_NORMAL 
    }
    let objTime = {
      hour_zero: true,
      hour_startX: nHourX,
      hour_startY: nHourY,
      hour_array: arrTimeHour,
      hour_align: hmUI.align.LEFT,
      // hour_unit_sc: "images/time/dot.png",
      // hour_unit_tc: "images/time/dot.png",
      // hour_unit_en: "images/time/dot.png",
      hour_space: 5,
      minute_zero: true,
      minute_startX: nMinuteX,
      minute_startY: nMinuteY,
      minute_array: arrTimeMinute,
      minute_align: hmUI.align.LEFT,
      minute_space: 5,
      show_level: hmUI.show_level.ONLY_NORMAL,
    }
    let objAodTime = { ...objTime }
    objAodTime.hour_array = arrAodTime
    objAodTime.minute_array = arrAodTime
    objAodTime.show_level = hmUI.show_level.ONAL_AOD
    let objMonthOption = {
      // month_startX: nMonthX,
      // month_startY: nMonthY,
      // month_zero: 1,
      // month_en_array: arrDate,
      // month_sc_array: arrDate,
      // month_tc_array: arrDate,
      // month_unit_sc: "images/date/slash.png", //单位
      // month_unit_tc: "images/date/slash.png",
      // month_unit_en: "images/date/slash.png",
      // month_space: -1,//文字间隔
      day_startX: nDayX,
      day_startY: nDayY,
      // day_follow: 1,
      day_zero: 1,
      day_space: -1,//文字间隔
      day_en_array: arrDate,
      day_sc_array: arrDate,
      day_tc_array: arrDate,
      show_level: hmUI.show_level.ONLY_NORMAL,
    }
    let objAmPm = {
      am_x: nAmPmX,
      am_y: nAmPmY,
      am_sc_path: "images/ampm/amtc.png",
      am_en_path: "images/ampm/am.png",
      pm_x: nAmPmX,
      pm_y: nAmPmY,
      pm_sc_path: "images/ampm/pmtc.png",
      pm_en_path: "images/ampm/pm.png",
      show_level: hmUI.show_level.ONLY_NORMAL,
    }
    let objImg = { //表盘底层背景
      x: 0,
      y: 0,
      w: 336,
      h: 384,
      color: 0x000000
    }
    let objPaiText = {  // 心率数值
      x: 38,
      y: 177,
      w: 100,
      icon: `images/data/pai.png`,
      icon_space: 6,
      type: hmUI.data_type.PAI_WEEKLY,
      font_array: arrData,
      align_h: hmUI.align.CENTER_H,
      // invalid_image: "images/data/invalid.png",
      show_level: hmUI.show_level.ONLY_NORMAL,
    }
    const logger = DeviceRuntimeCore.HmLogger.getLogger("defult");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        hmUI.createWidget(hmUI.widget.FILL_RECT, objImg)
        hmUI.createWidget(hmUI.widget.IMG_WEEK, objWeekOption)
        hmUI.createWidget(hmUI.widget.IMG_TIME, objTime)
        hmUI.createWidget(hmUI.widget.IMG_TIME, objAodTime)        
        hmUI.createWidget(hmUI.widget.IMG_TIME, objAmPm)
        hmUI.createWidget(hmUI.widget.IMG_DATE, objMonthOption) 
        hmUI.createWidget(hmUI.widget.TEXT_IMG, objPaiText)  
      },
      onInit() {
        console.log('index page.js on init invoke');
        this.init_view();
      },
      onReady() {
        console.log('index page.js on ready invoke')
      },
      onShow() {
        console.log('index page.js on show invoke')
      },
      onHide() {
        console.log('index page.js on hide invoke')
      },
      onDestory() {
        console.log('index page.js on destory invoke')
      },
    });
    /*
    * end js
    */
  })()
} catch (e) {
  console.log(e)
}
