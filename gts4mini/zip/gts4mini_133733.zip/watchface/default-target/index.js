try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 336,
                    h: 384,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 168,
                    hour_centerY: 192,
                    hour_posX: 30,
                    hour_posY: 192,
                    hour_path: '3.png',
                    hour_cover_x: 30,
                    hour_cover_y: 192,
                    minute_centerX: 168,
                    minute_centerY: 192,
                    minute_posX: 30,
                    minute_posY: 192,
                    minute_path: '4.png',
                    minute_cover_x: 30,
                    minute_cover_y: 192,
                    second_centerX: 168,
                    second_centerY: 192,
                    second_posX: 30,
                    second_posY: 192,
                    second_path: '5.png',
                    second_cover_x: 30,
                    second_cover_y: 192,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 168,
                    hour_centerY: 192,
                    hour_posX: 30,
                    hour_posY: 192,
                    hour_path: '3.png',
                    hour_cover_x: 30,
                    hour_cover_y: 192,
                    minute_centerX: 168,
                    minute_centerY: 192,
                    minute_posX: 30,
                    minute_posY: 192,
                    minute_path: '4.png',
                    minute_cover_x: 30,
                    minute_cover_y: 192,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}