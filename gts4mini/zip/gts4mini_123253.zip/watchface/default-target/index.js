try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_9a6ff513490c42d8ba8d1872c75da66f = '';
        let normal$_$text_d107086e6df74a89b6939e8ee9bd9260 = '';
        let normal$_$text_12849d1dac7747949befebcdf7e336e2 = '';
        let normal$_$text_befecce431c34714b01e32413f84b54d = '';
        let dateFormat = '';
        let dateFormatMap = '';
        let normal$_$text_399e18fe7f8a41299426009b8b6dfa26 = '';
        let normal$_$text_359f753a281a414da222102a3f9fa5d1 = '';
        let normal$_$text_d25ff45433144e6f844d106ab1c22021 = '';
        let idle$_$text_7189fdc8c0fb45b68c1c450f5befa5f2 = '';
        let idle$_$text_4977873173b84a40908f82c5e2c35e28 = '';
        let idle$_$text_94382f9fc4f14d18965adf7a1150777d = '';
        let timeSensor = '';
        let calorieSensor = '';
        let batterySensor = '';
        let heartSensor = '';
        let stepSensor = '';
        const logger = Logger.getLogger('watchface6');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 336,
                    h: 384,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_9a6ff513490c42d8ba8d1872c75da66f = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 112,
                    y: 91,
                    w: 111,
                    h: 46,
                    text: '[HOUR_24_Z]:[MIN_Z]',
                    color: '0xFFF8571E',
                    text_size: 43,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_d107086e6df74a89b6939e8ee9bd9260 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 66,
                    y: 183,
                    w: 62,
                    h: 26,
                    text: '[CAL]',
                    color: '0xFFF8571E',
                    text_size: 22,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 110,
                    y: 158,
                    src: '3.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_12849d1dac7747949befebcdf7e336e2 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 139,
                    y: 48,
                    w: 100,
                    h: 40,
                    text: '[BATT_PER]%',
                    color: '0xFFF8571E',
                    text_size: 22,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 103,
                    y: 28,
                    src: '4.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_befecce431c34714b01e32413f84b54d = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 158,
                    y: 140,
                    w: 76,
                    h: 24,
                    text: '[MON_Z]-[DAY_Z]',
                    color: '0xFFD4351A',
                    text_size: 17,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_399e18fe7f8a41299426009b8b6dfa26 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 165,
                    y: 183,
                    w: 49,
                    h: 26,
                    text: '[HR]',
                    color: '0xFFF8571E',
                    text_size: 22,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 196,
                    y: 159,
                    src: '5.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_359f753a281a414da222102a3f9fa5d1 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 246,
                    y: 182,
                    w: 70,
                    h: 29,
                    text: '[SC]',
                    color: '0xFFF8571E',
                    text_size: 22,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 11,
                    y: 153,
                    src: '6.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_d25ff45433144e6f844d106ab1c22021 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 103,
                    y: 141,
                    w: 60,
                    h: 24,
                    text: '[WEEK_EN_S]',
                    color: '0xFFD4351A',
                    text_size: 17,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 336,
                    h: 384,
                    src: '7.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                idle$_$text_7189fdc8c0fb45b68c1c450f5befa5f2 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 158,
                    y: 140,
                    w: 90,
                    h: 36,
                    text: '[MON_Z] - [DAY_Z]',
                    color: '0xFFF8571E',
                    text_size: 23,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                idle$_$text_4977873173b84a40908f82c5e2c35e28 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 83,
                    y: 64,
                    w: 170,
                    h: 68,
                    text: '[HOUR_24_Z]:[MIN_Z]',
                    color: '0xFFF8571E',
                    text_size: 60,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                idle$_$text_94382f9fc4f14d18965adf7a1150777d = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 87,
                    y: 140,
                    w: 79,
                    h: 36,
                    text: '[WEEK_EN_S]',
                    color: '0xFFF8571E',
                    text_size: 23,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                if (!timeSensor) {
                    timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                }
                if (!calorieSensor) {
                    calorieSensor = hmSensor.createSensor(hmSensor.id.CALORIE);
                }
                if (!batterySensor) {
                    batterySensor = hmSensor.createSensor(hmSensor.id.BATTERY);
                }
                if (!heartSensor) {
                    heartSensor = hmSensor.createSensor(hmSensor.id.HEART);
                }
                if (!stepSensor) {
                    stepSensor = hmSensor.createSensor(hmSensor.id.STEP);
                }
                timeSensor.addEventListener(timeSensor.event.MINUTEEND, function () {
                    normal$_$text_9a6ff513490c42d8ba8d1872c75da66f.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }:${ String(timeSensor.minute).padStart(2, '0') }` });
                    idle$_$text_4977873173b84a40908f82c5e2c35e28.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }:${ String(timeSensor.minute).padStart(2, '0') }` });
                }), calorieSensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_d107086e6df74a89b6939e8ee9bd9260.setProperty(hmUI.prop.MORE, { text: `${ calorieSensor.current }` });
                }), batterySensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_12849d1dac7747949befebcdf7e336e2.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }%` });
                }), timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_befecce431c34714b01e32413f84b54d.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }-${ String(timeSensor.day).padStart(2, '0') }` });
                        },
                        () => {
                            normal$_$text_befecce431c34714b01e32413f84b54d.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }-${ String(timeSensor.month).padStart(2, '0') }` });
                        },
                        () => {
                            normal$_$text_befecce431c34714b01e32413f84b54d.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }-${ String(timeSensor.day).padStart(2, '0') }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                    const WEEK_EN_S = function (val) {
                        const valueMap = {
                            '1': 'Mon',
                            '2': 'Tue',
                            '3': 'Wed',
                            '4': 'Thu',
                            '5': 'Fri',
                            '6': 'Sat',
                            '7': 'Sun'
                        };
                        return valueMap[val];
                    };
                    normal$_$text_d25ff45433144e6f844d106ab1c22021.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_S(timeSensor.week) }` });
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            idle$_$text_7189fdc8c0fb45b68c1c450f5befa5f2.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') } - ${ String(timeSensor.day).padStart(2, '0') }` });
                        },
                        () => {
                            idle$_$text_7189fdc8c0fb45b68c1c450f5befa5f2.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') } - ${ String(timeSensor.month).padStart(2, '0') }` });
                        },
                        () => {
                            idle$_$text_7189fdc8c0fb45b68c1c450f5befa5f2.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') } - ${ String(timeSensor.day).padStart(2, '0') }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                    idle$_$text_94382f9fc4f14d18965adf7a1150777d.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_S(timeSensor.week) }` });
                }), heartSensor.addEventListener(heartSensor.event.LAST, function () {
                    normal$_$text_399e18fe7f8a41299426009b8b6dfa26.setProperty(hmUI.prop.MORE, { text: `${ heartSensor.last }` });
                }), stepSensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_359f753a281a414da222102a3f9fa5d1.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                });
                normal$_$text_9a6ff513490c42d8ba8d1872c75da66f.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }:${ String(timeSensor.minute).padStart(2, '0') }` });
                idle$_$text_4977873173b84a40908f82c5e2c35e28.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }:${ String(timeSensor.minute).padStart(2, '0') }` });
                timer.createTimer(0, 1000, function (timeSensor2) {
                    normal$_$text_9a6ff513490c42d8ba8d1872c75da66f.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor2.hour).padStart(2, '0') }:${ String(timeSensor2.minute).padStart(2, '0') }` });
                    idle$_$text_4977873173b84a40908f82c5e2c35e28.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor2.hour).padStart(2, '0') }:${ String(timeSensor2.minute).padStart(2, '0') }` });
                }, timeSensor);
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        normal$_$text_9a6ff513490c42d8ba8d1872c75da66f.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }:${ String(timeSensor.minute).padStart(2, '0') }` });
                        normal$_$text_d107086e6df74a89b6939e8ee9bd9260.setProperty(hmUI.prop.MORE, { text: `${ calorieSensor.current }` });
                        normal$_$text_12849d1dac7747949befebcdf7e336e2.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }%` });
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                normal$_$text_befecce431c34714b01e32413f84b54d.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }-${ String(timeSensor.day).padStart(2, '0') }` });
                            },
                            () => {
                                normal$_$text_befecce431c34714b01e32413f84b54d.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }-${ String(timeSensor.month).padStart(2, '0') }` });
                            },
                            () => {
                                normal$_$text_befecce431c34714b01e32413f84b54d.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }-${ String(timeSensor.day).padStart(2, '0') }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                        normal$_$text_399e18fe7f8a41299426009b8b6dfa26.setProperty(hmUI.prop.MORE, { text: `${ heartSensor.last }` });
                        normal$_$text_359f753a281a414da222102a3f9fa5d1.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                        const WEEK_EN_S = function (val) {
                            const valueMap = {
                                '1': 'Mon',
                                '2': 'Tue',
                                '3': 'Wed',
                                '4': 'Thu',
                                '5': 'Fri',
                                '6': 'Sat',
                                '7': 'Sun'
                            };
                            return valueMap[val];
                        };
                        normal$_$text_d25ff45433144e6f844d106ab1c22021.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_S(timeSensor.week) }` });
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                idle$_$text_7189fdc8c0fb45b68c1c450f5befa5f2.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') } - ${ String(timeSensor.day).padStart(2, '0') }` });
                            },
                            () => {
                                idle$_$text_7189fdc8c0fb45b68c1c450f5befa5f2.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') } - ${ String(timeSensor.month).padStart(2, '0') }` });
                            },
                            () => {
                                idle$_$text_7189fdc8c0fb45b68c1c450f5befa5f2.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') } - ${ String(timeSensor.day).padStart(2, '0') }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                        idle$_$text_4977873173b84a40908f82c5e2c35e28.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }:${ String(timeSensor.minute).padStart(2, '0') }` });
                        idle$_$text_94382f9fc4f14d18965adf7a1150777d.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_S(timeSensor.week) }` });
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}