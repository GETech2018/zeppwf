try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface6');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 336,
                    h: 384,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 262,
                    month_startY: 182,
                    month_sc_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    month_tc_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    month_en_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    month_align: hmUI.align.CENTER_H,
                    month_zero: 0,
                    month_follow: 0,
                    month_space: -9,
                    month_is_character: false,
                    day_startX: 230,
                    day_startY: 182,
                    day_sc_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    day_tc_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    day_en_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    day_align: hmUI.align.CENTER_H,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: -9,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 252,
                    y: 182,
                    w: 20,
                    h: 20,
                    src: '13.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 0,
                    y: 0,
                    image_array: [
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png'
                    ],
                    image_length: 4,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 137,
                    y: 125,
                    type: hmUI.data_type.BATTERY,
                    font_array: [
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -6,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '28.png',
                    unit_tc: '28.png',
                    unit_en: '28.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 139,
                    y: 296,
                    type: hmUI.data_type.STEP,
                    font_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -6,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: true,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 53,
                    y: 28,
                    type: hmUI.data_type.HEART,
                    font_array: [
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: -7,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '39.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 31,
                    y: 47,
                    w: 20,
                    h: 20,
                    src: '40.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 23,
                    y: 20,
                    src: '41.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 53,
                    y: 338,
                    type: hmUI.data_type.SPO2,
                    font_array: [
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: -7,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '42.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 85,
                    y: 355,
                    w: 20,
                    h: 20,
                    src: '43.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 26,
                    y: 330,
                    src: '44.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 240,
                    hour_startY: 28,
                    hour_array: [
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png'
                    ],
                    hour_space: -8,
                    hour_unit_sc: '45.png',
                    hour_unit_tc: '45.png',
                    hour_unit_en: '45.png',
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 275,
                    minute_startY: 28,
                    minute_array: [
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png'
                    ],
                    minute_space: -8,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    am_x: 280,
                    am_y: 45,
                    am_sc_path: '46.png',
                    am_en_path: '47.png',
                    pm_x: 280,
                    pm_y: 45,
                    pm_sc_path: '48.png',
                    pm_en_path: '49.png',
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 168,
                    hour_centerY: 192,
                    hour_posX: 40,
                    hour_posY: 192,
                    hour_path: '50.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 168,
                    minute_centerY: 192,
                    minute_posX: 40,
                    minute_posY: 192,
                    minute_path: '51.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    second_centerX: 168,
                    second_centerY: 245,
                    second_posX: 32,
                    second_posY: 192,
                    second_path: '52.png',
                    second_cover_x: 0,
                    second_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}