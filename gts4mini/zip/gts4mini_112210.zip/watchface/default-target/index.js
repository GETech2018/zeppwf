try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_9e41842bab674bda8b71ac6bd154f5e2 = '';
        let normal$_$text_80ab9fb547334cc0ba7082ee8f318c43 = '';
        let idle$_$text_93523575c93042cab272714d4a2e3445 = '';
        let idle$_$text_96241faad40e4da29912064d82b4ef01 = '';
        let stepSensor = '';
        const logger = Logger.getLogger('watchface6');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 336,
                    h: 384,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_9e41842bab674bda8b71ac6bd154f5e2 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 118,
                    y: 268,
                    w: 100,
                    h: 40,
                    text: '[SC]',
                    color: '0xFFb39d84',
                    text_size: 26,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_80ab9fb547334cc0ba7082ee8f318c43 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 118,
                    y: 293,
                    w: 100,
                    h: 40,
                    text: 'Steps',
                    color: '0xFFb39d84',
                    text_size: 26,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 168,
                    hour_centerY: 192,
                    hour_posX: 168,
                    hour_posY: 192,
                    hour_path: '3.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 168,
                    minute_centerY: 192,
                    minute_posX: 168,
                    minute_posY: 192,
                    minute_path: '4.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    second_centerX: 168,
                    second_centerY: 192,
                    second_posX: 18,
                    second_posY: 167,
                    second_path: '5.png',
                    second_cover_x: 0,
                    second_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    src: '6.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                idle$_$text_93523575c93042cab272714d4a2e3445 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 118,
                    y: 293,
                    w: 100,
                    h: 40,
                    text: 'Steps',
                    color: '0xFFb39d84',
                    text_size: 26,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                idle$_$text_96241faad40e4da29912064d82b4ef01 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 118,
                    y: 266,
                    w: 100,
                    h: 40,
                    text: '[SC]',
                    color: '0xFFb39d84',
                    text_size: 26,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 168,
                    hour_centerY: 192,
                    hour_posX: 168,
                    hour_posY: 192,
                    hour_path: '7.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 168,
                    minute_centerY: 192,
                    minute_posX: 168,
                    minute_posY: 192,
                    minute_path: '8.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                if (!stepSensor) {
                    stepSensor = hmSensor.createSensor(hmSensor.id.STEP);
                }
                stepSensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_9e41842bab674bda8b71ac6bd154f5e2.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                    idle$_$text_96241faad40e4da29912064d82b4ef01.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                });
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        normal$_$text_9e41842bab674bda8b71ac6bd154f5e2.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                        normal$_$text_80ab9fb547334cc0ba7082ee8f318c43.setProperty(hmUI.prop.MORE, { text: `Steps` });
                        idle$_$text_93523575c93042cab272714d4a2e3445.setProperty(hmUI.prop.MORE, { text: `Steps` });
                        idle$_$text_96241faad40e4da29912064d82b4ef01.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}