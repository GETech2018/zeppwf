try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let idle$_$text_f3018de7c98f48588d4a4b2850c88cf5 = '';
        let idle$_$text_55d8b12e68104a34b236e9c060a4e5dd = '';
        let idle$_$text_830fe2ce7acb4bde9528f764c2fe6867 = '';
        let idle$_$text_f8b96e5a36fd4204a83b4f27024feabf = '';
        let dateFormat = '';
        let dateFormatMap = '';
        let idle$_$text_c66dfb8306ab44368db7fb524feaf58d = '';
        let idle$_$text_aff2423dd2aa4f15b31318fa1307e05f = '';
        let timeSensor = '';
        const logger = Logger.getLogger('watchface6');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 336,
                    h: 384,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 120,
                    y: 12,
                    src: '3.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 268,
                    y: 20,
                    src: '4.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 34,
                    y: 18,
                    src: '5.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 34,
                    y: 18,
                    src: '6.png',
                    type: hmUI.system_status.DISCONNECT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 268,
                    y: 20,
                    src: '7.png',
                    type: hmUI.system_status.LOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 69,
                    month_startY: 244,
                    month_sc_array: [
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png'
                    ],
                    month_tc_array: [
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png'
                    ],
                    month_en_array: [
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png'
                    ],
                    month_align: hmUI.align.LEFT,
                    month_zero: 1,
                    month_follow: 0,
                    month_space: -3,
                    month_is_character: false,
                    day_startX: 121,
                    day_startY: 245,
                    day_sc_array: [
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png'
                    ],
                    day_tc_array: [
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png'
                    ],
                    day_en_array: [
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png'
                    ],
                    day_align: hmUI.align.LEFT,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: -3,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 192,
                    y: 245,
                    week_en: [
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png'
                    ],
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 104,
                    y: 284,
                    type: hmUI.data_type.SUN_RISE,
                    font_array: [
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: -1,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    dot_image: '36.png',
                    invalid_image: '35.png',
                    padding: true,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 194,
                    y: 284,
                    type: hmUI.data_type.SUN_SET,
                    font_array: [
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    dot_image: '38.png',
                    invalid_image: '37.png',
                    padding: true,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 223,
                    y: 12,
                    image_array: [
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png',
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png',
                        '58.png',
                        '59.png',
                        '60.png',
                        '61.png',
                        '62.png',
                        '63.png',
                        '64.png',
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png'
                    ],
                    image_length: 30,
                    type: hmUI.data_type.MOON,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 70,
                    hour_startY: 151,
                    hour_array: [
                        '69.png',
                        '70.png',
                        '71.png',
                        '72.png',
                        '73.png',
                        '74.png',
                        '75.png',
                        '76.png',
                        '77.png',
                        '78.png'
                    ],
                    hour_space: -7,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 173,
                    minute_startY: 151,
                    minute_array: [
                        '69.png',
                        '70.png',
                        '71.png',
                        '72.png',
                        '73.png',
                        '74.png',
                        '75.png',
                        '76.png',
                        '77.png',
                        '78.png'
                    ],
                    minute_space: -7,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    second_zero: 1,
                    second_startX: 195,
                    second_startY: 210,
                    second_array: [
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png'
                    ],
                    second_space: -3,
                    second_align: hmUI.align.LEFT,
                    second_follow: 0,
                    am_x: 90,
                    am_y: 210,
                    am_en_path: '79.png',
                    pm_x: 90,
                    pm_y: 210,
                    pm_en_path: '80.png',
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 120,
                    y: 13,
                    image_array: [
                        '81.png',
                        '82.png',
                        '83.png',
                        '84.png',
                        '85.png',
                        '86.png',
                        '87.png',
                        '88.png',
                        '89.png',
                        '90.png'
                    ],
                    image_length: 10,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 127,
                    y: 23,
                    type: hmUI.data_type.BATTERY,
                    font_array: [
                        '91.png',
                        '92.png',
                        '93.png',
                        '94.png',
                        '95.png',
                        '96.png',
                        '97.png',
                        '98.png',
                        '99.png',
                        '100.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -4,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '101.png',
                    unit_tc: '101.png',
                    unit_en: '101.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 271,
                    y: 203,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: [
                        '102.png',
                        '103.png',
                        '104.png',
                        '105.png',
                        '106.png',
                        '107.png',
                        '108.png',
                        '109.png',
                        '110.png',
                        '111.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: -1,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '114.png',
                    unit_tc: '114.png',
                    unit_en: '114.png',
                    negative_image: '113.png',
                    invalid_image: '112.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 296,
                    y: 157,
                    type: hmUI.data_type.WEATHER_HIGH,
                    font_array: [
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -2,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    negative_image: '116.png',
                    invalid_image: '115.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 296,
                    y: 180,
                    type: hmUI.data_type.WEATHER_LOW,
                    font_array: [
                        '117.png',
                        '118.png',
                        '119.png',
                        '120.png',
                        '121.png',
                        '122.png',
                        '123.png',
                        '124.png',
                        '125.png',
                        '126.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -2,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    negative_image: '128.png',
                    invalid_image: '127.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 264,
                    y: 156,
                    src: '129.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 242,
                    y: 316,
                    type: hmUI.data_type.SPO2,
                    font_array: [
                        '102.png',
                        '103.png',
                        '104.png',
                        '105.png',
                        '106.png',
                        '107.png',
                        '108.png',
                        '109.png',
                        '110.png',
                        '111.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -1,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '131.png',
                    unit_tc: '131.png',
                    unit_en: '131.png',
                    invalid_image: '130.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 255,
                    y: 332,
                    src: '132.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 13,
                    y: 114,
                    type: hmUI.data_type.DISTANCE,
                    font_array: [
                        '102.png',
                        '103.png',
                        '104.png',
                        '105.png',
                        '106.png',
                        '107.png',
                        '108.png',
                        '109.png',
                        '110.png',
                        '111.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: -1,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '135.png',
                    unit_tc: '135.png',
                    unit_en: '135.png',
                    imperial_unit_sc: '136.png',
                    imperial_unit_tc: '136.png',
                    imperial_unit_en: '136.png',
                    dot_image: '134.png',
                    invalid_image: '133.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 53,
                    y: 68,
                    src: '137.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 6,
                    y: 203,
                    type: hmUI.data_type.HUMIDITY,
                    font_array: [
                        '102.png',
                        '103.png',
                        '104.png',
                        '105.png',
                        '106.png',
                        '107.png',
                        '108.png',
                        '109.png',
                        '110.png',
                        '111.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -1,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '138.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 11,
                    y: 156,
                    src: '139.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 76,
                    y: 15,
                    image_array: [
                        '140.png',
                        '141.png',
                        '142.png',
                        '143.png',
                        '144.png',
                        '145.png',
                        '146.png',
                        '147.png',
                        '148.png',
                        '149.png',
                        '150.png',
                        '151.png',
                        '152.png',
                        '153.png',
                        '154.png',
                        '155.png',
                        '156.png',
                        '157.png',
                        '158.png',
                        '159.png',
                        '160.png',
                        '161.png',
                        '162.png',
                        '163.png',
                        '164.png',
                        '165.png',
                        '166.png',
                        '167.png',
                        '168.png'
                    ],
                    image_length: 29,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 34,
                    y: 316,
                    type: hmUI.data_type.HEART,
                    font_array: [
                        '102.png',
                        '103.png',
                        '104.png',
                        '105.png',
                        '106.png',
                        '107.png',
                        '108.png',
                        '109.png',
                        '110.png',
                        '111.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -1,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '169.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 37,
                    y: 333,
                    src: '170.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 107,
                    y: 316,
                    type: hmUI.data_type.STRESS,
                    font_array: [
                        '102.png',
                        '103.png',
                        '104.png',
                        '105.png',
                        '106.png',
                        '107.png',
                        '108.png',
                        '109.png',
                        '110.png',
                        '111.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -1,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '171.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 111,
                    y: 336,
                    src: '172.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 258,
                    y: 114,
                    type: hmUI.data_type.CAL,
                    font_array: [
                        '102.png',
                        '103.png',
                        '104.png',
                        '105.png',
                        '106.png',
                        '107.png',
                        '108.png',
                        '109.png',
                        '110.png',
                        '111.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -1,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '173.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 270,
                    y: 68,
                    src: '174.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 13,
                    y: 282,
                    type: hmUI.data_type.UVI,
                    font_array: [
                        '102.png',
                        '103.png',
                        '104.png',
                        '105.png',
                        '106.png',
                        '107.png',
                        '108.png',
                        '109.png',
                        '110.png',
                        '111.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -1,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '175.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 10,
                    y: 236,
                    src: '176.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 178,
                    y: 316,
                    type: hmUI.data_type.PAI_DAILY,
                    font_array: [
                        '177.png',
                        '178.png',
                        '179.png',
                        '180.png',
                        '181.png',
                        '182.png',
                        '183.png',
                        '184.png',
                        '185.png',
                        '186.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -1,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '187.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 182,
                    y: 336,
                    src: '188.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 151,
                    y: 114,
                    type: hmUI.data_type.STEP,
                    font_array: [
                        '102.png',
                        '103.png',
                        '104.png',
                        '105.png',
                        '106.png',
                        '107.png',
                        '108.png',
                        '109.png',
                        '110.png',
                        '111.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -1,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '189.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 169,
                    y: 68,
                    src: '190.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 277,
                    y: 279,
                    type: hmUI.data_type.WIND,
                    font_array: [
                        '191.png',
                        '192.png',
                        '193.png',
                        '194.png',
                        '195.png',
                        '196.png',
                        '197.png',
                        '198.png',
                        '199.png',
                        '200.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -1,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '201.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 277,
                    y: 235,
                    src: '202.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 336,
                    h: 384,
                    src: '203.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 84,
                    hour_startY: 24,
                    hour_array: [
                        '204.png',
                        '205.png',
                        '206.png',
                        '207.png',
                        '208.png',
                        '209.png',
                        '210.png',
                        '211.png',
                        '212.png',
                        '213.png'
                    ],
                    hour_space: -10,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 84,
                    minute_startY: 128,
                    minute_array: [
                        '204.png',
                        '205.png',
                        '206.png',
                        '207.png',
                        '208.png',
                        '209.png',
                        '210.png',
                        '211.png',
                        '212.png',
                        '213.png'
                    ],
                    minute_space: -10,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    am_x: 118,
                    am_y: 239,
                    am_en_path: '214.png',
                    pm_x: 118,
                    pm_y: 233,
                    pm_en_path: '215.png',
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                idle$_$text_f3018de7c98f48588d4a4b2850c88cf5 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 117,
                    y: 336,
                    w: 108,
                    h: 28,
                    text: '[WEEK_EN_F]',
                    color: '0xFF00ff00',
                    text_size: 20,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                idle$_$text_55d8b12e68104a34b236e9c060a4e5dd = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 134,
                    y: 295,
                    w: 19,
                    h: 30,
                    text: '/',
                    color: '0xFF00ff00',
                    text_size: 26,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                idle$_$text_830fe2ce7acb4bde9528f764c2fe6867 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 216,
                    y: 295,
                    w: 19,
                    h: 30,
                    text: '/',
                    color: '0xFF00ff00',
                    text_size: 26,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                idle$_$text_f8b96e5a36fd4204a83b4f27024feabf = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 50,
                    y: 294,
                    w: 71,
                    h: 33,
                    text: '[YEAR]',
                    color: '0xFF00ff00',
                    text_size: 28,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                idle$_$text_c66dfb8306ab44368db7fb524feaf58d = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 163,
                    y: 294,
                    w: 41,
                    h: 33,
                    text: '[MON_Z]',
                    color: '0xFF00ff00',
                    text_size: 28,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                idle$_$text_aff2423dd2aa4f15b31318fa1307e05f = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 247,
                    y: 294,
                    w: 41,
                    h: 33,
                    text: '[DAY_Z]',
                    color: '0xFF00ff00',
                    text_size: 28,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                if (!timeSensor) {
                    timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                }
                timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
                    const WEEK_EN_F = function (val) {
                        const valueMap = {
                            '1': 'Monday',
                            '2': 'Tuesday',
                            '3': 'Wednesday',
                            '4': 'Thursday',
                            '5': 'Friday',
                            '6': 'Saturday',
                            '7': 'Sunday'
                        };
                        return valueMap[val];
                    };
                    idle$_$text_f3018de7c98f48588d4a4b2850c88cf5.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_F(timeSensor.week) }` });
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            idle$_$text_f8b96e5a36fd4204a83b4f27024feabf.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }` });
                        },
                        () => {
                            idle$_$text_f8b96e5a36fd4204a83b4f27024feabf.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }` });
                        },
                        () => {
                            idle$_$text_f8b96e5a36fd4204a83b4f27024feabf.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            idle$_$text_c66dfb8306ab44368db7fb524feaf58d.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }` });
                        },
                        () => {
                            idle$_$text_c66dfb8306ab44368db7fb524feaf58d.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }` });
                        },
                        () => {
                            idle$_$text_c66dfb8306ab44368db7fb524feaf58d.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            idle$_$text_aff2423dd2aa4f15b31318fa1307e05f.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }` });
                        },
                        () => {
                            idle$_$text_aff2423dd2aa4f15b31318fa1307e05f.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }` });
                        },
                        () => {
                            idle$_$text_aff2423dd2aa4f15b31318fa1307e05f.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                });
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        const WEEK_EN_F = function (val) {
                            const valueMap = {
                                '1': 'Monday',
                                '2': 'Tuesday',
                                '3': 'Wednesday',
                                '4': 'Thursday',
                                '5': 'Friday',
                                '6': 'Saturday',
                                '7': 'Sunday'
                            };
                            return valueMap[val];
                        };
                        idle$_$text_f3018de7c98f48588d4a4b2850c88cf5.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_F(timeSensor.week) }` });
                        idle$_$text_55d8b12e68104a34b236e9c060a4e5dd.setProperty(hmUI.prop.MORE, { text: `/` });
                        idle$_$text_830fe2ce7acb4bde9528f764c2fe6867.setProperty(hmUI.prop.MORE, { text: `/` });
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                idle$_$text_f8b96e5a36fd4204a83b4f27024feabf.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }` });
                            },
                            () => {
                                idle$_$text_f8b96e5a36fd4204a83b4f27024feabf.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }` });
                            },
                            () => {
                                idle$_$text_f8b96e5a36fd4204a83b4f27024feabf.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                idle$_$text_c66dfb8306ab44368db7fb524feaf58d.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }` });
                            },
                            () => {
                                idle$_$text_c66dfb8306ab44368db7fb524feaf58d.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }` });
                            },
                            () => {
                                idle$_$text_c66dfb8306ab44368db7fb524feaf58d.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                idle$_$text_aff2423dd2aa4f15b31318fa1307e05f.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }` });
                            },
                            () => {
                                idle$_$text_aff2423dd2aa4f15b31318fa1307e05f.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }` });
                            },
                            () => {
                                idle$_$text_aff2423dd2aa4f15b31318fa1307e05f.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}