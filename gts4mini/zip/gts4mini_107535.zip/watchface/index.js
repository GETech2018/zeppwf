try {
  (() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__),
      "drink"
    );

    /*
     * huamiOS bundle tool v1.0.17
     * Copyright © Huami. All Rights Reserved
     */
    ("use strict");

    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let rootPath = "images/";
    let dontPath = rootPath + "date/slash.png";
    let weekEnArray = [];
    let date_array = [];
    let timeArray = [];

    for (let i = 1; i < 8; i++) {
      weekEnArray.push(rootPath + 'week_en/' + i + '.png')
    }
    for (let i = 0; i < 10; i++) {
      date_array.push(rootPath + 'date/' + i + '.png')
      timeArray.push(rootPath + 'time/' + i + '.png')
    }

    let obj_bg = {//背景
      x: 0,
      y: 0,
      // w: 336,
      // h: 387,
      src: rootPath + 'bg.png',
      show_level: hmUI.show_level.ONLY_NORMAL,
    }
    let weekObj = {//星期
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD,
      x: 81,
      y: 36,
      week_tc: weekEnArray,
      week_sc: weekEnArray,
      week_en: weekEnArray,
    }
    let dateObj = {//日期
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD,
      month_startX: 165,
      month_startY: 36,
      month_zero: true,
      month_en_array: date_array,
      month_align: hmUI.align.RIGHT,
      month_unit_sc: dontPath,
      month_unit_tc: dontPath,
      month_unit_en: dontPath,
      day_follow: true,
      day_zero: true,
      day_en_array: date_array,
    }
    let timeObj = {//时间
      hour_zero: true,
      hour_startX: 51,
      hour_startY: 68,
      hour_array: timeArray,
      hour_space: 0,
      hour_unit_sc: rootPath + "time/colon.png", //单位
      hour_unit_tc: rootPath + "time/colon.png",
      hour_unit_en: rootPath + "time/colon.png",
      hour_align: hmUI.align.LEFT,
      minute_zero: 1, //是否补零 1为补零
      minute_array: timeArray,
      minute_startX: 181,
      minute_startY: 68,
      am_x: 9,
      am_y: 122,
      am_sc_path: rootPath + 'ampm/am.png',
      am_en_path: rootPath + 'ampm/am.png',
      pm_x: 9,
      pm_y: 122,
      pm_sc_path: rootPath + 'ampm/pm.png',
      pm_en_path: rootPath + 'ampm/pm.png',
      show_level: hmUI.show_level.ONLY_NORMAL ,
    }
    let timeXpObj = {//时间
      hour_zero: true,
      hour_startX: 51,
      hour_startY: 68,
      hour_array: timeArray,
      hour_space: 0,
      hour_unit_sc: rootPath + "time/colon.png", //单位
      hour_unit_tc: rootPath + "time/colon.png",
      hour_unit_en: rootPath + "time/colon.png",
      hour_align: hmUI.align.LEFT,
      minute_zero: 1, //是否补零 1为补零
      minute_startX: 181,
      minute_startY: 68,
      minute_array: timeArray,
      show_level:  hmUI.show_level.ONAL_AOD ,
    }
    const logger = DeviceRuntimeCore.HmLogger.getLogger("defult");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({

      init_view() {
        hmUI.createWidget(hmUI.widget.IMG, obj_bg)
        hmUI.createWidget(hmUI.widget.IMG_WEEK, weekObj);
        hmUI.createWidget(hmUI.widget.IMG_DATE, dateObj);
        hmUI.createWidget(hmUI.widget.IMG_TIME, timeObj);
        hmUI.createWidget(hmUI.widget.IMG_TIME, timeXpObj);
      },

      onInit() {
        console.log("index page.js on init invoke");
        this.init_view();
      },

      onReady() {
        console.log("index page.js on ready invoke");
      },

      onShow() {
        console.log("index page.js on show invoke");
      },

      onHide() {
        console.log("index page.js on hide invoke");
      },

      onDestory() {
        console.log("index page.js on destory invoke");
      },
    });
    /*
     * end js
     */
  })();
} catch (e) {
  console.log(e);
}