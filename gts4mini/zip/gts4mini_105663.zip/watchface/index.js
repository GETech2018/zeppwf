try {
  (() => {

    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

    /*
* huamiOS bundle tool v1.0.17
* Copyright © Huami. All Rights Reserved
*/
    'use strict';

    console.log("----->>>current")
    console.log(__$$hmAppManager$$__.currentApp.pid)
    console.log(__$$hmAppManager$$__.currentApp.current)
    /*params声明*/
   
    let strRootPath = "images/"
    let nX = 0
    let nY = 0
    let nW = 336
    let nH = 384
    let arrTime = []
    let arrAodTime = []
    let arrEnWeek = []
    let arrScWeek = []
    let arrTcWeek = []
    let arrDataFont = []
  
    let objBg = {
      x: nX,
      y: nY,
      w: nW,
      h: nH,
      src: strRootPath + "background/bg_normal.png",
      show_level: hmUI.show_level.ONLY_NORMAL,
    }
    let objAodBg = {
      x: nX,
      y: nY,
      w: nW,
      h: nH,
      src: strRootPath + "background/bg_aod.png",
      show_level: hmUI.show_level.ONAL_AOD,
    }
    let objMask = {
      x: 24,
      y: nY,
      w: nW,
      h: nH,
      src: strRootPath + "element/element.png",
      show_level: hmUI.show_level.ONLY_NORMAL,
    }
    let objTime = {
      hour_zero: 1,
      hour_startX: 39,
      hour_startY: 55,
      hour_array: arrTime,
      hour_space: 0,
      hour_align: hmUI.align.CENTER_H,
      minute_zero: 1,
      minute_startX: 125,
      minute_startY: 209,
      minute_array: arrTime,
      minute_space: 0,
      minute_align: hmUI.align.CENTER_H,

      am_x: 211,
      am_y: 100,
      am_sc_path: strRootPath + "time_lot/sc/am_sc.png",
      am_en_path: strRootPath + "time_lot/en/am_en.png",
      pm_x: 211,
      pm_y: 100,
      pm_sc_path: strRootPath + "time_lot/sc/pm_sc.png",
      pm_en_path: strRootPath + "time_lot/en/pm_en.png",
      show_level: hmUI.show_level.ONLY_NORMAL
    }
    let objAodTime = {
      hour_zero: 1,
      hour_startX: 39,
      hour_startY: 55,
      hour_array: arrAodTime,
      hour_space: 0,
      hour_align: hmUI.align.CENTER_H,
      minute_zero: 1,
      minute_startX: 125,
      minute_startY: 209,
      minute_array: arrAodTime,
      minute_space: 0,
      minute_align: hmUI.align.CENTER_H,
      show_level: hmUI.show_level.ONAL_AOD
    }
    let objWeek = {
      x: 211,
      y: 177,
      week_en: arrEnWeek,
      week_tc: arrTcWeek,
      week_sc: arrScWeek,
      show_level: hmUI.show_level.ONLY_NORMAL
    }
    let objMonth = {
      month_startX: 39,
      month_startY: 179,
      month_align: hmUI.align.LEFT,
      month_space: 0,
      month_zero: 1,
      month_follow: 0,
      month_en_array: arrDataFont,
      month_sc_array: arrDataFont,
      month_tc_array: arrDataFont,
      month_unit_sc:strRootPath + "date_number/slash.png",
      month_unit_tc:strRootPath + "date_number/slash.png",
      month_unit_en:strRootPath + "date_number/slash.png",
      day_align: hmUI.align.LEFT,
      day_space: 0,
      day_zero: 1,
      day_follow: 1,
      day_en_array: arrDataFont,
      day_sc_array: arrDataFont,
      day_tc_array: arrDataFont,
      show_level: hmUI.show_level.ONLY_NORMAL,
    }
  

    /*遍历数组*/
    for(i = 0; i < 10; i++){
      if( i < 8 && i > 0 ){
        arrEnWeek.push(strRootPath+"week/en/"+i+".png")
        arrScWeek.push(strRootPath+"week/sc/"+i+".png")
        arrTcWeek.push(strRootPath+"week/sc/"+i+".png")
      }
      arrTime.push(strRootPath+"time_number/normal_mode/"+i+".png")
      arrAodTime.push(strRootPath+"time_number/aod_mode/"+i+".png")
      arrDataFont.push(strRootPath+"date_number/"+i+".png")
      
    }

    const logger = DeviceRuntimeCore.HmLogger.getLogger("xiping");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({

      init_view() {

        /* 正常背景 */
        let bg = hmUI.createWidget(hmUI.widget.IMG, objBg)

        /* 息屏背景 */
        let aodBg = hmUI.createWidget(hmUI.widget.IMG, objAodBg)

        /* 时间 */
        let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, objTime)

        /* 息屏时间 */
        let timeAod = hmUI.createWidget(hmUI.widget.IMG_TIME, objAodTime)

        /* 星期 */
        let timeWeek = hmUI.createWidget(hmUI.widget.IMG_WEEK, objWeek)

        /* 日期 */
        let timeMonth = hmUI.createWidget(hmUI.widget.IMG_DATE, objMonth)

        /* 正常背景 */
        let bgmask = hmUI.createWidget(hmUI.widget.IMG, objMask)

       
      },

      onInit() {
        console.log('index page.js on init invoke')
        this.init_view();
      },

      onReady() {
        console.log('index page.js on ready invoke')
      },

      onShow() {
        console.log('index page.js on show invoke')
      },

      onHide() {
        console.log('index page.js on hide invoke')
      },

      onDestory() {
        console.log('index page.js on destory invoke')
      },
    });
    /*
    * end js
    */
  })()
} catch (e) {
  console.log(e)
}
