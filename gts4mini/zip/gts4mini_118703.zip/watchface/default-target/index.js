try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_bf47a6c32d7f4bfcb8e11fd615b16d55 = '';
        let normal$_$text_3ea74202afc74032967c0bd8b80658b5 = '';
        let timeSensor = '';
        const logger = Logger.getLogger('watchface6');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 336,
                    h: 384,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 58,
                    y: 151,
                    image_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png'
                    ],
                    image_length: 29,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_bf47a6c32d7f4bfcb8e11fd615b16d55 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 93,
                    y: 101,
                    w: 150,
                    h: 40,
                    text: '[WEEK_EN_F]',
                    color: '0xFFffffff',
                    text_size: 22,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 168,
                    center_y: 266,
                    radius: 24,
                    start_angle: 0,
                    end_angle: 360,
                    color: 4287426052,
                    line_width: 9,
                    src_bg: '32.png',
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 168,
                    center_y: 266,
                    radius: 10,
                    start_angle: 0,
                    end_angle: 360,
                    color: 4278437078,
                    line_width: 9,
                    src_bg: '33.png',
                    type: hmUI.data_type.PAI_DAILY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 235,
                    y: 151,
                    src: '34.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 168,
                    center_y: 266,
                    radius: 36,
                    start_angle: 0,
                    end_angle: 360,
                    color: 4294454915,
                    line_width: 9,
                    src_bg: '35.png',
                    type: hmUI.data_type.CAL,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_3ea74202afc74032967c0bd8b80658b5 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 8,
                    y: 16,
                    w: 100,
                    h: 40,
                    text: '[HOUR_24_Z]:[MIN_Z]',
                    color: '0xFFffffff',
                    text_size: 22,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 55,
                    y: 201,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: [
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '48.png',
                    unit_tc: '48.png',
                    unit_en: '48.png',
                    negative_image: '47.png',
                    invalid_image: '46.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 239,
                    y: 201,
                    type: hmUI.data_type.HEART,
                    font_array: [
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png',
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png',
                        '58.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '59.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 168,
                    hour_centerY: 193,
                    hour_posX: 7,
                    hour_posY: 72,
                    hour_path: '60.png',
                    hour_cover_x: 7,
                    hour_cover_y: 72,
                    minute_centerX: 168,
                    minute_centerY: 192,
                    minute_posX: 7,
                    minute_posY: 128,
                    minute_path: '61.png',
                    minute_cover_x: 7,
                    minute_cover_y: 128,
                    second_centerX: 168,
                    second_centerY: 193,
                    second_posX: 6,
                    second_posY: 144,
                    second_path: '62.png',
                    second_cover_x: 6,
                    second_cover_y: 146,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 285,
                    y: 24,
                    image_array: [
                        '63.png',
                        '64.png',
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png',
                        '71.png',
                        '72.png'
                    ],
                    image_length: 10,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 336,
                    h: 384,
                    src: '74.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 168,
                    hour_centerY: 193,
                    hour_posX: 7,
                    hour_posY: 71,
                    hour_path: '76.png',
                    hour_cover_path: '75.png',
                    hour_cover_x: 165,
                    hour_cover_y: 190,
                    minute_centerX: 168,
                    minute_centerY: 193,
                    minute_posX: 7,
                    minute_posY: 128,
                    minute_path: '78.png',
                    minute_cover_path: '77.png',
                    minute_cover_x: 165,
                    minute_cover_y: 190,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                if (!timeSensor) {
                    timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                }
                timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
                    const WEEK_EN_F = function (val) {
                        const valueMap = {
                            '1': 'Monday',
                            '2': 'Tuesday',
                            '3': 'Wednesday',
                            '4': 'Thursday',
                            '5': 'Friday',
                            '6': 'Saturday',
                            '7': 'Sunday'
                        };
                        return valueMap[val];
                    };
                    normal$_$text_bf47a6c32d7f4bfcb8e11fd615b16d55.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_F(timeSensor.week) }` });
                }), timeSensor.addEventListener(timeSensor.event.MINUTEEND, function () {
                    normal$_$text_3ea74202afc74032967c0bd8b80658b5.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }:${ String(timeSensor.minute).padStart(2, '0') }` });
                });
                normal$_$text_3ea74202afc74032967c0bd8b80658b5.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }:${ String(timeSensor.minute).padStart(2, '0') }` });
                timer.createTimer(0, 1000, function (timeSensor2) {
                    normal$_$text_3ea74202afc74032967c0bd8b80658b5.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor2.hour).padStart(2, '0') }:${ String(timeSensor2.minute).padStart(2, '0') }` });
                }, timeSensor);
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 285,
                    y: 24,
                    w: 0,
                    h: 0,
                    src: '73.png',
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        const WEEK_EN_F = function (val) {
                            const valueMap = {
                                '1': 'Monday',
                                '2': 'Tuesday',
                                '3': 'Wednesday',
                                '4': 'Thursday',
                                '5': 'Friday',
                                '6': 'Saturday',
                                '7': 'Sunday'
                            };
                            return valueMap[val];
                        };
                        normal$_$text_bf47a6c32d7f4bfcb8e11fd615b16d55.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_F(timeSensor.week) }` });
                        normal$_$text_3ea74202afc74032967c0bd8b80658b5.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }:${ String(timeSensor.minute).padStart(2, '0') }` });
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}