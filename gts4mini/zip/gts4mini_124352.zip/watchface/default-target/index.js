try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_bdd4f55f022444f58de12ed803fd354b = '';
        let dateFormat = '';
        let dateFormatMap = '';
        let normal$_$text_57ed35227bfd4238acd17de98ee9a749 = '';
        let normal$_$text_60f8a516bf834f698e67f6a65f7f7184 = '';
        let normal$_$text_02b8ea4c15ba4f7492a3ac5736998fe3 = '';
        let timeSensor = '';
        let stepSensor = '';
        let calorieSensor = '';
        let heartSensor = '';
        const logger = Logger.getLogger('watchface6');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 336,
                    h: 384,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    second_centerX: 168,
                    second_centerY: 192,
                    second_posX: 75,
                    second_posY: 250,
                    second_path: '3.png',
                    second_cover_x: 0,
                    second_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 336,
                    h: 384,
                    src: '4.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_bdd4f55f022444f58de12ed803fd354b = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 0,
                    y: 84,
                    w: 50,
                    h: 36,
                    text: '[MON]',
                    color: '0xFFffffff',
                    text_size: 32,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_57ed35227bfd4238acd17de98ee9a749 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 0,
                    y: 120,
                    w: 50,
                    h: 36,
                    text: '[DAY]',
                    color: '0xFFffffff',
                    text_size: 32,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_60f8a516bf834f698e67f6a65f7f7184 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 0,
                    y: 64,
                    w: 50,
                    h: 20,
                    text: '[YEAR]',
                    color: '0xFFffffff',
                    text_size: 18,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_val: new Date().getHours(),
                    hour_zero: 1,
                    hour_startX: 60,
                    hour_startY: 16,
                    hour_array: [
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png'
                    ],
                    hour_space: 16,
                    hour_align: hmUI.align.CENTER_H,
                    minute_val: new Date().getMinutes(),
                    minute_zero: 1,
                    minute_startX: 60,
                    minute_startY: 182,
                    minute_array: [
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png'
                    ],
                    minute_space: 16,
                    minute_align: hmUI.align.CENTER_H,
                    minute_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 292,
                    y: 204,
                    src: '15.png',
                    type: hmUI.system_status.DISCONNECT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 292,
                    y: 74,
                    src: '16.png',
                    type: hmUI.system_status.LOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 292,
                    y: 276,
                    src: '17.png',
                    type: hmUI.system_status.CLOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 8,
                    y: 222,
                    image_array: [
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png'
                    ],
                    image_length: 10,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_02b8ea4c15ba4f7492a3ac5736998fe3 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 20,
                    y: 335,
                    w: 296,
                    h: 40,
                    text: '[SC] steps - [CAL] kcal - [HR] bpm',
                    color: '0xFFffffff',
                    text_size: 16,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                if (!timeSensor) {
                    timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                }
                if (!stepSensor) {
                    stepSensor = hmSensor.createSensor(hmSensor.id.STEP);
                }
                if (!calorieSensor) {
                    calorieSensor = hmSensor.createSensor(hmSensor.id.CALORIE);
                }
                if (!heartSensor) {
                    heartSensor = hmSensor.createSensor(hmSensor.id.HEART);
                }
                timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_bdd4f55f022444f58de12ed803fd354b.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.month }` });
                        },
                        () => {
                            normal$_$text_bdd4f55f022444f58de12ed803fd354b.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.month }` });
                        },
                        () => {
                            normal$_$text_bdd4f55f022444f58de12ed803fd354b.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.month }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_57ed35227bfd4238acd17de98ee9a749.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                        },
                        () => {
                            normal$_$text_57ed35227bfd4238acd17de98ee9a749.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                        },
                        () => {
                            normal$_$text_57ed35227bfd4238acd17de98ee9a749.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_60f8a516bf834f698e67f6a65f7f7184.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }` });
                        },
                        () => {
                            normal$_$text_60f8a516bf834f698e67f6a65f7f7184.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }` });
                        },
                        () => {
                            normal$_$text_60f8a516bf834f698e67f6a65f7f7184.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                }), stepSensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_02b8ea4c15ba4f7492a3ac5736998fe3.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current } steps - ${ calorieSensor.current } kcal - ${ heartSensor.last } bpm` });
                }), calorieSensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_02b8ea4c15ba4f7492a3ac5736998fe3.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current } steps - ${ calorieSensor.current } kcal - ${ heartSensor.last } bpm` });
                }), heartSensor.addEventListener(heartSensor.event.LAST, function () {
                    normal$_$text_02b8ea4c15ba4f7492a3ac5736998fe3.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current } steps - ${ calorieSensor.current } kcal - ${ heartSensor.last } bpm` });
                });
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                normal$_$text_bdd4f55f022444f58de12ed803fd354b.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.month }` });
                            },
                            () => {
                                normal$_$text_bdd4f55f022444f58de12ed803fd354b.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.month }` });
                            },
                            () => {
                                normal$_$text_bdd4f55f022444f58de12ed803fd354b.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.month }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                normal$_$text_57ed35227bfd4238acd17de98ee9a749.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                            },
                            () => {
                                normal$_$text_57ed35227bfd4238acd17de98ee9a749.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                            },
                            () => {
                                normal$_$text_57ed35227bfd4238acd17de98ee9a749.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                normal$_$text_60f8a516bf834f698e67f6a65f7f7184.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }` });
                            },
                            () => {
                                normal$_$text_60f8a516bf834f698e67f6a65f7f7184.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }` });
                            },
                            () => {
                                normal$_$text_60f8a516bf834f698e67f6a65f7f7184.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                        normal$_$text_02b8ea4c15ba4f7492a3ac5736998fe3.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current } steps - ${ calorieSensor.current } kcal - ${ heartSensor.last } bpm` });
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}