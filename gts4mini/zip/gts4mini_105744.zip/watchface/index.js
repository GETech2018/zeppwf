try {
  (() => {

    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

/*
* huamiOS bundle tool v1.0.17
* Copyright © Huami. All Rights Reserved
*/
    'use strict';

    console.log("----->>>current")
    console.log(__$$hmAppManager$$__.currentApp.pid)
    console.log(__$$hmAppManager$$__.currentApp.current)

    /*params声明*/
   
    let strRootPath = "images/"
    let nX = 0
    let nY = 0
    let pageX = 168
    let pageY = 192
    let arrTime = []
    let arrWeek = []
    let arrData = []
    let arrLevel = []

    let objBg = {
      x: nX,
      y: nY,
      src: strRootPath + "background/bg.png",
      show_level: hmUI.show_level.ONLY_NORMAL,
    }
    let objPointer = {
      hour_centerX: pageX,
      hour_centerY: pageY,
      hour_posX: 16,
      hour_posY: 168,
      hour_path: strRootPath + "time/hour.png",
      minute_centerX: pageX,
      minute_centerY: pageY,
      minute_posX: 16,
      minute_posY: 168,
      minute_path: strRootPath + "time/minute.png",
      second_centerX: pageX,
      second_centerY: pageY,
      second_posX: 16,
      second_posY: 168,
      second_path: strRootPath + "time/sec.png",
      show_level: hmUI.show_level.ONLY_NORMAL
    }
    let objAodPointer = {
      hour_centerX: pageX,
      hour_centerY: pageY,
      hour_posX: 16,
      hour_posY: 168,
      hour_path: strRootPath + "time/hour.png",
      minute_centerX: pageX,
      minute_centerY: pageY,
      minute_posX: 16,
      minute_posY: 168,
      minute_path: strRootPath + "time/minute.png",
      show_level: hmUI.show_level.ONAL_AOD 
    }
    let objWeek = {
      x: 88,
      y: 241,
      week_en: arrWeek,
      week_sc: arrWeek,
      show_level: hmUI.show_level.ONLY_NORMAL
    }
   
    /*遍历数组*/
    for(i = 0; i < 11; i++){
      if( i < 8 && i > 0 ){
        arrWeek.push(strRootPath+"week/"+i+".png")
      }
      if(i < 10){
        arrTime.push(strRootPath+"Time_number/"+i+".png")
        arrData.push(strRootPath+"data/font/"+i+".png")
      }
        arrLevel.push(strRootPath+"data/level/"+i+".png")
    }

    const logger = DeviceRuntimeCore.HmLogger.getLogger("xiping");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      
      /* 获取数值--电量/湿度/步数/卡路里/天气温度/PAI/心率 */
      getFont(options) {
        let objConfig = {
          x: 0,
          y: 0,
          w: 50,
          type: "",
          font_array: arrData,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          unit_sc: "",
          unit_en: "",
          invalid_image: "",
          dot_image:"",
          padding: !1,
          negative_image: "",
          show_level: hmUI.show_level.ONLY_NORMAL
        }
        for (let key in options) {
          if (key in objConfig) {
            objConfig[key] = options[key]
          }
        }
        for (let key in objConfig) {
          if (!objConfig[key]) {
            delete objConfig[key]
          }
        }
        let text = hmUI.createWidget(hmUI.widget.TEXT_IMG, objConfig)
      },
      /* 获取进度--电量/湿度/步数/卡路里 */
      getLevel(options) {
        let { x, y, arr, type } = options
        let progress = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: x,
          y: y,
          image_array: arr,
          image_length: arr.length, //长度
          type: type,
          show_level: hmUI.show_level.ONLY_NORMAL
        })
      },

      /* 获取图标--Bluetooth / clock / disturb / lock */
      getIcon(options){
        let { x, y, type, src  } = options
        let icon = hmUI.createWidget(hmUI.widget.IMG, {
          x: x,
          y: y,
          src: src,
          type: type,
          show_level: hmUI.show_level.ONLY_NORMAL,
        })
       
      },

      init_view() {

        /* 正常背景 */
        let bg = hmUI.createWidget(hmUI.widget.IMG, objBg)

        /* 星期 */
        let timeWeek = hmUI.createWidget(hmUI.widget.IMG_WEEK, objWeek)

        /* HEART */
        this.getFont({ x: 21, y: 38, type: hmUI.data_type.HEART,invalid_image:strRootPath +"data/font/null.png"})

        /* PAI */ 
        this.getFont({ x: 262, y: 38,type: hmUI.data_type.PAI_WEEKLY})

        /* 湿度 */
        this.getFont({ x: 21, y: 330,type: hmUI.data_type.HUMIDITY, invalid_image:strRootPath +"data/font/null.png",})

        /* UVI */
        this.getFont({ x: 262, y: 330,type: hmUI.data_type.UVI,invalid_image:strRootPath +"data/font/null.png"})

        /* level */
        this.getLevel({ x: 19,y: 18, arr: arrLevel, type: hmUI.data_type.HEART})
        this.getLevel({ x: 259,y: 18, arr: arrLevel, type: hmUI.data_type.PAI_WEEKLY})
        this.getLevel({ x: 259,y: 313, arr: arrLevel, type: hmUI.data_type.UVI})
        this.getLevel({ x: 19,y: 313, arr: arrLevel, type: hmUI.data_type.HUMIDITY})

        /* 亮屏时间指针 */
        let timePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, objPointer)

         /* 息屏时间指针 */
        let timeAodPointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, objAodPointer)

      },

      onInit() {
        console.log('index page.js on init invoke')
        this.init_view();
      },

      onReady() {
        console.log('index page.js on ready invoke')
      },

      onShow() {
        console.log('index page.js on show invoke')
      },

      onHide() {
        console.log('index page.js on hide invoke')
      },

      onDestory() {
        console.log('index page.js on destory invoke')
      },
    });
    /*
    * end js
    */
  })()
} catch (e) {
  console.log(e)
}
