try {
  (() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');
    /*
  * huamiOS bundle tool v1.0.17
  * Copyright © Huami. All Rights Reserved
  */
    'use strict';
    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let nHourX = 21
    let nHourY = 4
    let nMinuteY = 192 

   
    let arrTime = [];
    let arrAodTime = [];   
    for (let i = 0; i < 10; i++) {    
      arrTime.push(`images/time/${i}.png`)
      arrAodTime.push(`images/aodtime/${i}.png`)     
    } 
    let objTime = {
      hour_zero: true,
      hour_startX: nHourX,
      hour_startY: nHourY,
      hour_array: arrTime,
      hour_align: hmUI.align.LEFT,
      hour_unit_sc: "images/time/dot.png",
      hour_unit_tc: "images/time/dot.png",
      hour_unit_en: "images/time/dot.png",
      hour_space: 0,
      minute_zero: true,
      minute_startX: nHourX,
      minute_startY: nMinuteY,
      minute_array: arrTime,
      minute_align: hmUI.align.LEFT,
      minute_space: 0,
      show_level: hmUI.show_level.ONLY_NORMAL,
    }
    let objAodTime = { ...objTime }
    objAodTime.hour_array = arrAodTime
    objAodTime.minute_array = arrAodTime
    objAodTime.show_level = hmUI.show_level.ONAL_AOD   

    let objImg = { //表盘底层背景
      x: 0,
      y: 0,
      src: "images/bg/bg.png",
      show_level: hmUI.show_level.ONLY_NORMAL,
    }   
    const logger = DeviceRuntimeCore.HmLogger.getLogger("defult");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {

        hmUI.createWidget(hmUI.widget.IMG, objImg)  
        hmUI.createWidget(hmUI.widget.IMG_TIME, objTime)
        hmUI.createWidget(hmUI.widget.IMG_TIME, objAodTime)

      
     
       
      },
      onInit() {
        console.log('index page.js on init invoke');
        this.init_view();
      },
      onReady() {
        console.log('index page.js on ready invoke')
      },
      onShow() {
        console.log('index page.js on show invoke')
      },
      onHide() {
        console.log('index page.js on hide invoke')
      },
      onDestory() {
        console.log('index page.js on destory invoke')
      },
    });
    /*
    * end js
    */
  })()
} catch (e) {
  console.log(e)
}
