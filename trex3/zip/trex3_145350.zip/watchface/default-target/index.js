try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '3.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 211,
                    y: 35,
                    image_array: [
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png'
                    ],
                    image_length: 29,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 195,
                    y: 109,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: [
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -7,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '45.png',
                    unit_tc: '45.png',
                    unit_en: '45.png',
                    negative_image: '44.png',
                    invalid_image: '43.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 326,
                    y: 134,
                    type: hmUI.data_type.WEATHER_HIGH,
                    font_array: [
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png',
                        '54.png',
                        '55.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: -5,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '58.png',
                    unit_tc: '58.png',
                    unit_en: '58.png',
                    negative_image: '57.png',
                    invalid_image: '56.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 101,
                    y: 134,
                    type: hmUI.data_type.WEATHER_LOW,
                    font_array: [
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png',
                        '54.png',
                        '55.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: -5,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '61.png',
                    unit_tc: '61.png',
                    unit_en: '61.png',
                    negative_image: '60.png',
                    invalid_image: '59.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 173,
                    y: 343,
                    type: hmUI.data_type.STEP,
                    font_array: [
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -4,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '62.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 118,
                    y: 438,
                    image_array: [
                        '63.png',
                        '64.png',
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png',
                        '71.png',
                        '72.png'
                    ],
                    image_length: 10,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 210,
                    y: 442,
                    type: hmUI.data_type.BATTERY,
                    font_array: [
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png',
                        '54.png',
                        '55.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -4,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '74.png',
                    unit_tc: '74.png',
                    unit_en: '74.png',
                    invalid_image: '73.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 79,
                    y: 304,
                    src: '75.png',
                    type: hmUI.system_status.DISCONNECT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 329,
                    y: 304,
                    src: '76.png',
                    type: hmUI.system_status.CLOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 108,
                    y: 393,
                    type: hmUI.data_type.DISTANCE,
                    font_array: [
                        '77.png',
                        '78.png',
                        '79.png',
                        '80.png',
                        '81.png',
                        '82.png',
                        '83.png',
                        '84.png',
                        '85.png',
                        '86.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: -4,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '89.png',
                    unit_tc: '89.png',
                    unit_en: '89.png',
                    imperial_unit_sc: '90.png',
                    imperial_unit_tc: '90.png',
                    imperial_unit_en: '90.png',
                    dot_image: '88.png',
                    invalid_image: '87.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 280,
                    y: 393,
                    type: hmUI.data_type.HEART,
                    font_array: [
                        '77.png',
                        '78.png',
                        '79.png',
                        '80.png',
                        '81.png',
                        '82.png',
                        '83.png',
                        '84.png',
                        '85.png',
                        '86.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: -4,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '91.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 295,
                    y: 81,
                    week_en: [
                        '92.png',
                        '93.png',
                        '94.png',
                        '95.png',
                        '96.png',
                        '97.png',
                        '98.png'
                    ],
                    week_sc: [
                        '99.png',
                        '100.png',
                        '101.png',
                        '102.png',
                        '103.png',
                        '104.png',
                        '105.png'
                    ],
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 113,
                    month_startY: 81,
                    month_sc_array: [
                        '106.png',
                        '107.png',
                        '108.png',
                        '109.png',
                        '110.png',
                        '111.png',
                        '112.png',
                        '113.png',
                        '114.png',
                        '115.png'
                    ],
                    month_tc_array: [
                        '106.png',
                        '107.png',
                        '108.png',
                        '109.png',
                        '110.png',
                        '111.png',
                        '112.png',
                        '113.png',
                        '114.png',
                        '115.png'
                    ],
                    month_en_array: [
                        '106.png',
                        '107.png',
                        '108.png',
                        '109.png',
                        '110.png',
                        '111.png',
                        '112.png',
                        '113.png',
                        '114.png',
                        '115.png'
                    ],
                    month_align: hmUI.align.LEFT,
                    month_zero: 1,
                    month_follow: 0,
                    month_space: -1,
                    month_is_character: false,
                    day_startX: 164,
                    day_startY: 81,
                    day_sc_array: [
                        '116.png',
                        '117.png',
                        '118.png',
                        '119.png',
                        '120.png',
                        '121.png',
                        '122.png',
                        '123.png',
                        '124.png',
                        '125.png'
                    ],
                    day_tc_array: [
                        '116.png',
                        '117.png',
                        '118.png',
                        '119.png',
                        '120.png',
                        '121.png',
                        '122.png',
                        '123.png',
                        '124.png',
                        '125.png'
                    ],
                    day_en_array: [
                        '116.png',
                        '117.png',
                        '118.png',
                        '119.png',
                        '120.png',
                        '121.png',
                        '122.png',
                        '123.png',
                        '124.png',
                        '125.png'
                    ],
                    day_align: hmUI.align.LEFT,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: -1,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 82,
                    hour_startY: 173,
                    hour_array: [
                        '126.png',
                        '127.png',
                        '128.png',
                        '129.png',
                        '130.png',
                        '131.png',
                        '132.png',
                        '133.png',
                        '134.png',
                        '135.png'
                    ],
                    hour_space: 6,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 270,
                    minute_startY: 173,
                    minute_array: [
                        '126.png',
                        '127.png',
                        '128.png',
                        '129.png',
                        '130.png',
                        '131.png',
                        '132.png',
                        '133.png',
                        '134.png',
                        '135.png'
                    ],
                    minute_space: 6,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    second_zero: 1,
                    second_startX: 403,
                    second_startY: 242,
                    second_array: [
                        '136.png',
                        '137.png',
                        '138.png',
                        '139.png',
                        '140.png',
                        '141.png',
                        '142.png',
                        '143.png',
                        '144.png',
                        '145.png'
                    ],
                    second_space: -1,
                    second_align: hmUI.align.LEFT,
                    second_follow: 0,
                    am_x: 36,
                    am_y: 216,
                    am_sc_path: '146.png',
                    am_en_path: '147.png',
                    pm_x: 36,
                    pm_y: 216,
                    pm_sc_path: '148.png',
                    pm_en_path: '149.png',
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '150.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 120,
                    month_startY: 112,
                    month_sc_array: [
                        '151.png',
                        '152.png',
                        '153.png',
                        '154.png',
                        '155.png',
                        '156.png',
                        '157.png',
                        '158.png',
                        '159.png',
                        '160.png'
                    ],
                    month_tc_array: [
                        '151.png',
                        '152.png',
                        '153.png',
                        '154.png',
                        '155.png',
                        '156.png',
                        '157.png',
                        '158.png',
                        '159.png',
                        '160.png'
                    ],
                    month_en_array: [
                        '151.png',
                        '152.png',
                        '153.png',
                        '154.png',
                        '155.png',
                        '156.png',
                        '157.png',
                        '158.png',
                        '159.png',
                        '160.png'
                    ],
                    month_align: hmUI.align.LEFT,
                    month_zero: 1,
                    month_follow: 0,
                    month_space: -1,
                    month_is_character: false,
                    day_startX: 168,
                    day_startY: 112,
                    day_sc_array: [
                        '151.png',
                        '152.png',
                        '153.png',
                        '154.png',
                        '155.png',
                        '156.png',
                        '157.png',
                        '158.png',
                        '159.png',
                        '160.png'
                    ],
                    day_tc_array: [
                        '151.png',
                        '152.png',
                        '153.png',
                        '154.png',
                        '155.png',
                        '156.png',
                        '157.png',
                        '158.png',
                        '159.png',
                        '160.png'
                    ],
                    day_en_array: [
                        '151.png',
                        '152.png',
                        '153.png',
                        '154.png',
                        '155.png',
                        '156.png',
                        '157.png',
                        '158.png',
                        '159.png',
                        '160.png'
                    ],
                    day_align: hmUI.align.LEFT,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: -1,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 299,
                    y: 113,
                    week_en: [
                        '161.png',
                        '162.png',
                        '163.png',
                        '164.png',
                        '165.png',
                        '166.png',
                        '167.png'
                    ],
                    week_sc: [
                        '168.png',
                        '169.png',
                        '170.png',
                        '171.png',
                        '172.png',
                        '173.png',
                        '174.png'
                    ],
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 173,
                    y: 343,
                    type: hmUI.data_type.STEP,
                    font_array: [
                        '175.png',
                        '176.png',
                        '177.png',
                        '178.png',
                        '179.png',
                        '180.png',
                        '181.png',
                        '182.png',
                        '183.png',
                        '184.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -4,
                    show_level: hmUI.show_level.ONLY_AOD,
                    invalid_image: '185.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 209,
                    y: 422,
                    type: hmUI.data_type.BATTERY,
                    font_array: [
                        '186.png',
                        '187.png',
                        '188.png',
                        '189.png',
                        '190.png',
                        '191.png',
                        '192.png',
                        '193.png',
                        '194.png',
                        '195.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -2,
                    show_level: hmUI.show_level.ONLY_AOD,
                    unit_sc: '197.png',
                    unit_tc: '197.png',
                    unit_en: '197.png',
                    invalid_image: '196.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 82,
                    hour_startY: 172,
                    hour_array: [
                        '198.png',
                        '199.png',
                        '200.png',
                        '201.png',
                        '202.png',
                        '203.png',
                        '204.png',
                        '205.png',
                        '206.png',
                        '207.png'
                    ],
                    hour_space: 6,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 270,
                    minute_startY: 172,
                    minute_array: [
                        '198.png',
                        '199.png',
                        '200.png',
                        '201.png',
                        '202.png',
                        '203.png',
                        '204.png',
                        '205.png',
                        '206.png',
                        '207.png'
                    ],
                    minute_space: 6,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    am_x: 36,
                    am_y: 247,
                    am_sc_path: '208.png',
                    am_en_path: '209.png',
                    pm_x: 36,
                    pm_y: 247,
                    pm_sc_path: '210.png',
                    pm_en_path: '211.png',
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}