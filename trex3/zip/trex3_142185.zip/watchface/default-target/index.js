try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$component_0$_$component = '';
        let normal$_$component_1$_$component = '';
        let normal$_$component_2$_$component = '';
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 358,
                    y: 407,
                    type: hmUI.data_type.WIND,
                    font_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '13.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: '14.png',
                    center_x: 240,
                    center_y: 240,
                    x: 10,
                    y: 235,
                    type: hmUI.data_type.WIND,
                    start_angle: 43,
                    end_angle: 136,
                    cover_x: 0,
                    cover_y: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 100,
                    y: 407,
                    type: hmUI.data_type.UVI,
                    font_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '15.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: '16.png',
                    center_x: 240,
                    center_y: 240,
                    x: 10,
                    y: 235,
                    type: hmUI.data_type.UVI,
                    start_angle: -136,
                    end_angle: -43,
                    cover_x: 0,
                    cover_y: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    year_startX: 266,
                    year_startY: 22,
                    year_sc_array: [
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png'
                    ],
                    year_tc_array: [
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png'
                    ],
                    year_en_array: [
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png'
                    ],
                    year_align: hmUI.align.CENTER_H,
                    year_zero: 0,
                    year_space: 0,
                    year_is_character: false,
                    month_startX: 222,
                    month_startY: 22,
                    month_sc_array: [
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png'
                    ],
                    month_tc_array: [
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png'
                    ],
                    month_en_array: [
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png'
                    ],
                    month_unit_sc: '27.png',
                    month_unit_tc: '27.png',
                    month_unit_en: '27.png',
                    month_align: hmUI.align.CENTER_H,
                    month_zero: 1,
                    month_follow: 0,
                    month_space: 0,
                    month_is_character: false,
                    day_startX: 178,
                    day_startY: 22,
                    day_sc_array: [
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png'
                    ],
                    day_tc_array: [
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png'
                    ],
                    day_en_array: [
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png'
                    ],
                    day_unit_sc: '28.png',
                    day_unit_tc: '28.png',
                    day_unit_en: '28.png',
                    day_align: hmUI.align.CENTER_H,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 0,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 140,
                    y: 55,
                    week_en: [
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png'
                    ],
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 95,
                    y: 302,
                    image_array: [
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png',
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png',
                        '58.png',
                        '59.png',
                        '60.png',
                        '61.png',
                        '62.png',
                        '63.png',
                        '64.png'
                    ],
                    image_length: 29,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 175,
                    y: 319,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: [
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png',
                        '71.png',
                        '72.png',
                        '73.png',
                        '74.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    negative_image: '76.png',
                    invalid_image: '75.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 348,
                    y: 328,
                    type: hmUI.data_type.WEATHER_HIGH,
                    font_array: [
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    negative_image: '78.png',
                    invalid_image: '77.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 287,
                    y: 328,
                    type: hmUI.data_type.WEATHER_LOW,
                    font_array: [
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '81.png',
                    unit_tc: '81.png',
                    unit_en: '81.png',
                    negative_image: '80.png',
                    invalid_image: '79.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 83,
                    hour_startY: 95,
                    hour_array: [
                        '83.png',
                        '84.png',
                        '85.png',
                        '86.png',
                        '87.png',
                        '88.png',
                        '89.png',
                        '90.png',
                        '91.png',
                        '92.png'
                    ],
                    hour_space: 10,
                    hour_unit_sc: '93.png',
                    hour_unit_tc: '93.png',
                    hour_unit_en: '93.png',
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 257,
                    minute_startY: 95,
                    minute_array: [
                        '83.png',
                        '84.png',
                        '85.png',
                        '86.png',
                        '87.png',
                        '88.png',
                        '89.png',
                        '90.png',
                        '91.png',
                        '92.png'
                    ],
                    minute_space: 10,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    second_zero: 1,
                    second_startX: 228,
                    second_startY: 112,
                    second_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    second_space: 0,
                    second_align: hmUI.align.LEFT,
                    second_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$component_0$_$component = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: 1,
                    x: 67,
                    y: 167,
                    w: 110,
                    h: 110,
                    select_image: '94.png',
                    un_select_image: '95.png',
                    default_type: hmUI.edit_type.HEART,
                    optional_types: [
                        {
                            'type': hmUI.edit_type.HEART,
                            'preview': '97.png'
                        },
                        {
                            'type': hmUI.edit_type.BATTERY,
                            'preview': '98.png'
                        },
                        {
                            'type': 'hmUI.data_type.STRESS',
                            'preview': '99.png'
                        }
                    ],
                    count: 3,
                    select_list: {
                        title_font_size: 34,
                        title_align_h: hmUI.align.CENTER_H,
                        list_item_vspace: 8,
                        list_tips_text_font_size: 32,
                        list_tips_text_align_h: hmUI.align.LEFT
                    },
                    tips_BG: '96.png',
                    tips_x: 6,
                    tips_y: 123,
                    tips_width: 104,
                    tips_margin: 0
                });
                editType = normal$_$component_0$_$component.getProperty(hmUI.prop.CURRENT_TYPE);
                switch (editType) {
                case hmUI.edit_type.STEP:
                    break;
                case hmUI.edit_type.BATTERY:
                    hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                        x: 111,
                        y: 253,
                        image_array: [
                            '100.png',
                            '101.png',
                            '102.png',
                            '103.png',
                            '104.png',
                            '105.png',
                            '106.png',
                            '107.png',
                            '108.png',
                            '109.png'
                        ],
                        image_length: 10,
                        type: hmUI.data_type.BATTERY,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 93,
                        y: 207,
                        type: hmUI.data_type.BATTERY,
                        font_array: [
                            '110.png',
                            '111.png',
                            '112.png',
                            '113.png',
                            '114.png',
                            '115.png',
                            '116.png',
                            '117.png',
                            '118.png',
                            '119.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        unit_sc: '120.png',
                        unit_tc: '120.png',
                        unit_en: '120.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 70,
                        y: 170,
                        src: '121.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                        src: '122.png',
                        center_x: 122,
                        center_y: 220,
                        x: 7,
                        y: 53,
                        type: hmUI.data_type.BATTERY,
                        start_angle: -135,
                        end_angle: 135,
                        cover_x: 0,
                        cover_y: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 85,
                        y: 185,
                        w: 75,
                        h: 75,
                        type: hmUI.data_type.BATTERY,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.HEART:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 99,
                        y: 207,
                        type: hmUI.data_type.HEART,
                        font_array: [
                            '123.png',
                            '124.png',
                            '125.png',
                            '126.png',
                            '127.png',
                            '128.png',
                            '129.png',
                            '130.png',
                            '131.png',
                            '132.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '133.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 70,
                        y: 170,
                        src: '134.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                        src: '135.png',
                        center_x: 122,
                        center_y: 220,
                        x: 7,
                        y: 53,
                        type: hmUI.data_type.HEART,
                        start_angle: -135,
                        end_angle: 135,
                        cover_x: 0,
                        cover_y: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 85,
                        y: 185,
                        w: 75,
                        h: 75,
                        src: '136.png',
                        type: hmUI.data_type.HEART,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.CAL:
                    break;
                case hmUI.edit_type.PAI_DAILY:
                    break;
                case hmUI.edit_type.DISTANCE:
                    break;
                case hmUI.edit_type.AQI:
                    break;
                case hmUI.edit_type.HUMIDITY:
                    break;
                case hmUI.edit_type.ALTIMETER:
                    break;
                case hmUI.edit_type.STRESS:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 100,
                        y: 207,
                        type: hmUI.data_type.STRESS,
                        font_array: [
                            '137.png',
                            '138.png',
                            '139.png',
                            '140.png',
                            '141.png',
                            '142.png',
                            '143.png',
                            '144.png',
                            '145.png',
                            '146.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '147.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 70,
                        y: 170,
                        src: '148.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                        src: '149.png',
                        center_x: 122,
                        center_y: 220,
                        x: 7,
                        y: 53,
                        type: hmUI.data_type.STRESS,
                        start_angle: -135,
                        end_angle: 135,
                        cover_x: 0,
                        cover_y: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 85,
                        y: 185,
                        w: 75,
                        h: 75,
                        src: '150.png',
                        type: hmUI.data_type.STRESS,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.WIND:
                    break;
                case hmUI.edit_type.SPO2:
                    break;
                case hmUI.edit_type.TRAINING_LOAD:
                    break;
                case hmUI.edit_type.VO2MAX:
                    break;
                case hmUI.edit_type.UVI:
                    break;
                case hmUI.edit_type.DATE:
                    break;
                case hmUI.edit_type.WEEK:
                    break;
                case hmUI.edit_type.WEATHER:
                    break;
                case hmUI.edit_type.TEMPERATURE:
                    break;
                case hmUI.edit_type.SUN:
                    break;
                }
                normal$_$component_1$_$component = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: 2,
                    x: 187,
                    y: 167,
                    w: 110,
                    h: 110,
                    select_image: '151.png',
                    un_select_image: '152.png',
                    default_type: hmUI.edit_type.STEP,
                    optional_types: [
                        {
                            'type': hmUI.edit_type.STEP,
                            'preview': '154.png'
                        },
                        {
                            'type': hmUI.edit_type.CAL,
                            'preview': '155.png'
                        }
                    ],
                    count: 2,
                    select_list: {
                        title_font_size: 34,
                        title_align_h: hmUI.align.CENTER_H,
                        list_item_vspace: 8,
                        list_tips_text_font_size: 32,
                        list_tips_text_align_h: hmUI.align.LEFT
                    },
                    tips_BG: '153.png',
                    tips_x: 2,
                    tips_y: 123,
                    tips_width: 104,
                    tips_margin: 0
                });
                editType = normal$_$component_1$_$component.getProperty(hmUI.prop.CURRENT_TYPE);
                switch (editType) {
                case hmUI.edit_type.STEP:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 207,
                        y: 207,
                        type: hmUI.data_type.STEP,
                        font_array: [
                            '156.png',
                            '157.png',
                            '158.png',
                            '159.png',
                            '160.png',
                            '161.png',
                            '162.png',
                            '163.png',
                            '164.png',
                            '165.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -1,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '166.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 190,
                        y: 170,
                        src: '167.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                        src: '168.png',
                        center_x: 243,
                        center_y: 220,
                        x: 7,
                        y: 53,
                        type: hmUI.data_type.STEP,
                        start_angle: -135,
                        end_angle: 135,
                        cover_x: 0,
                        cover_y: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 206,
                        y: 185,
                        w: 75,
                        h: 75,
                        type: hmUI.data_type.STEP,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.BATTERY:
                    break;
                case hmUI.edit_type.HEART:
                    break;
                case hmUI.edit_type.CAL:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 213,
                        y: 207,
                        type: hmUI.data_type.CAL,
                        font_array: [
                            '169.png',
                            '170.png',
                            '171.png',
                            '172.png',
                            '173.png',
                            '174.png',
                            '175.png',
                            '176.png',
                            '177.png',
                            '178.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '179.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 190,
                        y: 170,
                        src: '180.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                        src: '181.png',
                        center_x: 243,
                        center_y: 220,
                        x: 7,
                        y: 53,
                        type: hmUI.data_type.CAL,
                        start_angle: -135,
                        end_angle: 135,
                        cover_x: 0,
                        cover_y: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 206,
                        y: 185,
                        w: 75,
                        h: 75,
                        type: hmUI.data_type.CAL,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.PAI_DAILY:
                    break;
                case hmUI.edit_type.DISTANCE:
                    break;
                case hmUI.edit_type.AQI:
                    break;
                case hmUI.edit_type.HUMIDITY:
                    break;
                case hmUI.edit_type.ALTIMETER:
                    break;
                case hmUI.edit_type.STRESS:
                    break;
                case hmUI.edit_type.WIND:
                    break;
                case hmUI.edit_type.SPO2:
                    break;
                case hmUI.edit_type.TRAINING_LOAD:
                    break;
                case hmUI.edit_type.VO2MAX:
                    break;
                case hmUI.edit_type.UVI:
                    break;
                case hmUI.edit_type.DATE:
                    break;
                case hmUI.edit_type.WEEK:
                    break;
                case hmUI.edit_type.WEATHER:
                    break;
                case hmUI.edit_type.TEMPERATURE:
                    break;
                case hmUI.edit_type.SUN:
                    break;
                }
                normal$_$component_2$_$component = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: 3,
                    x: 307,
                    y: 167,
                    w: 110,
                    h: 110,
                    select_image: '182.png',
                    un_select_image: '183.png',
                    default_type: hmUI.edit_type.TRAINING_LOAD,
                    optional_types: [
                        {
                            'type': hmUI.edit_type.TRAINING_LOAD,
                            'preview': '185.png'
                        },
                        {
                            'type': hmUI.edit_type.VO2MAX,
                            'preview': '186.png'
                        },
                        {
                            'type': hmUI.edit_type.PAI_DAILY,
                            'preview': '187.png'
                        }
                    ],
                    count: 3,
                    select_list: {
                        title_font_size: 34,
                        title_align_h: hmUI.align.CENTER_H,
                        list_item_vspace: 8,
                        list_tips_text_font_size: 32,
                        list_tips_text_align_h: hmUI.align.LEFT
                    },
                    tips_BG: '184.png',
                    tips_x: 2,
                    tips_y: 123,
                    tips_width: 104,
                    tips_margin: 0
                });
                editType = normal$_$component_2$_$component.getProperty(hmUI.prop.CURRENT_TYPE);
                switch (editType) {
                case hmUI.edit_type.STEP:
                    break;
                case hmUI.edit_type.BATTERY:
                    break;
                case hmUI.edit_type.HEART:
                    break;
                case hmUI.edit_type.CAL:
                    break;
                case hmUI.edit_type.PAI_DAILY:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 339,
                        y: 207,
                        type: hmUI.data_type.PAI_DAILY,
                        font_array: [
                            '188.png',
                            '189.png',
                            '190.png',
                            '191.png',
                            '192.png',
                            '193.png',
                            '194.png',
                            '195.png',
                            '196.png',
                            '197.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '198.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 310,
                        y: 170,
                        src: '199.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                        src: '200.png',
                        center_x: 362,
                        center_y: 220,
                        x: 7,
                        y: 53,
                        type: hmUI.data_type.PAI_DAILY,
                        start_angle: -135,
                        end_angle: 135,
                        cover_x: 0,
                        cover_y: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 326,
                        y: 185,
                        w: 75,
                        h: 75,
                        src: '201.png',
                        type: hmUI.data_type.PAI_DAILY,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.DISTANCE:
                    break;
                case hmUI.edit_type.AQI:
                    break;
                case hmUI.edit_type.HUMIDITY:
                    break;
                case hmUI.edit_type.ALTIMETER:
                    break;
                case hmUI.edit_type.STRESS:
                    break;
                case hmUI.edit_type.WIND:
                    break;
                case hmUI.edit_type.SPO2:
                    break;
                case hmUI.edit_type.TRAINING_LOAD:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 339,
                        y: 207,
                        w: 60,
                        type: hmUI.data_type.TRAINING_LOAD,
                        font_array: [
                            '202.png',
                            '203.png',
                            '204.png',
                            '205.png',
                            '206.png',
                            '207.png',
                            '208.png',
                            '209.png',
                            '210.png',
                            '211.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '212.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 310,
                        y: 170,
                        src: '213.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                        src: '214.png',
                        center_x: 362,
                        center_y: 220,
                        x: 7,
                        y: 53,
                        type: hmUI.data_type.TRAINING_LOAD,
                        start_angle: -135,
                        end_angle: 135,
                        cover_x: 0,
                        cover_y: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 326,
                        y: 185,
                        w: 75,
                        h: 75,
                        type: hmUI.data_type.TRAINING_LOAD,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.VO2MAX:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 346,
                        y: 207,
                        type: hmUI.data_type.VO2MAX,
                        font_array: [
                            '215.png',
                            '216.png',
                            '217.png',
                            '218.png',
                            '219.png',
                            '220.png',
                            '221.png',
                            '222.png',
                            '223.png',
                            '224.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '225.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 310,
                        y: 170,
                        src: '226.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                        src: '227.png',
                        center_x: 362,
                        center_y: 220,
                        x: 7,
                        y: 53,
                        type: hmUI.data_type.VO2MAX,
                        start_angle: -135,
                        end_angle: 135,
                        cover_x: 0,
                        cover_y: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 326,
                        y: 185,
                        w: 75,
                        h: 75,
                        src: '228.png',
                        type: hmUI.data_type.VO2MAX,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.UVI:
                    break;
                case hmUI.edit_type.DATE:
                    break;
                case hmUI.edit_type.WEEK:
                    break;
                case hmUI.edit_type.WEATHER:
                    break;
                case hmUI.edit_type.TEMPERATURE:
                    break;
                case hmUI.edit_type.SUN:
                    break;
                }
                hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '229.png',
                    show_level: hmUI.show_level.ONLY_EDIT
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 227,
                    y: 443,
                    src: '230.png',
                    type: hmUI.system_status.DISCONNECT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 264,
                    y: 443,
                    src: '231.png',
                    type: hmUI.system_status.LOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 190,
                    y: 443,
                    src: '232.png',
                    type: hmUI.system_status.CLOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '233.png',
                    show_level: hmUI.show_level.ONLY_EDIT
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 83,
                    hour_startY: 207,
                    hour_array: [
                        '83.png',
                        '84.png',
                        '85.png',
                        '86.png',
                        '87.png',
                        '88.png',
                        '89.png',
                        '90.png',
                        '91.png',
                        '92.png'
                    ],
                    hour_space: 10,
                    hour_unit_sc: '234.png',
                    hour_unit_tc: '234.png',
                    hour_unit_en: '234.png',
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 257,
                    minute_startY: 207,
                    minute_array: [
                        '83.png',
                        '84.png',
                        '85.png',
                        '86.png',
                        '87.png',
                        '88.png',
                        '89.png',
                        '90.png',
                        '91.png',
                        '92.png'
                    ],
                    minute_space: 10,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 130,
                    y: 305,
                    w: 130,
                    h: 75,
                    src: '82.png',
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
				
				hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 135,
              y: 390, 
              text: '',
              w: 60, 
              h: 60, 
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
               click_func: () => {
              hmApp.startApp({ url: 'PhoneRecentCallScreen', native: true });
              },
               longpress_func: () => {
              hmApp.startApp({ url: 'PhoneContactsScreen', native: true });
              },
                show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 283,
              y: 390, 
              text: '',
              w: 60, 
              h: 60, 
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
               click_func: () => {
              hmApp.startApp({ url: 'LocalMusicScreen', native: true });
              },
               longpress_func: () => {
              hmApp.startApp({ url: 'MusicCommonScreen', native: true });
              },
                show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 210,
              y: 390,
              w: 60,
              h: 60,
			  text: '',
			  normal_src: 'Empty.png',
			  press_src: 'Empty.png',
			  click_func: () => {
				hmApp.startApp({ url: 'Settings_homeScreen', native: true });
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}