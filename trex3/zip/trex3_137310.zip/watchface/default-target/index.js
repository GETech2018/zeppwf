try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '4.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 121,
                    hour_startY: 201,
                    hour_array: [
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png'
                    ],
                    hour_space: 5,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 253,
                    minute_startY: 201,
                    minute_array: [
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png'
                    ],
                    minute_space: 5,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    second_val: new Date().getSeconds(),
                    second_zero: 1,
                    second_startX: 365,
                    second_startY: 201,
                    second_array: [
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png'
                    ],
                    second_space: -4,
                    second_align: hmUI.align.CENTER_H,
                    second_follow: 0,
                    am_x: 61,
                    am_y: 201,
                    am_sc_path: '25.png',
                    am_en_path: '26.png',
                    pm_x: 61,
                    pm_y: 201,
                    pm_sc_path: '27.png',
                    pm_en_path: '28.png',
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 220,
                    y: 201,
                    w: 38,
                    h: 70,
                    src: '29.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 177,
                    month_startY: 109,
                    month_sc_array: [
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png'
                    ],
                    month_tc_array: [
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png'
                    ],
                    month_en_array: [
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png',
                        '58.png',
                        '59.png',
                        '60.png',
                        '61.png',
                        '62.png',
                        '63.png',
                        '64.png',
                        '65.png'
                    ],
                    month_align: hmUI.align.LEFT,
                    month_zero: 0,
                    month_follow: 0,
                    month_space: 0,
                    month_is_character: true,
                    day_startX: 252,
                    day_startY: 108,
                    day_sc_array: [
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png',
                        '71.png',
                        '72.png',
                        '73.png',
                        '74.png',
                        '75.png'
                    ],
                    day_tc_array: [
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png',
                        '71.png',
                        '72.png',
                        '73.png',
                        '74.png',
                        '75.png'
                    ],
                    day_en_array: [
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png',
                        '71.png',
                        '72.png',
                        '73.png',
                        '74.png',
                        '75.png'
                    ],
                    day_align: hmUI.align.CENTER_H,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 1,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 82,
                    y: 155,
                    week_en: [
                        '76.png',
                        '77.png',
                        '78.png',
                        '79.png',
                        '80.png',
                        '81.png',
                        '82.png'
                    ],
                    week_tc: [
                        '83.png',
                        '84.png',
                        '85.png',
                        '86.png',
                        '87.png',
                        '88.png',
                        '89.png'
                    ],
                    week_sc: [
                        '90.png',
                        '91.png',
                        '92.png',
                        '93.png',
                        '94.png',
                        '95.png',
                        '96.png'
                    ],
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 161,
                    y: 417,
                    image_array: [
                        '97.png',
                        '98.png',
                        '99.png',
                        '100.png',
                        '101.png',
                        '102.png',
                        '103.png',
                        '104.png',
                        '105.png',
                        '106.png',
                        '107.png',
                        '108.png',
                        '109.png'
                    ],
                    image_length: 13,
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 217,
                    y: 374,
                    type: hmUI.data_type.HEART,
                    font_array: [
                        '110.png',
                        '111.png',
                        '112.png',
                        '113.png',
                        '114.png',
                        '115.png',
                        '116.png',
                        '117.png',
                        '118.png',
                        '119.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -4,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '120.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 346,
                    y: 91,
                    image_array: [
                        '121.png',
                        '122.png',
                        '123.png',
                        '124.png',
                        '125.png',
                        '126.png',
                        '127.png',
                        '128.png',
                        '129.png',
                        '130.png',
                        '131.png',
                        '132.png',
                        '133.png',
                        '134.png',
                        '135.png',
                        '136.png',
                        '137.png',
                        '138.png',
                        '139.png',
                        '140.png',
                        '141.png',
                        '142.png',
                        '143.png',
                        '144.png',
                        '145.png',
                        '146.png',
                        '147.png',
                        '148.png',
                        '149.png'
                    ],
                    image_length: 29,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 61,
                    y: 283,
                    image_array: [
                        '150.png',
                        '151.png',
                        '152.png',
                        '153.png',
                        '154.png',
                        '155.png',
                        '156.png',
                        '157.png',
                        '158.png',
                        '159.png'
                    ],
                    image_length: 10,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 95,
                    y: 332,
                    type: hmUI.data_type.STEP,
                    font_array: [
                        '160.png',
                        '161.png',
                        '162.png',
                        '163.png',
                        '164.png',
                        '165.png',
                        '166.png',
                        '167.png',
                        '168.png',
                        '169.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -3,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '170.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 92,
                    y: 88,
                    image_array: [
                        '171.png',
                        '172.png',
                        '173.png',
                        '174.png',
                        '175.png',
                        '176.png',
                        '177.png',
                        '178.png',
                        '179.png',
                        '180.png',
                        '181.png',
                        '182.png',
                        '183.png',
                        '184.png',
                        '185.png',
                        '186.png',
                        '187.png',
                        '188.png',
                        '189.png',
                        '190.png',
                        '191.png',
                        '192.png',
                        '193.png',
                        '194.png',
                        '195.png',
                        '196.png',
                        '197.png',
                        '198.png',
                        '199.png',
                        '200.png'
                    ],
                    image_length: 30,
                    type: hmUI.data_type.MOON,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 294,
                    y: 283,
                    image_array: [
                        '201.png',
                        '202.png',
                        '203.png',
                        '204.png',
                        '205.png',
                        '206.png',
                        '207.png',
                        '208.png',
                        '209.png',
                        '210.png'
                    ],
                    image_length: 10,
                    type: hmUI.data_type.CAL,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 311,
                    y: 332,
                    type: hmUI.data_type.CAL,
                    font_array: [
                        '211.png',
                        '212.png',
                        '213.png',
                        '214.png',
                        '215.png',
                        '216.png',
                        '217.png',
                        '218.png',
                        '219.png',
                        '220.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -3,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '221.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 160,
                    y: 283,
                    image_array: [
                        '222.png',
                        '223.png',
                        '224.png',
                        '225.png',
                        '226.png',
                        '227.png',
                        '228.png',
                        '229.png',
                        '230.png',
                        '231.png'
                    ],
                    image_length: 10,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 219,
                    y: 332,
                    type: hmUI.data_type.BATTERY,
                    font_array: [
                        '232.png',
                        '233.png',
                        '234.png',
                        '235.png',
                        '236.png',
                        '237.png',
                        '238.png',
                        '239.png',
                        '240.png',
                        '241.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -4,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '242.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 181,
                    y: 64,
                    type: hmUI.data_type.UVI,
                    font_array: [
                        '243.png',
                        '244.png',
                        '245.png',
                        '246.png',
                        '247.png',
                        '248.png',
                        '249.png',
                        '250.png',
                        '251.png',
                        '252.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -2,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '253.png',
                    padding: true,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 254,
                    y: 64,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: [
                        '254.png',
                        '255.png',
                        '256.png',
                        '257.png',
                        '258.png',
                        '259.png',
                        '260.png',
                        '261.png',
                        '262.png',
                        '263.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -3,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '266.png',
                    unit_tc: '266.png',
                    unit_en: '266.png',
                    negative_image: '265.png',
                    invalid_image: '264.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    second_centerX: 240,
                    second_centerY: 240,
                    second_posX: 240,
                    second_posY: 240,
                    second_path: '267.png',
                    second_cover_x: 0,
                    second_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 121,
                    hour_startY: 201,
                    hour_array: [
                        '268.png',
                        '269.png',
                        '270.png',
                        '271.png',
                        '272.png',
                        '273.png',
                        '274.png',
                        '275.png',
                        '276.png',
                        '277.png'
                    ],
                    hour_space: 5,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 253,
                    minute_startY: 201,
                    minute_array: [
                        '268.png',
                        '269.png',
                        '270.png',
                        '271.png',
                        '272.png',
                        '273.png',
                        '274.png',
                        '275.png',
                        '276.png',
                        '277.png'
                    ],
                    minute_space: 5,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 220,
                    y: 201,
                    w: 38,
                    h: 70,
                    src: '278.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 155,
                    y: 375,
                    w: 170,
                    h: 70,
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 70,
                    y: 284,
                    w: 105,
                    h: 80,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 305,
                    y: 284,
                    w: 105,
                    h: 80,
                    type: hmUI.data_type.CAL,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 180,
                    y: 285,
                    w: 120,
                    h: 80,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 175,
                    y: 35,
                    w: 60,
                    h: 60,
                    type: hmUI.data_type.UVI,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 245,
                    y: 30,
                    w: 65,
                    h: 65,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 80,
                    y: 70,
                    w: 70,
                    h: 70,
                    type: hmUI.data_type.SUN_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 330,
                    y: 70,
                    w: 70,
                    h: 70,
                    type: hmUI.data_type.HUMIDITY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}