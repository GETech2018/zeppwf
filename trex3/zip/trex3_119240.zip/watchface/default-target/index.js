try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface6');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '4.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 194,
                    y: 180,
                    image_array: [
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png'
                    ],
                    image_length: 20,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 64,
                    hour_startY: 160,
                    hour_array: [
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png'
                    ],
                    hour_space: 0,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 316,
                    minute_startY: 160,
                    minute_array: [
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png'
                    ],
                    minute_space: 0,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    second_zero: 1,
                    second_startX: 419,
                    second_startY: 216,
                    second_array: [
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png',
                        '54.png',
                        '55.png'
                    ],
                    second_space: 0,
                    second_align: hmUI.align.LEFT,
                    second_follow: 0,
                    am_x: 25,
                    am_y: 229,
                    am_en_path: '56.png',
                    pm_x: 25,
                    pm_y: 229,
                    pm_en_path: '57.png',
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 115,
                    y: 94,
                    type: hmUI.data_type.CAL,
                    font_array: [
                        '58.png',
                        '59.png',
                        '60.png',
                        '61.png',
                        '62.png',
                        '63.png',
                        '64.png',
                        '65.png',
                        '66.png',
                        '67.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '68.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 20,
                    y: 52,
                    image_array: [
                        '69.png',
                        '70.png',
                        '71.png',
                        '72.png',
                        '73.png',
                        '74.png',
                        '75.png',
                        '76.png',
                        '77.png',
                        '78.png'
                    ],
                    image_length: 10,
                    type: hmUI.data_type.CAL,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 371,
                    y: 52,
                    image_array: [
                        '80.png',
                        '81.png',
                        '82.png',
                        '83.png',
                        '84.png',
                        '85.png',
                        '86.png',
                        '87.png',
                        '88.png',
                        '89.png'
                    ],
                    image_length: 10,
                    type: hmUI.data_type.HUMIDITY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 326,
                    y: 94,
                    type: hmUI.data_type.HUMIDITY,
                    font_array: [
                        '90.png',
                        '91.png',
                        '92.png',
                        '93.png',
                        '94.png',
                        '95.png',
                        '96.png',
                        '97.png',
                        '98.png',
                        '99.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '100.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 20,
                    y: 307,
                    image_array: [
                        '102.png',
                        '103.png',
                        '104.png',
                        '105.png',
                        '106.png',
                        '107.png'
                    ],
                    image_length: 6,
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 127,
                    y: 345,
                    type: hmUI.data_type.HEART,
                    font_array: [
                        '108.png',
                        '109.png',
                        '110.png',
                        '111.png',
                        '112.png',
                        '113.png',
                        '114.png',
                        '115.png',
                        '116.png',
                        '117.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '118.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 307,
                    y: 345,
                    type: hmUI.data_type.STEP,
                    font_array: [
                        '90.png',
                        '91.png',
                        '92.png',
                        '93.png',
                        '94.png',
                        '95.png',
                        '96.png',
                        '97.png',
                        '98.png',
                        '99.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '120.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 371,
                    y: 307,
                    image_array: [
                        '121.png',
                        '122.png',
                        '123.png',
                        '124.png',
                        '125.png',
                        '126.png',
                        '127.png',
                        '128.png',
                        '129.png',
                        '130.png'
                    ],
                    image_length: 10,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 213,
                    y: 32,
                    image_array: [
                        '132.png',
                        '133.png',
                        '134.png',
                        '135.png',
                        '136.png',
                        '137.png',
                        '138.png',
                        '139.png',
                        '140.png',
                        '141.png',
                        '142.png',
                        '143.png',
                        '144.png',
                        '145.png',
                        '146.png',
                        '147.png',
                        '148.png',
                        '149.png',
                        '150.png',
                        '151.png',
                        '152.png',
                        '153.png',
                        '154.png',
                        '155.png',
                        '156.png',
                        '157.png',
                        '158.png',
                        '159.png',
                        '160.png'
                    ],
                    image_length: 29,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 224,
                    y: 100,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: [
                        '161.png',
                        '162.png',
                        '163.png',
                        '164.png',
                        '165.png',
                        '166.png',
                        '167.png',
                        '168.png',
                        '169.png',
                        '170.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '173.png',
                    unit_tc: '173.png',
                    unit_en: '173.png',
                    negative_image: '172.png',
                    invalid_image: '171.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 197,
                    y: 341,
                    week_en: [
                        '182.png',
                        '183.png',
                        '184.png',
                        '185.png',
                        '186.png',
                        '187.png',
                        '188.png'
                    ],
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 195,
                    month_startY: 394,
                    month_en_array: [
                        '202.png',
                        '203.png',
                        '204.png',
                        '205.png',
                        '206.png',
                        '207.png',
                        '208.png',
                        '209.png',
                        '210.png',
                        '211.png',
                        '212.png',
                        '213.png',
                        '214.png'
                    ],
                    month_align: hmUI.align.LEFT,
                    month_zero: 0,
                    month_follow: 0,
                    month_space: 0,
                    month_is_character: true,
                    day_startX: 263,
                    day_startY: 346,
                    day_sc_array: [
                        '215.png',
                        '216.png',
                        '217.png',
                        '218.png',
                        '219.png',
                        '220.png',
                        '221.png',
                        '222.png',
                        '223.png',
                        '224.png'
                    ],
                    day_tc_array: [
                        '215.png',
                        '216.png',
                        '217.png',
                        '218.png',
                        '219.png',
                        '220.png',
                        '221.png',
                        '222.png',
                        '223.png',
                        '224.png'
                    ],
                    day_en_array: [
                        '215.png',
                        '216.png',
                        '217.png',
                        '218.png',
                        '219.png',
                        '220.png',
                        '221.png',
                        '222.png',
                        '223.png',
                        '224.png'
                    ],
                    day_align: hmUI.align.LEFT,
                    day_zero: 0,
                    day_follow: 0,
                    day_space: 0,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '225.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 64,
                    hour_startY: 160,
                    hour_array: [
                        '226.png',
                        '227.png',
                        '228.png',
                        '229.png',
                        '230.png',
                        '231.png',
                        '232.png',
                        '233.png',
                        '234.png',
                        '235.png'
                    ],
                    hour_space: 0,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 316,
                    minute_startY: 160,
                    minute_array: [
                        '236.png',
                        '237.png',
                        '238.png',
                        '239.png',
                        '240.png',
                        '241.png',
                        '242.png',
                        '243.png',
                        '244.png',
                        '245.png'
                    ],
                    minute_space: 0,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    am_x: 25,
                    am_y: 229,
                    am_en_path: '246.png',
                    pm_x: 25,
                    pm_y: 229,
                    pm_en_path: '247.png',
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 197,
                    y: 340,
                    week_en: [
                        '255.png',
                        '256.png',
                        '257.png',
                        '258.png',
                        '259.png',
                        '260.png',
                        '261.png'
                    ],
                    week_tc: [
                        '262.png',
                        '263.png',
                        '264.png',
                        '265.png',
                        '266.png',
                        '267.png',
                        '268.png'
                    ],
                    week_sc: [
                        '269.png',
                        '270.png',
                        '271.png',
                        '272.png',
                        '273.png',
                        '274.png',
                        '275.png'
                    ],
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    day_startX: 263,
                    day_startY: 340,
                    day_sc_array: [
                        '276.png',
                        '277.png',
                        '278.png',
                        '279.png',
                        '280.png',
                        '281.png',
                        '282.png',
                        '283.png',
                        '284.png',
                        '285.png'
                    ],
                    day_tc_array: [
                        '276.png',
                        '277.png',
                        '278.png',
                        '279.png',
                        '280.png',
                        '281.png',
                        '282.png',
                        '283.png',
                        '284.png',
                        '285.png'
                    ],
                    day_en_array: [
                        '276.png',
                        '277.png',
                        '278.png',
                        '279.png',
                        '280.png',
                        '281.png',
                        '282.png',
                        '283.png',
                        '284.png',
                        '285.png'
                    ],
                    day_align: hmUI.align.LEFT,
                    day_zero: 0,
                    day_follow: 0,
                    day_space: 0,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 188,
                    y: 175,
                    w: 100,
                    h: 120,
                    src: '25.png',
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 0,
                    y: 0,
                    w: 170,
                    h: 175,
                    src: '79.png',
                    type: hmUI.data_type.CAL,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 310,
                    y: 0,
                    w: 140,
                    h: 170,
                    src: '101.png',
                    type: hmUI.data_type.HUMIDITY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 0,
                    y: 305,
                    w: 160,
                    h: 142,
                    src: '119.png',
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 310,
                    y: 310,
                    w: 140,
                    h: 150,
                    src: '131.png',
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 200,
                    y: 25,
                    w: 80,
                    h: 110,
                    src: '174.png',
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}