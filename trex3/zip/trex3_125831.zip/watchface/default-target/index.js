try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_47e3f820af1a4121abd6b4bd3677ee9b = '';
        let normal$_$text_5981a49be2364d76a76406e8185fa743 = '';
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 114,
                    hour_startY: 179,
                    hour_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    hour_space: 7,
                    hour_align: hmUI.align.RIGHT,
                    minute_zero: 1,
                    minute_startX: 265,
                    minute_startY: 179,
                    minute_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    minute_space: 7,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    second_zero: 1,
                    second_startX: 394,
                    second_startY: 204,
                    second_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    second_space: 7,
                    second_align: hmUI.align.LEFT,
                    second_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 58,
                    y: 194,
                    type: hmUI.data_type.BATTERY,
                    font_array: [
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '34.png',
                    unit_tc: '34.png',
                    unit_en: '34.png',
                    invalid_image: '33.png',
                    padding: false,
                    isCharacter: false
                });
                normal$_$text_47e3f820af1a4121abd6b4bd3677ee9b = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 124,
                    y: 350,
                    w: 235,
                    h: 35,
                    text: 'BlackBTRyt Original',
                    color: '0xFFffff',
                    text_size: 26,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_5981a49be2364d76a76406e8185fa743 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 164,
                    y: 385,
                    w: 90,
                    h: 30,
                    text: 'Made in',
                    color: '0xFFffffff',
                    text_size: 23,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 257,
                    y: 385,
                    src: '35.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '36.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 128,
                    hour_startY: 191,
                    hour_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    hour_space: 7,
                    hour_align: hmUI.align.RIGHT,
                    minute_zero: 1,
                    minute_startX: 275,
                    minute_startY: 191,
                    minute_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    minute_space: 7,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        normal$_$text_47e3f820af1a4121abd6b4bd3677ee9b.setProperty(hmUI.prop.MORE, { text: `BlackBTRyt Original` });
                        normal$_$text_5981a49be2364d76a76406e8185fa743.setProperty(hmUI.prop.MORE, { text: `Made in` });
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}