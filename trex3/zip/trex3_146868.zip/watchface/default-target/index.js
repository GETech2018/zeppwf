try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    day_startX: 357,
                    day_startY: 221,
                    day_sc_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    day_tc_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    day_en_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    day_align: hmUI.align.LEFT,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: -2,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 106,
                    center_y: 272,
                    radius: 30,
                    start_angle: 360,
                    end_angle: 0,
                    color: 4283683730,
                    line_width: 4,
                    src_bg: '13.png',
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 210,
                    y: 163,
                    src: '14.png',
                    type: hmUI.system_status.DISCONNECT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 280,
                    y: 221,
                    week_en: [
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png'
                    ],
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 175,
                    y: 303,
                    image_array: [
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png'
                    ],
                    image_length: 30,
                    type: hmUI.data_type.MOON,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 106,
                    center_y: 204,
                    radius: 30,
                    start_angle: 0,
                    end_angle: 360,
                    color: 4294403686,
                    line_width: 4,
                    src_bg: '52.png',
                    type: hmUI.data_type.CAL,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 160,
                    center_y: 237,
                    radius: 30,
                    start_angle: -110,
                    end_angle: 110,
                    color: 4294616626,
                    line_width: 4,
                    src_bg: '53.png',
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 137,
                    y: 249,
                    type: hmUI.data_type.STEP,
                    font_array: [
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png',
                        '58.png',
                        '59.png',
                        '60.png',
                        '61.png',
                        '62.png',
                        '63.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: -21,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 240,
                    hour_centerY: 240,
                    hour_posX: 40,
                    hour_posY: 240,
                    hour_path: '64.png',
                    hour_cover_x: 200,
                    hour_cover_y: 200,
                    minute_centerX: 240,
                    minute_centerY: 240,
                    minute_posX: 40,
                    minute_posY: 240,
                    minute_path: '65.png',
                    minute_cover_x: 200,
                    minute_cover_y: 200,
                    second_centerX: 240,
                    second_centerY: 240,
                    second_posX: 40,
                    second_posY: 240,
                    second_path: '67.png',
                    second_cover_path: '66.png',
                    second_cover_x: 200,
                    second_cover_y: 200,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '68.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    day_startX: 357,
                    day_startY: 221,
                    day_sc_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    day_tc_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    day_en_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    day_align: hmUI.align.LEFT,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: -2,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 280,
                    y: 221,
                    week_en: [
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png'
                    ],
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 106,
                    center_y: 204,
                    radius: 30,
                    start_angle: 0,
                    end_angle: 360,
                    color: 4294403686,
                    line_width: 4,
                    src_bg: '52.png',
                    type: hmUI.data_type.CAL,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 175,
                    y: 303,
                    image_array: [
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png'
                    ],
                    image_length: 30,
                    type: hmUI.data_type.MOON,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 160,
                    center_y: 237,
                    radius: 30,
                    start_angle: -110,
                    end_angle: 110,
                    color: 4294616626,
                    line_width: 4,
                    src_bg: '53.png',
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 137,
                    y: 249,
                    type: hmUI.data_type.STEP,
                    font_array: [
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png',
                        '58.png',
                        '59.png',
                        '60.png',
                        '61.png',
                        '62.png',
                        '63.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: -21,
                    show_level: hmUI.show_level.ONLY_AOD,
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 106,
                    center_y: 272,
                    radius: 30,
                    start_angle: 360,
                    end_angle: 0,
                    color: 4283683730,
                    line_width: 4,
                    src_bg: '13.png',
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 240,
                    hour_centerY: 240,
                    hour_posX: 40,
                    hour_posY: 240,
                    hour_path: '64.png',
                    hour_cover_x: 200,
                    hour_cover_y: 200,
                    minute_centerX: 240,
                    minute_centerY: 240,
                    minute_posX: 40,
                    minute_posY: 240,
                    minute_path: '70.png',
                    minute_cover_path: '69.png',
                    minute_cover_x: 188,
                    minute_cover_y: 189,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}