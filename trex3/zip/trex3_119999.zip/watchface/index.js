try {
  (() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__),
      "drink"
    );

    /*
     * huamiOS bundle tool v1.0.17
     * Copyright © Huami. All Rights Reserved
     */
    ("use strict");
    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    const ROOTPATH = "images/";
    let percentPath = ROOTPATH + "step_power/percent.png";
    let widgetInvalidPath = ROOTPATH + "data_widget/null.png";
    let widgetEnPath = ROOTPATH + "widget/en/";
    let widgetScPath = ROOTPATH + "widget/sc/";
    let widgetTcPath = ROOTPATH + "widget/tc/";
    let dateSalshPath = ROOTPATH + "date/slash.png";
    let duPath = ROOTPATH + "temperature/du.png";
    let connectorPath = ROOTPATH + "temperature/connector.png";
    let invalidTempPath = ROOTPATH + "temperature/null.png";

    let step_powerDataArr = [];
    let widgetDataArr = [];
    let weekScArr = [];
    let weekEnArr = [];
    let dateArr = [];
    let tempArr = [];
    let num = 1.15;

    for (let i = 0; i < 10; i++) {
      step_powerDataArr.push("images/step_power/" + i + ".png");
      widgetDataArr.push("images/data_widget/" + i + ".png");
      dateArr.push("images/date/" + i + ".png");
      tempArr.push("images/temperature/" + i + ".png");
      if (i > 0 && i < 8) {
        weekScArr.push("images/week/sc/" + i + ".png");
        weekEnArr.push("images/week/en/" + i + ".png");
      }
    }

    let objBg = {
      x: 0,
      y: 0,
      w: 480,
      h: 480,
      src: "images/bg.png",
      show_level: hmUI.show_level.ONLY_NORMAL,
    };

    let objAodBg = {
      ...objBg,
      src: "images/bg_aod.png",
      show_level: hmUI.show_level.ONAL_AOD,
    };

    let objPowerLevel = {
      center_x: 240, // 圆弧中心位置x坐标
      center_y: 110, // 圆弧中心位置y坐标
      radius: 56, // 圆弧内半径
      start_angle: 0, // 开始角度
      end_angle: 360, // 结束角度 (小于'开始角度'时为逆时针)
      color: 0x71df6f, // 填充色
      line_width: 7, // 弧形进度条宽度
      corner_flag: 3, // 可选, 默认0-两端圆角,1-仅起始圆角,2-仅终点圆角,其它值-两端直角
      type: hmUI.data_type.BATTERY, // 设置数据类型来驱动进度,type和level至少要设置一个.
      show_level: hmUI.show_level.ONLY_NORMAL,
    };

    let objStepLevel = {
      center_x: 240, // 圆弧中心位置x坐标
      center_y: 361, // 圆弧中心位置y坐标
      radius: 56, // 圆弧内半径
      start_angle: 0, // 开始角度
      end_angle: 360, // 结束角度 (小于'开始角度'时为逆时针)
      color: 0x71df6f, // 填充色
      line_width: 7, // 弧形进度条宽度
      corner_flag: 3, // 可选, 默认0-两端圆角,1-仅起始圆角,2-仅终点圆角,其它值-两端直角
      type: hmUI.data_type.STEP, // 设置数据类型来驱动进度,type和level至少要设置一个.
      show_level: hmUI.show_level.ONLY_NORMAL,
      //   level: 50,
    };

    let objMaskPower = {
      x: 173,
      y: 43,
      w: 416,
      src: "images/mask/small.png",
      show_level: hmUI.show_level.ONLY_NORMAL,
    };

    let objMaskStep = {
      x: 173,
      y: 294,
      w: 416,
      src: "images/mask/small.png",
      show_level: hmUI.show_level.ONLY_NORMAL,
    };

    let objPowerText = {
      x: 32,
      y: 82,
      w: 416,
      padding: 0,
      unit_sc: percentPath,
      unit_tc: percentPath,
      unit_en: percentPath,
      type: hmUI.data_type.BATTERY,
      font_array: step_powerDataArr,
      h_space: 0,
      align_h: hmUI.align.CENTER_H,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };

    let objStepText = {
      x: 32,
      y: 333,
      w: 416,
      padding: 0,
      type: hmUI.data_type.STEP,
      font_array: step_powerDataArr,
      h_space: 0,
      align_h: hmUI.align.CENTER_H,
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
    };

    let objPowerPointer = {
      src: "images/pointer/power.png",
      center_x: 238, // 圆弧中心位置x坐标
      center_y: 110, // 圆弧中心位置y坐标
      x: 11,
      y: 62,
      type: hmUI.data_type.BATTERY,
      invalid_visible: true, // optional,无数据时指针是否可见,默认显示并指向start_angle
      start_angle: 0,
      end_angle: 360,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };

    function getLanguage() {
      // 语言匹配
      let lang = hmSetting.getLanguage();
      // console.log('language+++++++++++++++++++', lang);
      // 默认
      let iconPath = widgetEnPath;
      if (lang == 0) {
        iconPath = widgetScPath;
      } else if (lang == 1) {
        iconPath = widgetTcPath;
      } else {
        iconPath = widgetEnPath;
      }
      return iconPath;
    }

    function getASLIcon(path) {
      let objASLIcon = {
        x: 38,
        y: 199,
        src: path + "asl.png",
        show_level: hmUI.show_level.ONLY_NORMAL,
      };
      return objASLIcon;
    }

    function getKPAIcon(path) {
      let objKPAIcon = {
        x: 38,
        y: 258,
        src: path + "kpa.png",
        show_level: hmUI.show_level.ONLY_NORMAL,
      };
      return objKPAIcon;
    }

    function getBPMIcon(path) {
      let objBPMIcon = {
        x: 381,
        y: 199,
        src: path + "bpm.png",
        show_level: hmUI.show_level.ONLY_NORMAL,
      };
      return objBPMIcon;
    }

    function getKCALIcon(path) {
      let objKCALIcon = {
        x: 381,
        y: 258,
        src: path + "kcal.png",
        show_level: hmUI.show_level.ONLY_NORMAL,
      };
      return objKCALIcon;
    }
    // 海拔
    let objASLText = {
      x: 95,
      y: 200,
      w: 120,
      type: hmUI.data_type.ALTITUDE,
      // type: hmUI.data_type.ALTIMETER,
      font_array: widgetDataArr,
      h_space: 0,
      align_h: hmUI.align.LEFT,
      invalid_image: widgetInvalidPath,
      negative_image: "images/data_widget/connector.png", // 此处新增负数符号
      padding: 0,
      // text: "9999",
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    // 气压
    let objKPAText = {
      x: 95,
      y: 259,
      w: 120,
      type: hmUI.data_type.ALTIMETER,
      font_array: widgetDataArr,
      h_space: 0,
      align_h: hmUI.align.LEFT,
      invalid_image: widgetInvalidPath,
      padding: 0,
      // text: "9999",
      show_level: hmUI.show_level.ONLY_NORMAL,
    };

    // 心率
    let objBPMText = {
      x: 317,
      y: 200,
      w: 57,
      type: hmUI.data_type.HEART,
      font_array: widgetDataArr,
      h_space: 0,
      align_h: hmUI.align.RIGHT,
      invalid_image: widgetInvalidPath,
      padding: 0,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };

    // 消耗
    let objKCALText = {
      x: 297,
      y: 258,
      w: 75,
      type: hmUI.data_type.CAL,
      font_array: widgetDataArr,
      h_space: 0,
      align_h: hmUI.align.RIGHT,
      // invalid_image: widgetInvalidPath, 卡路里不需要
      padding: 0,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };

    let objWeek = {
      x: 96,
      y: 345,
      // w,h不可设置, 使用weekArray中图片实际宽高
      week_en: weekEnArr,
      week_tc: weekScArr,
      week_sc: weekScArr,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    // WEATHER_CURRENT
    let objTempText = {
      x: 314,
      y: 349,
      w: 64,
      type: hmUI.data_type.WEATHER_CURRENT,
      font_array: tempArr,
      h_space: 0,
      align_h: hmUI.align.CENTER_H,
      invalid_image: invalidTempPath,
      unit_sc: duPath,
      unit_tc: duPath,
      unit_en: duPath,
      negative_image: connectorPath,
      padding: 0,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };

    let objDate = {
      month_startX: 196,
      month_startY: 432,
      month_unit_sc: dateSalshPath, //单位
      month_unit_tc: dateSalshPath,
      month_unit_en: dateSalshPath,
      month_align: hmUI.align.CENTER_H,
      month_space: 0, // 文字间隔
      month_zero: 1, // 是否补零
      // month_follow: 1, //是否跟随
      month_en_array: dateArr,
      month_sc_array: dateArr,
      month_tc_array: dateArr,
      month_is_character: false, // 年份此字段无效 默认为false 为true时 传入的图片为月份12张 日31张
      // 月日同上 需要替换前缀为 month/day
      day_align: hmUI.align.CENTER_H,
      day_space: 0, //文字间隔
      day_zero: 1, //是否补零
      day_follow: 1, //是否跟随
      day_en_array: dateArr,
      day_sc_array: dateArr,
      day_tc_array: dateArr,
      day_is_character: false,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };

    let objTimePointerAod = {
      hour_centerX: 240, //指针旋转中心 对应centerX
      hour_centerY: 240, //指针旋转中心 对应centerY
      hour_posX: 33, //指针自身旋转中心 对应positioin中的x
      hour_posY: 240, //指针自身旋转中心 对应positioin中的y
      hour_path: "images/pointer/aod_hour.png",
      //分针 秒针同上 只需要把hour替换成minute/second 即可
      minute_centerX: 240, //指针旋转中心 对应centerX
      minute_centerY: 240, //指针旋转中心 对应centerY
      minute_posX: 33, // 指针自身旋转中心 对应positioin中的x
      minute_posY: 240, // 指针自身旋转中心 对应positioin中的y
      minute_path: "images/pointer/aod_min.png",
      show_level: hmUI.show_level.ONLY_AOD,
    };

    let objTimePointer = {
      ...objTimePointerAod,
      hour_path: "images/pointer/hour.png",
      minute_path: "images/pointer/min.png",
      second_centerX: 240, //指针旋转中心 对应centerX
      second_centerY: 240, //指针旋转中心 对应centerY
      second_posX: 33, // 指针自身旋转中心 对应positioin中的x
      second_posY: 240, // 指针自身旋转中心 对应positioin中的y
      second_path: "images/pointer/second.png",
      show_level: hmUI.show_level.ONLY_NORMAL,
    };

    let objPAILevel = {
      center_x: 240, // 圆弧中心位置x坐标
      center_y: 240, // 圆弧中心位置y坐标
      radius: 232, // 圆弧内半径
      start_angle: 149, // 开始角度
      end_angle: 0, // 结束角度 (小于'开始角度'时为逆时针)
      color: 0x277e31, // 填充色
      line_width: 5, // 弧形进度条宽度
      corner_flag: 3, // 可选, 默认0-两端圆角,1-仅起始圆角,2-仅终点圆角,其它值-两端直角
      type: hmUI.data_type.PAI_WEEKLY, // 设置数据类型来驱动进度,type和level至少要设置一个.
      // type: hmUI.data_type.BATTERY, // 设置数据类型来驱动进度,type和level至少要设置一个.
      show_level: hmUI.show_level.ONLY_NORMAL,
    };

    let objSPO2Level = {
      center_x: 240, // 圆弧中心位置x坐标
      center_y: 240, // 圆弧中心位置y坐标
      radius: 232, // 圆弧内半径
      start_angle: -150, // 开始角度
      end_angle: 0, // 结束角度 (小于'开始角度'时为逆时针)
      color: 0x277e31, // 填充色
      line_width: 5, // 弧形进度条宽度
      corner_flag: 3, // 可选, 默认0-两端圆角,1-仅起始圆角,2-仅终点圆角,其它值-两端直角
      type: hmUI.data_type.SPO2, // 设置数据类型来驱动进度,type和level至少要设置一个.
      // type: hmUI.data_type.BATTERY, // 设置数据类型来驱动进度,type和level至少要设置一个.
      show_level: hmUI.show_level.ONLY_NORMAL,
    };

    //===============点击事件==================

    let objStepClick = {
      x: 202,
      y: 323,
      w: 77,
      h: 74,
      type: hmUI.data_type.STEP, //必写 跳转的action
    };
    let objHeartClick = {
      x: 301,
      y: 188,
      w: 139,
      h: 42,
      type: hmUI.data_type.HEART, //必写 跳转的action
    };
    let objCalClick = {
      x: 301,
      y: 250,
      w: 139,
      h: 42,
      type: hmUI.data_type.CAL, //必写 跳转的action
    };
    let objAltitudeClick = {
      //海拔
      x: 46,
      y: 188,
      w: 139,
      h: 42,
      type: hmUI.data_type.ALTITUDE, //必写 跳转的action
    };
    let objAltmeterClick = {
      //气压
      x: 46,
      y: 251,
      w: 139,
      h: 42,
      type: hmUI.data_type.ALTIMETER, //必写 跳转的action
    };
    let objWeatherClick = {
      //气压
      x: 318,
      y: 340,
      w: 65,
      h: 41,
      type: hmUI.data_type.WEATHER, //必写 跳转的action
    };
    let objMaskLeft = {
      x: 0,
      y: 0,
      src: "images/mask/left.png",
      show_level: hmUI.show_level.ONLY_NORMAL,
    };

    let objMaskRight = {
      x: 240,
      y: 0,
      src: "images/mask/right.png",
      show_level: hmUI.show_level.ONLY_NORMAL,
    };

    const logger = DeviceRuntimeCore.HmLogger.getLogger("xiping");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        hmUI.createWidget(hmUI.widget.IMG, objBg);
        hmUI.createWidget(hmUI.widget.IMG, objAodBg);
        hmUI.createWidget(hmUI.widget.ARC_PROGRESS, objPowerLevel);
        hmUI.createWidget(hmUI.widget.ARC_PROGRESS, objStepLevel);
        hmUI.createWidget(hmUI.widget.IMG, objMaskPower);
        hmUI.createWidget(hmUI.widget.IMG, objMaskStep);
        hmUI.createWidget(hmUI.widget.TEXT_IMG, objPowerText);
        hmUI.createWidget(hmUI.widget.TEXT_IMG, objStepText);
        hmUI.createWidget(hmUI.widget.IMG_POINTER, objPowerPointer);
        let iconPath = getLanguage();
        let iconASL = hmUI.createWidget(hmUI.widget.IMG, getASLIcon(iconPath));
        let iconBPM = hmUI.createWidget(hmUI.widget.IMG, getBPMIcon(iconPath));
        let iconKCAL = hmUI.createWidget(
          hmUI.widget.IMG,
          getKCALIcon(iconPath)
        );
        let iconKPA = hmUI.createWidget(hmUI.widget.IMG, getKPAIcon(iconPath));
        hmUI.createWidget(hmUI.widget.TEXT_IMG, objASLText);
        hmUI.createWidget(hmUI.widget.TEXT_IMG, objBPMText);
        hmUI.createWidget(hmUI.widget.TEXT_IMG, objKCALText);
        hmUI.createWidget(hmUI.widget.TEXT_IMG, objKPAText);
        hmUI.createWidget(hmUI.widget.IMG_WEEK, objWeek);
        hmUI.createWidget(hmUI.widget.TEXT_IMG, objTempText);
        hmUI.createWidget(hmUI.widget.IMG_DATE, objDate);
        // hmUI.createWidget(hmUI.widget.ARC_PROGRESS, objPAILevel);
        // hmUI.createWidget(hmUI.widget.ARC_PROGRESS, objSPO2Level);
        // hmUI.createWidget(hmUI.widget.IMG, objMaskLeft);
        // hmUI.createWidget(hmUI.widget.IMG, objMaskRight);
        // 指针
        hmUI.createWidget(hmUI.widget.TIME_POINTER, objTimePointer);
        hmUI.createWidget(hmUI.widget.TIME_POINTER, objTimePointerAod);

        // 跳转部分
        hmUI.createWidget(hmUI.widget.IMG_CLICK, objStepClick);
        hmUI.createWidget(hmUI.widget.IMG_CLICK, objHeartClick);
        hmUI.createWidget(hmUI.widget.IMG_CLICK, objCalClick);
        hmUI.createWidget(hmUI.widget.IMG_CLICK, objAltitudeClick);
        hmUI.createWidget(hmUI.widget.IMG_CLICK, objAltmeterClick);
        hmUI.createWidget(hmUI.widget.IMG_CLICK, objWeatherClick);

        const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: function () {
            // 设置语言后重新获取语言
            let iconNewPath = getLanguage();
            iconASL.setProperty(hmUI.prop.SRC, getASLIcon(iconNewPath).src);
            iconBPM.setProperty(hmUI.prop.SRC, getBPMIcon(iconNewPath).src);
            iconKCAL.setProperty(hmUI.prop.SRC, getKCALIcon(iconNewPath).src);
            iconKPA.setProperty(hmUI.prop.SRC, getKPAIcon(iconNewPath).src);
          },
          pause_call: function () {
            // console.log('ui pause');
          },
        });
      },

      onInit() {
        // console.log('index page.js on init invoke');
        this.init_view();
      },

      onReady() {
        // console.log('index page.js on ready invoke');
      },

      onShow() {
        console.log("index page.js on show invoke");
      },

      onHide() {
        console.log("index page.js on hide invoke");
      },

      onDestory() {
        console.log("index page.js on destory invoke");
      },
    });
    /*
     * end js
     */
  })();
} catch (e) {
  console.log(e);
}
