try {
  (() => {
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    function getApp() {
      return __$$app$$__.app;
    }
    function getCurrentPage() {
      return __$$app$$__.current && __$$app$$__.current.module;
    }
    const __$$module$$__ = __$$app$$__.current;
    const h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__)
    );
    const { px } = __$$app$$__.__globals__;
    let normal$_$component_2$_$component = "";
    let normal$_$component_0$_$component = "";
    let normal$_$component_1$_$component = "";
    const logger = Logger.getLogger("watchface6");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 480,
          h: 480,
          src: "4.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal$_$component_2$_$component = hmUI.createWidget(
          hmUI.widget.WATCHFACE_EDIT_GROUP,
          {
            edit_id: 1,
            x: 172,
            y: 272,
            w: 136,
            h: 136,
            select_image: "5.png",
            un_select_image: "6.png",
            default_type: hmUI.edit_type.BATTERY,
            optional_types: [
              {
                type: hmUI.edit_type.BATTERY,
                preview: "8.png",
              },
              {
                type: hmUI.edit_type.SPO2,
                preview: "9.png",
              },
              {
                type: hmUI.edit_type.UVI,
                preview: "10.png",
              },
              {
                type: hmUI.edit_type.STEP,
                preview: "11.png",
              },
              {
                type: hmUI.edit_type.CAL,
                preview: "12.png",
              },
              {
                type: hmUI.edit_type.HEART,
                preview: "13.png",
              },
              {
                type: hmUI.edit_type.AQI,
                preview: "14.png",
              },
              {
                type: hmUI.edit_type.PAI_WEEKLY,
                preview: "15.png",
              },
            ],
            count: 8,
            select_list: {
              title_font_size: 34,
              title_align_h: hmUI.align.CENTER_H,
              list_item_vspace: 8,
              list_tips_text_font_size: 32,
              list_tips_text_align_h: hmUI.align.LEFT,
            },
            tips_BG: "7.png",
            tips_x: 3,
            tips_y: 140,
            tips_width: 124,
            tips_margin: 0,
          }
        );
        editType = normal$_$component_2$_$component.getProperty(
          hmUI.prop.CURRENT_TYPE
        );
        switch (editType) {
          case hmUI.edit_type.STEP:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 201,
              y: 368,
              type: hmUI.data_type.STEP,
              font_array: [
                "16.png",
                "17.png",
                "18.png",
                "19.png",
                "20.png",
                "21.png",
                "22.png",
                "23.png",
                "24.png",
                "25.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 229,
              y: 303,
              src: "26.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "27.png",
              center_x: 239,
              center_y: 341,
              x: 10,
              y: 39,
              type: hmUI.data_type.STEP,
              start_angle: -120,
              end_angle: 120,
              cover_x: 0,
              cover_y: 200,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 193,
              y: 302,
              w: 98,
              h: 96,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.BATTERY:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 216,
              y: 368,
              type: hmUI.data_type.BATTERY,
              font_array: [
                "16.png",
                "17.png",
                "18.png",
                "19.png",
                "20.png",
                "21.png",
                "22.png",
                "23.png",
                "24.png",
                "25.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: "28.png",
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 229,
              y: 303,
              src: "29.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "30.png",
              center_x: 239,
              center_y: 341,
              x: 10,
              y: 39,
              type: hmUI.data_type.BATTERY,
              start_angle: -120,
              end_angle: 120,
              cover_x: 0,
              cover_y: 200,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 193,
              y: 302,
              w: 98,
              h: 96,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.HEART:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 216,
              y: 368,
              type: hmUI.data_type.HEART,
              font_array: [
                "16.png",
                "17.png",
                "18.png",
                "19.png",
                "20.png",
                "21.png",
                "22.png",
                "23.png",
                "24.png",
                "25.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: "31.png",
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 229,
              y: 300,
              src: "32.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "33.png",
              center_x: 239,
              center_y: 341,
              x: 10,
              y: 39,
              type: hmUI.data_type.HEART,
              start_angle: -120,
              end_angle: 120,
              cover_x: 0,
              cover_y: 200,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 193,
              y: 302,
              w: 98,
              h: 96,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.CAL:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 209,
              y: 368,
              type: hmUI.data_type.CAL,
              font_array: [
                "16.png",
                "17.png",
                "18.png",
                "19.png",
                "20.png",
                "21.png",
                "22.png",
                "23.png",
                "24.png",
                "25.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 229,
              y: 303,
              src: "34.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "35.png",
              center_x: 239,
              center_y: 341,
              x: 10,
              y: 39,
              type: hmUI.data_type.CAL,
              start_angle: -120,
              end_angle: 120,
              cover_x: 0,
              cover_y: 200,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 193,
              y: 302,
              w: 98,
              h: 96,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.PAI_WEEKLY:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 216,
              y: 368,
              type: hmUI.data_type.PAI_WEEKLY,
              font_array: [
                "36.png",
                "37.png",
                "38.png",
                "39.png",
                "40.png",
                "41.png",
                "42.png",
                "43.png",
                "44.png",
                "45.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 229,
              y: 303,
              src: "46.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "47.png",
              center_x: 239,
              center_y: 341,
              x: 10,
              y: 39,
              type: hmUI.data_type.PAI_WEEKLY,
              start_angle: -120,
              end_angle: 120,
              cover_x: 0,
              cover_y: 200,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 193,
              y: 302,
              w: 98,
              h: 96,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.DISTANCE:
            break;
          case hmUI.edit_type.AQI:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 216,
              y: 368,
              type: hmUI.data_type.AQI,
              font_array: [
                "48.png",
                "49.png",
                "50.png",
                "51.png",
                "52.png",
                "53.png",
                "54.png",
                "55.png",
                "56.png",
                "57.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: "58.png",
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 229,
              y: 298,
              src: "59.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "60.png",
              center_x: 239,
              center_y: 341,
              x: 10,
              y: 39,
              type: hmUI.data_type.AQI,
              start_angle: -120,
              end_angle: 120,
              cover_x: 10,
              cover_y: 239,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 193,
              y: 302,
              w: 98,
              h: 96,
              type: hmUI.data_type.AQI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.HUMIDITY:
            break;
          case hmUI.edit_type.ALTIMETER:
            break;
          case hmUI.edit_type.STRESS:
            break;
          case hmUI.edit_type.WIND:
            break;
          case hmUI.edit_type.SPO2:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 208,
              y: 368,
              type: hmUI.data_type.SPO2,
              font_array: [
                "16.png",
                "17.png",
                "18.png",
                "19.png",
                "20.png",
                "21.png",
                "22.png",
                "23.png",
                "24.png",
                "25.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: "62.png",
              unit_tc: "62.png",
              unit_en: "62.png",
              invalid_image: "61.png",
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 229,
              y: 303,
              src: "63.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "64.png",
              center_x: 239,
              center_y: 341,
              x: 10,
              y: 39,
              type: hmUI.data_type.SPO2,
              start_angle: -120,
              end_angle: 120,
              cover_x: 0,
              cover_y: 200,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 193,
              y: 302,
              w: 98,
              h: 96,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.TRAINING_LOAD:
            break;
          case hmUI.edit_type.VO2MAX:
            break;
          case hmUI.edit_type.UVI:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 225,
              y: 368,
              type: hmUI.data_type.UVI,
              font_array: [
                "16.png",
                "17.png",
                "18.png",
                "19.png",
                "20.png",
                "21.png",
                "22.png",
                "23.png",
                "24.png",
                "25.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: "65.png",
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 229,
              y: 300,
              src: "66.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "67.png",
              center_x: 239,
              center_y: 341,
              x: 10,
              y: 39,
              type: hmUI.data_type.UVI,
              start_angle: -120,
              end_angle: 120,
              cover_x: 0,
              cover_y: 200,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 193,
              y: 302,
              w: 98,
              h: 96,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.DATE:
            break;
          case hmUI.edit_type.WEEK:
            break;
          case hmUI.edit_type.WEATHER:
            break;
          case hmUI.edit_type.TEMPERATURE:
            break;
          case hmUI.edit_type.SUN:
            break;
        }
        hmUI.createWidget(hmUI.widget.IMG_DATE, {
          day_startX: 61,
          day_startY: 191,
          day_sc_array: [
            "68.png",
            "69.png",
            "70.png",
            "71.png",
            "72.png",
            "73.png",
            "74.png",
            "75.png",
            "76.png",
            "77.png",
          ],
          day_tc_array: [
            "68.png",
            "69.png",
            "70.png",
            "71.png",
            "72.png",
            "73.png",
            "74.png",
            "75.png",
            "76.png",
            "77.png",
          ],
          day_en_array: [
            "68.png",
            "69.png",
            "70.png",
            "71.png",
            "72.png",
            "73.png",
            "74.png",
            "75.png",
            "76.png",
            "77.png",
          ],
          day_align: hmUI.align.LEFT,
          day_zero: 1,
          day_follow: 0,
          day_space: 0,
          day_is_character: false,
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        hmUI.createWidget(hmUI.widget.IMG_WEEK, {
          x: 45,
          y: 246,
          week_en: [
            "78.png",
            "79.png",
            "80.png",
            "81.png",
            "82.png",
            "83.png",
            "84.png",
          ],
          week_tc: [
            "85.png",
            "86.png",
            "87.png",
            "88.png",
            "89.png",
            "90.png",
            "91.png",
          ],
          week_sc: [
            "92.png",
            "93.png",
            "94.png",
            "95.png",
            "96.png",
            "97.png",
            "98.png",
          ],
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal$_$component_0$_$component = hmUI.createWidget(
          hmUI.widget.WATCHFACE_EDIT_GROUP,
          {
            edit_id: 2,
            x: 280,
            y: 172,
            w: 136,
            h: 136,
            select_image: "99.png",
            un_select_image: "100.png",
            default_type: hmUI.edit_type.HEART,
            optional_types: [
              {
                type: hmUI.edit_type.HEART,
                preview: "101.png",
              },
              {
                type: hmUI.edit_type.SPO2,
                preview: "102.png",
              },
              {
                type: hmUI.edit_type.UVI,
                preview: "103.png",
              },
              {
                type: hmUI.edit_type.STEP,
                preview: "104.png",
              },
              {
                type: hmUI.edit_type.BATTERY,
                preview: "105.png",
              },
              {
                type: hmUI.edit_type.CAL,
                preview: "106.png",
              },
              {
                type: hmUI.edit_type.AQI,
                preview: "107.png",
              },
              {
                type: hmUI.edit_type.PAI_WEEKLY,
                preview: "108.png",
              },
            ],
            count: 8,
            select_list: {
              title_font_size: 34,
              title_align_h: hmUI.align.CENTER_H,
              list_item_vspace: 8,
              list_tips_text_font_size: 32,
              list_tips_text_align_h: hmUI.align.LEFT,
            },
            tips_BG: "7.png",
            tips_x: -105,
            tips_y: 240,
            tips_width: 124,
            tips_margin: 0,
          }
        );
        editType = normal$_$component_0$_$component.getProperty(
          hmUI.prop.CURRENT_TYPE
        );
        switch (editType) {
          case hmUI.edit_type.STEP:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 309,
              y: 265,
              type: hmUI.data_type.STEP,
              font_array: [
                "16.png",
                "17.png",
                "18.png",
                "19.png",
                "20.png",
                "21.png",
                "22.png",
                "23.png",
                "24.png",
                "25.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 336,
              y: 201,
              src: "109.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "110.png",
              center_x: 347,
              center_y: 240,
              x: 10,
              y: 39,
              type: hmUI.data_type.STEP,
              start_angle: -120,
              end_angle: 120,
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 305,
              y: 206,
              w: 78,
              h: 75,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.BATTERY:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 324,
              y: 265,
              type: hmUI.data_type.BATTERY,
              font_array: [
                "48.png",
                "49.png",
                "50.png",
                "51.png",
                "52.png",
                "53.png",
                "54.png",
                "55.png",
                "56.png",
                "57.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: "111.png",
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 335,
              y: 201,
              src: "112.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "113.png",
              center_x: 347,
              center_y: 240,
              x: 10,
              y: 39,
              type: hmUI.data_type.BATTERY,
              start_angle: -120,
              end_angle: 120,
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 305,
              y: 206,
              w: 78,
              h: 75,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.HEART:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 324,
              y: 265,
              type: hmUI.data_type.HEART,
              font_array: [
                "16.png",
                "17.png",
                "18.png",
                "19.png",
                "20.png",
                "21.png",
                "22.png",
                "23.png",
                "24.png",
                "25.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: "114.png",
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 336,
              y: 201,
              src: "115.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "116.png",
              center_x: 347,
              center_y: 240,
              x: 10,
              y: 39,
              type: hmUI.data_type.HEART,
              start_angle: -120,
              end_angle: 120,
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 305,
              y: 206,
              w: 78,
              h: 75,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.CAL:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 316,
              y: 265,
              type: hmUI.data_type.CAL,
              font_array: [
                "16.png",
                "17.png",
                "18.png",
                "19.png",
                "20.png",
                "21.png",
                "22.png",
                "23.png",
                "24.png",
                "25.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 335,
              y: 201,
              src: "117.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "118.png",
              center_x: 347,
              center_y: 240,
              x: 10,
              y: 39,
              type: hmUI.data_type.CAL,
              start_angle: -120,
              end_angle: 120,
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 305,
              y: 206,
              w: 78,
              h: 75,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.PAI_WEEKLY:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 321,
              y: 265,
              type: hmUI.data_type.PAI_WEEKLY,
              font_array: [
                "48.png",
                "49.png",
                "50.png",
                "51.png",
                "52.png",
                "53.png",
                "54.png",
                "55.png",
                "56.png",
                "57.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 335,
              y: 201,
              src: "119.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "120.png",
              center_x: 347,
              center_y: 240,
              x: 10,
              y: 39,
              type: hmUI.data_type.PAI_WEEKLY,
              start_angle: -120,
              end_angle: 120,
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 305,
              y: 206,
              w: 78,
              h: 75,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.DISTANCE:
            break;
          case hmUI.edit_type.AQI:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 324,
              y: 265,
              type: hmUI.data_type.AQI,
              font_array: [
                "48.png",
                "49.png",
                "50.png",
                "51.png",
                "52.png",
                "53.png",
                "54.png",
                "55.png",
                "56.png",
                "57.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: "58.png",
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 335,
              y: 201,
              src: "121.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "60.png",
              center_x: 347,
              center_y: 240,
              x: 10,
              y: 39,
              type: hmUI.data_type.AQI,
              start_angle: -121,
              end_angle: 121,
              cover_x: 10,
              cover_y: 39,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 305,
              y: 206,
              w: 78,
              h: 75,
              type: hmUI.data_type.AQI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.HUMIDITY:
            break;
          case hmUI.edit_type.ALTIMETER:
            break;
          case hmUI.edit_type.STRESS:
            break;
          case hmUI.edit_type.WIND:
            break;
          case hmUI.edit_type.SPO2:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 315,
              y: 265,
              type: hmUI.data_type.SPO2,
              font_array: [
                "16.png",
                "17.png",
                "18.png",
                "19.png",
                "20.png",
                "21.png",
                "22.png",
                "23.png",
                "24.png",
                "25.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: "123.png",
              unit_tc: "123.png",
              unit_en: "123.png",
              invalid_image: "122.png",
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 336,
              y: 201,
              src: "124.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "125.png",
              center_x: 347,
              center_y: 240,
              x: 10,
              y: 39,
              type: hmUI.data_type.SPO2,
              start_angle: -120,
              end_angle: 120,
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 305,
              y: 206,
              w: 78,
              h: 75,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.TRAINING_LOAD:
            break;
          case hmUI.edit_type.VO2MAX:
            break;
          case hmUI.edit_type.UVI:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 333,
              y: 265,
              type: hmUI.data_type.UVI,
              font_array: [
                "16.png",
                "17.png",
                "18.png",
                "19.png",
                "20.png",
                "21.png",
                "22.png",
                "23.png",
                "24.png",
                "25.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: "126.png",
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 335,
              y: 201,
              src: "127.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "128.png",
              center_x: 347,
              center_y: 240,
              x: 10,
              y: 39,
              type: hmUI.data_type.UVI,
              start_angle: -120,
              end_angle: 120,
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 305,
              y: 206,
              w: 78,
              h: 75,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.DATE:
            break;
          case hmUI.edit_type.WEEK:
            break;
          case hmUI.edit_type.WEATHER:
            break;
          case hmUI.edit_type.TEMPERATURE:
            break;
          case hmUI.edit_type.SUN:
            break;
        }
        normal$_$component_1$_$component = hmUI.createWidget(
          hmUI.widget.WATCHFACE_EDIT_GROUP,
          {
            edit_id: 3,
            x: 172,
            y: 72,
            w: 136,
            h: 136,
            select_image: "5.png",
            un_select_image: "6.png",
            default_type: hmUI.edit_type.STEP,
            optional_types: [
              {
                type: hmUI.edit_type.STEP,
                preview: "11.png",
              },
              {
                type: hmUI.edit_type.SPO2,
                preview: "9.png",
              },
              {
                type: hmUI.edit_type.UVI,
                preview: "10.png",
              },
              {
                type: hmUI.edit_type.BATTERY,
                preview: "8.png",
              },
              {
                type: hmUI.edit_type.CAL,
                preview: "12.png",
              },
              {
                type: hmUI.edit_type.HEART,
                preview: "13.png",
              },
              {
                type: hmUI.edit_type.AQI,
                preview: "14.png",
              },
              {
                type: hmUI.edit_type.PAI_WEEKLY,
                preview: "129.png",
              },
            ],
            count: 8,
            select_list: {
              title_font_size: 34,
              title_align_h: hmUI.align.CENTER_H,
              list_item_vspace: 8,
              list_tips_text_font_size: 32,
              list_tips_text_align_h: hmUI.align.LEFT,
            },
            tips_BG: "7.png",
            tips_x: 3,
            tips_y: 340,
            tips_width: 124,
            tips_margin: 0,
          }
        );
        editType = normal$_$component_1$_$component.getProperty(
          hmUI.prop.CURRENT_TYPE
        );
        switch (editType) {
          case hmUI.edit_type.STEP:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 201,
              y: 168,
              type: hmUI.data_type.STEP,
              font_array: [
                "16.png",
                "17.png",
                "18.png",
                "19.png",
                "20.png",
                "21.png",
                "22.png",
                "23.png",
                "24.png",
                "25.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 229,
              y: 103,
              src: "26.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "27.png",
              center_x: 240,
              center_y: 141,
              x: 10,
              y: 39,
              type: hmUI.data_type.STEP,
              start_angle: -120,
              end_angle: 120,
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 193,
              y: 93,
              w: 98,
              h: 96,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.BATTERY:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 217,
              y: 168,
              type: hmUI.data_type.BATTERY,
              font_array: [
                "16.png",
                "17.png",
                "18.png",
                "19.png",
                "20.png",
                "21.png",
                "22.png",
                "23.png",
                "24.png",
                "25.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: "28.png",
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 229,
              y: 103,
              src: "29.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "30.png",
              center_x: 240,
              center_y: 141,
              x: 10,
              y: 39,
              type: hmUI.data_type.BATTERY,
              start_angle: -120,
              end_angle: 120,
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 193,
              y: 93,
              w: 98,
              h: 96,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.HEART:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 216,
              y: 168,
              type: hmUI.data_type.HEART,
              font_array: [
                "16.png",
                "17.png",
                "18.png",
                "19.png",
                "20.png",
                "21.png",
                "22.png",
                "23.png",
                "24.png",
                "25.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: "31.png",
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 229,
              y: 100,
              src: "32.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "33.png",
              center_x: 239,
              center_y: 141,
              x: 10,
              y: 39,
              type: hmUI.data_type.HEART,
              start_angle: -120,
              end_angle: 120,
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 193,
              y: 93,
              w: 98,
              h: 96,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.CAL:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 209,
              y: 168,
              type: hmUI.data_type.CAL,
              font_array: [
                "16.png",
                "17.png",
                "18.png",
                "19.png",
                "20.png",
                "21.png",
                "22.png",
                "23.png",
                "24.png",
                "25.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 229,
              y: 101,
              src: "130.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "35.png",
              center_x: 239,
              center_y: 141,
              x: 10,
              y: 39,
              type: hmUI.data_type.CAL,
              start_angle: -121,
              end_angle: 121,
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 193,
              y: 93,
              w: 98,
              h: 96,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.PAI_WEEKLY:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 215,
              y: 168,
              type: hmUI.data_type.PAI_WEEKLY,
              font_array: [
                "36.png",
                "37.png",
                "38.png",
                "39.png",
                "40.png",
                "41.png",
                "42.png",
                "43.png",
                "44.png",
                "45.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 229,
              y: 100,
              src: "131.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "132.png",
              center_x: 239,
              center_y: 141,
              x: 10,
              y: 39,
              type: hmUI.data_type.PAI_WEEKLY,
              start_angle: -121,
              end_angle: 121,
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 193,
              y: 93,
              w: 98,
              h: 96,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.DISTANCE:
            break;
          case hmUI.edit_type.AQI:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 216,
              y: 168,
              type: hmUI.data_type.AQI,
              font_array: [
                "48.png",
                "49.png",
                "50.png",
                "51.png",
                "52.png",
                "53.png",
                "54.png",
                "55.png",
                "56.png",
                "57.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: "58.png",
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 229,
              y: 98,
              src: "59.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "60.png",
              center_x: 240,
              center_y: 141,
              x: 10,
              y: 39,
              type: hmUI.data_type.AQI,
              start_angle: -121,
              end_angle: 121,
              cover_x: 10,
              cover_y: 39,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 193,
              y: 93,
              w: 98,
              h: 96,
              type: hmUI.data_type.AQI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.HUMIDITY:
            break;
          case hmUI.edit_type.ALTIMETER:
            break;
          case hmUI.edit_type.STRESS:
            break;
          case hmUI.edit_type.WIND:
            break;
          case hmUI.edit_type.SPO2:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 209,
              y: 168,
              type: hmUI.data_type.SPO2,
              font_array: [
                "16.png",
                "17.png",
                "18.png",
                "19.png",
                "20.png",
                "21.png",
                "22.png",
                "23.png",
                "24.png",
                "25.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: "133.png",
              unit_tc: "133.png",
              unit_en: "133.png",
              invalid_image: "61.png",
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 229,
              y: 103,
              src: "63.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "64.png",
              center_x: 239,
              center_y: 141,
              x: 10,
              y: 39,
              type: hmUI.data_type.SPO2,
              start_angle: -120,
              end_angle: 120,
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 193,
              y: 93,
              w: 98,
              h: 96,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.TRAINING_LOAD:
            break;
          case hmUI.edit_type.VO2MAX:
            break;
          case hmUI.edit_type.UVI:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 225,
              y: 168,
              type: hmUI.data_type.UVI,
              font_array: [
                "16.png",
                "17.png",
                "18.png",
                "19.png",
                "20.png",
                "21.png",
                "22.png",
                "23.png",
                "24.png",
                "25.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: "65.png",
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 229,
              y: 100,
              src: "66.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "67.png",
              center_x: 239,
              center_y: 141,
              x: 10,
              y: 39,
              type: hmUI.data_type.UVI,
              start_angle: -120,
              end_angle: 120,
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 193,
              y: 93,
              w: 98,
              h: 96,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.DATE:
            break;
          case hmUI.edit_type.WEEK:
            break;
          case hmUI.edit_type.WEATHER:
            break;
          case hmUI.edit_type.TEMPERATURE:
            break;
          case hmUI.edit_type.SUN:
            break;
        }
        hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK, {
          x: 0,
          y: 0,
          w: 480,
          h: 480,
          src: "134.png",
          show_level: hmUI.show_level.ONLY_EDIT,
        });
        hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_centerX: 240,
          hour_centerY: 240,
          hour_posX: 28,
          hour_posY: 159,
          hour_path: "135.png",
          hour_cover_x: 0,
          hour_cover_y: 0,
          minute_centerX: 240,
          minute_centerY: 240,
          minute_posX: 27,
          minute_posY: 215,
          minute_path: "136.png",
          minute_cover_x: 0,
          minute_cover_y: 0,
          second_centerX: 240,
          second_centerY: 240,
          second_posX: 12,
          second_posY: 228,
          second_path: "138.png",
          second_cover_path: "137.png",
          second_cover_x: 228,
          second_cover_y: 228,
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
          x: 0,
          y: 0,
          w: 480,
          h: 480,
          src: "139.png",
          show_level: hmUI.show_level.ONLY_EDIT,
        });
        hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_centerX: 240,
          hour_centerY: 240,
          hour_posX: 13,
          hour_posY: 148,
          hour_path: "140.png",
          hour_cover_x: 0,
          hour_cover_y: 0,
          minute_centerX: 240,
          minute_centerY: 240,
          minute_posX: 14,
          minute_posY: 206,
          minute_path: "141.png",
          minute_cover_x: 0,
          minute_cover_y: 0,
          enable: false,
          show_level: hmUI.show_level.ONLY_AOD,
        });
      },
      onInit() {
        logger.log("index page.js on init invoke");
      },
      build() {
        this.init_view();
        logger.log("index page.js on ready invoke");
      },
      onDestroy() {
        logger.log("index page.js on destroy invoke");
      },
    });
  })();
} catch (e) {
  console.log("Mini Program Error", e);
  e &&
    e.stack &&
    e.stack.split(/\n/).forEach((i) => console.log("error stack", i));
}
