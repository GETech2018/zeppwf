try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$component_0$_$component = '';
        let normal$_$component_1$_$component = '';
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 240,
                    center_y: 240,
                    radius: 225,
                    start_angle: 208,
                    end_angle: 332,
                    color: 4278213119,
                    line_width: 20,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 135,
                    y: 26,
                    type: hmUI.data_type.STEP,
                    font_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 150,
                    y: 441,
                    src: '13.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 240,
                    center_y: 240,
                    radius: 225,
                    start_angle: 152,
                    end_angle: 29,
                    color: 4294901760,
                    line_width: 20,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 292,
                    y: 26,
                    type: hmUI.data_type.BATTERY,
                    font_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 310,
                    y: 441,
                    src: '14.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    src: '15.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 140,
                    y: 75,
                    week_en: [
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 133,
                    month_startY: 110,
                    month_en_array: [
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png'
                    ],
                    month_align: hmUI.align.RIGHT,
                    month_zero: 0,
                    month_follow: 0,
                    month_space: 0,
                    month_is_character: true,
                    day_startX: 268,
                    day_startY: 110,
                    day_sc_array: [
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png'
                    ],
                    day_tc_array: [
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png'
                    ],
                    day_en_array: [
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png'
                    ],
                    day_align: hmUI.align.RIGHT,
                    day_zero: 0,
                    day_follow: 0,
                    day_space: 0,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 100,
                    hour_startY: 158,
                    hour_array: [
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png',
                        '54.png'
                    ],
                    hour_space: 0,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 252,
                    minute_startY: 158,
                    minute_array: [
                        '55.png',
                        '56.png',
                        '57.png',
                        '58.png',
                        '59.png',
                        '60.png',
                        '61.png',
                        '62.png',
                        '63.png',
                        '64.png'
                    ],
                    minute_space: 0,
                    minute_align: hmUI.align.RIGHT,
                    minute_follow: 0,
                    second_zero: 1,
                    second_startX: 381,
                    second_startY: 216,
                    second_array: [
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png'
                    ],
                    second_space: 0,
                    second_align: hmUI.align.LEFT,
                    second_follow: 0,
                    am_x: 39,
                    am_y: 216,
                    am_en_path: '65.png',
                    pm_x: 39,
                    pm_y: 216,
                    pm_en_path: '66.png',
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$component_0$_$component = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: 1,
                    x: 100,
                    y: 300,
                    w: 120,
                    h: 100,
                    select_image: '67.png',
                    un_select_image: '68.png',
                    default_type: hmUI.edit_type.HEART,
                    optional_types: [
                        {
                            'type': hmUI.edit_type.HEART,
                            'preview': '70.png'
                        },
                        {
                            'type': hmUI.edit_type.CAL,
                            'preview': '71.png'
                        },
                        {
                            'type': hmUI.edit_type.TEMPERATURE,
                            'preview': '72.png'
                        },
                        {
                            'type': hmUI.edit_type.WEATHER,
                            'preview': '73.png'
                        },
                        {
                            'type': hmUI.edit_type.DISTANCE,
                            'preview': '74.png'
                        }
                    ],
                    count: 5,
                    select_list: {
                        title_font_size: 34,
                        title_align_h: hmUI.align.CENTER_H,
                        list_item_vspace: 8,
                        list_tips_text_font_size: 32,
                        list_tips_text_align_h: hmUI.align.LEFT
                    },
                    tips_BG: '69.png',
                    tips_x: 0,
                    tips_y: 85,
                    tips_width: 100,
                    tips_margin: 0
                });
                editType = normal$_$component_0$_$component.getProperty(hmUI.prop.CURRENT_TYPE);
                switch (editType) {
                case hmUI.edit_type.STEP:
                    break;
                case hmUI.edit_type.BATTERY:
                    break;
                case hmUI.edit_type.HEART:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 123,
                        y: 355,
                        type: hmUI.data_type.HEART,
                        font_array: [
                            '3.png',
                            '4.png',
                            '5.png',
                            '6.png',
                            '7.png',
                            '8.png',
                            '9.png',
                            '10.png',
                            '11.png',
                            '12.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '75.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 139,
                        y: 320,
                        w: 20,
                        h: 20,
                        src: '76.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.CAL:
                    hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                        center_x: 150,
                        center_y: 350,
                        radius: 40,
                        start_angle: 217,
                        end_angle: 500,
                        color: 4283431168,
                        line_width: 10,
                        type: hmUI.data_type.CAL,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 115,
                        y: 366,
                        type: hmUI.data_type.CAL,
                        font_array: [
                            '3.png',
                            '4.png',
                            '5.png',
                            '6.png',
                            '7.png',
                            '8.png',
                            '9.png',
                            '10.png',
                            '11.png',
                            '12.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 127,
                        y: 315,
                        src: '77.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.PAI_DAILY:
                    break;
                case hmUI.edit_type.DISTANCE:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 110,
                        y: 360,
                        type: hmUI.data_type.DISTANCE,
                        font_array: [
                            '3.png',
                            '4.png',
                            '5.png',
                            '6.png',
                            '7.png',
                            '8.png',
                            '9.png',
                            '10.png',
                            '11.png',
                            '12.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        dot_image: '78.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 126,
                        y: 310,
                        src: '79.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.AQI:
                    break;
                case hmUI.edit_type.HUMIDITY:
                    break;
                case hmUI.edit_type.ALTIMETER:
                    break;
                case hmUI.edit_type.STRESS:
                    break;
                case hmUI.edit_type.WIND:
                    break;
                case hmUI.edit_type.SPO2:
                    break;
                case hmUI.edit_type.TRAINING_LOAD:
                    break;
                case hmUI.edit_type.VO2MAX:
                    break;
                case hmUI.edit_type.UVI:
                    break;
                case hmUI.edit_type.DATE:
                    break;
                case hmUI.edit_type.WEEK:
                    break;
                case hmUI.edit_type.WEATHER:
                    hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                        x: 100,
                        y: 310,
                        image_array: [
                            '80.png',
                            '81.png',
                            '82.png',
                            '83.png',
                            '84.png',
                            '85.png',
                            '86.png',
                            '87.png',
                            '88.png',
                            '89.png',
                            '90.png',
                            '91.png',
                            '92.png',
                            '93.png',
                            '94.png',
                            '95.png',
                            '96.png',
                            '97.png',
                            '98.png',
                            '99.png',
                            '100.png',
                            '101.png',
                            '102.png',
                            '103.png',
                            '104.png',
                            '105.png',
                            '106.png',
                            '107.png',
                            '108.png'
                        ],
                        image_length: 29,
                        type: hmUI.data_type.WEATHER_CURRENT,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.TEMPERATURE:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 130,
                        y: 365,
                        type: hmUI.data_type.WEATHER_CURRENT,
                        font_array: [
                            '3.png',
                            '4.png',
                            '5.png',
                            '6.png',
                            '7.png',
                            '8.png',
                            '9.png',
                            '10.png',
                            '11.png',
                            '12.png'
                        ],
                        align_h: hmUI.align.LEFT,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        unit_sc: '111.png',
                        unit_tc: '111.png',
                        unit_en: '111.png',
                        negative_image: '110.png',
                        invalid_image: '109.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 130,
                        y: 310,
                        src: '112.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.SUN:
                    break;
                }
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 233,
                    y: 160,
                    src: '113.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$component_1$_$component = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: 2,
                    x: 280,
                    y: 300,
                    w: 120,
                    h: 100,
                    select_image: '67.png',
                    un_select_image: '68.png',
                    default_type: hmUI.edit_type.HEART,
                    optional_types: [
                        {
                            'type': hmUI.edit_type.HEART,
                            'preview': '70.png'
                        },
                        {
                            'type': hmUI.edit_type.CAL,
                            'preview': '71.png'
                        },
                        {
                            'type': hmUI.edit_type.TEMPERATURE,
                            'preview': '72.png'
                        },
                        {
                            'type': hmUI.edit_type.WEATHER,
                            'preview': '114.png'
                        },
                        {
                            'type': hmUI.edit_type.DISTANCE,
                            'preview': '74.png'
                        }
                    ],
                    count: 5,
                    select_list: {
                        title_font_size: 34,
                        title_align_h: hmUI.align.CENTER_H,
                        list_item_vspace: 8,
                        list_tips_text_font_size: 32,
                        list_tips_text_align_h: hmUI.align.LEFT
                    },
                    tips_BG: '69.png',
                    tips_x: 0,
                    tips_y: 85,
                    tips_width: 100,
                    tips_margin: 0
                });
                editType = normal$_$component_1$_$component.getProperty(hmUI.prop.CURRENT_TYPE);
                switch (editType) {
                case hmUI.edit_type.STEP:
                    break;
                case hmUI.edit_type.BATTERY:
                    break;
                case hmUI.edit_type.HEART:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 303,
                        y: 355,
                        type: hmUI.data_type.HEART,
                        font_array: [
                            '3.png',
                            '4.png',
                            '5.png',
                            '6.png',
                            '7.png',
                            '8.png',
                            '9.png',
                            '10.png',
                            '11.png',
                            '12.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '75.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 319,
                        y: 320,
                        w: 20,
                        h: 20,
                        src: '76.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.CAL:
                    hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                        center_x: 330,
                        center_y: 350,
                        radius: 40,
                        start_angle: 217,
                        end_angle: 500,
                        color: 4283431168,
                        line_width: 10,
                        type: hmUI.data_type.CAL,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 295,
                        y: 366,
                        type: hmUI.data_type.CAL,
                        font_array: [
                            '3.png',
                            '4.png',
                            '5.png',
                            '6.png',
                            '7.png',
                            '8.png',
                            '9.png',
                            '10.png',
                            '11.png',
                            '12.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 307,
                        y: 315,
                        src: '77.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.PAI_DAILY:
                    break;
                case hmUI.edit_type.DISTANCE:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 290,
                        y: 360,
                        type: hmUI.data_type.DISTANCE,
                        font_array: [
                            '3.png',
                            '4.png',
                            '5.png',
                            '6.png',
                            '7.png',
                            '8.png',
                            '9.png',
                            '10.png',
                            '11.png',
                            '12.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        dot_image: '78.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 306,
                        y: 310,
                        src: '79.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.AQI:
                    break;
                case hmUI.edit_type.HUMIDITY:
                    break;
                case hmUI.edit_type.ALTIMETER:
                    break;
                case hmUI.edit_type.STRESS:
                    break;
                case hmUI.edit_type.WIND:
                    break;
                case hmUI.edit_type.SPO2:
                    break;
                case hmUI.edit_type.TRAINING_LOAD:
                    break;
                case hmUI.edit_type.VO2MAX:
                    break;
                case hmUI.edit_type.UVI:
                    break;
                case hmUI.edit_type.DATE:
                    break;
                case hmUI.edit_type.WEEK:
                    break;
                case hmUI.edit_type.WEATHER:
                    hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                        x: 280,
                        y: 310,
                        image_array: [
                            '115.png',
                            '116.png',
                            '117.png',
                            '118.png',
                            '119.png',
                            '120.png',
                            '121.png',
                            '122.png',
                            '123.png',
                            '124.png',
                            '125.png',
                            '126.png',
                            '127.png',
                            '128.png',
                            '129.png',
                            '130.png',
                            '131.png',
                            '132.png',
                            '133.png',
                            '134.png',
                            '135.png',
                            '136.png',
                            '137.png',
                            '138.png',
                            '139.png',
                            '140.png',
                            '141.png',
                            '142.png',
                            '143.png'
                        ],
                        image_length: 29,
                        type: hmUI.data_type.WEATHER_CURRENT,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.TEMPERATURE:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 310,
                        y: 365,
                        type: hmUI.data_type.WEATHER_CURRENT,
                        font_array: [
                            '3.png',
                            '4.png',
                            '5.png',
                            '6.png',
                            '7.png',
                            '8.png',
                            '9.png',
                            '10.png',
                            '11.png',
                            '12.png'
                        ],
                        align_h: hmUI.align.LEFT,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        unit_sc: '111.png',
                        unit_tc: '111.png',
                        unit_en: '111.png',
                        negative_image: '110.png',
                        invalid_image: '109.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 310,
                        y: 310,
                        src: '112.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.SUN:
                    break;
                }
                hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '144.png',
                    show_level: hmUI.show_level.ONLY_EDIT
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 100,
                    y: 300,
                    src: '145.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 280,
                    y: 300,
                    src: '146.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '147.png',
                    show_level: hmUI.show_level.ONLY_EDIT
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 140,
                    y: 75,
                    week_en: [
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 133,
                    month_startY: 110,
                    month_en_array: [
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png'
                    ],
                    month_align: hmUI.align.RIGHT,
                    month_zero: 0,
                    month_follow: 0,
                    month_space: 0,
                    month_is_character: true,
                    day_startX: 268,
                    day_startY: 110,
                    day_sc_array: [
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png'
                    ],
                    day_tc_array: [
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png'
                    ],
                    day_en_array: [
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png'
                    ],
                    day_align: hmUI.align.RIGHT,
                    day_zero: 0,
                    day_follow: 0,
                    day_space: 0,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 100,
                    hour_startY: 158,
                    hour_array: [
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png',
                        '54.png'
                    ],
                    hour_space: 0,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 252,
                    minute_startY: 158,
                    minute_array: [
                        '55.png',
                        '56.png',
                        '57.png',
                        '58.png',
                        '59.png',
                        '60.png',
                        '61.png',
                        '62.png',
                        '63.png',
                        '64.png'
                    ],
                    minute_space: 0,
                    minute_align: hmUI.align.RIGHT,
                    minute_follow: 0,
                    am_x: 39,
                    am_y: 216,
                    am_en_path: '65.png',
                    pm_x: 39,
                    pm_y: 216,
                    pm_en_path: '66.png',
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    src: '148.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 280,
                    y: 300,
                    src: '149.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 100,
                    y: 300,
                    src: '150.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}