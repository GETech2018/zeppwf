try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$component_0$_$component = '';
        let normal$_$component_1$_$component = '';
        let normal$_$component_2$_$component = '';
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
                    edit_id: 1,
                    x: 0,
                    y: 0,
                    bg_config: [
                        {
                            'id': 1,
                            'path': '4.png',
                            'preview': '5.png'
                        },
                        {
                            'id': 2,
                            'path': '6.png',
                            'preview': '7.png'
                        },
                        {
                            'id': 3,
                            'path': '8.png',
                            'preview': '9.png'
                        },
                        {
                            'id': 4,
                            'path': '10.png',
                            'preview': '11.png'
                        },
                        {
                            'id': 5,
                            'path': '12.png',
                            'preview': '13.png'
                        },
                        {
                            'id': 6,
                            'path': '14.png',
                            'preview': '15.png'
                        },
                        {
                            'id': 7,
                            'path': '16.png',
                            'preview': '17.png'
                        },
                        {
                            'id': 8,
                            'path': '18.png',
                            'preview': '19.png'
                        }
                    ],
                    count: 8,
                    default_id: 1,
                    fg: '3.png',
                    tips_x: 279,
                    tips_y: 147,
                    tips_bg: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 335,
                    y: 68,
                    image_array: [
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png'
                    ],
                    image_length: 29,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 228,
                    y: 103,
                    type: hmUI.data_type.AQI,
                    font_array: [
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png',
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png',
                        '58.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '60.png',
                    unit_tc: '60.png',
                    unit_en: '60.png',
                    invalid_image: '59.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 228,
                    y: 63,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: [
                        '61.png',
                        '62.png',
                        '63.png',
                        '64.png',
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '73.png',
                    unit_tc: '73.png',
                    unit_en: '73.png',
                    negative_image: '72.png',
                    invalid_image: '71.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 144,
                    y: 66,
                    week_en: [
                        '74.png',
                        '75.png',
                        '76.png',
                        '77.png',
                        '78.png',
                        '79.png',
                        '80.png'
                    ],
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 83,
                    month_startY: 110,
                    month_en_array: [
                        '81.png',
                        '82.png',
                        '83.png',
                        '84.png',
                        '85.png',
                        '86.png',
                        '87.png',
                        '88.png',
                        '89.png',
                        '90.png',
                        '91.png',
                        '92.png'
                    ],
                    month_align: hmUI.align.LEFT,
                    month_zero: 0,
                    month_follow: 0,
                    month_space: 0,
                    month_is_character: true,
                    day_startX: 172,
                    day_startY: 103,
                    day_sc_array: [
                        '61.png',
                        '62.png',
                        '63.png',
                        '64.png',
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png'
                    ],
                    day_tc_array: [
                        '61.png',
                        '62.png',
                        '63.png',
                        '64.png',
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png'
                    ],
                    day_en_array: [
                        '61.png',
                        '62.png',
                        '63.png',
                        '64.png',
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png'
                    ],
                    day_align: hmUI.align.LEFT,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 0,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 68,
                    hour_startY: 186,
                    hour_array: [
                        '93.png',
                        '94.png',
                        '95.png',
                        '96.png',
                        '97.png',
                        '98.png',
                        '99.png',
                        '100.png',
                        '101.png',
                        '102.png'
                    ],
                    hour_space: 0,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 252,
                    minute_startY: 186,
                    minute_array: [
                        '103.png',
                        '104.png',
                        '105.png',
                        '106.png',
                        '107.png',
                        '108.png',
                        '109.png',
                        '110.png',
                        '111.png',
                        '112.png'
                    ],
                    minute_space: 0,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    second_zero: 1,
                    second_startX: 415,
                    second_startY: 255,
                    second_array: [
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png',
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png',
                        '58.png'
                    ],
                    second_space: 0,
                    second_align: hmUI.align.LEFT,
                    second_follow: 0,
                    am_x: 15,
                    am_y: 188,
                    am_sc_path: '113.png',
                    am_en_path: '114.png',
                    pm_x: 16,
                    pm_y: 189,
                    pm_sc_path: '115.png',
                    pm_en_path: '116.png',
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 232,
                    y: 211,
                    w: 16,
                    h: 58,
                    src: '117.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 411,
                    y: 190,
                    src: '118.png',
                    type: hmUI.system_status.DISCONNECT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 226,
                    y: 11,
                    src: '119.png',
                    type: hmUI.system_status.DISTURB,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 36,
                    y: 224,
                    src: '120.png',
                    type: hmUI.system_status.LOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 36,
                    y: 262,
                    src: '121.png',
                    type: hmUI.system_status.CLOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$component_0$_$component = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: 2,
                    x: 67,
                    y: 315,
                    w: 105,
                    h: 93,
                    select_image: '122.png',
                    un_select_image: '123.png',
                    default_type: hmUI.edit_type.HEART,
                    optional_types: [
                        {
                            'type': hmUI.edit_type.HEART,
                            'preview': '125.png'
                        },
                        {
                            'type': hmUI.edit_type.SPO2,
                            'preview': '126.png'
                        },
                        {
                            'type': hmUI.edit_type.UVI,
                            'preview': '127.png'
                        },
                        {
                            'type': hmUI.edit_type.VO2MAX,
                            'preview': '128.png'
                        },
                        {
                            'type': hmUI.edit_type.STEP,
                            'preview': '129.png'
                        },
                        {
                            'type': hmUI.edit_type.BATTERY,
                            'preview': '130.png'
                        },
                        {
                            'type': hmUI.edit_type.CAL,
                            'preview': '131.png'
                        },
                        {
                            'type': hmUI.edit_type.HUMIDITY,
                            'preview': '132.png'
                        },
                        {
                            'type': hmUI.edit_type.DISTANCE,
                            'preview': '133.png'
                        },
                        {
                            'type': hmUI.edit_type.PAI_DAILY,
                            'preview': '134.png'
                        }
                    ],
                    count: 10,
                    tips_BG: '124.png',
                    tips_x: 1,
                    tips_y: -35,
                    tips_width: 100,
                    tips_margin: 0
                });
                editType = normal$_$component_0$_$component.getProperty(hmUI.prop.CURRENT_TYPE);
                switch (editType) {
                case hmUI.edit_type.STEP:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 57,
                        y: 363,
                        type: hmUI.data_type.STEP,
                        font_array: [
                            '135.png',
                            '136.png',
                            '137.png',
                            '138.png',
                            '139.png',
                            '140.png',
                            '141.png',
                            '142.png',
                            '143.png',
                            '144.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 104,
                        y: 324,
                        src: '145.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 67,
                        y: 315,
                        w: 105,
                        h: 93,
                        type: hmUI.data_type.STEP,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.BATTERY:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 70,
                        y: 363,
                        type: hmUI.data_type.BATTERY,
                        font_array: [
                            '135.png',
                            '136.png',
                            '137.png',
                            '138.png',
                            '139.png',
                            '140.png',
                            '141.png',
                            '142.png',
                            '143.png',
                            '144.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        unit_sc: '146.png',
                        unit_tc: '146.png',
                        unit_en: '146.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 104,
                        y: 324,
                        src: '147.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 67,
                        y: 315,
                        w: 105,
                        h: 93,
                        type: hmUI.data_type.BATTERY,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.HEART:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 83,
                        y: 363,
                        type: hmUI.data_type.HEART,
                        font_array: [
                            '135.png',
                            '136.png',
                            '137.png',
                            '138.png',
                            '139.png',
                            '140.png',
                            '141.png',
                            '142.png',
                            '143.png',
                            '144.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '148.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 104,
                        y: 324,
                        src: '149.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 67,
                        y: 315,
                        w: 105,
                        h: 93,
                        type: hmUI.data_type.HEART,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.CAL:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 70,
                        y: 363,
                        type: hmUI.data_type.CAL,
                        font_array: [
                            '135.png',
                            '136.png',
                            '137.png',
                            '138.png',
                            '139.png',
                            '140.png',
                            '141.png',
                            '142.png',
                            '143.png',
                            '144.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 104,
                        y: 324,
                        src: '150.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 67,
                        y: 315,
                        w: 105,
                        h: 93,
                        type: hmUI.data_type.CAL,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.PAI_DAILY:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 83,
                        y: 363,
                        type: hmUI.data_type.PAI_DAILY,
                        font_array: [
                            '135.png',
                            '136.png',
                            '137.png',
                            '138.png',
                            '139.png',
                            '140.png',
                            '141.png',
                            '142.png',
                            '143.png',
                            '144.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 104,
                        y: 324,
                        src: '151.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 67,
                        y: 315,
                        w: 105,
                        h: 93,
                        type: hmUI.data_type.PAI_DAILY,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.DISTANCE:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 59,
                        y: 363,
                        type: hmUI.data_type.DISTANCE,
                        font_array: [
                            '135.png',
                            '136.png',
                            '137.png',
                            '138.png',
                            '139.png',
                            '140.png',
                            '141.png',
                            '142.png',
                            '143.png',
                            '144.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        unit_sc: '153.png',
                        unit_tc: '153.png',
                        unit_en: '153.png',
                        imperial_unit_sc: '154.png',
                        imperial_unit_tc: '154.png',
                        imperial_unit_en: '154.png',
                        dot_image: '152.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 104,
                        y: 324,
                        src: '155.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 67,
                        y: 315,
                        w: 105,
                        h: 93,
                        type: hmUI.data_type.DISTANCE,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.AQI:
                    break;
                case hmUI.edit_type.HUMIDITY:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 70,
                        y: 363,
                        type: hmUI.data_type.HUMIDITY,
                        font_array: [
                            '135.png',
                            '136.png',
                            '137.png',
                            '138.png',
                            '139.png',
                            '140.png',
                            '141.png',
                            '142.png',
                            '143.png',
                            '144.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        unit_sc: '157.png',
                        unit_tc: '157.png',
                        unit_en: '157.png',
                        invalid_image: '156.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 104,
                        y: 324,
                        src: '158.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 67,
                        y: 315,
                        w: 105,
                        h: 93,
                        type: hmUI.data_type.HUMIDITY,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.ALTIMETER:
                    break;
                case hmUI.edit_type.STRESS:
                    break;
                case hmUI.edit_type.WIND:
                    break;
                case hmUI.edit_type.SPO2:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 70,
                        y: 363,
                        type: hmUI.data_type.SPO2,
                        font_array: [
                            '135.png',
                            '136.png',
                            '137.png',
                            '138.png',
                            '139.png',
                            '140.png',
                            '141.png',
                            '142.png',
                            '143.png',
                            '144.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        unit_sc: '160.png',
                        unit_tc: '160.png',
                        unit_en: '160.png',
                        invalid_image: '159.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 104,
                        y: 324,
                        src: '161.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 67,
                        y: 315,
                        w: 105,
                        h: 93,
                        type: hmUI.data_type.SPO2,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.TRAINING_LOAD:
                    break;
                case hmUI.edit_type.VO2MAX:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 95,
                        y: 363,
                        type: hmUI.data_type.VO2MAX,
                        font_array: [
                            '135.png',
                            '136.png',
                            '137.png',
                            '138.png',
                            '139.png',
                            '140.png',
                            '141.png',
                            '142.png',
                            '143.png',
                            '144.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '162.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 104,
                        y: 324,
                        src: '163.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 67,
                        y: 315,
                        w: 105,
                        h: 93,
                        type: hmUI.data_type.VO2MAX,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.UVI:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 95,
                        y: 363,
                        type: hmUI.data_type.UVI,
                        font_array: [
                            '135.png',
                            '136.png',
                            '137.png',
                            '138.png',
                            '139.png',
                            '140.png',
                            '141.png',
                            '142.png',
                            '143.png',
                            '144.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '164.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 104,
                        y: 324,
                        src: '165.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 67,
                        y: 315,
                        w: 105,
                        h: 93,
                        type: hmUI.data_type.UVI,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.DATE:
                    break;
                case hmUI.edit_type.WEEK:
                    break;
                case hmUI.edit_type.WEATHER:
                    break;
                case hmUI.edit_type.TEMPERATURE:
                    break;
                case hmUI.edit_type.SUN:
                    break;
                }
                normal$_$component_1$_$component = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: 3,
                    x: 187,
                    y: 315,
                    w: 105,
                    h: 93,
                    select_image: '166.png',
                    un_select_image: '167.png',
                    default_type: hmUI.edit_type.STEP,
                    optional_types: [
                        {
                            'type': hmUI.edit_type.STEP,
                            'preview': '169.png'
                        },
                        {
                            'type': hmUI.edit_type.SPO2,
                            'preview': '170.png'
                        },
                        {
                            'type': hmUI.edit_type.UVI,
                            'preview': '171.png'
                        },
                        {
                            'type': hmUI.edit_type.VO2MAX,
                            'preview': '172.png'
                        },
                        {
                            'type': hmUI.edit_type.BATTERY,
                            'preview': '173.png'
                        },
                        {
                            'type': hmUI.edit_type.CAL,
                            'preview': '174.png'
                        },
                        {
                            'type': hmUI.edit_type.HUMIDITY,
                            'preview': '175.png'
                        },
                        {
                            'type': hmUI.edit_type.DISTANCE,
                            'preview': '176.png'
                        },
                        {
                            'type': hmUI.edit_type.HEART,
                            'preview': '177.png'
                        },
                        {
                            'type': hmUI.edit_type.PAI_DAILY,
                            'preview': '178.png'
                        }
                    ],
                    count: 10,
                    tips_BG: '168.png',
                    tips_x: 1,
                    tips_y: -35,
                    tips_width: 100,
                    tips_margin: 0
                });
                editType = normal$_$component_1$_$component.getProperty(hmUI.prop.CURRENT_TYPE);
                switch (editType) {
                case hmUI.edit_type.STEP:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 177,
                        y: 363,
                        type: hmUI.data_type.STEP,
                        font_array: [
                            '135.png',
                            '136.png',
                            '137.png',
                            '138.png',
                            '139.png',
                            '140.png',
                            '141.png',
                            '142.png',
                            '143.png',
                            '144.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 224,
                        y: 324,
                        src: '145.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 187,
                        y: 315,
                        w: 105,
                        h: 93,
                        type: hmUI.data_type.STEP,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.BATTERY:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 190,
                        y: 363,
                        type: hmUI.data_type.BATTERY,
                        font_array: [
                            '135.png',
                            '136.png',
                            '137.png',
                            '138.png',
                            '139.png',
                            '140.png',
                            '141.png',
                            '142.png',
                            '143.png',
                            '144.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        unit_sc: '179.png',
                        unit_tc: '179.png',
                        unit_en: '179.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 224,
                        y: 324,
                        src: '147.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 187,
                        y: 315,
                        w: 105,
                        h: 93,
                        type: hmUI.data_type.BATTERY,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.HEART:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 203,
                        y: 363,
                        type: hmUI.data_type.HEART,
                        font_array: [
                            '135.png',
                            '136.png',
                            '137.png',
                            '138.png',
                            '139.png',
                            '140.png',
                            '141.png',
                            '142.png',
                            '143.png',
                            '144.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '148.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 224,
                        y: 324,
                        src: '149.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 187,
                        y: 315,
                        w: 105,
                        h: 93,
                        type: hmUI.data_type.HEART,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.CAL:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 190,
                        y: 363,
                        type: hmUI.data_type.CAL,
                        font_array: [
                            '135.png',
                            '136.png',
                            '137.png',
                            '138.png',
                            '139.png',
                            '140.png',
                            '141.png',
                            '142.png',
                            '143.png',
                            '144.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 224,
                        y: 324,
                        src: '180.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 187,
                        y: 315,
                        w: 105,
                        h: 93,
                        type: hmUI.data_type.CAL,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.PAI_DAILY:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 203,
                        y: 363,
                        type: hmUI.data_type.PAI_DAILY,
                        font_array: [
                            '135.png',
                            '136.png',
                            '137.png',
                            '138.png',
                            '139.png',
                            '140.png',
                            '141.png',
                            '142.png',
                            '143.png',
                            '144.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 224,
                        y: 324,
                        src: '181.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 187,
                        y: 315,
                        w: 105,
                        h: 93,
                        type: hmUI.data_type.PAI_DAILY,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.DISTANCE:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 179,
                        y: 363,
                        type: hmUI.data_type.DISTANCE,
                        font_array: [
                            '135.png',
                            '136.png',
                            '137.png',
                            '138.png',
                            '139.png',
                            '140.png',
                            '141.png',
                            '142.png',
                            '143.png',
                            '144.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        unit_sc: '183.png',
                        unit_tc: '183.png',
                        unit_en: '183.png',
                        imperial_unit_sc: '184.png',
                        imperial_unit_tc: '184.png',
                        imperial_unit_en: '184.png',
                        dot_image: '182.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 224,
                        y: 324,
                        src: '185.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 187,
                        y: 315,
                        w: 105,
                        h: 93,
                        type: hmUI.data_type.DISTANCE,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.AQI:
                    break;
                case hmUI.edit_type.HUMIDITY:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 190,
                        y: 363,
                        type: hmUI.data_type.HUMIDITY,
                        font_array: [
                            '135.png',
                            '136.png',
                            '137.png',
                            '138.png',
                            '139.png',
                            '140.png',
                            '141.png',
                            '142.png',
                            '143.png',
                            '144.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        unit_sc: '187.png',
                        unit_tc: '187.png',
                        unit_en: '187.png',
                        invalid_image: '186.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 224,
                        y: 324,
                        src: '188.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 187,
                        y: 315,
                        w: 105,
                        h: 93,
                        type: hmUI.data_type.HUMIDITY,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.ALTIMETER:
                    break;
                case hmUI.edit_type.STRESS:
                    break;
                case hmUI.edit_type.WIND:
                    break;
                case hmUI.edit_type.SPO2:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 190,
                        y: 363,
                        type: hmUI.data_type.SPO2,
                        font_array: [
                            '135.png',
                            '136.png',
                            '137.png',
                            '138.png',
                            '139.png',
                            '140.png',
                            '141.png',
                            '142.png',
                            '143.png',
                            '144.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        unit_sc: '190.png',
                        unit_tc: '190.png',
                        unit_en: '190.png',
                        invalid_image: '189.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 224,
                        y: 324,
                        src: '191.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 187,
                        y: 315,
                        w: 105,
                        h: 93,
                        type: hmUI.data_type.SPO2,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.TRAINING_LOAD:
                    break;
                case hmUI.edit_type.VO2MAX:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 215,
                        y: 363,
                        type: hmUI.data_type.VO2MAX,
                        font_array: [
                            '135.png',
                            '136.png',
                            '137.png',
                            '138.png',
                            '139.png',
                            '140.png',
                            '141.png',
                            '142.png',
                            '143.png',
                            '144.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '192.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 224,
                        y: 324,
                        src: '193.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 187,
                        y: 315,
                        w: 105,
                        h: 93,
                        type: hmUI.data_type.VO2MAX,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.UVI:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 215,
                        y: 363,
                        type: hmUI.data_type.UVI,
                        font_array: [
                            '135.png',
                            '136.png',
                            '137.png',
                            '138.png',
                            '139.png',
                            '140.png',
                            '141.png',
                            '142.png',
                            '143.png',
                            '144.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '194.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 224,
                        y: 324,
                        src: '195.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 187,
                        y: 315,
                        w: 105,
                        h: 93,
                        type: hmUI.data_type.UVI,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.DATE:
                    break;
                case hmUI.edit_type.WEEK:
                    break;
                case hmUI.edit_type.WEATHER:
                    break;
                case hmUI.edit_type.TEMPERATURE:
                    break;
                case hmUI.edit_type.SUN:
                    break;
                }
                normal$_$component_2$_$component = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: 4,
                    x: 307,
                    y: 315,
                    w: 105,
                    h: 93,
                    select_image: '196.png',
                    un_select_image: '197.png',
                    default_type: hmUI.edit_type.BATTERY,
                    optional_types: [
                        {
                            'type': hmUI.edit_type.BATTERY,
                            'preview': '199.png'
                        },
                        {
                            'type': hmUI.edit_type.SPO2,
                            'preview': '200.png'
                        },
                        {
                            'type': hmUI.edit_type.UVI,
                            'preview': '201.png'
                        },
                        {
                            'type': hmUI.edit_type.VO2MAX,
                            'preview': '202.png'
                        },
                        {
                            'type': hmUI.edit_type.STEP,
                            'preview': '203.png'
                        },
                        {
                            'type': hmUI.edit_type.CAL,
                            'preview': '204.png'
                        },
                        {
                            'type': hmUI.edit_type.HUMIDITY,
                            'preview': '205.png'
                        },
                        {
                            'type': hmUI.edit_type.DISTANCE,
                            'preview': '206.png'
                        },
                        {
                            'type': hmUI.edit_type.HEART,
                            'preview': '207.png'
                        },
                        {
                            'type': hmUI.edit_type.PAI_DAILY,
                            'preview': '208.png'
                        }
                    ],
                    count: 10,
                    tips_BG: '198.png',
                    tips_x: 1,
                    tips_y: -35,
                    tips_width: 100,
                    tips_margin: 0
                });
                editType = normal$_$component_2$_$component.getProperty(hmUI.prop.CURRENT_TYPE);
                switch (editType) {
                case hmUI.edit_type.STEP:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 297,
                        y: 363,
                        type: hmUI.data_type.STEP,
                        font_array: [
                            '135.png',
                            '136.png',
                            '137.png',
                            '138.png',
                            '139.png',
                            '140.png',
                            '141.png',
                            '142.png',
                            '143.png',
                            '144.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 344,
                        y: 324,
                        src: '145.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 307,
                        y: 315,
                        w: 105,
                        h: 93,
                        type: hmUI.data_type.STEP,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.BATTERY:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 310,
                        y: 363,
                        type: hmUI.data_type.BATTERY,
                        font_array: [
                            '135.png',
                            '136.png',
                            '137.png',
                            '138.png',
                            '139.png',
                            '140.png',
                            '141.png',
                            '142.png',
                            '143.png',
                            '144.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        unit_sc: '209.png',
                        unit_tc: '209.png',
                        unit_en: '209.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 344,
                        y: 324,
                        src: '147.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 307,
                        y: 315,
                        w: 105,
                        h: 93,
                        type: hmUI.data_type.BATTERY,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.HEART:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 323,
                        y: 363,
                        type: hmUI.data_type.HEART,
                        font_array: [
                            '135.png',
                            '136.png',
                            '137.png',
                            '138.png',
                            '139.png',
                            '140.png',
                            '141.png',
                            '142.png',
                            '143.png',
                            '144.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '148.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 344,
                        y: 324,
                        src: '149.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 307,
                        y: 315,
                        w: 105,
                        h: 93,
                        type: hmUI.data_type.HEART,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.CAL:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 310,
                        y: 363,
                        type: hmUI.data_type.CAL,
                        font_array: [
                            '135.png',
                            '136.png',
                            '137.png',
                            '138.png',
                            '139.png',
                            '140.png',
                            '141.png',
                            '142.png',
                            '143.png',
                            '144.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 344,
                        y: 324,
                        src: '210.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 307,
                        y: 315,
                        w: 105,
                        h: 93,
                        type: hmUI.data_type.CAL,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.PAI_DAILY:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 323,
                        y: 363,
                        type: hmUI.data_type.PAI_DAILY,
                        font_array: [
                            '135.png',
                            '136.png',
                            '137.png',
                            '138.png',
                            '139.png',
                            '140.png',
                            '141.png',
                            '142.png',
                            '143.png',
                            '144.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 344,
                        y: 324,
                        src: '211.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 307,
                        y: 315,
                        w: 105,
                        h: 93,
                        type: hmUI.data_type.PAI_DAILY,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.DISTANCE:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 299,
                        y: 363,
                        type: hmUI.data_type.DISTANCE,
                        font_array: [
                            '135.png',
                            '136.png',
                            '137.png',
                            '138.png',
                            '139.png',
                            '140.png',
                            '141.png',
                            '142.png',
                            '143.png',
                            '144.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        unit_sc: '213.png',
                        unit_tc: '213.png',
                        unit_en: '213.png',
                        imperial_unit_sc: '214.png',
                        imperial_unit_tc: '214.png',
                        imperial_unit_en: '214.png',
                        dot_image: '212.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 344,
                        y: 324,
                        src: '215.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 307,
                        y: 315,
                        w: 105,
                        h: 93,
                        type: hmUI.data_type.DISTANCE,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.AQI:
                    break;
                case hmUI.edit_type.HUMIDITY:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 310,
                        y: 363,
                        type: hmUI.data_type.HUMIDITY,
                        font_array: [
                            '135.png',
                            '136.png',
                            '137.png',
                            '138.png',
                            '139.png',
                            '140.png',
                            '141.png',
                            '142.png',
                            '143.png',
                            '144.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        unit_sc: '217.png',
                        unit_tc: '217.png',
                        unit_en: '217.png',
                        invalid_image: '216.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 344,
                        y: 324,
                        src: '218.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 307,
                        y: 315,
                        w: 105,
                        h: 93,
                        type: hmUI.data_type.HUMIDITY,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.ALTIMETER:
                    break;
                case hmUI.edit_type.STRESS:
                    break;
                case hmUI.edit_type.WIND:
                    break;
                case hmUI.edit_type.SPO2:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 310,
                        y: 363,
                        type: hmUI.data_type.SPO2,
                        font_array: [
                            '135.png',
                            '136.png',
                            '137.png',
                            '138.png',
                            '139.png',
                            '140.png',
                            '141.png',
                            '142.png',
                            '143.png',
                            '144.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        unit_sc: '220.png',
                        unit_tc: '220.png',
                        unit_en: '220.png',
                        invalid_image: '219.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 344,
                        y: 324,
                        src: '221.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 307,
                        y: 315,
                        w: 105,
                        h: 93,
                        type: hmUI.data_type.SPO2,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.TRAINING_LOAD:
                    break;
                case hmUI.edit_type.VO2MAX:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 335,
                        y: 363,
                        type: hmUI.data_type.VO2MAX,
                        font_array: [
                            '135.png',
                            '136.png',
                            '137.png',
                            '138.png',
                            '139.png',
                            '140.png',
                            '141.png',
                            '142.png',
                            '143.png',
                            '144.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '222.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 344,
                        y: 324,
                        src: '223.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 307,
                        y: 315,
                        w: 105,
                        h: 93,
                        type: hmUI.data_type.VO2MAX,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.UVI:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 335,
                        y: 363,
                        type: hmUI.data_type.UVI,
                        font_array: [
                            '135.png',
                            '136.png',
                            '137.png',
                            '138.png',
                            '139.png',
                            '140.png',
                            '141.png',
                            '142.png',
                            '143.png',
                            '144.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '224.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 344,
                        y: 324,
                        src: '225.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 307,
                        y: 315,
                        w: 105,
                        h: 93,
                        type: hmUI.data_type.UVI,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.DATE:
                    break;
                case hmUI.edit_type.WEEK:
                    break;
                case hmUI.edit_type.WEATHER:
                    break;
                case hmUI.edit_type.TEMPERATURE:
                    break;
                case hmUI.edit_type.SUN:
                    break;
                }
                hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '226.png',
                    show_level: hmUI.show_level.ONLY_EDIT
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 70,
                    hour_startY: 185,
                    hour_array: [
                        '227.png',
                        '228.png',
                        '229.png',
                        '230.png',
                        '231.png',
                        '232.png',
                        '233.png',
                        '234.png',
                        '235.png',
                        '236.png'
                    ],
                    hour_space: 0,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 250,
                    minute_startY: 185,
                    minute_array: [
                        '227.png',
                        '228.png',
                        '229.png',
                        '230.png',
                        '231.png',
                        '232.png',
                        '233.png',
                        '234.png',
                        '235.png',
                        '236.png'
                    ],
                    minute_space: 0,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 232,
                    y: 210,
                    w: 16,
                    h: 58,
                    src: '237.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}