try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
                    edit_id: 1,
                    x: 0,
                    y: 0,
                    bg_config: [
                        {
                            'id': 1,
                            'path': '4.png',
                            'preview': '4.png'
                        },
                        {
                            'id': 2,
                            'path': '5.png',
                            'preview': '5.png'
                        },
                        {
                            'id': 3,
                            'path': '6.png',
                            'preview': '6.png'
                        },
                        {
                            'id': 4,
                            'path': '7.png',
                            'preview': '7.png'
                        }
                    ],
                    count: 4,
                    default_id: 1,
                    fg: '3.png',
                    tips_x: 0,
                    tips_y: 0,
                    tips_bg: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 313,
                    hour_startY: 200,
                    hour_array: [
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png'
                    ],
                    hour_space: 0,
                    hour_unit_sc: '18.png',
                    hour_unit_tc: '18.png',
                    hour_unit_en: '18.png',
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_array: [
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png'
                    ],
                    minute_follow: 1,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    day_startX: 397,
                    day_startY: 254,
                    day_sc_array: [
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png'
                    ],
                    day_tc_array: [
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png'
                    ],
                    day_en_array: [
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png'
                    ],
                    day_align: hmUI.align.CENTER_H,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 0,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 315,
                    y: 254,
                    week_en: [
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png'
                    ],
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 221,
                    y: 77,
                    image_array: [
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png',
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png',
                        '58.png',
                        '59.png',
                        '60.png',
                        '61.png',
                        '62.png',
                        '63.png',
                        '64.png'
                    ],
                    image_length: 29,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 221,
                    y: 137,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: [
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png',
                        '71.png',
                        '72.png',
                        '73.png',
                        '74.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '77.png',
                    unit_tc: '77.png',
                    unit_en: '77.png',
                    negative_image: '76.png',
                    invalid_image: '75.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: '78.png',
                    center_x: 241,
                    center_y: 114,
                    x: 13,
                    y: 72,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    start_angle: -120,
                    end_angle: 120,
                    cover_x: 0,
                    cover_y: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 210,
                    y: 386,
                    type: hmUI.data_type.STEP,
                    font_array: [
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png',
                        '71.png',
                        '72.png',
                        '73.png',
                        '74.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: '79.png',
                    center_x: 241,
                    center_y: 361,
                    x: 13,
                    y: 68,
                    type: hmUI.data_type.STEP,
                    start_angle: -120,
                    end_angle: 120,
                    cover_x: 0,
                    cover_y: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 158,
                    y: 228,
                    type: hmUI.data_type.BATTERY,
                    font_array: [
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png',
                        '71.png',
                        '72.png',
                        '73.png',
                        '74.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: '80.png',
                    center_x: 115,
                    center_y: 241,
                    x: 13,
                    y: 68,
                    type: hmUI.data_type.BATTERY,
                    start_angle: -180,
                    end_angle: 0,
                    cover_x: 0,
                    cover_y: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 3,
                    y: 3,
                    src: '81.png',
                    type: hmUI.system_status.DISCONNECT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 0,
                    y: 0,
                    src: '82.png',
                    type: hmUI.system_status.CLOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 99,
                    y: 328,
                    type: hmUI.data_type.HEART,
                    font_array: [
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png',
                        '71.png',
                        '72.png',
                        '73.png',
                        '74.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '83.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 100,
                    y: 126,
                    type: hmUI.data_type.STRESS,
                    font_array: [
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png',
                        '71.png',
                        '72.png',
                        '73.png',
                        '74.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '84.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 146,
                    y: 142,
                    src: '85.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 240,
                    hour_centerY: 240,
                    hour_posX: 60,
                    hour_posY: 240,
                    hour_path: '86.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 240,
                    minute_centerY: 240,
                    minute_posX: 60,
                    minute_posY: 240,
                    minute_path: '87.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    second_centerX: 240,
                    second_centerY: 240,
                    second_posX: 32,
                    second_posY: 240,
                    second_path: '88.png',
                    second_cover_x: 0,
                    second_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '89.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 313,
                    hour_startY: 200,
                    hour_array: [
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png'
                    ],
                    hour_space: 0,
                    hour_unit_sc: '18.png',
                    hour_unit_tc: '18.png',
                    hour_unit_en: '18.png',
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_array: [
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png'
                    ],
                    minute_follow: 1,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    day_startX: 397,
                    day_startY: 254,
                    day_sc_array: [
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png'
                    ],
                    day_tc_array: [
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png'
                    ],
                    day_en_array: [
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png'
                    ],
                    day_align: hmUI.align.CENTER_H,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 0,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 315,
                    y: 254,
                    week_en: [
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png'
                    ],
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 221,
                    y: 77,
                    image_array: [
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png',
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png',
                        '58.png',
                        '59.png',
                        '60.png',
                        '61.png',
                        '62.png',
                        '63.png',
                        '64.png'
                    ],
                    image_length: 29,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 221,
                    y: 137,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: [
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png',
                        '71.png',
                        '72.png',
                        '73.png',
                        '74.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_AOD,
                    unit_sc: '77.png',
                    unit_tc: '77.png',
                    unit_en: '77.png',
                    negative_image: '76.png',
                    invalid_image: '75.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: '78.png',
                    center_x: 241,
                    center_y: 114,
                    x: 13,
                    y: 72,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    start_angle: -120,
                    end_angle: 120,
                    cover_x: 0,
                    cover_y: 0,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 210,
                    y: 386,
                    type: hmUI.data_type.STEP,
                    font_array: [
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png',
                        '71.png',
                        '72.png',
                        '73.png',
                        '74.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_AOD,
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: '79.png',
                    center_x: 241,
                    center_y: 361,
                    x: 13,
                    y: 68,
                    type: hmUI.data_type.STEP,
                    start_angle: -120,
                    end_angle: 120,
                    cover_x: 0,
                    cover_y: 0,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 158,
                    y: 228,
                    type: hmUI.data_type.BATTERY,
                    font_array: [
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png',
                        '71.png',
                        '72.png',
                        '73.png',
                        '74.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_AOD,
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: '80.png',
                    center_x: 115,
                    center_y: 241,
                    x: 13,
                    y: 68,
                    type: hmUI.data_type.BATTERY,
                    start_angle: -180,
                    end_angle: 0,
                    cover_x: 0,
                    cover_y: 0,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 99,
                    y: 328,
                    type: hmUI.data_type.HEART,
                    font_array: [
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png',
                        '71.png',
                        '72.png',
                        '73.png',
                        '74.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_AOD,
                    invalid_image: '83.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 240,
                    hour_centerY: 240,
                    hour_posX: 60,
                    hour_posY: 240,
                    hour_path: '90.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 240,
                    minute_centerY: 240,
                    minute_posX: 60,
                    minute_posY: 240,
                    minute_path: '91.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 180,
                    y: 60,
                    w: 120,
                    h: 120,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 180,
                    y: 298,
                    w: 120,
                    h: 120,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 51,
                    y: 180,
                    w: 120,
                    h: 120,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 86,
                    y: 318,
                    w: 60,
                    h: 40,
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 89,
                    y: 117,
                    w: 60,
                    h: 40,
                    type: hmUI.data_type.STRESS,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}