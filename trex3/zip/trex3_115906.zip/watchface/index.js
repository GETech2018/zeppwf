try {
  (() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__),
      'drink'
    );

    /*
     * huamiOS bundle tool v1.0.17
     * Copyright © Huami. All Rights Reserved
     */
    ('use strict');

    console.log('----->>>current');
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let rootPath = 'images/';
    let bigPath = rootPath + 'big/';
    let iconPath = rootPath + 'icon/';
    let maskPath = rootPath + 'mask/';
    let previewPath = rootPath + 'preview/';
    let smallPath = rootPath + 'small/';
    let week_cnPath = rootPath + 'week_cn/';
    let week_enPath = rootPath + 'week_en/';
    let type = null;
    let item_text = null;

    let big_num_array = [];
    let small_num_array = [];
    let week_en_array = [];
    let week_cn_array = [];

    //获取设备信息  0 -方屏、1-圆屏
    const deviceInfo = hmSetting.getDeviceInfo();
    let { width, height, screenShape } = deviceInfo;
    // 确认所获取数据的类型  基本类型
    // console.log('deviceInfo+++++++++++++++++++++width', width);
    // console.log('deviceInfo+++++++++++++++++++++height', height);
    // console.log('deviceInfo+++++++++++++++++++++screenShape', screenShape);

    let key;
    let baseWidth;
    // TODO: 测试用
    // screenShape = 1;
    // width = 454;
    // height = 454;
    switch (screenShape) {
      case 0:
        key = 's';
        baseWidth = 390;
        break;
      case 1:
        key = 'r';
        baseWidth = 454;
        break;
    }

    console.log('key++++++++++++++++++++++++', key);
    // console.log('key++++++++++++++++++++++++', baseWidth);
    // 分辨率转换
    let HTML_FONT_SIZE = ((100 * width) / baseWidth).toFixed(2);
    function rem(num) {
      return Math.ceil((num / 100) * HTML_FONT_SIZE);
    }

    // 取对应样式
    function getStyle(objStyle) {
      // 大小适配
      if (key == 'r') {
        let arrRem = [
          'x',
          'y',
          'w',
          'h',
          'hour_startX',
          'hour_startY',
          'minute_startX',
          'minute_startY',
          'minute_space',
          'hour_space',
          'month_startX',
          'month_startY',
          'month_space',
          'day_space',
          'center_x',
          'center_y',
          'radius',
          'line_width',
          'day_startX',
          'day_startY',
          'second_centerX',
          'second_centerY',
          'second_posX',
          'second_posY',
          'hour_centerX',
          'hour_centerY',
          'hour_posX',
          'hour_posY',
          'minute_centerX',
          'minute_centerY',
          'minute_posX',
          'minute_posY',
          'tips_x',
          'tips_y',
          'tips_width',
          //   'iconX',
          //   'iconY'
        ];
        arrRem.forEach((element) => {
          objStyle[element] && (objStyle[element] = rem(objStyle[element]));
        });
      }
      return objStyle;
    }

    for (let i = 0; i < 10; i++) {
      big_num_array.push(bigPath + i + '.png');
      small_num_array.push(smallPath + i + '.png');
    }

    for (let i = 1; i < 8; i++) {
      week_en_array.push(week_enPath + i + '.png');
      week_cn_array.push(week_cnPath + i + '.png');
    }

    const logger = DeviceRuntimeCore.HmLogger.getLogger('defult');
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      drawWidget(item) {
        config = {
          iconX: 157,
          iconY: 384,
          // numX: 205,
          // numY: 375,
          iconImg: null,
          unit: null,
          type: null,
          invalid: null,
        };
        // config.dot = stepPath + "dot.png"
        switch (item) {
          case hmUI.edit_type.HEART:
            config.iconImg = iconPath + 'hr.png';
            config.type = hmUI.data_type.HEART;
            config.invalid = smallPath + 'null.png';

            break;
          case hmUI.edit_type.BATTERY:
            config.iconImg = iconPath + 'bt.png';
            config.type = hmUI.data_type.BATTERY;
            config.unit = smallPath + 'baifen.png';

            break;
          case hmUI.edit_type.STEP:
            config.iconImg = iconPath + 'st.png';
            config.type = hmUI.data_type.STEP;

            break;
          case hmUI.edit_type.CAL:
            config.iconImg = iconPath + 'cal.png';
            config.type = hmUI.data_type.CAL;
            break;
          case hmUI.edit_type.ALTIMETER: // 气压
            config.iconImg = iconPath + 'kpa.png';
            config.type = hmUI.data_type.ALTIMETER;
            config.invalid = smallPath + 'null.png';

            break;
          case hmUI.edit_type.ALTITUDE: //海拔
            config.iconImg = iconPath + 'hb.png';
            config.type = hmUI.data_type.ALTITUDE;
            config.invalid = smallPath + 'null.png';
            config.negative = smallPath + 'fu.png';
            break;
          default:
            return config;
            break;
        }

        // const item_iconImg = hmUI.createWidget(hmUI.widget.IMG, {
        //     x: config.iconX,
        //     y: config.iconY,
        //     src: config.iconImg,
        //     show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD,
        // })

        // let item_text = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
        //     x: config.numX,
        //     y: config.numY,
        //     type: config.type,
        //     font_array: small_num_array,
        //     h_space: 0,
        //     align_h: hmUI.align.LEFT,
        //     unit_sc: config.unit,
        //     unit_tc: config.unit,
        //     unit_en: config.unit,
        //     invalid_image: config.invalid,
        //     padding: false,
        //     show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD,
        // });
        type = config.type;
        item_text = hmUI.createWidget(
          hmUI.widget.TEXT_IMG,
          getStyle({
            x: 0,
            y: config.iconY,
            w: 454,
            h: 40,
            icon: config.iconImg,
            icon_space: 8,
            type: config.type,
            font_array: small_num_array,
            h_space: 0,
            align_h: hmUI.align.CENTER_H,
            unit_sc: config.unit,
            unit_tc: config.unit,
            unit_en: config.unit,
            invalid_image: config.invalid,
            negative_image: config.negative,
            padding: false,
            show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD,
          })
        );
      },

      init_view() {
        let bg = hmUI.createWidget(
          hmUI.widget.IMG,
          getStyle({
            x: 0,
            y: 0,
            w: 454,
            h: 454,
            src: rootPath + 'bg.png',
            show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
          })
        );

        // 星期
        let weekNor = hmUI.createWidget(
          hmUI.widget.IMG_WEEK,
          getStyle({
            x: 252,
            y: 223,
            week_tc: week_cn_array,
            week_sc: week_cn_array,
            week_en: week_en_array,
            show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD,
          })
        );

        let weekEdit = hmUI.createWidget(
          hmUI.widget.IMG_WEEK,
          getStyle({
            x: 252,
            y: 224,
            week_tc: week_cn_array,
            week_sc: week_cn_array,
            week_en: week_en_array,
            show_level: hmUI.show_level.ONLY_EDIT,
          })
        );

        // 年月日
        let month = hmUI.createWidget(
          hmUI.widget.IMG_DATE,
          getStyle({
            month_startX: 125,
            month_startY: 223,
            month_zero: true,
            month_en_array: small_num_array,
            month_align: hmUI.align.RIGHT,
            month_unit_sc: smallPath + 'xie.png',
            month_unit_tc: smallPath + 'xie.png',
            month_unit_en: smallPath + 'xie.png',
            day_zero: true,
            day_follow: 1, // 是否跟随
            day_en_array: small_num_array,
            day_align: hmUI.align.LEFT,
            show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD,
          })
        );

        // 时间
        let time = hmUI.createWidget(
          hmUI.widget.IMG_TIME,
          getStyle({
            hour_zero: true,
            hour_startX: 83,
            hour_startY: 280,
            hour_array: big_num_array,
            hour_space: 0,
            hour_unit_sc: bigPath + 'maohao.png', //单位
            hour_unit_tc: bigPath + 'maohao.png',
            hour_unit_en: bigPath + 'maohao.png',
            hour_align: hmUI.align.LEFT,
            minute_startX: 247,
            minute_startY: 280,
            minute_zero: 1, //是否补零 1为补零
            minute_array: big_num_array,
            show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD,
          })
        );

        let optionWidgets = [
          {
            type: hmUI.edit_type.HEART,
            preview: previewPath + 'hr.png',
          },
          {
            type: hmUI.edit_type.BATTERY,
            preview: previewPath + 'bt.png',
          },
          {
            type: hmUI.edit_type.STEP,
            preview: previewPath + 'st.png',
          },
          {
            type: hmUI.edit_type.CAL,
            preview: previewPath + 'cal.png',
          },
          {
            //气压
            type: hmUI.edit_type.ALTIMETER,
            preview: previewPath + 'kpa.png',
          },
          {
            //海拔
            type: hmUI.edit_type.ALTITUDE,
            preview: previewPath + 'hb.png',
          },
        ];

        let groupX = 149;
        let groupY = 380;
        let edit_list_config = {
          title_font_size: 34,
          title_align_h: hmUI.align.CENTER_H,
          list_item_vspace: 8,
          list_bg_color: 0x0000,
          list_bg_radius: 30,
          list_group_text_font_size: 32,
          list_group_text_align_h: hmUI.align.CENTER_H,
          list_tips_text_font_size: 32,
          list_tips_text_align_h: hmUI.align.LEFT,
        };

        let Group = hmUI.createWidget(
          hmUI.widget.WATCHFACE_EDIT_GROUP,
          getStyle({
            edit_id: 101,
            x: groupX,
            y: groupY,
            w: 170,
            h: 50,
            select_image: maskPath + 'select.png',
            un_select_image: maskPath + 'select.png',
            default_type: hmUI.edit_type.STEP,
            optional_types: optionWidgets,
            count: optionWidgets.length,
            tips_BG: maskPath + 'tips.png',
            tips_x: 13,
            tips_y: -359,
            tips_width: 148,
            tips_margin: 10,
            select_list: edit_list_config, // 新增配置选项
          })
        );

        let item1 = Group.getProperty(hmUI.prop.CURRENT_TYPE);
        this.drawWidget(item1);
        let objClickStyle = getStyle({
          x: 165,
          y: 378,
          w: 165,
          h: 57,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        //100%mask
        let maskCover = hmUI.createWidget(
          hmUI.widget.IMG,
          getStyle({
            x: 0,
            y: 0,
            w: 454,
            h: 454,
            src: maskPath + 'mask_100.png',
            show_level: hmUI.show_level.ONLY_EDIT,
          })
        );

        //70%msk
        let mask = hmUI.createWidget(
          hmUI.widget.IMG,
          getStyle({
            x: 0,
            y: 0,
            w: 454,
            h: 454,
            src: maskPath + 'mask70.png',
            show_level: hmUI.show_level.ONLY_EDIT,
          })
        );

        click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          ...objClickStyle,
          type: type, //必写 跳转的action
        });

        // 获取颜色方法----------------------------------------------------
        let getColor = readColor();
        try {
          weekNor.setColor(getColor);
          month.setColor(getColor);
          time.setColor(getColor);
          item_text.setColor(getColor);
        } catch (error) {
          console.log(error);
        }

        function readColor() {
          //资源文件路径: assets/config.json
          const file_name = 'config.json';
          // 获取文件信息
          // stat_asset 获取应用 assets 目录下的文件信息
          const [file_stat, err] = hmFS.stat_asset(file_name);
          if (err == 0) {
            console.log('file size:', file_stat.size);
          } else {
            console.log('err:', err);
          }
          // 根据文件大小申请 buffer
          var test_buf = new Uint8Array(file_stat.size);
          //打开文件(hmFS.O_RDONLY ：打开方式为只读只读)
          var fd = hmFS.open_asset(file_name, hmFS.O_RDONLY);
          //定位到文件开始位置
          // seek 移动文件指针
          // hmFS.SEEK_SET 我的理解是通过 hmFS.SEEK_SET 设置指针跳转到 fd文件的 0 位置（开头）
          hmFS.seek(fd, 0, hmFS.SEEK_SET);
          // 读取 buffer
          hmFS.read(fd, test_buf.buffer, 0, test_buf.length);
          // 关闭文件
          hmFS.close(fd);
          //打印读取内容 (config.json内容)
          // fromCharCode 是 string 对象的静态方法，用于将二进制编码转为字符串
          // apply 修改 this 指向，返回一个新的方法，test_buf 参数数组
          // 所以 val 最终得到的是 JSON 格式字符串
          const val = String.fromCharCode.apply(null, test_buf);
          contentObj = val ? JSON.parse(val) : {};
          const colors = parseInt('0x' + contentObj.foreground.color);
          return colors;
        }
      },

      onInit() {
        console.log('index page.js on init invoke');

        this.init_view();
      },

      onReady() {
        console.log('index page.js on ready invoke');
      },

      onShow() {
        console.log('index page.js on show invoke');
      },

      onHide() {
        console.log('index page.js on hide invoke');
      },

      onDestory() {
        console.log('index page.js on destory invoke');
      },
    });
    /*
     * end js
     */
  })();
} catch (e) {
  console.log(e);
}
