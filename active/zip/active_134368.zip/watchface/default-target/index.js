try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 390,
                    h: 450,
                    src: '4.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_val: new Date().getHours(),
                    hour_zero: 1,
                    hour_startX: 36,
                    hour_startY: 88,
                    hour_array: [
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png'
                    ],
                    hour_space: 1,
                    hour_unit_sc: '15.png',
                    hour_unit_tc: '15.png',
                    hour_unit_en: '15.png',
                    hour_align: hmUI.align.CENTER_H,
                    minute_val: new Date().getMinutes(),
                    minute_zero: 1,
                    minute_startX: 186,
                    minute_startY: 88,
                    minute_array: [
                        '5.png',
                        '6.png',
                        '16.png',
                        '8.png',
                        '9.png',
                        '17.png',
                        '18.png',
                        '12.png',
                        '13.png',
                        '14.png'
                    ],
                    minute_space: 1,
                    minute_align: hmUI.align.CENTER_H,
                    minute_follow: 0,
                    second_val: new Date().getSeconds(),
                    second_zero: 1,
                    second_startX: 303,
                    second_startY: 125,
                    second_array: [
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png'
                    ],
                    second_space: -1,
                    second_align: hmUI.align.CENTER_H,
                    second_follow: 0,
                    am_x: 305,
                    am_y: 184,
                    am_sc_path: '29.png',
                    am_en_path: '30.png',
                    pm_x: 305,
                    pm_y: 184,
                    pm_sc_path: '31.png',
                    pm_en_path: '32.png',
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 58,
                    y: 35,
                    week_en: [
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png'
                    ],
                    week_tc: [
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png'
                    ],
                    week_sc: [
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png'
                    ],
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 144,
                    y: 345,
                    src: '54.png',
                    type: hmUI.system_status.DISCONNECT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 214,
                    y: 345,
                    src: '55.png',
                    type: hmUI.system_status.DISTURB,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 68,
                    y: 345,
                    src: '56.png',
                    type: hmUI.system_status.LOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 286,
                    y: 345,
                    src: '57.png',
                    type: hmUI.system_status.CLOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    year_startX: 110,
                    year_startY: 187,
                    year_sc_array: [
                        '58.png',
                        '59.png',
                        '60.png',
                        '61.png',
                        '62.png',
                        '63.png',
                        '64.png',
                        '65.png',
                        '66.png',
                        '67.png'
                    ],
                    year_tc_array: [
                        '58.png',
                        '59.png',
                        '60.png',
                        '61.png',
                        '62.png',
                        '63.png',
                        '64.png',
                        '65.png',
                        '66.png',
                        '67.png'
                    ],
                    year_en_array: [
                        '58.png',
                        '59.png',
                        '60.png',
                        '61.png',
                        '62.png',
                        '63.png',
                        '64.png',
                        '65.png',
                        '66.png',
                        '67.png'
                    ],
                    year_unit_sc: '68.png',
                    year_unit_tc: '68.png',
                    year_unit_en: '68.png',
                    year_align: hmUI.align.CENTER_H,
                    year_zero: 1,
                    year_space: 0,
                    year_is_character: false,
                    month_sc_array: [
                        '58.png',
                        '59.png',
                        '60.png',
                        '61.png',
                        '62.png',
                        '63.png',
                        '64.png',
                        '65.png',
                        '66.png',
                        '67.png'
                    ],
                    month_tc_array: [
                        '58.png',
                        '59.png',
                        '60.png',
                        '61.png',
                        '62.png',
                        '63.png',
                        '64.png',
                        '65.png',
                        '66.png',
                        '67.png'
                    ],
                    month_en_array: [
                        '58.png',
                        '59.png',
                        '60.png',
                        '61.png',
                        '62.png',
                        '63.png',
                        '64.png',
                        '65.png',
                        '66.png',
                        '67.png'
                    ],
                    month_unit_sc: '69.png',
                    month_unit_tc: '69.png',
                    month_unit_en: '69.png',
                    month_zero: 1,
                    month_follow: 1,
                    month_is_character: false,
                    day_sc_array: [
                        '58.png',
                        '59.png',
                        '60.png',
                        '61.png',
                        '62.png',
                        '63.png',
                        '64.png',
                        '65.png',
                        '66.png',
                        '67.png'
                    ],
                    day_tc_array: [
                        '58.png',
                        '59.png',
                        '60.png',
                        '61.png',
                        '62.png',
                        '63.png',
                        '64.png',
                        '65.png',
                        '66.png',
                        '67.png'
                    ],
                    day_en_array: [
                        '58.png',
                        '59.png',
                        '60.png',
                        '61.png',
                        '62.png',
                        '63.png',
                        '64.png',
                        '65.png',
                        '66.png',
                        '67.png'
                    ],
                    day_zero: 1,
                    day_follow: 1,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 167,
                    y: 245,
                    image_array: [
                        '70.png',
                        '71.png',
                        '72.png',
                        '73.png',
                        '74.png',
                        '75.png',
                        '76.png',
                        '77.png',
                        '78.png',
                        '79.png'
                    ],
                    image_length: 10,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 306,
                    y: 246,
                    type: hmUI.data_type.STEP,
                    font_array: [
                        '80.png',
                        '81.png',
                        '82.png',
                        '83.png',
                        '84.png',
                        '85.png',
                        '86.png',
                        '87.png',
                        '88.png',
                        '89.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: -2,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '90.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 161,
                    y: 289,
                    image_array: [
                        '91.png',
                        '92.png',
                        '93.png',
                        '94.png',
                        '95.png',
                        '96.png',
                        '97.png',
                        '98.png',
                        '99.png',
                        '100.png'
                    ],
                    image_length: 10,
                    type: hmUI.data_type.CAL,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 302,
                    y: 290,
                    type: hmUI.data_type.CAL,
                    font_array: [
                        '80.png',
                        '81.png',
                        '82.png',
                        '83.png',
                        '84.png',
                        '85.png',
                        '86.png',
                        '87.png',
                        '88.png',
                        '89.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: -2,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '101.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 8,
                    y: 214,
                    image_array: [
                        '102.png',
                        '103.png',
                        '104.png',
                        '105.png',
                        '106.png',
                        '107.png',
                        '108.png',
                        '109.png',
                        '110.png',
                        '111.png'
                    ],
                    image_length: 10,
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 37,
                    y: 260,
                    type: hmUI.data_type.HEART,
                    font_array: [
                        '112.png',
                        '113.png',
                        '114.png',
                        '115.png',
                        '116.png',
                        '117.png',
                        '118.png',
                        '119.png',
                        '120.png',
                        '121.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -2,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '122.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 136,
                    y: 393,
                    image_array: [
                        '123.png',
                        '124.png',
                        '125.png',
                        '126.png',
                        '127.png',
                        '128.png',
                        '129.png',
                        '130.png',
                        '131.png',
                        '132.png'
                    ],
                    image_length: 10,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 180,
                    y: 403,
                    type: hmUI.data_type.BATTERY,
                    font_array: [
                        '133.png',
                        '134.png',
                        '135.png',
                        '136.png',
                        '137.png',
                        '138.png',
                        '139.png',
                        '140.png',
                        '141.png',
                        '142.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '143.png',
                    unit_tc: '143.png',
                    unit_en: '143.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 390,
                    h: 450,
                    src: '144.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_val: new Date().getHours(),
                    hour_zero: 1,
                    hour_startX: 36,
                    hour_startY: 88,
                    hour_array: [
                        '145.png',
                        '146.png',
                        '147.png',
                        '148.png',
                        '149.png',
                        '150.png',
                        '151.png',
                        '152.png',
                        '153.png',
                        '154.png'
                    ],
                    hour_space: 1,
                    hour_unit_sc: '155.png',
                    hour_unit_tc: '155.png',
                    hour_unit_en: '155.png',
                    hour_align: hmUI.align.CENTER_H,
                    minute_val: new Date().getMinutes(),
                    minute_zero: 1,
                    minute_startX: 186,
                    minute_startY: 88,
                    minute_array: [
                        '145.png',
                        '146.png',
                        '147.png',
                        '148.png',
                        '149.png',
                        '150.png',
                        '151.png',
                        '152.png',
                        '153.png',
                        '154.png'
                    ],
                    minute_space: 1,
                    minute_align: hmUI.align.CENTER_H,
                    minute_follow: 0,
                    am_x: 303,
                    am_y: 139,
                    am_sc_path: '156.png',
                    am_en_path: '157.png',
                    pm_x: 303,
                    pm_y: 139,
                    pm_sc_path: '158.png',
                    pm_en_path: '159.png',
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 138,
                    y: 239,
                    w: 245,
                    h: 40,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 134,
                    y: 285,
                    w: 247,
                    h: 37,
                    type: hmUI.data_type.CAL,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 7,
                    y: 216,
                    w: 120,
                    h: 120,
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 81,
                    y: 392,
                    w: 220,
                    h: 50,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}