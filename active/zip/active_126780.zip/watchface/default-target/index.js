try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_18f740e6f3a94a11a166c3bba635f727 = '';
        let dateFormat = '';
        let dateFormatMap = '';
        let normal$_$text_5ec483d0c12b4e57938ab00ef23598b3 = '';
        let normal$_$text_d8b8fae93a3540d39adde44e69f832e0 = '';
        let normal$_$text_d1511f95732844b1997a7674d0324183 = '';
        let normal$_$text_eed673d4ea3f485985d17123b0ec25da = '';
        let timeSensor = '';
        let heartSensor = '';
        let stepSensor = '';
        let batterySensor = '';
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 390,
                    h: 450,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 23,
                    hour_startY: 117,
                    hour_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    hour_space: 0,
                    hour_align: hmUI.align.RIGHT,
                    minute_zero: 1,
                    minute_startX: 199,
                    minute_startY: 117,
                    minute_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    minute_space: 0,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 131,
                    y: 160,
                    src: '13.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_18f740e6f3a94a11a166c3bba635f727 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 335,
                    y: 247,
                    w: 50,
                    h: 40,
                    text: '[MON_Z]',
                    color: '0xFFe8e8e8',
                    text_size: 29,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_5ec483d0c12b4e57938ab00ef23598b3 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 285,
                    y: 246,
                    w: 50,
                    h: 40,
                    text: '[DAY_Z]/',
                    color: '0xFFe8e8e8',
                    text_size: 29,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.RIGHT,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_d8b8fae93a3540d39adde44e69f832e0 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 55,
                    y: 246,
                    w: 50,
                    h: 40,
                    text: '[HR]',
                    color: '0xFFe8e8e8',
                    text_size: 26,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_d1511f95732844b1997a7674d0324183 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 55,
                    y: 286,
                    w: 70,
                    h: 40,
                    text: '[SC]',
                    color: '0xFFe8e8e8',
                    text_size: 26,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_eed673d4ea3f485985d17123b0ec25da = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 55,
                    y: 326,
                    w: 60,
                    h: 40,
                    text: '[BATT_PER]%',
                    color: '0xFFe8e8e8',
                    text_size: 25,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 29,
                    y: 295,
                    src: '14.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 32,
                    y: 337,
                    src: '15.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 29,
                    y: 258,
                    src: '16.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                if (!timeSensor) {
                    timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                }
                if (!heartSensor) {
                    heartSensor = hmSensor.createSensor(hmSensor.id.HEART);
                }
                if (!stepSensor) {
                    stepSensor = hmSensor.createSensor(hmSensor.id.STEP);
                }
                if (!batterySensor) {
                    batterySensor = hmSensor.createSensor(hmSensor.id.BATTERY);
                }
                timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_18f740e6f3a94a11a166c3bba635f727.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }` });
                        },
                        () => {
                            normal$_$text_18f740e6f3a94a11a166c3bba635f727.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }` });
                        },
                        () => {
                            normal$_$text_18f740e6f3a94a11a166c3bba635f727.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_5ec483d0c12b4e57938ab00ef23598b3.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }/` });
                        },
                        () => {
                            normal$_$text_5ec483d0c12b4e57938ab00ef23598b3.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }/` });
                        },
                        () => {
                            normal$_$text_5ec483d0c12b4e57938ab00ef23598b3.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }/` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                }), heartSensor.addEventListener(heartSensor.event.LAST, function () {
                    normal$_$text_d8b8fae93a3540d39adde44e69f832e0.setProperty(hmUI.prop.MORE, { text: `${ heartSensor.last }` });
                }), stepSensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_d1511f95732844b1997a7674d0324183.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                }), batterySensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_eed673d4ea3f485985d17123b0ec25da.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }%` });
                });
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                normal$_$text_18f740e6f3a94a11a166c3bba635f727.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }` });
                            },
                            () => {
                                normal$_$text_18f740e6f3a94a11a166c3bba635f727.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }` });
                            },
                            () => {
                                normal$_$text_18f740e6f3a94a11a166c3bba635f727.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                normal$_$text_5ec483d0c12b4e57938ab00ef23598b3.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }/` });
                            },
                            () => {
                                normal$_$text_5ec483d0c12b4e57938ab00ef23598b3.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }/` });
                            },
                            () => {
                                normal$_$text_5ec483d0c12b4e57938ab00ef23598b3.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }/` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                        normal$_$text_d8b8fae93a3540d39adde44e69f832e0.setProperty(hmUI.prop.MORE, { text: `${ heartSensor.last }` });
                        normal$_$text_d1511f95732844b1997a7674d0324183.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                        normal$_$text_eed673d4ea3f485985d17123b0ec25da.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }%` });
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}