try {
  (() => {
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    function getApp() {
      return __$$app$$__.app;
    }
    function getCurrentPage() {
      return __$$app$$__.current && __$$app$$__.current.module;
    }
    const __$$module$$__ = __$$app$$__.current;
    const h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__)
    );
    const { px } = __$$app$$__.__globals__;
    let normal$_$component_1$_$component = "";
    let normal$_$component_2$_$component = "";
    let normal$_$component_0$_$component = "";
    const logger = Logger.getLogger("watchface6");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 390,
          h: 450,
          src: "4.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        hmUI.createWidget(hmUI.widget.IMG_DATE, {
          day_startX: 48,
          day_startY: 178,
          day_sc_array: [
            "5.png",
            "6.png",
            "7.png",
            "8.png",
            "9.png",
            "10.png",
            "11.png",
            "12.png",
            "13.png",
            "14.png",
          ],
          day_tc_array: [
            "5.png",
            "6.png",
            "7.png",
            "8.png",
            "9.png",
            "10.png",
            "11.png",
            "12.png",
            "13.png",
            "14.png",
          ],
          day_en_array: [
            "5.png",
            "6.png",
            "7.png",
            "8.png",
            "9.png",
            "10.png",
            "11.png",
            "12.png",
            "13.png",
            "14.png",
          ],
          day_align: hmUI.align.LEFT,
          day_zero: 1,
          day_follow: 0,
          day_space: -3,
          day_is_character: false,
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        hmUI.createWidget(hmUI.widget.IMG_WEEK, {
          x: 46,
          y: 228,
          week_en: [
            "15.png",
            "16.png",
            "17.png",
            "18.png",
            "19.png",
            "20.png",
            "21.png",
          ],
          week_tc: [
            "22.png",
            "23.png",
            "24.png",
            "25.png",
            "26.png",
            "27.png",
            "28.png",
          ],
          week_sc: [
            "29.png",
            "30.png",
            "31.png",
            "32.png",
            "33.png",
            "34.png",
            "35.png",
          ],
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal$_$component_1$_$component = hmUI.createWidget(
          hmUI.widget.WATCHFACE_EDIT_GROUP,
          {
            edit_id: 1,
            x: 232,
            y: 165,
            w: 122,
            h: 122,
            select_image: "36.png",
            un_select_image: "37.png",
            default_type: hmUI.edit_type.HEART,
            optional_types: [
              {
                type: hmUI.edit_type.HEART,
                preview: "39.png",
              },
              {
                type: hmUI.edit_type.SPO2,
                preview: "40.png",
              },
              {
                type: hmUI.edit_type.UVI,
                preview: "41.png",
              },
              {
                type: hmUI.edit_type.STEP,
                preview: "42.png",
              },
              {
                type: hmUI.edit_type.BATTERY,
                preview: "43.png",
              },
              {
                type: hmUI.edit_type.CAL,
                preview: "44.png",
              },
              {
                type: hmUI.edit_type.AQI,
                preview: "45.png",
              },
              {
                type: hmUI.edit_type.PAI_WEEKLY,
                preview: "46.png",
              },
            ],
            count: 8,
            select_list: {
              title_font_size: 34,
              title_align_h: hmUI.align.CENTER_H,
              list_item_vspace: 8,
              list_tips_text_font_size: 32,
              list_tips_text_align_h: hmUI.align.LEFT,
            },
            tips_BG: "38.png",
            tips_x: -99,
            tips_y: 230,
            tips_width: 124,
            tips_margin: 0,
          }
        );
        editType = normal$_$component_1$_$component.getProperty(
          hmUI.prop.CURRENT_TYPE
        );
        switch (editType) {
          case hmUI.edit_type.STEP:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 254,
              y: 250,
              type: hmUI.data_type.STEP,
              font_array: [
                "47.png",
                "48.png",
                "49.png",
                "50.png",
                "51.png",
                "52.png",
                "53.png",
                "54.png",
                "55.png",
                "56.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 279,
              y: 186,
              src: "57.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "58.png",
              center_x: 290,
              center_y: 227,
              x: 10,
              y: 38,
              type: hmUI.data_type.STEP,
              start_angle: -120,
              end_angle: 120,
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 250,
              y: 186,
              w: 80,
              h: 80,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.BATTERY:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 269,
              y: 248,
              type: hmUI.data_type.BATTERY,
              font_array: [
                "47.png",
                "48.png",
                "49.png",
                "50.png",
                "51.png",
                "52.png",
                "53.png",
                "54.png",
                "55.png",
                "56.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 279,
              y: 186,
              src: "59.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "60.png",
              center_x: 289,
              center_y: 227,
              x: 10,
              y: 38,
              type: hmUI.data_type.BATTERY,
              start_angle: -120,
              end_angle: 120,
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 250,
              y: 186,
              w: 80,
              h: 80,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.HEART:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 268,
              y: 250,
              type: hmUI.data_type.HEART,
              font_array: [
                "47.png",
                "48.png",
                "49.png",
                "50.png",
                "51.png",
                "52.png",
                "53.png",
                "54.png",
                "55.png",
                "56.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: "61.png",
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 279,
              y: 186,
              src: "62.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "63.png",
              center_x: 289,
              center_y: 227,
              x: 10,
              y: 38,
              type: hmUI.data_type.HEART,
              start_angle: -120,
              end_angle: 120,
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 250,
              y: 186,
              w: 80,
              h: 80,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.CAL:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 261,
              y: 250,
              type: hmUI.data_type.CAL,
              font_array: [
                "47.png",
                "48.png",
                "49.png",
                "50.png",
                "51.png",
                "52.png",
                "53.png",
                "54.png",
                "55.png",
                "56.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 278,
              y: 186,
              src: "64.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "65.png",
              center_x: 290,
              center_y: 228,
              x: 10,
              y: 38,
              type: hmUI.data_type.CAL,
              start_angle: -120,
              end_angle: 120,
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 250,
              y: 186,
              w: 80,
              h: 80,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.PAI_WEEKLY:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 267,
              y: 250,
              type: hmUI.data_type.PAI_WEEKLY,
              font_array: [
                "47.png",
                "48.png",
                "49.png",
                "50.png",
                "51.png",
                "52.png",
                "53.png",
                "54.png",
                "55.png",
                "56.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 279,
              y: 186,
              src: "66.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "67.png",
              center_x: 290,
              center_y: 227,
              x: 10,
              y: 38,
              type: hmUI.data_type.PAI_WEEKLY,
              start_angle: -120,
              end_angle: 120,
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 250,
              y: 186,
              w: 80,
              h: 80,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.DISTANCE:
            break;
          case hmUI.edit_type.AQI:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 268,
              y: 250,
              type: hmUI.data_type.AQI,
              font_array: [
                "47.png",
                "48.png",
                "49.png",
                "50.png",
                "51.png",
                "52.png",
                "53.png",
                "54.png",
                "55.png",
                "56.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: "68.png",
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 279,
              y: 186,
              src: "69.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "70.png",
              center_x: 289,
              center_y: 227,
              x: 10,
              y: 38,
              type: hmUI.data_type.AQI,
              start_angle: -120,
              end_angle: 120,
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 250,
              y: 186,
              w: 80,
              h: 80,
              type: hmUI.data_type.AQI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.HUMIDITY:
            break;
          case hmUI.edit_type.ALTIMETER:
            break;
          case hmUI.edit_type.STRESS:
            break;
          case hmUI.edit_type.WIND:
            break;
          case hmUI.edit_type.SPO2:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 261,
              y: 250,
              type: hmUI.data_type.SPO2,
              font_array: [
                "47.png",
                "48.png",
                "49.png",
                "50.png",
                "51.png",
                "52.png",
                "53.png",
                "54.png",
                "55.png",
                "56.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: "72.png",
              unit_tc: "72.png",
              unit_en: "72.png",
              invalid_image: "71.png",
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 278,
              y: 186,
              src: "73.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "74.png",
              center_x: 289,
              center_y: 227,
              x: 10,
              y: 38,
              type: hmUI.data_type.SPO2,
              start_angle: -120,
              end_angle: 120,
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 250,
              y: 186,
              w: 80,
              h: 80,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.TRAINING_LOAD:
            break;
          case hmUI.edit_type.VO2MAX:
            break;
          case hmUI.edit_type.UVI:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 276,
              y: 250,
              type: hmUI.data_type.UVI,
              font_array: [
                "47.png",
                "48.png",
                "49.png",
                "50.png",
                "51.png",
                "52.png",
                "53.png",
                "54.png",
                "55.png",
                "56.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: "75.png",
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 279,
              y: 186,
              src: "76.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "77.png",
              center_x: 290,
              center_y: 227,
              x: 10,
              y: 38,
              type: hmUI.data_type.UVI,
              start_angle: -120,
              end_angle: 120,
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 250,
              y: 186,
              w: 80,
              h: 80,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.DATE:
            break;
          case hmUI.edit_type.WEEK:
            break;
          case hmUI.edit_type.WEATHER:
            break;
          case hmUI.edit_type.TEMPERATURE:
            break;
          case hmUI.edit_type.SUN:
            break;
        }
        normal$_$component_2$_$component = hmUI.createWidget(
          hmUI.widget.WATCHFACE_EDIT_GROUP,
          {
            edit_id: 2,
            x: 135,
            y: 56,
            w: 124,
            h: 124,
            select_image: "78.png",
            un_select_image: "79.png",
            default_type: hmUI.edit_type.STEP,
            optional_types: [
              {
                type: hmUI.edit_type.STEP,
                preview: "81.png",
              },
              {
                type: hmUI.edit_type.SPO2,
                preview: "82.png",
              },
              {
                type: hmUI.edit_type.UVI,
                preview: "83.png",
              },
              {
                type: hmUI.edit_type.BATTERY,
                preview: "84.png",
              },
              {
                type: hmUI.edit_type.CAL,
                preview: "85.png",
              },
              {
                type: hmUI.edit_type.HEART,
                preview: "86.png",
              },
              {
                type: hmUI.edit_type.AQI,
                preview: "87.png",
              },
              {
                type: hmUI.edit_type.PAI_WEEKLY,
                preview: "88.png",
              },
            ],
            count: 8,
            select_list: {
              title_font_size: 34,
              title_align_h: hmUI.align.CENTER_H,
              list_item_vspace: 8,
              list_tips_text_font_size: 32,
              list_tips_text_align_h: hmUI.align.LEFT,
            },
            tips_BG: "80.png",
            tips_x: -2,
            tips_y: 339,
            tips_width: 124,
            tips_margin: 0,
          }
        );
        editType = normal$_$component_2$_$component.getProperty(
          hmUI.prop.CURRENT_TYPE
        );
        switch (editType) {
          case hmUI.edit_type.STEP:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 158,
              y: 145,
              type: hmUI.data_type.STEP,
              font_array: [
                "47.png",
                "48.png",
                "49.png",
                "50.png",
                "51.png",
                "52.png",
                "53.png",
                "54.png",
                "55.png",
                "56.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 184,
              y: 78,
              src: "57.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "58.png",
              center_x: 195,
              center_y: 120,
              x: 10,
              y: 38,
              type: hmUI.data_type.STEP,
              start_angle: -120,
              end_angle: 120,
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 155,
              y: 78,
              w: 80,
              h: 80,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.BATTERY:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 172,
              y: 145,
              type: hmUI.data_type.BATTERY,
              font_array: [
                "47.png",
                "48.png",
                "49.png",
                "50.png",
                "51.png",
                "52.png",
                "53.png",
                "54.png",
                "55.png",
                "56.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 184,
              y: 78,
              src: "59.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "60.png",
              center_x: 194,
              center_y: 120,
              x: 10,
              y: 38,
              type: hmUI.data_type.BATTERY,
              start_angle: -120,
              end_angle: 120,
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 155,
              y: 78,
              w: 80,
              h: 80,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.HEART:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 172,
              y: 145,
              type: hmUI.data_type.HEART,
              font_array: [
                "47.png",
                "48.png",
                "49.png",
                "50.png",
                "51.png",
                "52.png",
                "53.png",
                "54.png",
                "55.png",
                "56.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: "89.png",
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 184,
              y: 78,
              src: "62.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "63.png",
              center_x: 194,
              center_y: 120,
              x: 10,
              y: 38,
              type: hmUI.data_type.HEART,
              start_angle: -120,
              end_angle: 120,
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 155,
              y: 78,
              w: 80,
              h: 80,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.CAL:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 165,
              y: 145,
              type: hmUI.data_type.CAL,
              font_array: [
                "47.png",
                "48.png",
                "49.png",
                "50.png",
                "51.png",
                "52.png",
                "53.png",
                "54.png",
                "55.png",
                "56.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 183,
              y: 78,
              src: "64.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "65.png",
              center_x: 195,
              center_y: 120,
              x: 10,
              y: 38,
              type: hmUI.data_type.CAL,
              start_angle: -120,
              end_angle: 120,
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 155,
              y: 78,
              w: 80,
              h: 80,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.PAI_WEEKLY:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 173,
              y: 145,
              type: hmUI.data_type.PAI_WEEKLY,
              font_array: [
                "47.png",
                "48.png",
                "49.png",
                "50.png",
                "51.png",
                "52.png",
                "53.png",
                "54.png",
                "55.png",
                "56.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 184,
              y: 78,
              src: "90.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "91.png",
              center_x: 195,
              center_y: 120,
              x: 10,
              y: 38,
              type: hmUI.data_type.PAI_WEEKLY,
              start_angle: -120,
              end_angle: 120,
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 155,
              y: 78,
              w: 80,
              h: 80,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.DISTANCE:
            break;
          case hmUI.edit_type.AQI:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 172,
              y: 145,
              type: hmUI.data_type.AQI,
              font_array: [
                "47.png",
                "48.png",
                "49.png",
                "50.png",
                "51.png",
                "52.png",
                "53.png",
                "54.png",
                "55.png",
                "56.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: "92.png",
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 184,
              y: 78,
              src: "69.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "70.png",
              center_x: 194,
              center_y: 120,
              x: 10,
              y: 38,
              type: hmUI.data_type.AQI,
              start_angle: -120,
              end_angle: 120,
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 155,
              y: 78,
              w: 80,
              h: 80,
              type: hmUI.data_type.AQI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.HUMIDITY:
            break;
          case hmUI.edit_type.ALTIMETER:
            break;
          case hmUI.edit_type.STRESS:
            break;
          case hmUI.edit_type.WIND:
            break;
          case hmUI.edit_type.SPO2:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 165,
              y: 145,
              type: hmUI.data_type.SPO2,
              font_array: [
                "47.png",
                "48.png",
                "49.png",
                "50.png",
                "51.png",
                "52.png",
                "53.png",
                "54.png",
                "55.png",
                "56.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: "94.png",
              unit_tc: "94.png",
              unit_en: "94.png",
              invalid_image: "93.png",
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 183,
              y: 78,
              src: "73.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "74.png",
              center_x: 194,
              center_y: 120,
              x: 10,
              y: 38,
              type: hmUI.data_type.SPO2,
              start_angle: -120,
              end_angle: 120,
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 155,
              y: 78,
              w: 80,
              h: 80,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.TRAINING_LOAD:
            break;
          case hmUI.edit_type.VO2MAX:
            break;
          case hmUI.edit_type.UVI:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 180,
              y: 145,
              type: hmUI.data_type.UVI,
              font_array: [
                "47.png",
                "48.png",
                "49.png",
                "50.png",
                "51.png",
                "52.png",
                "53.png",
                "54.png",
                "55.png",
                "56.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: "95.png",
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 184,
              y: 78,
              src: "76.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "77.png",
              center_x: 195,
              center_y: 120,
              x: 10,
              y: 38,
              type: hmUI.data_type.UVI,
              start_angle: -120,
              end_angle: 120,
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 155,
              y: 78,
              w: 80,
              h: 80,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.DATE:
            break;
          case hmUI.edit_type.WEEK:
            break;
          case hmUI.edit_type.WEATHER:
            break;
          case hmUI.edit_type.TEMPERATURE:
            break;
          case hmUI.edit_type.SUN:
            break;
        }
        normal$_$component_0$_$component = hmUI.createWidget(
          hmUI.widget.WATCHFACE_EDIT_GROUP,
          {
            edit_id: 3,
            x: 135,
            y: 270,
            w: 124,
            h: 124,
            select_image: "96.png",
            un_select_image: "97.png",
            default_type: hmUI.edit_type.BATTERY,
            optional_types: [
              {
                type: hmUI.edit_type.BATTERY,
                preview: "84.png",
              },
              {
                type: hmUI.edit_type.SPO2,
                preview: "82.png",
              },
              {
                type: hmUI.edit_type.UVI,
                preview: "83.png",
              },
              {
                type: hmUI.edit_type.STEP,
                preview: "81.png",
              },
              {
                type: hmUI.edit_type.CAL,
                preview: "85.png",
              },
              {
                type: hmUI.edit_type.HEART,
                preview: "86.png",
              },
              {
                type: hmUI.edit_type.AQI,
                preview: "87.png",
              },
              {
                type: hmUI.edit_type.PAI_WEEKLY,
                preview: "99.png",
              },
            ],
            count: 8,
            select_list: {
              title_font_size: 34,
              title_align_h: hmUI.align.CENTER_H,
              list_item_vspace: 8,
              list_tips_text_font_size: 32,
              list_tips_text_align_h: hmUI.align.LEFT,
            },
            tips_BG: "98.png",
            tips_x: -2,
            tips_y: 125,
            tips_width: 124,
            tips_margin: 0,
          }
        );
        editType = normal$_$component_0$_$component.getProperty(
          hmUI.prop.CURRENT_TYPE
        );
        switch (editType) {
          case hmUI.edit_type.STEP:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 158,
              y: 355,
              type: hmUI.data_type.STEP,
              font_array: [
                "47.png",
                "48.png",
                "49.png",
                "50.png",
                "51.png",
                "52.png",
                "53.png",
                "54.png",
                "55.png",
                "56.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 184,
              y: 295,
              src: "57.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "58.png",
              center_x: 195,
              center_y: 333,
              x: 10,
              y: 38,
              type: hmUI.data_type.STEP,
              start_angle: -120,
              end_angle: 120,
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 155,
              y: 291,
              w: 80,
              h: 80,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.BATTERY:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 172,
              y: 355,
              type: hmUI.data_type.BATTERY,
              font_array: [
                "47.png",
                "48.png",
                "49.png",
                "50.png",
                "51.png",
                "52.png",
                "53.png",
                "54.png",
                "55.png",
                "56.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 184,
              y: 295,
              src: "59.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "60.png",
              center_x: 194,
              center_y: 333,
              x: 10,
              y: 38,
              type: hmUI.data_type.BATTERY,
              start_angle: -120,
              end_angle: 120,
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 155,
              y: 291,
              w: 80,
              h: 80,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.HEART:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 172,
              y: 355,
              type: hmUI.data_type.HEART,
              font_array: [
                "47.png",
                "48.png",
                "49.png",
                "50.png",
                "51.png",
                "52.png",
                "53.png",
                "54.png",
                "55.png",
                "56.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: "100.png",
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 184,
              y: 295,
              src: "62.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "63.png",
              center_x: 194,
              center_y: 333,
              x: 10,
              y: 38,
              type: hmUI.data_type.HEART,
              start_angle: -120,
              end_angle: 120,
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 155,
              y: 291,
              w: 80,
              h: 80,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.CAL:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 165,
              y: 355,
              type: hmUI.data_type.CAL,
              font_array: [
                "47.png",
                "48.png",
                "49.png",
                "50.png",
                "51.png",
                "52.png",
                "53.png",
                "54.png",
                "55.png",
                "56.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 183,
              y: 295,
              src: "64.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "65.png",
              center_x: 194,
              center_y: 333,
              x: 10,
              y: 38,
              type: hmUI.data_type.CAL,
              start_angle: -120,
              end_angle: 120,
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 155,
              y: 291,
              w: 80,
              h: 80,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.PAI_WEEKLY:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 173,
              y: 355,
              type: hmUI.data_type.PAI_WEEKLY,
              font_array: [
                "47.png",
                "48.png",
                "49.png",
                "50.png",
                "51.png",
                "52.png",
                "53.png",
                "54.png",
                "55.png",
                "56.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 184,
              y: 295,
              src: "101.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "102.png",
              center_x: 195,
              center_y: 333,
              x: 10,
              y: 38,
              type: hmUI.data_type.PAI_WEEKLY,
              start_angle: -120,
              end_angle: 120,
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 155,
              y: 291,
              w: 80,
              h: 80,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.DISTANCE:
            break;
          case hmUI.edit_type.AQI:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 172,
              y: 355,
              type: hmUI.data_type.AQI,
              font_array: [
                "47.png",
                "48.png",
                "49.png",
                "50.png",
                "51.png",
                "52.png",
                "53.png",
                "54.png",
                "55.png",
                "56.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: "103.png",
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 184,
              y: 295,
              src: "69.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "70.png",
              center_x: 194,
              center_y: 333,
              x: 10,
              y: 38,
              type: hmUI.data_type.AQI,
              start_angle: -120,
              end_angle: 120,
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 155,
              y: 291,
              w: 80,
              h: 80,
              type: hmUI.data_type.AQI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.HUMIDITY:
            break;
          case hmUI.edit_type.ALTIMETER:
            break;
          case hmUI.edit_type.STRESS:
            break;
          case hmUI.edit_type.WIND:
            break;
          case hmUI.edit_type.SPO2:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 165,
              y: 355,
              type: hmUI.data_type.SPO2,
              font_array: [
                "47.png",
                "48.png",
                "49.png",
                "50.png",
                "51.png",
                "52.png",
                "53.png",
                "54.png",
                "55.png",
                "56.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: "105.png",
              unit_tc: "105.png",
              unit_en: "105.png",
              invalid_image: "104.png",
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 183,
              y: 295,
              src: "73.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "74.png",
              center_x: 194,
              center_y: 333,
              x: 10,
              y: 38,
              type: hmUI.data_type.SPO2,
              start_angle: -120,
              end_angle: 120,
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 155,
              y: 291,
              w: 80,
              h: 80,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.TRAINING_LOAD:
            break;
          case hmUI.edit_type.VO2MAX:
            break;
          case hmUI.edit_type.UVI:
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 180,
              y: 355,
              type: hmUI.data_type.UVI,
              font_array: [
                "47.png",
                "48.png",
                "49.png",
                "50.png",
                "51.png",
                "52.png",
                "53.png",
                "54.png",
                "55.png",
                "56.png",
              ],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: "106.png",
              padding: false,
              isCharacter: false,
            });
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 184,
              y: 295,
              src: "76.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: "77.png",
              center_x: 195,
              center_y: 333,
              x: 10,
              y: 38,
              type: hmUI.data_type.UVI,
              start_angle: 480,
              end_angle: 120,
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 155,
              y: 291,
              w: 80,
              h: 80,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.DATE:
            break;
          case hmUI.edit_type.WEEK:
            break;
          case hmUI.edit_type.WEATHER:
            break;
          case hmUI.edit_type.TEMPERATURE:
            break;
          case hmUI.edit_type.SUN:
            break;
        }
        hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK, {
          x: 0,
          y: 0,
          w: 390,
          h: 450,
          src: "107.png",
          show_level: hmUI.show_level.ONLY_EDIT,
        });
        hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_centerX: 195,
          hour_centerY: 225,
          hour_posX: 27,
          hour_posY: 120,
          hour_path: "108.png",
          hour_cover_x: 0,
          hour_cover_y: 0,
          minute_centerX: 195,
          minute_centerY: 225,
          minute_posX: 33,
          minute_posY: 163,
          minute_path: "109.png",
          minute_cover_x: 0,
          minute_cover_y: 0,
          second_centerX: 195,
          second_centerY: 225,
          second_posX: 13,
          second_posY: 182,
          second_path: "111.png",
          second_cover_path: "110.png",
          second_cover_x: 183,
          second_cover_y: 213,
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
          x: 0,
          y: 0,
          w: 390,
          h: 450,
          src: "112.png",
          show_level: hmUI.show_level.ONLY_EDIT,
        });
        hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_centerX: 195,
          hour_centerY: 225,
          hour_posX: 14,
          hour_posY: 109,
          hour_path: "113.png",
          hour_cover_x: 0,
          hour_cover_y: 0,
          minute_centerX: 195,
          minute_centerY: 225,
          minute_posX: 17,
          minute_posY: 153,
          minute_path: "114.png",
          minute_cover_x: 183,
          minute_cover_y: 213,
          enable: false,
          show_level: hmUI.show_level.ONLY_AOD,
        });
      },
      onInit() {
        logger.log("index page.js on init invoke");
      },
      build() {
        this.init_view();
        logger.log("index page.js on ready invoke");
      },
      onDestroy() {
        logger.log("index page.js on destroy invoke");
      },
    });
  })();
} catch (e) {
  console.log("Mini Program Error", e);
  e &&
    e.stack &&
    e.stack.split(/\n/).forEach((i) => console.log("error stack", i));
}
