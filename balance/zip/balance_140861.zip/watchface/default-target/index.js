try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_56f97d5f35ec46dd96a0ee5d5c86c777 = '';
        let dateFormat = '';
        let dateFormatMap = '';
        let normal$_$text_3e6a19a46f2440c2ab0bd62048b1d1a3 = '';
        let normal$_$text_1558ebd26c484778b8a24902ddb072fc = '';
        let normal$_$text_177a288f12d5417589d5e34c4ab7a098 = '';
        let timeSensor = '';
        let stepSensor = '';
        let heartSensor = '';
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
                    edit_id: 1,
                    x: 0,
                    y: 0,
                    bg_config: [
                        {
                            'id': 1,
                            'path': '4.png',
                            'preview': '5.png'
                        },
                        {
                            'id': 2,
                            'path': '6.png',
                            'preview': '7.png'
                        }
                    ],
                    count: 2,
                    default_id: 1,
                    fg: '3.png',
                    tips_x: 0,
                    tips_y: 0,
                    tips_bg: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                });
                hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 240,
                    center_y: 240,
                    radius: 230,
                    start_angle: 0,
                    end_angle: 360,
                    color: 4294808075,
                    line_width: 16,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    src: '8.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 2,
                    y: 2,
                    src: '9.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 185,
                    y: 176,
                    src: '10.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 224,
                    y: 147,
                    src: '11.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 260,
                    y: 432,
                    src: '12.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 156,
                    y: 424,
                    src: '13.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 232,
                    y: 446,
                    image_array: [
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png'
                    ],
                    image_length: 10,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 175,
                    y: 225,
                    src: '24.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 203,
                    y: 76,
                    src: '25.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_56f97d5f35ec46dd96a0ee5d5c86c777 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 392,
                    y: 217,
                    w: 57,
                    h: 45,
                    text: '[DAY_Z]',
                    color: '0xFFf5f5f5',
                    text_size: 37,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 164,
                    y: 377,
                    src: '26.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 197,
                    y: 386,
                    type: hmUI.data_type.DISTANCE,
                    font_array: [
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 1,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '39.png',
                    unit_tc: '39.png',
                    unit_en: '39.png',
                    imperial_unit_sc: '40.png',
                    imperial_unit_tc: '40.png',
                    imperial_unit_en: '40.png',
                    dot_image: '38.png',
                    invalid_image: '37.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 168,
                    y: 382,
                    src: '41.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_3e6a19a46f2440c2ab0bd62048b1d1a3 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 306,
                    y: 219,
                    w: 84,
                    h: 40,
                    text: '[WEEK_EN_S]',
                    color: '0xFFf5f5f5',
                    text_size: 37,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_1558ebd26c484778b8a24902ddb072fc = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 36,
                    y: 219,
                    w: 133,
                    h: 40,
                    text: '[SC]',
                    color: '0xFFf5f5f5',
                    text_size: 37,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_177a288f12d5417589d5e34c4ab7a098 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 204,
                    y: 79,
                    w: 72,
                    h: 40,
                    text: '[HR]',
                    color: '0xFFffffff',
                    text_size: 34,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 240,
                    hour_centerY: 240,
                    hour_posX: 36,
                    hour_posY: 162,
                    hour_path: '42.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 240,
                    minute_centerY: 240,
                    minute_posX: 36,
                    minute_posY: 235,
                    minute_path: '43.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    second_centerX: 240,
                    second_centerY: 240,
                    second_posX: 25,
                    second_posY: 227,
                    second_path: '44.png',
                    second_cover_x: 0,
                    second_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '45.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: '46.png',
                    center_x: 240,
                    center_y: 240,
                    x: 40,
                    y: 234,
                    type: hmUI.data_type.STEP,
                    start_angle: 0,
                    end_angle: 360,
                    cover_x: 0,
                    cover_y: 0,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 229,
                    y: 431,
                    image_array: [
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png',
                        '54.png',
                        '55.png',
                        '56.png'
                    ],
                    image_length: 10,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 240,
                    hour_centerY: 240,
                    hour_posX: 19,
                    hour_posY: 132,
                    hour_path: '57.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 240,
                    minute_centerY: 240,
                    minute_posX: 18,
                    minute_posY: 209,
                    minute_path: '58.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                if (!timeSensor) {
                    timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                }
                if (!stepSensor) {
                    stepSensor = hmSensor.createSensor(hmSensor.id.STEP);
                }
                if (!heartSensor) {
                    heartSensor = hmSensor.createSensor(hmSensor.id.HEART);
                }
                timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_56f97d5f35ec46dd96a0ee5d5c86c777.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }` });
                        },
                        () => {
                            normal$_$text_56f97d5f35ec46dd96a0ee5d5c86c777.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }` });
                        },
                        () => {
                            normal$_$text_56f97d5f35ec46dd96a0ee5d5c86c777.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                    const WEEK_EN_S = function (val) {
                        const valueMap = {
                            '1': 'Mon',
                            '2': 'Tue',
                            '3': 'Wed',
                            '4': 'Thu',
                            '5': 'Fri',
                            '6': 'Sat',
                            '7': 'Sun'
                        };
                        return valueMap[val];
                    };
                    normal$_$text_3e6a19a46f2440c2ab0bd62048b1d1a3.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_S(timeSensor.week) }` });
                }), stepSensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_1558ebd26c484778b8a24902ddb072fc.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                }), heartSensor.addEventListener(heartSensor.event.LAST, function () {
                    normal$_$text_177a288f12d5417589d5e34c4ab7a098.setProperty(hmUI.prop.MORE, { text: `${ heartSensor.last }` });
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 37,
                    y: 190,
                    w: 132,
                    h: 100,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 190,
                    y: 431,
                    w: 100,
                    h: 46,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 190,
                    y: 54,
                    w: 100,
                    h: 100,
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 166,
                    y: 367,
                    w: 148,
                    h: 45,
                    type: hmUI.data_type.DISTANCE,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                normal$_$text_56f97d5f35ec46dd96a0ee5d5c86c777.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }` });
                            },
                            () => {
                                normal$_$text_56f97d5f35ec46dd96a0ee5d5c86c777.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }` });
                            },
                            () => {
                                normal$_$text_56f97d5f35ec46dd96a0ee5d5c86c777.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                        const WEEK_EN_S = function (val) {
                            const valueMap = {
                                '1': 'Mon',
                                '2': 'Tue',
                                '3': 'Wed',
                                '4': 'Thu',
                                '5': 'Fri',
                                '6': 'Sat',
                                '7': 'Sun'
                            };
                            return valueMap[val];
                        };
                        normal$_$text_3e6a19a46f2440c2ab0bd62048b1d1a3.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_S(timeSensor.week) }` });
                        normal$_$text_1558ebd26c484778b8a24902ddb072fc.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                        normal$_$text_177a288f12d5417589d5e34c4ab7a098.setProperty(hmUI.prop.MORE, { text: `${ heartSensor.last }` });
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}