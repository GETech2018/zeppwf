import os
from PIL import Image

def resize_images_in_folder(folder_path, scale_factor=480/466):
    """
    Resize all PNG images in the given folder by the specified scale factor.

    :param folder_path: Path to the folder containing PNG images.
    :param scale_factor: The factor by which to resize the images (e.g., 1.03 for 3% increase).
    """
    # Ensure the folder exists
    if not os.path.isdir(folder_path):
        print(f"The folder '{folder_path}' does not exist.")
        return

    # Create an output directory
    output_folder = os.path.join(folder_path, "resized")
    os.makedirs(output_folder, exist_ok=True)

    # Process each PNG image in the folder
    for file_name in os.listdir(folder_path):
        if file_name.lower().endswith(".png"):
            input_path = os.path.join(folder_path, file_name)
            output_path = os.path.join(output_folder, file_name)

            try:
                # Open the image
                with Image.open(input_path) as img:
                    # Calculate new dimensions
                    new_width = int(img.width * scale_factor)
                    new_height = int(img.height * scale_factor)

                    # Resize with high quality
                    resized_img = img.resize((new_width, new_height), Image.Resampling.LANCZOS)

                    # Save the resized image to the output directory
                    resized_img.save(output_path, format="PNG")

                    print(f"Resized '{file_name}' and saved to '{output_path}'.")
            except Exception as e:
                print(f"Failed to process '{file_name}': {e}")

if __name__ == "__main__":
    # Use the current directory as the folder path
    folder_path = os.path.dirname(os.path.abspath(__file__))
    resize_images_in_folder(folder_path)