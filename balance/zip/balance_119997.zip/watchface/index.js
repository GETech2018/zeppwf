try {
  (() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__),
      "drink"
    );

    /*
     * huamiOS bundle tool v1.0.17
     * Copyright © Huami. All Rights Reserved
     */
    ("use strict");

    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let rootPath = null;
    let ambPath = null;
    let bgPath = null;
    let batPath = null;
    let dayPath = null;
    let heartPath = null;
    let weekPath = null;
    let uviPath = null;
    let humidityPath = null;
    let paiPath = null;
    let powerPath = null;
    let kcalPath = null;
    let moonPath = null;
    let statusPath = null;
    let stepsPath = null;
    let steps_leavePath = null;
    let sunPath = null;
    let timePath = null;
    let time_mPath = null;

    let bat_array = null;
    let day_array = null;
    let heart_array = null;
    let humidity_array = null;
    let kcal_array = null;
    let moon_array = null;
    let pai_arrary = null;
    let power_array = null;
    let steps_array = null;
    let steps_leave_array = null;
    let sun_array = null;
    let time_h_array = null;
    let time_m_array = null;
    let uvi_array = null;
    let week_array = null;

    const logger = DeviceRuntimeCore.HmLogger.getLogger("defult");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        rootPath = "images/";
        ambPath = rootPath + "amb/";
        bgPath = rootPath + "bg/";
        batPath = rootPath + "bat/";
        dayPath = rootPath + "day/";
        heartPath = rootPath + "heart/";
        weekPath = rootPath + "week/";
        uviPath = rootPath + "uvi/";
        humidityPath = rootPath + "humidity/";
        paiPath = rootPath + "pai/";
        powerPath = rootPath + "power/";
        kcalPath = rootPath + "kcal/";
        moonPath = rootPath + "moon/";
        statusPath = rootPath + "status/";
        stepsPath = rootPath + "steps/";
        steps_leavePath = stepsPath + "leave/";
        sunPath = rootPath + "sun/";
        timePath = rootPath + "time/";
        time_mPath = timePath + "m/";

        bat_array = [
          batPath + "1.png",
          batPath + "2.png",
          batPath + "3.png",
          batPath + "4.png",
          batPath + "5.png",
          batPath + "6.png",
        ];

        day_array = [
          dayPath + "0.png",
          dayPath + "1.png",
          dayPath + "2.png",
          dayPath + "3.png",
          dayPath + "4.png",
          dayPath + "5.png",
          dayPath + "6.png",
          dayPath + "7.png",
          dayPath + "8.png",
          dayPath + "9.png",
        ];

        heart_array = [
          heartPath + "0.png",
          heartPath + "1.png",
          heartPath + "2.png",
          heartPath + "3.png",
          heartPath + "4.png",
          heartPath + "5.png",
          heartPath + "6.png",
          heartPath + "7.png",
          heartPath + "8.png",
          heartPath + "9.png",
        ];

        humidity_array = [
          humidityPath + "0.png",
          humidityPath + "1.png",
          humidityPath + "2.png",
          humidityPath + "3.png",
          humidityPath + "4.png",
          humidityPath + "5.png",
          humidityPath + "6.png",
          humidityPath + "7.png",
          humidityPath + "8.png",
          humidityPath + "9.png",
        ];

        kcal_array = [
          kcalPath + "0.png",
          kcalPath + "1.png",
          kcalPath + "2.png",
          kcalPath + "3.png",
          kcalPath + "4.png",
          kcalPath + "5.png",
          kcalPath + "6.png",
          kcalPath + "7.png",
          kcalPath + "8.png",
          kcalPath + "9.png",
        ];

        // moon_array = [
        //   moonPath + "1.png",
        //   moonPath + "2.png",
        //   moonPath + "3.png",
        //   moonPath + "4.png",
        //   moonPath + "5.png",
        //   moonPath + "6.png",
        //   moonPath + "7.png",
        // ]

        moon_array = [
          moonPath + "1.png",
          moonPath + "2.png",
          moonPath + "3.png",
          moonPath + "4.png",
          moonPath + "5.png",
          moonPath + "6.png",
          moonPath + "7.png",
          moonPath + "8.png",
          moonPath + "9.png",
          moonPath + "10.png",
          moonPath + "11.png",
          moonPath + "12.png",
          moonPath + "13.png",
          moonPath + "14.png",
          moonPath + "15.png",
          moonPath + "16.png",
          moonPath + "17.png",
          moonPath + "18.png",
          moonPath + "19.png",
          moonPath + "20.png",
          moonPath + "21.png",
          moonPath + "22.png",
          moonPath + "23.png",
          moonPath + "24.png",
          moonPath + "25.png",
          moonPath + "26.png",
          moonPath + "27.png",
          moonPath + "28.png",
          moonPath + "29.png",
          moonPath + "30.png",
        ];
        pai_array = [
          paiPath + "0.png",
          paiPath + "1.png",
          paiPath + "2.png",
          paiPath + "3.png",
          paiPath + "4.png",
          paiPath + "5.png",
          paiPath + "6.png",
          paiPath + "7.png",
          paiPath + "8.png",
          paiPath + "9.png",
        ];

        power_array = [
          powerPath + "0.png",
          powerPath + "1.png",
          powerPath + "2.png",
          powerPath + "3.png",
          powerPath + "4.png",
          powerPath + "5.png",
          powerPath + "6.png",
          powerPath + "7.png",
          powerPath + "8.png",
          powerPath + "9.png",
        ];

        steps_array = [
          stepsPath + "0.png",
          stepsPath + "1.png",
          stepsPath + "2.png",
          stepsPath + "3.png",
          stepsPath + "4.png",
          stepsPath + "5.png",
          stepsPath + "6.png",
          stepsPath + "7.png",
          stepsPath + "8.png",
          stepsPath + "9.png",
        ];

        steps_leave_array = [
          steps_leavePath + "0.png",
          steps_leavePath + "1.png",
          steps_leavePath + "2.png",
          steps_leavePath + "3.png",
          steps_leavePath + "4.png",
          steps_leavePath + "5.png",
          steps_leavePath + "6.png",
          steps_leavePath + "7.png",
          steps_leavePath + "8.png",
          steps_leavePath + "9.png",
        ];

        sun_array = [
          sunPath + "0.png",
          sunPath + "1.png",
          sunPath + "2.png",
          sunPath + "3.png",
          sunPath + "4.png",
          sunPath + "5.png",
          sunPath + "6.png",
          sunPath + "7.png",
          sunPath + "8.png",
          sunPath + "9.png",
        ];

        time_h_array = [
          timePath + "0.png",
          timePath + "1.png",
          timePath + "2.png",
          timePath + "3.png",
          timePath + "4.png",
          timePath + "5.png",
          timePath + "6.png",
          timePath + "7.png",
          timePath + "8.png",
          timePath + "9.png",
        ];

        time_m_array = [
          time_mPath + "0.png",
          time_mPath + "1.png",
          time_mPath + "2.png",
          time_mPath + "3.png",
          time_mPath + "4.png",
          time_mPath + "5.png",
          time_mPath + "6.png",
          time_mPath + "7.png",
          time_mPath + "8.png",
          time_mPath + "9.png",
        ];

        uvi_array = [
          uviPath + "1.png",
          uviPath + "2.png",
          uviPath + "3.png",
          uviPath + "4.png",
          uviPath + "5.png",
        ];

        week_array = [
          weekPath + "1.png",
          weekPath + "2.png",
          weekPath + "3.png",
          weekPath + "4.png",
          weekPath + "5.png",
          weekPath + "6.png",
          weekPath + "7.png",
        ];

        let bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 480,
          h: 480,
          src: bgPath + "bg.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let paiLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 28,
          y: 60,
          image_array: pai_array,
          image_length: pai_array.length, //长度
          type: hmUI.data_type.PAI_WEEKLY,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let humidityLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 145,
          y: 23,
          image_array: humidity_array,
          image_length: humidity_array.length, //长度
          type: hmUI.data_type.HUMIDITY,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // let batLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
        //   x: 348,
        //   y: 60,
        //   image_array: bat_array,
        //   image_length: bat_array.length,//长度
        //   type: hmUI.data_type.AQI,
        //   show_level: hmUI.show_level.ONLY_NORMAL
        // });
        let batLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 348,
          y: 60,
          image_array: bat_array,
          image_length: bat_array.length, //长度
          type: hmUI.data_type.BATTERY,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let uviLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 348,
          y: 244,
          image_array: uvi_array,
          image_length: uvi_array.length, //长度
          type: hmUI.data_type.UVI,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let stepsLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 145 + 1,
          y: 410,
          image_array: steps_leave_array,
          image_length: steps_leave_array.length, //长度
          type: hmUI.data_type.STEP,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let calLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 28.7,
          y: 244.5,
          image_array: kcal_array,
          image_length: kcal_array.length, //长度
          type: hmUI.data_type.CAL,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let moonLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 373,
          y: 199,
          image_array: moon_array,
          image_length: moon_array.length, //长度
          type: hmUI.data_type.MOON,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let weekText = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
          x: 180,
          y: 72,
          week_en: week_array,
          week_tc: week_array,
          week_sc: week_array,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let heartText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          // x: 273,
          // y: 167,
          x: 273,
          y: 283,
          type: hmUI.data_type.HEART,
          font_array: heart_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NORMAL,
          invalid_image: heartPath + "null.png",
          // padding: true
        });

        let stepText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 193,
          y: 388,
          type: hmUI.data_type.STEP,
          font_array: heart_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NORMAL,

          // padding: true
        });

        let batteryText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 273,
          y: 167,
          // x: 273,
          // y: 283,
          type: hmUI.data_type.BATTERY,
          font_array: heart_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NORMAL,
          // invalid_image: heartPath + "null.png",
          // padding: true
        });

        let sun_RISEText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 251,
          y: 349,
          type: hmUI.data_type.SUN_RISE,
          font_array: sun_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          dot_image: sunPath + "maohao.png",
          invalid_image: sunPath + "null.png",
          isCharater: true,
          padding: true,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let sun_SETText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 159,
          y: 349,
          type: hmUI.data_type.SUN_SET,
          font_array: sun_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          dot_image: sunPath + "maohao.png",
          invalid_image: sunPath + "null.png",
          isCharater: true,
          padding: true,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let disturbStatus = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
          x: 383,
          y: 261,
          type: hmUI.system_status.DISTURB,
          src: statusPath + "disturb.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let lockStatus = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
          x: 354,
          y: 114,
          type: hmUI.system_status.LOCK,

          src: statusPath + "lock.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let disconnectStatus = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
          x: 364,
          y: 304,
          type: hmUI.system_status.DISCONNECT,
          src: statusPath + "disconnect.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
          // hmUI.system_status.DISCONNECT
        });

        let clockStatus = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
          x: 376,
          y: 157,
          type: hmUI.system_status.CLOCK,
          src: statusPath + "clock.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          hour_zero: 1, //是否补零
          hour_startX: 88,
          hour_startY: 118,
          hour_array: time_h_array,
          hour_space: 0, //每个数组间的间隔

          minute_zero: 1, //是否补零
          minute_startX: 88,
          minute_startY: 222,
          minute_array: time_m_array,
          minute_space: 0, //每个数组间的间隔

          am_x: 52,
          am_y: 227,
          am_sc_path: timePath + "AM.png",
          am_en_path: timePath + "AM.png",
          pm_x: 52,
          pm_y: 227,
          pm_sc_path: timePath + "PM.png",
          pm_en_path: timePath + "PM.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let dayText = hmUI.createWidget(hmUI.widget.IMG_DATE, {
          day_startX: 258,
          day_startY: 72,
          day_align: hmUI.align.LEFT,
          day_space: -2, //文字间隔
          day_zero: 1, //是否补零
          day_en_array: day_array,
          day_sc_array: day_array,
          day_tc_array: day_array,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let AOD_timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          hour_zero: 1, //是否补零
          hour_startX: 166,
          hour_startY: 118,
          hour_array: time_h_array,
          hour_space: 0, //每个数组间的间隔

          minute_zero: 1, //是否补零
          minute_startX: 166,
          minute_startY: 222,
          minute_array: time_m_array,
          minute_space: 0, //每个数组间的间隔\
          show_level: hmUI.show_level.ONAL_AOD,
        });
        hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 180,
          y: 0,
          w: 133,
          h: 49,
          type: hmUI.data_type.HUMIDITY,
        });
        hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 8,
          y: 95,
          w: 72,
          h: 73,
          type: hmUI.data_type.PAI_WEEKLY,
        });
        hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 16,
          y: 307,
          w: 61,
          h: 91,
          type: hmUI.data_type.CAL,
        });
        hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 260,
          y: 240,
          w: 85,
          h: 85,
          type: hmUI.data_type.HEART,
        });
        hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 369,
          y: 150,
          w: 42,
          h: 43,
          type: hmUI.data_type.ALARM_CLOCK,
        });
        hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 369,
          y: 197,
          w: 58,
          h: 59,
          type: hmUI.data_type.MOON,
        });
        hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 118,
          y: 341,
          w: 121,
          h: 30,
          type: hmUI.data_type.SUN_RISE,
        });
        hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 248,
          y: 341,
          w: 121,
          h: 30,
          type: hmUI.data_type.SUN_RISE,
        });
        hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 401,
          y: 303,
          w: 72,
          h: 91,
          type: hmUI.data_type.UVI,
        });
        hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 197,
          y: 384,
          w: 89,
          h: 97,
          type: hmUI.data_type.STEP,
        });
      },

      onInit() {
        console.log("index page.js on init invoke");

        this.init_view();
      },

      onReady() {
        console.log("index page.js on ready invoke");
      },

      onShow() {
        console.log("index page.js on show invoke");
      },

      onHide() {
        console.log("index page.js on hide invoke");
      },

      onDestory() {
        console.log("index page.js on destory invoke");
      },
    });
    /*
     * end js
     */
  })();
} catch (e) {
  console.log(e);
}
