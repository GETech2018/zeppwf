try {
  (() => {

    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

/*
* huamiOS bundle tool v1.0.17
* Copyright © Huami. All Rights Reserved
*/
    'use strict';

    console.log("----->>>current")
    console.log(__$$hmAppManager$$__.currentApp.pid)
    console.log(__$$hmAppManager$$__.currentApp.current)
    /*params声明*/

    let strRootPath = "images/"
    let nX = 0
    let nY = 0
    let nW = 466
    let nH = 466
    let pageX = 233;
    let pageY = 233;
    let arrFont = []
    let arrFonts = []
    let arrWeather = []
    let arrMonthEn = []
    let arrMonthSc = []

    let objBg = {
      x: nX,
      y: nY,
      w: nW,
      h: nH,
      src: strRootPath + "bg.png",
      show_level: hmUI.show_level.ONLY_NORMAL,
    }
    let objMonth = {
      month_startX:203,
      month_startY:367,
      month_align:hmUI.align.CENTER_H,
      month_en_array: arrMonthEn,
      month_sc_array: arrMonthSc,
      month_tc_array: arrMonthSc,
      month_is_character:true,
      day_startX:215,
      day_startY:332,
      day_align:hmUI.align.CENTER_H,
      day_zero:1,
      day_en_array: arrFont,
      day_sc_array: arrFont,
      day_tc_array: arrFont,
      show_level: hmUI.show_level.ONLY_NORMAL,
    }
    let objPointer = {
      hour_centerX: pageX,
      hour_centerY: pageY,
      hour_posX: 34,
      hour_posY: 131,
      hour_path: strRootPath + "pointer/hour.png",
      minute_centerX: pageX + 1,
      minute_centerY: pageY,
      minute_posX: 32,
      minute_posY: 202,
      minute_path: strRootPath + "pointer/minute.png",
      second_centerX: pageX,
      second_centerY: pageY,
      second_posX: 29,
      second_posY: 230,
      second_path: strRootPath + "pointer/second.png",
      show_level: hmUI.show_level.ONLY_NORMAL
    };
    let objAodPointer = {
      hour_centerX: pageX,
      hour_centerY: pageY,
      hour_posX: 36,
      hour_posY: 131,
      hour_path: strRootPath + "pointer/aod_hour.png",
      minute_centerX: pageX,
      minute_centerY: pageY,
      minute_posX: 32,
      minute_posY: 202,
      minute_path: strRootPath + "pointer/aod_minute.png",
      show_level: hmUI.show_level.ONLY_AOD
    }

    /*遍历数组*/
    for(i = 0; i < 29; i++){
      if(i < 10){
        arrFont.push(strRootPath+"font/"+i+".png")
        arrFonts.push(strRootPath+"step_font/"+i+".png")
      }
      if(i < 13 && i > 0){
        arrMonthEn.push(strRootPath + "month/en/"+i+".png" )
        arrMonthSc.push(strRootPath + "month/sc/"+i+".png" )
      }
      arrWeather.push(strRootPath+"weather/"+i+".png")
    }

    const logger = DeviceRuntimeCore.HmLogger.getLogger("xiping");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({

      /* 获取数值--电量/湿度/步数/卡路里/天气温度/PAI/心率 */
      getFont(options) {
        let objConfig = {
          x: 0,
          y: 0,
          w: 0,
          type: "",
          font_array: arrFont,
          h_space: 0,
          align_h: hmUI.align.LIFT,
          unit_sc: "",
          unit_en: "",
          invalid_image: "",
          dot_image:"",
          padding: !1,
          negative_image: "",
          show_level: hmUI.show_level.ONLY_NORMAL
        }
        for (let key in options) {
          if (key in objConfig) {
            objConfig[key] = options[key]
          }
        }
        for (let key in objConfig) {
          if (!objConfig[key]) {
            delete objConfig[key]
          }
        }
        let text = hmUI.createWidget(hmUI.widget.TEXT_IMG, objConfig)
      },
      /* 获取进度--电量/湿度/步数/卡路里 */
      getLevel(options) {
        let { x, y, arr, type } = options
        let progress = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: x,
          y: y,
          image_array: arr,
          image_length: arr.length, //长度
          type: type,
          show_level: hmUI.show_level.ONLY_NORMAL
        })
      },
      /* 获取数据指针 */
      getDataPointet(options){
        let { x, y, type } = options
        let pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
          src: strRootPath + "pointer/data.png",
          center_x: x,
          center_y: y,
          x: 20,
          y: 63,
          type:type,
          invalid_visible:true,
          start_angle: -125,
          end_angle: 125,
          show_level: hmUI.show_level.ONLY_NORMAL
        })
      },
      /* 点击事件 */
      changeClick(options){
        let { x, y, w, h, type} = options
        let click = hmUI.createWidget(hmUI.widget.IMG_CLICK,{
          x: x,
          y: y,
          w: w,
          h: h,
          type: type,
        })
      },
      init_view() {
        /* --数据控件-- */

        /* 正常背景 */
        let bg = hmUI.createWidget(hmUI.widget.IMG, objBg)

        /* cal */
        this.getFont({ x: 215, y: 88, w: 70, type: hmUI.data_type.CAL,align_h: hmUI.align.RIGHT})

        /* PAI */
        this.getFont({ x: 92, y: 359, w: 60, type: hmUI.data_type.PAI_WEEKLY,align_h: hmUI.align.CENTER_H})

        /* UVI */
        this.getFont({ x: 313, y: 359, w: 60, type: hmUI.data_type.UVI,align_h: hmUI.align.CENTER_H, invalid_image:strRootPath +"font/null.png"})

        /* HEART */
        this.getFont({ x: 215, y: 122, w: 70, type: hmUI.data_type.HEART, align_h: hmUI.align.RIGHT, invalid_image:strRootPath +"font/null.png"})

        /* step */
        this.getFont({ x: 296, y: 260, w: 90, type: hmUI.data_type.STEP, font_array: arrFonts, align_h: hmUI.align.CENTER_H})

        /* bat */
        this.getFont({ x: 90, y: 260, w: 80, type: hmUI.data_type.BATTERY, font_array: arrFonts, align_h: hmUI.align.CENTER_H,
          unit_sc: strRootPath +"font/baifen.png",
          unit_en: strRootPath +"font/baifen.png",
          unit_tc: strRootPath +"font/baifen.png",
        })

        /* 天气icon */
        this.getLevel({ x: 99,y: 89, arr: arrWeather, type: hmUI.data_type.WEATHER_CURRENT})

        /* 温度 */
        this.getFont({ x: 310, y: 102, w: 70, font_array: arrFont, type: hmUI.data_type.WEATHER_CURRENT,align_h: hmUI.align.CENTER_H,
          h_space: -1,
          unit_sc: strRootPath +"font/du.png",
          unit_en: strRootPath +"font/du.png",
          unit_tc: strRootPath +"font/du.png",
          negative_image:strRootPath +"font/negative.png",
          invalid_image:strRootPath +"font/null.png"})

        /* 月份 */
        let Month = hmUI.createWidget(hmUI.widget.IMG_DATE, objMonth);

        /* step数据指针 */
        this.getDataPointet({ x: 340, y: 233, type: hmUI.data_type.STEP});

        /* bat数据指针 */
        this.getDataPointet({ x: 128, y: 233, type: hmUI.data_type.BATTERY});

        /* 亮屏时间指针 */
        let timePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, objPointer);

        /* 亮屏时间指针 */
        let timeAodPointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, objAodPointer);

        /* --热区跳转-- */

        /* 天气icon jump */
        this.changeClick({x: 99, y:89, w:50, h:40, type:hmUI.data_type.WEATHER_CURRENT})

        /* 天气数值jump */
        this.changeClick({ x: 325, y:89, w:45, h:35, type:hmUI.data_type.WEATHER_CURRENT})

        /* cal数值jump */
        this.changeClick({  x: 185, y: 80, w: 100, h:25, type:hmUI.data_type.CAL})

        /* heart数值jump */
        this.changeClick({ x: 180, y: 115, w: 110, h:25, type:hmUI.data_type.HEART})

        /* Bat数值jump */
        this.changeClick({ x: 80, y: 185, w: 90, h: 90, type:hmUI.data_type.BATTERY})

        /* Step数值jump */
        this.changeClick({ x: 295, y: 185, w: 90, h: 90, type:hmUI.data_type.STEP})

        /* Pai数值jump */
        this.changeClick({ x: 95, y: 335, w: 50, h: 40, type:hmUI.data_type.PAI_WEEKLY})

        /* Uvi数值jump */
        this.changeClick({ x: 317, y: 335, w: 50, h: 40, type:hmUI.data_type.UVI})

      },

      onInit() {
        console.log('index page.js on init invoke')
        this.init_view();
      },

      onReady() {
        console.log('index page.js on ready invoke')
      },

      onShow() {
        console.log('index page.js on show invoke')
      },

      onHide() {
        console.log('index page.js on hide invoke')
      },

      onDestory() {
        console.log('index page.js on destory invoke')
      },
    });
    /*
    * end js
    */
  })()
} catch (e) {
  console.log(e)
}
