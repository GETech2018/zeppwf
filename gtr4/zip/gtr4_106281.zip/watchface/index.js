try {
  ;(() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp

    var __$$module$$__ = __$$app$$__.current
    var h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__),
      'drink'
    )

    /*
     * huamiOS bundle tool v1.0.17
     * Copyright © Huami. All Rights Reserved
     */
    ;('use strict')

    console.log('----->>>current')
    console.log(__$$hmAppManager$$__.currentApp.pid)
    console.log(__$$hmAppManager$$__.currentApp.current)

    let config = null

    let rootPath = 'images/'
    let bgPath = rootPath + 'BG/'
    let weather_imgPath = rootPath + 'weather/'
    let calorie_imgPath = rootPath + 'yellow/calorie/'
    let yellowPath = rootPath + 'yellow/'
    let hourPath = rootPath + 'time/'
    let timePath = rootPath + 'date/'
    let timePath1 = rootPath + 'date1/'
    let widgetPreview = rootPath + 'preview/'
    let week_enPath = rootPath + 'week/en/'
    let week_scPath = rootPath + 'week/sc/'
    let week1_enPath = rootPath + 'week1/en/'
    let week1_scPath = rootPath + 'week1/sc/'
    let numPath = rootPath + 'motion/'
    let greenPath = rootPath + 'green/'
    let greenAqiPath = rootPath + 'green/aqi/'
    let bluePath = rootPath + 'blue/'
    let bluePaiPath = rootPath + 'blue/pai/'
    let pink_numPath = rootPath + 'pink/num/'
    let pinkPath = rootPath + 'pink/'
    let blue = bluePath + 'bg.png'
    let yellow = calorie_imgPath + '11.png'
    let pink = pinkPath + 'bg.png'
    let green = greenAqiPath + 'bg.png'
    let violetPath = rootPath + 'violet/'
    let uviPath = violetPath + 'uvi/'
    let violet = uviPath + '6.png'
    let restPath = rootPath + 'time1/'

    let weather_img_array = []
    let calorie_array = []
    let yellow_num_array = []
    let hour_array = []
    let timeArray = []
    let timeArray1 = []
    let week_en_array = []
    let week_sc_array = []
    let num_array = []
    let aqi_num_array = []
    let pai_array = []
    let aqi_array = []
    let pai_num_array = []
    let pink_num_array = []
    let pink_array = []
    let violet_array = []
    let violet_num_array = []
    let time_array1 = []
    let week1_en_array = []
    let week1_sc_array = []

    const num_time_h_x = 230
    const num_time_m_x = 350
    const num_time_common_y = 196
    const num_am_pm_y = 101
    const num_am_pm_x = 294
    const num_week_x = 341
    const num_week_y = 160
    const num_date_x = 296
    const num_icon_x = 298
    const num_tips_w = 109

    const logger = DeviceRuntimeCore.HmLogger.getLogger('defult')
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        for (let k = 0; k < 29; k++) {
          weather_img_array.push(weather_imgPath + k + '.png')
        }

        for (let j = 1; j < 11; j++) {
          calorie_array.push(calorie_imgPath + j + '.png')
          pai_array.push(bluePaiPath + j + '.png')
        }

        for (let i = 0; i < 10; i++) {
          yellow_num_array.push(yellowPath + i + '.png')
          hour_array.push(hourPath + 'h' + i + '.png')
          timeArray.push(timePath + i + '.png')
          timeArray1.push(timePath1 + i + '.png')
          num_array.push(numPath + i + '.png')
          aqi_num_array.push(greenPath + i + '.png')
          pai_num_array.push(bluePath + i + '.png')
          pink_num_array.push(pink_numPath + i + '.png')
          violet_num_array.push(violetPath + i + '.png')
          time_array1.push(restPath + 'h' + i + '.png')
        }

        for (let k = 1; k < 8; k++) {
          week_en_array.push(week_enPath + k + '.png')
          week_sc_array.push(week_scPath + k + '.png')
          week1_en_array.push(week1_enPath + k + '.png')
          week1_sc_array.push(week1_scPath + k + '.png')
        }

        for (let m = 1; m < 7; m++) {
          aqi_array.push(greenAqiPath + m + '.png')
          pink_array.push(pinkPath + m + '.png')
        }

        for (let p = 1; p < 6; p++) {
          violet_array.push(uviPath + p + '.png')
        }

        let obj_bg = {
          x: 0,
          y: 0,
          w: 466,
          h: 466,
          src: bgPath + 'bg.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        }

        let obj_time = {
          hour_zero: 1,
          hour_startX: num_time_h_x,
          hour_startY: num_time_common_y,
          hour_array: hour_array,
          hour_space: 8,
          minute_zero: 1,
          minute_startX: num_time_m_x,
          minute_startY: num_time_common_y,
          minute_array: hour_array,
          minute_space: 8,
          second_zero: 1,
          second_startX: num_date_x,
          second_startY: 278,
          second_array: timeArray,
          second_space: 0,
          hour_align: hmUI.align.LEFT,
          am_x: num_am_pm_x,
          am_y: num_am_pm_y,
          am_sc_path: rootPath + 'am_pm/am.png',
          am_en_path: rootPath + 'am_pm/am.png',
          pm_x: num_am_pm_x,
          pm_y: num_am_pm_y,
          pm_sc_path: rootPath + 'am_pm/pm.png',
          pm_en_path: rootPath + 'am_pm/pm.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        }

        let obj_clock_status = {
          x: 319,
          y: 50 * 0.987083,
          type: hmUI.system_status.CLOCK,
          src: bgPath + 'clock.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        }

        let obj_date = {
          day_startX: num_date_x,
          day_startY: num_week_y,
          day_align: hmUI.align.LEFT,
          day_space: 1, //文字间隔
          day_zero: 1, //是否补零
          day_en_array: timeArray,
          day_sc_array: timeArray,
          day_tc_array: timeArray,
        }

        let obj_week = {
          x: num_week_x,
          y: num_week_y,
          week_en: week_en_array,
          week_tc: week_sc_array,
          week_sc: week_sc_array,
        }

        let obj_step_icon = {
          x: num_icon_x,
          y: 330,
          src: bluePath + 'step.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        }

        let obj_step_text = {
          x: 345 * 0.987083,
          y: 334,
          type: hmUI.data_type.STEP,
          font_array: num_array,
          h_space: -1,
          align_h: hmUI.align.LEFT,
          show_level: hmUI.show_level.ONLY_NORMAL,
        }

        let obj_hum_icon = {
          x: num_icon_x,
          y: 386,
          src: bluePath + 'humidity.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        }

        let obj_hum_text = {
          x: 345 * 0.987083,
          y: 390,
          type: hmUI.data_type.HUMIDITY,
          font_array: num_array,
          h_space: 0,
          align_h: hmUI.align.LEFT,
          show_level: hmUI.show_level.ONLY_NORMAL,
          invalid_image: numPath + 'null.png',
        }

        let obj_weather = {
          x: 69 * 0.987083,
          y: 105 * 0.987083,
          image_array: weather_img_array,
          image_length: weather_img_array.length,
          type: hmUI.data_type.WEATHER_CURRENT,
          show_level: hmUI.show_level.ONLY_NORMAL,
        }

        let obj_bg_xp = {
          x: 345 * 0.987083,
          y: 390,
          type: hmUI.data_type.HUMIDITY,
          font_array: num_array,
          h_space: 0,
          align_h: hmUI.align.LEFT,
          show_level: hmUI.show_level.ONLY_NORMAL,
          invalid_image: numPath + 'null.png',
        }

        let obj_time_xp = {
          hour_zero: 1, //是否补零
          hour_startX: num_time_h_x,
          hour_startY: num_time_common_y,
          hour_array: time_array1,
          hour_space: 8,
          minute_zero: 1, //是否补零
          minute_startX: num_time_m_x,
          minute_startY: num_time_common_y,
          minute_array: time_array1,
          minute_space: 8,
          hour_align: hmUI.align.LEFT,
          show_level: hmUI.show_level.ONAL_AOD,
        }

        let obj_week_xp = {
          x: num_week_x,
          y: num_week_y,
          week_en: week1_en_array,
          week_tc: week1_sc_array,
          week_sc: week1_sc_array,
          show_level: hmUI.show_level.ONAL_AOD,
        }

        let obj_date_xp = {
          day_startX: num_date_x,
          day_startY: num_week_y,
          day_align: hmUI.align.LEFT,
          day_space: 1,
          day_zero: 1,
          day_en_array: timeArray1,
          day_sc_array: timeArray1,
          day_tc_array: timeArray1,
          show_level: hmUI.show_level.ONAL_AOD,
        }

        let obj_uvi = {
          center_x: 86 * 0.987083,
          center_y: 348,
          x: 5 * 0.987083,
          y: 26 * 0.987083,
          src: violetPath + '10.png',
          type: hmUI.data_type.UVI,
          text: 0,
          start_angle: -180,
          end_angle: 180,
          show_level: hmUI.show_level.ONLY_NORMAL,
        }

        let edit_list_config = {
          title_font_size: 34,
          title_align_h: hmUI.align.CENTER_H,
          list_item_vspace: 8,
          list_bg_color: 0x0000,
          list_bg_radius: 30,
          list_group_text_font_size: 32,
          list_group_text_align_h: hmUI.align.CENTER_H,
          list_tips_text_font_size: 32,
          list_tips_text_align_h: hmUI.align.LEFT,
        }

        let widgetOptionalArray = [
          { type: hmUI.edit_type.STEP, preview: widgetPreview + 'steps.png' },
          { type: hmUI.edit_type.CAL, preview: widgetPreview + 'cal.png' },
          { type: hmUI.edit_type.BATTERY, preview: widgetPreview + 'battery.png' },
          { type: hmUI.edit_type.HEART, preview: widgetPreview + 'heart.png' },
          { type: hmUI.edit_type.UVI, preview: widgetPreview + 'uvi.png' },
          { type: hmUI.edit_type.PAI, preview: widgetPreview + 'pai.png' },
        ]

        let obj_uvi_click = {
          x: 60,
          y: 320,
          w: 50,
          h: 50,
          type: hmUI.data_type.UVI,
        }

        let obj_weather_click = {
          x: 60,
          y: 95,
          w: 50,
          h: 50,
          type: hmUI.data_type.WEATHER_CURRENT,
        }

        let obj_step_click = {
          x: num_icon_x,
          y: 330,
          w: 100,
          h: 40,
          type: hmUI.data_type.STEP,
        }

        let obj_hum_click = {
          x: num_icon_x,
          y: 386,
          w: 79,
          h: 40,
          type: hmUI.data_type.HUMIDITY,
        }

        let obj_clock_click = {
          x: 319,
          y: 45,
          w: 40,
          h: 40,
          type: hmUI.data_type.ALARM_CLOCK,
        }

        // 背景
        let bg_img = hmUI.createWidget(hmUI.widget.IMG, obj_bg)

        // 时间文本
        let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, obj_time)

        //
        let clockStatus = hmUI.createWidget(hmUI.widget.IMG_STATUS, obj_clock_status)

        // 日期
        let status = hmUI.createWidget(hmUI.widget.IMG_DATE, obj_date)

        // 星期
        let weekText = hmUI.createWidget(hmUI.widget.IMG_WEEK, obj_week)

        // 步数图标
        const stepwidget = hmUI.createWidget(hmUI.widget.IMG, obj_step_icon)

        // 步数文本
        let stepText = hmUI.createWidget(hmUI.widget.TEXT_IMG, obj_step_text)

        // 湿度图标
        const humidityidget = hmUI.createWidget(hmUI.widget.IMG, obj_hum_icon)

        // 湿度文本
        let humidityText = hmUI.createWidget(hmUI.widget.TEXT_IMG, obj_hum_text)

        // 天气图标
        let weather_img = hmUI.createWidget(hmUI.widget.IMG_LEVEL, obj_weather)

        // 紫外线强度
        let pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, obj_uvi)

        // 息屏背景
        let AOD_bg_img = hmUI.createWidget(hmUI.widget.IMG, obj_bg_xp)

        let AOD_timeText1 = hmUI.createWidget(hmUI.widget.IMG_TIME, obj_time_xp)

        let AOD_weekText1 = hmUI.createWidget(hmUI.widget.IMG_WEEK, obj_week_xp)

        let AOD_status1 = hmUI.createWidget(hmUI.widget.IMG_DATE, obj_date_xp)

        let groupX = 147
        let groupY = 50
        let Group1 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 101,
          x: groupX * 0.987083,
          y: groupY * 0.987083,
          w: 113 * 0.987083,
          h: 113 * 0.987083,
          select_image: rootPath + 'select/select.png',
          un_select_image: rootPath + 'select/un_select.png',
          default_type: hmUI.edit_type.CAL,
          optional_types: widgetOptionalArray,
          count: widgetOptionalArray.length,
          tips_BG: rootPath + 'select/tips.png',
          tips_x: 44,
          tips_y: 380,
          tips_width: num_tips_w,
          tips_margin: 10,
          select_list: edit_list_config,
        })

        let item = Group1.getProperty(hmUI.prop.CURRENT_TYPE)
        this.drawWidget(item, 101)

        let groupX2 = 46
        let groupY2 = 185
        let Group2 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 102,
          x: groupX2 * 0.987083,
          y: groupY2 * 0.987083,
          w: 113 * 0.987083,
          h: 113 * 0.987083,
          select_image: rootPath + 'select/select.png',
          un_select_image: rootPath + 'select/un_select.png',
          default_type: hmUI.edit_type.BATTERY,
          optional_types: widgetOptionalArray,
          count: widgetOptionalArray.length,
          tips_BG: rootPath + 'select/tips.png',
          tips_x: 144,
          tips_y: 247,
          tips_width: num_tips_w,
          tips_margin: 10,
          select_list: edit_list_config,
        })

        let item2 = Group2.getProperty(hmUI.prop.CURRENT_TYPE)
        this.drawWidget(item2, 102)

        let groupX3 = 145
        let groupY3 = 318
        let Group3 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 103,
          x: groupX3 * 0.987083,
          y: groupY3 * 0.987083,
          w: 113 * 0.987083,
          h: 113 * 0.987083,
          select_image: rootPath + 'select/select.png',
          un_select_image: rootPath + 'select/un_select.png',
          default_type: hmUI.edit_type.HEART,
          optional_types: widgetOptionalArray,
          count: widgetOptionalArray.length,
          tips_BG: rootPath + 'select/tips.png',
          tips_x: 45,
          tips_y: 116,
          tips_width: num_tips_w,
          tips_margin: 10,
          select_list: edit_list_config,
        })
        let item3 = Group3.getProperty(hmUI.prop.CURRENT_TYPE)
        this.drawWidget(item3, 103)

        let maskCover = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK, {
          x: 0,
          y: 0,
          w: 466,
          h: 466,
          src: rootPath + 'select/mask100.png',
          show_level: hmUI.show_level.ONLY_EDIT,
        })

        let mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
          x: 0,
          y: 0,
          w: 466,
          h: 466,
          src: rootPath + 'select/mask70.png',
          show_level: hmUI.show_level.ONLY_EDIT,
        })

        // VUI点击
        let uvi_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, obj_uvi_click)

        // 天气图标点击
        let weather_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, obj_weather_click)

        // 步数图标点击
        let step_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, obj_step_click)

        // 湿度图标点击
        let hum_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, obj_hum_click)

        // 闹钟图标点击
        let clock_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, obj_clock_click)
      },
      drawWidget(editType, id) {
        config = {
          bgx: null,
          bgy: null,
          w: 150,
          iconX: null,
          iconY: null,
          numX: null,
          numY: null,
          bgimg1: null,
          array: null,
          type: null,
          src: null,
          num_array: null,
          h: 0,
          invalid: null,
        }

        switch (id) {
          case 101:
            ;(config.bgx = 151),
              (config.bgy = 57),
              (config.bgw = 94),
              (config.numX = 158),
              (config.numY = 90),
              (config.iconX = 180),
              (config.iconY = 120)
            break
          case 102:
            ;(config.bgx = 54),
              (config.bgy = 190),
              (config.bgw = 94),
              (config.numX = 62),
              (config.numY = 224),
              (config.iconX = 83),
              (config.iconY = 253)
            break
          case 103:
            ;(config.bgx = 150),
              (config.bgy = 317),
              (config.bgw = 94),
              (config.numX = 158),
              (config.numY = 353),
              (config.iconX = 180),
              (config.iconY = 383)
            break
          default:
        }

        switch (editType) {
          case hmUI.edit_type.BATTERY:
            config.bgimg1 = blue
            config.array = pai_array
            config.type = hmUI.data_type.BATTERY
            config.src = bluePath + 'battery.png'
            config.num_array = pai_num_array
            config.numX = config.numX + 15 - 53
            // config.invalid = bluePath + "null.png"
            break
          case hmUI.edit_type.CAL:
            config.bgimg1 = yellow
            config.array = calorie_array
            config.type = hmUI.data_type.CAL
            config.num_array = yellow_num_array
            config.src = yellowPath + 'calorie.png'
            // config.src = yellowPath + "calorie.png"
            config.numX = config.numX + 8 - 43
            // config.invalid = yellowPath + "yellow.png"
            break
          case hmUI.edit_type.PAI:
            config.bgimg1 = blue
            config.array = pai_array
            config.type = hmUI.data_type.PAI_WEEKLY
            config.src = bluePath + 'pai.png'
            config.num_array = pai_num_array
            config.numX = config.numX + 16 - 53
            // config.invalid = bluePath + "null.png"

            break
          case hmUI.edit_type.STEP:
            config.bgimg1 = blue
            config.array = pai_array
            config.type = hmUI.data_type.STEP
            config.src = bluePath + 'step.png'
            config.num_array = pai_num_array
            config.numX = config.numX + 7 - 43
            config.h = -3
            // config.invalid = bluePath + "null.png"
            break
          case hmUI.edit_type.UVI:
            config.bgx = config.numX - 11
            config.bgy = config.bgy - 3
            config.bgimg1 = violet
            config.array = violet_array
            config.type = hmUI.data_type.UVI
            config.src = violetPath + 'icon.png'
            config.num_array = violet_num_array
            config.numX = config.numX + 23 - 60
            config.invalid = violetPath + 'null.png'

            break
          case hmUI.edit_type.HEART:
            config.bgx = config.numX - 10
            config.bgy = config.bgy - 3
            config.bgimg1 = pink
            config.array = pink_array
            config.type = hmUI.data_type.HEART
            config.src = pinkPath + 'heart.png'
            config.num_array = pink_num_array
            config.numX = config.numX + 16 - 53
            config.invalid = pink_numPath + '10.png'
            break

          default:
            return config
        }

        // 背景进度条
        item_bgimg = hmUI.createWidget(hmUI.widget.IMG, {
          x: config.bgx,
          y: config.bgy,
          w: config.bgw,
          h: config.bgw,
          src: config.bgimg1,
          show_level: hmUI.show_level.ONLY_NORMAL,
        })

        // 组件进度条
        item_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: config.bgx,
          y: config.bgy,
          image_array: config.array,
          image_length: config.array.length,
          type: config.type,
          show_level: hmUI.show_level.ONLY_NORMAL,
        })

        // 组件文本
        let item_Text = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: config.numX,
          y: config.numY,
          w: config.w,
          type: config.type,
          font_array: config.num_array,
          h_space: config.h,
          show_level: hmUI.show_level.ONLY_NORMAL,
          invalid_image: config.invalid,
          // padding: true,
          align_h: hmUI.align.CENTER_H,
        })

        // 组件图标
        let item_icon = hmUI.createWidget(hmUI.widget.IMG, {
          x: config.iconX,
          y: config.iconY,
          src: config.src,
          show_level: hmUI.show_level.ONLY_NORMAL,
        })

        let item_icon_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: config.bgx,
          y: config.bgy,
          w: 90,
          h: 90,
          type: config.type,
        })
      },

      onInit() {
        console.log('index page.js on init invoke')

        this.init_view()
      },

      onReady() {
        console.log('index page.js on ready invoke')
      },

      onShow() {
        console.log('index page.js on show invoke')
      },

      onHide() {
        console.log('index page.js on hide invoke')
      },

      onDestory() {
        console.log('index page.js on destory invoke')
      },
    })
    /*
     * end js
     */
  })()
} catch (e) {
  console.log(e)
}
