try {
  (() => {
    var e = __$$hmAppManager$$__.currentApp;
    const n = e.current,
      { px: _ } =
        (new DeviceRuntimeCore.WidgetFactory(
          new DeviceRuntimeCore.HmDomApi(e, n)
        ),
        e.app.__globals__),
      o = Logger.getLogger("watchface6");
    n.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
          edit_id: 1,
          x: 0,
          y: 0,
          bg_config: [
            { id: 1, path: "6.png", preview: "6.png" },
            { id: 2, path: "7.png", preview: "7.png" },
            { id: 3, path: "8.png", preview: "8.png" },
          ],
          count: 3,
          default_id: 1,
          fg: "5.png",
          tips_x: 151,
          tips_y: 21,
          tips_bg: "4.png",
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
        }),
          hmUI.createWidget(hmUI.widget.TIME_POINTER, {
            hour_centerX: 233,
            hour_centerY: 233,
            hour_posX: 233,
            hour_posY: 233,
            hour_path: "9.png",
            hour_cover_x: 233,
            hour_cover_y: 233,
            enable: !1,
            show_level: hmUI.show_level.ONLY_NORMAL,
          }),
          hmUI.createWidget(hmUI.widget.TIME_POINTER, {
            second_centerX: 233,
            second_centerY: 233,
            second_posX: 233,
            second_posY: 233,
            second_path: "11.png",
            second_cover_x: 233,
            second_cover_y: 233,
            enable: !1,
            show_level: hmUI.show_level.ONLY_NORMAL,
          }),
          hmUI.createWidget(hmUI.widget.TIME_POINTER, {
            minute_centerX: 233,
            minute_centerY: 233,
            minute_posX: 8,
            minute_posY: 233,
            minute_path: "10.png",
            minute_cover_x: 0,
            minute_cover_y: 0,
            enable: !1,
            show_level: hmUI.show_level.ONLY_NORMAL,
          }),
          hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
            center_x: 233,
            center_y: 233,
            radius: 232,
            start_angle: 180,
            end_angle: -180,
            color: 4286348412,
            line_width: 3,
            type: hmUI.data_type.STEP,
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
      },
      onInit() {
        o.log("index page.js on init invoke");
      },
      build() {
        this.init_view(), o.log("index page.js on ready invoke");
      },
      onDestory() {
        o.log("index page.js on destory invoke");
      },
    });
  })();
} catch (e) {
  console.log(e);
}
