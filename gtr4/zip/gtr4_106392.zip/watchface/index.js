try {
  ; (() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp

    var __$$module$$__ = __$$app$$__.current
    var h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__),
      'drink'
    )

      /*
       * huamiOS bundle tool v1.0.17
       * Copyright © Huami. All Rights Reserved
       */
      ; ('use strict')

    console.log('----->>>current')
    console.log(__$$hmAppManager$$__.currentApp.pid)
    console.log(__$$hmAppManager$$__.currentApp.current)

    // =========================================================

    const WIDGET_LEFT_ID = 101
    const WIDGET_RIGHT_ID = 102
    const WIDGET_LEFT = 1
    const WIDGET_RIGHT = 2
    const WIDGET_EDIT_SIZE = 158
    const weather = hmSensor.createSensor(hmSensor.id.WEATHER);

    // 数组对象
    let norWeek_en = []
    let norWeek_sc = []
    let norWeek_tc = []
    let aodWeek_en = []
    let aodWeek_sc = []
    let aodWeek_tc = []
    let norDate = []
    let aodDate = []
    let heartArray = []
    let fontArray = []
    let moonArray = []
    let timeNumDarkArray = []
    let timeNumLightArray = []
    let widgetOptionalArray = []
    let editWidgetChooseLeft = null
    let editWidgetChooseRight = null
    let leftWidget = null
    let rightWidget = null
    let lefteditType = null
    let righteditType = null
    let ARC = null
    let arc_light = null
    let startArc1 = null
    let startArc2 = null
    let endArc1 = null
    let endArc2 = null

    var ARC_START = null
    var ARC_END = null
    var timeStart = null
    var timeEnd = null

    var time24Array = []
    //=====================================================================
    // 路径
    const ROOTPATH = 'images/'
    const WIDGET = ROOTPATH + 'nor/widget/'
    const widgetPreview = ROOTPATH + 'nor/widget/pre/'
    const select = ROOTPATH + 'nor/widget/'
    const WIDGET_TIPS_PATH = ROOTPATH + 'nor/widget/tips_bg.png'
    const WIDGET_POINTER_PATH = WIDGET + 'pointer.png'

    // 填充静态

    for (let i = 1; i < 8; i++) {
      norWeek_en.push(ROOTPATH + 'nor/week/en/' + i + '.png')
      norWeek_tc.push(ROOTPATH + 'nor/week/tc/' + i + '.png')
      norWeek_sc.push(ROOTPATH + 'nor/week/sc/' + i + '.png')
      aodWeek_en.push(ROOTPATH + 'aod/week/en/' + i + '.png')
      aodWeek_tc.push(ROOTPATH + 'aod/week/tc/' + i + '.png')
      aodWeek_sc.push(ROOTPATH + 'aod/week/sc/' + i + '.png')
    }

    for (let i = 0; i < 10; i++) {
      norDate.push(ROOTPATH + 'nor/date/' + i + '.png')
      aodDate.push(ROOTPATH + 'aod/date/' + i + '.png')
      fontArray.push(ROOTPATH + 'nor/other/num/' + i + '.png')
      heartArray.push(ROOTPATH + 'nor/heart/data/' + i + '.png')
    }
    for (let i = 1; i < 31; i++) {
      moonArray.push(ROOTPATH + 'nor/moon/moon' + i + '.png')
    }
    for (let i = 1; i < 25; i++) {
      timeNumDarkArray.push(ROOTPATH + 'nor/dark/' + i + '.png')
      timeNumLightArray.push(ROOTPATH + 'nor/light/' + i + '.png')
    }
    // 表盘时间刻度坐标
    let timeXy = [
      { x: 278, y: 6 },
      { x: 333, y: 28 },
      { x: 378, y: 62 },
      { x: 415, y: 110 },
      { x: 436, y: 164 },
      { x: 442, y: 221 },
      { x: 434, y: 278 },
      { x: 412, y: 333 },
      { x: 378, y: 378 },
      { x: 333, y: 413 },
      { x: 278, y: 436 },
      { x: 221, y: 442 },
      { x: 164, y: 436 },
      { x: 110, y: 414 },
      { x: 64, y: 378 },
      { x: 29, y: 333 },
      { x: 6, y: 278 },
      { x: 0, y: 221 },
      { x: 6, y: 163 },
      { x: 28, y: 110 },
      { x: 62, y: 64 },
      { x: 109, y: 28 },
      { x: 164, y: 6 },
      { x: 221, y: 0 },
    ]
    //------------------------------------------------表盘背景图-----------------------------------------------
    let bgObj = {
      x: 0,
      y: 0,
      src: ROOTPATH + 'nor/bg/bg.png',
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
    }
    // -----------------------------------------------正常月相-----------------------------------------------
    let moonObj = {
      x: 207,
      y: 57,
      image_array: moonArray,
      image_length: moonArray.length,
      type: hmUI.data_type.MOON,
      show_level: hmUI.show_level.ONLY_NORMAL
    }
    //------------------------------------------------正常星期-----------------------------------------------
    let norobjWeek = {
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
      x: 222,
      y: 140,
      week_tc: norWeek_tc,
      week_sc: norWeek_sc,
      week_en: norWeek_en,
    }
    //------------------------------------------------息屏星期-----------------------------------------------
    let aodobjWeek = {
      show_level: hmUI.show_level.ONAL_AOD,
      x: 222,
      y: 140,
      week_tc: aodWeek_tc,
      week_sc: aodWeek_sc,
      week_en: aodWeek_en,
    }
    //------------------------------------------------正常日期-----------------------------------------------
    let norobjDay = {
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
      day_startX: 189,
      day_startY: 141,
      day_zero: true,
      day_en_array: norDate,
    }
    //------------------------------------------------息屏日期-----------------------------------------------
    let aodobjDay = {
      show_level: hmUI.show_level.ONAL_AOD,
      day_startX: 189,
      day_startY: 141,
      day_zero: true,
      day_en_array: aodDate,
    }
    //------------------------------------------------正常时间-----------------------------------------------
    let timePointer = {
      hour_centerX: 233, // 指针旋转中心 对应 centerX
      hour_centerY: 233, // 指针旋转中心 对应 centerY
      hour_posX: 18, // 指针自身旋转中心 对应 position 中的 x
      hour_posY: 233, // 指针自身旋转中心 对应 position 中的 y
      hour_path: ROOTPATH + 'nor/time/hour.png',
      minute_centerX: 233, // 指针旋转中心 对应 centerX
      minute_centerY: 233, // 指针旋转中心 对应 centerY
      minute_posX: 18, // 指针自身旋转中心 对应 position 中的 x
      minute_posY: 233, // 指针自身旋转中心 对应 position 中的 y
      minute_path: ROOTPATH + 'nor/time/minute.png',
      second_centerX: 233, // 指针旋转中心 对应 centerX
      second_centerY: 233, // 指针旋转中心 对应 centerY
      second_posX: 18, // 指针自身旋转中心 对应 position 中的 x
      second_posY: 233, // 指针自身旋转中心 对应 position 中的 y
      second_path: ROOTPATH + 'nor/time/second.png',
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
    }
    //------------------------------------------------息屏时间-----------------------------------------------
    let timeAodPointer = {
      hour_centerX: 233, // 指针旋转中心 对应 centerX
      hour_centerY: 233, // 指针旋转中心 对应 centerY
      hour_posX: 18, // 指针自身旋转中心 对应 position 中的 x
      hour_posY: 233, // 指针自身旋转中心 对应 position 中的 y
      hour_path: ROOTPATH + 'aod/time/hour.png',
      minute_centerX: 233, // 指针旋转中心 对应 centerX
      minute_centerY: 233, // 指针旋转中心 对应 centerY
      minute_posX: 18, // 指针自身旋转中心 对应 position 中的 x
      minute_posY: 233, // 指针自身旋转中心 对应 position 中的 y
      minute_path: ROOTPATH + 'aod/time/minute.png',
      show_level: hmUI.show_level.ONAL_AOD,
    }
    //------------------------------------------------正常心率-----------------------------------------------
    // 心率指针
    let heartPointerObj = {
      src: ROOTPATH + "nor/heart/pointer.png",
      center_x: 233,
      center_y: 353,
      x: 14,
      y: 76,
      type: hmUI.data_type.HEART,
      invalid_visible: true,
      start_angle: 153,
      end_angle: -153,
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
    }
    // 心率文本
    let heartTextObj = {
      x: 203,
      y: 350,
      w: 60,
      type: hmUI.data_type.HEART,
      font_array: heartArray,
      h_space: 0,
      align_h: hmUI.align.CENTER_H,
      invalid_image: "images/nor/heart/null.png",
      padding: false,
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
    }
    // 心率上方文字
    let heartImgObj = {
      x: 196,
      y: 312,
      src: ROOTPATH + "nor/heart/heart_en.png",
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
    }
    // --------------------------------------------------------可编辑遮罩-----------------------------------------
    let objMask = {
      x: 0,
      y: 0,
      w: 466,
      h: 466,
      src: ROOTPATH + 'mask.png',
      show_level: hmUI.show_level.ONLY_EDIT,
    }
    // ------------------------------------------环形控件配置---------------------------------
    let ARC_PUBLIC = {
      center_x: 233,
      center_y: 233,
      radius: 220,
      line_width: 25,
      corner_flag: 3,
      level: 100,
      show_level: hmUI.show_level.ONLY_NORMAL
    }

    //------------------------------------------------可编辑列表配置--------------------------------
    let edit_list_config = {
      title_font_size: 34,
      title_align_h: hmUI.align.CENTER_H,
      list_item_vspace: 8,
      list_bg_color: 0x0000,
      list_bg_radius: 30,
      list_group_text_font_size: 32,
      list_group_text_align_h: hmUI.align.CENTER_H,
      list_tips_text_font_size: 32,
      list_tips_text_align_h: hmUI.align.LEFT,
    };
    const logger = DeviceRuntimeCore.HmLogger.getLogger('sanjiao')
    __$$module$$__.module = DeviceRuntimeCore.Page({
      init_view() {

        let languageId = hmSetting.getLanguage()
        // --------------------------------------------------可编辑控件预览图语言切换---------------------------------------------
        function changeWidgetOption(languageId) {
          let temp = null
          switch (languageId) {
            case 0:
              temp = 'sc'
              break;
            case 1:
              temp = 'tc'
              break;
            case 2:
              temp = 'en'
              break;
            default:
              temp = 'en'
              break;
          }
          widgetOptionalArray = [
            { type: hmUI.edit_type.CAL, preview: widgetPreview + `${temp}/CAL.png` },
            { type: hmUI.edit_type.STEP, preview: widgetPreview + `${temp}/STEP.png` },
            { type: hmUI.edit_type.DISTANCE, preview: widgetPreview + `${temp}/DIS.png`, },
            { type: hmUI.edit_type.PAI_WEEKLY, preview: widgetPreview + `${temp}/PAI.png` },
            { type: hmUI.edit_type.BATTERY, preview: widgetPreview + `${temp}/BAT.png` },
            { type: hmUI.edit_type.STAND, preview: widgetPreview + `${temp}/STAND.png` },
            { type: hmUI.edit_type.UVI, preview: widgetPreview + `${temp}/UVI.png` },
          ]
          return widgetOptionalArray
        }
        // --------------------------------------------------可编辑控件配置函数---------------------------------------------
        function parseWidgetConfig(languageId, editType) {
          let path = null
          switch (languageId) {
            case 0:
              path = ROOTPATH + 'nor/other/icon/sc/'
              break;
            case 1:
              path = ROOTPATH + 'nor/other/icon/tc/'
              break;
            case 2:
              path = ROOTPATH + 'nor/other/icon/en/'
              break;
            default:
              path = ROOTPATH + 'nor/other/icon/en/'
              break;
          }
          let config = {
            bgPath: null, //背景图
            dataType: null, //数据类型
            nonePath: null, //无数据的图片
            xiaoshudian: null, // 小数点
            padding: false, // 是否补零
            unitEnPath: null, //单位
            unitScPath: null,
            unitTcPath: null,
            imperial_unit_sc: null,
            imperial_unit_en: null,
            imperial_unit_tc: null,
            pointerType: null, // 指针类型
            moveX: null, // 相对偏移量
            moveY: null, // 相对偏移量
            width: null, // 图片文本所占宽度
            startAngle: 0, //指针开始角度
            endAngle: 360, //指针结束角度
          }
          switch (editType) {
            case hmUI.edit_type.STEP:
              config.bgPath = WIDGET + 'bg.png'
              config.iconPath = path + 'STEP.png'
              config.dataType = hmUI.data_type.STEP
              config.pointerType = hmUI.data_type.STEP
              config.moveX = 32
              config.moveY = 94
              config.width = 100
              break
            case hmUI.edit_type.CAL:
              config.bgPath = WIDGET + 'bg.png'
              config.iconPath = path + 'CAL.png'
              config.dataType = hmUI.data_type.CAL
              config.pointerType = hmUI.data_type.CAL
              config.moveX = 43
              config.moveY = 94
              config.width = 75
              break
            case hmUI.edit_type.DISTANCE:
              config.bgPath = WIDGET + 'bg.png'
              config.iconPath = path + 'DIS.png'
              config.dataType = hmUI.data_type.DISTANCE
              config.nonePath = ROOTPATH + 'nor/other/null.png'
              config.xiaoshudian = ROOTPATH + 'dian.png'
              config.unitEnPath = ''
              config.unitScPath = ''
              config.unitTcPath = ''
              config.imperial_unit_sc = ''
              config.imperial_unit_en = ''
              config.imperial_unit_tc = ''
              config.pointerType = hmUI.data_type.STEP
              config.padding = false,
                config.moveX = 43
              config.moveY = 94
              config.width = 75
              break
            case hmUI.edit_type.PAI_WEEKLY:
              config.bgPath = WIDGET + 'bg.png'
              config.iconPath = path + 'PAI.png'
              config.dataType = hmUI.data_type.PAI_WEEKLY
              config.nonePath = ROOTPATH + 'nor/other/null.png'
              config.pointerType = hmUI.data_type.PAI_WEEKLY
              config.moveX = 56
              config.moveY = 94
              config.width = 45
              break
            case hmUI.edit_type.BATTERY:
              config.bgPath = WIDGET + 'bg.png'
              config.iconPath = path + 'BAT.png'
              config.dataType = hmUI.data_type.BATTERY
              config.unitEnPath = ROOTPATH + 'nor/other/baifenhao.png'
              config.unitScPath = ROOTPATH + 'nor/other/baifenhao.png'
              config.unitTcPath = ROOTPATH + 'nor/other/baifenhao.png'
              config.pointerType = hmUI.data_type.BATTERY
              config.moveX = 46
              config.moveY = 94
              config.width = 75
              break
            case hmUI.edit_type.STAND:
              config.bgPath = WIDGET + 'bg.png'
              config.iconPath = path + 'STAND.png'
              config.dataType = hmUI.data_type.STAND
              config.pointerType = hmUI.data_type.STAND
              config.moveX = 58
              config.moveY = 94
              config.width = 45
              break
            case hmUI.edit_type.UVI:
              config.bgPath = WIDGET + 'bg.png'
              config.iconPath = path + 'UVI.png'
              config.dataType = hmUI.data_type.UVI
              config.nonePath = ROOTPATH + 'nor/other/null.png'
              config.pointerType = hmUI.data_type.UVI
              config.moveX = 66
              config.moveY = 94
              config.width = 30
              break
            default:
              return config
          }
          return config
        }
        // --------------------------------------------------创建独立可编辑控件函数-------------------------------------
        function drawWidget(languageId, widgetType, editType) {
          let bgX = 0
          let bgY = 0
          switch (widgetType) {
            case WIDGET_RIGHT:
              bgX = 264
              bgY = 154
              break
            case WIDGET_LEFT:
              bgX = 45
              bgY = 154
              break
            default:
              return
          }
          const bgSize = WIDGET_EDIT_SIZE
          const config = parseWidgetConfig(languageId, editType)
          const iconX = bgX + 34
          const iconY = bgY + 38
          const textX = bgX + config.moveX
          const textY = bgY + config.moveY
          hmUI.createWidget(hmUI.widget.IMG, {
            x: bgX,
            y: bgY,
            src: config.bgPath,
            show_level: hmUI.show_level.ONLY_NORMAL
          })
          switch (widgetType) {
            case WIDGET_LEFT:
              editWidgetChooseLeft = hmUI.createWidget(hmUI.widget.IMG, {
                x: iconX,
                y: iconY,
                src: config.iconPath,
                show_level: hmUI.show_level.ONLY_NORMAL
              })
              break
            case WIDGET_RIGHT:
              editWidgetChooseRight = hmUI.createWidget(hmUI.widget.IMG, {
                x: iconX,
                y: iconY,
                src: config.iconPath,
                show_level: hmUI.show_level.ONLY_NORMAL
              })
              break
            default:
              return
          }
          //====================================================================
          let publicTextOption = {
            x: textX,
            y: textY,
            w: config.width,
            align_h: hmUI.align.CENTER_H,
            type: config.dataType,
            h_space: 1,
            font_array: fontArray,
            unit_sc: config.unitScPath,
            unit_en: config.unitEnPath,
            unit_tc: config.unitTcPath,
            imperial_unit_sc: config.imperial_unit_sc,
            imperial_unit_en: config.imperial_unit_en,
            imperial_unit_tc: config.imperial_unit_tc,
            invalid_image: config.nonePath,
            padding: config.padding,
          }
          if (config.dataType == hmUI.data_type.DISTANCE) {
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              ...publicTextOption,
              dot_image: config.xiaoshudian,
              show_level: hmUI.show_level.ONLY_NORMAL
            })
          } else {
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              ...publicTextOption,
              show_level: hmUI.show_level.ONLY_NORMAL
            })
          }
          hmUI.createWidget(hmUI.widget.IMG_POINTER, {
            center_x: bgX + (bgSize / 2),
            center_y: bgY + (bgSize / 2),
            x: 10,
            y: 77,
            src: WIDGET_POINTER_PATH,
            type: config.pointerType,
            start_angle: config.startAngle,
            end_angle: config.endAngle,
            show_level: hmUI.show_level.ONLY_NORMAL
          })
          hmUI.createWidget(hmUI.widget.IMG_CLICK, {
            x: bgX,
            y: bgY,
            w: WIDGET_EDIT_SIZE,
            h: WIDGET_EDIT_SIZE,
            type: config.dataType,//必写 跳转的action
          });
        }
        // --------------------------------------------------心率语言选择-----------------------------------------------
        function chooseHeartText(languageId) {
          let heartTextPath = null
          switch (languageId) {
            case 0:
              heartTextPath = ROOTPATH + 'nor/heart/heart_sc.png'
              break;
            case 1:
              heartTextPath = ROOTPATH + 'nor/heart/heart_tc.png'
              break;
            case 2:
              heartTextPath = ROOTPATH + 'nor/heart/heart_en.png'
              break;
            default:
              heartTextPath = ROOTPATH + 'nor/heart/heart_en.png'
              break;
          }
          return heartTextPath
        }
        const screenType = hmSetting.getScreenType()
        hmUI.createWidget(hmUI.widget.IMG, bgObj) // 背景图片
        hmUI.createWidget(hmUI.widget.IMG_WEEK, norobjWeek) // 正常星期
        hmUI.createWidget(hmUI.widget.IMG_WEEK, aodobjWeek) // 息屏星期
        hmUI.createWidget(hmUI.widget.IMG_DATE, norobjDay) // 正常日期
        hmUI.createWidget(hmUI.widget.IMG_DATE, aodobjDay) // 息屏日期
        hmUI.createWidget(hmUI.widget.TEXT_IMG, heartTextObj)
        heartWidget = hmUI.createWidget(hmUI.widget.IMG, heartImgObj)
        heartWidget.setProperty(hmUI.prop.SRC, chooseHeartText(languageId))
        hmUI.createWidget(hmUI.widget.IMG_LEVEL, moonObj)

        //-----------------------------------------------------------------------------------------
        ARC = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, ARC_PUBLIC)
        arc_light = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, ARC_PUBLIC)

        startArc2 = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, ARC_PUBLIC)
        endArc2 = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, ARC_PUBLIC)

        for (let i = 0; i < 24; i++) {
          time24Array.push(hmUI.createWidget(hmUI.widget.IMG, {
            x: timeXy[i].x,
            y: timeXy[i].y,
            src: timeNumDarkArray[i],
            w: 24,
            h: 24,
            show_level: hmUI.show_level.ONLY_NORMAL
          }))
          time24Array[i].setProperty(hmUI.prop.VISIBLE, false)
        }
        const weatherData = weather.getForecastWeather()
        const tideData = weatherData.tideData

        function getSun() {
          const weatherData = weather.getForecastWeather()
          const tideData = weatherData.tideData
          const element = tideData.data[0];
          ARC_START = (element.sunrise.hour * 60 + element.sunrise.minute) * 360 / 1440
          ARC_END = ((element.sunset.hour * 60 + element.sunset.minute) * 360 / 1440)
          if(element.sunset.minute === 0){
            timeStart = element.sunrise.hour -1
          }else{
            timeStart = element.sunrise.hour
          }
          timeEnd = element.sunset.hour
          // 底色灰圈
          ARC.setProperty(hmUI.prop.MORE, {
            start_angle: 180,
            end_angle: -180,
            color: 0x1d1f1d,
            center_x: 233,
            center_y: 233,
            radius: 222,
            line_width: 22,
            corner_flag: 3,
            level: 100,
            show_level: hmUI.show_level.ONLY_NORMAL
          })
          // 白色圈
          arc_light.setProperty(hmUI.prop.MORE, {
            start_angle: ARC_START,
            end_angle: ARC_END,
            color: 0x868486,
            center_x: 233,
            center_y: 233,
            radius: 222,
            line_width: 22,
            corner_flag: 3,
            level: 100,
            show_level: hmUI.show_level.ONLY_NORMAL
          })
          // 白色隔断
          startArc2.setProperty(hmUI.prop.MORE, {
            start_angle: ARC_START - 2,
            end_angle: ARC_START - 1,
            color: 0xffffff,
            center_x: 233,
            center_y: 233,
            radius: 222,
            line_width: 22,
            corner_flag: 3,
            level: 100,
            show_level: hmUI.show_level.ONLY_NORMAL
          })
          endArc2.setProperty(hmUI.prop.MORE, {
            start_angle: ARC_END + 1,
            end_angle: ARC_END + 2,
            color: 0xffffff,
            center_x: 233,
            center_y: 233,
            radius: 222,
            line_width: 22,
            corner_flag: 3,
            level: 100,
            show_level: hmUI.show_level.ONLY_NORMAL
          })
          for (let i = 0; i < 24; i++) {
            time24Array[i].setProperty(hmUI.prop.VISIBLE, true)
            time24Array[i].setProperty(hmUI.prop.SRC, timeNumDarkArray[i])
          }
          for (let i = timeStart; i < timeEnd; i++) {
            time24Array[i].setProperty(hmUI.prop.SRC, timeNumLightArray[i])
          }
        }
        if (tideData.count != 0 && tideData.data[0]) {
          getSun()
        }
        hmUI.createWidget(hmUI.widget.IMG_POINTER, heartPointerObj)
        hmUI.createWidget(hmUI.widget.TIME_POINTER, timePointer)
        hmUI.createWidget(hmUI.widget.TIME_POINTER, timeAodPointer)
        mask = hmUI.createWidget(hmUI.widget.IMG, objMask)
        function drawPublic() {
          // --------------------------------------------------左侧可编辑组件-----------------------------------------------
          let leftOptional = changeWidgetOption(languageId)
          let objLeftWidget = {
            edit_id: WIDGET_LEFT_ID,
            x: 45,
            y: 154,
            w: WIDGET_EDIT_SIZE,
            h: WIDGET_EDIT_SIZE,
            select_image: select + 'select.png',
            un_select_image: select + 'unselect.png',
            default_type: hmUI.edit_type.BATTERY,
            optional_types: leftOptional,
            count: leftOptional.length,
            tips_BG: 'images/nor/widget/tips_bg.png',
            tips_x: 105,
            tips_y: WIDGET_EDIT_SIZE + 94,
            tips_width: 170,
            tips_margin: 10,
            select_list: edit_list_config,
          }
          leftWidget = hmUI.createWidget(
            hmUI.widget.WATCHFACE_EDIT_GROUP,
            {
              ...objLeftWidget,
              default_type: hmUI.edit_type.BATTERY
            }
          )
          lefteditType = leftWidget.getProperty(hmUI.prop.CURRENT_TYPE)
          drawWidget(languageId, WIDGET_LEFT, lefteditType)

          // --------------------------------------------------右侧可编辑组件-----------------------------------------------
          let rightOptional = changeWidgetOption(languageId)
          let objRightWidget = {
            edit_id: WIDGET_RIGHT_ID,
            x: 264,
            y: 154,
            w: WIDGET_EDIT_SIZE,
            h: WIDGET_EDIT_SIZE,
            select_image: select + 'select.png',
            un_select_image: select + 'unselect.png',
            default_type: hmUI.edit_type.STEP,
            optional_types: rightOptional,
            count: rightOptional.length,
            tips_BG: 'images/nor/widget/tips_bg.png',
            tips_x: -114,
            tips_y: WIDGET_EDIT_SIZE + 94,
            tips_width: 170,
            tips_margin: 10,
            select_list: edit_list_config,
          }
          rightWidget = hmUI.createWidget(
            hmUI.widget.WATCHFACE_EDIT_GROUP,
            objRightWidget
          )
          righteditType = rightWidget.getProperty(hmUI.prop.CURRENT_TYPE)
          drawWidget(languageId, WIDGET_RIGHT, righteditType)
        }
        if (screenType == hmSetting.screen_type.WATCHFACE) {
          drawPublic()
          hmUI.createWidget(hmUI.widget.TIME_POINTER, timePointer)
          hmUI.createWidget(hmUI.widget.TIME_POINTER, timeAodPointer)
          mask = hmUI.createWidget(hmUI.widget.IMG, objMask)
        } else {
          hmUI.createWidget(hmUI.widget.IMG, bgObj) // 背景图片
          hmUI.createWidget(hmUI.widget.IMG_WEEK, norobjWeek) // 正常星期
          hmUI.createWidget(hmUI.widget.IMG_WEEK, aodobjWeek) // 息屏星期
          hmUI.createWidget(hmUI.widget.IMG_DATE, norobjDay) // 正常日期
          hmUI.createWidget(hmUI.widget.IMG_DATE, aodobjDay) // 息屏日期
          hmUI.createWidget(hmUI.widget.TEXT_IMG, heartTextObj)
          heartWidget = hmUI.createWidget(hmUI.widget.IMG, heartImgObj)
          heartWidget.setProperty(hmUI.prop.SRC, chooseHeartText(languageId))
          hmUI.createWidget(hmUI.widget.TIME_POINTER, timePointer)
          hmUI.createWidget(hmUI.widget.TIME_POINTER, timeAodPointer)
          mask = hmUI.createWidget(hmUI.widget.IMG, objMask)
          drawPublic()

        }
        hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 176,
          y: 298,
          w: 105,
          h: 105,
          type: hmUI.data_type.HEART,//必写 跳转的action
        });
        hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 227,
          y: 57,
          w: 52,
          h: 52,
          type: hmUI.data_type.MOON,//必写 跳转的action
        });
        hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: (function () {
            let languageId = hmSetting.getLanguage()
            let textPath = null
            let heartTextPath = null
            let PathLeft = null
            let PathRight = null

            switch (languageId) {
              case 0:
                textPath = ROOTPATH + 'nor/other/icon/sc/'
                heartTextPath = ROOTPATH + 'nor/heart/heart_sc.png'
                break;
              case 1:
                textPath = ROOTPATH + 'nor/other/icon/tc/'
                heartTextPath = ROOTPATH + 'nor/heart/heart_tc.png'
                break;
              case 2:
                textPath = ROOTPATH + 'nor/other/icon/en/'
                heartTextPath = ROOTPATH + 'nor/heart/heart_en.png'
                break;
              default:
                textPath = ROOTPATH + 'nor/other/icon/en/'
                heartTextPath = ROOTPATH + 'nor/heart/heart_en.png'
                break;
            }
            heartWidget.setProperty(hmUI.prop.SRC, heartTextPath)

            let left = leftWidget.getProperty(hmUI.prop.CURRENT_TYPE)
            switch (left) {
              case hmUI.edit_type.STEP:
                PathLeft = textPath + 'STEP.png'
                break
              case hmUI.edit_type.CAL:
                PathLeft = textPath + 'CAL.png'
                break
              case hmUI.edit_type.DISTANCE:
                PathLeft = textPath + 'DIS.png'
                break
              case hmUI.edit_type.PAI_WEEKLY:
                PathLeft = textPath + 'PAI.png'
                break
              case hmUI.edit_type.BATTERY:
                PathLeft = textPath + 'BAT.png'
                break
              case hmUI.edit_type.STAND:
                PathLeft = textPath + 'STAND.png'
                break
              case hmUI.edit_type.UVI:
                PathLeft = textPath + 'UVI.png'
                break
              default:
                break;
            }
            editWidgetChooseLeft.setProperty(hmUI.prop.SRC, PathLeft)

            let right = rightWidget.getProperty(hmUI.prop.CURRENT_TYPE)
            switch (right) {
              case hmUI.edit_type.STEP:
                PathRight = textPath + 'STEP.png'
                break
              case hmUI.edit_type.CAL:
                PathRight = textPath + 'CAL.png'
                break
              case hmUI.edit_type.DISTANCE:
                PathRight = textPath + 'DIS.png'
                break
              case hmUI.edit_type.PAI_WEEKLY:
                PathRight = textPath + 'PAI.png'
                break
              case hmUI.edit_type.BATTERY:
                PathRight = textPath + 'BAT.png'
                break
              case hmUI.edit_type.STAND:
                PathRight = textPath + 'STAND.png'
                break
              case hmUI.edit_type.UVI:
                PathRight = textPath + 'UVI.png'
                break
              default:
                break;
            }
            editWidgetChooseRight.setProperty(hmUI.prop.SRC, PathRight)
            const weatherData = weather.getForecastWeather()
            const tideData = weatherData.tideData
            if (tideData.count != 0 && tideData.data[0]) {
            console.log('already resume_call');
              getSun()
            }
          }),
          pause_call: (function () {
            console.log('ui pause');
          }),
        });
      },

      onInit() {
        console.log('index page.js on init invoke')
        this.init_view()
      },

      onReady() {
        console.log('index page.js on ready invoke')
      },

      onShow() {
        console.log('index page.js on show invoke')
      },

      onHide() {
        console.log('index page.js on hide invoke')
      },

      onDestory() {
        console.log('index page.js on destory invoke')
      },
    })
    /*
     * end js
     */
  })()
} catch (e) {
  console.log(e)
}
