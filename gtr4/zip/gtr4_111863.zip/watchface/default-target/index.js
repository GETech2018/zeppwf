try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface6');

        let val, hour, minute, hLabel, mLabel, Hour, Minute, mHand, timeSensor;
        const center = 233;
        const hW = 400;
        const mhW = 10;
        const wW = 52;
        const dH = 32;
        const bR = 190;
        const bBg = '0xFF333333';
        const bFg = '0xFF858385';
        const baBg = '0xFF541111';
        const baFg = '0xFFFF3333';
        const bW = 6;
        const iW = 32;
        const cH = 60;

        function setLabel(val) {
            const timeFormat = hmSetting.getTimeFormat();
            hour = val.hour;
            minute = val.minute;

            if (timeFormat == 0 && hour > 11) { hour = hour - 12; }
            hLabel = 'h' + hour + '.png';
            Hour.setProperty(hmUI.prop.SRC, `${ hLabel }`);
            mLabel = 'm' + minute + '.png';
            Minute.setProperty(hmUI.prop.SRC, `${ mLabel }`);

            mHand.setProperty(hmUI.prop.MORE, {
                angle: minute * 6
            });
        }

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                if (!timeSensor) { timeSensor = hmSensor.createSensor(hmSensor.id.TIME); }

                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: center * 2,
                    h: center * 2,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                Minute = hmUI.createWidget(hmUI.widget.IMG, {
                    x: center - hW / 2,
                    y: center - hW / 2,
                    w: hW,
                    h: hW,
                    src: 'm0.png',
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                Hour = hmUI.createWidget(hmUI.widget.IMG, {
                    x: center - hW / 2,
                    y: center - hW / 2,
                    w: hW,
                    h: hW,
                    src: 'h0.png',
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: center - iW / 2,
                    y: 45 + iW / 2,
                    src: '21.png',
                    type: hmUI.system_status.CLOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: center - iW / 2,
                    y: center * 2 - iW,
                    src: '22.png',
                    type: hmUI.system_status.DISCONNECT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: center,
                    center_y: center,
                    radius: bR,
                    start_angle: 120,
                    end_angle: 60,
                    color: baBg,
                    line_width: bW,
                    level: 100,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: center,
                    center_y: center,
                    radius: bR,
                    start_angle: 120,
                    end_angle: 60,
                    color: baFg,
                    line_width: bW,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: center,
                    center_y: center,
                    radius: bR + 8,
                    start_angle: 240,
                    end_angle: 300,
                    color: bBg,
                    line_width: bW,
                    level: 100,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: center,
                    center_y: center,
                    radius: bR + 8,
                    start_angle: 240,
                    end_angle: 300,
                    color: bFg,
                    line_width: bW,
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: center,
                    center_y: center,
                    radius: bR - 7,
                    start_angle: 240,
                    end_angle: 300,
                    color: bBg,
                    line_width: bW,
                    level: 100,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: center,
                    center_y: center,
                    radius: bR - 7,
                    start_angle: 240,
                    end_angle: 300,
                    color: bFg,
                    line_width: bW,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: center - wW - 4,
                    y: center * 2 - 45 - dH,
                    week_en: [
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png'
                    ],
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    day_startX: center + 4,
                    day_startY: center * 2 - 45 - dH,
                    day_en_array: [
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png'
                    ],
                    day_align: hmUI.align.LEFT,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 0,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                mHand = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: center * 2,
                    h: center * 2,
                    center_x: center,
                    center_y: center,
                    pos_x: center - mhW / 2,
                    pos_y: 0,
                    angle: 0,
                    src: '3.png',
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: center / 2,
                    y: 0,
                    w: center,
                    h: cH,
                    type: hmUI.data_type.WEATHER,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: center / 2,
                    y: center * 2 - cH,
                    w: center,
                    h: cH,
                    type: hmUI.data_type.SPO2,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 0,
                    y: center / 2,
                    w: cH,
                    h: center,
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: center * 2 - cH,
                    y: center / 2,
                    w: cH,
                    h: center,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });

                timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
                    setLabel(timeSensor);
                });
                timer.createTimer(0, 60000, function (timeSensor2) {
                    setLabel(timeSensor2);
                }, timeSensor);
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function() {
                        setLabel(timeSensor);
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
