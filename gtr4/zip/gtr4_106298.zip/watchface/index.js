try {
  (() => {

    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

    /*
  * huamiOS bundle tool v1.0.17
  * Copyright © Huami. All Rights Reserved
  */
    'use strict';

    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let strRootPath = "images/"
    let strBgPath = strRootPath + "bg/"
    let strCoPath = strRootPath + "co/"
    let strHeartPath = strRootPath + "heart/"
    let strCenPath = strRootPath + "huan/"
    let strStepPath = strRootPath + "step/"
    let strTimePath = strRootPath + "time/"
    let strWearPath = strRootPath + "weather/"
    let strPointerPath = strRootPath + "zhizhen/"

    let arrHeart = []
    let arrCo = []
    let arrCen = []
    let arrTime = []
    let arrStep = []
    let arrWear = []

    for (i = 0; i < 29; i++) {
      if(i < 6){
        arrHeart.push(strHeartPath +i+".png")
        arrCo.push(strCoPath +i+".png")
        arrStep.push(strStepPath +i+".png")
        arrCen.push(strCenPath +i+".png")
      }
      if(i < 10){
        arrTime.push(strTimePath+i+".png")
      }
      arrWear.push(strWearPath+i+".png")
    }

    // const logger = DeviceRuntimeCore.HmLogger.getLogger("defult");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({

      changeClick(options){
        let { x, y, w, h, type} = options
        let click = hmUI.createWidget(hmUI.widget.IMG_CLICK,{
          x: x,
          y: y,
          w: w,
          h: h,
          type: type,
        })
      },
      changeClickAg(options){
        let { x, y, w, h, type} = options
        let click = hmUI.createWidget(hmUI.widget.IMG_CLICK,{
          x: x,
          y: y,
          w: w,
          h: h,
          type: type,
          radius:10,
          angle: 45
        })
      },

      init_view() {

        var animDemo = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
          x: 0,
          y: 0,
          anim_path: strRootPath + "bg",
          anim_prefix: "anim",
          anim_ext: "png",
          anim_fps: 25,
          anim_size: 4,
          repeat_count: 1,
          anim_repeat: true,
          anim_status: hmUI.anim_status.START,
          display_on_restart: false,
          show_level: hmUI.show_level.ONLY_NORMAL

        });
        //设置动画状态
        animDemo.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.PAUSE)

        batter_img = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 0,
          y: 0,
          image_array: arrCen,
          image_length: arrCen.length,
          type: hmUI.data_type.BATTERY,
          show_level: hmUI.show_level.ONLY_NORMAL
        });
        step_img = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 0,
          y: 0,
          image_array: arrStep,
          image_length: arrStep.length,
          // type: hmUI.data_type.WEATHER,
          type: hmUI.data_type.STEP,
          show_level: hmUI.show_level.ONLY_NORMAL
        });
        cal_img = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 0,
          y: 0,
          image_array: arrHeart,
          image_length: arrHeart.length,
          type: hmUI.data_type.CAL,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        heart_img = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 0,
          y: 0,
          image_array: arrCo,
          image_length: arrCo.length,
          type: hmUI.data_type.HEART,
          show_level: hmUI.show_level.ONLY_NORMAL
        });


        humidity_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
          center_x: 373*0.9708,
          center_y: 243*0.9708,
          x: 13*0.9708,
          y: 64*0.9708,
          src: strPointerPath + "dot.png",
          type: hmUI.data_type.HUMIDITY,
          start_angle: -45,
          end_angle: 215,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });


        weather_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
          center_x: 110*0.9708,
          center_y: 242*0.9708,
          x: 13*0.9708,
          y: 62*0.9708,
          src: strPointerPath + "dot.png",
          type: hmUI.data_type.WEATHER_CURRENT,
          start_angle: 125,
          end_angle: 415,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });


        uvi_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
          center_x: 240*0.9708,
          center_y: 370*0.9708,
          x: 13*0.9708,
          y: 62*0.9708,
          src: strPointerPath + "dot.png",
          type: hmUI.data_type.UVI,
          start_angle: 35,
          end_angle: 325,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        pai_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
          center_x: 240*0.9708,
          center_y: 112*0.9708,
          x: 13*0.9708,
          y: 62*0.9708,
          src: strPointerPath + "dot.png",
          type: hmUI.data_type.PAI_WEEKLY,
          start_angle: 215,
          end_angle: 505,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        paiText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 200*0.9708,
          y: 96*0.9708,
          w: 80,
          type: hmUI.data_type.PAI_DAILY,
          font_array: arrTime,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NORMAL,
          invalid_image: strTimePath + "null.png",
          // padding:true
        });
        uviText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 201*0.9708,
          y: 356*0.9708,
          w: 80,
          type: hmUI.data_type.UVI,
          font_array: arrTime,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NORMAL,
          invalid_image: strTimePath + "null.png",
          // padding:!0
        });
        weatherText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 73*0.9708,
          y: 228*0.9708,
          w: 80,
          type: hmUI.data_type.WEATHER_CURRENT,
          font_array: arrTime,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          unit_sc: strTimePath + "10.png",
          unit_tc: strTimePath + "10.png",
          unit_en: strTimePath + "10.png",
          negative_image: strTimePath + "11.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
          invalid_image: strTimePath + "null2.png",
          // padding:!0
        });
        humidityText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 332*0.9708,
          y: 228*0.9708,
          w: 80,
          type: hmUI.data_type.HUMIDITY,
          font_array: arrTime,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          // unit_sc: strTimePath + "12.png",
          // unit_tc: strTimePath + "12.png",
          // unit_en: strTimePath + "12.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
          invalid_image: strTimePath + "null.png",
          // padding:!0
        });

        timePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_centerX: 233,
          hour_centerY: 233,
          hour_posX: 59,
          hour_posY: 233,
          hour_path: strPointerPath + "hour.png",
          minute_centerX: 233,
          minute_centerY: 233,
          minute_posX: 60,
          minute_posY: 233,
          minute_path: strPointerPath + "min.png",
          second_centerX: 233,
          second_centerY: 233,
          second_posX: 12,
          second_posY: 217,
          second_path: strPointerPath + "s.png",
          show_level: hmUI.show_level.ONLY_NORMAL
        })

        timePointer1 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_centerX: 233,
          hour_centerY: 233,
          hour_posX: 59,
          hour_posY: 233,
          hour_path: strPointerPath + "hour.png",
          minute_centerX: 233,
          minute_centerY: 233,
          minute_posX: 60,
          minute_posY: 233,
          minute_path: strPointerPath + "min.png",
          show_level: hmUI.show_level.ONAL_AOD
        })

        bg_img1 = hmUI.createWidget(hmUI.widget.IMG, {
          x: 226*0.9708,
          y: 226*0.9708,
          src: strPointerPath + "z.png",
          show_level: hmUI.show_level.ONAL_AOD
        })

        //点击pai组件跳转
        this.changeClick({ x: 220*0.9708, y: 90*0.9708, w: 40, h: 80, type: hmUI.data_type.PAI_WEEKLY})
        //点击uvi组件跳转
        this.changeClick({ x: 220*0.9708, y: 306*0.9708, w: 40, h: 85, type: hmUI.data_type.UVI})
        //点击天气组件跳转
        this.changeClick({ x: 88*0.9708, y: 215*0.9708, w: 80, h: 50, type: hmUI.data_type.WEATHER_CURRENT})
        //点击湿度组件跳转
        this.changeClick({  x: 312*0.9708, y: 215*0.9708, w: 80, h: 50, type: hmUI.data_type.HUMIDITY})

        //点击bat组件跳转
        this.changeClickAg({ x: 60*0.9708, y: 60*0.9708, w: 70, h: 70, type: hmUI.data_type.BATTERY})
        //点击step组件跳转
        this.changeClickAg({ x: 55*0.9708, y: 335*0.9708, w: 80, h: 75, type: hmUI.data_type.STEP})
        //点击Heart组件跳转
        this.changeClickAg({ x: 327*0.9708,y: 65*0.9708, w: 80, h: 60, type: hmUI.data_type.HEART})
         //点击cal组件跳转
        this.changeClickAg({ x: 327*0.9708, y: 330*0.9708, w: 80, h: 80, type: hmUI.data_type.CAL})


      },

      onInit() {
        console.log('index page.js on init invoke');

        this.init_view();


      },

      onReady() {
        console.log('index page.js on ready invoke')
      },

      onShow() {
        console.log('index page.js on show invoke')
      },

      onHide() {
        console.log('index page.js on hide invoke')
      },

      onDestory() {
        console.log('index page.js on destory invoke')
      },
    });
    /*
    * end js
    */
  })()
} catch (e) {
  console.log(e)
}
