try {
    (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;

        var __$$module$$__ = __$$app$$__.current;
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        /*
    * huamiOS bundle tool v1.0.17
    * Copyright © Huami. All Rights Reserved
    */
        'use strict';

        console.log("----->>>current")
        console.log(__$$hmAppManager$$__.currentApp.pid)
        console.log(__$$hmAppManager$$__.currentApp.current)

        let rootPath = null  


        let img_bg = null
        let mask_bg = null
       

        let jstime = null


        let editGroup = null
        let centerIcon = null
        let centerText = null
        let nCenter = 233
        rootPath = "images/"
        weekRootPath = rootPath + "week/"
        let arrWeek = []
        let arrData = []
        for (let i = 1; i < 8; i++) {
            arrWeek.push(weekRootPath + "week_" + i + ".png")
        }     
        for (let i = 0; i < 10; i++) {
            arrData.push(rootPath + "data/data_" + i + ".png")
        }  

        let edit_list_config = { //编辑列表配置
            title_font_size :34 ,  
            title_align_h: hmUI.align.CENTER_H ,
            list_item_vspace: 8 ,
            list_bg_color : 0x000000,
            list_bg_radius: 30,
            list_group_text_font_size: 32,
            list_group_text_align_h: hmUI.align.CENTER_H,
            list_tips_text_font_size: 32,
            list_tips_text_align_h : hmUI.align.LEFT,
            // list_group_text_align_h: hmUI.align.CENTER_H,
        };

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

            init_view() {
                img_bg = hmUI.createWidget(hmUI.widget.IMG, {
                    show_level: hmUI.show_level.ALL,
                });
                var screenType = hmSetting.getScreenType();
                if (screenType == hmSetting.screen_type.AOD) {
                    img_bg.setProperty(hmUI.prop.MORE, {
                        x: 0,
                        y: 0,
                        w: 466,
                        h: 466,
                        src: rootPath + "img/bg_xp.png",
                        show_level: hmUI.show_level.ALL,
                    });
                    weekLevel = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                        x: 190,
                        y: 117,
                        week_sc: arrWeek,/*  */
                        week_tc: arrWeek,
                        week_en: arrWeek,
                        show_level: hmUI.show_level.ALL,
                    });

                    day_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
                        day_startX: 255,
                        day_startY: 117,
                        day_en_array: arrData,
                        day_sc_array: arrData,
                        day_tc_array: arrData,
                        day_space: 0,
                        day_zero: 1,
                        // day_is_character:true,
                        day_align: hmUI.align.LEFT,
                        show_level: hmUI.show_level.ALL,
                    });

                    timePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                        hour_centerX: 233,
                        hour_centerY: 233,
                        hour_posX: 6,
                        hour_posY: 136,
                        hour_path: rootPath + "time/hour.png",

                        minute_centerX: 233,
                        minute_centerY: 233,
                        minute_posX: 11,
                        minute_posY: 212,
                        minute_path: rootPath + "time/min_xp.png",
                        show_level: hmUI.show_level.ONAL_AOD,
                    });
                } else if (screenType == hmSetting.screen_type.WATCHFACE) {
                    img_bg.setProperty(hmUI.prop.MORE, {
                        x: 0,
                        y: 0,
                        w: 466,
                        h: 466,
                        src: rootPath + "img/bg.png",
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                    mask_bg = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 0,
                        y: 0,
                        w: 466,
                        h: 466,
                        src: rootPath + "img/maskBg.png",
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                    centerText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        show_level: hmUI.show_level.ALL,

                    });
                    centerIcon = hmUI.createWidget(hmUI.widget.IMG, {
                        show_level: hmUI.show_level.ALL,
                    });
                    weekLevel = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                        x: 190,
                        y: 117,
                        week_sc: arrWeek,
                        week_tc: arrWeek,
                        week_en: arrWeek,
                        show_level: hmUI.show_level.ALL,
                    });

                    day_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
                        day_startX: 255,
                        day_startY: 117,
                        day_en_array: arrData,
                        day_sc_array: arrData,
                        day_tc_array: arrData,
                        day_space: 0,
                        day_zero: 1,
                        // day_is_character:true,
                        day_align: hmUI.align.LEFT,
                        show_level: hmUI.show_level.ALL,
                    });
                    timePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                        hour_centerX: nCenter,
                        hour_centerY: nCenter,
                        hour_posX: 6,
                        hour_posY: 136,
                        hour_path: rootPath + "time/hour.png",

                        minute_centerX: nCenter,
                        minute_centerY: nCenter,
                        minute_posX: 11,
                        minute_posY: 212,
                        minute_path: rootPath + "time/min_xp.png",

                        second_centerX: nCenter,
                        second_centerY: nCenter,
                        second_posX: 11,
                        second_posY: 228,
                        second_path: rootPath + "time/sec.png",
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                    jstime = hmSensor.createSensor(hmSensor.id.TIME);

                    // 监听事件
                    jstime.addEventListener(jstime.event.MINUTEEND, function () {
                        //console.log("time minute change"+jstime.minute);
                        var min = jstime.minute;
                        if (min == 0) {
                            setBgAngle(jstime.hour);
                        }
                    });
                    // 创建传感器
                    setBgAngle(jstime.hour);

                    function setBgAngle(currentHour) {
                        switch (currentHour) {
                            case 12:
                            case 24:
                            case 0:
                                maskBgRotation(0);
                                break;
                            case 13:
                            case 1:
                                maskBgRotation(30);
                                break;
                            case 14:
                            case 2:
                                maskBgRotation(60);
                                break;
                            case 15:
                            case 3:
                                maskBgRotation(90);
                                break;
                            case 16:
                            case 4:
                                maskBgRotation(120);
                                break;
                            case 17:
                            case 5:
                                maskBgRotation(150);
                                break;
                            case 18:
                            case 6:
                                maskBgRotation(180);
                                break;
                            case 19:
                            case 7:
                                maskBgRotation(210);
                                break;
                            case 20:
                            case 8:
                                maskBgRotation(240);
                                break;
                            case 21:
                            case 9:
                                maskBgRotation(270);
                                break;
                            case 22:
                            case 10:
                                maskBgRotation(300);
                                break;
                            case 23:
                            case 11:
                                maskBgRotation(330);
                                break;

                        }
                    }

                    function maskBgRotation(angle) {
                        // mask_bg.setProperty(hmUI.prop.ANGLE,angle);
                        mask_bg.setProperty(hmUI.prop.MORE, {
                            x: 0,
                            y: 0,
                            w: 466,
                            h: 466,
                            center_x: 233,
                            center_y: 233,
                            src: rootPath + "img/maskBg.png",
                            angle: angle,
                        });
                    }
                }

                var editGroupX = 185;
                var editGroupY = 296;

                editGroup = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: 101,
                    x: editGroupX,
                    y: editGroupY,
                    w: 95,
                    h: 95,
                    select_image: rootPath + "mask/selected.png",
                    un_select_image: rootPath + "mask/unselected.png",
                    default_type: hmUI.edit_type.HEART,
                    optional_types: [
                        { type: hmUI.edit_type.BATTERY, preview: rootPath + "preview/battery.png" },
                        { type: hmUI.edit_type.CAL, preview: rootPath + "preview/cal.png" },
                        { type: hmUI.edit_type.HEART, preview: rootPath + "preview/heart.png" },
                        { type: hmUI.edit_type.PAI_WEEKLY, preview: rootPath + "preview/pai.png" },
                        { type: hmUI.edit_type.STEP, preview: rootPath + "preview/step.png" },
                    ],
                    count: 5,
                    tips_BG: rootPath + "mask/text_tag.png",
                    tips_x: 182 - editGroupX,
                    tips_y: 100 ,
                    tips_width: 100,
                    tips_margin: 10,
                    select_list: edit_list_config,
                });
                //通过这个函数来获取当前的保存的数据项类型来绘制组件
                var leftType = editGroup.getProperty(hmUI.prop.CURRENT_TYPE);
                let objGroup = {}
                switch (leftType) {
                    case hmUI.edit_type.PAI_WEEKLY:
                        objGroup.type = hmUI.data_type.PAI_WEEKLY
                        centerIcon.setProperty(hmUI.prop.MORE, {
                            x: 210,
                            y: 300,
                            // w: 46,
                            // h: 46,
                            src: rootPath + "icon/pai.png",
                        });

                        centerText.setProperty(hmUI.prop.MORE, {
                            x: 184,
                            y: 352,
                            w: 100,
                            type: hmUI.data_type.PAI_WEEKLY,
                            font_array: arrData,
                            h_space: 0, //图片间隔
                            align_h: hmUI.align.CENTER_H,
                            padding: false, //是否补零 true为补零
                        });
                        break;
                    case hmUI.edit_type.CAL:
                        objGroup.type = hmUI.data_type.CAL
                        centerIcon.setProperty(hmUI.prop.MORE, {
                            x: 212,
                            y: 300,
                            // w: 46,
                            // h: 46,
                            src: rootPath + "icon/cal.png",
                        });

                        centerText.setProperty(hmUI.prop.MORE, {
                            x: 160,
                            y: 352,
                            w: 150,
                            type: hmUI.data_type.CAL,
                            font_array: arrData,
                            h_space: 0, //图片间隔
                            align_h: hmUI.align.CENTER_H,
                            padding: false, //是否补零 true为补零
                        });
                        break;
                    case hmUI.edit_type.BATTERY:
                        objGroup.type = hmUI.data_type.BATTERY
                        centerIcon.setProperty(hmUI.prop.MORE, {
                            x: 213,
                            y: 300,
                            // w: 46,
                            // h: 46,
                            src: rootPath + "icon/battery.png",
                        });

                        centerText.setProperty(hmUI.prop.MORE, {
                            x: 190,
                            y: 352,
                            w: 100,
                            type: hmUI.data_type.BATTERY,
                            font_array: arrData,
                            h_space: 0, //图片间隔
                            align_h: hmUI.align.CENTER_H,
                            unit_sc: rootPath + "img/per.png",//单位
                            unit_tc: rootPath + "img/per.png",//单位
                            unit_en: rootPath + "img/per.png",//单位
                            invalid_image: rootPath + "img/invalid.png",
                            padding: false, //是否补零 true为补零
                        });
                        break;
                    case hmUI.edit_type.HEART:
                        objGroup.type = hmUI.data_type.HEART
                        centerIcon.setProperty(hmUI.prop.MORE, {
                            x: 213,
                            y: 300,
                            // w: 46,
                            // h: 46,
                            src: rootPath + "icon/heart.png",
                        });

                        centerText.setProperty(hmUI.prop.MORE, {
                            x: 185,
                            y: 352,
                            w: 100,
                            type: hmUI.data_type.HEART,
                            font_array: arrData,
                            h_space: 0, //图片间隔
                            align_h: hmUI.align.CENTER_H,
                            invalid_image: rootPath + "img/invalid.png",
                            padding: false, //是否补零 true为补零
                        });
                        break;
                    case hmUI.edit_type.STEP:
                        objGroup.type = hmUI.data_type.STEP
                        centerIcon.setProperty(hmUI.prop.MORE, {
                            x: 213,
                            y: 300,
                            // w: 46,
                            // h: 46,
                            src: rootPath + "icon/step.png",
                        });
                        centerText.setProperty(hmUI.prop.MORE, {
                            x: 160,
                            y: 352,
                            w: 150,
                            type: hmUI.data_type.STEP,
                            font_array: arrData,
                            h_space: 0, //图片间隔
                            align_h: hmUI.align.CENTER_H,
                            padding: false, //是否补零 true为补零
                        });
                        break;
                }
                function jumpApp(x ,y ,w ,h ,type){
                    hmUI.createWidget(hmUI.widget.IMG_CLICK,{
                      x, y, w, h, type //type必写 跳转的action
                      });
                  }    
                  //-----------------跳转应用执行----------------
                  if(objGroup.type){
                    jumpApp(206,294,58,79,objGroup.type)           
                  }
                //component  
                maskCover = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK, {
                    x: 0,
                    y: 0,
                    w: 466,
                    h: 466,
                    src: rootPath + "mask/mask100.png",
                    show_level: hmUI.show_level.ONLY_EDIT,
                });

                mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
                    x: 0,
                    y: 0,
                    w: 466,
                    h: 466,
                    src: rootPath + "mask/mask70.png",
                    show_level: hmUI.show_level.ONLY_EDIT,
                });

                const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: (function () {
                        setBgAngle(jstime.hour);
                    }),
                    pause_call: (function () {
                        //console.log('ui pause');
                    }),

                });
            },

            onInit() {
                console.log('index page.js on init invoke')

                this.init_view();

            },

            onReady() {
                console.log('index page.js on ready invoke')
            },

            onShow() {
                console.log('index page.js on show invoke')
            },

            onHide() {
                console.log('index page.js on hide invoke')
            },

            onDestory() {
                console.log('index page.js on destory invoke')
            },
        });
        /*
        * end js
        */
    })()
} catch (e) {
    console.log(e)
}
