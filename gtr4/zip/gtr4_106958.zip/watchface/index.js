try {
  (() => {

    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

    /*
  * huamiOS bundle tool v1.0.17
  * Copyright © Huami. All Rights Reserved
  */
    'use strict';

    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let strRootPath = "images/";
    let strStepPath = strRootPath + "step/";
    let strTimePath = strRootPath + "time/";
    let arrFont = [];
    let arrTime = [];
    let arrWeekEn = [];
    let arrWeekSc = [];
    let arrFish = [];
    for (let i = 0; i < 10; i++) {
      arrFont.push(strStepPath + `font` + i + ".png");
      arrTime.push(strTimePath + `time_` + i + ".png");
      arrFish.push(strRootPath + `fishlength/` + i + ".png");
    }
    for (let i = 1; i < 8; i++) {
      arrWeekEn.push(strRootPath + `week/en/` + i + ".png");
      arrWeekSc.push(strRootPath + `week/tc/` + i + ".png");
    }
    let objBg = {
      x: 0,
      y: 0,
      w: 466,
      h: 466,
      src: "images/bg.png",
      show_level: hmUI.show_level.ONLY_NORMAL
    };
    let objAnim = {
      x: 0,
      y: 0,
      anim_path: strRootPath + "bg/water",
      anim_prefix: "water",
      anim_ext: "png",
      anim_fps: 24,
      anim_size: 48,
      repeat_count: 1, //0位无限重复
      anim_repeat: true,//是否重复
      anim_status: hmUI.anim_status.START,
      // display_on_restart: true,//从息屏到亮屏是否自动重复播放
      // anim_complete_call:animCall,//动画结束回调 无限重复永远不会调用到
      show_level: hmUI.show_level.ONLY_NORMAL
    };
    let objBatteryBg = {
      x: 193,
      y: 32,
      src: `images/battery/0.png`,
      show_level: hmUI.show_level.ONLY_NORMAL
    };
    let objBatteryIcon = {
      x: 161,
      y: 32,
      src: `images/step/battery.png`,
      show_level: hmUI.show_level.ONLY_NORMAL
    };

    let objTime = {
      hour_zero: 1, //是否补零
      hour_startX: 74,
      hour_startY: 81,
      hour_array: arrTime,
      hour_space: 10, //每个数组间的间隔
      minute_zero: 1, //是否补零
      minute_startX: 250,
      minute_startY: 81,
      minute_array: arrTime,
      minute_space: 10, //每个数组间的间隔
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
    };
    let objBatteryText = {
      x: 252,
      y: 33,
      type: hmUI.data_type.BATTERY,
      font_array: arrFont,
      h_space: 1,
      align_h: hmUI.align.LEFT,
      unit_sc: "images/unit/baifenhao.png",
      unit_tc: "images/unit/baifenhao.png",
      unit_en: "images/unit/baifenhao.png",
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    let objTimeUnit = {
      x: 200,
      y: 78,
      src: strTimePath + "maohao.png",
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
    };
    let objDate = {
      month_startX: 70,
      month_startY: 185,
      month_unit_sc: "images/unit/fenhao.png", //单位
      month_unit_tc: "images/unit/fenhao.png",
      month_unit_en: "images/unit/fenhao.png",
      month_align: hmUI.align.LEFT,
      month_space: 0,//文字间隔
      month_zero: true,//是否补零
      month_en_array: arrFont,
      month_sc_array: arrFont,
      month_tc_array: arrFont,
      day_follow: 1,//是否跟随
      day_align: hmUI.align.LEFT,
      day_space: 0,//文字间隔
      day_zero: true,//是否补零
      day_en_array: arrFont,
      day_sc_array: arrFont,
      day_tc_array: arrFont,
      show_level: hmUI.show_level.ONLY_NORMAL
    };
    let objStep = {
      x: 210,
      y: 185,
      w: 150,
      type: hmUI.data_type.STEP,
      font_array: arrFont,
      h_space: 0,
      align_h: hmUI.align.RIGHT,

      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    let objStepIcon = {
      x: 370,
      y: 184,
      src: `images/step/step.png`,
      show_level: hmUI.show_level.ONLY_NORMAL
    };
    let objStepJump = {
      x: 289,
      y: 180,
      w: 110,
      h: 34,
      type: hmUI.data_type.STEP, //必写 跳转的action
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    let objWeek = {
      x: 150,
      y: 184,
      week_en: arrWeekEn,
      week_tc: arrWeekSc,
      week_sc: arrWeekSc,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    //------------完成界面配置start-------------------
    let objFillBg = {
      x: -2,
      y: -2,
      w: 470,
      h: 470,
      radius: 470 / 2,
      color: 0x000000,
    };
    let objbgLight = {
      x: 0,
      y: 0,
      src: "images/bg_light.png",
    };

    //------------完成界面配置end---------------------
    let battery = hmSensor.createSensor(hmSensor.id.BATTERY);
    let battery_rect;
    function setBattery(battery) {
      let batteryCurrent = battery.current;
      // batteryCurrent = 10; //调试
      let batw = 30 * (batteryCurrent / 100);
      let color;
      if (batteryCurrent <= 15) {
        color = 0xff0000;
      } else {
        color = 0xffffff;
      }
      battery_rect.setProperty(hmUI.prop.MORE, {
        x: 197,
        y: 37,
        w: batw,
        h: 13,
        color
      });
    }
    let vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);//震动传感器
    vibrate.stop();
    let flag = false;
    const logger = DeviceRuntimeCore.HmLogger.getLogger("defult");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        //--------------------非交互区域----------------------
        hmUI.createWidget(hmUI.widget.IMG_ANIM, objAnim);
        hmUI.createWidget(hmUI.widget.IMG, objBg);
        hmUI.createWidget(hmUI.widget.IMG, objBatteryBg);
        hmUI.createWidget(hmUI.widget.IMG, objBatteryIcon);
        battery_rect = hmUI.createWidget(hmUI.widget.FILL_RECT, {
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        setBattery(battery);
        battery.addEventListener(hmSensor.event.CHANGE, function () {
          setBattery(battery);
        });
        hmUI.createWidget(hmUI.widget.TEXT_IMG, objBatteryText);
        hmUI.createWidget(hmUI.widget.IMG_TIME, objTime);
        hmUI.createWidget(hmUI.widget.IMG, objTimeUnit);
        hmUI.createWidget(hmUI.widget.IMG_DATE, objDate);
        hmUI.createWidget(hmUI.widget.IMG_WEEK, objWeek);
        hmUI.createWidget(hmUI.widget.IMG, objStepIcon);
        hmUI.createWidget(hmUI.widget.TEXT_IMG, objStep);
        hmUI.createWidget(hmUI.widget.IMG_CLICK, objStepJump);
        hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: (function () {
            setBattery(battery);
            console.log('ui resume');
          }),
          pause_call: (function () {
            console.log('ui pause');
          }),
        });
        let animFishing = hmUI.createWidget(hmUI.widget.IMG_ANIM, { //鱼咬钩动画
          x: 40,
          y: 230,
          anim_path: "images/bg/fishing",
          anim_prefix: "fishing",
          anim_ext: "png",
          anim_fps: 24,
          anim_size: 48,
          anim_repeat: true,
          repeat_count: 1,
          anim_status: 1,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        //-------------------------------------------------------
        let btn = hmUI.createWidget(hmUI.widget.IMG, { //按钮背景
          x: 185,
          y: 315,
          src: "images/btn/button.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        let btnPlay = hmUI.createWidget(hmUI.widget.IMG, {  //按钮上的三角图
          x: 204,
          y: 330,
          src: "images/btn/play.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        let animCreate = hmUI.createWidget(hmUI.widget.IMG_ANIM, { //点击按钮后3秒倒计时动画
          x: 202,
          y: 330,
          anim_path: "images/play",
          anim_prefix: "game",
          anim_ext: "png",
          anim_fps: 1,
          anim_size: 3,
          anim_repeat: false,
          repeat_count: 1,
          anim_complete_call: animateShow,  //3秒倒计时动画结束后、隐藏按钮以及背景、开始甩杆动画
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        animCreate.setProperty(hmUI.prop.VISIBLE, false);//隐藏倒计时动画控件
        btnPlay.addEventListener(hmUI.event.CLICK_UP, (function (info) {//按钮事件
          btnPlay.setProperty(hmUI.prop.VISIBLE, false); //按钮三角隐藏
          animCreate.setProperty(hmUI.prop.VISIBLE, true); //显示3秒倒计时动画（是否可以移除）
          animCreate.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.START);//播放三秒倒计时开始
          hmSetting.setBrightScreen(200); //开始钓鱼后屏幕常亮200秒
        }));
        let objAnimThrow = hmUI.createWidget(hmUI.widget.IMG_ANIM, {//甩杆动画控件
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        let objAnimBite = hmUI.createWidget(hmUI.widget.IMG_ANIM, {//上钩动画控件
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        objAnimThrow.setProperty(hmUI.prop.VISIBLE, false); //隐藏甩杆动画（是否可以移除）
        objAnimBite.setProperty(hmUI.prop.VISIBLE, false); ////隐藏上钩动画（是否可以移除）
        //--------------------钓鱼失败界面开始--------------------
        let failBg = hmUI.createWidget(hmUI.widget.IMG, {//脱钩背景图
          x: 0,
          y: 0,
          src: `images/mask.png`,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        let failAnim = hmUI.createWidget(hmUI.widget.IMG_ANIM, {//脱钩动画控件
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        failBg.setProperty(hmUI.prop.VISIBLE, false);//隐藏脱钩背景
        failAnim.setProperty(hmUI.prop.VISIBLE, false); //隐藏脱钩动画
        //--------------------钓鱼失败界面结束--------------------
        let objAnimClick = hmUI.createWidget(hmUI.widget.IMG_ANIM, {//小手引导点击动画控件
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        // let btnResBg, btnRes;
        let fillBg = hmUI.createWidget(hmUI.widget.FILL_RECT, {//成功上钩底色背景控件
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        let bgLight = hmUI.createWidget(hmUI.widget.IMG, {//成功上钩背景控件
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        let animRetractor = hmUI.createWidget(hmUI.widget.IMG_ANIM, {//成功上钩动画控件
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        let mathNum = hmUI.createWidget(hmUI.widget.TEXT_IMG, {//鱼线长度控件
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        //--------------------重新开始按钮--------------------
        let btnResBg = hmUI.createWidget(hmUI.widget.IMG, {//重新开始背景图片
          x: 253,
          y: 315,
          src: "images/btn/button.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        let btnRes = hmUI.createWidget(hmUI.widget.IMG, {//重新开始图片
          x: 270,
          y: 330,
          src: "images/btn/return.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let btnStopBg = hmUI.createWidget(hmUI.widget.IMG, {//重新开始背景图片
          x: 117,
          y: 315,
          src: "images/btn/button.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        let btnStop = hmUI.createWidget(hmUI.widget.IMG, {//重新开始图片
          x: 135,
          y: 330,
          src: "images/btn/stop.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        btnResBg.setProperty(hmUI.prop.VISIBLE, false); //隐藏重新开始按钮
        btnRes.setProperty(hmUI.prop.VISIBLE, false);//隐藏重新开始按钮
        btnStopBg.setProperty(hmUI.prop.VISIBLE, false); //隐藏重新开始按钮
        btnStop.setProperty(hmUI.prop.VISIBLE, false);//隐藏重新开始按钮
        //--------------------重新开始按钮--------------------
        fillBg.setProperty(hmUI.prop.VISIBLE, false);//隐藏成功界面控件
        bgLight.setProperty(hmUI.prop.VISIBLE, false);//隐藏成功界面控件
        animRetractor.setProperty(hmUI.prop.VISIBLE, false);//隐藏成功界面控件
        mathNum.setProperty(hmUI.prop.VISIBLE, false);//隐藏成功界面控件
        objAnimClick.setProperty(hmUI.prop.VISIBLE, false); //小手引导点击动画控件
        //-----------------------------方法↓----------------------------
        function animateShow() { //3秒倒计时动画结束后执行的函数、隐藏按钮以及背景、鱼咬钩动画、开始甩杆动画
          btn.setProperty(hmUI.prop.VISIBLE, false);
          animCreate.setProperty(hmUI.prop.VISIBLE, false);
          animFishing.setProperty(hmUI.prop.VISIBLE, false);
          animFishing.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.STOP);//停止咬钩动画
          animThrow(); //开始甩杆动画
        }
        function animThrow() { //甩杆动画  不循环播放
          objAnimThrow.setProperty(hmUI.prop.VISIBLE, true); //显示甩杆动画控件
          objAnimThrow.setProperty(hmUI.prop.MORE, { //更改甩杆动画属性
            x: 0,
            y: 120,
            anim_path: "images/bg/throw",
            anim_prefix: "s",
            anim_ext: "png",
            anim_fps: 24,
            anim_size: 48,
            anim_repeat: false,
            repeat_count: 1,
            anim_status: 1,
            anim_complete_call: animBite, //回调鱼上钩动画
          });
        };

        function animBite() { //鱼上钩动画
          let clockTimer1 = null;
          let clockTimer = null;
          clockTimer1 = timer.createTimer(  //上钩动画
            3000, 1000, (function (option) {
              timer.stopTimer(clockTimer1);
              clockTimer1 = null;
              objAnimThrow.setProperty(hmUI.prop.VISIBLE, false);  //隐藏甩杆动画
              objAnimThrow.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.STOP);//停止甩杆动画
              objAnimBite.setProperty(hmUI.prop.VISIBLE, true); //显示上钩动画控件
              objAnimBite.setProperty(hmUI.prop.MORE, { //上钩动画更改属性
                x: 40,
                y: 230,
                anim_path: "images/bg/bite",
                anim_prefix: "bite",
                anim_ext: "png",
                anim_fps: 24,
                anim_size: 48,
                // anim_repeat: false,
                anim_repeat: true,
                repeat_count: 1,
                anim_status: 1,
              });
              vibrate.start();//轻震动
              flag = true;
              objAnimBite.addEventListener(hmUI.event.CLICK_UP, (function (info) {//动画点击事件
                flag = false;//控制引导点击动画开关（true展示）
                vibrate.stop();//停止震动（不停止无法再次开启）
                objAnimBite.setProperty(hmUI.prop.VISIBLE, false);//隐藏上钩动画
                objAnimBite.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.STOP);//停止上钩动画（上钩动画为重复播放）
                random();
              }));
            }),
            {});

          clockTimer = timer.createTimer(  //延时展示引导点击动画，在鱼咬钩动画执行3秒后未点击屏幕，执行该动画，点击屏幕则不执行
            6000, 6000, (function (option) {
              timer.stopTimer(clockTimer);
              clockTimer = null;
              if (flag) {
                animClick();
              }
              //  vibrate.stop()
            })
            , {});
        }
        function animClick() {//引导点击函数
          objAnimClick.setProperty(hmUI.prop.VISIBLE, true);//显示引导点击动画控件
          objAnimClick.setProperty(hmUI.prop.MORE, { //设置引导点击动画控件属性 重复播放
            x: 143,
            y: 220,
            anim_path: "images/bg/click",
            anim_prefix: "anim",
            anim_ext: "png",
            anim_fps: 24,
            anim_size: 49,
            anim_repeat: true,
            repeat_count: 1,
            anim_status: 1,
          });
          objAnimClick.addEventListener(hmUI.event.CLICK_UP, (function (info) {  //引导动画点击事件
            vibrate.stop();
            objAnimBite.setProperty(hmUI.prop.VISIBLE, false); //隐藏上钩动画
            objAnimClick.setProperty(hmUI.prop.VISIBLE, false); //隐藏引导点击动画
            objAnimBite.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.STOP);//停止上钩动画
            objAnimClick.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.STOP);//停止引导点击动画
            random();
          }));
        }
        function random() { //随机函数
          let chance = Math.floor(Math.random() * 10);
          if (chance < 4) {
            failAnim.setProperty(hmUI.prop.VISIBLE, false);
            fnAnimRetractor();
          } else {
            failAnim.setProperty(hmUI.prop.VISIBLE, true);
            failBg.setProperty(hmUI.prop.VISIBLE, true);
            failAnim.setProperty(hmUI.prop.MORE, { //空钩动画
              x: 0,
              y: 0,
              anim_path: "images/bg/fail",
              anim_prefix: "anim",
              anim_ext: "png",
              anim_fps: 24,
              anim_size: 30,
              anim_repeat: false,
              repeat_count: 1,
              anim_status: 1,
              anim_complete_call: fnFail, //鱼脱钩动画
            });
          }
        }
        function failHide() { //失败界面需要隐藏的  按钮 背景 动画
          btnRes.setProperty(hmUI.prop.VISIBLE, false);
          btnResBg.setProperty(hmUI.prop.VISIBLE, false);
          btnStopBg.setProperty(hmUI.prop.VISIBLE, false);
          btnStop.setProperty(hmUI.prop.VISIBLE, false);
          failBg.setProperty(hmUI.prop.VISIBLE, false);
          failAnim.setProperty(hmUI.prop.VISIBLE, false);
        }
        function fnFail() {  // 失败动画
          btnResBg.setProperty(hmUI.prop.VISIBLE, true);
          btnRes.setProperty(hmUI.prop.VISIBLE, true);
          btnStopBg.setProperty(hmUI.prop.VISIBLE, true);
          btnStop.setProperty(hmUI.prop.VISIBLE, true);
          btnStop.addEventListener(hmUI.event.CLICK_UP, (function (info) { //不玩了
            failHide()
            btn.setProperty(hmUI.prop.VISIBLE, true);
            btnPlay.setProperty(hmUI.prop.VISIBLE, true);
            animFishing.setProperty(hmUI.prop.VISIBLE, true);
            animFishing.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.START);
            hmSetting.setBrightScreenCancel(); //取消屏幕常亮
            // flag = true;
          }));
          btnRes.addEventListener(hmUI.event.CLICK_UP, (function (info) {
            failHide()
            objAnimThrow.setProperty(hmUI.prop.VISIBLE, true);
            objAnimThrow.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.START);
          }));
        }
        function fnAnimRetractor() { //最后完成界面
          fillBg.setProperty(hmUI.prop.VISIBLE, true);
          bgLight.setProperty(hmUI.prop.VISIBLE, true);
          animRetractor.setProperty(hmUI.prop.VISIBLE, true);
          fillBg.setProperty(hmUI.prop.MORE, objFillBg);
          bgLight.setProperty(hmUI.prop.MORE, objbgLight);
          animRetractor.setProperty(hmUI.prop.MORE, {
            x: 0,
            y: 0,
            anim_path: "images/bg/retractor",
            anim_prefix: "a",
            anim_ext: "png",
            anim_fps: 24,
            anim_size: 49,
            anim_repeat: false,
            repeat_count: 1,
            anim_status: 1,
            anim_complete_call: fnNum,
          });
          function groupHide() {//成功界面隐藏   停止按钮  重新开始按钮 随机数字 黑背景  光环图 上钩动画
            btnRes.setProperty(hmUI.prop.VISIBLE, false);
            btnResBg.setProperty(hmUI.prop.VISIBLE, false);
            btnStopBg.setProperty(hmUI.prop.VISIBLE, false);
            btnStop.setProperty(hmUI.prop.VISIBLE, false);
            mathNum.setProperty(hmUI.prop.VISIBLE, false);
            animRetractor.setProperty(hmUI.prop.VISIBLE, false);
            bgLight.setProperty(hmUI.prop.VISIBLE, false);
            fillBg.setProperty(hmUI.prop.VISIBLE, false);
            // objAnimBite.setProperty(hmUI.prop.VISIBLE, false);
          }
          function fnNum() {
            vibrate.start();//震动
            mathNum.setProperty(hmUI.prop.VISIBLE, true);
            mathNum.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 200,
              w: 466,
              text: Math.ceil(Math.random() * 1000) * Math.ceil(Math.random() * 10),
              font_array: arrFish,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              unit_sc: "images/fishlength/unit.png",
              unit_tc: "images/fishlength/unit.png",
              unit_en: "images/fishlength/unit.png",
            });
            var clockTimer1 = timer.createTimer(
              1500, 1000, (function (option) {
                timer.stopTimer(clockTimer1);
                btnResBg.setProperty(hmUI.prop.VISIBLE, true);
                btnRes.setProperty(hmUI.prop.VISIBLE, true);
                btnStopBg.setProperty(hmUI.prop.VISIBLE, true);
                btnStop.setProperty(hmUI.prop.VISIBLE, true);
                vibrate.stop();
                btnStop.addEventListener(hmUI.event.CLICK_UP, (function (info) {
                  groupHide()
                  //----------------------------从头开始-------------------------
                  btn.setProperty(hmUI.prop.VISIBLE, true);
                  btnPlay.setProperty(hmUI.prop.VISIBLE, true);
                  animFishing.setProperty(hmUI.prop.VISIBLE, true);
                  animFishing.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.START);
                  hmSetting.setBrightScreenCancel(); //取消屏幕常亮
                  // flag = true;
                }));
                btnRes.addEventListener(hmUI.event.CLICK_UP, (function (info) {
                  groupHide()
                  //----------------------------甩杆开始-------------------------
                  objAnimThrow.setProperty(hmUI.prop.VISIBLE, true);
                  objAnimThrow.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.START);
                  // flag = true;

                }));
              })
              , {});
          }
        }
      },

      onInit() {
        console.log('index page.js on init invoke');
        this.init_view();
      },
      onReady() {
        console.log('index page.js on ready invoke');
      },
      onShow() {
        console.log('index page.js on show invoke');
      },
      onHide() {
        console.log('index page.js on hide invoke');
      },
      onDestroy() {
        vibrate.stop();
        timer.stopTimer(clockTimer1);
        timer.stopTimer(clockTimer);
        clockTimer = null;
        clockTimer1 = null;
        console.log('index page.js on destory invoke');
      },
    });
    /*
    * end js
    */
  })();
} catch (e) {
  console.log(e);
}