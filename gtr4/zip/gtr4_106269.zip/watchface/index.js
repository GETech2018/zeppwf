try {
  (() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__),
      'drink'
    );
    /*
     * huamiOS bundle tool v1.0.17
     * Copyright © Huami. All Rights Reserved
     */
    ('use strict');

    console.log('----->>>current');
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    // 容器
    let weekArray = [];
    let dateArray = [];
    let date2Array = [];
    let dateEnArray = [];
    let monthArray = [];
    let month2Array = [];
    let monthEnArray = [];
    let timeArray = [];
    let batArr = [];
    let stepArr = [];

    // 路径及资源填充
    let rootPath = 'images/';

    for (let i = 0; i < 13; i++) {
      if (0 < i && i < 8) {
        weekArray.push(rootPath + 'week/' + i + '.png');
      }
      if (i < 10) {
        dateArray.push(rootPath + 'date/' + i + '.png');
        date2Array.push(rootPath + 'date2/' + i + '.png');
        dateEnArray.push(rootPath + 'date_en/' + i + '.png');
        monthArray.push(rootPath + 'month/' + i + '.png');
        month2Array.push(rootPath + 'month2/' + i + '.png');
        timeArray.push(rootPath + 'time/hour_' + i + '.png');
        stepArr.push(rootPath + 'step/' + i + '.png');
      }
      if (i > 0) {
        monthEnArray.push(rootPath + 'month_en/' + i + '.png');
      }
      if (i > 0 && i < 10) {
        batArr.push(rootPath + 'batProgress/bat_' + i + '.png');
      }
    }

    // 配置项
    let objTimeTxt = {
      am_x: 37 * 0.9708,
      am_y: 168 * 0.9708,
      am_sc_path: rootPath + 'ap/am2.png',
      am_en_path: rootPath + 'ap/am2.png',

      pm_x: 37 * 0.9708,
      pm_y: 168 * 0.9708,
      pm_sc_path: rootPath + 'ap/pm2.png',
      pm_en_path: rootPath + 'ap/pm2.png',
    };

    let objImg_bkg = {
      x: 0,
      y: 0,
      w: 466,
      h: 466,
      src: rootPath + 'img/bg.png',
    };

    let objMonthEn_img = {
      month_startX: 82 * 0.9708,
      month_startY: 132 * 0.9708,
      month_en_array: monthEnArray,
      month_sc_array: monthEnArray,
      month_tc_array: monthEnArray,
      month_is_character: true,
      month_space: 0,
      month_zero: 0,
      month_align: hmUI.align.RIGHT,
    };

    let objTimeTxt2 = {
      am_x: 37 * 0.9708,
      am_y: 175 * 0.9708,
      am_sc_path: rootPath + 'ap/am.png',
      am_en_path: rootPath + 'ap/am.png',

      pm_x: 37 * 0.9708,
      pm_y: 175 * 0.9708,
      pm_sc_path: rootPath + 'ap/pm.png',
      pm_en_path: rootPath + 'ap/pm.png',
    };

    let objWeek = {
      x: 155 * 0.9708,
      y: 15 * 0.9708,
      week_en: weekArray,
      week_tc: weekArray,
      week_sc: weekArray,
    };

    let objStep = {
      x: 294 * 0.9708,
      y: 311 * 0.9708,
      type: hmUI.data_type.STEP,
      font_array: stepArr,
      h_space: 0,
      align_h: hmUI.align.LEFT,
      padding: false, // 是否补零 true为补零
      isCharacter: true, // true为文字图片
      padding: true,
    };

    let objPow = {
      x: 292 * 0.9708,
      y: 403 * 0.9708,
      type: hmUI.data_type.BATTERY,
      font_array: stepArr,
      h_space: 0,
      align_h: hmUI.align.LEFT,
      padding: false, // 是否补零 true为补零
      isCharacter: true, // true为文字图片
      padding: true,
    };

    let objPointer = {
      hour_centerX: 233,
      hour_centerY: 233,
      hour_posX: 16,
      hour_posY: 158,
      hour_path: rootPath + 'img/hour.png',

      minute_centerX: 233,
      minute_centerY: 233,
      minute_posX: 14,
      minute_posY: 230,
      minute_path: rootPath + 'img/minute.png',

      second_centerX: 233,
      second_centerY: 233,
      second_posX: 11,
      second_posY: 226,
      second_path: rootPath + 'img/second.png',
    };

    let objCenter = {
      x: 224 * 0.98,
      y: 225 * 0.98,
      src: rootPath + 'img/cover.png',
    };
    // 热区跳转
    const objStepClick = {
      x: 270,
      y: 246,
      w: 160,
      h: 94,
      type: hmUI.data_type.STEP, //必写 跳转的action
    };

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        let jstime = hmSensor.createSensor(hmSensor.id.TIME);
        let screenType = hmSetting.getScreenType();
        let img_bkg = hmUI.createWidget(hmUI.widget.IMG, objImg_bkg);
        let h1 = hmUI.createWidget(hmUI.widget.IMG);
        let h2 = hmUI.createWidget(hmUI.widget.IMG);
        let m1 = hmUI.createWidget(hmUI.widget.IMG);
        let m2 = hmUI.createWidget(hmUI.widget.IMG);
        let d1 = hmUI.createWidget(hmUI.widget.IMG);
        let d2 = hmUI.createWidget(hmUI.widget.IMG);
        function setMinute() {
          let minute = jstime.minute;
          let first = parseInt(minute / 10);
          let second = minute % 10;
          let screenType = hmSetting.getScreenType();
          if (screenType == hmSetting.screen_type.AOD) {
            src1 = date2Array[second];
            src2 = month2Array[first];
          } else {
            src1 = dateArray[second];
            src2 = monthArray[first];
          }
          m1.setProperty(hmUI.prop.MORE, {
            x: 203 * 0.9708,
            y: 71 * 0.9708,
            src: src2,
          });
          m2.setProperty(hmUI.prop.MORE, {
            x: 338 * 0.9708,
            y: 71 * 0.9708,
            src: src1,
          });
        }
        function setHour() {
          let hour = jstime.format_hour;
          let first = parseInt(hour / 10);
          let second = hour % 10;
          let screenType = hmSetting.getScreenType();
          if (screenType == hmSetting.screen_type.AOD) {
            src1 = month2Array[second];
            src2 = month2Array[first];
          } else {
            src1 = monthArray[second];
            src2 = monthArray[first];
          }
          h1.setProperty(hmUI.prop.MORE, {
            x: 8 * 0.9708,
            y: 250 * 0.9708,
            src: src2,
          });
          h2.setProperty(hmUI.prop.MORE, {
            x: 8 * 0.9708 + 132,
            y: 250 * 0.9708,
            src: src1,
          });
        }
        function setDate() {
          let day = jstime.day;
          let first = parseInt(day / 10);
          let second = day % 10;
          d1.setProperty(hmUI.prop.MORE, {
            x: 88 * 0.9708,
            y: 204 * 0.9708,
            src: dateEnArray[first],
          });
          d2.setProperty(hmUI.prop.MORE, {
            x: 88 * 0.9708,
            y: 167 * 0.9708,
            src: dateEnArray[second],
          });
        }
        // jstime.event.MINUTEEND
        // const clockTimer = timer.createTimer(0, 1000, (function (option) {
        //   setHour()
        //   setMinute()
        // }), { })
        // jstime.addEventListener(jstime.event.HOURCHANGE, function () {
        //   setHour()
        // })
        jstime.addEventListener(jstime.event.MINUTECHANGE, function () {
          setMinute();
          if (jstime.minute == 0) {
            setHour;
          }
        });
        jstime.addEventListener(jstime.event.DAYCHANGE, function () {
          setDate();
        });
        const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: function () {
            console.log('ui resume');
            setDate();
            setMinute();
            setHour();
          },
          pause_call: function () {
            console.log('ui pause');
          },
        });
        if (screenType == hmSetting.screen_type.AOD) {
          img_bkg.setProperty(hmUI.prop.VISIBLE, false);
          d1.setProperty(hmUI.prop.VISIBLE, false);
          d2.setProperty(hmUI.prop.VISIBLE, false);
          let timeTxt = hmUI.createWidget(hmUI.widget.IMG_TIME, objTimeTxt); // AM PM
          // let month_img = hmUI.createWidget(hmUI.widget.IMG_TIME, objMonth_img)  // 小时
          // objm1Text.font_array = month2Array
          // objm2Text.font_array = date2Array
        } else {
          img_bkg.setProperty(hmUI.prop.VISIBLE, true);
          d1.setProperty(hmUI.prop.VISIBLE, true);
          d2.setProperty(hmUI.prop.VISIBLE, true);
          // let time_text = hmUI.createWidget(hmUI.widget.IMG_TIME, objTime_text) // 小时
          let monthEn_img = hmUI.createWidget(
            hmUI.widget.IMG_DATE,
            objMonthEn_img
          );
          timeTxt = hmUI.createWidget(hmUI.widget.IMG_TIME, objTimeTxt2); // am pm
          week = hmUI.createWidget(hmUI.widget.IMG_WEEK, objWeek);
          let step = hmUI.createWidget(hmUI.widget.TEXT_IMG, objStep);

          let pow = hmUI.createWidget(hmUI.widget.TEXT_IMG, objPow);
          timePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, objPointer);
          let center = hmUI.createWidget(hmUI.widget.IMG, objCenter);
          // 热区控件
          hmUI.createWidget(hmUI.widget.IMG_CLICK, objStepClick);
        }
      },

      onInit() {
        console.log('index page.js on init invoke');

        this.init_view();
      },

      onReady() {
        console.log('index page.js on ready invoke');
      },

      onShow() {
        console.log('index page.js on show invoke');
      },

      onHide() {
        console.log('index page.js on hide invoke');
      },

      onDestory() {
        console.log('index page.js on destory invoke');
        // timer.stopTimer(timerSupport)
      },
    });
    /*
     * end js
     */
  })();
} catch (e) {
  console.log(e);
}
