try {
  (() => {

    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

    /*
     * huamiOS bundle tool v1.0.17
     * Copyright © Huami. All Rights Reserved
     */
    'use strict';

    console.log("----->>>current")
    console.log(__$$hmAppManager$$__.currentApp.pid)
    console.log(__$$hmAppManager$$__.currentApp.current)
    /*params声明*/

    let strRootPath = "images/"
    let nX = 0
    let nY = 0
    let nW = 466
    let nH = 466
    let arrFont = []
    let arrWeather = []
    let arrTime = []
    let arrEnWeek = []
    let arrScWeek = []
    let editLeft = null
    let editRight = null
    let arrBlueMax = []
    let arrRedMax = []
    let arrBlueMin = []
    let arrRedMin = []
    let arrBat = []
    let jumpLeft, jumpRight
    let objBg = {
      x: nX,
      y: nY,
      w: nW,
      h: nH,
      src: strRootPath + "bg.png",
      show_level: hmUI.show_level.ONLY_NORMAL,
      // show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
    }
    let objBgAod = {
      x: nX,
      y: nY,
      w: nW,
      h: nH,
      src: strRootPath + "bgAOD.png",
      show_level: hmUI.show_level.ONAL_AOD,
      // show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
    }
    let objTime = {
      hour_zero: 1,
      hour_startX: 73,
      hour_startY: 183,
      hour_array: arrTime,
      hour_space: 1,
      hour_align: hmUI.align.CENTER_H,
      minute_zero: 1,
      minute_startX: 258,
      minute_startY: 183,
      minute_array: arrTime,
      minute_space: 1,
      minute_align: hmUI.align.CENTER_H,
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD,
      // show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
    }
    let objTimeAmPm = {
      am_x: 185,
      am_y: 26,
      am_sc_path: strRootPath + "time/am_sc.png",
      am_en_path: strRootPath + "time/am_en.png",
      pm_x: 185,
      pm_y: 26,
      pm_sc_path: strRootPath + "time/pm_sc.png",
      pm_en_path: strRootPath + "time/pm_en.png",
      show_level: hmUI.show_level.ONLY_NORMAL
    }
    let objDate = {
      month_startX: 158,
      month_startY: 301,
      month_align: hmUI.align.LEFT,
      month_space: 0,
      month_zero: 1,
      month_follow: 0,
      month_en_array: arrFont,
      month_sc_array: arrFont,
      month_tc_array: arrFont,
      month_unit_sc: strRootPath + "font/unit.png",
      month_unit_tc: strRootPath + "font/unit.png",
      month_unit_en: strRootPath + "font/unit.png",
      // day_startX: 197,
      // day_startY: 301,
      // day_align: hmUI.align.LEFT,
      day_space: 0,
      day_zero: 1,
      day_follow: 1,
      day_en_array: arrFont,
      day_sc_array: arrFont,
      day_tc_array: arrFont,
      show_level: hmUI.show_level.ONLY_NORMAL,
      // show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
    };
    let objWeek = {
      x: 239,
      y: 299,
      week_en: arrEnWeek,
      week_sc: arrScWeek,
      week_tc: arrScWeek,
      show_level: hmUI.show_level.ONLY_NORMAL,
      // show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,    //ONAL_AOD  or  ONLY_AOD
    };
    let objMask = {
      x: nX,
      y: nY,
      w: 466,
      h: 466,
      src: strRootPath + "bg_mask1.png",
      show_level: hmUI.show_level.ONLY_EDIT,
    };
    let edit_list_config = {
      title_font_size: 34,
      title_align_h: hmUI.align.CENTER_H,
      list_item_vspace: 8,
      list_bg_color: 0x0000,
      list_bg_radius: 30,
      list_group_text_font_size: 32,
      list_group_text_align_h: hmUI.align.CENTER_H,
      list_tips_text_font_size: 32,
      list_tips_text_align_h: hmUI.align.LEFT,
    };
    let objEditLeft = {
      edit_id: 101,
      x: 82,
      y: 71,
      w: 109,
      h: 109,
      select_list: edit_list_config, // 新增配置选项
      select_image: strRootPath + "select.png",
      un_select_image: strRootPath + "select_null.png",
      default_type: hmUI.edit_type.HEART,
      optional_types: [{
          type: hmUI.edit_type.AQI,
          preview: strRootPath + "edit/icon/AQI_red.png"
        },
        {
          type: hmUI.edit_type.DISTANCE,
          preview: strRootPath + "edit/icon/dis_red.png"
        },
        {
          type: hmUI.edit_type.UVI,
          preview: strRootPath + "edit/icon/uvi_red.png",
        },
        {
          type: hmUI.edit_type.PAI_WEEKLY,
          preview: strRootPath + "edit/icon/pai_red.png",
        },
        {
          type: hmUI.edit_type.HUMIDITY,
          preview: strRootPath + "edit/icon/hm_red.png",
        },
        {
          type: hmUI.edit_type.FAT_BURN,
          preview: strRootPath + "edit/icon/cal_red.png",
        },
        {
          type: hmUI.edit_type.HEART,
          preview: strRootPath + "edit/icon/heart_red.png",
        },
      ],
      count: 7,
      tips_BG: strRootPath + "tips.png",
      tips_x: 75,
      tips_y: 325,
      tips_width: 170,
      tips_margin: 10,
      // select_list: edit_list_Left,
    };
    let objEditRight = {
      edit_id: 102,
      x: 287,
      y: 71,
      w: 109,
      h: 109,
      select_list: edit_list_config, // 新增配置选项
      select_image: strRootPath + "select.png",
      un_select_image: strRootPath + "select_null.png",
      default_type: hmUI.edit_type.HUMIDITY,
      optional_types: [{
          type: hmUI.edit_type.AQI,
          preview: strRootPath + "edit/icon/AQI_blue.png"
        },
        {
          type: hmUI.edit_type.DISTANCE,
          preview: strRootPath + "edit/icon/dis_blue.png"
        },
        {
          type: hmUI.edit_type.UVI,
          preview: strRootPath + "edit/icon/uvi_blue.png",
        },
        {
          type: hmUI.edit_type.PAI_WEEKLY,
          preview: strRootPath + "edit/icon/pai_blue.png",
        },
        {
          type: hmUI.edit_type.HUMIDITY,
          preview: strRootPath + "edit/icon/hm_blue.png",
        },
        {
          type: hmUI.edit_type.FAT_BURN,
          preview: strRootPath + "edit/icon/cal_blue.png",
        },
        {
          type: hmUI.edit_type.HEART,
          preview: strRootPath + "edit/icon/heart_blue.png",
        },
      ],
      count: 7,
      tips_BG: strRootPath + "tips.png",
      tips_x: -130,
      tips_y: 325,
      tips_width: 170,
      tips_margin: 0,
      // select_list: edit_list_Left,
    };

    /*遍历数组*/
    for (i = 0; i < 29; i++) {
      if (i < 7 && i > 0) {
        arrBlueMin.push(strRootPath + "level/blue_min/" + i + ".png")
        arrRedMin.push(strRootPath + "level/red_min/" + i + ".png")
      }
      if (i < 8 && i > 0) {
        arrScWeek.push(strRootPath + "week/sc/" + i + ".png")
        arrEnWeek.push(strRootPath + "week/en/" + i + ".png")
      }
      if (i < 10) {
        arrTime.push(strRootPath + "time/" + i + ".png")
        arrFont.push(strRootPath + "font/" + i + ".png")
        arrBat.push(strRootPath + "level/bat/" + i + ".png")
      }
      if (i < 11 && i > 0) {
        arrBlueMax.push(strRootPath + "level/blue_max/" + i + ".png")
        arrRedMax.push(strRootPath + "level/red_max/" + i + ".png")
      }
      arrWeather.push(strRootPath + "weather/" + i + ".png")
    }

    const logger = DeviceRuntimeCore.HmLogger.getLogger("xiping");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({

      /* 获取数值--电量/湿度/步数/卡路里/天气温度/PAI/心率 */
      getFont(options) {
        let objConfig = {
          x: 0,
          y: 0,
          w: 0,
          type: "",
          font_array: arrFont,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          unit_sc: "",
          unit_en: "",
          invalid_image: "",
          dot_image: "",
          padding: !1,
          negative_image: "",
          show_level: hmUI.show_level.ONLY_NORMAL,
          // show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
        }
        for (let key in options) {
          if (key in objConfig) {
            objConfig[key] = options[key]
          }
        }
        for (let key in objConfig) {
          if (!objConfig[key]) {
            delete objConfig[key]
          }
        }
        let text = hmUI.createWidget(hmUI.widget.TEXT_IMG, objConfig)
      },
      /* 获取进度--电量/湿度/步数/卡路里 */
      getLevel(options) {
        let {
          x,
          y,
          arr,
          type
        } = options
        let progress = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: x,
          y: y,
          image_array: arr,
          image_length: arr.length, //长度
          type: type,
          show_level: hmUI.show_level.ONLY_NORMAL,
          // show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
        })
      },
      /* 点击事件 */
      changeClick(options) {
        let {
          x,
          y,
          w,
          h,
          type
        } = options
        let click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: x,
          y: y,
          w: w,
          h: h,
          type: type,
        })
      },
      /* 获取图标 */
      getIcon(options) {
        let {
          x,
          y,
          src
        } = options
        let icon = hmUI.createWidget(hmUI.widget.IMG, {
          x: x,
          y: y,
          src: src,
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
        })
        return icon;
      },
      /* 根据编辑的状态选择数据Left */
      getLeftData(options) {
        let {
          x,
          y,
          ix,
          iy,
          type
        } = options
        switch (type) {
          case hmUI.edit_type.DISTANCE:
            jumpLeft = hmUI.data_type.DISTANCE
            this.getFont({
              x: x,
              y: y,
              w: 90,
              type: hmUI.data_type.DISTANCE,
              dot_image: strRootPath + "font/dot.png",
              invalid_image: strRootPath + "font/null.png"
            });
            this.getIcon({
              x: ix,
              y: iy,
              src: strRootPath + "icon/red/dist.png"
            });
            this.getLevel({
              x: 82,
              y: 71,
              arr: arrRedMax,
              type: hmUI.data_type.STEP
            });
            // this.changeClick({ x: 178, y: 65, w: 110, h: 110, type: hmUI.data_type.DISTANCE});
            break;
          case hmUI.edit_type.PAI_WEEKLY:
            jumpLeft = hmUI.data_type.PAI_WEEKLY
            this.getFont({
              x: x,
              y: y,
              w: 90,
              type: hmUI.data_type.PAI_WEEKLY
            });
            this.getIcon({
              x: ix,
              y: iy,
              src: strRootPath + "icon/red/pai.png"
            });
            this.getLevel({
              x: 82,
              y: 71,
              arr: arrRedMax,
              type: hmUI.data_type.PAI_WEEKLY
            });
            // this.changeClick({ x: 178, y: 65, w: 110, h: 110, type: hmUI.data_type.PAI_WEEKLY})
            break;
          case hmUI.edit_type.AQI:
            jumpLeft = hmUI.data_type.AQI
            this.getFont({
              x: x,
              y: y,
              w: 90,
              type: hmUI.data_type.AQI,
              invalid_image: strRootPath + "font/null.png"
            });
            this.getIcon({
              x: ix,
              y: iy,
              src: strRootPath + "icon/red/aqi.png"
            });
            this.getLevel({
              x: 82,
              y: 71,
              arr: arrRedMax,
              type: hmUI.data_type.AQI
            });
            // this.changeClick({ x: 178, y: 65, w: 110, h: 110, type: hmUI.data_type.STAND})
            break;
          case hmUI.edit_type.UVI:
            jumpLeft = hmUI.data_type.UVI
            this.getFont({
              x: x,
              y: y,
              w: 90,
              type: hmUI.data_type.UVI,
              invalid_image: strRootPath + "font/null.png"
            });
            this.getIcon({
              x: ix,
              y: iy,
              src: strRootPath + "icon/red/uvi.png"
            });
            this.getLevel({
              x: 82,
              y: 71,
              arr: arrRedMin,
              type: hmUI.data_type.UVI
            });
            // this.changeClick({ x: 178, y: 65, w: 110, h: 110, type: hmUI.data_type.UVI})
            break;
          case hmUI.edit_type.HEART:
            jumpLeft = hmUI.data_type.HEART
            this.getFont({
              x: x,
              y: y,
              w: 90,
              type: hmUI.data_type.HEART,
              invalid_image: strRootPath + "font/null.png"
            })
            this.getIcon({
              x: ix,
              y: iy,
              src: strRootPath + "icon/red/hr.png"
            });
            this.getLevel({
              x: 82,
              y: 71,
              arr: arrRedMax,
              type: hmUI.data_type.HEART
            });
            // this.changeClick({ x: 178, y: 65, w: 110, h: 110, type: hmUI.data_type.UVI})
            break;
          case hmUI.edit_type.FAT_BURN:
            jumpLeft = hmUI.data_type.FAT_BURNING
            this.getFont({
              x: x,
              y: y,
              w: 90,
              type: hmUI.data_type.FAT_BURNING,
              invalid_image: strRootPath + "font/null.png"
            });
            this.getIcon({
              x: ix,
              y: iy,
              src: strRootPath + "icon/red/spt.png"
            });
            this.getLevel({
              x: 82,
              y: 71,
              arr: arrRedMax,
              type: hmUI.data_type.FAT_BURNING
            });
            // this.changeClick({ x: 178, y: 65, w: 110, h: 110, type: hmUI.data_type.UVI})
            break;
          case hmUI.edit_type.HUMIDITY:
            jumpLeft = hmUI.data_type.HUMIDITY
            this.getFont({
              x: x,
              y: y,
              w: 90,
              type: hmUI.data_type.HUMIDITY,
              invalid_image: strRootPath + "font/null.png",
              unit_sc: strRootPath + "font/baifen.png",
              unit_en: strRootPath + "font/baifen.png",
              unit_tc: strRootPath + "font/baifen.png",
            });
            this.getIcon({
              x: ix,
              y: iy,
              src: strRootPath + "icon/red/hm.png"
            });
            this.getLevel({
              x: 82,
              y: 71,
              arr: arrRedMax,
              type: hmUI.data_type.HUMIDITY
            });
            // this.changeClick({ x: 178, y: 65, w: 110, h: 110, type: hmUI.data_type.UVI})
            break;

          default:
            break;
        }

      },
      /* 根据编辑的状态选择数据Left */
      getRightData(options) {
        let {
          x,
          y,
          ix,
          iy,
          type
        } = options
        switch (type) {
          case hmUI.edit_type.DISTANCE:
            jumpRight = hmUI.data_type.DISTANCE
            this.getFont({
              x: x,
              y: y,
              w: 80,
              type: hmUI.data_type.DISTANCE,
              dot_image: strRootPath + "font/dot.png",
              invalid_image: strRootPath + "font/null.png"
            })
            this.getIcon({
              x: ix,
              y: iy,
              src: strRootPath + "icon/blue/dist.png"
            });
            this.getLevel({
              x: 287,
              y: 71,
              arr: arrBlueMax,
              type: hmUI.data_type.STEP
            });
            // this.changeClick({ x: 178, y: 65, w: 110, h: 110, type: hmUI.data_type.DISTANCE})
            break;
          case hmUI.edit_type.PAI_WEEKLY:
            jumpRight = hmUI.data_type.PAI_WEEKLY
            this.getFont({
              x: x,
              y: y,
              w: 80,
              type: hmUI.data_type.PAI_WEEKLY
            });
            this.getIcon({
              x: ix,
              y: iy,
              src: strRootPath + "icon/blue/pai.png"
            });
            this.getLevel({
              x: 287,
              y: 71,
              arr: arrBlueMax,
              type: hmUI.data_type.PAI_WEEKLY
            });
            // this.changeClick({ x: 178, y: 65, w: 110, h: 110, type: hmUI.data_type.PAI_WEEKLY})
            break;
          case hmUI.edit_type.AQI:
            jumpRight = hmUI.data_type.AQI
            this.getFont({
              x: x,
              y: y,
              w: 80,
              type: hmUI.data_type.AQI,
              invalid_image: strRootPath + "font/null.png"
            })
            this.getIcon({
              x: ix,
              y: iy,
              src: strRootPath + "icon/blue/aqi.png"
            });
            this.getLevel({
              x: 287,
              y: 71,
              arr: arrBlueMax,
              type: hmUI.data_type.AQI
            });
            // this.changeClick({ x: 178, y: 65, w: 110, h: 110, type: hmUI.data_type.STAND})
            break;
          case hmUI.edit_type.UVI:
            jumpRight = hmUI.data_type.UVI
            this.getFont({
              x: x,
              y: y,
              w: 80,
              type: hmUI.data_type.UVI,
              invalid_image: strRootPath + "font/null.png"
            })
            this.getIcon({
              x: ix,
              y: iy,
              src: strRootPath + "icon/blue/uvi.png"
            });
            this.getLevel({
              x: 287,
              y: 71,
              arr: arrBlueMin,
              type: hmUI.data_type.UVI
            });
            // this.changeClick({ x: 178, y: 65, w: 110, h: 110, type: hmUI.data_type.UVI})
            break;
          case hmUI.edit_type.HEART:
            jumpRight = hmUI.data_type.HEART
            this.getFont({
              x: x,
              y: y,
              w: 80,
              type: hmUI.data_type.HEART,
              invalid_image: strRootPath + "font/null.png"
            })
            this.getIcon({
              x: ix,
              y: iy,
              src: strRootPath + "icon/blue/hr.png"
            });
            this.getLevel({
              x: 287,
              y: 71,
              arr: arrBlueMax,
              type: hmUI.data_type.HEART
            });
            // this.changeClick({ x: 178, y: 65, w: 110, h: 110, type: hmUI.data_type.UVI})
            break;
          case hmUI.edit_type.FAT_BURN:
            jumpRight = hmUI.data_type.FAT_BURNING
            this.getFont({
              x: x,
              y: y,
              w: 80,
              type: hmUI.data_type.FAT_BURNING,
              invalid_image: strRootPath + "font/null.png"
            })
            this.getIcon({
              x: ix,
              y: iy,
              src: strRootPath + "icon/blue/spt.png"
            });
            this.getLevel({
              x: 287,
              y: 71,
              arr: arrBlueMax,
              type: hmUI.data_type.FAT_BURNING
            });
            // this.changeClick({ x: 178, y: 65, w: 110, h: 110, type: hmUI.data_type.UVI})
            break;
          case hmUI.edit_type.HUMIDITY:
            jumpRight = hmUI.data_type.HUMIDITY
            this.getFont({
              x: x,
              y: y,
              w: 80,
              type: hmUI.data_type.HUMIDITY,
              invalid_image: strRootPath + "font/null.png",
              unit_sc: strRootPath + "font/baifen.png",
              unit_en: strRootPath + "font/baifen.png",
              unit_tc: strRootPath + "font/baifen.png",
            })
            this.getIcon({
              x: ix,
              y: iy,
              src: strRootPath + "icon/blue/hm.png"
            });
            this.getLevel({
              x: 287,
              y: 71,
              arr: arrBlueMax,
              type: hmUI.data_type.HUMIDITY
            });
            // this.changeClick({ x: 178, y: 65, w: 110, h: 110, type: hmUI.data_type.UVI})
            break;

          default:
            break;
        }

      },
      init_view() {
        /* --数据控件-- */

        /* 正常背景 */
        let bg = hmUI.createWidget(hmUI.widget.IMG, objBg)
        let aodBg = hmUI.createWidget(hmUI.widget.IMG, objBgAod)
        this.getIcon({
          x: 82,
          y: 71,
          src: strRootPath + "level/blue_max/0.png"
        })
        this.getIcon({
          x: 287,
          y: 71,
          src: strRootPath + "level/blue_max/0.png"
        })

        /* 时间 */
        let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, objTime)
        let timeTextAmpm = hmUI.createWidget(hmUI.widget.IMG_TIME, objTimeAmPm)

        /* 日期 */
        let timeDate = hmUI.createWidget(hmUI.widget.IMG_DATE, objDate);

        /* 星期 */
        let timeWeek = hmUI.createWidget(hmUI.widget.IMG_WEEK, objWeek);

        /* 天气icon */
        this.getLevel({
          x: 214,
          y: 80,
          arr: arrWeather,
          type: hmUI.data_type.WEATHER_CURRENT
        })

        /* 温度 */
        this.getFont({
          x: 202,
          y: 144,
          w: 70,
          type: hmUI.data_type.WEATHER_CURRENT,
          h_space: 0,
          unit_sc: strRootPath + "font/du.png",
          unit_en: strRootPath + "font/du.png",
          unit_tc: strRootPath + "font/du.png",
          negative_image: strRootPath + "font/fu.png",
          invalid_image: strRootPath + "font/nullweather.png"
        })

        /* 电量 */
        this.getFont({
          x: 222,
          y: 411,
          w: 80,
          type: hmUI.data_type.BATTERY,
          align_h: hmUI.align.LIFT,
          unit_sc: strRootPath + "font/baifen.png",
          unit_en: strRootPath + "font/baifen.png",
          unit_tc: strRootPath + "font/baifen.png",
        })
        /* 电量进度 */
        this.getLevel({
          x: 161,
          y: 437,
          arr: arrBat,
          type: hmUI.data_type.BATTERY
        })

        /* 步数 */
        this.getFont({
          x: 146,
          y: 359,
          w: 80,
          align_h: hmUI.align.LIFT,
          type: hmUI.data_type.STEP
        })

        /* cal */
        this.getFont({
          x: 303,
          y: 359,
          w: 80,
          align_h: hmUI.align.LIFT,
          type: hmUI.data_type.CAL
        })

        /* 100%mask 编辑背景 */
        let maskCover = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK, objMask);

        /* 可编辑组件 */
        editLeft = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, objEditLeft);
        editRight = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, objEditRight);

        /* 获取当前编辑选择的id */
        let leftType = editLeft.getProperty(hmUI.prop.CURRENT_TYPE);
        let rightype = editRight.getProperty(hmUI.prop.CURRENT_TYPE);
        this.getLeftData({
          x: 85,
          y: 119,
          ix: 116,
          iy: 88,
          type: leftType
        });
        this.getRightData({
          x: 295,
          y: 119,
          ix: 321,
          iy: 88,
          type: rightype
        });


        /* --热区跳转-- */
        let leftEditClick = hmUI.createWidget(hmUI.widget.IMG_CLICK, { //使用IMGCLICK控件传入组件对应类型
          x: 87,
          y: 77,
          w: 85,
          h: 85,
          type: jumpLeft,
        })
        let rightEditClick = hmUI.createWidget(hmUI.widget.IMG_CLICK, { //使用IMGCLICK控件传入组件对应类型
          x: 294,
          y: 77,
          w: 85,
          h: 85,
          type: jumpRight,
        })
        let weatherClick = hmUI.createWidget(hmUI.widget.IMG_CLICK, { //使用IMGCLICK控件传入组件对应类型
          x: 214,
          y: 77,
          w: 44,
          h: 95,
          type: hmUI.data_type.WEATHER_CURRENT,
        })
        let stepClick = hmUI.createWidget(hmUI.widget.IMG_CLICK, { //使用IMGCLICK控件传入组件对应类型
          x: 104,
          y: 349,
          w: 119,
          h: 34,
          type: hmUI.data_type.STEP,
        })
        let calClick = hmUI.createWidget(hmUI.widget.IMG_CLICK, { //使用IMGCLICK控件传入组件对应类型
          x: 254,
          y: 349,
          w: 119,
          h: 34,
          type: hmUI.data_type.CAL,
        })
      },

      onInit() {
        console.log('index page.js on init invoke')
        this.init_view();
      },

      onReady() {
        console.log('index page.js on ready invoke')
      },

      onShow() {
        console.log('index page.js on show invoke')
      },

      onHide() {
        console.log('index page.js on hide invoke')
      },

      onDestory() {
        console.log('index page.js on destory invoke')
      },
    });
    /*
     * end js
     */
  })()
} catch (e) {
  console.log(e)
}