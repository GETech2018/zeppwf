try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface6');

        let group, complication, timeSensor;
        const xShift = - (45 - 11) / 2;
        const center = 233;

        function moveX() {
            const timeFormat = hmSetting.getTimeFormat();
            const screenType = hmSetting.getScreenType();
            const edit = screenType == hmSetting.screen_type.SETTINGS;
            if (timeFormat == 1 && !edit ) {
                group.setProperty(hmUI.prop.MORE, {x: xShift});
            } else {
                group.setProperty(hmUI.prop.MORE, {x: 0});
            }
        }

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                if (!timeSensor) { timeSensor = hmSensor.createSensor(hmSensor.id.TIME); }

                group = hmUI.createWidget(hmUI.widget.GROUP, {
                    x: 0,
                    y: 0,
                    w: center * 2,
                    h: center * 2
                });

                group.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    src: '144.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                group.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
                    edit_id: 1,
                    x: 0,
                    y: 0,
                    bg_config: [
                        {
                            'id': 1,
                            'path': '5.png',
                            'preview': '6.png'
                        },
                        {
                            'id': 2,
                            'path': '7.png',
                            'preview': '8.png'
                        },
                        {
                            'id': 3,
                            'path': '9.png',
                            'preview': '10.png'
                        },
                        {
                            'id': 4,
                            'path': '11.png',
                            'preview': '12.png'
                        },
                        {
                            'id': 5,
                            'path': '13.png',
                            'preview': '14.png'
                        },
                        {
                            'id': 6,
                            'path': '15.png',
                            'preview': '16.png'
                        },
                        {
                            'id': 7,
                            'path': '17.png',
                            'preview': '18.png'
                        },
                        {
                            'id': 8,
                            'path': '19.png',
                            'preview': '20.png'
                        }
                    ],
                    count: 8,
                    default_id: 1,
                    fg: '4.png',
                    tips_x: 163,
                    tips_y: 110,
                    tips_bg: '3.png',
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 217,
                    y: 424,
                    src: '21.png',
                    type: hmUI.system_status.DISCONNECT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 253,
                    y: 424,
                    src: '22.png',
                    type: hmUI.system_status.LOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 181,
                    y: 424,
                    src: '23.png',
                    type: hmUI.system_status.CLOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                group.createWidget(hmUI.widget.IMG_DATE, {
                    day_startX: 395,
                    day_startY: 188,
                    day_sc_array: [
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png'
                    ],
                    day_tc_array: [
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png'
                    ],
                    day_en_array: [
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png'
                    ],
                    day_align: hmUI.align.LEFT,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 0,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                group.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 320,
                    y: 188,
                    week_en: [
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png'
                    ],
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                group.createWidget(hmUI.widget.IMG, {
                    x: 315,
                    y: 233,
                    src: '51.png',
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                group.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 315,
                    y: 233,
                    image_array: [
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png'
                    ],
                    image_length: 10,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                group.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 315,
                    y: 233,
                    w: 75,
                    h: 45,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                group.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 45,
                    hour_startY: 188,
                    hour_array: [
                        '111.png',
                        '112.png',
                        '113.png',
                        '114.png',
                        '115.png',
                        '116.png',
                        '117.png',
                        '118.png',
                        '119.png',
                        '120.png'
                    ],
                    hour_space: 0,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 165,
                    minute_startY: 188,
                    minute_array: [
                        '121.png',
                        '122.png',
                        '123.png',
                        '124.png',
                        '125.png',
                        '126.png',
                        '127.png',
                        '128.png',
                        '129.png',
                        '130.png'
                    ],
                    minute_space: 0,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    am_x: 10,
                    am_y: 188,
                    am_en_path: '141.png',
                    pm_x: 10,
                    pm_y: 233,
                    pm_en_path: '142.png',
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                group.createWidget(hmUI.widget.IMG_TIME, {
                    second_zero: 1,
                    second_startX: 395,
                    second_startY: 233,
                    second_array: [
                        '131.png',
                        '132.png',
                        '133.png',
                        '134.png',
                        '135.png',
                        '136.png',
                        '137.png',
                        '138.png',
                        '139.png',
                        '140.png'
                    ],
                    second_space: 0,
                    second_align: hmUI.align.LEFT,
                    second_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                group.createWidget(hmUI.widget.IMG, {
                    x: 288,
                    y: 183,
                    src: '110.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                complication = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: 2,
                    x: 288,
                    y: 183,
                    w: 28,
                    h: 100,
                    select_image: '52.png',
                    un_select_image: '53.png',
                    default_type: hmUI.edit_type.STEP,
                    optional_types: [
                        {
                            'type': hmUI.edit_type.STEP,
                            'preview': '55.png'
                        },
                        {
                            'type': hmUI.edit_type.SPO2,
                            'preview': '56.png'
                        },
                        {
                            'type': hmUI.edit_type.CAL,
                            'preview': '57.png'
                        },
                        {
                            'type': hmUI.edit_type.HEART,
                            'preview': '58.png'
                        },
                        {
                            'type': hmUI.edit_type.PAI_DAILY,
                            'preview': '59.png'
                        }
                    ],
                    count: 5,
                    tips_BG: '54.png',
                    tips_x: -56,
                    tips_y: 117,
                    tips_width: 140,
                    tips_margin: 0
                });
                editType = complication.getProperty(hmUI.prop.CURRENT_TYPE);
                switch (editType) {
                case hmUI.edit_type.STEP:
                    group.createWidget(hmUI.widget.IMG_LEVEL, {
                        x: 288,
                        y: 183,
                        image_array: [
                            '60.png',
                            '61.png',
                            '62.png',
                            '63.png',
                            '64.png',
                            '65.png',
                            '66.png',
                            '67.png',
                            '68.png',
                            '69.png'
                        ],
                        image_length: 10,
                        type: hmUI.data_type.STEP,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    group.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 288,
                        y: 183,
                        w: 28,
                        h: 100,
                        type: hmUI.data_type.STEP,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.BATTERY:
                    break;
                case hmUI.edit_type.HEART:
                    group.createWidget(hmUI.widget.IMG_LEVEL, {
                        x: 288,
                        y: 183,
                        image_array: [
                            '70.png',
                            '71.png',
                            '72.png',
                            '73.png',
                            '74.png',
                            '75.png',
                            '76.png',
                            '77.png',
                            '78.png',
                            '79.png'
                        ],
                        image_length: 10,
                        type: hmUI.data_type.HEART,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    group.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 288,
                        y: 183,
                        w: 28,
                        h: 100,
                        type: hmUI.data_type.HEART,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.CAL:
                    group.createWidget(hmUI.widget.IMG_LEVEL, {
                        x: 288,
                        y: 183,
                        image_array: [
                            '80.png',
                            '81.png',
                            '82.png',
                            '83.png',
                            '84.png',
                            '85.png',
                            '86.png',
                            '87.png',
                            '88.png',
                            '89.png'
                        ],
                        image_length: 10,
                        type: hmUI.data_type.CAL,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    group.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 288,
                        y: 183,
                        w: 28,
                        h: 100,
                        type: hmUI.data_type.CAL,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.PAI_DAILY:
                    group.createWidget(hmUI.widget.IMG_LEVEL, {
                        x: 288,
                        y: 183,
                        image_array: [
                            '90.png',
                            '91.png',
                            '92.png',
                            '93.png',
                            '94.png',
                            '95.png',
                            '96.png',
                            '97.png',
                            '98.png',
                            '99.png'
                        ],
                        image_length: 10,
                        type: hmUI.data_type.PAI_DAILY,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    group.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 288,
                        y: 183,
                        w: 28,
                        h: 100,
                        type: hmUI.data_type.PAI_DAILY,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.DISTANCE:
                    break;
                case hmUI.edit_type.AQI:
                    break;
                case hmUI.edit_type.HUMIDITY:
                    break;
                case hmUI.edit_type.ALTIMETER:
                    break;
                case hmUI.edit_type.STRESS:
                    break;
                case hmUI.edit_type.WIND:
                    break;
                case hmUI.edit_type.SPO2:
                    group.createWidget(hmUI.widget.IMG_LEVEL, {
                        x: 288,
                        y: 183,
                        image_array: [
                            '100.png',
                            '101.png',
                            '102.png',
                            '103.png',
                            '104.png',
                            '105.png',
                            '106.png',
                            '107.png',
                            '108.png',
                            '109.png'
                        ],
                        image_length: 10,
                        type: hmUI.data_type.SPO2,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    group.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 288,
                        y: 183,
                        w: 28,
                        h: 100,
                        type: hmUI.data_type.SPO2,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.TRAINING_LOAD:
                    break;
                case hmUI.edit_type.VO2MAX:
                    break;
                case hmUI.edit_type.UVI:
                    break;
                case hmUI.edit_type.DATE:
                    break;
                case hmUI.edit_type.WEEK:
                    break;
                case hmUI.edit_type.WEATHER:
                    break;
                case hmUI.edit_type.TEMPERATURE:
                    break;
                case hmUI.edit_type.SUN:
                    break;
                }
                group.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
                    x: 0,
                    y: 0,
                    w: 466,
                    h: 466,
                    src: '143.png',
                    show_level: hmUI.show_level.ONLY_EDIT
                });

                timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() { moveX() });
                timer.createTimer(0, 60000, function (timeSensor2) { moveX(); }, timeSensor);
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function() { moveX() }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
