try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_673043cd65c245b99fbbd39892dd0af0 = '';
        let normal$_$text_50ec0b215f344053946c9d0b65e78bc7 = '';
        let dateFormat = '';
        let dateFormatMap = '';
        let normal$_$text_420a7bdf30d645548b929e7a96d0d72e = '';
        let normal$_$text_7f7ff8d9382949c8a66bcad33fd827c3 = '';
        let normal$_$text_74d6ada49e0c46deaf80398321af8d38 = '';
        let normal$_$text_e9329be30ea048038b34ff0490201891 = '';
        let stepSensor = '';
        let timeSensor = '';
        let heartSensor = '';
        const logger = Logger.getLogger('watchface6');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 466,
                    h: 466,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_val: new Date().getHours(),
                    hour_zero: 1,
                    hour_startX: 100,
                    hour_startY: 40,
                    hour_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    hour_space: 26,
                    hour_align: hmUI.align.CENTER_H,
                    minute_val: new Date().getMinutes(),
                    minute_zero: 1,
                    minute_startX: 100,
                    minute_startY: 246,
                    minute_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    minute_space: 26,
                    minute_align: hmUI.align.CENTER_H,
                    minute_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 466,
                    h: 466,
                    src: '23.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 49,
                    y: 107,
                    image_array: [
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png'
                    ],
                    image_length: 10,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 391,
                    y: 309,
                    src: '34.png',
                    type: hmUI.system_status.DISCONNECT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 391,
                    y: 205,
                    src: '35.png',
                    type: hmUI.system_status.LOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 391,
                    y: 111,
                    src: '36.png',
                    type: hmUI.system_status.CLOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 228,
                    y: 422,
                    src: '37.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_673043cd65c245b99fbbd39892dd0af0 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 125,
                    y: 428,
                    w: 100,
                    h: 30,
                    text: '[SC]',
                    color: '0xFFbdbdbd',
                    text_size: 24,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.RIGHT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_50ec0b215f344053946c9d0b65e78bc7 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 0,
                    y: 246,
                    w: 100,
                    h: 30,
                    text: '[YEAR]',
                    color: '0xFFbdbdbd',
                    text_size: 20,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_420a7bdf30d645548b929e7a96d0d72e = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 0,
                    y: 276,
                    w: 100,
                    h: 30,
                    text: '[MON]',
                    color: '0xFFbdbdbd',
                    text_size: 24,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_7f7ff8d9382949c8a66bcad33fd827c3 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 0,
                    y: 306,
                    w: 100,
                    h: 30,
                    text: '[DAY]',
                    color: '0xFFbdbdbd',
                    text_size: 24,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 54,
                    y: 345,
                    src: '38.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 212,
                    y: 9,
                    src: '39.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_74d6ada49e0c46deaf80398321af8d38 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 251,
                    y: 10,
                    w: 70,
                    h: 30,
                    text: '[HR]',
                    color: '0xFFbdbdbd',
                    text_size: 24,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_e9329be30ea048038b34ff0490201891 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 0,
                    y: 226,
                    w: 100,
                    h: 20,
                    text: '[WEEK_EN_F]',
                    color: '0xFFbdbdbd',
                    text_size: 16,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                if (!stepSensor) {
                    stepSensor = hmSensor.createSensor(hmSensor.id.STEP);
                }
                if (!timeSensor) {
                    timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                }
                if (!heartSensor) {
                    heartSensor = hmSensor.createSensor(hmSensor.id.HEART);
                }
                stepSensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_673043cd65c245b99fbbd39892dd0af0.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                }), timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_50ec0b215f344053946c9d0b65e78bc7.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }` });
                        },
                        () => {
                            normal$_$text_50ec0b215f344053946c9d0b65e78bc7.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }` });
                        },
                        () => {
                            normal$_$text_50ec0b215f344053946c9d0b65e78bc7.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_420a7bdf30d645548b929e7a96d0d72e.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.month }` });
                        },
                        () => {
                            normal$_$text_420a7bdf30d645548b929e7a96d0d72e.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.month }` });
                        },
                        () => {
                            normal$_$text_420a7bdf30d645548b929e7a96d0d72e.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.month }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_7f7ff8d9382949c8a66bcad33fd827c3.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                        },
                        () => {
                            normal$_$text_7f7ff8d9382949c8a66bcad33fd827c3.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                        },
                        () => {
                            normal$_$text_7f7ff8d9382949c8a66bcad33fd827c3.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                    const WEEK_EN_F = function (val) {
                        const valueMap = {
                            '1': 'Monday',
                            '2': 'Tuesday',
                            '3': 'Wednesday',
                            '4': 'Thursday',
                            '5': 'Friday',
                            '6': 'Saturday',
                            '7': 'Sunday'
                        };
                        return valueMap[val];
                    };
                    normal$_$text_e9329be30ea048038b34ff0490201891.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_F(timeSensor.week) }` });
                }), heartSensor.addEventListener(heartSensor.event.LAST, function () {
                    normal$_$text_74d6ada49e0c46deaf80398321af8d38.setProperty(hmUI.prop.MORE, { text: `${ heartSensor.last }` });
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 49,
                    y: 107,
                    w: 35,
                    h: 70,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 130,
                    y: 0,
                    w: 200,
                    h: 45,
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 130,
                    y: 421,
                    w: 200,
                    h: 45,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        normal$_$text_673043cd65c245b99fbbd39892dd0af0.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                normal$_$text_50ec0b215f344053946c9d0b65e78bc7.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }` });
                            },
                            () => {
                                normal$_$text_50ec0b215f344053946c9d0b65e78bc7.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }` });
                            },
                            () => {
                                normal$_$text_50ec0b215f344053946c9d0b65e78bc7.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                normal$_$text_420a7bdf30d645548b929e7a96d0d72e.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.month }` });
                            },
                            () => {
                                normal$_$text_420a7bdf30d645548b929e7a96d0d72e.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.month }` });
                            },
                            () => {
                                normal$_$text_420a7bdf30d645548b929e7a96d0d72e.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.month }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                normal$_$text_7f7ff8d9382949c8a66bcad33fd827c3.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                            },
                            () => {
                                normal$_$text_7f7ff8d9382949c8a66bcad33fd827c3.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                            },
                            () => {
                                normal$_$text_7f7ff8d9382949c8a66bcad33fd827c3.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                        normal$_$text_74d6ada49e0c46deaf80398321af8d38.setProperty(hmUI.prop.MORE, { text: `${ heartSensor.last }` });
                        const WEEK_EN_F = function (val) {
                            const valueMap = {
                                '1': 'Monday',
                                '2': 'Tuesday',
                                '3': 'Wednesday',
                                '4': 'Thursday',
                                '5': 'Friday',
                                '6': 'Saturday',
                                '7': 'Sunday'
                            };
                            return valueMap[val];
                        };
                        normal$_$text_e9329be30ea048038b34ff0490201891.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_F(timeSensor.week) }` });
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}