try {
    ;(() => {
      var __$$app$$__ = __$$hmAppManager$$__.currentApp

      var __$$module$$__ = __$$app$$__.current
      var h = new DeviceRuntimeCore.WidgetFactory(
        new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__),
        'drink'
      )

      /*
       * huamiOS bundle tool v1.0.17
       * Copyright © Huami. All Rights Reserved
       */
      ;('use strict')

      console.log('----->>>current')
      console.log(__$$hmAppManager$$__.currentApp.pid)
      console.log(__$$hmAppManager$$__.currentApp.current)

      // =========================================================

      const WIDGET_LEFT_ID = 101
      const WIDGET_RIGHT_ID = 102
      const WIDGET_BOTTOM_ID = 103
      let bottomeditType = null
      let bottomWidget = null
      let smallTypeImg = null
      let pointerNor = null
      let pointerAod = null
      const WIDGET_LEFT = 1
      const WIDGET_RIGHT = 2
      const WIDGET_BOTTOM = 3
      const WIDGET_BIG_EDIT_SIZE = 162
      const WIDGET_SMALL_EDIT_SIZE = 162
      // 数组对象
      let norWeek_en = []
      let norWeek_sc = []
      let norWeek_tc = []
      let norDate = []
      let tempArray = []
      let fontArray = []
      let weatherArray = []
      let widgetOptionalArray = []
      // 路径
      const ROOTPATH = 'images/'
      const widgetPreviewSmall = ROOTPATH + 'nor/widget/smallPre/'
      const widgetPreviewBig = ROOTPATH + 'nor/widget/bigPre/'
      const WIDGET_POINTER_PATH = ROOTPATH + 'nor/data/pointer.png'
      const selectBig = ROOTPATH +'nor/widget/selectBig.png'
      const unselectBig = ROOTPATH +'nor/widget/unselectBig.png'
      const selectSmall = ROOTPATH +'nor/widget/selectSmall.png'
      const unselectSmall = ROOTPATH +'nor/widget/unselectSmall.png'
      //==========================================================
      let textPath = null
      let widgetPrePath = null
      //==========================================================

      // 填充静态

      for (let i = 1; i < 8; i++) {
        norWeek_en.push(ROOTPATH + 'nor/week/en/' + i + '.png')
        norWeek_tc.push(ROOTPATH + 'nor/week/tc/' + i + '.png')
        norWeek_sc.push(ROOTPATH + 'nor/week/sc/' + i + '.png')
      }

      for (let i = 0; i < 10; i++) {
        norDate.push(ROOTPATH + 'nor/date/' + i + '.png')
        fontArray.push(ROOTPATH + 'nor/data/bat/' + i + '.png')
        tempArray.push(ROOTPATH + 'nor/data/temp/' + i + '.png')
      }
      for (let i = 1; i < 30; i++) {
        weatherArray.push('images/nor/data/weather/' + i + '.png')
      }
      let languageId = hmSetting.getLanguage()
      switch (languageId) {
        case 0:
         textPath= ROOTPATH + 'nor/data/text/sc/'
         widgetPrePath = widgetPreviewSmall +'sc/'
         break;
       case 1:
         textPath = ROOTPATH + 'nor/data/text/tc/'
         widgetPrePath = widgetPreviewSmall +'tc/'
         break;
       case 2:
         textPath = ROOTPATH + 'nor/data/text/en/'
         widgetPrePath = widgetPreviewSmall +'en/'
         break;
        default:
          textPath = ROOTPATH + 'nor/data/text/en/'
          widgetPrePath = widgetPreviewSmall +'en/'
          break;
      }
     //------------------------------------------------表盘背景图-----------------------------------------------
     let bgObj = {
       x:0,
       y:0,
       src:ROOTPATH+'nor/bg.png',
       show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
     }
      //------------------------------------------------正常星期-----------------------------------------------
      let norobjWeek = {
        show_level: hmUI.show_level.ONLY_NORMAL| hmUI.show_level.ONLY_EDIT,
        x: 184,
        y: 122,
        week_tc: norWeek_tc,
        week_sc: norWeek_sc,
        week_en: norWeek_en,
      }
      //------------------------------------------------正常日期-----------------------------------------------
      let norobjDay = {
        show_level: hmUI.show_level.ONLY_NORMAL| hmUI.show_level.ONLY_EDIT,
        day_startX: 248,
        day_startY: 122,
        day_zero: true,
        day_en_array: norDate,
      }
      //------------------------------------------------正常时间-----------------------------------------------
      let timePointer = {
        hour_centerX: 233, // 指针旋转中心 对应 centerX
        hour_centerY: 233, // 指针旋转中心 对应 centerY
        hour_posX: 18, // 指针自身旋转中心 对应 position 中的 x
        hour_posY: 233, // 指针自身旋转中心 对应 position 中的 y
        hour_path: ROOTPATH + 'nor/time/hour.png',
        minute_centerX: 233, // 指针旋转中心 对应 centerX
        minute_centerY: 233, // 指针旋转中心 对应 centerY
        minute_posX: 18, // 指针自身旋转中心 对应 position 中的 x
        minute_posY: 233, // 指针自身旋转中心 对应 position 中的 y
        minute_path: ROOTPATH + 'nor/time/minute.png',
        second_centerX: 233, // 指针旋转中心 对应 centerX
        second_centerY: 233, // 指针旋转中心 对应 centerY
        second_posX: 18, // 指针自身旋转中心 对应 position 中的 x
        second_posY: 233, // 指针自身旋转中心 对应 position 中的 y
        second_path: ROOTPATH + 'nor/time/second.png',
        show_level: hmUI.show_level.ONLY_NORMAL| hmUI.show_level.ONLY_EDIT,
      }
      //------------------------------------------------正常温度-----------------------------------------------
      let temp = {
        x:235,
        y:79,
        type:hmUI.data_type.WEATHER_CURRENT,
        font_array: tempArray ,
        h_space: 2,
        //图片间隔
        align_h:hmUI.align.CENTER_H,
        unit_sc:"images/du.png",
        //单位
        unit_tc:"images/du.png",
        //单位
        unit_en:"images/du.png",
        //单位
        negative_image:"images/fuhao.png",
        //负号图片
        invalid_image:"images/null.png",
        // 无数据时显示的图片
        padding:false,
        //是否补零 true为补零
        show_level: hmUI.show_level.ONLY_NORMAL| hmUI.show_level.ONLY_EDIT,
        }
      //------------------------------------------------正常天气-----------------------------------------------
      let weatherObj = {
        x: 191,
        y: 68,
        type:hmUI.data_type.WEATHER,
        image_array: weatherArray,
        image_length: weatherArray.length,//长度
        show_level: hmUI.show_level.ONLY_NORMAL| hmUI.show_level.ONLY_EDIT,
      }
      //------------------------------------------------可编辑列表配置--------------------------------
      let edit_list_config = {
        title_font_size: 34,
        title_align_h: hmUI.align.CENTER_H,
        list_item_vspace: 8,
        list_bg_color: 0x0000,
        list_bg_radius: 30,
        list_group_text_font_size: 32,
        list_group_text_align_h: hmUI.align.CENTER_H,
        list_tips_text_font_size: 32,
        list_tips_text_align_h: hmUI.align.LEFT,
    };
      //------------------------------------------------息屏时间-----------------------------------------------
      let timeAodPointer = {
        hour_centerX: 233, // 指针旋转中心 对应 centerX
        hour_centerY: 233, // 指针旋转中心 对应 centerY
        hour_posX: 18, // 指针自身旋转中心 对应 position 中的 x
        hour_posY: 233, // 指针自身旋转中心 对应 position 中的 y
        hour_path: ROOTPATH + 'aod/hour.png',
        minute_centerX: 233, // 指针旋转中心 对应 centerX
        minute_centerY: 233, // 指针旋转中心 对应 centerY
        minute_posX: 18, // 指针自身旋转中心 对应 position 中的 x
        minute_posY: 233, // 指针自身旋转中心 对应 position 中的 y
        minute_path: ROOTPATH + 'aod/minute.png',
        show_level: hmUI.show_level.ONAL_AOD,
      }
      // --------------------------------------------------------可编辑遮罩-----------------------------------------
      let objMask = {
        x: 0,
        y: 0,
        w: 466,
        h: 466,
        src: ROOTPATH + 'mask.png',
        show_level: hmUI.show_level.ONLY_EDIT,
      }
      const logger = DeviceRuntimeCore.HmLogger.getLogger('sanjiao')
      __$$module$$__.module = DeviceRuntimeCore.Page({
        init_view() {
          function changeWidgetOption(size){
            if(size=='small'){
                widgetOptionalArray = [
                    { type: hmUI.edit_type.CAL, preview: widgetPrePath + `CAL.png` },
                    { type: hmUI.edit_type.STEP, preview: widgetPrePath + `STEP.png` },
                    { type: hmUI.edit_type.DISTANCE,preview: widgetPrePath + `DIS.png`,},
                    { type: hmUI.edit_type.BATTERY, preview: widgetPrePath + `BAT.png` },
                    { type: hmUI.edit_type.STAND, preview: widgetPrePath + `STAND.png` },
                    { type: hmUI.edit_type.UVI, preview: widgetPrePath + `UVI.png` },
                    { type: hmUI.edit_type.HEART, preview: widgetPrePath + `HEART.png` },
                    { type: hmUI.edit_type.PAI_WEEKLY, preview: widgetPrePath + `PAI.png` },
               ]
            }else{
                widgetOptionalArray = [
                    { type: hmUI.edit_type.CAL, preview: widgetPreviewBig + `CAL.png` },
                    { type: hmUI.edit_type.STEP, preview: widgetPreviewBig + `STEP.png` },
                    { type: hmUI.edit_type.DISTANCE,preview: widgetPreviewBig + `DIS.png`,},
                    { type: hmUI.edit_type.BATTERY, preview: widgetPreviewBig + `BAT.png` },
                    { type: hmUI.edit_type.STAND, preview: widgetPreviewBig + `STAND.png` },
                    { type: hmUI.edit_type.UVI, preview: widgetPreviewBig + `UVI.png` },
                    { type: hmUI.edit_type.HEART, preview: widgetPreviewBig + `HEART.png` },
                    { type: hmUI.edit_type.PAI_WEEKLY, preview: widgetPreviewBig + `PAI.png` },
                   ]
            }
         return widgetOptionalArray
        }
        // --------------------------------------------------可编辑控件配置函数---------------------------------------------
        function parseWidgetConfig(editType,size) {
            let bg = null
            let iconPath = null
            // let textPath = null
            let nonePath = ROOTPATH +'nor/data/bat/null.png'
            let xiaoshudianPath = ROOTPATH +'nor/data/bat/dot_1.png'
            let baifenhaoPath = ROOTPATH +'nor/data/bat/dot_%.png'
            let config = {
              bgPath: null, //背景图
              iconPath:null, // 图标
              dataType: null, //数据类型
              nonePath: null, //无数据的图片
              xiaoshudian:null, // 小数点
              padding:false, // 是否补零
              unitEnPath: null, //单位
              unitScPath: null,
              unitTcPath: null,
              imperial_unit_sc:null,
              imperial_unit_en:null,
              imperial_unit_tc:null,
              width:null, // 图片文本所占宽度
              startAngle: 0, //指针开始角度
              endAngle: 360, //指针结束角度
            }
            if(size=='small'){
                iconPath = ROOTPATH + 'nor/data/icon/small/'
                bg = ROOTPATH + 'nor/widget/bgSmall.png'
                config.moveXT=43
                config.moveYT=105
                config.moveXI=67
                config.moveYI=35
                config.moveXN=39
                config.moveYN=73
                config.width=84
                switch (editType) {
                    case hmUI.edit_type.STEP:
                      config.bgPath = bg
                      config.iconPath = iconPath + 'STEP.png'
                      config.textPath = textPath + 'STEP.png'
                      config.dataType = hmUI.data_type.STEP
                      break
                    case hmUI.edit_type.CAL:
                      config.bgPath = bg
                      config.iconPath = iconPath + 'CAL.png'
                      config.textPath = textPath + 'CAL.png'
                      config.dataType = hmUI.data_type.CAL
                      break
                    case hmUI.edit_type.DISTANCE:
                      config.bgPath = bg
                      config.iconPath = iconPath + 'DIS.png'
                      config.textPath = textPath + 'DIS.png'
                      config.dataType = hmUI.data_type.DISTANCE
                      config.nonePath = nonePath
                      config.unitEnPath = ''
                      config.unitScPath = ''
                      config.unitTcPath = ''
                      config.imperial_unit_sc = ''
                      config.imperial_unit_en = ''
                      config.imperial_unit_tc = ''
                      config.xiaoshudian = xiaoshudianPath
                      config.padding=true
                      break
                    case hmUI.edit_type.PAI_WEEKLY:
                      config.bgPath = bg
                      config.iconPath = iconPath + 'PAI.png'
                      config.textPath = textPath + 'PAI.png'
                      config.dataType = hmUI.data_type.PAI_WEEKLY
                      config.nonePath = nonePath
                      break
                    case hmUI.edit_type.BATTERY:
                      config.bgPath = bg
                      config.iconPath = iconPath + 'BAT.png'
                      config.textPath = textPath + 'BAT.png'
                      config.dataType = hmUI.data_type.BATTERY
                      config.unitEnPath = baifenhaoPath
                      config.unitScPath = baifenhaoPath
                      config.unitTcPath = baifenhaoPath
                      break
                    case hmUI.edit_type.STAND:
                      config.bgPath = bg
                      config.iconPath = iconPath + 'STAND.png'
                      config.textPath = textPath + 'STAND.png'
                      config.dataType = hmUI.data_type.STAND
                      break
                    case hmUI.edit_type.HEART:
                      config.bgPath = bg
                      config.iconPath = iconPath + 'HEART.png'
                      config.textPath = textPath + 'HEART.png'
                      config.nonePath = nonePath
                      config.dataType = hmUI.data_type.HEART
                      break
                    case hmUI.edit_type.UVI:
                      config.bgPath = bg
                      config.iconPath = iconPath + 'UVI.png'
                      config.textPath = textPath + 'UVI.png'
                      config.dataType = hmUI.data_type.UVI
                      config.nonePath = nonePath
                      break
                    default:
                      return config
                  }
            }else{
                path = null
                iconPath = ROOTPATH + 'nor/data/icon/big/'
                bg = ROOTPATH + 'nor/widget/bgBig.png'
                config.moveXI=67
                config.moveYI=36
                config.moveXN=39
                config.moveYN=96
                config.width=84
                switch (editType) {
                case hmUI.edit_type.STEP:
                config.bgPath = bg
                config.iconPath = iconPath + 'STEP.png'
                config.dataType = hmUI.data_type.STEP
                config.pointerType = hmUI.data_type.STEP
                break
                case hmUI.edit_type.CAL:
                config.bgPath = bg
                config.iconPath = iconPath + 'CAL.png'
                config.dataType = hmUI.data_type.CAL
                config.pointerType = hmUI.data_type.CAL
                break
                case hmUI.edit_type.DISTANCE:
                config.bgPath = bg
                config.iconPath = iconPath + 'DIS.png'
                config.dataType = hmUI.data_type.DISTANCE
                config.nonePath = nonePath
                config.xiaoshudian = xiaoshudianPath
                config.unitEnPath = ''
                config.unitScPath = ''
                config.unitTcPath = ''
                config.imperial_unit_sc = ''
                config.imperial_unit_en = ''
                config.imperial_unit_tc = ''
                config.pointerType = hmUI.data_type.STEP
                config.padding=true
                break
                case hmUI.edit_type.PAI_WEEKLY:
                config.bgPath = bg
                config.iconPath = iconPath + 'PAI.png'
                config.dataType = hmUI.data_type.PAI_WEEKLY
                config.nonePath = nonePath
                config.pointerType = hmUI.data_type.PAI_WEEKLY
                break
                case hmUI.edit_type.BATTERY:
                config.bgPath = bg
                config.iconPath = iconPath + 'BAT.png'
                config.dataType = hmUI.data_type.BATTERY
                config.unitEnPath = baifenhaoPath
                config.unitScPath = baifenhaoPath
                config.unitTcPath = baifenhaoPath
                config.pointerType = hmUI.data_type.BATTERY
                break
                case hmUI.edit_type.STAND:
                config.bgPath = bg
                config.iconPath = iconPath + 'STAND.png'
                config.dataType = hmUI.data_type.STAND
                config.pointerType = hmUI.data_type.STAND
                break
                case hmUI.edit_type.HEART:
                config.bgPath = bg
                config.iconPath = iconPath + 'HEART.png'
                config.dataType = hmUI.data_type.HEART
                config.nonePath = nonePath
                config.pointerType = hmUI.data_type.HEART
                break
                case hmUI.edit_type.UVI:
                config.bgPath = bg
                config.iconPath = iconPath + 'UVI.png'
                config.dataType = hmUI.data_type.UVI
                config.nonePath = nonePath
                config.pointerType = hmUI.data_type.UVI
                break
                default:
                return config
            }
            }
          return config
        }
        // --------------------------------------------------创建独立可编辑控件函数-------------------------------------
        function drawWidget(widgetType, editType,size) {
          let bgX = 0
          let bgY = 0
          switch (widgetType) {
            case WIDGET_RIGHT:
              bgX = 267
              bgY = 152
              break
            case WIDGET_LEFT:
              bgX = 38
              bgY = 152
              break
            case WIDGET_BOTTOM:
              bgX = 152
              bgY = 269
              break
            default:
              return
          }
          const config = parseWidgetConfig(editType,size)
          const iconX = bgX + config.moveXI
          const iconY = bgY + config.moveYI
          const textX = bgX + config.moveXT
          const textY = bgY + config.moveYT
          const numX = bgX + config.moveXN
          const numY = bgY + config.moveYN
          hmUI.createWidget(hmUI.widget.IMG, {
            x: bgX,
            y: bgY,
            src: config.bgPath,
            show_level: hmUI.show_level.ONLY_NORMAL
          })
          hmUI.createWidget(hmUI.widget.IMG, {
            x: iconX,
            y: iconY,
            src: config.iconPath,
            show_level: hmUI.show_level.ONLY_NORMAL
          })
          let publicTextOption = {
            x: numX,
            y: numY,
            w:config.width,
            align_h: hmUI.align.CENTER_H,
            type: config.dataType,
            h_space: 1,
            font_array: fontArray,
            unit_sc:config.unitScPath,
            unit_en:config.unitEnPath,
            unit_tc:config.unitTcPath,
            imperial_unit_sc:config.imperial_unit_sc,
            imperial_unit_en:config.imperial_unit_en,
            imperial_unit_tc:config.imperial_unit_tc,
            invalid_image:config.nonePath,
            padding:config.padding,
          }
          if(config.dataType == hmUI.data_type.DISTANCE){
          hmUI.createWidget(hmUI.widget.TEXT_IMG, {
           ...publicTextOption,
            dot_image: config.xiaoshudian,
            show_level: hmUI.show_level.ONLY_NORMAL
          })
          }else{
          hmUI.createWidget(hmUI.widget.TEXT_IMG, {
            ...publicTextOption,
            show_level: hmUI.show_level.ONLY_NORMAL
          })
          }

          if(size=='small'){
          // ===========================================================================================
            smallTypeImg = hmUI.createWidget(hmUI.widget.IMG, {
              x: textX,
              y: textY,
              src: config.textPath,
              show_level: hmUI.show_level.ONLY_NORMAL
            })
          // =============================================================================================
          }else{
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                center_x: bgX + 81,
                center_y: bgY + 81,
                x: 10,
                y: 73,
                src: WIDGET_POINTER_PATH,
                type: config.pointerType,
                start_angle: config.startAngle,
                end_angle: config.endAngle,
                show_level: hmUI.show_level.ONLY_NORMAL
              })
          }
          hmUI.createWidget(hmUI.widget.IMG_CLICK,{
            x:bgX,
            y:bgY,
            w:162,
            h:162,
            type:config.dataType, //必写 跳转的action
            });
        }
        function fn(){
          const screenType = hmSetting.getScreenType()
          hmUI.createWidget(hmUI.widget.IMG, bgObj) // 背景图片
          hmUI.createWidget(hmUI.widget.IMG_WEEK, norobjWeek) // 正常星期
          hmUI.createWidget(hmUI.widget.IMG_DATE, norobjDay) // 正常日期
          hmUI.createWidget(hmUI.widget.TEXT_IMG, temp) // 温度
          hmUI.createWidget(hmUI.widget.IMG_LEVEL,weatherObj) // 天气
          pointerNor = hmUI.createWidget(hmUI.widget.TIME_POINTER,timePointer)
          pointerAod = hmUI.createWidget(hmUI.widget.TIME_POINTER,timeAodPointer)
          mask = hmUI.createWidget(hmUI.widget.IMG, objMask) // 遮罩

        // 创建可编辑控件函数
        function drawPublic() {
          // --------------------------------------------------左侧可编辑组件-----------------------------------------------
          let leftOptional =  changeWidgetOption('big')
          let objLeftWidget = {
            edit_id: WIDGET_LEFT_ID,
            x: 38,
            y: 152,
            w: WIDGET_BIG_EDIT_SIZE,
            h: WIDGET_BIG_EDIT_SIZE,
            select_image: selectBig,
            un_select_image: unselectBig,
            default_type: hmUI.edit_type.STEP,
            optional_types: leftOptional,
            count: leftOptional.length,
            tips_BG: 'images/nor/widget/tips.png',
            tips_x: 110,
            tips_y: -126,
            tips_width: 170,
            tips_margin: 10,
            select_list: edit_list_config,
          }
          let leftWidget = hmUI.createWidget(
            hmUI.widget.WATCHFACE_EDIT_GROUP,
            {
              ...objLeftWidget,
              default_type: hmUI.edit_type.STEP
            }
          )
          let lefteditType = leftWidget.getProperty(hmUI.prop.CURRENT_TYPE)
         drawWidget(WIDGET_LEFT, lefteditType,'big')
          // --------------------------------------------------右侧可编辑组件-----------------------------------------------
          let rightOptional =  changeWidgetOption('big')
          let objRightWidget = {
            edit_id: WIDGET_RIGHT_ID,
            x: 267,
            y: 152,
            w: WIDGET_BIG_EDIT_SIZE,
            h: WIDGET_BIG_EDIT_SIZE,
            select_image: selectBig,
            un_select_image: unselectBig,
            default_type: hmUI.edit_type.BATTERY,
            optional_types:  rightOptional,
            count: rightOptional.length,
            tips_BG:'images/nor/widget/tips.png',
            tips_x:-119,
            tips_y:  -126,
            tips_width: 170,
            tips_margin: 10,
            select_list: edit_list_config,
          }
          let rightWidget = hmUI.createWidget(
            hmUI.widget.WATCHFACE_EDIT_GROUP,
            objRightWidget
          )
          let righteditType = rightWidget.getProperty(hmUI.prop.CURRENT_TYPE)
          drawWidget(WIDGET_RIGHT, righteditType,'big')

          // --------------------------------------------------底部可编辑组件-----------------------------------------------
          let bottomOptional =  changeWidgetOption('small')
          let objBottomWidget = {
            edit_id: WIDGET_BOTTOM_ID,
            x: 152,
            y: 269,
            w: WIDGET_SMALL_EDIT_SIZE,
            h: WIDGET_SMALL_EDIT_SIZE,
            select_image: selectSmall,
            un_select_image: unselectSmall,
            default_type: hmUI.edit_type.HEART,
            optional_types:  bottomOptional,
            count: bottomOptional.length,
            tips_BG:'images/nor/widget/tips.png',
            tips_x:-4,
            tips_y:  -243,
            tips_width: 170,
            tips_margin: 10,
            select_list: edit_list_config,
          }
          bottomWidget = hmUI.createWidget(
            hmUI.widget.WATCHFACE_EDIT_GROUP,
            objBottomWidget
          )
          bottomeditType = bottomWidget.getProperty(hmUI.prop.CURRENT_TYPE)
          drawWidget(WIDGET_BOTTOM, bottomeditType,'small')
        }
        if (screenType ==hmSetting.screen_type.WATCHFACE) {
          drawPublic()
          pointerNor = hmUI.createWidget(hmUI.widget.TIME_POINTER,timePointer)
          hmUI.createWidget(hmUI.widget.TIME_POINTER,timeAodPointer)
          mask = hmUI.createWidget(hmUI.widget.IMG, objMask)
        }else{
          hmUI.createWidget(hmUI.widget.IMG, bgObj) // 背景图片
          hmUI.createWidget(hmUI.widget.IMG_WEEK, norobjWeek) // 正常星期
          hmUI.createWidget(hmUI.widget.IMG_DATE, norobjDay) // 正常日期
          hmUI.createWidget(hmUI.widget.TEXT_IMG, temp)
          hmUI.createWidget(hmUI.widget.IMG_LEVEL,weatherObj)
          pointerNor = hmUI.createWidget(hmUI.widget.TIME_POINTER,timePointer)
          hmUI.createWidget(hmUI.widget.TIME_POINTER,timeAodPointer)
          mask = hmUI.createWidget(hmUI.widget.IMG, objMask)
          drawPublic()
        }
        hmUI.createWidget(hmUI.widget.IMG_CLICK,{
          x:191,
          y:68,
          w:110,
          h:42,
          type:hmUI.data_type.WEATHER_CURRENT, //必写 跳转的action
          });
      }
      fn()
      hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
        resume_call: (function () {
          let languageId = hmSetting.getLanguage()
          let textPath = null
          let Path = null
          let widgetPrePath = null
          switch (languageId) {
            case 0:
            textPath= ROOTPATH + 'nor/data/text/sc/'
            widgetPrePath = widgetPreviewSmall +'sc/'
            break;
          case 1:
            textPath = ROOTPATH + 'nor/data/text/tc/'
            widgetPrePath = widgetPreviewSmall +'tc/'
            break;
          case 2:
            textPath = ROOTPATH + 'nor/data/text/en/'
            widgetPrePath = widgetPreviewSmall +'en/'
            break;
            default:
              textPath = ROOTPATH + 'nor/data/text/en/'
              widgetPrePath = widgetPreviewSmall +'en/'
              break;
          }
          bottomeditType = bottomWidget.getProperty(hmUI.prop.CURRENT_TYPE)
          switch (bottomeditType) {
            case hmUI.edit_type.STEP:
              Path = textPath + 'STEP.png'
              break
            case hmUI.edit_type.CAL:
              Path = textPath + 'CAL.png'
              break
            case hmUI.edit_type.DISTANCE:
              Path = textPath + 'DIS.png'
              break
            case hmUI.edit_type.PAI_WEEKLY:
              Path = textPath + 'PAI.png'
              break
            case hmUI.edit_type.BATTERY:
              Path = textPath + 'BAT.png'
              break
            case hmUI.edit_type.STAND:
              Path = textPath + 'STAND.png'
              break
            case hmUI.edit_type.HEART:
              Path = textPath + 'HEART.png'
              break
            case hmUI.edit_type.UVI:
              Path = textPath + 'UVI.png'
              break
            default:
              break;
          }
          let bgX = 152
          let bgY = 269
          let config = parseWidgetConfig(bottomeditType,'small')
          const textX = bgX + config.moveXT
          const textY = bgY + config.moveYT
          smallTypeImg.setProperty(hmUI.prop.MORE, {
            x: textX,
            y: textY,
            src: Path,
            show_level: hmUI.show_level.ONLY_NORMAL
          })


        }),
        pause_call: (function () {
          console.log('ui pause');
        }),
      });

      },

        onInit() {
          console.log('index page.js on init invoke')
          this.init_view()
        },

        onReady() {
          console.log('index page.js on ready invoke')
        },

        onShow() {
          console.log('index page.js on show invoke')
        },

        onHide() {
          console.log('index page.js on hide invoke')
        },

        onDestory() {
          console.log('index page.js on destory invoke')
        },
      })
      /*
       * end js
       */
    })()
  } catch (e) {
    console.log(e)
  }
