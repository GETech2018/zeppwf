try {
  (() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__),
      'drink'
    );

    /*
     * huamiOS bundle tool v1.0.17
     * Copyright © Huami. All Rights Reserved
     */
    ('use strict');

    console.log('----->>>current');
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    // ===============================================================
    const ASCII_START = 65; // A
    let worldCount = 0;
    let world_clock = null;
    let timePointer = null;
    let worldPointer = null;
    let timeZone = null;
    let timeHourImg = null;
    let gmtImg = null;
    let dataArr = [];
    const cityArrayImg = new Array(3);
    const ASSIC_MAX_COUNT = 26;
    const ASCIIARRAY = new Array(ASSIC_MAX_COUNT);
    // 静态资源填充
    // 城市图片路径填充
    const rootPath = 'images/';
    let assicIndex = 0;
    for (let i = ASCII_START; i < ASCII_START + 26; i++) {
      const path = rootPath + 'cityCode/' + String.fromCharCode(i) + '.png';
      ASCIIARRAY[assicIndex++] = path;
    }

    for (let i = 0; i < 10; i++) {
      dataArr.push(rootPath + 'data/' + i + '.png');
    }
    // 熄屏背景
    const objBg = {
      x: 0,
      y: 0,
      w: 466,
      h: 466,
      color: 0x000000,
      show_level: hmUI.show_level.ONAL_AOD,
    };

    // 亮屏背景
    const objImgBg = {
      x: 0,
      y: 0,
      w: 466,
      h: 466,
      src: rootPath + 'img/bg.png',
      show_level: hmUI.show_level.ONLY_NORMAL,
    };

    const objGMT = {
      x: 214 * 0.9708,
      y: 345 * 0.9708,
      w: 31,
      h: 21,
      src: rootPath + 'img/GMT.png',
      show_level: hmUI.show_level.ONLY_NORMAL,
    };

    objCalPointer = {
      // 旋转中心
      center_x: 129 * 0.972,
      center_y: 240 * 0.9708,
      // 指针自身旋转中心偏移的 x y
      x: 25 * 0.9708,
      y: 78 * 0.9708,
      start_angle: 0,
      end_angle: 360,
      type: hmUI.data_type.CAL,
      src: rootPath + 'img/pointer.png',
      show_level: hmUI.show_level.ONLY_NORMAL,
    };

    const objCalText = {
      x: 90, // 112 * 0.9708(之前的数据)  目前数据以指针旋转中心x算的
      y: 258 * 0.9708,
      w: 69,
      type: hmUI.data_type.CAL,
      font_array: dataArr,
      h_space: 0,
      align_h: hmUI.align.CENTER_H,
      // padding: 1,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };

    const objStepPointer = {
      center_x: 241 * 0.972,
      center_y: 150 * 0.9708,
      x: 25 * 0.9708,
      y: 78 * 0.9708,
      start_angle: 0,
      end_angle: 360,
      type: hmUI.data_type.STEP,
      src: rootPath + 'img/pointer.png',
      show_level: hmUI.show_level.ONLY_NORMAL,
    };

    const objStepText = {
      x: 190,
      y: 170 * 0.9708,
      w: 86,
      // padding: 1,  // 补零测试不生效
      type: hmUI.data_type.STEP,
      font_array: dataArr,
      h_space: 0,
      align_h: hmUI.align.CENTER_H,
      padding: false,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };

    const objPaiPointer = {
      center_x: 354 * 0.971,
      center_y: 240 * 0.9708,
      x: 25 * 0.9708,
      y: 78 * 0.9708,
      start_angle: 0,
      end_angle: 360,
      type: hmUI.data_type.PAI_WEEKLY,
      src: rootPath + 'img/pointer.png',
      show_level: hmUI.show_level.ONLY_NORMAL,
    };

    const objPaiText = {
      x: 315, // 342 * 0.9708
      y: 258 * 0.9708,
      w: 56,
      // padding: 1, 不生效
      type: hmUI.data_type.PAI_WEEKLY,
      font_array: dataArr,
      h_space: 0,
      align_h: hmUI.align.CENTER_H,
      padding: false,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };

    const objCityArrayImg = {
      x: 211 * 0.9708,
      y: 297 * 0.9708,
      // w: 20,
      // h: 28,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };

    const objTimeZone = {
      x: 245 * 0.9708,
      y: 346 * 0.9708,
      w: 10 * 0.9709,
      h: 22 * 0.9709,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };

    const objTimeHourImg = {
      x: 258 * 0.9708,
      y: 346 * 0.9708,
      w: 20 * 0.9709,
      h: 22 * 0.9709,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };

    const objNoData = {
      x: 212 * 0.9708,
      y: 305 * 0.9708,
      w: 56 * 0.9709,
      h: 56 * 0.9709,
      src: rootPath + 'img/nodata.png',
      show_level: hmUI.show_level.ONLY_NORMAL,
    };

    const objWorldPointer = {
      x: 0,
      y: 0,
      w: 466,
      h: 466,
      pos_x: (240 - 25) * 0.9708, //  240 - 25
      pos_y: (240 - 235) * 0.9708, //
      center_x: 233,
      center_y: 233,
      angle: 0,
      src: rootPath + 'img/world_pointer.png',
      //   show_level: hmUI.show_level.ALL,
    };

    const objTimePointerAod = {
      hour_centerX: 240 * 0.9708,
      hour_centerY: 240 * 0.9708,
      hour_posX: 28 * 0.9708,
      hour_posY: 188 * 0.9708,
      hour_path: rootPath + 'img/hour.png',

      minute_centerX: 240 * 0.9708,
      minute_centerY: 240 * 0.9708,
      minute_posX: 26 * 0.9708,
      minute_posY: 228 * 0.9708,
      minute_path: rootPath + 'img/min.png',

      minute_cover_path: rootPath + 'img/cover_xp.png',
      minute_cover_x: 227 * 0.9708,
      minute_cover_y: 227 * 0.9708,
      show_level: hmUI.show_level.ONAL_AOD,
    };

    const objTimePointerOther = {
      hour_centerX: 240 * 0.9708,
      hour_centerY: 240 * 0.9708,
      hour_posX: 28 * 0.9708,
      hour_posY: 188 * 0.9708,
      hour_path: rootPath + 'img/hour.png',

      minute_centerX: 240 * 0.9708,
      minute_centerY: 240 * 0.9708,
      minute_posX: 26 * 0.9708,
      minute_posY: 228 * 0.9708,
      minute_path: rootPath + 'img/min.png',

      second_centerX: 240 * 0.9708,
      second_centerY: 240 * 0.9708,
      second_posX: 17 * 0.9708,
      second_posY: 230 * 0.9708,
      second_path: rootPath + 'img/sec.png',

      second_cover_path: rootPath + 'img/sec_cover.png', //指针圆心图片
      second_cover_y: 232 * 0.9708,
      second_cover_x: 232 * 0.9708,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };

    const objStepClick = {
      x: 185,
      y: 100,
      w: 92,
      h: 92,
      type: hmUI.data_type.STEP,
    };

    const objCALClick = {
      x: 73,
      y: 184,
      w: 98,
      h: 98,
      type: hmUI.data_type.CAL,
    };

    const objPAIClick = {
      x: 290,
      y: 187,
      w: 94,
      h: 94,
      type: hmUI.data_type.PAI_WEEKLY,
    };

    function setJsWidgetVisible(widget, visible) {
      if (widget != null) {
        widget.setProperty(hmUI.prop.VISIBLE, visible);
      }
    }
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      showTimeZone(timeZoneHour) {
        var path = rootPath + 'img/jian.png';
        if (timeZoneHour > 0) {
          path = rootPath + 'img/jia.png';
        }

        var path2 = rootPath + 'hour/' + Math.abs(timeZoneHour) + '.png';
        timeZone.setProperty(hmUI.prop.SRC, path);
        timeHourImg.setProperty(hmUI.prop.SRC, path2);
      },

      showCity(cityCode) {
        let index = 0;
        let maxWidth = 0;
        let path = 0;
        let sizeArray = new Array(3);

        for (let char of cityCode) {
          const charCode = char.charCodeAt();
          if (charCode < ASCII_START) {
            continue;
          }
          if (index >= 3) {
            break;
          }
          path = ASCIIARRAY[charCode - ASCII_START];
          const imageInfo = hmUI.getImageInfo(path);
          sizeArray[index] = imageInfo.width;
          maxWidth += imageInfo.width;
          cityArrayImg[index++].setProperty(
            hmUI.prop.SRC,
            ASCIIARRAY[charCode - ASCII_START]
          );
        }
        const bMWidth = 132 * 0.9708;
        const baseX = 174 * 0.9708;
        let startX = baseX + (bMWidth - maxWidth) / 2;
        for (var i = 0; i < 3; i++) {
          cityArrayImg[i].setProperty(hmUI.prop.X, startX);
          startX += sizeArray[i];
        }
      },
      setWorldAngle(hour, min) {
        var angle = 15 * hour + min * 0.25; //min= 360/24/60=0.25; hour= 360/24=15;
        angle = parseInt(angle);
        worldPointer.setProperty(hmUI.prop.ANGLE, angle);
      },
      init_view() {
        var screenType = hmSetting.getScreenType(); // 获取屏幕状态
        // 创建世界时钟传感器
        world_clock = hmSensor.createSensor(hmSensor.id.WORLD_CLOCK);

        if (screenType == hmSetting.screen_type.AOD) {
          // 创建熄屏背景
          img_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, objBg);
        } else {
          // 亮屏状态下背景
          img_bg = hmUI.createWidget(hmUI.widget.IMG, objImgBg);
        }
        // GMT 格林尼治标准时间
        gmtImg = hmUI.createWidget(hmUI.widget.IMG, objGMT);
        // CAL 卡路里 创建卡路里指针控件
        let calPointer = hmUI.createWidget(
          hmUI.widget.IMG_POINTER,
          objCalPointer
        );
        let calTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG, objCalText);
        let stepPointer = hmUI.createWidget(
          hmUI.widget.IMG_POINTER,
          objStepPointer
        );
        let stepTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG, objStepText);
        let paiPointer = hmUI.createWidget(
          hmUI.widget.IMG_POINTER,
          objPaiPointer
        );
        let paiTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG, objPaiText);
        //world  clock=-----------------
        for (let i = 0; i < 3; i++) {
          // 创建三个图片控件
          cityArrayImg[i] = hmUI.createWidget(hmUI.widget.IMG, objCityArrayImg);
        }
        // 创建时区控件
        timeZone = hmUI.createWidget(hmUI.widget.IMG, objTimeZone);

        timeHourImg = hmUI.createWidget(hmUI.widget.IMG, objTimeHourImg);
        // 无数据时图片控件
        let noData = hmUI.createWidget(hmUI.widget.IMG, objNoData);
        // hmUI > addEventlistener
        noData.addEventListener(hmUI.event.CLICK_UP, function (info) {
          // 跳转路径  定义在哪里
          // native 控制的是啥
          hmApp.startApp({ url: 'WorldClockScreen', native: true });
        });
        // 设置空间不可见
        noData.setProperty(hmUI.prop.VISIBLE, false);
        worldPointer = hmUI.createWidget(hmUI.widget.IMG, objWorldPointer);
        timePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER);

        world_clock.init();
        worldCount = world_clock.getWorldClockCount();

        if (worldCount > 0) {
          noData.setProperty(hmUI.prop.VISIBLE, false);
          worldPointer.setProperty(hmUI.prop.VISIBLE, true);
          setJsWidgetVisible(worldPointer, true);
          setJsWidgetVisible(timeZone, true);
          setJsWidgetVisible(timeHourImg, true);
          setJsWidgetVisible(gmtImg, true);
          let worldData = world_clock.getWorldClockInfo(0);
          console.log('worldData+++++++++++++++');
          console.log(JSON.stringify(worldData));

          if (screenType != hmSetting.screen_type.AOD) {
            this.showCity(worldData.cityCode);
            this.showTimeZone(worldData.timeZoneHour);
          }
          this.setWorldAngle(worldData.hour, worldData.minute);
        } else {
          for (var i = 0; i < 3; i++) {
            cityArrayImg[i].setProperty(hmUI.prop.VISIBLE, false);
          }
          worldPointer.setProperty(hmUI.prop.VISIBLE, false);
          timeZone.setProperty(hmUI.prop.VISIBLE, false);
          timeHourImg.setProperty(hmUI.prop.VISIBLE, false);
          gmtImg.setProperty(hmUI.prop.VISIBLE, false);
          noData.setProperty(hmUI.prop.VISIBLE, true);
        }
        world_clock.uninit();
        if (screenType == hmSetting.screen_type.AOD) {
          timePointer.setProperty(hmUI.prop.MORE, objTimePointerAod);
        } else {
          timePointer.setProperty(hmUI.prop.MORE, objTimePointerOther);
        }
        const objDelegate = {
          resume_call: function () {
            console.log('ui resume');
            world_clock.init();
            worldCount = world_clock.getWorldClockCount();
            console.log('worldCount++++++++++++++++' + worldCount);
            if (worldCount > 0) {
              noData.setProperty(hmUI.prop.VISIBLE, false);
              worldPointer.setProperty(hmUI.prop.VISIBLE, true);
              timeZone.setProperty(hmUI.prop.VISIBLE, true);
              timeHourImg.setProperty(hmUI.prop.VISIBLE, true);
              gmtImg.setProperty(hmUI.prop.VISIBLE, true);
              let worldData = world_clock.getWorldClockInfo(0);
              let hour = worldData.hour;
              let min = worldData.minute;
              var angle = 15 * hour + min * 0.25; //min= 360/24/60=0.25; hour= 360/24=15;

              worldPointer.setProperty(hmUI.prop.ANGLE, angle);
              if (!(screenType == hmSetting.screen_type.AOD)) {
                let index = 0;
                let maxWidth = 0;
                let path = 0;
                let sizeArray = new Array(3);

                for (let char of worldData.cityCode) {
                  const charCode = char.charCodeAt();
                  if (charCode < ASCII_START) {
                    continue;
                  }
                  if (index >= 3) {
                    break;
                  }
                  path = ASCIIARRAY[charCode - ASCII_START];
                  const imageInfo = hmUI.getImageInfo(path);
                  sizeArray[index] = imageInfo.width;
                  maxWidth += imageInfo.width;
                  cityArrayImg[index].setProperty(hmUI.prop.VISIBLE, true);
                  cityArrayImg[index++].setProperty(
                    hmUI.prop.SRC,
                    ASCIIARRAY[charCode - ASCII_START]
                  );
                }
                const bMWidth = 132 * 0.9708;
                const baseX = 174 * 0.9708;
                let startX = baseX + (bMWidth - maxWidth) / 2;
                for (var i = 0; i < 3; i++) {
                  cityArrayImg[i].setProperty(hmUI.prop.X, startX);
                  startX += sizeArray[i];
                }
                // this.showTimeZone(worldData.timeZoneHour);
                path = rootPath + 'img/jian.png';
                if (worldData.timeZoneHour > 0) {
                  path = rootPath + 'img/jia.png';
                }

                var path2 =
                  rootPath +
                  'hour/' +
                  Math.abs(worldData.timeZoneHour) +
                  '.png';
                timeZone.setProperty(hmUI.prop.SRC, path);
                timeHourImg.setProperty(hmUI.prop.SRC, path2);
              }
            } else {
              for (var i = 0; i < 3; i++) {
                cityArrayImg[i].setProperty(hmUI.prop.VISIBLE, false);
              }
              worldPointer.setProperty(hmUI.prop.VISIBLE, false);
              timeZone.setProperty(hmUI.prop.VISIBLE, false);
              timeHourImg.setProperty(hmUI.prop.VISIBLE, false);
              gmtImg.setProperty(hmUI.prop.VISIBLE, false);
              noData.setProperty(hmUI.prop.VISIBLE, true);
            }
            world_clock.uninit();
          },
          pause_call: function () {
            console.log('ui pause');
          },
        };

        const vDelegate = hmUI.createWidget(
          hmUI.widget.WIDGET_DELEGATE,
          objDelegate
        );
        hmUI.createWidget(hmUI.widget.IMG_CLICK, objStepClick);
        hmUI.createWidget(hmUI.widget.IMG_CLICK, objCALClick);
        hmUI.createWidget(hmUI.widget.IMG_CLICK, objPAIClick);
      },

      onInit() {
        console.log('index page.js on init invoke');
        this.init_view();
      },

      onReady() {
        console.log('index page.js on ready invoke');
      },

      onShow() {
        console.log('index page.js on show invoke');
      },

      onHide() {
        console.log('index page.js on hide invoke');
      },

      onDestory() {
        console.log('index page.js on destory invoke');
      },
    });
    /*
     * end js
     */
  })();
} catch (e) {
  console.log(e);
}
