try {
  ;(() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp

    var __$$module$$__ = __$$app$$__.current
    var h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__),
      'drink'
    )

    /*
     * huamiOS bundle tool v1.0.17
     * Copyright © Huami. All Rights Reserved
     */
    ;('use strict')

    console.log('----->>>current')
    console.log(__$$hmAppManager$$__.currentApp.pid)
    console.log(__$$hmAppManager$$__.currentApp.current)

    // =========================================================


    // 数组对象
    let norWeek_en = []
    let norWeek_sc = []
    let norWeek_tc = []
    let month_en = []
    let month_sc = []
    let month_tc = []
    let norDate = []
    let batArr = []
    let widgetNum = []
    let widgetOptionalArray = []
    let topWidget = null
    let editType = null
    let widgetText = null
    let bg = null
    // 路径
    const ROOTPATH = 'images/'
    const SPORTROOTPATH = 'images/sport/'

    // 填充静态

    for (let i = 1; i < 13; i++) {
      month_en.push(ROOTPATH + 'sport/month/en/' + i + '.png')
      month_sc.push(ROOTPATH + 'sport/month/sc/' + i + '.png')
      month_tc.push(ROOTPATH + 'sport/month/sc/' + i + '.png')
    }

    for (let i = 1; i < 8; i++) {
      norWeek_en.push(ROOTPATH + 'sport/week/en/' + i + '.png')
      norWeek_sc.push(ROOTPATH + 'sport/week/sc/' + i + '.png')
      norWeek_tc.push(ROOTPATH + 'sport/week/sc/' + i + '.png')
    }

    for (let i = 0; i < 10; i++) {
      norDate.push(ROOTPATH + 'sport/date/' + i + '.png')
      widgetNum.push(ROOTPATH + 'sport/widgetNum/' + i + '.png')
      batArr.push(ROOTPATH + 'sport/bat/' + i + '.png')
    }
   //------------------------------------------------表盘背景图-----------------------------------------------
   let bgObj = {
     x:0,
     y:0,
     src:SPORTROOTPATH+'bgEn.png',
     show_level: hmUI.show_level.ONLY_NORMAL  | hmUI.show_level.ONLY_EDIT,
   }

    //------------------------------------------------正常星期-----------------------------------------------
    let norobjWeek = {
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
      x:48,
      y: 219,
      week_tc: norWeek_tc,
      week_sc: norWeek_sc,
      week_en: norWeek_en,
    }
    //------------------------------------------------正常月份-----------------------------------------------
    let norobjMonth = {
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
      month_startX: 76,
      month_startY: 247,
      month_en_array: month_en,
      month_sc_array: month_sc,
      month_tc_array: month_tc,
      month_is_character: true
    }
    //------------------------------------------------正常日期-----------------------------------------------
    let norobjDay = {
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
      day_startX: 346,
      day_startY: 218,
      day_zero: true,
      day_en_array: norDate,
    }
    //------------------------------------------------正常电量-----------------------------------------------
    let norobjBat = {
      x:181,
      y:309,
      w:120,
      type:hmUI.data_type.BATTERY,
      font_array: batArr,
      h_space: 0,
      align_h:hmUI.align.CENTER_H,
      unit_sc:SPORTROOTPATH + "bat/baifenhao.png",
      //单位
      unit_tc:SPORTROOTPATH + "bat/baifenhao.png",
      //单位
      unit_en:SPORTROOTPATH + "bat/baifenhao.png",
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
    }
    //------------------------------------------------正常电量指针-----------------------------------------------
    let batPointerObj = {
      src: SPORTROOTPATH + "pointer/widgetPointer.png",
      center_x: 233,
      center_y: 299,
      x: 13,
      y: 67,
      type:hmUI.data_type.BATTERY,
      invalid_visible:true,
      start_angle:-93,
      end_angle:-270,
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
    }
    //------------------------------------------------正常时间-----------------------------------------------
    let timePointer = {
      hour_centerX: 233, // 指针旋转中心 对应 centerX
      hour_centerY: 233, // 指针旋转中心 对应 centerY
      hour_posX: 21, // 指针自身旋转中心 对应 position 中的 x
      hour_posY: 177, // 指针自身旋转中心 对应 position 中的 y
      hour_path: SPORTROOTPATH + 'pointer/hour.png',
      minute_centerX: 233, // 指针旋转中心 对应 centerX
      minute_centerY: 233, // 指针旋转中心 对应 centerY
      minute_posX:23, // 指针自身旋转中心 对应 position 中的 x
      minute_posY: 220, // 指针自身旋转中心 对应 position 中的 y
      minute_path: SPORTROOTPATH + 'pointer/minute.png',
      second_centerX: 233, // 指针旋转中心 对应 centerX
      second_centerY: 233, // 指针旋转中心 对应 centerY
      second_posX: 8, // 指针自身旋转中心 对应 position 中的 x
      second_posY: 232, // 指针自身旋转中心 对应 position 中的 y
      second_path: SPORTROOTPATH + 'pointer/second.png',
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
    }
    //------------------------------------------------息屏时间-----------------------------------------------
    let timeAodPointer = {
      hour_centerX: 233, // 指针旋转中心 对应 centerX
      hour_centerY: 233, // 指针旋转中心 对应 centerY
      hour_posX: 21, // 指针自身旋转中心 对应 position 中的 x
      hour_posY: 177, // 指针自身旋转中心 对应 position 中的 y
      hour_path: SPORTROOTPATH + 'pointer/hour.png',
      minute_centerX: 233, // 指针旋转中心 对应 centerX
      minute_centerY: 233, // 指针旋转中心 对应 centerY
      minute_posX:23, // 指针自身旋转中心 对应 position 中的 x
      minute_posY: 220, // 指针自身旋转中心 对应 position 中的 y
      minute_path: SPORTROOTPATH + 'pointer/minute.png',
      show_level: hmUI.show_level.ONAL_AOD,
    }
    // --------------------------------------------------------可编辑遮罩-----------------------------------------
    let objMask = {
      x: 0,
      y: 0,
      w: 466,
      h: 466,
      src: SPORTROOTPATH + 'mask/mask.png',
      show_level: hmUI.show_level.ONLY_EDIT,
    }
    //------------------------------------------------可编辑列表配置--------------------------------
    let edit_list_config = {
      title_font_size: 34,
        title_align_h: hmUI.align.CENTER_H,
        list_item_vspace: 8,
        list_bg_color: 0x0000,
        list_bg_radius: 30,
        list_group_text_font_size: 32,
        list_group_text_align_h: hmUI.align.CENTER_H,
        list_tips_text_font_size: 32,
        list_tips_text_align_h: hmUI.align.LEFT,
    };
    const logger = DeviceRuntimeCore.HmLogger.getLogger('sanjiao')
    __$$module$$__.module = DeviceRuntimeCore.Page({


      init_view() {
       // --------------------------------------------------可编辑控件预览图语言切换---------------------------------------------
       function changeWidgetOption(languageId){
        let temp = null
        switch (languageId) {
          case 0:
           temp = 'sc'
           break;
         case 1:
           temp = 'tc'
           break;
         case 2:
           temp = 'en'
           break;
          default:
            temp = 'en'
            break;
        }
        widgetOptionalArray = [
         { type: hmUI.edit_type.CAL, preview: `images/sport/widget/${temp}/kcal.png` },
         { type: hmUI.edit_type.STEP, preview: `images/sport/widget/${temp}/steps.png` },
         { type: hmUI.edit_type.DISTANCE,preview: `images/sport/widget/${temp}/dist.png`,},
         { type: hmUI.edit_type.PAI_WEEKLY, preview: `images/sport/widget/${temp}/pai.png` },
         { type: hmUI.edit_type.HEART, preview: `images/sport/widget/${temp}/heart.png` },
         { type: hmUI.edit_type.STAND, preview: `images/sport/widget/${temp}/stand.png` },
         { type: hmUI.edit_type.UVI, preview: `images/sport/widget/${temp}/uvi.png` },
         { type: hmUI.edit_type.TEMPERATURE, preview: `images/sport/widget/${temp}/temp.png` },
       ]
       return widgetOptionalArray
      }
      // --------------------------------------------------可编辑控件配置函数---------------------------------------------
      function parseWidgetConfig(languageId,editType) {
        let textObj = {
          step:null,
          cal:null,
          distance:null,
          pai:null,
          heart:null,
          stand:null,
          uvi:null,
          temp:null,
        }
        switch (languageId) {
          case 0:
            textObj.step = '步数'
            textObj.cal = '卡路里'
            textObj.distance = '距离'
            textObj.pai = 'PAI'
            textObj.heart = '心率'
            textObj.stand = '站立'
            textObj.uvi = '紫外线'
            textObj.temp = '温度'
           break;
         case 1:
           textObj.step = '步數'
           textObj.cal = 'KCAL'
           textObj.distance = '距離'
           textObj.pai = 'PAI'
           textObj.heart = '心率'
           textObj.stand = '站立'
           textObj.uvi = '紫外線'
           textObj.temp = '溫度'
           break;
         case 2:
           textObj.step = 'STEPS'
           textObj.cal = 'KCAL'
           textObj.distance = 'DIST'
           textObj.pai = 'PAI'
           textObj.heart = 'HEART'
           textObj.stand = 'STAND'
           textObj.uvi = 'UVI'
           textObj.temp = 'TEMP'
           break;
          default:
            textObj.step = 'STEPS'
            textObj.cal = 'KCAL'
            textObj.distance = 'DIST'
            textObj.pai = 'PAI'
            textObj.heart = 'HEART'
            textObj.stand = 'STAND'
            textObj.uvi = 'UVI'
            textObj.temp = 'TEMP'
            break;
        }
        let config = {
          bgPath: null, //背景图
          dataType: null, //数据类型
          dataType1: null, // 当数据类型为距离时，需要监控步数数据类型
          nonePath: null, //无数据的图片
          xiaoshudian:null, // 小数点
          negative:null, // 负号 图片
          padding:false, // 是否补零
          unitEnPath: null, //单位
          unitScPath: null,
          unitTcPath: null,
          imperial_unit_sc:null,
          imperial_unit_en:null,
          imperial_unit_tc:null,
          text:null // 自定义文本
        }
        switch (editType) {
          // 步数
          case hmUI.edit_type.STEP:
            config.bgPath = SPORTROOTPATH +'widget/10_bg.png'
            config.dataType = hmUI.data_type.STEP
            config.text = textObj.step
            break
          // 消耗
          case hmUI.edit_type.CAL:
            config.bgPath = SPORTROOTPATH +'widget/10_bg.png'
            config.dataType = hmUI.data_type.CAL
            config.text = textObj.cal
            break
          // 距离
          case hmUI.edit_type.DISTANCE:
            config.bgPath = SPORTROOTPATH +'widget/10_bg.png'
            config.dataType = hmUI.data_type.DISTANCE
            config.dataType1 = hmUI.data_type.STEP
            config.nonePath = SPORTROOTPATH + 'widgetNum/null.png'
            config.xiaoshudian = SPORTROOTPATH + 'widgetNum/xiaoshudian.png'
            config.unitEnPath = ''
            config.unitScPath = ''
            config.unitTcPath = ''
            config.imperial_unit_sc = ''
            config.imperial_unit_en = ''
            config.imperial_unit_tc = ''
            config.padding = true
            config.text = textObj.distance
            break
          // 总pai
          case hmUI.edit_type.PAI_WEEKLY:
            config.bgPath = SPORTROOTPATH +'widget/10_bg.png'
            config.dataType = hmUI.data_type.PAI_WEEKLY
            config.nonePath = SPORTROOTPATH + 'widgetNum/null.png'
            config.text = textObj.pai
            break
          // 心率
          case hmUI.edit_type.HEART:
            config.bgPath = SPORTROOTPATH +'widget/12_bg.png'
            config.dataType = hmUI.data_type.HEART
            config.nonePath = SPORTROOTPATH + 'widgetNum/null.png'
            config.text = textObj.heart
            break
          // 站立 1-12
          case hmUI.edit_type.STAND:
            config.bgPath =  SPORTROOTPATH +'widget/12_bg.png'
            config.dataType = hmUI.data_type.STAND
            config.padding = false
            config.text = textObj.stand
            break
          // 紫外线
          case hmUI.edit_type.UVI:
            config.bgPath =  SPORTROOTPATH +'widget/10_bg.png'
            config.dataType = hmUI.data_type.UVI
            config.nonePath = SPORTROOTPATH + 'widgetNum/null.png'
            config.text = textObj.uvi
            break
          // 温度
          case hmUI.edit_type.TEMPERATURE:
            config.bgPath =  SPORTROOTPATH +'widget/10_bg.png'
            config.dataType = hmUI.data_type.WEATHER_CURRENT
            config.unitEnPath = SPORTROOTPATH + 'widgetNum/du.png'
            config.unitScPath = SPORTROOTPATH + 'widgetNum/du.png'
            config.unitTcPath = SPORTROOTPATH + 'widgetNum/du.png'
            config.nonePath = SPORTROOTPATH + 'widgetNum/null.png'
            config.negative = SPORTROOTPATH + 'widgetNum/fuhao.png'
            config.text = textObj.temp
            break
          default:
            return config
        }
        return config
      }
      // --------------------------------------------------创建独立可编辑控件函数-------------------------------------
      function drawWidget(languageId, editType) {
        const config = parseWidgetConfig(languageId,editType)
        hmUI.createWidget(hmUI.widget.IMG, {
          x: 143,
          y: 51,
          src: config.bgPath,
          show_level: hmUI.show_level.ONLY_NORMAL
        })
        widgetText = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 193,
          y: 147,
          align_h:hmUI.align.CENTER_H,
          text:config.text,
          w:80,
          color:0x6a6a6a,
          show_level: hmUI.show_level.ONLY_NORMAL
        })

        let objTextPublic = {
          x: 193,
          y: 123,
          w: 80,
          align_h: hmUI.align.CENTER_H,
          type: config.dataType,
          h_space: -1,
          font_array: widgetNum,
          unit_sc: config.unitScPath,
          unit_en: config.unitEnPath,
          unit_tc: config.unitTcPath,
          imperial_unit_sc:config.imperial_unit_sc,
          imperial_unit_en:config.imperial_unit_en,
          imperial_unit_tc:config.imperial_unit_tc,
          invalid_image: config.nonePath,
          negative_image:config.negative,
          padding: config.padding,
        }
        let objArcPublic = {
          center_x: 234,  // 圆弧中心位置x坐标
          center_y: 142,  // 圆弧中心位置y坐标
          radius: 56,    // 圆弧内半径
          start_angle: -180, // 开始角度
          end_angle: 180,    // 结束角度 (小于'开始角度'时为逆时针)
          color: 0x9a9a9a,  // 填充色
          corner_flag: 0,
          line_width: 4,   // 弧形进度条宽度
        }
            //------------------------------------------------组件公共配置----------------------------

        if(config.dataType == hmUI.data_type.DISTANCE){
          hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
            ...objArcPublic,
            type: config.dataType1, // 设置数据类型来驱动进度,type和level至少要设置一个.
            show_level: hmUI.show_level.ONLY_NORMAL
        })
        hmUI.createWidget(hmUI.widget.TEXT_IMG, {
         ...objTextPublic,
          dot_image: config.xiaoshudian,
          show_level: hmUI.show_level.ONLY_NORMAL
        })
        }else{
        hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
            ...objArcPublic,
            type: config.dataType,
            show_level: hmUI.show_level.ONLY_NORMAL
        })
        hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          ...objTextPublic,
          show_level: hmUI.show_level.ONLY_NORMAL
        })
        }
        hmUI.createWidget(hmUI.widget.IMG_CLICK,{
          x:140,
          y:46,
          w:182,
          h:182,
          type:config.dataType, //必写 跳转的action
          });

      }
      let languageId = hmSetting.getLanguage()
     bg = hmUI.createWidget(hmUI.widget.IMG, bgObj)
      switch (languageId) {
        case 0:
          bg.setProperty(hmUI.prop.SRC, SPORTROOTPATH+'bgSc.png')
          break;
        case 1:
          bg.setProperty(hmUI.prop.SRC, SPORTROOTPATH+'bgTc.png')
          break;
        case 2:
          bg.setProperty(hmUI.prop.SRC, SPORTROOTPATH+'bgEn.png')
          break;

        default:
          bg.setProperty(hmUI.prop.SRC, SPORTROOTPATH+'bgEn.png')
          break;
      }
      const screenType = hmSetting.getScreenType()
      hmUI.createWidget(hmUI.widget.IMG_WEEK,norobjWeek)
      hmUI.createWidget(hmUI.widget.IMG_DATE,norobjMonth)
      hmUI.createWidget(hmUI.widget.IMG_DATE,norobjDay)
      hmUI.createWidget(hmUI.widget.TEXT_IMG, norobjBat)
      function drawWidgetFn(){
        let Optional2 = changeWidgetOption(languageId)
        let objWidget = {
          edit_id: 104,
          x: 140.5,
          y: 47,
          w: 182,
          h: 182,
          select_image: SPORTROOTPATH + 'mask/blue_c.png',
          un_select_image: SPORTROOTPATH + 'mask/blue_c.png',
          default_type: hmUI.edit_type.STEP,
          optional_types: Optional2,
          count: Optional2.length,
          tips_BG: SPORTROOTPATH + 'mask/blue_tip.png',
          tips_x: 5,
          tips_y: 184,
          tips_width: 170,
          tips_margin: 10,
          select_list: edit_list_config,
        }
        topWidget = hmUI.createWidget(
          hmUI.widget.WATCHFACE_EDIT_GROUP,
          objWidget
        )
        editType = topWidget.getProperty(hmUI.prop.CURRENT_TYPE)
        drawWidget(languageId, editType)
      }
      if(screenType == hmSetting.screen_type.WATCHFACE ){
        drawWidgetFn()
        hmUI.createWidget(hmUI.widget.IMG_POINTER, batPointerObj)
        hmUI.createWidget(hmUI.widget.TIME_POINTER,timePointer)
        hmUI.createWidget(hmUI.widget.TIME_POINTER,timeAodPointer)
        mask = hmUI.createWidget(hmUI.widget.IMG, objMask)
      }else{
        hmUI.createWidget(hmUI.widget.IMG_WEEK,norobjWeek)
        hmUI.createWidget(hmUI.widget.IMG_DATE,norobjMonth)
        hmUI.createWidget(hmUI.widget.IMG_DATE,norobjDay)
        hmUI.createWidget(hmUI.widget.TEXT_IMG, norobjBat)
        hmUI.createWidget(hmUI.widget.IMG_POINTER, batPointerObj)
        hmUI.createWidget(hmUI.widget.TIME_POINTER,timePointer)
        hmUI.createWidget(hmUI.widget.TIME_POINTER,timeAodPointer)
        mask = hmUI.createWidget(hmUI.widget.IMG, objMask)
        drawWidgetFn()
      }
      hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
        resume_call: (function () {
          let languageId = hmSetting.getLanguage()
          let textObj = {}
          let config = {}
          switch (languageId) {
            case 0:
            bg.setProperty(hmUI.prop.SRC, SPORTROOTPATH+'bgSc.png')
            textObj.step = '步数'
            textObj.cal = '卡路里'
            textObj.distance = '距离'
            textObj.pai = 'PAI'
            textObj.heart = '心率'
            textObj.stand = '站立'
            textObj.uvi = '紫外线'
            textObj.temp = '温度'
           break;
         case 1:
          bg.setProperty(hmUI.prop.SRC, SPORTROOTPATH+'bgTc.png')
           textObj.step = '步數'
           textObj.cal = 'KCAL'
           textObj.distance = '距離'
           textObj.pai = 'PAI'
           textObj.heart = '心率'
           textObj.stand = '站立'
           textObj.uvi = '紫外線'
           textObj.temp = '溫度'
           break;
         case 2:
          bg.setProperty(hmUI.prop.SRC, SPORTROOTPATH+'bgEn.png')
           textObj.step = 'STEPS'
           textObj.cal = 'KCAL'
           textObj.distance = 'DIST'
           textObj.pai = 'PAI'
           textObj.heart = 'HEART'
           textObj.stand = 'STAND'
           textObj.uvi = 'UVI'
           textObj.temp = 'TEMP'
           break;
          default:
            bg.setProperty(hmUI.prop.SRC, SPORTROOTPATH+'bgEn.png')
            textObj.step = 'STEPS'
            textObj.cal = 'KCAL'
            textObj.distance = 'DIST'
            textObj.pai = 'PAI'
            textObj.heart = 'HEART'
            textObj.stand = 'STAND'
            textObj.uvi = 'UVI'
            textObj.temp = 'TEMP'
            break;
          }
          let dd = topWidget.getProperty(hmUI.prop.CURRENT_TYPE)
          switch (dd) {
            // 步数
            case hmUI.edit_type.STEP:
              config.text = textObj.step
              break
            // 消耗
            case hmUI.edit_type.CAL:
              config.text = textObj.cal
              break
            // 距离
            case hmUI.edit_type.DISTANCE:
              config.text = textObj.distance
              break
            // 总pai
            case hmUI.edit_type.PAI_WEEKLY:
              config.text = textObj.pai
              break
            // 心率
            case hmUI.edit_type.HEART:
              config.text = textObj.heart
              break
            // 站立 1-12
            case hmUI.edit_type.STAND:
              config.text = textObj.stand
              break
            // 紫外线
            case hmUI.edit_type.UVI:
              config.text = textObj.uvi
              break
            // 温度
            case hmUI.edit_type.TEMPERATURE:
              config.text = textObj.temp
              break
              default:
                break;
          }
          widgetText.setProperty(hmUI.prop.MORE, {
            x: 193,
            y: 147,
            align_h:hmUI.align.CENTER_H,
            text:config.text,
            w:80,
            color:0x6a6a6a,
            show_level: hmUI.show_level.ONLY_NORMAL
          })


        }),
        pause_call: (function () {
          console.log('ui pause');
        }),
      });

      },

      onInit() {
        console.log('index page.js on init invoke')
        this.init_view()
      },

      onReady() {
        console.log('index page.js on ready invoke')
      },

      onShow() {
        console.log('index page.js on show invoke')
      },

      onHide() {
        console.log('index page.js on hide invoke')
      },

      onDestory() {
        console.log('index page.js on destory invoke')
      },
    })
    /*
     * end js
     */
  })()
} catch (e) {
  console.log(e)
}
