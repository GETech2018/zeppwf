try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface');
// СВОИ
        let Quote_img = ''// пусто
        let btn_Quote = ''// пусто
        let Quote_num = 0// начальная, прозрачная png
        let Quote_all = 9// всего картинок png

//проверка кнопки	
        function click_Quote() {
            if(Quote_num>=Quote_all) {
		Quote_num=0;		
		}
            else { 
		Quote_num=Quote_num+1;
            	// hmUI.showToast({text: "Цитата " + parseInt(Quote_num) });
		}
            Quote_img.setProperty(hmUI.prop.SRC, "Quote_" + parseInt(Quote_num) + ".png");
            }
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 174,
                    y: 125,
                    type: hmUI.data_type.STEP,
                    font_array: [
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 327,
                    y: 125,
                    type: hmUI.data_type.HEART,
                    font_array: [
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '14.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 243,
                    month_startY: 364,
                    month_sc_array: [
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png'
                    ],
                    month_tc_array: [
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png'
                    ],
                    month_en_array: [
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png'
                    ],
                    month_align: hmUI.align.LEFT,
                    month_zero: 1,
                    month_follow: 0,
                    month_space: 4,
                    month_is_character: false,
                    day_startX: 148,
                    day_startY: 364,
                    day_sc_array: [
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png'
                    ],
                    day_tc_array: [
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png'
                    ],
                    day_en_array: [
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png'
                    ],
                    day_align: hmUI.align.RIGHT,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 4,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 225,
                    y: 397,
                    w: 15,
                    h: 10,
                    src: '25.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 345,
                    y: 300,
                    src: '26.png',
                    type: hmUI.system_status.DISCONNECT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 261,
                    y: 300,
                    src: '27.png',
                    type: hmUI.system_status.DISTURB,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 80,
                    y: 302,
                    src: '28.png',
                    type: hmUI.system_status.LOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 167,
                    y: 303,
                    src: '29.png',
                    type: hmUI.system_status.CLOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 0,
                    hour_startX: 13,
                    hour_startY: 158,
                    hour_array: [
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png'
                    ],
                    hour_space: 5,
                    hour_align: hmUI.align.RIGHT,
                    minute_val: new Date().getMinutes(),
                    minute_zero: 1,
                    minute_startX: 171,
                    minute_startY: 158,
                    minute_array: [
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png'
                    ],
                    minute_space: 5,
                    minute_align: hmUI.align.CENTER_H,
                    minute_follow: 0,
                    second_val: new Date().getSeconds(),
                    second_zero: 1,
                    second_startX: 313,
                    second_startY: 158,
                    second_array: [
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png'
                    ],
                    second_space: 5,
                    second_align: hmUI.align.CENTER_H,
                    second_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 144,
                    y: 154,
                    w: 25,
                    h: 140,
                    src: '40.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 27,
                    y: 350,
                    image_array: [
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png'
                    ],
                    image_length: 10,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 101,
                    y: 21,
                    week_en: [
                        '51.png',
                        '52.png',
                        '53.png',
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png'
                    ],
                    week_tc: [
                        '58.png',
                        '59.png',
                        '60.png',
                        '61.png',
                        '62.png',
                        '63.png',
                        '64.png'
                    ],
                    week_sc: [
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png',
                        '71.png'
                    ],
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 0,
                    hour_startX: 92,
                    hour_startY: 158,
                    hour_array: [
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png'
                    ],
                    hour_space: 5,
                    hour_align: hmUI.align.RIGHT,
                    minute_val: new Date().getMinutes(),
                    minute_zero: 1,
                    minute_startX: 246,
                    minute_startY: 158,
                    minute_array: [
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png'
                    ],
                    minute_space: 5,
                    minute_align: hmUI.align.CENTER_H,
                    minute_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 220,
                    y: 154,
                    w: 25,
                    h: 140,
                    src: '72.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 243,
                    month_startY: 364,
                    month_sc_array: [
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png'
                    ],
                    month_tc_array: [
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png'
                    ],
                    month_en_array: [
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png'
                    ],
                    month_align: hmUI.align.LEFT,
                    month_zero: 1,
                    month_follow: 0,
                    month_space: 4,
                    month_is_character: false,
                    day_startX: 148,
                    day_startY: 364,
                    day_sc_array: [
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png'
                    ],
                    day_tc_array: [
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png'
                    ],
                    day_en_array: [
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png'
                    ],
                    day_align: hmUI.align.RIGHT,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 4,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 225,
                    y: 397,
                    w: 15,
                    h: 10,
                    src: '25.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 151,
                    y: 25,
                    week_en: [
                        '73.png',
                        '74.png',
                        '75.png',
                        '76.png',
                        '77.png',
                        '78.png',
                        '79.png'
                    ],
                    week_tc: [
                        '80.png',
                        '81.png',
                        '82.png',
                        '83.png',
                        '84.png',
                        '85.png',
                        '86.png'
                    ],
                    week_sc: [
                        '87.png',
                        '88.png',
                        '89.png',
                        '90.png',
                        '91.png',
                        '92.png',
                        '93.png'
                    ],
                    show_level: hmUI.show_level.ONLY_AOD
                });
//картинка Пасхалки (0-прозрачная)
            Quote_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Quote_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
// погода
		hmUI.createWidget(hmUI.widget.BUTTON, {
     			x: 141,
     			y: 0,
     			w: 182,
     			h: 115,
     			text: '',
     			normal_src: '14.png',
     			press_src: '14.png',
     			click_func: () => {
				hmApp.startApp({ url: 'WeatherScreen', native: true });  
     			},
     			show_level: hmUI.show_level.ONLY_NORMAL,
		});
// шаги
		hmUI.createWidget(hmUI.widget.BUTTON, {
     			x: 104,
     			y: 121,
     			w: 139,
     			h: 30,
     			text: '',
     			normal_src: '14.png',
     			press_src: '14.png',
     			click_func: () => {
				hmApp.startApp({ url: 'activityAppScreen', native: true });  
     			},
     			show_level: hmUI.show_level.ONLY_NORMAL,
		});
// пульс
		hmUI.createWidget(hmUI.widget.BUTTON, {
     			x: 252,
     			y: 121,
     			w: 116,
     			h: 30,
     			text: '',
     			normal_src: '14.png',
     			press_src: '14.png',
     			click_func: () => {
				hmApp.startApp({ url: 'heart_app_Screen', native: true });  
     			},
     			show_level: hmUI.show_level.ONLY_NORMAL,
		});
// обратный отчет/таймер?
		hmUI.createWidget(hmUI.widget.BUTTON, {
     			x: 17,
     			y: 155,
     			w: 287,
     			h: 144,
     			text: '',
     			normal_src: '14.png',
     			press_src: '14.png',
     			click_func: () => {
				hmApp.startApp({ url: 'CountdownAppScreen', native: true });  
     			},
     			show_level: hmUI.show_level.ONLY_NORMAL,
		});
// секундомер
		hmUI.createWidget(hmUI.widget.BUTTON, {
     			x: 309,
     			y: 155,
     			w: 139,
     			h: 144,
     			text: '',
     			normal_src: '14.png',
     			press_src: '14.png',
     			click_func: () => {
				hmApp.startApp({ url: 'StopWatchScreen', native: true });  
     			},
     			show_level: hmUI.show_level.ONLY_NORMAL,
		});
// 2й. будильник
		hmUI.createWidget(hmUI.widget.BUTTON, {
     			x: 154,
     			y: 299,
     			w: 82,
     			h: 58,
     			text: '',
     			normal_src: '14.png',
     			press_src: '14.png',
     			click_func: () => {
				hmApp.startApp({ url: 'AlarmInfoScreen', native: true });  
     			},
     			show_level: hmUI.show_level.ONLY_NORMAL,
		});
// календарь
		hmUI.createWidget(hmUI.widget.BUTTON, {
     			x: 145,
     			y: 360,
     			w: 176,
     			h: 107,
     			text: '',
     			normal_src: '14.png',
     			press_src: '14.png',
     			click_func: () => {
				hmApp.startApp({ url: 'ScheduleCalScreen', native: true });  
     			},
     			show_level: hmUI.show_level.ONLY_NORMAL,
		});
//кнопка Пасхалки
            btn_Quote = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 350,//x кнопки
              y: 378,//y кнопки
              text: '',
              w: 65,//ширина кнопки
              h: 57,//высота кнопки
              normal_src: '14.png', 
              press_src: '14.png',
              click_func: () => {
               click_Quote();//имя вызываемой функции
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_Quote.setProperty(hmUI.prop.VISIBLE, true);
            },

            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}