try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_f94f4ce199534fb096c2b067a7a125e1 = '';
        let dateFormat = '';
        let dateFormatMap = '';
        let normal$_$text_844a0ad3e1bc4801a3f11e75f23fbfd5 = '';
        let normal$_$text_a05b346f50a34c40a5d6abba76bbb5e8 = '';
        let normal$_$text_46a090703ce24ca5a97244089a0e49fb = '';
        let normal$_$text_95358072844d43a185212853d3454379 = '';
        let timeSensor = '';
        let heartSensor = '';
        let stepSensor = '';
        let calorieSensor = '';
        const logger = Logger.getLogger('watchface6');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
                    edit_id: 1,
                    x: 0,
                    y: 0,
                    bg_config: [
                        {
                            'id': 1,
                            'path': '4.png',
                            'preview': '4.png'
                        },
                        {
                            'id': 2,
                            'path': '5.png',
                            'preview': '5.png'
                        },
                        {
                            'id': 3,
                            'path': '6.png',
                            'preview': '6.png'
                        },
                        {
                            'id': 4,
                            'path': '7.png',
                            'preview': '7.png'
                        },
                        {
                            'id': 5,
                            'path': '8.png',
                            'preview': '8.png'
                        },
                        {
                            'id': 6,
                            'path': '9.png',
                            'preview': '9.png'
                        },
                        {
                            'id': 7,
                            'path': '10.png',
                            'preview': '10.png'
                        },
                        {
                            'id': 8,
                            'path': '11.png',
                            'preview': '11.png'
                        }
                    ],
                    count: 8,
                    default_id: 1,
                    fg: '3.png',
                    tips_x: 0,
                    tips_y: 0,
                    tips_bg: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                });
                normal$_$text_f94f4ce199534fb096c2b067a7a125e1 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 212,
                    y: 41,
                    w: 100,
                    h: 30,
                    text: '[YEAR].[MON_Z].[DAY_Z]',
                    color: '0xFFffffff',
                    text_size: 20,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.RIGHT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_844a0ad3e1bc4801a3f11e75f23fbfd5 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 148,
                    y: 16,
                    w: 160,
                    h: 25,
                    text: '[WEEK_EN_F]',
                    color: '0xFF808080',
                    text_size: 20,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_a05b346f50a34c40a5d6abba76bbb5e8 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 173,
                    y: 375,
                    w: 100,
                    h: 25,
                    text: '[HR] bpm',
                    color: '0xFF808080',
                    text_size: 20,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_46a090703ce24ca5a97244089a0e49fb = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 203,
                    y: 402,
                    w: 120,
                    h: 25,
                    text: '[SC] steps',
                    color: '0xFFffffff',
                    text_size: 20,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.RIGHT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_95358072844d43a185212853d3454379 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 173,
                    y: 429,
                    w: 100,
                    h: 25,
                    text: '[CAL] kcal',
                    color: '0xFF808080',
                    text_size: 20,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 0,
                    hour_centerY: 233,
                    hour_posX: 225,
                    hour_posY: 225,
                    hour_path: '12.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 466,
                    minute_centerY: 233,
                    minute_posX: 225,
                    minute_posY: 225,
                    minute_path: '13.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    second_centerX: 466,
                    second_centerY: 233,
                    second_posX: 225,
                    second_posY: 225,
                    second_path: '14.png',
                    second_cover_x: 0,
                    second_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: '15.png',
                    center_x: 0,
                    center_y: 233,
                    x: 3,
                    y: 64,
                    type: hmUI.data_type.BATTERY,
                    start_angle: 165,
                    end_angle: 15,
                    cover_x: 0,
                    cover_y: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                if (!timeSensor) {
                    timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                }
                if (!heartSensor) {
                    heartSensor = hmSensor.createSensor(hmSensor.id.HEART);
                }
                if (!stepSensor) {
                    stepSensor = hmSensor.createSensor(hmSensor.id.STEP);
                }
                if (!calorieSensor) {
                    calorieSensor = hmSensor.createSensor(hmSensor.id.CALORIE);
                }
                timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_f94f4ce199534fb096c2b067a7a125e1.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }.${ String(timeSensor.month).padStart(2, '0') }.${ String(timeSensor.day).padStart(2, '0') }` });
                        },
                        () => {
                            normal$_$text_f94f4ce199534fb096c2b067a7a125e1.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }.${ String(timeSensor.month).padStart(2, '0') }.${ timeSensor.year }` });
                        },
                        () => {
                            normal$_$text_f94f4ce199534fb096c2b067a7a125e1.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }.${ String(timeSensor.day).padStart(2, '0') }.${ timeSensor.year }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                    const WEEK_EN_F = function (val) {
                        const valueMap = {
                            '1': 'Monday',
                            '2': 'Tuesday',
                            '3': 'Wednesday',
                            '4': 'Thursday',
                            '5': 'Friday',
                            '6': 'Saturday',
                            '7': 'Sunday'
                        };
                        return valueMap[val];
                    };
                    normal$_$text_844a0ad3e1bc4801a3f11e75f23fbfd5.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_F(timeSensor.week) }` });
                }), heartSensor.addEventListener(heartSensor.event.LAST, function () {
                    normal$_$text_a05b346f50a34c40a5d6abba76bbb5e8.setProperty(hmUI.prop.MORE, { text: `${ heartSensor.last } bpm` });
                }), stepSensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_46a090703ce24ca5a97244089a0e49fb.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current } steps` });
                }), calorieSensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_95358072844d43a185212853d3454379.setProperty(hmUI.prop.MORE, { text: `${ calorieSensor.current } kcal` });
                });
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                normal$_$text_f94f4ce199534fb096c2b067a7a125e1.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }.${ String(timeSensor.month).padStart(2, '0') }.${ String(timeSensor.day).padStart(2, '0') }` });
                            },
                            () => {
                                normal$_$text_f94f4ce199534fb096c2b067a7a125e1.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }.${ String(timeSensor.month).padStart(2, '0') }.${ timeSensor.year }` });
                            },
                            () => {
                                normal$_$text_f94f4ce199534fb096c2b067a7a125e1.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }.${ String(timeSensor.day).padStart(2, '0') }.${ timeSensor.year }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                        const WEEK_EN_F = function (val) {
                            const valueMap = {
                                '1': 'Monday',
                                '2': 'Tuesday',
                                '3': 'Wednesday',
                                '4': 'Thursday',
                                '5': 'Friday',
                                '6': 'Saturday',
                                '7': 'Sunday'
                            };
                            return valueMap[val];
                        };
                        normal$_$text_844a0ad3e1bc4801a3f11e75f23fbfd5.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_F(timeSensor.week) }` });
                        normal$_$text_a05b346f50a34c40a5d6abba76bbb5e8.setProperty(hmUI.prop.MORE, { text: `${ heartSensor.last } bpm` });
                        normal$_$text_46a090703ce24ca5a97244089a0e49fb.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current } steps` });
                        normal$_$text_95358072844d43a185212853d3454379.setProperty(hmUI.prop.MORE, { text: `${ calorieSensor.current } kcal` });
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}