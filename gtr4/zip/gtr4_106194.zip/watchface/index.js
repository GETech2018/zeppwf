try {
    (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;

        var __$$module$$__ = __$$app$$__.current;
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        /*
      * huamiOS bundle tool v1.0.17
      * Copyright © Huami. All Rights Reserved
      */
        'use strict';

        console.log("----->>>current");
        console.log(__$$hmAppManager$$__.currentApp.pid);
        console.log(__$$hmAppManager$$__.currentApp.current);

        let rootPath = null
        let weekScArray = []
        let weekEnArray = []
        let fontArray = []
        let timeArray = []
        let dontPath = null
        let bg = null
        let btText = null
        let click = null
        let btIcon = null
        let weekNor = null
        let month = null
        let animCreate = null
        let time = null
        let size = 'middle'
        let editGroup = null
        const logger = DeviceRuntimeCore.HmLogger.getLogger("defult");
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({



            init_view() {
                rootPath = "images/";
                for (let i = 1; i < 8; i++) {
                    weekScArray.push(rootPath + "num/" + size + "/week_sc/0" + i + ".png")
                    weekEnArray.push(rootPath + "num/" + size + "/week_en/0" + i + ".png")
                }
                for (let i = 0; i < 10; i++) {
                    fontArray.push(rootPath + "num/" + size + "/data/0" + i + ".png")
                    timeArray.push(rootPath + "num/" + size + "/time/0" + i + ".png")
                }

                dontPath = rootPath + "num/" + size + "/data/gan.png";
                var screenType = hmSetting.getScreenType();
                var nomalModel = screenType == hmSetting.screen_type.APP || screenType == hmSetting.screen_type.WATCHFACE;
                var aodModel = screenType == hmSetting.screen_type.AOD;

                let bg = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 466,
                    h: 466,
                    src: rootPath + "bg.png",
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
                })

                btIcon = hmUI.createWidget(hmUI.widget.IMG, {

                    show_level: hmUI.show_level.ONLY_NORMAL | hmSetting.screen_type.AOD
                });

                btText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {

                    show_level: hmUI.show_level.ONLY_NORMAL | hmSetting.screen_type.AOD,
                });

                weekNor = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 325 * 0.971,
                    y: 131 * 0.971,
                    week_tc: weekScArray,
                    week_sc: weekScArray,
                    week_en: weekEnArray,
                    show_level:hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD,
                });
                let weekEdit  = hmUI.createWidget(hmUI.widget.IMG_WEEK,{
                    x: 325 * 0.971,
                    y: 134 * 0.971,
                    week_tc:weekScArray,
                    week_sc:weekScArray,
                    week_en:weekEnArray,
                    show_level:hmUI.show_level.ONLY_EDIT,
                });
                month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    show_level: hmUI.show_level.ALL,
                    month_startX: 214 * 0.971,
                    month_startY: 135 * 0.971,
                    month_zero: true,
                    month_en_array: fontArray,
                    month_align: hmUI.align.LEFT,
                    month_unit_sc: dontPath,
                    month_unit_tc: dontPath,
                    month_unit_en: dontPath,
                    day_follow: true,
                    day_zero: true,
                    day_en_array: fontArray,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmSetting.screen_type.AOD,
                });


                time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: true,
                    hour_startX: 120 * 0.971,
                    hour_startY: 190 * 0.971,
                    hour_array: timeArray,
                    hour_space: 0,
                    hour_unit_sc: rootPath + "num/" + size + "/time/colon.png",
                    hour_unit_tc: rootPath + "num/" + size + "/time/colon.png",
                    hour_unit_en: rootPath + "num/" + size + "/time/colon.png",
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1, //是否补零 1为补零
                    minute_follow: true, //是否跟随
                    minute_array: timeArray,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmSetting.screen_type.AOD,
                });

                var editConfig = [
                    { type: hmUI.edit_type.BATTERY, preview: rootPath + "icon/" + size + "/bat_preview.png" },
                    { type: hmUI.edit_type.CAL, preview: rootPath + "icon/" + size + "/cal_preview.png" },
                    { type: hmUI.edit_type.HEART, preview: rootPath + "icon/" + size + "/heart_preview.png" },
                    { type: hmUI.edit_type.STEP, preview: rootPath + "icon/" + size + "/step_preview.png" },
                    { type: hmUI.edit_type.HUMIDITY, preview: rootPath + "icon/" + size + "/humi_preview.png" },
                ];
                let edit_list_config = {
                    title_font_size: 34,
                    title_align_h: hmUI.align.CENTER_H,
                    list_item_vspace: 8,
                    list_bg_color: 0x0000,
                    list_bg_radius: 30,
                    list_group_text_font_size: 32,
                    list_group_text_align_h: hmUI.align.CENTER_H,
                    list_tips_text_font_size: 32,
                    list_tips_text_align_h: hmUI.align.LEFT,
                };
                editGroup = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    show_level: hmUI.show_level.ALL,
                    edit_id: 101,
                    x: 267 * 0.971,
                    y: 308 * 0.971,
                    w: 170 * 0.971,
                    h: 57 * 0.971,
                    select_image: rootPath + "edit/selected.png",
                    un_select_image: rootPath + "edit/selected.png",
                    default_type: hmUI.edit_type.STEP,
                    optional_types: editConfig,
                    count: editConfig.length,
                    tips_BG: rootPath + "edit/tag.png",
                    tips_x: (321 - 288) * 0.971,
                    tips_y: (262 - 308) * 0.971,
                    tips_width: 104 * 0.971,
                    tips_margin: 10,
                    select_list: edit_list_config, // 新增配置选项
                });
                var editType = editGroup.getProperty(hmUI.prop.CURRENT_TYPE);
                var topProp = {
                    x: 224 * 0.971,
                    y: 308 * 0.971,
                    w: 200 * 0.971,
                    h: 45 * 0.971,
                    h_space: 0,
                    align_h: hmUI.align.RIGHT,
                    icon_space: 0,
                    font_array: fontArray,
                }
                let objClickStyle = {
                    x: 270 * 0.971,
                    y: 308 * 0.971,
                    w: 165 * 0.971,
                    h: 57 * 0.971,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }
                switch (editType) {
                    case hmUI.edit_type.HEART:
                        topProp.invalid_image = rootPath + "num/" + size + "/data/invalid.png",
                            topProp.type = hmUI.data_type.HEART;
                        topProp.icon = rootPath + "icon/" + size + "/heart.png";
                        btText = hmUI.createWidget(hmUI.widget.TEXT_IMG, topProp);
                        click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                            ...objClickStyle,
                            type: hmUI.data_type.HEART, //必写 跳转的action
                        })
                        break;
                    case hmUI.edit_type.BATTERY:
                        topProp.invalid_image = rootPath + "num/" + size + "/data/invalid.png",
                            topProp.type = hmUI.data_type.BATTERY;
                        topProp.icon = rootPath + "icon/" + size + "/bat.png";
                        topProp.unit_en = rootPath + "num/" + size + "/data/per.png",
                            topProp.unit_sc = rootPath + "num/" + size + "/data/per.png",
                            topProp.unit_tc = rootPath + "num/" + size + "/data/per.png",
                            btText = hmUI.createWidget(hmUI.widget.TEXT_IMG, topProp);
                        break;
                    case hmUI.edit_type.STEP:
                        topProp.type = hmUI.data_type.STEP;
                        topProp.icon = rootPath + "icon/" + size + "/step.png";
                        btText = hmUI.createWidget(hmUI.widget.TEXT_IMG, topProp);
                        click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                            ...objClickStyle,
                            type: hmUI.data_type.STEP, //必写 跳转的action
                        })
                        break;
                    case hmUI.edit_type.CAL:
                        topProp.type = hmUI.data_type.CAL;
                        topProp.icon = rootPath + "icon/" + size + "/cal.png";
                        btText = hmUI.createWidget(hmUI.widget.TEXT_IMG, topProp);
                        click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                            ...objClickStyle,
                            type: hmUI.data_type.CAL, //必写 跳转的action
                        })
                        break;
                    case hmUI.edit_type.HUMIDITY:
                        topProp.type = hmUI.data_type.HUMIDITY;
                        topProp.invalid_image = rootPath + "num/" + size + "/data/invalid.png",
                            topProp.icon = rootPath + "icon/" + size + "/humi.png";
                        topProp.unit_en = rootPath + "num/" + size + "/data/per.png",
                            topProp.unit_sc = rootPath + "num/" + size + "/data/per.png",
                            topProp.unit_tc = rootPath + "num/" + size + "/data/per.png",
                            btText = hmUI.createWidget(hmUI.widget.TEXT_IMG, topProp);
                        click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                            ...objClickStyle,
                            type: hmUI.data_type.HUMIDITY, //必写 跳转的action
                        })
                        break;
                }


                mask100 = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 466,
                    h: 466,
                    src: rootPath + "edit/you_edit.png",
                    show_level: hmUI.show_level.ONLY_EDIT,
                });

                mask70 = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 466,
                    h: 466,
                    src: rootPath + "edit/mask70.png",
                    show_level: hmUI.show_level.ONLY_EDIT,
                });
                // 获取颜色方法----------------------------------------------------
                let getColor = readColor();
                weekNor.setColor(getColor);
                month.setColor(getColor);
                time.setColor(getColor);
                btText.setColor(getColor);

                function readColor() {
                    //资源文件路径: assets/config.json
                    const file_name = 'config.json';
                    // 获取文件信息
                    // stat_asset 获取应用 assets 目录下的文件信息
                    const [file_stat, err] = hmFS.stat_asset(file_name);
                    if (err == 0) {
                        console.log('file size:', file_stat.size);
                    } else {
                        console.log('err:', err);
                    }
                    // 根据文件大小申请 buffer
                    var test_buf = new Uint8Array(file_stat.size);
                    //打开文件(hmFS.O_RDONLY ：打开方式为只读只读)
                    var fd = hmFS.open_asset(file_name, hmFS.O_RDONLY);
                    //定位到文件开始位置
                    // seek 移动文件指针
                    // hmFS.SEEK_SET 我的理解是通过 hmFS.SEEK_SET 设置指针跳转到 fd文件的 0 位置（开头）
                    hmFS.seek(fd, 0, hmFS.SEEK_SET);
                    // 读取 buffer
                    hmFS.read(fd, test_buf.buffer, 0, test_buf.length);
                    // 关闭文件
                    hmFS.close(fd);
                    //打印读取内容 (config.json内容)
                    // fromCharCode 是 string 对象的静态方法，用于将二进制编码转为字符串
                    // apply 修改 this 指向，返回一个新的方法，test_buf 参数数组
                    // 所以 val 最终得到的是 JSON 格式字符串
                    const val = String.fromCharCode.apply(null, test_buf);
                    contentObj = val ? JSON.parse(val) : {};
                    const colors = parseInt('0x' + contentObj.foreground.color);
                    return colors;
                }

            },

            onInit() {
                console.log('index page.js on init invoke');

                this.init_view();


            },

            onReady() {
                console.log('index page.js on ready invoke')
            },

            onShow() {
                console.log('index page.js on show invoke')
            },

            onHide() {
                console.log('index page.js on hide invoke')
            },

            onDestory() {
                console.log('index page.js on destory invoke')
            },
        });
        /*
        * end js
        */
    })()
} catch (e) {
    console.log(e)
}