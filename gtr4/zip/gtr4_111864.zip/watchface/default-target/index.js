try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$component_0$_$component = '';
        const logger = Logger.getLogger('watchface6');

        let pointerEdit, pointer, aodPointer;
        const pointerConfig = [
            {
                id: 1,
                second: {
                    centerX: 379,
                    centerY: 233,
                    posX: 59,
                    posY: 59,
                    path: '93.png'
                },
                preview: '101.png'
            },
            {
                id: 2,
                second: {
                    centerX: 379,
                    centerY: 233,
                    posX: 59,
                    posY: 59,
                    path: '94.png'
                },
                preview: '102.png'
            },
            {
                id: 3,
                second: {
                    centerX: 379,
                    centerY: 233,
                    posX: 59,
                    posY: 59,
                    path: '95.png'
                },
                preview: '103.png'
            },
            {
                id: 4,
                second: {
                    centerX: 379,
                    centerY: 233,
                    posX: 59,
                    posY: 59,
                    path: '96.png'
                },
                preview: '104.png'
            },
            {
                id: 5,
                second: {
                    centerX: 379,
                    centerY: 233,
                    posX: 59,
                    posY: 59,
                    path: '97.png'
                },
                preview: '105.png'
            },
            {
                id: 6,
                second: {
                    centerX: 379,
                    centerY: 233,
                    posX: 59,
                    posY: 59,
                    path: '98.png'
                },
                preview: '106.png'
            },
            {
                id: 7,
                second: {
                    centerX: 379,
                    centerY: 233,
                    posX: 59,
                    posY: 59,
                    path: '99.png'
                },
                preview: '107.png'
            },
            {
                id: 8,
                second: {
                    centerX: 379,
                    centerY: 233,
                    posX: 59,
                    posY: 59,
                    path: '100.png'
                },
                preview: '108.png'
            }
        ];

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
                    edit_id: 1,
                    x: 0,
                    y: 0,
                    bg_config: [
                        {
                            'id': 1,
                            'path': '4.png',
                            'preview': '5.png'
                        },
                        {
                            'id': 2,
                            'path': '6.png',
                            'preview': '7.png'
                        },
                        {
                            'id': 3,
                            'path': '8.png',
                            'preview': '9.png'
                        },
                        {
                            'id': 4,
                            'path': '10.png',
                            'preview': '11.png'
                        },
                        {
                            'id': 5,
                            'path': '12.png',
                            'preview': '13.png'
                        },
                        {
                            'id': 6,
                            'path': '14.png',
                            'preview': '15.png'
                        },
                        {
                            'id': 7,
                            'path': '16.png',
                            'preview': '17.png'
                        },
                        {
                            'id': 8,
                            'path': '18.png',
                            'preview': '19.png'
                        }
                    ],
                    count: 8,
                    default_id: 1,
                    fg: '3.png',
                    tips_x: 163,
                    tips_y: 208,
                    tips_bg: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD | hmUI.show_level.ONLY_EDIT
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 50,
                    hour_startY: 183,
                    hour_array: [
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png'
                    ],
                    hour_space: 0,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 176,
                    minute_startY: 183,
                    minute_array: [
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png'
                    ],
                    minute_space: 0,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    am_x: 276,
                    am_y: 253,
                    am_en_path: '30.png',
                    pm_x: 276,
                    pm_y: 253,
                    pm_en_path: '31.png',
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 146,
                    y: 183,
                    w: 30,
                    h: 100,
                    src: '32.png',
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 250,
                    month_startY: 100,
                    month_en_array: [
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png'
                    ],
                    month_align: hmUI.align.LEFT,
                    month_zero: 0,
                    month_follow: 0,
                    month_space: 0,
                    month_is_character: true,
                    day_startX: 174,
                    day_startY: 68,
                    day_en_array: [
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png',
                        '54.png'
                    ],
                    day_align: hmUI.align.LEFT,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 0,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 250,
                    y: 68,
                    week_en: [
                        '55.png',
                        '56.png',
                        '57.png',
                        '58.png',
                        '59.png',
                        '60.png',
                        '61.png'
                    ],
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                normal$_$component_0$_$component = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: 2,
                    x: 78,
                    y: 334,
                    w: 310,
                    h: 65,
                    select_image: '64.png',
                    un_select_image: '65.png',
                    default_type: hmUI.edit_type.STEP,
                    optional_types: [
                        {
                            'type': hmUI.edit_type.STEP,
                            'preview': '67.png'
                        },
                        {
                            'type': hmUI.edit_type.SPO2,
                            'preview': '68.png'
                        },
                        {
                            'type': hmUI.edit_type.BATTERY,
                            'preview': '69.png'
                        },
                        {
                            'type': hmUI.edit_type.CAL,
                            'preview': '70.png'
                        },
                        {
                            'type': hmUI.edit_type.DISTANCE,
                            'preview': '71.png'
                        },
                        {
                            'type': hmUI.edit_type.HEART,
                            'preview': '72.png'
                        },
                        {
                            'type': hmUI.edit_type.PAI_DAILY,
                            'preview': '73.png'
                        }
                    ],
                    count: 7,
                    tips_BG: '66.png',
                    tips_x: 85,
                    tips_y: -71,
                    tips_width: 140,
                    tips_margin: 0
                });
                editType = normal$_$component_0$_$component.getProperty(hmUI.prop.CURRENT_TYPE);
                switch (editType) {
                case hmUI.edit_type.STEP:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 78,
                        y: 334,
                        type: hmUI.data_type.STEP,
                        font_array: [
                            '45.png',
                            '46.png',
                            '47.png',
                            '48.png',
                            '49.png',
                            '50.png',
                            '51.png',
                            '52.png',
                            '53.png',
                            '54.png'
                        ],
                        align_h: hmUI.align.RIGHT,
                        h_space: 0,
                        padding: false,
                        isCharacter: false,
                        show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 250,
                        y: 366,
                        w: 72,
                        h: 33,
                        src: '74.png',
                        show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 250,
                        y: 334,
                        src: '75.png',
                        show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 78,
                        y: 334,
                        w: 310,
                        h: 132,
                        type: hmUI.data_type.STEP,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.BATTERY:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 142,
                        y: 334,
                        type: hmUI.data_type.BATTERY,
                        font_array: [
                            '45.png',
                            '46.png',
                            '47.png',
                            '48.png',
                            '49.png',
                            '50.png',
                            '51.png',
                            '52.png',
                            '53.png',
                            '54.png'
                        ],
                        align_h: hmUI.align.RIGHT,
                        h_space: 0,
                        padding: false,
                        isCharacter: false,
                        show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 250,
                        y: 366,
                        w: 72,
                        h: 33,
                        src: '76.png',
                        show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 250,
                        y: 334,
                        src: '77.png',
                        show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                    });
                    break;
                case hmUI.edit_type.HEART:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 142,
                        y: 334,
                        type: hmUI.data_type.HEART,
                        font_array: [
                            '45.png',
                            '46.png',
                            '47.png',
                            '48.png',
                            '49.png',
                            '50.png',
                            '51.png',
                            '52.png',
                            '53.png',
                            '54.png'
                        ],
                        align_h: hmUI.align.RIGHT,
                        h_space: 0,
                        invalid_image: '78.png',
                        padding: false,
                        isCharacter: false,
                        show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 250,
                        y: 366,
                        w: 72,
                        h: 33,
                        src: '79.png',
                        show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 250,
                        y: 334,
                        src: '80.png',
                        show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 78,
                        y: 334,
                        w: 310,
                        h: 132,
                        type: hmUI.data_type.HEART,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.CAL:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 110,
                        y: 334,
                        type: hmUI.data_type.CAL,
                        font_array: [
                            '45.png',
                            '46.png',
                            '47.png',
                            '48.png',
                            '49.png',
                            '50.png',
                            '51.png',
                            '52.png',
                            '53.png',
                            '54.png'
                        ],
                        align_h: hmUI.align.RIGHT,
                        h_space: 0,
                        padding: false,
                        isCharacter: false,
                        show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 250,
                        y: 366,
                        w: 72,
                        h: 33,
                        src: '81.png',
                        show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 250,
                        y: 334,
                        src: '82.png',
                        show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 78,
                        y: 334,
                        w: 310,
                        h: 132,
                        type: hmUI.data_type.CAL,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.PAI_DAILY:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 142,
                        y: 334,
                        type: hmUI.data_type.PAI_DAILY,
                        font_array: [
                            '45.png',
                            '46.png',
                            '47.png',
                            '48.png',
                            '49.png',
                            '50.png',
                            '51.png',
                            '52.png',
                            '53.png',
                            '54.png'
                        ],
                        align_h: hmUI.align.RIGHT,
                        h_space: 0,
                        padding: false,
                        isCharacter: false,
                        show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 250,
                        y: 366,
                        w: 72,
                        h: 33,
                        src: '83.png',
                        show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 250,
                        y: 334,
                        src: '84.png',
                        show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 78,
                        y: 334,
                        w: 310,
                        h: 132,
                        type: hmUI.data_type.PAI_DAILY,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.DISTANCE:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 92,
                        y: 334,
                        type: hmUI.data_type.DISTANCE,
                        font_array: [
                            '45.png',
                            '46.png',
                            '47.png',
                            '48.png',
                            '49.png',
                            '50.png',
                            '51.png',
                            '52.png',
                            '53.png',
                            '54.png'
                        ],
                        align_h: hmUI.align.RIGHT,
                        h_space: 0,
                        unit_en: '86.png',
                        imperial_unit_en: '87.png',
                        dot_image: '85.png',
                        padding: false,
                        isCharacter: false,
                        show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 250,
                        y: 334,
                        src: '88.png',
                        show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 78,
                        y: 334,
                        w: 310,
                        h: 132,
                        type: hmUI.data_type.DISTANCE,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.AQI:
                    break;
                case hmUI.edit_type.HUMIDITY:
                    break;
                case hmUI.edit_type.ALTIMETER:
                    break;
                case hmUI.edit_type.STRESS:
                    break;
                case hmUI.edit_type.WIND:
                    break;
                case hmUI.edit_type.SPO2:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 142,
                        y: 334,
                        type: hmUI.data_type.SPO2,
                        font_array: [
                            '45.png',
                            '46.png',
                            '47.png',
                            '48.png',
                            '49.png',
                            '50.png',
                            '51.png',
                            '52.png',
                            '53.png',
                            '54.png'
                        ],
                        align_h: hmUI.align.RIGHT,
                        h_space: 0,
                        invalid_image: '89.png',
                        padding: false,
                        isCharacter: false,
                        show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 250,
                        y: 366,
                        w: 72,
                        h: 33,
                        src: '90.png',
                        show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 250,
                        y: 334,
                        src: '91.png',
                        show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 78,
                        y: 334,
                        w: 310,
                        h: 132,
                        type: hmUI.data_type.SPO2,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.TRAINING_LOAD:
                    break;
                case hmUI.edit_type.VO2MAX:
                    break;
                case hmUI.edit_type.UVI:
                    break;
                case hmUI.edit_type.DATE:
                    break;
                case hmUI.edit_type.WEEK:
                    break;
                case hmUI.edit_type.WEATHER:
                    break;
                case hmUI.edit_type.TEMPERATURE:
                    break;
                case hmUI.edit_type.SUN:
                    break;
                }
                hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
                    x: 0,
                    y: 0,
                    w: 466,
                    h: 466,
                    src: '92.png',
                    show_level: hmUI.show_level.ONLY_EDIT
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 233 - 32 / 2,
                    y: 233 * 2 - 32 - 6,
                    src: '109.png',
                    type: hmUI.system_status.DISCONNECT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 233 - 32 / 2,
                    y: 6,
                    src: '110.png',
                    type: hmUI.system_status.CLOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 320,
                    y: 174,
                    src: '63.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER, {
                    edit_id: 3,
                    x: 0,
                    y: 0,
                    config: pointerConfig,
                    count: 8,
                    default_id: 1,
                    fg: '3.png',
                    tips_x: 163,
                    tips_y: 208,
                    tips_bg: '2.png'
                });

                const screenType = hmSetting.getScreenType();
                const aod = screenType == hmSetting.screen_type.AOD;
                const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG, !aod);
                pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp);
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
