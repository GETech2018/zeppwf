try {
  ;(() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp

    var __$$module$$__ = __$$app$$__.current
    var h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__),
      'drink'
    )

    /*
     * huamiOS bundle tool v1.0.17
     * Copyright © Huami. All Rights Reserved
     */
    ;('use strict')

    console.log('----->>>current')
    console.log(__$$hmAppManager$$__.currentApp.pid)
    console.log(__$$hmAppManager$$__.currentApp.current)

    let day_array = []
    let distance_array = []
    let heart_array = []
    let hour_array = []
    let humidity_array = []
    let power_array = []
    let power_dis_array = []
    let step_array = []
    let sunrise_array = []
    let sunset_array = []
    let temperature_array = []
    let walk_array = []
    let weather_array = []
    let week_array = []

    let rootPath = 'images/'
    let bgPath = rootPath + 'bg/'
    let dayPath = rootPath + 'day/'
    let distancePath = rootPath + 'distance/'
    let heartPath = rootPath + 'heart/'
    let hourPath = rootPath + 'hour/'
    let humidityPath = rootPath + 'humidity/'
    let powerPath = rootPath + 'power/'
    let power_disPath = powerPath + 'distance/'
    let stepPath = rootPath + 'step/'
    let sunrisePath = rootPath + 'sunrise/'
    let sunsetPath = rootPath + 'sunset/'
    let temperaturePath = rootPath + 'temperature/'
    let walkPath = rootPath + 'walk/'
    let weatherPath = rootPath + 'weather/'
    let weekPath = rootPath + 'week/'

    let num_sun_common_y = 355
    let num_time_common_h = 2
    let num_year_common_y = 141

    const logger = DeviceRuntimeCore.HmLogger.getLogger('defult')
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        for (let i = 0; i < 10; i++) {
          day_array.push(dayPath + i + '.png')
          distance_array.push(distancePath + i + '.png')
          heart_array.push(heartPath + i + '.png')
          hour_array.push(hourPath + i + '.png')
          humidity_array.push(humidityPath + i + '.png')
          power_dis_array.push(power_disPath + i + '.png')
          step_array.push(stepPath + i + '.png')
          sunrise_array.push(sunrisePath + i + '.png')
          sunset_array.push(sunsetPath + i + '.png')
          temperature_array.push(temperaturePath + i + '.png')
        }

        for (let k = 1; k < 11; k++) {
          power_array.push(powerPath + k + '.png')
        }

        for (let m = 0; m < 29; m++) {
          weather_array.push(weatherPath + m + '.png')
        }

        for (let p = 1; p < 6; p++) {
          walk_array.push(walkPath + p + '.png')
        }

        for (let n = 1; n < 8; n++) {
          week_array.push(weekPath + n + '.png')
        }

        // let obj_anim = {
        //   x: 0,
        //   y: 0,
        //   anim_path: rootPath + 'bg',
        //   anim_prefix: 'anim',
        //   anim_ext: 'png',
        //   anim_fps: 10,
        //   anim_size: 6,
        //   repeat_count: 1,
        //   display_on_restart: true,
        //   anim_repeat: false,
        //   anim_status: hmUI.anim_status.START,
        // }

        let obj_battery_progress_bar = {
          x: 191.77 * 0.987083,
          y: 27,
          image_array: power_array,
          image_length: power_array.length, //长度
          type: hmUI.data_type.BATTERY,
          show_level: hmUI.show_level.ONLY_NORMAL,
        }
        let obj_battery_text = {
          x: 230,
          y: 19,
          type: hmUI.data_type.BATTERY,
          font_array: power_dis_array,
          h_space: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
          unit_sc: power_disPath + 'baifen.png',
          unit_tc: power_disPath + 'baifen.png',
          unit_en: power_disPath + 'baifen.png',
          // padding: true
        }

        let obj_time = {
          hour_zero: 1,
          hour_startX: 111 - 12,
          hour_startY: 74,
          hour_array: hour_array,
          hour_space: num_time_common_h,
          hour_unit_sc: hourPath + 'maohao.png',
          hour_unit_tc: hourPath + 'maohao.png',
          hour_unit_en: hourPath + 'maohao.png',
          minute_zero: 1,
          minute_startX: 203 - 6,
          minute_startY: 74,
          minute_array: hour_array,
          minute_space: num_time_common_h,
          minute_unit_sc: hourPath + 'maohao.png',
          minute_unit_tc: hourPath + 'maohao.png',
          minute_unit_en: hourPath + 'maohao.png',
          second_zero: 1,
          second_startX: 294,
          second_startY: 74,
          second_array: hour_array,
          second_space: num_time_common_h,
          show_level: hmUI.show_level.ONLY_NORMAL,
        }

        let obj_date = {
          month_startX: 170.22 * 0.987083,
          month_startY: num_year_common_y,
          // month_align: hmUI.align.LEFT,
          month_space: 0,
          month_zero: 1,
          month_unit_sc: dayPath + 'hen.png',
          month_unit_tc: dayPath + 'hen.png',
          month_unit_en: dayPath + 'hen.png',
          month_en_array: day_array,
          month_sc_array: day_array,
          month_tc_array: day_array,
          day_startX: 222.68 * 0.987083,
          day_startY: num_year_common_y,
          // day_align: hmUI.align.LEFT,
          day_space: 0, //文字间隔
          day_zero: 1, //是否补零
          day_en_array: day_array,
          day_sc_array: day_array,
          day_tc_array: day_array,
          show_level: hmUI.show_level.ONLY_NORMAL,
        }
        let obj_week = {
          x: 260.74 * 0.987083,
          y: 145.79 * 0.987083,
          week_en: week_array,
          week_tc: week_array,
          week_sc: week_array,
          show_level: hmUI.show_level.ONLY_NORMAL,
        }
        let obj_distance_text = {
          x: 45,
          y: 228 - 3 - 5,
          w: 120 * 0.987083,
          type: hmUI.data_type.DISTANCE,
          font_array: distance_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NOMAL,
          invalid_image: temperaturePath + 'null.png',
          dot_image: distancePath + 'dot.png',
        }

        let obj_weather_progress_bar = {
          x: 225 - 10,
          y: 187 - 6,
          image_array: weather_array,
          image_length: weather_array.length,
          type: hmUI.data_type.WEATHER_CURRENT,
          show_level: hmUI.show_level.ONLY_NORMAL,
        }

        let obj_weather_text = {
          x: 195 + 3 - 40,
          y: 228 - 2 - 5,
          w: 150,
          type: hmUI.data_type.WEATHER_CURRENT,
          font_array: temperature_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          invalid_image: temperaturePath + 'null.png',
          dot_image: temperaturePath + 'dot.png',
          unit_sc: temperaturePath + 'du.png',
          unit_tc: temperaturePath + 'du.png',
          unit_en: temperaturePath + 'du.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
          // padding: true
        }

        let obj_hum_text = {
          //湿度
          x: 318 - 1,
          y: 228 - 3 - 5,
          type: hmUI.data_type.HUMIDITY,
          font_array: humidity_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          unit_sc: humidityPath + 'baifen.png',
          unit_tc: humidityPath + 'baifen.png',
          unit_en: humidityPath + 'baifen.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
          invalid_image: temperaturePath + 'null.png',
          // dot_image: distancePath + "dot.png",
          // padding: true
        }

        let obj_step_text = {
          x: 196,
          y: 272,
          type: hmUI.data_type.STEP,
          font_array: step_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NORMAL,
          // padding: true
        }
        let obj_sun_rise_text = {
          x: 130 - 14,
          y: num_sun_common_y,
          type: hmUI.data_type.SUN_RISE,
          font_array: sunrise_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          dot_image: sunrisePath + 'maohao.png',
          padding: true,
          invalid_image: heartPath + 'null.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        }

        let obj_sun_set_text = {
          x: 287 - 14,
          y: num_sun_common_y,
          type: hmUI.data_type.SUN_SET,
          font_array: sunset_array,
          align_h: hmUI.align.CENTER_H,
          dot_image: sunsetPath + 'maohao.png',
          padding: true,
          invalid_image: heartPath + 'null.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        }

        let obj_heart_text = {
          x: 208,
          y: 400,
          type: hmUI.data_type.HEART,
          font_array: heart_array,
          h_space: 2,
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NORMAL,
          invalid_image: heartPath + 'null.png',
          // padding:true
        }

        let obj_step_progress_bar = {
          x: 31,
          y: 315,
          image_array: walk_array,
          image_length: walk_array.length,
          type: hmUI.data_type.STEP_TARGET,
          show_level: hmUI.show_level.ONLY_NORMAL,
        }

        let obj_time_xp = {
          hour_zero: 1,
          hour_startX: 111 - 12,
          hour_startY: 74,
          hour_array: hour_array,
          hour_space: num_time_common_h,
          hour_unit_sc: hourPath + 'maohao.png',
          hour_unit_tc: hourPath + 'maohao.png',
          hour_unit_en: hourPath + 'maohao.png',
          minute_zero: 1,
          minute_startX: 203 - 6,
          minute_startY: 74,
          minute_array: hour_array,
          minute_space: num_time_common_h,
          show_level: hmUI.show_level.ONAL_AOD,
        }

        let obj_distance_click = {
          x: 60,
          y: 180,
          w: 80,
          h: 75,
          type: hmUI.data_type.DISTANCE,
          show_level: hmUI.show_level.ONLY_NORMAL,
        }

        let obj_weather_click = {
          x: 195,
          y: 180,
          w: 80,
          h: 75,
          type: hmUI.data_type.WEATHER_CURRENT,
          show_level: hmUI.show_level.ONLY_NORMAL,
        }

        let obj_hum_click = {
          x: 320,
          y: 180,
          w: 80,
          h: 75,
          type: hmUI.data_type.HUMIDITY,
          show_level: hmUI.show_level.ONLY_NORMAL,
        }

        let obj_step_click = {
          x: 170,
          y: 270,
          w: 120,
          h: 30,
          type: hmUI.data_type.STEP,
          show_level: hmUI.show_level.ONLY_NORMAL,
        }

        let obj_step_progress_bar_click = {
          x: 30,
          y: 310,
          w: 400,
          h: 15,
          type: hmUI.data_type.STEP,
          show_level: hmUI.show_level.ONLY_NORMAL,
        }

        let obj_sun_RISEText_click = {
          x: 97,
          y: 353,
          w: 110,
          h: 30,
          type: hmUI.data_type.SUN_RISE,
          show_level: hmUI.show_level.ONLY_NORMAL,
        }

        let obj_sun_SETText_click = {
          x: 257,
          y: 353,
          w: 110,
          h: 30,
          type: hmUI.data_type.SUN_SET,
          show_level: hmUI.show_level.ONLY_NORMAL,
        }

        let obj_heart_click = {
          x: 180,
          y: 395,
          w: 80,
          h: 30,
          type: hmUI.data_type.HEART,
          show_level: hmUI.show_level.ONLY_NORMAL,
        }

        const img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          src: bgPath + 'anim_5.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        })

        // let animA = hmUI.createWidget(hmUI.widget.IMG_ANIM, obj_anim)

        let batteryLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, obj_battery_progress_bar)

        let batteryText = hmUI.createWidget(hmUI.widget.TEXT_IMG, obj_battery_text)

        let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, obj_time)

        let dayText = hmUI.createWidget(hmUI.widget.IMG_DATE, obj_date)

        let weekText = hmUI.createWidget(hmUI.widget.IMG_WEEK, obj_week)

        let distanceText = hmUI.createWidget(hmUI.widget.TEXT_IMG, obj_distance_text)

        let weatherLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, obj_weather_progress_bar)

        let weatherText = hmUI.createWidget(hmUI.widget.TEXT_IMG, obj_weather_text)

        let humidityText = hmUI.createWidget(hmUI.widget.TEXT_IMG, obj_hum_text)

        let stepText = hmUI.createWidget(hmUI.widget.TEXT_IMG, obj_step_text)

        let sun_RISEText = hmUI.createWidget(hmUI.widget.TEXT_IMG, obj_sun_rise_text)

        let sun_SETText = hmUI.createWidget(hmUI.widget.TEXT_IMG, obj_sun_set_text)

        let heartText = hmUI.createWidget(hmUI.widget.TEXT_IMG, obj_heart_text)

        let step_target_img = hmUI.createWidget(hmUI.widget.IMG_LEVEL, obj_step_progress_bar)

        let AOD_timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, obj_time_xp)

        // 步数图标点击
        let distance_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, obj_distance_click)
        // 步数图标点击
        let weather_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, obj_weather_click)
        // 步数图标点击
        let hum_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, obj_hum_click)

        // 步数图标点击
        let step_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, obj_step_click)
        let step_progress_bar_click = hmUI.createWidget(
          hmUI.widget.IMG_CLICK,
          obj_step_progress_bar_click
        )
        // 步数图标点击
        let sun_RISEText_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, obj_sun_RISEText_click)
        // 步数图标点击
        let sun_SETText_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, obj_sun_SETText_click)
        // 步数图标点击
        let heart_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, obj_heart_click)
      },

      onInit() {
        console.log('index page.js on init invoke')

        this.init_view()
      },

      onReady() {
        console.log('index page.js on ready invoke')
      },

      onShow() {
        console.log('index page.js on show invoke')
      },

      onHide() {
        console.log('index page.js on hide invoke')
      },

      onDestory() {
        console.log('index page.js on destory invoke')
      },
    })
    /*
     * end js
     */
  })()
} catch (e) {
  console.log(e)
}
