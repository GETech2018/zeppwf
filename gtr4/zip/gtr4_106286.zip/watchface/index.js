try {
  (() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__),
      "drink"
    );

    /*
     * hugray_small_numiOS bundle tool v1.0.17
     * Copyright © Hugray_small_numi. All Rights Reserved
     */
    ("use strict");

    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let timeArray = [];
    let dateArray = [];
    let stepArray = [];
    let batArray = [];
    let animateMoon = null;
    let moon_timer = null;
    let rootPath = "images/";

    // 资源填充
    for (let i = 0; i < 10; i++) {
      timeArray.push(rootPath + "time/time_font_" + i + ".png");
      dateArray.push(rootPath + "date/date_font_0" + i + ".png");
      stepArray.push(rootPath + "step/steps_font_" + i + ".png");
    }
    for (let i = 1; i < 20; i++) {
      batArray.push(rootPath + "bat_progress/" + i + ".png");
    }

    // 配置项
    let objBgAod = {
      x: 0,
      y: 0,
      w: 466,
      h: 466,
      color: 0x000000,
    };

    let objBg = {
      x: 0,
      y: 0,
      w: 466,
      h: 466,
      src: rootPath + "img/bg.png",
    };

    let objTimeText = {
      hour_zero: 1,
      hour_startX: 57 * 0.9708,
      hour_startY: 157 * 0.9708,
      hour_array: timeArray,
      hour_space: 0,
      hour_align: hmUI.align.LEFT,

      minute_zero: 1, //是否补零 1为补零
      minute_startX: 57 * 0.9708,
      minute_startY: 249 * 0.9708,
      minute_array: timeArray,
      minute_space: 0, //两个图片间隔 对应GT2的interval
      minute_follow: 0, //是否跟随
      minute_align: hmUI.align.LEFT,
      show_level: hmUI.show_level.ALL,
    };

    let objMonthImg = {
      month_startX: 60 * 0.9708,
      month_startY: 118 * 0.9708,
      month_unit_sc: rootPath + "img/line.png",
      month_unit_tc: rootPath + "img/line.png",
      month_unit_en: rootPath + "img/line.png",
      month_align: hmUI.align.LEFT,
      month_space: 0,
      month_zero: 1,
      month_follow: 0,
      month_is_character: false,
      month_en_array: dateArray,
      month_sc_array: dateArray,
      month_tc_array: dateArray,

      day_align: hmUI.align.LEFT,
      day_space: 0,
      day_zero: 1,
      day_follow: 1,
      day_en_array: dateArray,
      day_sc_array: dateArray,
      day_tc_array: dateArray,
      day_is_character: false,
      show_level: hmUI.show_level.ALL,
    };

    let objBatTxt = {
      x: 238 * 0.9708,
      y: 25 * 0.9708,
      type: hmUI.data_type.BATTERY,
      font_array: dateArray,
      h_space: 0, // 图片间隔
      align_h: hmUI.align.LEFT,
      unit_sc: rootPath + "img/per.png", //单位
      unit_tc: rootPath + "img/per.png", //单位
      unit_en: rootPath + "img/per.png", //单位

      padding: false, //是否补零 true为补零
      // show_level: hmUI.show_level.ONLY_NORMAL,
    };

    let objBatBg = {
      x: 196 * 0.9708,
      y: 26 * 0.9708,
      src: rootPath + "bat_progress/bg.png",
    };

    let objBatLevel = {
      x: 196 * 0.9708,
      y: 26 * 0.9708,
      image_array: batArray,
      image_length: batArray.length,
      type: hmUI.data_type.BATTERY,
    };
    // 做了全屏居中
    let objStepTxt = {
      x: 0,
      y: 427 * 0.9708,
      w: 466,
      h: 30,
      icon: rootPath + "img/steps.png",
      icon_space: 6, //icon到文字的间隔
      type: hmUI.data_type.STEP,
      font_array: stepArray,
      h_space: 0, //文字间隔
      align_h: hmUI.align.CENTER_H,
      padding: false, //是否补零 true为补零
    };

    let objAnimateMoon = {
      x: 0,
      y: 0,
      anim_path: rootPath + "moonMotion",
      anim_prefix: "moon",
      anim_ext: "png",
      anim_fps: 25,
      anim_size: 65,
      anim_repeat: false,
      repeat_count: 1,
    };

    // 热区跳转对象
    const objStepClick = {
      x: 162,
      y: 404,
      w: 142,
      h: 50,
      type:hmUI.data_type.STEP, //必写 跳转的action
    }

    const logger = DeviceRuntimeCore.HmLogger.getLogger("流星");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        let screenType = hmSetting.getScreenType();
        if (screenType == hmSetting.screen_type.AOD) {
          bg = hmUI.createWidget(hmUI.widget.FILL_RECT, objBgAod);
          timer.stopTimer(moon_timer);
        } else {
          bg = hmUI.createWidget(hmUI.widget.IMG, objBg);
          showDate();
        }

        hmUI.createWidget(hmUI.widget.IMG_TIME, objTimeText);
        hmUI.createWidget(hmUI.widget.IMG_DATE, objMonthImg);

        function showDate() {
          let batTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG, objBatTxt);
          hmUI.createWidget(hmUI.widget.IMG, objBatBg);
          let batLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, objBatLevel);
          let stepTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG, objStepTxt);
          animateMoon = hmUI.createWidget(hmUI.widget.IMG_ANIM, objAnimateMoon);
          moon_timer = timer.createTimer(3000, 5000, function (option) {
            //回调
            animateMoon.setProperty(
              hmUI.prop.ANIM_STATUS,
              hmUI.anim_status.START
            );
          });
        }
        hmUI.createWidget(hmUI.widget.IMG_CLICK, objStepClick)
      },

      onInit() {
        console.log("index page.js on init invoke");

        this.init_view();
      },

      onReady() {
        console.log("index page.js on ready invoke");
      },

      onShow() {
        console.log("index page.js on show invoke");
      },

      onHide() {
        console.log("index page.js on hide invoke");
      },

      onDestory() {
        console.log("index page.js on destory invoke");
        timer.stopTimer(clock_timer);
        timer.stopTimer(moon_timer);
      },
    });
    /*
     * end js
     */
  })();
} catch (e) {
  console.log(e);
}
