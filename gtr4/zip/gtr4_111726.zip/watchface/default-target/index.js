try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface6');

        let val, hour, minute, second, hourH, minuteH, hourD, angleH, angleM, angleS, editableBg, secondH, timeSensor, text;
        const center = 233;
        const mW = 286;

        function rotate(val) {
            const timeFormat = hmSetting.getTimeFormat();
            const screenType = hmSetting.getScreenType();
            const aod = screenType == hmSetting.screen_type.AOD;
            hour = val.hour;
            minute = val.minute;
            second = val.second;
            angleH = - (hour + minute / 60) * 30;
            if (aod) {
                angleM = - minute * 6;
            } else {
                angleM = - (minute + second / 60) * 6;
            }
            angleS = second * 6;

            hourH.setProperty(hmUI.prop.MORE, {angle: angleH});
            minuteH.setProperty(hmUI.prop.MORE, {angle: angleM});
            secondH.setProperty(hmUI.prop.MORE, {angle: angleS});
            if (timeFormat == 1) {
                hourD.setProperty(hmUI.prop.TEXT, `${ String(hour).padStart(2, '0') }`);
                if (hour > 11) {
                    hourH.setProperty(hmUI.prop.SRC, '7.png');
                } else {
                    hourH.setProperty(hmUI.prop.SRC, '6.png');
                }
            } else {
                if (hour > 12) { hour = hour - 12; }
                hourD.setProperty(hmUI.prop.TEXT, `${ String(hour) }`);
                hourH.setProperty(hmUI.prop.SRC, '5.png');
            }
        }

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                if (!timeSensor) { timeSensor = hmSensor.createSensor(hmSensor.id.TIME); }

                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    src: '66.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                secondH = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: center * 2,
                    h: center * 2,
                    center_x: center,
                    center_y: center,
                    pos_x: center - (8 / 2),
                    pos_y: 0,
                    src: '3.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 466,
                    h: 466,
                    src: '4.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hourH = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: center * 2,
                    h: center * 2,
                    center_x: center,
                    center_y: center,
                    pos_x: 0,
                    pos_y: 0,
                    angle: 0,
                    src: '5.png',
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                minuteH = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: center * 2,
                    h: center * 2,
                    center_x: center,
                    center_y: center,
                    pos_x: center - mW / 2,
                    pos_y: center - mW / 2,
                    angle: 0,
                    src: '8.png',
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                editableBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
                    edit_id: 1,
                    x: 0,
                    y: 0,
                    bg_config: [
                        {
                            'id': 1,
                            'path': '25.png',
                            'preview': '26.png'
                        },
                        {
                            'id': 2,
                            'path': '27.png',
                            'preview': '28.png'
                        },
                        {
                            'id': 3,
                            'path': '29.png',
                            'preview': '30.png'
                        },
                        {
                            'id': 4,
                            'path': '31.png',
                            'preview': '32.png'
                        },
                        {
                            'id': 5,
                            'path': '33.png',
                            'preview': '34.png'
                        },
                        {
                            'id': 6,
                            'path': '35.png',
                            'preview': '36.png'
                        },
                        {
                            'id': 7,
                            'path': '37.png',
                            'preview': '38.png'
                        }
                    ],
                    count: 7,
                    default_id: 1,
                    fg: '24.png',
                    tips_x: 163,
                    tips_y: 208,
                    tips_bg: '23.png',
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    src: '67.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 233,
                    center_y: 233,
                    radius: 80,
                    start_angle: -75,
                    end_angle: 75,
                    color: 4286611584,
                    line_width: 6,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 137,
                    y: 217,
                    src: '9.png',
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    day_startX: 218,
                    day_startY: 237,
                    day_sc_array: [
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png'
                    ],
                    day_tc_array: [
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png'
                    ],
                    day_en_array: [
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png'
                    ],
                    day_align: hmUI.align.LEFT,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 0,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 233,
                    center_y: 233,
                    radius: 80,
                    start_angle: 105,
                    end_angle: 255,
                    color: 4286611584,
                    line_width: 6,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 293,
                    y: 217,
                    src: '20.png',
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 285,
                    y: 209,
                    w: 48,
                    h: 48,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 217,
                    y: 162,
                    src: '21.png',
                    type: hmUI.system_status.DISCONNECT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 217,
                    y: 272,
                    src: '22.png',
                    type: hmUI.system_status.CLOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 200,
                    y: 199,
                    week_en: [
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png'
                    ],
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 200,
                    y: 199,
                    week_en: [
                        '68.png',
                        '69.png',
                        '70.png',
                        '71.png',
                        '72.png',
                        '73.png',
                        '74.png'
                    ],
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hourD = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 207,
                    y: 24,
                    w: 52,
                    h: 54,
                    font_array: [
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png',
                        '54.png',
                        '55.png'
                    ],
                    h_space: 0,
                    align_h: hmUI.align.CENTER_H,
                    text: '[HOUR]',
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    minute_zero: 1,
                    minute_startX: 213,
                    minute_startY: 92,
                    minute_array: [
                        '56.png',
                        '57.png',
                        '58.png',
                        '59.png',
                        '60.png',
                        '61.png',
                        '62.png',
                        '63.png',
                        '64.png',
                        '65.png'
                    ],
                    minute_space: 0,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });

                timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
                    rotate(timeSensor);
                });

                timer.createTimer(0, 1000, function (timeSensor2) {
                    rotate(timeSensor2);
                }, timeSensor);

                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function() {
                        rotate(timeSensor);
                    }
                });
           },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
