try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$component_0$_$component = '';
        const logger = Logger.getLogger('watchface6');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 466,
                    h: 466,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 217,
                    y: 89,
                    src: '3.png',
                    type: hmUI.system_status.DISCONNECT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 217,
                    y: 125,
                    src: '4.png',
                    type: hmUI.system_status.CLOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: '5.png',
                    center_x: 233,
                    center_y: 233,
                    x: 22,
                    y: 233,
                    type: hmUI.data_type.STEP,
                    start_angle: 30,
                    end_angle: 240,
                    cover_x: 0,
                    cover_y: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: '6.png',
                    center_x: 233,
                    center_y: 233,
                    x: 22,
                    y: 233,
                    type: hmUI.data_type.BATTERY,
                    start_angle: 270,
                    end_angle: 360,
                    cover_x: 0,
                    cover_y: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    day_startX: 244,
                    day_startY: 326,
                    day_sc_array: [
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png'
                    ],
                    day_tc_array: [
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png'
                    ],
                    day_en_array: [
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png'
                    ],
                    day_align: hmUI.align.LEFT,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 0,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 198,
                    y: 326,
                    week_en: [
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png'
                    ],
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 217,
                    y: 284,
                    src: '24.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 296,
                    y: 239,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: [
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '27.png',
                    unit_tc: '27.png',
                    unit_en: '27.png',
                    negative_image: '26.png',
                    invalid_image: '25.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 296,
                    y: 189,
                    image_array: [
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png',
                        '54.png',
                        '55.png',
                        '56.png'
                    ],
                    image_length: 29,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$component_0$_$component = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: 1,
                    x: 92,
                    y: 179,
                    w: 108,
                    h: 108,
                    select_image: '57.png',
                    un_select_image: '58.png',
                    default_type: hmUI.edit_type.DISTANCE,
                    optional_types: [
                        {
                            'type': hmUI.edit_type.DISTANCE,
                            'preview': '60.png'
                        },
                        {
                            'type': hmUI.edit_type.SPO2,
                            'preview': '61.png'
                        },
                        {
                            'type': hmUI.edit_type.CAL,
                            'preview': '62.png'
                        },
                        {
                            'type': hmUI.edit_type.HEART,
                            'preview': '63.png'
                        },
                        {
                            'type': hmUI.edit_type.PAI_DAILY,
                            'preview': '64.png'
                        }
                    ],
                    count: 5,
                    tips_BG: '59.png',
                    tips_x: -16,
                    tips_y: -59,
                    tips_width: 140,
                    tips_margin: 0
                });
                editType = normal$_$component_0$_$component.getProperty(hmUI.prop.CURRENT_TYPE);
                switch (editType) {
                case hmUI.edit_type.STEP:
                    break;
                case hmUI.edit_type.BATTERY:
                    break;
                case hmUI.edit_type.HEART:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 111,
                        y: 239,
                        type: hmUI.data_type.HEART,
                        font_array: [
                            '65.png',
                            '66.png',
                            '67.png',
                            '68.png',
                            '69.png',
                            '70.png',
                            '71.png',
                            '72.png',
                            '73.png',
                            '74.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        unit_sc: '76.png',
                        unit_tc: '76.png',
                        unit_en: '76.png',
                        invalid_image: '75.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 130,
                        y: 197,
                        src: '77.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 92,
                        y: 179,
                        w: 108,
                        h: 108,
                        type: hmUI.data_type.HEART,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.CAL:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 105,
                        y: 239,
                        type: hmUI.data_type.CAL,
                        font_array: [
                            '7.png',
                            '8.png',
                            '9.png',
                            '10.png',
                            '11.png',
                            '12.png',
                            '13.png',
                            '14.png',
                            '15.png',
                            '16.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        unit_sc: '79.png',
                        unit_tc: '79.png',
                        unit_en: '79.png',
                        invalid_image: '78.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 130,
                        y: 197,
                        src: '80.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 92,
                        y: 179,
                        w: 108,
                        h: 108,
                        type: hmUI.data_type.CAL,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.PAI_DAILY:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 116,
                        y: 239,
                        type: hmUI.data_type.PAI_DAILY,
                        font_array: [
                            '65.png',
                            '66.png',
                            '67.png',
                            '68.png',
                            '69.png',
                            '70.png',
                            '71.png',
                            '72.png',
                            '73.png',
                            '74.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        unit_sc: '82.png',
                        unit_tc: '82.png',
                        unit_en: '82.png',
                        invalid_image: '81.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 130,
                        y: 197,
                        src: '83.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 92,
                        y: 179,
                        w: 108,
                        h: 108,
                        type: hmUI.data_type.PAI_DAILY,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.DISTANCE:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 105,
                        y: 239,
                        type: hmUI.data_type.DISTANCE,
                        font_array: [
                            '7.png',
                            '8.png',
                            '9.png',
                            '10.png',
                            '11.png',
                            '12.png',
                            '13.png',
                            '14.png',
                            '15.png',
                            '16.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        unit_sc: '86.png',
                        unit_tc: '86.png',
                        unit_en: '86.png',
                        imperial_unit_sc: '87.png',
                        imperial_unit_tc: '87.png',
                        imperial_unit_en: '87.png',
                        dot_image: '85.png',
                        invalid_image: '84.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 130,
                        y: 197,
                        src: '88.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 92,
                        y: 179,
                        w: 108,
                        h: 108,
                        type: hmUI.data_type.DISTANCE,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.AQI:
                    break;
                case hmUI.edit_type.HUMIDITY:
                    break;
                case hmUI.edit_type.ALTIMETER:
                    break;
                case hmUI.edit_type.STRESS:
                    break;
                case hmUI.edit_type.WIND:
                    break;
                case hmUI.edit_type.SPO2:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 122,
                        y: 239,
                        type: hmUI.data_type.SPO2,
                        font_array: [
                            '7.png',
                            '8.png',
                            '9.png',
                            '10.png',
                            '11.png',
                            '12.png',
                            '13.png',
                            '14.png',
                            '15.png',
                            '16.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        unit_sc: '90.png',
                        unit_tc: '90.png',
                        unit_en: '90.png',
                        invalid_image: '89.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 130,
                        y: 197,
                        src: '91.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 92,
                        y: 179,
                        w: 108,
                        h: 108,
                        type: hmUI.data_type.SPO2,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.TRAINING_LOAD:
                    break;
                case hmUI.edit_type.VO2MAX:
                    break;
                case hmUI.edit_type.UVI:
                    break;
                case hmUI.edit_type.DATE:
                    break;
                case hmUI.edit_type.WEEK:
                    break;
                case hmUI.edit_type.WEATHER:
                    break;
                case hmUI.edit_type.TEMPERATURE:
                    break;
                case hmUI.edit_type.SUN:
                    break;
                }
                hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK, {
                    x: 0,
                    y: 0,
                    w: 466,
                    h: 466,
                    src: '92.png',
                    show_level: hmUI.show_level.ONLY_EDIT
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 233,
                    hour_centerY: 233,
                    hour_posX: 29,
                    hour_posY: 233,
                    hour_path: '93.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 233,
                    minute_centerY: 233,
                    minute_posX: 29,
                    minute_posY: 233,
                    minute_path: '94.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    second_centerX: 233,
                    second_centerY: 233,
                    second_posX: 29,
                    second_posY: 233,
                    second_path: '95.png',
                    second_cover_x: 0,
                    second_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
                    x: 0,
                    y: 0,
                    w: 466,
                    h: 466,
                    src: '96.png',
                    show_level: hmUI.show_level.ONLY_EDIT
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 466,
                    h: 466,
                    src: '97.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    day_startX: 244,
                    day_startY: 326,
                    day_sc_array: [
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png'
                    ],
                    day_tc_array: [
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png'
                    ],
                    day_en_array: [
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png'
                    ],
                    day_align: hmUI.align.LEFT,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 0,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 198,
                    y: 326,
                    week_en: [
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png'
                    ],
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 233,
                    hour_centerY: 233,
                    hour_posX: 29,
                    hour_posY: 233,
                    hour_path: '93.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 233,
                    minute_centerY: 233,
                    minute_posX: 29,
                    minute_posY: 233,
                    minute_path: '94.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 243,
                    y: 0,
                    w: 90,
                    h: 60,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 0,
                    y: 243,
                    w: 60,
                    h: 90,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 266,
                    y: 179,
                    w: 108,
                    h: 108,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}