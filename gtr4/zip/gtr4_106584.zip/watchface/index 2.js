try {
    (() => {
    
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
  
    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');
  
      /*
    * huamiOS bundle tool v1.0.17
    * Copyright © Huami. All Rights Reserved
    */
    'use strict';
  
    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let dataArray = []
    let calArray = []
    let batArray = []
    let weekArray = []
    let weekUnselect = []
   
    let timeArray = []
    let stepArray = []
   
    let img_bg = null
 
    let weatherArray =[]
    let weatherNumArray = []
    let moonArray =[]
    let weatherIconImgArray = []
    let weatherTxtImgArray =  []
    let timeSensor = null
    let weatherSensor = null
    let weekImgArray =  []

    const  ROOTPATH = "images/"
    let weatherData = null
    let forecastData = null
   
    const logger = DeviceRuntimeCore.HmLogger.getLogger("defult");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
        init_view() {

           for(var i=0; i<=28; i++){
                if(i<=9) {
                    timeArray.push(ROOTPATH + "time/"+i+".png");
                    batArray.push(ROOTPATH + "batLevel/"+i+".png");
                    stepArray.push(ROOTPATH + "stepLevel/"+i+".png");
                    calArray.push(ROOTPATH + "calLevle/"+i+".png");
                    dataArray.push(ROOTPATH + "data/"+i+".png");//步数&心率&秒钟通用
                    weatherNumArray.push(ROOTPATH + "weatherNum/"+i+".png");
                    if(i<=6) {
                        weekArray.push(ROOTPATH + "week/"+(i+1)+".png");
                        weekUnselect.push(ROOTPATH + "week/weekUnselect/"+(i+1)+".png");
                        
                    }
                }
                weatherArray.push(ROOTPATH +  "weather/"+i+".png");//0-28
                moonArray.push(ROOTPATH +  "moon/"+(i+1)+".png");//1-29
            }
            moonArray.push(ROOTPATH +  "moon/30.png");//1-30

            img_bg = hmUI.createWidget(hmUI.widget.IMG,{
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                src: ROOTPATH + "img/bg.png",
                show_level:hmUI.show_level.ONLY_NORMAL,
            });  
            let bg_aod= hmUI.createWidget(hmUI.widget.FILL_RECT, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                color: 0x000000,
                show_level:hmUI.show_level.ONLY_AOD,
            });
             
            let colonImg = hmUI.createWidget(hmUI.widget.IMG,{
                x: 205,
                y: 36,
                w: 56,
                h: 108,
                src: ROOTPATH + "img/colon.png",
                //show_level:hmUI.show_level.ONLY_NORMAL,
            }); 
            let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                hour_zero:1, //是否补零
                hour_startX:122,
                hour_startY:36,
                hour_array: timeArray,
                hour_space:-10, //每个数组间的间隔
                hour_align:hmUI.align.LEFT,

                // hour_unit_sc:  ROOTPATH + "img/colon.png", 
                // hour_unit_tc:  ROOTPATH + "img/colon.png",
                // hour_unit_en:  ROOTPATH + "img/colon.png",
                hour_align:hmUI.align.LEFT,

                minute_zero:1, //是否补零
                minute_startX:240,
                minute_startY:36,
                minute_array: timeArray,
                minute_space:-10, //每个数组间的间隔
                minute_align:hmUI.align.LEFT,
            
               
               
                am_x:210,
                am_y:20,
                am_sc_path:  ROOTPATH + "img/am.png",
                am_en_path:  ROOTPATH + "img/am.png",
                pm_x:210,
                pm_y:20,
                pm_sc_path:  ROOTPATH + "img/pm.png",
                pm_en_path:  ROOTPATH + "img/pm.png",
                //show_level:hmUI.show_level.ONLY_NORMAL,
            });   

            let weekLevel = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                x: 132,
                y: 20,
                w: 60,
                h: 28,
                week_sc: weekArray,
                week_tc: weekArray,
                week_en: weekArray,
               // show_level: hmUI.show_level.ONLY_NORMAL,
            });
            let monthTxt = hmUI.createWidget(hmUI.widget.IMG_DATE,{
                day_startX:299,
                day_startY:20,

                day_align:hmUI.align.LEFT,
                day_space:-2,//文字间隔
                day_zero:1,//是否补零 
                day_follow:0,//是否跟随
                day_en_array: weatherNumArray,
                day_sc_array: weatherNumArray,
                day_tc_array: weatherNumArray,
            });
            
          
            //battery-----
            let batLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL,{
                x: 62,
                y: 71,
                w: 62, 
                h: 62,
                image_array: batArray,
                image_length: batArray.length,//长度
                type: hmUI.data_type.BATTERY,
                shortcut: true, // optional, 默认为false, 表示是否使能快捷跳转功能
                show_level:hmUI.show_level.ONLY_NORMAL,
            });
            let calLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL,{
                x: 341,
                y: 71,
                w: 62, 
                h: 62,
                image_array: calArray,
                image_length: calArray.length,//长度
                type: hmUI.data_type.CAL,
                shortcut: true, // optional, 默认为false, 表示是否使能快捷跳转功能
                show_level:hmUI.show_level.ONLY_NORMAL,
            });
            //----------
            let stepTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG,{
                x: 105,
                y: 333,
                type:hmUI.data_type.STEP,
                font_array: dataArray ,
                align_h:hmUI.align.CENTER_H,
                padding:false, 
                h_space: 0, 
                show_level:hmUI.show_level.ONLY_NORMAL,
            })
            let stepLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                x: 40,
                y: 340,
                w: 178, 
                h: 116,
                image_array: stepArray,
                image_length: stepArray.length,
                type: hmUI.data_type.STEP,
                shortcut: true,
                show_level: hmUI.show_level.ONLY_NORMAL
            })  
            let heartTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG,{
                x: 290,
                y: 333,
                type: hmUI.data_type.HEART,
                font_array: dataArray,
                align_h: hmUI.align.CENTER_H,
                invalid_image: ROOTPATH + "data/invalid.png",
                padding:false, 
                show_level: hmUI.show_level.ONLY_NORMAL,
            })
              //* 
            let heartPoiner= hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                src:  ROOTPATH + "img/p.png",
                center_x: 233,
                center_y: 233,
                x: 10,
                y: 228,
                type: hmUI.data_type.HEART,
                start_angle: 118,
                end_angle: 170,
                show_level: hmUI.show_level.ONLY_NORMAL,
            })///*/
            let heartClick = hmUI.createWidget(hmUI.widget.IMG_CLICK,{
                x: 254,
                y: 332,
                w: 169,
                h: 134,
                type: hmUI.data_type.HEART,
            });
            let moonLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL,{
                x: 198,
                y: 340,
                w: 70, 
                h: 70,
                image_array: moonArray,
                image_length: moonArray.length,//长度
                type: hmUI.data_type.MOON,
                shortcut: true, // optional, 默认为false, 表示是否使能快捷跳转功能
                show_level:hmUI.show_level.ONLY_NORMAL,
            });

           // var screenType = hmSetting.getScreenType();
            //下排未来温度天气代码========================================
            for (var i = 0; i < 5; i++) {
              weekImgArray[i]  = hmUI.createWidget(hmUI.widget.IMG, {
                x: 37 + i * 76 * 1.04,
                y: 144,
                w: 76,
                h: 178,
                //src: weekUnselect[i],
               show_level: hmUI.show_level.ONLY_NORMAL,
              });

              weatherIconImgArray[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 58 + i * 76 * 1.04,
                y: 217,
                w: 34,
                h: 34,
               // src: weatherArray[i],
                shortcut: true,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
  
              weatherTxtImgArray[i] = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                x: 58 + i * 76 * 1.04,
                y: 257,

                font_array: weatherNumArray,
                h_space: 0,
                type: hmUI.data_type.WEATHER_CURRENT,
                shortcut: true,
                align_h: hmUI.align.LEFT,
                unit_sc:   ROOTPATH +"weatherNum/degree.png",
                unit_en:  ROOTPATH +"weatherNum/degree.png",
                unit_tc:  ROOTPATH +"weatherNum/degree.png",
                negative_image:  ROOTPATH + "weatherNum/negative.png", //负号图片
                invalid_image:  ROOTPATH + "weatherNum/invalid.png", // 无数据时显示的图片
                show_level: hmUI.show_level.ONLY_NORMAL,
              });

              let weatherClick = hmUI.createWidget(hmUI.widget.IMG_CLICK,{
                x: 23,
                y: 148,
                w: 420,
                h: 170,
                type: hmUI.data_type.WEATHER_HIGH,
            });
            }
       // weather change
       timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
       // 监听时间变化
       timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
         dayCahage();
        });
        dayCahage();
        function dayCahage(){
        weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
        //获取天气信息
        weatherData = weatherSensor.getForecastWeather();
        let weekDay= timeSensor.week;
            forecastData = weatherData.forecastData
            for (let i = 0; i < 5; i++) {
                let element = forecastData.data[i]; // i:0是当日天气
                let temperature =  element.high + ""; // 当前天气的高温
                let iconIndex = element.index; //天气索引
                weekImgArray[i].setProperty(hmUI.prop.SRC, weekUnselect[weekDay-1]);
                weatherTxtImgArray[i].setProperty(hmUI.prop.TEXT, temperature);
                weatherIconImgArray[i].setProperty(hmUI.prop.SRC, weatherArray[iconIndex]);
                weekDay++;
                if(weekDay == 8)
                {
                weekDay=1;
                }  
            }
        }

        },

        onInit() {
            console.log('index page.js on init invoke');
            this.init_view();
        },

        onReady() {
            console.log('index page.js on ready invoke')
        },

        onShow() {
            console.log('index page.js on show invoke')
        },

        onHide() {
            console.log('index page.js on hide invoke')
        },

        onDestory() {
            console.log('index page.js on destory invoke')
        },
    });
    /*
    * end js
    */
        })()
    } catch (e) {
        console.log(e)
    }