try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface6');

        let val, minute, second, week, day, minuteTxt, minuteBg, secondHand, weekPointer, weekTxt, dayTxt;
        let minuteX, minuteY, minuteA, secondX, secondY, secondCx, secondCy, secondA, day10, day1, dayA, day10v, day1v, timeSensor;
        const center = 233;
        const mH = 50;
        const mW = mH;
        const mX = center - (mW / 2 - 1);
        const mY = 96;
        const mR = center - (mY + mH / 2);
        const dH = 20;
        const dX = 55;
        const dY = center - dH / 2;
        const sH = 74;

        function motionXy(val) {
            minute = val.minute;
            second = val.second;
            week = val.week;
            day = val.day;

            minuteX = mX + mR * Math.sin(minute * Math.PI / 30);
            minuteY = (center - mH / 2 - 2) - mR * Math.cos(minute * Math.PI / 30);
            minuteA = minute * 6;
            secondCx = (minuteX - 1) + mH / 2;
            secondCy = (minuteY + 2) + mH / 2;
            secondX = (minuteX - 1) + mH / 2 - sH / 2;
            secondY = (minuteY + 2) + mH / 2 - sH / 2;
            secondA = second * 6;
            day10v = Math.floor(day / 10);
            day1v = day - day10v * 10;
            day10v = '10' + day10v + '.png';
            day1v = '10' + day1v + '.png';
            dayA = (week - 4) * -15;

            minuteTxt.setProperty(hmUI.prop.MORE, {
                x: minuteX,
                y: minuteY,
                text: `${ String(minute).padStart(2, '0') }`
            });
            minuteBg.setProperty(hmUI.prop.MORE, {angle: minuteA});
            secondHand.setProperty(hmUI.prop.MORE, {
                center_x: secondCx,
                center_y: secondCy,
                pos_x: secondX,
                pos_y: secondY,
                angle: secondA
            });

            day10.setProperty(hmUI.prop.SRC, `${ day10v }`);
            day1.setProperty(hmUI.prop.SRC, `${ day1v }`);
            day10.setProperty(hmUI.prop.MORE, { angle: dayA });
            day1.setProperty(hmUI.prop.MORE, { angle: dayA });
        }

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                if (!timeSensor) { timeSensor = hmSensor.createSensor(hmSensor.id.TIME); }

                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 466,
                    h: 466,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 217,
                    y: 431,
                    src: '3.png',
                    type: hmUI.system_status.DISCONNECT,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 217,
                    y: 396,
                    src: '4.png',
                    type: hmUI.system_status.CLOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 233,
                    center_y: 233,
                    radius: 198,
                    start_angle: 140,
                    end_angle: 40,
                    color: 4294901760,
                    line_width: 6,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 197,
                    hour_startY: 209,
                    hour_array: [
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png'
                    ],
                    hour_space: 0,
                    hour_align: hmUI.align.LEFT,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });

                weekTxt = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 0,
                    y: 0,
                    week_en: [
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png'
                    ],
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                day10 = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: center * 2,
                    h: center * 2,
                    center_x: center,
                    center_y: center,
                    pos_x: dX,
                    pos_y: dY,
                    angle: dayA,
                    src: '100.png',
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                day1 = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: center * 2,
                    h: center * 2,
                    center_x: center,
                    center_y: center,
                    pos_x: dX + 15,
                    pos_y: dY,
                    angle: dayA,
                    src: '100.png',
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                minuteBg = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: center * 2,
                    h: center * 2,
                    center_x: center,
                    center_y: center,
                    pos_x: 203,
                    pos_y: 0,
                    angle: minuteA,
                    src: '12.png',
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                minuteTxt = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: mX,
                    y: mY,
                    w: mW,
                    h: mH,
                    text: '[MIN_Z]',
                    color: '0xFF000000',
                    text_size: 27,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                secondHand = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: center * 2,
                    h: center * 2,
                    center_x: mX + sH / 2,
                    center_y: mY + sH / 2,
                    pos_x: center - sH / 2,
                    pos_y: mY - sH / 2,
                    angle: secondA,
                    src: '13.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });

                timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
                    motionXy(timeSensor);
                });

                timer.createTimer(0, 1000, function (timeSensor2) {
                    motionXy(timeSensor2);
                }, timeSensor);

                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function() {
                        motionXy(timeSensor);
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
