try {
    (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        /*
      * huamiOS bundle tool v1.0.17
      * Copyright © Huami. All Rights Reserved
      */
        'use strict';

        // console.log("----->>>current");
        // console.log(__$$hmAppManager$$__.currentApp.pid);
        // console.log(__$$hmAppManager$$__.currentApp.current);
        let nW = 466
        let nH = 466
        let strRootPath = "images/";
        let weekX = 0
        let weekY = 0
        let arrTime = [];
        let arrTimes = [];
        let arrStep = [];
        let arrHeart = [];
        let arrWeek = [];
        let arrIconWeek = []
        let arrBat = [];
        let arrLevel = []
        let arrLevel2 = []
        let animate = []

        let objAodTime = {
            hour_zero: 1,
            hour_startX: 39*0.9708,
            hour_startY: 172*0.9708,
            hour_unit_sc: strRootPath + "time2/maohao.png",
            hour_unit_tc: strRootPath + "time2/maohao.png",
            hour_unit_en: strRootPath + "time2/maohao.png",
            hour_array: arrTimes,
            hour_space: 8,
            hour_align: hmUI.align.LEFT,
            minute_zero: 1,
            minute_startX: 249*0.9708,
            minute_startY: 172*0.9708,
            minute_array: arrTimes,
            minute_space: 8,
            minute_align: hmUI.align.LEFT,
            show_level: hmUI.show_level.ONAL_AOD,
        }
        let objBg = {
            x: 0,
            y: 0,
            w: nW,
            h: nH,
            src: strRootPath + "img/bg.png",
            show_level: hmUI.show_level.ONLY_NORMAL
        }
        let objAnimate = {
            x: 0,
            y: 0,
            anim_path: strRootPath + "animate", //必须从0开始 可以询问君成 张莉
            anim_prefix: "anim",
            anim_ext: "png",
            anim_fps: 25,
            anim_size: 25,
            repeat_count: 0,
            anim_repeat: true,
            anim_status: hmUI.anim_status.START,
            display_on_restart: false,
            show_level: hmUI.show_level.ONLY_NORMAL
        }
        let objTime = {
            hour_zero: 1,
            hour_startX: 39*0.9708,
            hour_startY: 172*0.9708,
            hour_array: arrTime,
            hour_space: 0,
            hour_align: hmUI.align.LEFT,
            minute_zero: 1,
            minute_startX: 251*0.9708,
            minute_startY: 172*0.9708,
            minute_array: arrTime,
            minute_space: 0,
            minute_align: hmUI.align.LEFT,
            show_level: hmUI.show_level.ONLY_NORMAL
        }
        let objWeek = {
            x: 252*0.9708,
            y: 128*0.9708,
            week_en: arrWeek,
            week_tc: arrWeek,
            week_sc: arrWeek,
            show_level: hmUI.show_level.ONLY_NORMAL
        }
        let objIweek = {
            x: 95*0.9708,
            y: 309*0.9708,
            week_en: arrIconWeek,
            week_tc: arrIconWeek,
            week_sc: arrIconWeek,
            show_level: hmUI.show_level.ONLY_NORMAL
        }
        let objDate =  {
            month_startX: 150,
            month_startY: 128*0.9708,
            month_align: hmUI.align.LEFT,
            month_space: 0,
            month_zero: 1,
            month_follow: 0,
            month_unit_sc: strRootPath + "step/dot.png", //单位
            month_unit_tc: strRootPath + "step/dot.png",
            month_unit_en: strRootPath + "step/dot.png",
            month_en_array: arrStep,
            month_sc_array: arrStep,
            month_tc_array: arrStep,
            month_is_character: false,
            // day_startX: 181*0.9708,
            // day_startY: 128*0.9708,
            day_align: hmUI.align.LEFT,
            day_space: 0,
            day_zero: 1,
            day_follow: 1,
            day_en_array: arrStep,
            day_sc_array: arrStep,
            day_tc_array: arrStep,
            day_is_character: false,
            show_level: hmUI.show_level.ONLY_NORMAL
        }
        let objStep = {
            x: 214*0.9708,
            y: 361*0.9708,
            type: hmUI.data_type.STEP,
            font_array: arrStep,
            h_space: 0,
            align_h: hmUI.align.LEFT,
            padding: false,
            isCharacter: true,
            show_level: hmUI.show_level.ONLY_NORMAL
        }
        let objHeart = {
            x: 224*0.9708,
            y: 74*0.9708,
            type: hmUI.data_type.HEART,
            invalid_image:strRootPath + "heart/none.png",
            font_array: arrHeart,
            h_space: 0,
            align_h: hmUI.align.CENTER_H,
            padding: false,
            isCharacter: true,
            show_level: hmUI.show_level.ONLY_NORMAL
        }

        for (i = 0; i < 11; i++) {
            if (i <= 7 && i >= 1) {
                arrWeek.push(strRootPath + "week/" + i + ".png");
                arrIconWeek.push(strRootPath + "iconWeek/" + i + ".png")
            };
            if( i < 10 ){
                arrTime.push(strRootPath + "time/" + i + ".png");
                arrTimes.push(strRootPath + "time2/" + i + ".png");
                arrStep.push(strRootPath + "step/" + i + ".png");
                arrHeart.push(strRootPath + "heart/" + i + ".png");
                arrBat.push(strRootPath + "battery/power_n_" + i + ".png");
            }
            if( i < 11 && i > 0){
                arrLevel.push(strRootPath + "oneLevel/" + i + ".png")
                arrLevel2.push(strRootPath + "twoLevel/" + i + ".png")
            }
        }

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            getIcon(options){
                let { x, y, src  } = options
                let icon = hmUI.createWidget(hmUI.widget.IMG, {
                  x: x,
                  y: y,
                  src: src,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                })
            },
            getClick(options){
                let { x, y, w, h, type  } = options
                let click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                  x: x,
                  y: y,
                  w: w,
                  h: h,
                  type:type,
                })

            },
            init_view() {
                    let that = this;
                    //息屏时间
                    let aodtime = hmUI.createWidget(hmUI.widget.IMG_TIME, objAodTime);
                    //background
                    let bg = hmUI.createWidget(hmUI.widget.IMG, objBg);
                     // animate
                    let animate = hmUI.createWidget(hmUI.widget.IMG_ANIM, objAnimate);
                    //设置动画状态
                    animate.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.PAUSE)
                    //hour,minute(text)
                    let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, objTime);
                    //week
                    hmUI.createWidget(hmUI.widget.IMG_WEEK, objWeek);
                    //icon week
                    hmUI.createWidget(hmUI.widget.IMG_WEEK, objIweek);
                    // month
                    let month_num = hmUI.createWidget(hmUI.widget.IMG_DATE, objDate);
                    // text - step
                    let stepTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG, objStep);
                    // text - heart
                    let heartTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG, objHeart);
                    this.getIcon({ x: 14*0.9708, y: 13*0.9708, src: strRootPath + "oneLevel/0.png" })
                    this.getIcon({ x: 185*0.9708, y: 185*0.9708, src: strRootPath + "twoLevel/0.png" })
                    //Cal level
                    let stepLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                        x: 14*0.9708,
                        y: 13*0.9708,
                        image_array: arrLevel,
                        image_length: arrLevel.length,
                        type: hmUI.data_type.CAL,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    //bat level
                    let heartLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                        x: 185*0.9708,
                        y: 185*0.9708,
                        image_array: arrLevel2,
                        image_length: arrLevel2.length,
                        type: hmUI.data_type.BATTERY,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });


                //点击步数组件跳转
                this.getClick({ x: 135*0.9708, y: 361*0.9708, w: 140, h: 60, type: hmUI.data_type.STEP})
                //点击bpm组件跳转
                this.getClick({ x: 160*0.9708, y: 54*0.9708, w: 120, h: 50, type: hmUI.data_type.HEART})
                //点击cal组件跳转
                this.getClick({ x: 30*0.9708, y: 301*0.9708, w: 60, h: 50, type: hmUI.data_type.CAL})
                //点击bat组件跳转
                this.getClick({ x: 400*0.9708, y: 121*0.9708, w: 60, h: 60, type: hmUI.data_type.BATTERY})
            },

            onInit() {
                console.log('index page.js on init invoke')

                this.init_view();
            },

            onReady() {
                console.log('index page.js on ready invoke')
            },

            onShow() {
                console.log('index page.js on show invoke')
            },

            onHide() {
                console.log('index page.js on hide invoke')
            },

            onDestory() {
                console.log('index page.js on destory invoke')
                timer.stopTimer(timerSupport);
                timer.stopTimer(clockTimer);
            },
        });
        /*
        * end js
        */
    })()
} catch (e) {
    console.log(e)
}