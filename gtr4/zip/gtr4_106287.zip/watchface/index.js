try {
  (() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__),
      "drink"
    );

    /*
     * huamiOS bundle tool v1.0.17
     * Copyright © Huami. All Rights Reserved
     */
    ("use strict");

    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let weekArray = [];
    let dateArray = [];
    let timeArr = [];
    let restimeArr = [];
    let fontArr = [];
    let rootPath = "images/";

    for (let i = 0; i < 10; i++) {
      dateArray.push(rootPath + "date/" + i + ".png");
      timeArr.push(rootPath + "time/" + i + ".png");
      restimeArr.push(rootPath + "restTime/" + i + ".png");
      fontArr.push(rootPath + "font/" + i + ".png");
      if (i < 8 && i > 0) {
        weekArray.push(rootPath + "week/" + i + ".png");
      }
    }
    let objImg_bgAod = {
      x: 0,
      y: 0,
      w: 466,
      h: 466,
      src: rootPath + "img/bg.png",
    };
    let objTimeTxt = {
      hour_startX: 100 * 0.9708,
      hour_startY: 56 * 0.9708,
      hour_zero: 1,
      hour_array: restimeArr,
      hour_space: 8 * 0.9708,
      hour_align: hmUI.align.LEFT,

      minute_startX: 100 * 0.9708,
      minute_startY: 249 * 0.9708,
      minute_zero: 1,
      minute_array: restimeArr,
      minute_space: 8 * 0.9708,
      minute_align: hmUI.align.LEFT,
    };
    let objBg = {
      x: 0,
      y: 0,
      w: 466,
      h: 466,
      src: rootPath + "img/bg.png",
    };
    let objTimeText = {
      hour_startX: 100 * 0.9708,
      hour_startY: 56 * 0.9708,
      hour_zero: 1,
      hour_array: timeArr,
      hour_space: 8 * 0.9708,
      hour_align: hmUI.align.LEFT,

      minute_startX: 100 * 0.9708,
      minute_startY: 249 * 0.9708,
      minute_zero: 1,
      minute_array: timeArr,
      minute_space: 8 * 0.9708,
      minute_align: hmUI.align.LEFT,

      am_x: 384 * 0.9708,
      am_y: 180 * 0.9708,
      am_sc_path: rootPath + "AP/AM.png",
      am_en_path: rootPath + "AP/AM.png",

      pm_x: 384 * 0.9708,
      pm_y: 180 * 0.9708,
      pm_sc_path: rootPath + "AP/PM.png",
      pm_en_path: rootPath + "AP/PM.png",
    };
    let objWeek = {
      x: 42 * 0.9708,
      y: 199 * 0.9708,
      week_en: weekArray,
      week_tc: weekArray,
      week_sc: weekArray,
      show_level: hmUI.show_level.ONAL_NORML,
    };
    let objStepImg = {
      x: 42 * 0.9708,
      y: 281 * 0.9708,
      src: rootPath + "font/steps.png",
    };
    let objStepText = {
      x: 116 * 0.9708,
      y: 281 * 0.9708,
      type: hmUI.data_type.STEP,
      font_array: fontArr,
      invalid_image: rootPath + "font/none.png",
      h_space: 0,
      align_h: hmUI.align.LEFT,
      padding: false,
      isCharacter: false,
    };
    let objPowerImg = {
      x: 274 * 0.9708,
      y: 281 * 0.9708,
      src: rootPath + "font/power.png",
    };

    let objPowerText = {
      x: 362 * 0.9708,
      y: 281 * 0.9708,
      type: hmUI.data_type.BATTERY,
      font_array: fontArr,
      unit_sc: rootPath + "font/unit.png",
      unit_tc: rootPath + "font/unit.png",
      unit_en: rootPath + "font/unit.png",
      h_space: 0,
      invalid_image: rootPath + "font/none.png",
      align_h: hmUI.align.LEFT,
      padding: false,
      isCharacter: false,
    };

    // 热区跳转
    const objStepClick = {
      x: 34,
      y: 263,
      w: 145,
      h: 40,
      type:hmUI.data_type.STEP, //必写 跳转的action
    }

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        let screenType = hmSetting.getScreenType();
        if (screenType == hmSetting.screen_type.AOD) {
          let img_bg = hmUI.createWidget(hmUI.widget.IMG, objImg_bgAod);
          let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, objTimeTxt);
        } else {
          let img_bg = hmUI.createWidget(hmUI.widget.IMG, objBg);
          let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, objTimeText);
          week = hmUI.createWidget(hmUI.widget.IMG_WEEK, objWeek);
          let stepImg = hmUI.createWidget(hmUI.widget.IMG, objStepImg);
          let stepText = hmUI.createWidget(hmUI.widget.TEXT_IMG, objStepText);
          let powerImg = hmUI.createWidget(hmUI.widget.IMG, objPowerImg);
          let powerText = hmUI.createWidget(hmUI.widget.TEXT_IMG, objPowerText);
          // 热区控件
          hmUI.createWidget(hmUI.widget.IMG_CLICK, objStepClick)
        }
      },

      onInit() {
        console.log("index page.js on init invoke");
        this.init_view();
      },

      onReady() {
        console.log("index page.js on ready invoke");
      },

      onShow() {
        console.log("index page.js on show invoke");
      },

      onHide() {
        console.log("index page.js on hide invoke");
      },

      onDestory() {
        console.log("index page.js on destory invoke");
        timer.stopTimer(timerSupport);
      },
    });
    /*
     * end js
     */
  })();
} catch (e) {
  console.log(e);
}
