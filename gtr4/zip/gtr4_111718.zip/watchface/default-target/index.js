try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface6');

        let x1, x2, groupD, groupM1, groupM2;
        const dX = 335;
        const dY = 283;
        const dW = 15 * 2;
        const mX = 366;
        const mW = 45;
        const mH = 23;
        const m_array1 = [
                '14.png',
                '15.png',
                '16.png',
                '17.png',
                '18.png',
                '19.png',
                '20.png',
                '21.png',
                '22.png',
                '23.png',
                '24.png',
                '25.png' ];
        const m_array2 = [
                '80.png',
                '81.png',
                '82.png',
                '83.png',
                '84.png',
                '85.png',
                '86.png',
                '87.png',
                '88.png',
                '89.png',
                '90.png',
                '91.png' ];

        function swapDate() {
            const dateFormat = hmSetting.getDateFormat();
            if (dateFormat == 1) {
                groupD.setProperty(hmUI.prop.X, dX);
                groupM1.setProperty(hmUI.prop.VISIBLE, true);
                groupM2.setProperty(hmUI.prop.VISIBLE, false);
            } else {
                groupD.setProperty(hmUI.prop.X, mX + mW - dW);
                groupM1.setProperty(hmUI.prop.VISIBLE, false);
                groupM2.setProperty(hmUI.prop.VISIBLE, true);
            }
        }

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 466,
                    h: 466,
                    src: '78.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 213,
                    y: 182,
                    src: '79.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
                    edit_id: 1,
                    x: 0,
                    y: 0,
                    bg_config: [
                        {
                            'id': 1,
                            'path': '4.png',
                            'preview': '4.png'
                        },
                        {
                            'id': 2,
                            'path': '5.png',
                            'preview': '5.png'
                        },
                        {
                            'id': 3,
                            'path': '6.png',
                            'preview': '6.png'
                        },
                        {
                            'id': 4,
                            'path': '7.png',
                            'preview': '7.png'
                        },
                        {
                            'id': 5,
                            'path': '8.png',
                            'preview': '8.png'
                        },
                        {
                            'id': 6,
                            'path': '9.png',
                            'preview': '9.png'
                        },
                        {
                            'id': 7,
                            'path': '10.png',
                            'preview': '10.png'
                        }
                    ],
                    count: 7,
                    default_id: 1,
                    fg: '3.png',
                    tips_x: 163,
                    tips_y: 208,
                    tips_bg: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 117,
                    y: 400,
                    src: '11.png',
                    type: hmUI.system_status.DISCONNECT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 186,
                    y: 410,
                    src: '12.png',
                    type: hmUI.system_status.CLOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: '13.png',
                    center_x: 233,
                    center_y: 144,
                    x: 20,
                    y: 140,
                    type: hmUI.data_type.BATTERY,
                    start_angle: -126,
                    end_angle: 126,
                    cover_x: 0,
                    cover_y: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                groupD = hmUI.createWidget(hmUI.widget.GROUP, {
                    x: dX,
                    y: dY,
                    w: mW,
                    h: mH
                });
                groupD.createWidget(hmUI.widget.IMG_DATE, {
                    day_startX: 0,
                    day_startY: 0,
                    day_sc_array: [
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png'
                    ],
                    day_tc_array: [
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png'
                    ],
                    day_en_array: [
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png'
                    ],
                    day_align: hmUI.align.CENTER_H,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 0,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                groupM1 = hmUI.createWidget(hmUI.widget.GROUP, {
                    x: mX,
                    y: dY,
                    w: mW,
                    h: mH
                });
                groupM1.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 0,
                    month_startY: 0,
                    month_en_array: m_array1,
                    month_align: hmUI.align.LEFT,
                    month_zero: 0,
                    month_follow: 0,
                    month_space: 0,
                    month_is_character: true,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                groupM2 = hmUI.createWidget(hmUI.widget.GROUP, {
                    x: dX,
                    y: dY,
                    w: mW,
                    h: mH
                });
                groupM2.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 0,
                    month_startY: 0,
                    month_en_array: m_array2,
                    month_align: hmUI.align.LEFT,
                    month_zero: 0,
                    month_follow: 0,
                    month_space: 0,
                    month_is_character: true,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 312,
                    y: 258,
                    week_en: [
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png'
                    ],
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 66,
                    y: 283,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: [
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    unit_sc: '45.png',
                    unit_tc: '45.png',
                    unit_en: '45.png',
                    negative_image: '44.png',
                    invalid_image: '43.png',
                    padding: false,
                    isCharacter: false,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 22,
                    y: 258,
                    image_array: [
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png',
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png',
                        '58.png',
                        '59.png',
                        '60.png',
                        '61.png',
                        '62.png',
                        '63.png',
                        '64.png',
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png',
                        '71.png',
                        '72.png',
                        '73.png',
                        '74.png'
                    ],
                    image_length: 29,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 15,
                    y: 245,
                    w: 150,
                    h: 65,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    second_centerX: 233,
                    second_centerY: 322,
                    second_posX: 20,
                    second_posY: 140,
                    second_path: '77.png',
                    second_cover_x: 0,
                    second_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 233,
                    hour_centerY: 233,
                    hour_posX: 25,
                    hour_posY: 180,
                    hour_path: '75.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 233,
                    minute_centerY: 233,
                    minute_posX: 25,
                    minute_posY: 230,
                    minute_path: '76.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });

                timer.createTimer(0, 60000, function () { swapDate() });
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function() { swapDate() }
                });
           },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
