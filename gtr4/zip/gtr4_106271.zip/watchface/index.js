try {
  (() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__),
      "drink"
    );

    /*
     * huamiOS bundle tool v1.0.17
     * Copyright © Huami. All Rights Reserved
     */
    ("use strict");

    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    const rootPath = "images/";

    const bgPath = rootPath + "bg/";
    const batPath = rootPath + "bat/";
    const dayPath = rootPath + "day/";
    const heartPath = rootPath + "heart/";
    const weekPath = rootPath + "week/";
    const uviPath = rootPath + "uvi/";
    const humidityPath = rootPath + "humidity/";
    const paiPath = rootPath + "pai/";
    const powerPath = rootPath + "power/";
    const kcalPath = rootPath + "kcal/";
    const moonPath = rootPath + "moon/";
    const statusPath = rootPath + "status/";
    const stepsPath = rootPath + "steps/";
    const steps_leavePath = stepsPath + "leave/";
    const sunPath = rootPath + "sun/";
    const timePath = rootPath + "time/";
    const time_mPath = timePath + "m/";

    const bat_array = [];
    const day_array = [];
    const heart_array = [];
    const humidity_array = [];
    const kcal_array = [];
    const moon_array = [];
    const steps_leave_array = [];
    const sun_array = [];
    const time_h_array = [];
    const time_m_array = [];
    const uvi_array = [];
    const week_array = [];
    const pai_array = [];
    const power_array = [];
    const steps_array = [];

    for (let i = 1; i <= 4; i++) {
      uvi_array.push(uviPath + i + ".png");
    }
    for (let i = 1; i <= 6; i++) {
      bat_array.push(batPath + i + ".png");
    }
    for (let i = 1; i <= 7; i++) {
      week_array.push(weekPath + i + ".png");
    }

    for (let i = 0; i <= 9; i++) {
      day_array.push(dayPath + i + ".png");
      heart_array.push(heartPath + i + ".png");
      humidity_array.push(humidityPath + i + ".png");
      kcal_array.push(kcalPath + i + ".png");
      pai_array.push(paiPath + i + ".png");
      power_array.push(powerPath + i + ".png");
      steps_array.push(stepsPath + i + ".png");
      steps_leave_array.push(steps_leavePath + i + ".png");
      sun_array.push(sunPath + i + ".png");
      time_h_array.push(timePath + i + ".png");
      time_m_array.push(time_mPath + i + ".png");
    }
    for (let i = 1; i <= 30; i++) {
      moon_array.push(moonPath + i + ".png");
    }

    const logger = DeviceRuntimeCore.HmLogger.getLogger("defult");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        let bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 466,
          h: 466,
          src: bgPath + "bg.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let paiLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 28 * 0.9708,
          y: 60 * 0.9708,
          image_array: pai_array,
          image_length: pai_array.length, //长度
          type: hmUI.data_type.PAI_DAILY,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let humidityLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 145 * 0.9708,
          y: 23 * 0.9708,
          image_array: humidity_array,
          image_length: humidity_array.length, //长度
          type: hmUI.data_type.HUMIDITY,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // let batLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
        //   x: 348,
        //   y: 60,
        //   image_array: bat_array,
        //   image_length: bat_array.length,//长度
        //   type: hmUI.data_type.AQI,
        //   show_level: hmUI.show_level.ONLY_NORMAL
        // });
        let batLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 338,
          y: 60 * 0.9708,
          image_array: bat_array,
          image_length: bat_array.length, //长度
          type: hmUI.data_type.BATTERY,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let uviLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 348 * 0.9708,
          y: 244 * 0.9708,
          image_array: uvi_array,
          image_length: uvi_array.length, //长度
          type: hmUI.data_type.UVI,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let stepsLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 142 + 1 * 0.9708,
          y: 410 * 0.9708,
          image_array: steps_leave_array,
          image_length: steps_leave_array.length, //长度
          type: hmUI.data_type.STEP,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let calLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 28.7 * 0.9708,
          y: 244.5 * 0.9708,
          image_array: kcal_array,
          image_length: kcal_array.length, //长度
          type: hmUI.data_type.CAL,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let moonLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 373 * 0.9708,
          y: 199 * 0.9708,
          image_array: moon_array,
          image_length: moon_array.length, //长度
          type: hmUI.data_type.MOON,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let weekText = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
          x: 180 * 0.9708,
          y: 72 * 0.9708,
          week_en: week_array,
          week_tc: week_array,
          week_sc: week_array,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let heartText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          // x: 273,
          // y: 167,
          x: 272 * 0.9708,
          y: 283 * 0.9708,
          w: 60,
          type: hmUI.data_type.HEART,
          font_array: heart_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NORMAL,
          invalid_image: heartPath + "null.png",
          // padding: true
        });

        let stepText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 189,
          y: 380,
          type: hmUI.data_type.STEP,
          font_array: heart_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NORMAL,
          invalid_image: heartPath + "null.png",
          // padding: true
        });

        let batteryText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 272 * 0.9708,
          y: 167 * 0.9708,
          w: 60,
          // x: 273,
          // y: 283,
          type: hmUI.data_type.BATTERY,
          font_array: heart_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NORMAL,
          // invalid_image: heartPath + "null.png",
          // padding: true
        });

        let sun_RISEText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          // x: 162,
          // y: 349,
          x: 253 * 0.9708,
          y: 349 * 0.9708,
          type: hmUI.data_type.SUN_RISE,
          font_array: sun_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          dot_image: sunPath + "maohao.png",
          isCharater: true,
          padding: true,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let sun_SETText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          // x: 253,
          // y: 349,
          x: 162 * 0.9708,
          y: 349 * 0.9708,
          type: hmUI.data_type.SUN_SET,
          font_array: sun_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          dot_image: sunPath + "maohao.png",
          isCharater: true,
          padding: true,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let disturbStatus = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
          x: 383 * 0.9708,
          y: 261 * 0.9708,
          type: hmUI.system_status.DISTURB,
          src: statusPath + "disturb.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let lockStatus = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
          x: 354 * 0.9708,
          y: 114 * 0.9708,
          type: hmUI.system_status.LOCK,

          src: statusPath + "lock.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let disconnectStatus = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
          x: 364 * 0.9708,
          y: 304 * 0.9708,
          type: hmUI.system_status.DISCONNECT,
          src: statusPath + "disconnect.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
          // hmUI.system_status.DISCONNECT
        });

        let clockStatus = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
          x: 376 * 0.9708,
          y: 157 * 0.9708,
          type: hmUI.system_status.CLOCK,
          src: statusPath + "clock.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          hour_zero: 1, //是否补零
          hour_startX: 88 * 0.9708,
          hour_startY: 118 * 0.9708,
          hour_array: time_h_array,
          hour_space: 0, //每个数组间的间隔

          minute_zero: 1, //是否补零
          minute_startX: 88 * 0.9708,
          minute_startY: 222 * 0.9708,
          minute_array: time_m_array,
          minute_space: 0, //每个数组间的间隔

          am_x: 52 * 0.9708,
          am_y: 227 * 0.9708,
          am_sc_path: timePath + "AM.png",
          am_en_path: timePath + "AM.png",
          pm_x: 52 * 0.9708,
          pm_y: 227 * 0.9708,
          pm_sc_path: timePath + "PM.png",
          pm_en_path: timePath + "PM.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let dayText = hmUI.createWidget(hmUI.widget.IMG_DATE, {
          day_startX: 258 * 0.9708,
          day_startY: 72 * 0.9708,
          day_align: hmUI.align.LEFT,
          day_space: -2, //文字间隔
          day_zero: 1, //是否补零
          day_en_array: day_array,
          day_sc_array: day_array,
          day_tc_array: day_array,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let AOD_timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          hour_zero: 1, //是否补零
          hour_startX: 166 * 0.9708,
          hour_startY: 118 * 0.9708,
          hour_array: time_h_array,
          hour_space: 0, //每个数组间的间隔

          minute_zero: 1, //是否补零
          minute_startX: 166 * 0.9708,
          minute_startY: 222 * 0.9708,
          minute_array: time_m_array,
          minute_space: 0, //每个数组间的间隔\
          show_level: hmUI.show_level.ONAL_AOD,
        });

        let batClick = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 400,
          y: 80,
          w: 53,
          h: 98,
          type: hmUI.data_type.BATTERY,
        });
        let batBigClick = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 249,
          y: 114,
          w: 98,
          h: 98,
          type: hmUI.data_type.BATTERY,
        });
        let heartBigClick = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 249,
          y: 226,
          w: 98,
          h: 98,
          type: hmUI.data_type.HEART,
        });
        let moonClick = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 366,
          y: 198,
          w: 45,
          h: 45,
          type: hmUI.data_type.MOON,
        });
        let alarmClick = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 365,
          y: 148,
          w: 34,
          h: 32,
          type: hmUI.data_type.ALARM_CLOCK,
        });

        let uviClick = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 430,
          y: 297,
          w: 38,
          h: 81,
          type: hmUI.data_type.UVI,
        });

        let stepsClick = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 175,
          y: 421,
          w: 114,
          h: 52,
          type: hmUI.data_type.STEP,
        });

        let sunsetClick = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 112,
          y: 333,
          w: 111,
          h: 27,
          type: hmUI.data_type.SUN_SET,
        });
        let sunriseClick = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 247,
          y: 333,
          w: 111,
          h: 27,
          type: hmUI.data_type.SUN_RISE,
        });

        let calClick = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 10,
          y: 306,
          w: 62,
          h: 74,
          type: hmUI.data_type.CAL,
        });

        let paiClick = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 13,
          y: 98,
          w: 53,
          h: 62,
          type: hmUI.data_type.PAI_WEEKLY,
        });

        let humidityClick = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 185,
          y: 0,
          w: 117,
          h: 42,
          type: hmUI.data_type.HUMIDITY,
        });
      },

      onInit() {
        console.log("index page.js on init invoke");

        this.init_view();
      },

      onReady() {
        console.log("index page.js on ready invoke");
      },

      onShow() {
        console.log("index page.js on show invoke");
      },

      onHide() {
        console.log("index page.js on hide invoke");
      },

      onDestory() {
        console.log("index page.js on destory invoke");
      },
    });
    /*
     * end js
     */
  })();
} catch (e) {
  console.log(e);
}
