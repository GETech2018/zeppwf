try {
    (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;

        var __$$module$$__ = __$$app$$__.current;
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        /*
      * huamiOS bundle tool v1.0.17
      * Copyright © Huami. All Rights Reserved
      *   1000577
      */
        'use strict';

        console.log("----->>>current");
        console.log(__$$hmAppManager$$__.currentApp.pid);
        console.log(__$$hmAppManager$$__.currentApp.current);

        const rootPath = "images/";
        const DISPLAY_LEVEL = hmUI.show_level.ALL;

        let dayArray = []
        let monthArray = []
        let weekArray = []

        for (let i = 0; i < 10; i++) {
            dayArray.push(`images/day/${i}.png`)
        }
        for (let i = 1; i < 14; i++) {
            monthArray.push(`images/month/0${i}.png`)
        }
        for (let i = 1; i < 8; i++) {
            weekArray.push(`images/week/0${i}.png`)
        }

        let timeSensor = null;
        let day1 = null;
        let day2 = null;
        let timePointer = null;
        let bg = null;
        let timer1

        const logger = DeviceRuntimeCore.HmLogger.getLogger("lenshuangqiuhan");
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

            init_view() {
                //bg
                bg = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 466,
                    h: 466,
                });

                //week
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 229 * 0.9708,
                    y: 66 * 0.9708,
                    week_tc: weekArray,
                    week_sc: weekArray,
                    week_en: weekArray,
                });
                //date
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 228 * 0.9708,
                    month_startY: 318 * 0.9708,
                    month_zero: true,
                    month_en_array: monthArray,
                    month_is_character: true,
                });
                day1 = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 228 * 0.9708,
                    y: 399 * 0.9708,
                    w: 24 * 0.9708,
                    h: 18 * 0.9708,
                });
                day2 = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 228 * 0.9708,
                    y: 420 * 0.9708,
                    w: 24 * 0.9708,
                    h: 18 * 0.9708,
                });


                getTime()
                function getTime() {
                    timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                    if (timeSensor == null || day1 == null || day2 == null) {
                        console.log('refreshDay error');
                        return;
                    }
                    const currentDay = timeSensor.day;
                    logger.log("wwwwwwwwwwwwwwww", JSON.stringify(currentDay))
                    day1.setProperty(hmUI.prop.SRC, dayArray[parseInt(currentDay / 10)]);
                    day2.setProperty(hmUI.prop.SRC, dayArray[parseInt(currentDay % 10)]);
                    // console.log('++++++++++++++++++++++e'+parseInt(currentDay/10));
                    // console.log('++++++++++++++++++++++e'+parseInt(currentDay%10));
                }


                //创建timer，延时500ms触发，之后每1000ms执行一次
                timer1 = timer.createTimer(
                    500,
                    1000,
                    function (option) {
                        getTime()
                    },
                    { hour: 0, minute: 15, second: 30 }
                )

                const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: (function () {
                        getTime()
                    }),
                    pause_call: (function () {
                        console.log('ui pause');
                    }),
                });

                timePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {

                });
                var screenType = hmSetting.getScreenType();
                if (screenType == hmSetting.screen_type.AOD) {
                    bg.setProperty(hmUI.prop.MORE, {
                        src: rootPath + "img/bg_xp.png",
                    });
                    timePointer.setProperty(hmUI.prop.MORE, {
                        hour_centerX: 240 * 0.9708,
                        hour_centerY: 240 * 0.9708,
                        hour_posX: 20 * 0.9708,
                        hour_posY: 240 * 0.9708,//171,
                        hour_path: rootPath + "img/hour.png",
                        minute_centerX: 240 * 0.9708,
                        minute_centerY: 240 * 0.9708,
                        minute_posX: 20 * 0.9708,
                        minute_posY: 240 * 0.9708,
                        minute_path: rootPath + "img/min.png",
                        minute_cover_path: rootPath + "img/cover.png", //指针圆心图片
                        minute_cover_y: 230 * 0.9708,
                        minute_cover_x: 229 * 0.9708,
                    });
                } else {
                    bg.setProperty(hmUI.prop.MORE, {
                        src: rootPath + "img/bg.png",
                    });
                    timePointer.setProperty(hmUI.prop.MORE, {
                        hour_centerX: 240 * 0.9708,
                        hour_centerY: 240 * 0.9708,
                        hour_posX: 20 * 0.9708,
                        hour_posY: 240 * 0.9708,// 171,
                        hour_path: rootPath + "img/hour.png",
                        minute_centerX: 240 * 0.9708,
                        minute_centerY: 240 * 0.9708,
                        minute_posX: 20 * 0.9708,
                        minute_posY: 240 * 0.9708,
                        minute_path: rootPath + "img/min.png",
                        second_centerX: 240 * 0.9708,
                        second_centerY: 240 * 0.9708,
                        second_posX: 20 * 0.9708,
                        second_posY: 240 * 0.9708,
                        second_path: rootPath + "img/sec.png",
                        second_cover_path: rootPath + "img/cover.png", //指针圆心图片
                        second_cover_y: 230 * 0.9708,
                        second_cover_x: 229 * 0.9708,
                    });
                }
            },

            onInit() {
                console.log('index page.js on init invoke');
                this.init_view();
            },

            onReady() {
                console.log('index page.js on ready invoke')
            },

            onShow() {
                console.log('index page.js on show invoke')
            },

            onHide() {
                console.log('index page.js on hide invoke')
            },

            onDestory() {
                console.log('index page.js on destory invoke')
                //停止timer1
                timer.stopTimer(timer1)
            },
        });
        /*
        * end js
        */
    })()
} catch (e) {
    console.log(e)
}
