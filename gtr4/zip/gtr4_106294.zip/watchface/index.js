try {
  (() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__),
      "drink"
    );

    /*
     * huamiOS bundle tool v1.0.17
     * Copyright © Huami. All Rights Reserved
     */
    ("use strict");

    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let rootPath = "images/";
    let arrWeek = [];
    let arrWeekCn = [];
    let arrTime = [];
    let arrTimeAod = [];
    let arrDay = [];
    let arrCal = [];
    let arrPower = [];
    let arrMonth = [];
    let arrMonthCn = [];
    for (let i = 1; i < 8; i++) {
      arrWeek.push(rootPath + `week/` + i + `.png`);
      arrWeekCn.push(rootPath + `week_cn/` + i + `.png`);
    }
    for (let i = 0; i < 10; i++) {
      arrTime.push(rootPath + `time/` + i + `.png`);
      arrTimeAod.push(rootPath + `restTime/` + i + `.png`);
      arrDay.push(rootPath + `day/` + i + `.png`);
      arrCal.push(rootPath + `cal/` + i + `.png`);
      arrPower.push(rootPath + `power/` + i + `.png`);
    }
    for (let i = 1; i < 13; i++) {
      arrMonth.push(rootPath + `month/` + i + `.png`);
      arrMonthCn.push(rootPath + `month_cn/` + i + `.png`);
    }
    function px(num) {
      return num / (480 / 466);
    }
    let objBg = {
      x: 0,
      y: 0,
      w: px(480),
      h: px(480),
      src: rootPath + "img/bg.png",
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    let nSpace = 2;
    let objAodTime = {
      hour_startX: px(20),
      hour_startY: px(156),
      hour_zero: 1,
      hour_array: arrTimeAod,
      hour_space: nSpace,
      hour_align: hmUI.align.LEFT,

      minute_startX: px(240),
      minute_startY: px(156),
      minute_zero: 1,
      minute_array: arrTimeAod,
      minute_space: nSpace,
      minute_align: hmUI.align.LEFT,

      am_x: px(299),
      am_y: px(104),
      am_sc_path: rootPath + "ap_rest_cn/AM.png",
      am_en_path: rootPath + "ap_rest/AM.png",

      pm_x: px(299),
      pm_y: px(104),
      pm_sc_path: rootPath + "ap_rest_cn/PM.png",
      pm_en_path: rootPath + "ap_rest/PM.png",
    };

    let objTime = {
      hour_startX: px(20),
      hour_startY: px(156),
      hour_zero: 1,
      hour_array: arrTime,
      hour_space: nSpace,
      hour_align: hmUI.align.LEFT,

      minute_startX: px(240),
      minute_startY: px(156),
      minute_zero: 1,
      minute_array: arrTime,
      minute_space: nSpace,
      minute_align: hmUI.align.LEFT,

      am_x: px(299),
      am_y: px(104),
      am_sc_path: rootPath + "AP_cn/AM.png",
      am_en_path: rootPath + "AP/AM.png",

      pm_x: px(299),
      pm_y: px(104),
      pm_sc_path: rootPath + "AP_cn/PM.png",
      pm_en_path: rootPath + "AP/PM.png",
    };
    let objWeek = {
      x: px(313),
      y: px(53),
      week_en: arrWeek,
      week_tc: arrWeekCn,
      week_sc: arrWeekCn,
      show_level: hmUI.show_level.ONAL_NORML,
    };
    let objStepText = {
      x: px(140),
      y: px(107),
      // text: 68699,  //调试专用
      type: hmUI.data_type.STEP,
      font_array: arrDay,
      invalid_image: rootPath + "day/none.png",
      h_space: 0,
      align_h: hmUI.align.LEFT,
      padding: false,
      isCharacter: false,
    };
    let objPowerText = {
      x: px(133),
      y: px(54),
      // text: 78,  //调试专用
      type: hmUI.data_type.BATTERY,
      font_array: arrPower,
      unit_sc: rootPath + "power/unit.png",
      unit_tc: rootPath + "power/unit.png",
      unit_en: rootPath + "power/unit.png",
      h_space: 0,
      invalid_image: rootPath + "power/none.png",
      align_h: hmUI.align.LEFT,
      padding: false,
      isCharacter: false,
    };
    let objHeartText = {
      x: px(130),
      y: px(338),
      // text: 89,  //调试专用
      type: hmUI.data_type.HEART,
      font_array: arrDay,
      h_space: -2,
      invalid_image: rootPath + "day/none.png",
      align_h: hmUI.align.LEFT,
      padding: false,
      isCharacter: false,
    };
    let objCalText = {
      x: px(356),
      y: px(340),
      // text: 6400,  //测试专用
      type: hmUI.data_type.CAL,
      font_array: arrCal,
      // h_space: -2,
      invalid_image: rootPath + "day/none.png",
      align_h: hmUI.align.LEFT,
      // padding: 1,
    };
    let objDate = {
      month_startX: px(184),
      month_startY: px(433),
      month_align: hmUI.align.LEFT,
      month_space: 0,
      month_zero: 0,
      month_follow: 0,
      month_en_array: arrMonth,
      month_sc_array: arrMonthCn,
      month_tc_array: arrMonthCn,
      month_is_character: true,

      day_startX: px(220),
      day_startY: px(393),
      day_align: hmUI.align.LEFT,
      day_space: 0,
      day_zero: 1,
      day_follow: 0,
      day_en_array: arrDay,
      day_sc_array: arrDay,
      day_tc_array: arrDay,
      day_is_character: false,
    };

    function jumpApp(x, y, w, h, type) {
      hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x, y, w, h, type,//type必写 跳转的action
          show_level: hmUI.show_level.ONLY_NORMAL,
      });
  }

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        let screenType = hmSetting.getScreenType();
        if (screenType == hmSetting.screen_type.AOD) {
          hmUI.createWidget(hmUI.widget.IMG_TIME, objAodTime);
        } else {


          hmUI.createWidget(hmUI.widget.IMG, objBg);
          hmUI.createWidget(hmUI.widget.IMG_TIME, objTime);
          hmUI.createWidget(hmUI.widget.IMG_WEEK, objWeek);
          hmUI.createWidget(hmUI.widget.TEXT_IMG, objStepText);
          hmUI.createWidget(hmUI.widget.TEXT_IMG, objPowerText);
          hmUI.createWidget(hmUI.widget.TEXT_IMG, objHeartText);
          hmUI.createWidget(hmUI.widget.TEXT_IMG, objCalText);
          hmUI.createWidget(hmUI.widget.IMG_DATE, objDate);
          jumpApp(68, 99, 153, 49, hmUI.data_type.STEP);
          jumpApp(68, 316, 143, 56, hmUI.data_type.HEART);
          jumpApp(288, 316, 143, 56, hmUI.data_type.CAL);
        }
      },

      onInit() {
        console.log("index page.js on init invoke");
        this.init_view();
      },

      onReady() {
        console.log("index page.js on ready invoke");
      },

      onShow() {
        console.log("index page.js on show invoke");
      },

      onHide() {
        console.log("index page.js on hide invoke");
      },

      onDestory() {
        console.log("index page.js on destory invoke");
        timer.stopTimer(timerSupport);
      },
    });
    /*
     * end js
     */
  })();
} catch (e) {
  console.log(e);
}
