
try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface6');

        let val, hour, minute, timeSensor;
        const hArray = [ 'H0', 'H1', 'H2', 'H3', 'H4', 'H5', 'H6' ];
        const mArray = [ 'M0', 'M1', 'M2', 'M3', 'M4', 'M5', 'M6' ];
        const center = 233;
        const xgap = 10;
        const ygap = 15;
        const hlW = 40;
        const hlH = 50;
        const hmW = 28;
        const hmH = 40;
        const hsW = 22;
        const hsH = 30;
        const apW = 54;
        const apH = 30;
        const dW = 22;
        const dH = 30;
        const wW = 84;
        const wH = 30;
        const hlArray = [
           'hl0.png',
           'hl1.png',
           'hl2.png',
           'hl3.png',
           'hl4.png',
           'hl5.png',
           'hl6.png',
           'hl7.png',
           'hl8.png',
           'hl9.png'
        ];
        const hmArray = [
           'hm0.png',
           'hm1.png',
           'hm2.png',
           'hm3.png',
           'hm4.png',
           'hm5.png',
           'hm6.png',
           'hm7.png',
           'hm8.png',
           'hm9.png'
        ];
        const hsArray = [
           'hs0.png',
           'hs1.png',
           'hs2.png',
           'hs3.png',
           'hs4.png',
           'hs5.png',
           'hs6.png',
           'hs7.png',
           'hs8.png',
           'hs9.png'
        ];

        function setLabel(val) {
            const timeFormat = hmSetting.getTimeFormat();
            const tArray = [ -3, -2, -1, 0, 1, 2, 3 ];
            let hdelta = [];
            let mdelta = [];
            hour = val.hour;
            minute = val.minute;
            if (timeFormat == 1) {
                for (i = 0; i < 7; i++) {
                    if (hour + tArray[i] < 0) { hdelta.push(hour + tArray[i] + 24); }
                    else if (hour + tArray[i] > 23) { hdelta.push(hour + tArray[i] - 24); }
                    else { hdelta.push(hour + tArray[i]); }
                    hArray[i].setProperty(hmUI.prop.TEXT, `${ String(hdelta[i]).padStart(2, '0') }`);
                }
            } else {
                for (i = 0; i < 7; i++) {
                    if (hour > 11) {
                        if (hour - 12 + tArray[i] < 0) { hdelta.push(hour - 12 + tArray[i] + 12); }
                        else if (hour - 12 + tArray[i] > 11) { hdelta.push(hour - 12 + tArray[i] - 12); }
                        else { hdelta.push(hour - 12 + tArray[i]); }
                    } else {
                        if (hour + tArray[i] < 0) { hdelta.push(hour + tArray[i] + 12); }
                        else if (hour + tArray[i] > 11) { hdelta.push(hour + tArray[i] - 12); }
                        else { hdelta.push(hour + tArray[i]); }
                    }
                    hArray[i].setProperty(hmUI.prop.TEXT, `${ String(hdelta[i]) }`);
                }
            }

            for (i = 0; i < 7; i++) {
                if (minute + tArray[i] < 0) { mdelta.push(minute + tArray[i] + 60); }
                else if (minute + tArray[i] > 59) { mdelta.push(minute + tArray[i] - 60); }
                else { mdelta.push(minute + tArray[i]); }
                mArray[i].setProperty(hmUI.prop.TEXT, `${ String(mdelta[i]).padStart(2, '0') }`);
            }
        }

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                if (!timeSensor) { timeSensor = hmSensor.createSensor(hmSensor.id.TIME); }

                hmUI.createWidget(hmUI.widget.FILL_RECT, {
                    x: 0,
                    y: 0,
                    w: 466,
                    h: 466,
                    color: '0xFF000000',
                    radius: 233,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: center - 32 / 2,
                    y: center * 2 - 32 - 6,
                    src: '23.png',
                    type: hmUI.system_status.DISCONNECT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: center - 32 / 2,
                    y: center - hlH - ygap * 4 - apH - 32,
                    src: '24.png',
                    type: hmUI.system_status.CLOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hArray[0] = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: center - hlW - hmW * 2 - hsW * 4 - xgap * 3,
                    y: center - ygap - hsH,
                    w: hsW * 2,
                    h: hsH,
                    font_array: hsArray,
                    text: '1',
                    h_space: 0,
                    align_h: hmUI.align.CENTER_H,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hArray[1] = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: center - hlW - hmW * 2 - hsW * 2 - xgap * 2,
                    y: center - ygap - hsH,
                    w: hsW * 2,
                    h: hsH,
                    font_array: hsArray,
                    text: '2',
                    h_space: 0,
                    align_h: hmUI.align.CENTER_H,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hArray[2] = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: center - hlW  - hmW * 2 - xgap,
                    y: center - ygap - hmH,
                    w: hmW * 2,
                    h: hmH,
                    font_array: hmArray,
                    text: '3',
                    h_space: 0,
                    align_h: hmUI.align.CENTER_H,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hArray[3] = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: center - hlW,
                    y: center - ygap - hlH,
                    w: hlW * 2,
                    h: hlH,
                    font_array: hlArray,
                    text: '4',
                    h_space: 0,
                    align_h: hmUI.align.CENTER_H,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hArray[4] = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: center + hlW + xgap,
                    y: center - ygap - hmH,
                    w: hmW * 2,
                    h: hmH,
                    font_array: hmArray,
                    text: '5',
                    h_space: 0,
                    align_h: hmUI.align.CENTER_H,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hArray[5] = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: center + hlW + hmW * 2 + xgap * 2,
                    y: center - ygap - hsH,
                    w: hsW * 2,
                    h: hsH,
                    font_array: hsArray,
                    text: '6',
                    h_space: 0,
                    align_h: hmUI.align.CENTER_H,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hArray[6] = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: center + hlW + hmW * 2 + hsW * 2 + xgap * 3,
                    y: center - ygap - hsH,
                    w: hsW * 2,
                    h: hsH,
                    font_array: hsArray,
                    text: '7',
                    h_space: 0,
                    align_h: hmUI.align.CENTER_H,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                mArray[0] = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: center - hlW - hmW * 2 - hsW * 4 - xgap * 3,
                    y: center + ygap,
                    w: hsW * 2,
                    h: hsH,
                    font_array: hsArray,
                    text: '1',
                    h_space: 0,
                    align_h: hmUI.align.CENTER_H,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                mArray[1] = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: center - hlW - hmW * 2 - hsW * 2 - xgap * 2,
                    y: center + ygap,
                    w: hsW * 2,
                    h: hsH,
                    font_array: hsArray,
                    text: '2',
                    h_space: 0,
                    align_h: hmUI.align.CENTER_H,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                mArray[2] = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: center - hlW  - hmW * 2 - xgap,
                    y: center + ygap,
                    w: hmW * 2,
                    h: hmH,
                    font_array: hmArray,
                    text: '3',
                    h_space: 0,
                    align_h: hmUI.align.CENTER_H,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                mArray[3] = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: center - hlW,
                    y: center + ygap,
                    w: hlW * 2,
                    h: hlH,
                    font_array: hlArray,
                    text: '4',
                    h_space: 0,
                    align_h: hmUI.align.CENTER_H,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                mArray[4] = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: center + hlW + xgap,
                    y: center + ygap,
                    w: hmW * 2,
                    h: hmH,
                    font_array: hmArray,
                    text: '5',
                    h_space: 0,
                    align_h: hmUI.align.CENTER_H,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                mArray[5] = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: center + hlW + hmW * 2 + xgap * 2,
                    y: center + ygap,
                    w: hsW * 2,
                    h: hsH,
                    font_array: hsArray,
                    text: '6',
                    h_space: 0,
                    align_h: hmUI.align.CENTER_H,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                mArray[6] = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: center + hlW + hmW * 2 + hsW * 2 + xgap * 3,
                    y: center + ygap,
                    w: hsW * 2,
                    h: hsH,
                    font_array: hsArray,
                    text: '7',
                    h_space: 0,
                    align_h: hmUI.align.CENTER_H,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    am_x: center - apW / 2,
                    am_y: center - hlH - ygap * 3 - apH,
                    am_en_path: '2.png',
                    pm_x: center - apW / 2,
                    pm_y: center - hlH - ygap * 3 - apH,
                    pm_en_path: '3.png',
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: center - dW - wW - xgap * 2,
                    y: center + hlH + ygap * 3,
                    week_en: [
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png'
                    ],
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.FILL_RECT, {
                    x: center - dW - xgap - 1,
                    y: center + hlH + ygap * 3,
                    w: 2,
                    h: wH,
                    color: '0xFF545454',
                    radius: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    day_startX: center - dW,
                    day_startY: center + hlH + ygap * 3,
                    day_en_array: [
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png'
                    ],
                    day_align: hmUI.align.LEFT,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 0,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.FILL_RECT, {
                    x: center + dW + xgap - 1,
                    y: center + hlH + ygap * 3,
                    w: 2,
                    h: wH,
                    color: '0xFF545454',
                    radius: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: center + dW + xgap * 2,
                    y: center + hlH + ygap * 3,
                    font_array: [
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png'
                    ],
                    unit_en: '21.png',
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    type: hmUI.data_type.BATTERY,
                    padding: false,
                    isCharacter: false,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.FILL_RECT, {
                    x: center - xgap * 3 - dW * 2 - wW,
                    y: center + hlH + dH  + ygap * 4 - 1,
                    w: (xgap * 3 + dW * 2 + wW) * 2,
                    h: 2,
                    color: '0xFF545454',
                    radius: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: center - xgap - dW * 3,
                    y: center + hlH + dH  + ygap * 5,
                    w: dW * 3,
                    font_array: [
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png'
                    ],
                    invalid_image: '22.png',
                    align_h: hmUI.align.RIGHT,
                    h_space: 0,
                    type: hmUI.data_type.HEART,
                    padding: false,
                    isCharacter: false,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.FILL_RECT, {
                    x: center - 1,
                    y: center + hlH + dH  + ygap * 5,
                    w: 2,
                    h: wH,
                    color: '0xFF545454',
                    radius: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: center + xgap,
                    y: center + hlH + dH  + ygap * 5,
                    font_array: [
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png'
                    ],
                    invalid_image: '22.png',
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    type: hmUI.data_type.STEP,
                    padding: false,
                    isCharacter: false,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 0,
                    y: 0,
                    w: center * 2,
                    h: center - (hlH + dH  + ygap * 4),
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 0,
                    y: center + hlH + dH  + ygap * 4,
                    w: center,
                    h: center - (hlH + dH  + ygap * 4),
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: center,
                    y: center + hlH + dH  + ygap * 4,
                    w: center,
                    h: center - (hlH + dH  + ygap * 4),
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });

                timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
                    setLabel(timeSensor);
                });
                timer.createTimer(0, 60000, function (timeSensor2) {
                    setLabel(timeSensor2);
                }, timeSensor);
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function() {
                        setLabel(timeSensor);
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
