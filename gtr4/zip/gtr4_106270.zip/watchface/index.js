try {
  ;(() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp

    var __$$module$$__ = __$$app$$__.current
    var h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__),
      'drink'
    )

    /*
     * huamiOS bundle tool v1.0.17
     * Copyright © Huami. All Rights Reserved
     */
    ;('use strict')

    console.log('----->>>current')
    console.log(__$$hmAppManager$$__.currentApp.pid)
    console.log(__$$hmAppManager$$__.currentApp.current)

    const stepWidgetArray = new Array(5)
    const calorieWidgetArray = new Array(4)

    let rootPath = 'images/'
    let bgPath = rootPath + 'bg/'
    let week_enPath = rootPath + 'week_en/'
    let week_scPath = rootPath + 'week_sc/'
    let week_tcPath = rootPath + 'week_tc/'
    let timePath = rootPath + 'time/'
    let amPath = rootPath + 'am/'
    let dayPath = rootPath + 'fonts/'
    let clockPath = rootPath + 'clock/'
    let stepPath = rootPath + 'steps/'
    let font_stepsPath = rootPath + 'font_steps/'
    let weather_imgPath = rootPath + 'weather/'
    let calorie_imgPath = rootPath + 'calories/'
    let power_imgPath = rootPath + 'power/'

    let time_array = []
    let week_en_array = []
    let week_sc_array = []
    let week_tc_array = []
    let day_array = []
    let step_array = []
    let font_steps_array = []
    let weather_img_array = []
    let calorie_array = []
    let power_img_array = []

    const DISPLAY_LEVEL = hmUI.show_level.ONLY_NORMA

    const logger = DeviceRuntimeCore.HmLogger.getLogger('defult')
    let calorieSensor = hmSensor.createSensor(hmSensor.id.CALORIE)
    let stepSensor = hmSensor.createSensor(hmSensor.id.STEP)
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      setImgPath(widget, path) {
        widget.setProperty(hmUI.prop.SRC, path)
        widget.setProperty(hmUI.prop.VISIBLE, true)
      },
      addShowLevel(config) {
        config.showLevel = DISPLAY_LEVEL
        return config
      },

      init_view() {
        for (let i = 0; i < 10; i++) {
          time_array.push(timePath + '0' + i + '.png')
          day_array.push(dayPath + '0' + i + '.png')
          font_steps_array.push(font_stepsPath + '0' + i + '.png')
        }

        for (let j = 1; j < 11; j++) {
          step_array.push(stepPath + j + '.png')
          calorie_array.push(calorie_imgPath + j + '.png')
        }

        for (let k = 0; k < 29; k++) {
          weather_img_array.push(weather_imgPath + k + '.png')
        }

        for (let p = 1; p < 6; p++) {
          // calorie_array.push(calorie_imgPath + '0' + p + '.png')
          power_img_array.push(power_imgPath + '0' + p + '.png')
        }

        for (let k = 1; k < 8; k++) {
          week_en_array.push(week_enPath + '0' + k + '.png')
          week_sc_array.push(week_scPath + '0' + k + '.png')
          week_tc_array.push(week_tcPath + '0' + k + '.png')
        }

        let obj_bg = {
          x: 0,
          y: 0,
          w: 480 * 0.987083,
          h: 480 * 0.987083,
          src: bgPath + 'bg.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        }

        let obj_week = {
          x: 57 * 0.987083,
          y: 233,
          week_en: week_en_array,
          week_tc: week_tc_array,
          week_sc: week_sc_array,
          show_level: hmUI.show_level.ONLY_NORMAL,
        }

        let obj_date = {
          day_startX: 75 * 0.987083,
          day_startY: 208 * 0.987083,
          day_align: hmUI.align.LEFT,
          day_space: 0,
          day_zero: 1,
          day_en_array: day_array,
          day_sc_array: day_array,
          day_tc_array: day_array,
          show_level: hmUI.show_level.ONLY_NORMAL,
        }

        let obj_weather_progress_bar = {
          x: 220 * 0.987083,
          y: 53 * 0.987083,
          image_array: weather_img_array,
          image_length: weather_img_array.length,
          type: hmUI.data_type.WEATHER,
          show_level: hmUI.show_level.ONLY_NORMAL,
        }

        let obj_battery_progress_bar = {
          x: 329,
          y: 126 * 0.987083,
          image_array: power_img_array,
          image_length: power_img_array.length,
          type: hmUI.data_type.BATTERY,
          show_level: hmUI.show_level.ONLY_NORMAL,
        }

        let obj_weather_text = {
          x: 189,
          y: 96 * 0.987083,
          w: 100 * 0.987083,
          type: hmUI.data_type.WEATHER_CURRENT,
          font_array: day_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          unit_sc: dayPath + '11.png',
          unit_tc: dayPath + '11.png',
          unit_en: dayPath + '11.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
          negative_image: dayPath + '10.png',
          invalid_image: dayPath + '12.png',
          // padding: 1,
        }

        let obj_time_pointer = {
          hour_centerX: 233,
          hour_centerY: 233,
          hour_posX: 18 * 0.987083,
          hour_posY: 154 * 0.987083,
          hour_path: clockPath + 'hour.png',
          minute_centerX: 233,
          minute_centerY: 233,
          minute_posX: 11 * 0.987083,
          minute_posY: 196 * 0.987083,
          minute_path: clockPath + 'min.png',
          second_centerX: 233,
          second_centerY: 233,
          second_posX: 7 * 0.987083,
          second_posY: 98 * 0.987083,
          second_path: clockPath + 'sec.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        }

        let obj_heart_text = {
          x: 216 * 0.987083,
          y: 395 * 0.987083,
          type: hmUI.data_type.HEART,
          font_array: day_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NORMAL,
          invalid_image: rootPath + 'fonts/12.png',
        }

        let obj_time_pointer_xp = {
          hour_centerX: 233,
          hour_centerY: 233,
          hour_posX: 18 * 0.987083,
          hour_posY: 154 * 0.987083,
          hour_path: clockPath + 'hour.png',
          minute_centerX: 233,
          minute_centerY: 233,
          minute_posX: 11 * 0.987083,
          minute_posY: 196 * 0.987083,
          minute_path: clockPath + 'min.png',
          show_level: hmUI.show_level.ONAL_AOD,
        }

        let obj_cal_progress_bar = {
          x: 11 * 0.987083,
          y: 224,
          image_array: calorie_array,
          image_length: calorie_array.length,
          type: hmUI.data_type.CAL,
          show_level: hmUI.show_level.ONLY_NORMAL,
        }

        let obj_step_progress_bar = {
          x: 230,
          y: 4 * 0.987083,
          image_array: step_array,
          image_length: step_array.length,
          type: hmUI.data_type.STEP,
          show_level: hmUI.show_level.ONLY_NORMAL,
          // shortcut: true,
        }

        let obj_bg_xp = {
          x: 225 * 0.987083,
          y: 225 * 0.987083,
          src: bgPath + 'bg2.png',
          show_level: hmUI.show_level.ONAL_AOD,
        }

        let obj_step_icon_click = {
          x: 205,
          y: 15,
          w: 25,
          h: 25,
          type: hmUI.data_type.STEP,
        }

        let obj_step_text_click = {
          x: 434,
          y: 230,
          w: 15,
          h: 55,
          type: hmUI.data_type.STEP,
        }

        let obj_weather_click = {
          x: 208,
          y: 50,
          w: 50,
          h: 70,
          type: hmUI.data_type.WEATHER_CURRENT,
        }

        let obj_cal_text_click = {
          x: 18,
          y: 170,
          w: 15,
          h: 55,
          type: hmUI.data_type.CAL,
        }

        let obj_cal_icon_click = {
          x: 244,
          y: 432,
          w: 20,
          h: 20,
          type: hmUI.data_type.CAL,
        }

        let obj_heart_click = {
          x: 206,
          y: 350,
          w: 60,
          h: 63,
          type: hmUI.data_type.HEART,
        }

        let bg_img = hmUI.createWidget(hmUI.widget.IMG, obj_bg)

        let weekText = hmUI.createWidget(hmUI.widget.IMG_WEEK, obj_week)

        let datText = hmUI.createWidget(hmUI.widget.IMG_DATE, obj_date)

        let weather_img = hmUI.createWidget(hmUI.widget.IMG_LEVEL, obj_weather_progress_bar)

        let power_img = hmUI.createWidget(hmUI.widget.IMG_LEVEL, obj_battery_progress_bar)

        let weatherText = hmUI.createWidget(hmUI.widget.TEXT_IMG, obj_weather_text)

        let timePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, obj_time_pointer)

        let heartText = hmUI.createWidget(hmUI.widget.TEXT_IMG, obj_heart_text)

        let calorie_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, obj_cal_progress_bar)

        let setp_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, obj_step_progress_bar)

        let AOD_bg_img = hmUI.createWidget(hmUI.widget.IMG, obj_bg_xp)

        let AOD_timePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, obj_time_pointer_xp)

        // 步数图标点击
        let step_icon = hmUI.createWidget(hmUI.widget.IMG_CLICK, obj_step_icon_click)

        // 天气位置点击
        let weather_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, obj_weather_click)

        // 步数数据点击
        let step_text_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, obj_step_text_click)

        // 卡路里数据点击
        let cal_text_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, obj_cal_text_click)

        // 卡路里数据点击
        let cal_icon_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, obj_cal_icon_click)

        // 心率数据点击
        let heart_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, obj_heart_click)

        //创建图片文本控件
        function textImg() {
          this.create()
        }
        textImg.prototype.create = function () {
          this.widget = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
            show_level: hmUI.show_level.ONLY_NORMAL,
          })
        }
        textImg.prototype.set = function (x, y, text) {
          this.widget.setProperty(hmUI.prop.MORE, {
            x: x,
            y: y,
            text: text,
            font_array: font_steps_array,
            h_space: 0,
            align_h: hmUI.align.LEFT,
            padding: false,
            show_level: hmUI.show_level.ONLY_NORMAL,
          })
        }
        textImg.prototype.hide = function () {
          this.widget.setProperty(hmUI.prop.VISIBLE, false)
        }
        textImg.prototype.show = function () {
          this.widget.setProperty(hmUI.prop.VISIBLE, true)
        }
        //创建步数文本控件
        let stepTextArr = []
        for (let i = 0; i < 5; i++) {
          let stepText = new textImg()
          stepTextArr.push(stepText)
        }
        //创建卡路里文本控件
        let calTextArr = []
        for (let i = 0; i < 4; i++) {
          let calText = new textImg()
          calTextArr.push(calText)
        }
        //获取当前步数
        function currentStepFn() {
          let currentStep = stepSensor.current
          // currentStep = 5641
          let length = String(currentStep).length
          //更新当前布数信息
          for (let i = 0; i < stepTextArr.length; i++) {
            stepTextArr[i].hide()
          }
          for (let i = 0; i < length; i++) {
            stepTextArr[i].show()
            stepTextArr[i].set(434, 242 + i * 10, String(currentStep)[i])
          }
        }
        currentStepFn()
        //获取当前卡路里
        function currentCalFn() {
          let currentCal = calorieSensor.current
          // currentCal = 257
          let length = String(currentCal).length
          let start = 209 - (length - 1) * 10
          //更新当前卡路里信息
          for (let i = 0; i < calTextArr.length; i++) {
            calTextArr[i].hide()
          }
          for (let i = 0; i < length; i++) {
            calTextArr[i].show()
            calTextArr[i].set(18, start + i * 10, String(currentCal)[i])
          }
        }
        currentCalFn()
        //update
        var clockTimer = timer.createTimer(
          0,
          1000,
          function (option) {
            currentStepFn()
            currentCalFn()
          },
          {}
        )

        const vDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: () => {},
          pause_call: function () {},
        })
      },

      onInit() {
        console.log('index page.js on init invoke')

        this.init_view()
      },

      onReady() {
        console.log('index page.js on ready invoke')
      },

      onShow() {
        console.log('index page.js on show invoke')
      },

      onHide() {
        console.log('index page.js on hide invoke')
      },

      onDestory() {
        console.log('index page.js on destory invoke')
      },
    })
    /*
     * end js
     */
  })()
} catch (e) {
  console.log(e)
}
