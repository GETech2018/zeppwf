try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$component_0$_$component = '';
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 466,
                    h: 466,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 48,
                    y: 289,
                    week_en: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png'
                    ],
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 48,
                    month_startY: 220,
                    month_sc_array: [
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png'
                    ],
                    month_tc_array: [
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png'
                    ],
                    month_en_array: [
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png'
                    ],
                    month_align: hmUI.align.LEFT,
                    month_zero: 1,
                    month_follow: 0,
                    month_space: 3,
                    month_is_character: false,
                    day_startX: 48,
                    day_startY: 170,
                    day_sc_array: [
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png'
                    ],
                    day_tc_array: [
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png'
                    ],
                    day_en_array: [
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png'
                    ],
                    day_align: hmUI.align.LEFT,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 3,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 150,
                    hour_startY: 110,
                    hour_array: [
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png'
                    ],
                    hour_space: 6,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 150,
                    minute_startY: 230,
                    minute_array: [
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png'
                    ],
                    minute_space: 6,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    second_zero: 1,
                    second_startX: 361,
                    second_startY: 195,
                    second_array: [
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png'
                    ],
                    second_space: 3,
                    second_align: hmUI.align.LEFT,
                    second_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 233,
                    center_y: 233,
                    radius: 229,
                    start_angle: 15,
                    end_angle: 345,
                    color: 4294901760,
                    line_width: 8,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 170,
                    y: 0,
                    type: hmUI.data_type.BATTERY,
                    font_array: [
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 220,
                    y: 63,
                    src: '40.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$component_0$_$component = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: 1,
                    x: 125,
                    y: 362,
                    w: 250,
                    h: 90,
                    select_image: '41.png',
                    un_select_image: '42.png',
                    default_type: hmUI.edit_type.HEART,
                    optional_types: [
                        {
                            'type': hmUI.edit_type.HEART,
                            'preview': '44.png'
                        },
                        {
                            'type': hmUI.edit_type.STEP,
                            'preview': '45.png'
                        },
                        {
                            'type': hmUI.edit_type.CAL,
                            'preview': '46.png'
                        },
                        {
                            'type': hmUI.edit_type.TEMPERATURE,
                            'preview': '47.png'
                        },
                        {
                            'type': hmUI.edit_type.DISTANCE,
                            'preview': '48.png'
                        },
                        {
                            'type': hmUI.edit_type.PAI_DAILY,
                            'preview': '49.png'
                        }
                    ],
                    count: 6,
                    tips_BG: '43.png',
                    tips_x: -125,
                    tips_y: -362,
                    tips_width: 466,
                    tips_margin: 0
                });
                editType = normal$_$component_0$_$component.getProperty(hmUI.prop.CURRENT_TYPE);
                switch (editType) {
                case hmUI.edit_type.STEP:
                    hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                        center_x: 388,
                        center_y: 315,
                        radius: 30,
                        start_angle: 0,
                        end_angle: 360,
                        color: 4294770688,
                        line_width: 6,
                        type: hmUI.data_type.STEP,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 190,
                        y: 390,
                        type: hmUI.data_type.STEP,
                        font_array: [
                            '10.png',
                            '11.png',
                            '12.png',
                            '13.png',
                            '14.png',
                            '15.png',
                            '16.png',
                            '17.png',
                            '18.png',
                            '19.png'
                        ],
                        align_h: hmUI.align.RIGHT,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        padding: true,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 140,
                        y: 380,
                        w: 40,
                        h: 60,
                        src: '50.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 130,
                        y: 360,
                        w: 210,
                        h: 90,
                        type: hmUI.data_type.STEP,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.BATTERY:
                    break;
                case hmUI.edit_type.HEART:
                    hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                        center_x: 388,
                        center_y: 315,
                        radius: 30,
                        start_angle: 0,
                        end_angle: 360,
                        color: 4294901760,
                        line_width: 6,
                        type: hmUI.data_type.HEART,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 240,
                        y: 390,
                        type: hmUI.data_type.HEART,
                        font_array: [
                            '10.png',
                            '11.png',
                            '12.png',
                            '13.png',
                            '14.png',
                            '15.png',
                            '16.png',
                            '17.png',
                            '18.png',
                            '19.png'
                        ],
                        align_h: hmUI.align.RIGHT,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '51.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 140,
                        y: 380,
                        w: 40,
                        h: 60,
                        src: '52.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 130,
                        y: 360,
                        w: 210,
                        h: 90,
                        type: hmUI.data_type.HEART,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.CAL:
                    hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                        center_x: 388,
                        center_y: 315,
                        radius: 30,
                        start_angle: 0,
                        end_angle: 360,
                        color: 4294901760,
                        line_width: 6,
                        type: hmUI.data_type.CAL,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 210,
                        y: 390,
                        type: hmUI.data_type.CAL,
                        font_array: [
                            '10.png',
                            '11.png',
                            '12.png',
                            '13.png',
                            '14.png',
                            '15.png',
                            '16.png',
                            '17.png',
                            '18.png',
                            '19.png'
                        ],
                        align_h: hmUI.align.LEFT,
                        h_space: 3,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        padding: true,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 140,
                        y: 380,
                        w: 40,
                        h: 60,
                        src: '53.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 120,
                        y: 360,
                        w: 220,
                        h: 90,
                        type: hmUI.data_type.CAL,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.PAI_DAILY:
                    hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                        center_x: 388,
                        center_y: 315,
                        radius: 30,
                        start_angle: 0,
                        end_angle: 360,
                        color: 4294901760,
                        line_width: 6,
                        type: hmUI.data_type.PAI_DAILY,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 240,
                        y: 390,
                        type: hmUI.data_type.PAI_DAILY,
                        font_array: [
                            '10.png',
                            '11.png',
                            '12.png',
                            '13.png',
                            '14.png',
                            '15.png',
                            '16.png',
                            '17.png',
                            '18.png',
                            '19.png'
                        ],
                        align_h: hmUI.align.LEFT,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        padding: true,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 140,
                        y: 380,
                        w: 40,
                        h: 60,
                        src: '54.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 120,
                        y: 360,
                        w: 220,
                        h: 90,
                        type: hmUI.data_type.PAI_DAILY,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.DISTANCE:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 220,
                        y: 390,
                        type: hmUI.data_type.DISTANCE,
                        font_array: [
                            '10.png',
                            '11.png',
                            '12.png',
                            '13.png',
                            '14.png',
                            '15.png',
                            '16.png',
                            '17.png',
                            '18.png',
                            '19.png'
                        ],
                        align_h: hmUI.align.LEFT,
                        h_space: 3,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        dot_image: '55.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 355,
                        y: 289,
                        src: '56.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 130,
                        y: 360,
                        w: 210,
                        h: 90,
                        type: hmUI.data_type.DISTANCE,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.AQI:
                    break;
                case hmUI.edit_type.HUMIDITY:
                    break;
                case hmUI.edit_type.ALTIMETER:
                    break;
                case hmUI.edit_type.STRESS:
                    break;
                case hmUI.edit_type.WIND:
                    break;
                case hmUI.edit_type.SPO2:
                    break;
                case hmUI.edit_type.TRAINING_LOAD:
                    break;
                case hmUI.edit_type.VO2MAX:
                    break;
                case hmUI.edit_type.UVI:
                    break;
                case hmUI.edit_type.DATE:
                    break;
                case hmUI.edit_type.WEEK:
                    break;
                case hmUI.edit_type.WEATHER:
                    break;
                case hmUI.edit_type.TEMPERATURE:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 240,
                        y: 390,
                        type: hmUI.data_type.WEATHER_CURRENT,
                        font_array: [
                            '10.png',
                            '11.png',
                            '12.png',
                            '13.png',
                            '14.png',
                            '15.png',
                            '16.png',
                            '17.png',
                            '18.png',
                            '19.png'
                        ],
                        align_h: hmUI.align.RIGHT,
                        h_space: 3,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        negative_image: '58.png',
                        invalid_image: '57.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 370,
                        y: 289,
                        w: 33,
                        h: 50,
                        src: '59.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 130,
                        y: 360,
                        w: 210,
                        h: 90,
                        type: hmUI.data_type.WEATHER_CURRENT,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.SUN:
                    break;
                }
                hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK, {
                    x: 0,
                    y: 0,
                    w: 466,
                    h: 466,
                    src: '60.png',
                    show_level: hmUI.show_level.ONLY_EDIT
                });
                hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
                    x: 0,
                    y: 0,
                    w: 466,
                    h: 466,
                    src: '61.png',
                    show_level: hmUI.show_level.ONLY_EDIT
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 48,
                    month_startY: 220,
                    month_sc_array: [
                        '62.png',
                        '63.png',
                        '64.png',
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png',
                        '71.png'
                    ],
                    month_tc_array: [
                        '62.png',
                        '63.png',
                        '64.png',
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png',
                        '71.png'
                    ],
                    month_en_array: [
                        '62.png',
                        '63.png',
                        '64.png',
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png',
                        '71.png'
                    ],
                    month_align: hmUI.align.LEFT,
                    month_zero: 1,
                    month_follow: 0,
                    month_space: 3,
                    month_is_character: false,
                    day_startX: 48,
                    day_startY: 170,
                    day_sc_array: [
                        '62.png',
                        '63.png',
                        '64.png',
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png',
                        '71.png'
                    ],
                    day_tc_array: [
                        '62.png',
                        '63.png',
                        '64.png',
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png',
                        '71.png'
                    ],
                    day_en_array: [
                        '62.png',
                        '63.png',
                        '64.png',
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png',
                        '71.png'
                    ],
                    day_align: hmUI.align.LEFT,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 3,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 150,
                    hour_startY: 110,
                    hour_array: [
                        '72.png',
                        '73.png',
                        '74.png',
                        '75.png',
                        '76.png',
                        '77.png',
                        '78.png',
                        '79.png',
                        '80.png',
                        '81.png'
                    ],
                    hour_space: 6,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 150,
                    minute_startY: 230,
                    minute_array: [
                        '72.png',
                        '73.png',
                        '74.png',
                        '75.png',
                        '76.png',
                        '77.png',
                        '78.png',
                        '79.png',
                        '80.png',
                        '81.png'
                    ],
                    minute_space: 6,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 233,
                    center_y: 233,
                    radius: 229,
                    start_angle: 15,
                    end_angle: 345,
                    color: 4294901760,
                    line_width: 8,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 170,
                    y: 0,
                    type: hmUI.data_type.BATTERY,
                    font_array: [
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_AOD,
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 220,
                    y: 63,
                    src: '40.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 48,
                    y: 289,
                    week_en: [
                        '82.png',
                        '83.png',
                        '84.png',
                        '85.png',
                        '86.png',
                        '87.png',
                        '88.png'
                    ],
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 180,
                    y: 0,
                    w: 100,
                    h: 100,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}