try {
    (() => {
    
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
  
    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');
  
      /*
    * huamiOS bundle tool v1.0.17
    * Copyright © Huami. All Rights Reserved
    */
    'use strict';
  
    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let dataArray = []
    let secArray = []
    let stepArray = []
    let weekArray = []
    let img_bg = null
 
    
    let moonArray =[]
    let dayImg = null
    let jstime = null
    let currentDay = null
    const  ROOTPATH = "images/"
   
   
    const logger = DeviceRuntimeCore.HmLogger.getLogger("defult");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
        init_view() {

            creatAllArr();

            img_bg = hmUI.createWidget(hmUI.widget.IMG,{
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                src: ROOTPATH + "img/bg.png",
                show_level:hmUI.show_level.ONLY_NORMAL,
            });  
            let bg_aod= hmUI.createWidget(hmUI.widget.FILL_RECT, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                color: 0x000000,
                show_level:hmUI.show_level.ONLY_AOD | hmUI.show_level.ONAL_AOD ,
            });

            let timep = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                hour_centerX: 233,
                hour_centerY: 233,
                hour_posX: 26,
                hour_posY: 179,
                hour_path:  ROOTPATH + "img/h.png",
                
                minute_centerX: 233,
                minute_centerY: 233,
                minute_posX: 21,
                minute_posY: 229,
                minute_path:  ROOTPATH + "img/m.png",
                show_level:hmUI.show_level.ONLY_AOD | hmUI.show_level.ONAL_AOD,
            })

            let weekLevel = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                x: 225,
                y: 97,
                w: 206,
                h: 270,
                week_sc: weekArray,
                week_tc: weekArray,
                week_en: weekArray,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });
            let heartTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG,{
                x: 210, 
                y: 375,
                type: hmUI.data_type.HEART,
                font_array: dataArray,
                align_h: hmUI.align.CENTER_H,
                invalid_image: ROOTPATH + "data/invalid.png",
                padding:false, 
                show_level: hmUI.show_level.ONLY_NORMAL,
            })
               
            let heartPoiner= hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                src:  ROOTPATH + "img/p.png",
                center_x: 233,
                center_y: 350,
                x: 10,
                y: 68,
                type: hmUI.data_type.HEART,
                start_angle: -180,
                end_angle: 180,
                show_level: hmUI.show_level.ONLY_NORMAL,
            })
           
            //battery-----
            let batTxt =hmUI.createWidget(hmUI.widget.TEXT_IMG,{
                x: 210,
                y: 120,
                type:hmUI.data_type.BATTERY,
                font_array: dataArray ,
                align_h:hmUI.align.CENTER_H,
                padding:false, 
                show_level:hmUI.show_level.ONLY_NORMAL,
            })
            let batPoiner= hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                src:  ROOTPATH + "img/bat_p.png",
                center_x: 233,
                center_y: 116,
                x: 10,
                y: 55,
                type: hmUI.data_type.BATTERY,
                start_angle: -180,
                end_angle: 180,
                show_level: hmUI.show_level.ONLY_NORMAL,
            })
                //----------
               
            let moonLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL,{
                x: 76,
                y: 80,
                w: 64, 
                h: 64,
                image_array: moonArray,
                image_length: moonArray.length,//长度
                type: hmUI.data_type.MOON,
                shortcut: true, // optional, 默认为false, 表示是否使能快捷跳转功能
                show_level:hmUI.show_level.ONLY_NORMAL,
            });
            
            let stepTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG,{
                x: 76,
                y: 232,
                type:hmUI.data_type.STEP,
                font_array: dataArray ,
                align_h:hmUI.align.CENTER_H,
                padding:false, 
                h_space: 0, 
                show_level:hmUI.show_level.ONLY_NORMAL,
            })
            let stepLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                x: 33,
                y: 149,
                w: 168, 
                h: 168,
                image_array: stepArray,
                image_length: stepArray.length,
                type: hmUI.data_type.STEP,
                shortcut: true, 
                show_level: hmUI.show_level.ONLY_NORMAL
            })
            
            dayImg = hmUI.createWidget(hmUI.widget.IMG,{
                x: 226,
                y: 98,
                w: 206,
                h: 270,
                //src: ROOTPATH + "img/bg.png",
                show_level:hmUI.show_level.ONLY_NORMAL,
            }); 
             let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    second_zero:1, //是否补零
                    second_startX:88,
                    second_startY:343,
                    second_array: secArray,
                    second_space:0, //每个数组间的间隔
                    second_align:hmUI.align.LEFT,
                
                   
                   
                    am_x:277,
                    am_y:195,
                    am_sc_path:  ROOTPATH + "img/am.png",
                    am_en_path:  ROOTPATH + "img/am.png",
                    pm_x:277,
                    pm_y:195,
                    pm_sc_path:  ROOTPATH + "img/pm.png",
                    pm_en_path:  ROOTPATH + "img/pm.png",
                    show_level:hmUI.show_level.ONLY_NORMAL,
                });   
               let timepointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 233,
                    hour_centerY: 233,
                    hour_posX: 26,
                    hour_posY: 179,
                    hour_path:  ROOTPATH + "img/h.png",
                   
                    minute_centerX: 233,
                    minute_centerY: 233,
                    minute_posX: 21,
                    minute_posY: 229,
                    minute_path:  ROOTPATH + "img/m.png",
                   
                    second_centerX: 233,
                    second_centerY: 233,
                    second_posX: 13,
                    second_posY: 242,
                    second_path:  ROOTPATH + "img/s.png",
                   
                    show_level: hmUI.show_level.ONLY_NORMAL
                })
               // click--------------------------
               let batClick = hmUI.createWidget(hmUI.widget.IMG_CLICK,{
                    x: 165,
                    y: 38,
                    w: 140,
                    h: 140,
                    type: hmUI.data_type.BATTERY,
            });
               let heartClick = hmUI.createWidget(hmUI.widget.IMG_CLICK,{
                    x: 160,
                    y: 290,
                    w: 140,
                    h: 140,
                    type: hmUI.data_type.HEART,
                });
                let stepClick = hmUI.createWidget(hmUI.widget.IMG_CLICK,{
                    x: 45,
                    y: 160,
                    w: 140,
                    h: 140,
                    type:hmUI.data_type.STEP,
                });
               
                let moonClick = hmUI.createWidget(hmUI.widget.IMG_CLICK,{
                    x: 62,
                    y: 73,
                    w: 84,
                    h: 73,
                    type:hmUI.data_type.MOON, 
                });
                function creatAllArr() {
                    for(var i=0; i<=29; i++){
                        if(i<=9) {
                            secArray.push(ROOTPATH + "secNum/"+i+".png");
                            stepArray.push(ROOTPATH + "step_progress/"+i+".png");
                            dataArray.push(ROOTPATH + "data/"+i+".png");
                        }
                        if(i<=6) {
                            weekArray.push(ROOTPATH + "week/"+(i+1)+".png");
                        }
                        moonArray.push(ROOTPATH +  "moon/"+i+".png");
                    }
                }

            jstime = hmSensor.createSensor(hmSensor.id.TIME);
            // 读取日期
            setDayPath(jstime.year,jstime.month, jstime.day);
            // 监听时间变化
            jstime.addEventListener(jstime.event.DAYCHANGE, function() {
               console.log("date change"+jstime.day);
               setDayPath(jstime.year,jstime.month, jstime.day);
            });
            function setDayPath(year,month,day)
            {
                getDayPath(year,month,day);
                let dayPath = ROOTPATH + "date/"+ currentDay+".png";
                dayImg.setProperty(hmUI.prop.SRC, dayPath);
            }
            function  getDayPath(year,month,day){
                 if( month == 4 || month == 6 || month == 9 || month ==11 )//30天
                 {
                     if(day == 1 ) day = "1_31";
                     if(day == 2 ) day = "2_31";
                     

                     if(day == 29 ) day = "29_30";
                     if(day == 30 ) day = "30_30";

                 }else if(month == 5 || month ==7 || month == 8 || month ==10|| month == 12) {//31天  1- 3-5-7-8-10-12
                    
                    if( month == 8){
                        if(day == 1 ) day = "1_31";
                        if(day == 2 ) day = "2_31";
                    }else{
                        if(day == 1 ) day = "1_30";
                        if(day == 2 ) day = "2_30";
                    }
                   
                    
                     if(day == 29 ) day = "29_31";
                     if(day == 30 ) day = "30_31";
                     if(day == 31 ) day = "31_31";

                 }else{
                 if(year % 4 == 0 && (year % 100!=0 || year % 400==0)){//闰年
                     if(month == 1){//闰年2月29天
                         if(day == 1 ) day = "1_31"; //12月31
                         if(day == 2 ) day = "2_31";

                         if(day == 29 ) day = "29_31";
                         if(day == 30 ) day = "30_31";
                         if(day == 31 ) day = "31_31"; // 

                     }
                     if(month == 2){//闰年2月29天
                         if(day == 1 ) day = "1_31";
                         if(day == 2 ) day = "2_31";
                         if(day == 28 ) day = "28_29";
                         if(day == 29 ) day = "29_29";
                     }
                     if(month == 3){//闰年2月29天
                         if(day == 1 ) day = "1_29";
                         if(day == 2 ) day = "2_29";
                         
                         if(day == 29 ) day = "29_31";
                         if(day == 30 ) day = "30_31";
                         if(day == 31 ) day = "31_31";

                     }
                     }else {//平年2月28天----------------------平年------------
                         if(month == 1){
                            if(day == 1 ) day = "1_31"; //12月31
                            if(day == 2 ) day = "2_31";
                    
                            if(day == 29 ) day = "29_31";
                            if(day == 30 ) day = "30_31";
                            if(day == 31 ) day = "31_31"; 

                         }
                        if(month == 2){
                             if(day == 1 ) day = "1_31";
                             if(day == 2 ) day = "2_31";
                             if(day == 27 ) day = "27_28";
                             if(day == 28 ) day = "28_28";

                        }
                        if(month == 3){
                             if(day == 1 ) day = "1_28";
                             if(day == 2 ) day = "2_28";
                            
                             if(day == 29 ) day = "29_31";
                             if(day == 30 ) day = "30_31";
                             if(day == 31 ) day = "31_31";
                        }
                    }
                }
                 currentDay = day;
             };

            
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                resume_call: (function () {
                    setDayPath(jstime.year,jstime.month, jstime.day);
                }),
                pause_call: (function () {
                    console.log('ui pause');
                }),
            });
        },

        onInit() {
            console.log('index page.js on init invoke');

            this.init_view();

            
        },

        onReady() {
            console.log('index page.js on ready invoke')
        },

        onShow() {
            console.log('index page.js on show invoke')
        },

        onHide() {
            console.log('index page.js on hide invoke')
        },

        onDestory() {
            console.log('index page.js on destory invoke')
        },
    });
    /*
    * end js
    */
        })()
    } catch (e) {
        console.log(e)
    }