/*
 * =====================================================================================
 *
 *  Copyright (C) 2021. Huami Ltd, unpublished work. This computer program includes
 *  Confidential, Proprietary Information and is a Trade Secret of Huami Ltd.
 *  All use, disclosure, and/or reproduction is prohibited unless authorized in writing.
 *  All Rights Reserved.
 *
 *  Author: Huami
 *
 * =====================================================================================
 */
try {
  (() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');
    /*
     * huamiOS bundle tool v1.0.17
     * Copyright © Huami. All Rights Reserved
     */
    'use strict';
    let arrryBG = [];
    for (let i = 1; i <= 6; i++)
      arrryBG.push("images/bg/bg" + i + ".png");

    let arrayWeather = [];
    for (let i = 0; i <= 28; i++)
      arrayWeather.push("images/weather/weather_" + i + ".png");

    let arrayMoon = [];
    for (let i = 1; i <= 13; i++)
      arrayMoon.push("images/moon/moon" + i + ".png");
    function px(num) {
      return num * (466 / 480);
    }

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        let default_bg = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 466, //宽高可省略
          h: 466,
          src: "images/bg/bg1.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let bg_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 0,
          y: 0,
          w: 466, //宽高可省略
          h: 466,
          image_array: arrryBG,
          image_length: 6,
          type: hmUI.data_type.HEART,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let anim_cage = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
          x: px(130),
          y: px(256) + 1,
          // w: 220,
          // h: 220,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          anim_path: "images/animate",
          anim_prefix: "rotation",
          anim_ext: "png",
          anim_fps: 25,
          anim_size: 151,
          anim_repeat: true,
          step: 1,
          repeat_count: 1,
          anim_status: 1,
          display_on_restart: true,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        let bottom1_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          second_centerX: 233, //指针旋转中心 对应centerX
          second_centerY: px(368), //指针旋转中心 对应centerY
          second_posX: 93, //指针自身旋转中心 对应positioin中的x
          second_posY: 93, //指针自身旋转中心 对应positioin中的y
          second_path: "images/bottom_1.png",
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        let compass = hmUI.createWidget(hmUI.widget.IMG, {
          x: px(71) + 1,
          y: px(349) + 2,
          // w:338,
          // h:44,
          src: "images/bottom_2.png",
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        let compas = hmUI.createWidget(hmUI.widget.IMG, {
          x: px(104),
          y: px(91),
          // w:36,
          // h:36,
          src: "images/icon/compass.png",
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        compas.addEventListener(hmUI.event.CLICK_UP, (function (info) {

          hmApp.startApp({ url: "CompassScreen", native: true });
        }));

        let weather = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: px(345),
          y: px(91),
          // w: 36, //宽高可省略
          // h: 36,
          image_array: arrayWeather,
          image_length: arrayWeather.length,
          type: hmUI.data_type.WEATHER,
          shortcut: true,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let battery_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
          src: "images/pointer/pointer.png",
          center_x: px(381),
          center_y: px(240),
          x: px(16),
          y: px(78),
          type: hmUI.data_type.BATTERY,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        let heart_rate_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
          src: "images/pointer/pointer.png",
          center_x: px(97),
          center_y: px(240),
          x: px(16),
          y: px(78),
          type: hmUI.data_type.HEART,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        let moon = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: px(184),
          y: px(63),
          // w: 116, //宽高可省略
          // h: 91,
          image_array: arrayMoon,
          image_length: arrayMoon.length,
          type: hmUI.data_type.MOON,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let week_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
          src: "images/pointer/pointer.png",
          center_x: px(240),
          center_y: px(109),
          x: px(16),
          y: px(78),
          start_angle: 308,
          end_angle: 308,
          type: hmUI.data_type.WEEK,
          show_level: hmUI.show_level.ONLY_NORMAL
        });



        let time_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_centerX: px(240), //指针旋转中心 对应centerX
          hour_centerY: px(240), //指针旋转中心 对应centerY
          hour_posX: px(35), //指针自身旋转中心 对应positioin中的x
          hour_posY: px(240), //指针自身旋转中心 对应positioin中的y
          hour_path: "images/pointer/hour.png",

          minute_centerX: px(240), //指针旋转中心 对应centerX
          minute_centerY: px(240), //指针旋转中心 对应centerY
          minute_posX: px(35), //指针自身旋转中心 对应positioin中的x
          minute_posY: px(240), //指针自身旋转中心 对应positioin中的y
          minute_path: "images/pointer/min.png",

          second_centerX: px(240), //指针旋转中心 对应centerX
          second_centerY: px(240), //指针旋转中心 对应centerY
          second_posX: px(35), //指针自身旋转中心 对应positioin中的x
          second_posY: px(240), //指针自身旋转中心 对应positioin中的y
          second_path: "images/pointer/sec.png",

          show_level: hmUI.show_level.ONLY_NORMAL
        });

        let aod_timer_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_centerX: px(240), //指针旋转中心 对应centerX
          hour_centerY: px(240), //指针旋转中心 对应centerY
          hour_posX: px(35), //指针自身旋转中心 对应positioin中的x
          hour_posY: px(240), //指针自身旋转中心 对应positioin中的y
          hour_path: "images/pointer/hour_xp.png",

          minute_centerX: px(240), //指针旋转中心 对应centerX
          minute_centerY: px(240), //指针旋转中心 对应centerY
          minute_posX: px(35), //指针自身旋转中心 对应positioin中的x
          minute_posY: px(240), //指针自身旋转中心 对应positioin中的y
          minute_path: "images/pointer/min_xp.png",
          show_level: hmUI.show_level.ONLY_AOD

        });

        hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 12,
          y: 151,
          w: 161,
          h: 168,
          type: hmUI.data_type.HEART, //必写 跳转的action
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        //----------------------测试心率进度图代码------------------------
        // const text = hmUI.createWidget(hmUI.widget.TEXT, {
        //   x: 96,
        //   y: 220,
        //   w: 288,
        //   h: 46,
        //   color: 0xffff00,
        //   text_size: 36,
        //   align_h: hmUI.align.CENTER_H,
        //   align_v: hmUI.align.CENTER_V,
        //   text_style: hmUI.text_style.NONE,
        //   text: '切换背景'
        // });
        // let count = 1;
        // console.log(`2222222222222222222222`);
        // text.addEventListener(hmUI.event.CLICK_DOWN, (info) => {
        //   count++;
        //   console.log(`1111111111111111111`);
        //   if (count > 6) {
        //     count = 1
        //   }
        //   text.setProperty(hmUI.prop.MORE, {
        //     text: '切换背景'+ count
        //   })
        //   default_bg.setProperty(hmUI.prop.MORE, {
        //     src: arrryBG[count -1],
        //   });
        // });


      },
      onInit() {
        this.init_view();
      },
      onReady() {
        console.log('index page.js on ready invoke');
      },
      onShow() {
        console.log('index page.js on show invoke');
      },
      onHide() {
        console.log('index page.js on hide invoke');
      },
      onDestory() {
        console.log('index page.js on destory invoke');
      },
    });
    /*
     * end js
     */
  })();
} catch (e) { }
