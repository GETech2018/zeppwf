try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$component_0$_$component = '';
        let normal$_$component_1$_$component = '';
        const logger = Logger.getLogger('watchface6');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
                    edit_id: 1,
                    x: 0,
                    y: 0,
                    bg_config: [
                        {
                            'id': 1,
                            'path': '4.png',
                            'preview': '5.png'
                        },
                        {
                            'id': 2,
                            'path': '6.png',
                            'preview': '7.png'
                        }
                    ],
                    count: 2,
                    default_id: 1,
                    fg: '3.png',
                    tips_x: 129,
                    tips_y: 217,
                    tips_bg: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    day_startX: 212,
                    day_startY: 363,
                    day_sc_array: [
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png'
                    ],
                    day_tc_array: [
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png'
                    ],
                    day_en_array: [
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png'
                    ],
                    day_align: hmUI.align.LEFT,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: -9,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: '18.png',
                    center_x: 227,
                    center_y: 331,
                    x: 14,
                    y: 59,
                    type: hmUI.data_type.BATTERY,
                    start_angle: -151,
                    end_angle: 149,
                    cover_x: 0,
                    cover_y: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 177,
                    hour_startY: 128,
                    hour_array: [
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png'
                    ],
                    hour_space: -8,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 229,
                    minute_startY: 128,
                    minute_array: [
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png'
                    ],
                    minute_space: -8,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$component_0$_$component = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: 2,
                    x: 257,
                    y: 159,
                    w: 145,
                    h: 145,
                    select_image: '39.png',
                    un_select_image: '40.png',
                    default_type: hmUI.edit_type.TEMPERATURE,
                    optional_types: [
                        {
                            'type': hmUI.edit_type.TEMPERATURE,
                            'preview': '42.png'
                        },
                        {
                            'type': hmUI.edit_type.HEART,
                            'preview': '43.png'
                        }
                    ],
                    count: 2,
                    tips_BG: '41.png',
                    tips_x: 22,
                    tips_y: -37,
                    tips_width: 0,
                    tips_margin: 0
                });
                editType = normal$_$component_0$_$component.getProperty(hmUI.prop.CURRENT_TYPE);
                switch (editType) {
                case hmUI.edit_type.STEP:
                    break;
                case hmUI.edit_type.BATTERY:
                    break;
                case hmUI.edit_type.HEART:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 309,
                        y: 251,
                        type: hmUI.data_type.HEART,
                        font_array: [
                            '44.png',
                            '45.png',
                            '46.png',
                            '47.png',
                            '48.png',
                            '49.png',
                            '50.png',
                            '51.png',
                            '52.png',
                            '53.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -9,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '54.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 319,
                        y: 193,
                        src: '55.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                        src: '56.png',
                        center_x: 329,
                        center_y: 233,
                        x: 12,
                        y: 59,
                        type: hmUI.data_type.HEART,
                        start_angle: -120,
                        end_angle: 117,
                        cover_x: 0,
                        cover_y: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.CAL:
                    break;
                case hmUI.edit_type.PAI_DAILY:
                    break;
                case hmUI.edit_type.DISTANCE:
                    break;
                case hmUI.edit_type.AQI:
                    break;
                case hmUI.edit_type.HUMIDITY:
                    break;
                case hmUI.edit_type.ALTIMETER:
                    break;
                case hmUI.edit_type.STRESS:
                    break;
                case hmUI.edit_type.WIND:
                    break;
                case hmUI.edit_type.SPO2:
                    break;
                case hmUI.edit_type.TRAINING_LOAD:
                    break;
                case hmUI.edit_type.VO2MAX:
                    break;
                case hmUI.edit_type.UVI:
                    break;
                case hmUI.edit_type.DATE:
                    break;
                case hmUI.edit_type.WEEK:
                    break;
                case hmUI.edit_type.WEATHER:
                    break;
                case hmUI.edit_type.TEMPERATURE:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 309,
                        y: 251,
                        type: hmUI.data_type.WEATHER_CURRENT,
                        font_array: [
                            '57.png',
                            '58.png',
                            '59.png',
                            '60.png',
                            '61.png',
                            '62.png',
                            '63.png',
                            '64.png',
                            '65.png',
                            '66.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -9,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        unit_sc: '69.png',
                        unit_tc: '69.png',
                        unit_en: '69.png',
                        negative_image: '68.png',
                        invalid_image: '67.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 325,
                        y: 193,
                        src: '70.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                        src: '71.png',
                        center_x: 329,
                        center_y: 233,
                        x: 12,
                        y: 59,
                        type: hmUI.data_type.WEATHER_CURRENT,
                        start_angle: -120,
                        end_angle: 117,
                        cover_x: 0,
                        cover_y: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.SUN:
                    break;
                }
                normal$_$component_1$_$component = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: 3,
                    x: 53,
                    y: 159,
                    w: 145,
                    h: 145,
                    select_image: '72.png',
                    un_select_image: '73.png',
                    default_type: hmUI.edit_type.STEP,
                    optional_types: [
                        {
                            'type': hmUI.edit_type.STEP,
                            'preview': '75.png'
                        },
                        {
                            'type': hmUI.edit_type.PAI_DAILY,
                            'preview': '76.png'
                        }
                    ],
                    count: 2,
                    tips_BG: '74.png',
                    tips_x: 21,
                    tips_y: -37,
                    tips_width: 0,
                    tips_margin: 0
                });
                editType = normal$_$component_1$_$component.getProperty(hmUI.prop.CURRENT_TYPE);
                switch (editType) {
                case hmUI.edit_type.STEP:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 93,
                        y: 251,
                        type: hmUI.data_type.STEP,
                        font_array: [
                            '77.png',
                            '78.png',
                            '79.png',
                            '80.png',
                            '81.png',
                            '82.png',
                            '83.png',
                            '84.png',
                            '85.png',
                            '86.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -9,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '87.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 115,
                        y: 193,
                        src: '88.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                        src: '89.png',
                        center_x: 124,
                        center_y: 232,
                        x: 12,
                        y: 59,
                        type: hmUI.data_type.STEP,
                        start_angle: -121,
                        end_angle: 117,
                        cover_x: 0,
                        cover_y: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.BATTERY:
                    break;
                case hmUI.edit_type.HEART:
                    break;
                case hmUI.edit_type.CAL:
                    break;
                case hmUI.edit_type.PAI_DAILY:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 105,
                        y: 251,
                        type: hmUI.data_type.PAI_DAILY,
                        font_array: [
                            '90.png',
                            '91.png',
                            '92.png',
                            '93.png',
                            '94.png',
                            '95.png',
                            '96.png',
                            '97.png',
                            '98.png',
                            '99.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -9,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '100.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 113,
                        y: 193,
                        src: '101.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                        src: '102.png',
                        center_x: 124,
                        center_y: 232,
                        x: 12,
                        y: 59,
                        type: hmUI.data_type.PAI_DAILY,
                        start_angle: -121,
                        end_angle: 117,
                        cover_x: 0,
                        cover_y: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.DISTANCE:
                    break;
                case hmUI.edit_type.AQI:
                    break;
                case hmUI.edit_type.HUMIDITY:
                    break;
                case hmUI.edit_type.ALTIMETER:
                    break;
                case hmUI.edit_type.STRESS:
                    break;
                case hmUI.edit_type.WIND:
                    break;
                case hmUI.edit_type.SPO2:
                    break;
                case hmUI.edit_type.TRAINING_LOAD:
                    break;
                case hmUI.edit_type.VO2MAX:
                    break;
                case hmUI.edit_type.UVI:
                    break;
                case hmUI.edit_type.DATE:
                    break;
                case hmUI.edit_type.WEEK:
                    break;
                case hmUI.edit_type.WEATHER:
                    break;
                case hmUI.edit_type.TEMPERATURE:
                    break;
                case hmUI.edit_type.SUN:
                    break;
                }
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 227,
                    hour_centerY: 227,
                    hour_posX: 23,
                    hour_posY: 208,
                    hour_path: '103.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 227,
                    minute_centerY: 227,
                    minute_posX: 23,
                    minute_posY: 208,
                    minute_path: '104.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    second_centerX: 227,
                    second_centerY: 227,
                    second_posX: 17,
                    second_posY: 239,
                    second_path: '105.png',
                    second_cover_x: 0,
                    second_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
                    x: 0,
                    y: 0,
                    w: 454,
                    h: 454,
                    src: '106.png',
                    show_level: hmUI.show_level.ONLY_EDIT
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 454,
                    h: 454,
                    src: '107.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 177,
                    hour_startY: 128,
                    hour_array: [
                        '108.png',
                        '109.png',
                        '110.png',
                        '111.png',
                        '112.png',
                        '113.png',
                        '114.png',
                        '115.png',
                        '116.png',
                        '117.png'
                    ],
                    hour_space: -8,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 229,
                    minute_startY: 128,
                    minute_array: [
                        '118.png',
                        '119.png',
                        '120.png',
                        '121.png',
                        '122.png',
                        '123.png',
                        '124.png',
                        '125.png',
                        '126.png',
                        '127.png'
                    ],
                    minute_space: -6,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 227,
                    hour_centerY: 227,
                    hour_posX: 23,
                    hour_posY: 208,
                    hour_path: '128.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 227,
                    minute_centerY: 227,
                    minute_posX: 23,
                    minute_posY: 208,
                    minute_path: '129.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}