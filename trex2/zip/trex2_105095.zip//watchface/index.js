
    /*
    ** huamiOS bundle tool v1.0.17
    * *huamiOS watchface js version v1.0.1
    * *Copyright © Huami. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start
        let normal$_$background$_$bg = ''
        let normal$_$digital_clock$_$img_time = ''
        let normal$_$date$_$img_date = ''
        let normal$_$week$_$week = ''
        let normal$_$weather$_$image_progress$_$img_level = ''
        let normal$_$temperature$_$current$_$text_img = ''
        let normal$_$heart_rate$_$text$_$text_img = ''
        let normal$_$heart_rate$_$image_progress$_$img_progress = ''
        let normal$_$calorie$_$current$_$text_img = ''
        let normal$_$calorie$_$image_progress$_$img_level = ''
        let normal$_$step$_$current$_$text_img = ''
        let normal$_$step$_$image_progress$_$img_level = ''
        let normal$_$system$_$disconnect$_$img = ''
        let normal$_$system$_$dnd$_$img = ''
        let normal$_$system$_$lock$_$img = ''
        let normal$_$system$_$clock$_$img = ''
        let idle$_$digital_clock$_$img_time = ''
        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            normal$_$background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$digital_clock$_$img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_zero: 1,
              hour_startX: 127,
              hour_startY: 70,
              hour_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              hour_space: 5,
              hour_align: hmUI.align.CENTER_H,
              minute_zero: 1,
              minute_startX: 283,
              minute_startY: 72,
              minute_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              minute_space: 4,
              minute_align: hmUI.align.CENTER_H,
              minute_follow: 0,
              am_x: 284,
              am_y: 117,
              am_en_path: '22.png',
              pm_x: 284,
              pm_y: 117,
              pm_en_path: '23.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$date$_$img_date = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 37,
              month_startY: 227,
              month_sc_array: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png"],
              month_en_array: ["36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
              month_align: hmUI.align.LEFT,
              month_zero: 0,
              month_follow: 0,
              month_space: 0,
              month_is_character: true,
              day_startX: 204,
              day_startY: 154,
              day_sc_array: ["48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png","57.png"],
              day_tc_array: ["48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png","57.png"],
              day_en_array: ["48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png","57.png"],
              day_align: hmUI.align.CENTER_H,
              day_zero: 1,
              day_follow: 0,
              day_space: 3,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$week$_$week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 80,
              y: 196,
              week_en: ["58.png","59.png","60.png","61.png","62.png","63.png","64.png"],
              week_sc: ["65.png","66.png","67.png","68.png","69.png","70.png","71.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$weather$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 370,
              y: 138,
              image_array: ["72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png","93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$temperature$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 368,
              y: 113,
              type: hmUI.data_type.WEATHER_CURRENT,
              font_array: ["101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png","110.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 2,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: '113.png',//单位
              unit_en: '114.png',//单位
              negative_image: '112.png', //负号图片
              invalid_image: '111.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$heart_rate$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 285,
              y: 337,
              type: hmUI.data_type.HEART,
              font_array: ["115.png","116.png","117.png","118.png","119.png","120.png","121.png","122.png","123.png","124.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: '125.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$heart_rate$_$image_progress$_$img_progress = hmUI.createWidget(hmUI.widget.IMG_PROGRESS, {
              x: [266,266,266,266,266,266,266,266,266,266],
              y: [308,308,308,308,308,308,308,308,308,308],
              image_array: ["126.png","127.png","128.png","129.png","130.png","131.png","132.png","133.png","134.png","135.png"],
              image_length: 10,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$calorie$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 131,
              y: 337,
              type: hmUI.data_type.CAL,
              font_array: ["115.png","116.png","117.png","118.png","119.png","120.png","121.png","122.png","123.png","124.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: '136.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$calorie$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 119,
              y: 308,
              image_array: ["137.png","138.png","139.png","140.png","141.png","142.png","143.png","144.png","145.png","146.png"],
              image_length: 10,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$step$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 200,
              y: 367,
              type: hmUI.data_type.STEP,
              font_array: ["115.png","116.png","117.png","118.png","119.png","120.png","121.png","122.png","123.png","124.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: '147.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$step$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 191,
              y: 308,
              image_array: ["148.png","149.png","150.png","151.png","152.png","153.png","154.png","155.png","156.png","157.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$system$_$disconnect$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 151,
              y: 408,
              src: '158.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$system$_$dnd$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 151,
              y: 408,
              src: '159.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$system$_$lock$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 151,
              y: 408,
              src: '160.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$system$_$clock$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 72,
              y: 90,
              src: '161.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            idle$_$digital_clock$_$img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_zero: 1,
              hour_startX: 127,
              hour_startY: 70,
              hour_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              hour_space: 5,
              hour_align: hmUI.align.CENTER_H,
              minute_zero: 1,
              minute_startX: 283,
              minute_startY: 72,
              minute_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              minute_space: 4,
              minute_align: hmUI.align.CENTER_H,
              minute_follow: 0,
              am_x: 284,
              am_y: 117,
              am_en_path: '162.png',
              pm_x: 284,
              pm_y: 117,
              pm_en_path: '163.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  