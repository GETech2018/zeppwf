try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_c7af3c9ea8594fb996e377c4da3229d5 = '';
        let dateFormat = '';
        let dateFormatMap = '';
        let normal$_$text_90eb8936d143488a91bad1990739aecd = '';
        let idle$_$text_1810f6e42b004a8abf0182fe193dfb35 = '';
        let timeSensor = '';
        let stepSensor = '';
        const logger = Logger.getLogger('watchface6');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                normal$_$text_c7af3c9ea8594fb996e377c4da3229d5 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 131,
                    y: 88,
                    w: 200,
                    h: 50,
                    text: '[DAY_Z]/[MON_Z] [WEEK_EN_S]',
                    color: '0xFFffffff',
                    text_size: 40,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_90eb8936d143488a91bad1990739aecd = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 127,
                    y: 295,
                    w: 200,
                    h: 70,
                    text: '[SC]',
                    color: '0xFFffffff',
                    text_size: 60,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 227,
                    hour_centerY: 227,
                    hour_posX: 38,
                    hour_posY: 227,
                    hour_path: '2.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 227,
                    minute_centerY: 227,
                    minute_posX: 38,
                    minute_posY: 227,
                    minute_path: '3.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                idle$_$text_1810f6e42b004a8abf0182fe193dfb35 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 124,
                    y: 202,
                    w: 200,
                    h: 50,
                    text: '[HOUR_24_Z]:[MIN_Z]',
                    color: '0xFFffffff',
                    text_size: 40,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                if (!timeSensor) {
                    timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                }
                if (!stepSensor) {
                    stepSensor = hmSensor.createSensor(hmSensor.id.STEP);
                }
                timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_c7af3c9ea8594fb996e377c4da3229d5.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }/${ String(timeSensor.day).padStart(2, '0') } ${ WEEK_EN_S(timeSensor.week) }` });
                        },
                        () => {
                            normal$_$text_c7af3c9ea8594fb996e377c4da3229d5.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }/${ String(timeSensor.month).padStart(2, '0') } ${ WEEK_EN_S(timeSensor.week) }` });
                        },
                        () => {
                            normal$_$text_c7af3c9ea8594fb996e377c4da3229d5.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }/${ String(timeSensor.day).padStart(2, '0') } ${ WEEK_EN_S(timeSensor.week) }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                    const WEEK_EN_S = function (val) {
                        const valueMap = {
                            '1': 'Mon',
                            '2': 'Tue',
                            '3': 'Wed',
                            '4': 'Thu',
                            '5': 'Fri',
                            '6': 'Sat',
                            '7': 'Sun'
                        };
                        return valueMap[val];
                    };
                }), stepSensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_90eb8936d143488a91bad1990739aecd.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                }), timeSensor.addEventListener(timeSensor.event.MINUTEEND, function () {
                    idle$_$text_1810f6e42b004a8abf0182fe193dfb35.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }:${ String(timeSensor.minute).padStart(2, '0') }` });
                });
                idle$_$text_1810f6e42b004a8abf0182fe193dfb35.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }:${ String(timeSensor.minute).padStart(2, '0') }` });
                timer.createTimer(0, 1000, function (timeSensor2) {
                    idle$_$text_1810f6e42b004a8abf0182fe193dfb35.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor2.hour).padStart(2, '0') }:${ String(timeSensor2.minute).padStart(2, '0') }` });
                }, timeSensor);
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        const WEEK_EN_S = function (val) {
                            const valueMap = {
                                '1': 'Mon',
                                '2': 'Tue',
                                '3': 'Wed',
                                '4': 'Thu',
                                '5': 'Fri',
                                '6': 'Sat',
                                '7': 'Sun'
                            };
                            return valueMap[val];
                        };
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                normal$_$text_c7af3c9ea8594fb996e377c4da3229d5.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }/${ String(timeSensor.day).padStart(2, '0') } ${ WEEK_EN_S(timeSensor.week) }` });
                            },
                            () => {
                                normal$_$text_c7af3c9ea8594fb996e377c4da3229d5.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }/${ String(timeSensor.month).padStart(2, '0') } ${ WEEK_EN_S(timeSensor.week) }` });
                            },
                            () => {
                                normal$_$text_c7af3c9ea8594fb996e377c4da3229d5.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }/${ String(timeSensor.day).padStart(2, '0') } ${ WEEK_EN_S(timeSensor.week) }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                        normal$_$text_90eb8936d143488a91bad1990739aecd.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                        idle$_$text_1810f6e42b004a8abf0182fe193dfb35.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }:${ String(timeSensor.minute).padStart(2, '0') }` });
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}