
try {
  (() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__),
      "drink"
    );
    /*
     * huamiOS bundle tool v1.0.17
     * Copyright © Huami. All Rights Reserved
     */
    ("use strict");
    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);
    const logger = DeviceRuntimeCore.HmLogger.getLogger("ageset");
    function px(num) {
      return num * (454 / 454);   //teide
      // return num * (466 / 454);  //berlin
      // return num * (416 / 454);  //vienna
    }
    let SBname = `teide/`;
    // let SBname = `vienna/`;
    // let SBname = `berlin/`;
    /**
     * 1004402     000F5372 （466*466 berlin）
       1007511     000F5F97（454*454）
       1007512     000F5F98（416*416））
     */

    let language = null;
    let week = null;
    let date = null;
    let dateEn = null;
    let arrBat = [];
    let arrTime = [];
    let arrDate = [];
    let arrWeeken = [];
    let arrWeeksc = [];
    let i = 0;
    let j = 1;

    for (; i < 10; i++) {
      arrBat.push(`images/` + SBname + `data/` + i + `.png`);
      arrTime.push(`images/` + SBname + `time/` + i + `.png`);
      arrDate.push(`images/` + SBname + `date/` + i + `.png`);
    }
    for (; j < 8; j++) {
      arrWeeken.push(`images/` + SBname + `week/en/` + j + `.png`);
      arrWeeksc.push(`images/` + SBname + `week/sc/` + j + `.png`);
    }
    // let objBg = {
    //   x: 0,
    //   y: 0,
    //   src: "images/qy_0.png",
    //   show_level: hmUI.show_level.ONLY_NORMAL
    // };
    let objAnim = {
      x: 0,
      y: 0,
      anim_path: "images/" + SBname + "anim", //必须从0开始 可以询问君成 张莉
      anim_prefix: "qy",
      anim_ext: "png",
      anim_fps: 10,
      anim_size: 50,
      repeat_count: 1, //0位无限重复
      anim_repeat: true,//是否重复
      anim_status: hmUI.anim_status.START,
      // display_on_restart: false,//从息屏到亮屏是否自动重复播放
      show_level: hmUI.show_level.ONLY_NORMAL
    };
    let objBattery = {
      x: 0,
      y: px(115),
      w: px(454),
      icon: `images/` + SBname + `icon/bat.png`,
      icon_space: 3,
      type: hmUI.data_type.BATTERY,
      font_array: arrBat,
      h_space: 2,
      align_h: hmUI.align.CENTER_H,
      unit_sc: `images/` + SBname + `data/dot.png`,
      unit_tc: `images/` + SBname + `data/dot.png`,
      unit_en: `images/` + SBname + `data/dot.png`,
      show_level: hmUI.show_level.ONLY_NORMAL
    };
    let objStep = {
      x: 0,
      y: px(350),
      w: px(454),
      icon: `images/` + SBname + `icon/step.png`,
      icon_space: 5,
      type: hmUI.data_type.STEP,
      font_array: arrBat,
      h_space: 2,
      align_h: hmUI.align.CENTER_H,
      show_level: hmUI.show_level.ONLY_NORMAL
    };
    let objTime = {
      hour_zero: 1, //是否补零
      hour_startX: px(104),
      hour_startY: px(154),
      hour_array: arrTime,
      hour_space: 4, //每个数组间的间隔
      hour_align: hmUI.align.LEFT,

      minute_zero: 1, //是否补零
      minute_startX: px(241),
      minute_startY: px(154),
      minute_array: arrTime,
      minute_space: 4, //每个数组间的间隔
      minute_align: hmUI.align.LEFT,
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD
    };
    let objTimeUnit = {
      x: px(211),
      y: px(132),
      src: `images/` + SBname + `time/dot.png`,
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD
    };
    let objDate = { //中文下
      month_startX: px(128),
      month_startY: px(270),
      month_unit_sc: `images/` + SBname + `date/dot.png`, //单位
      month_unit_tc: `images/` + SBname + `date/dot.png`,
      month_unit_en: `images/` + SBname + `date/dot.png`,
      month_align: hmUI.align.LEFT,
      month_space: 1,//文字间隔
      month_zero: 1,//是否补零
      // month_follow: 1,//是否跟随
      month_en_array: arrDate,
      month_sc_array: arrDate,
      month_tc_array: arrDate,

      day_align: hmUI.align.LEFT,
      day_space: 1,//文字间隔
      day_zero: 1,//是否补零
      day_follow: 1,//是否跟随
      day_en_array: arrDate,
      day_sc_array: arrDate,
      day_tc_array: arrDate,
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD
    };
    let objDateEn = {
      ...objDate,
      month_startX: px(146),
    };
    let objWeek = {
      x: px(236),
      y: px(270),
      week_en: arrWeeken,
      week_tc: arrWeeksc,
      week_sc: arrWeeksc,
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD
    };

    let stepJump = {
      x: px(173),
      y: px(342),
      w: px(110),
      h: px(41),
      type: hmUI.data_type.STEP, //必写 跳转的action
      show_level: hmUI.show_level.ONLY_NORMAL
    };
    let batJump = {
      x: px(173),
      y: px(110),
      w: px(110),
      h: px(41),
      type: hmUI.data_type.BATTERY, //必写 跳转的action
      show_level: hmUI.show_level.ONLY_NORMAL
    };

    function getLanguage() { //获取不同语言 
      language = hmSetting.getLanguage();
      if (language == 1 || language == 0) { //中文  
        dateEn.setProperty(hmUI.prop.VISIBLE, false);
        date.setProperty(hmUI.prop.VISIBLE, true);
        week.setProperty(hmUI.prop.MORE, {  //设置中文下周的位置
          x: px(236),
        });
      } else {  //非中文       
        date.setProperty(hmUI.prop.VISIBLE, false);
        dateEn.setProperty(hmUI.prop.VISIBLE, true);
        week.setProperty(hmUI.prop.MORE, {  //设置中文下周的位置
          x: px(250),
        });
      }
    }

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        // hmUI.createWidget(hmUI.widget.IMG, objBg);
        hmUI.createWidget(hmUI.widget.IMG_ANIM, objAnim);
        hmUI.createWidget(hmUI.widget.TEXT_IMG, objBattery);
        hmUI.createWidget(hmUI.widget.TEXT_IMG, objStep);
        hmUI.createWidget(hmUI.widget.IMG, objTimeUnit);
        hmUI.createWidget(hmUI.widget.IMG_TIME, objTime);
        date = hmUI.createWidget(hmUI.widget.IMG_DATE, objDate);
        dateEn = hmUI.createWidget(hmUI.widget.IMG_DATE, objDateEn);
        week = hmUI.createWidget(hmUI.widget.IMG_WEEK, objWeek);
        date.setProperty(hmUI.prop.VISIBLE, false);
        dateEn.setProperty(hmUI.prop.VISIBLE, false);
        getLanguage();
        hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: (function () {
            getLanguage();
          }),
          pause_call: (function () {
            console.log('ui pause');
          }),
        });

        hmUI.createWidget(hmUI.widget.IMG_CLICK, stepJump);
        hmUI.createWidget(hmUI.widget.IMG_CLICK, batJump);
      },
      onInit() {
        console.log("index page.js on init invoke");
        this.init_view();
      },
      onReady() {
        console.log("index page.js on ready invoke");
      },
      onShow() {
        console.log("index page.js on show invoke");
      },
      onHide() {
        console.log("index page.js on hide invoke");
      },
      onDestory() {
        console.log("index page.js on destory invoke");
      },
    });
    /*
     * end js
     */
  })();
} catch (e) {
  console.log(e);
}
