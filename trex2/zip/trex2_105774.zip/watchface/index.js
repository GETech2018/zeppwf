try {
  (() => {

    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

    /*
  * huamiOS bundle tool v1.0.17
  * Copyright © Huami. All Rights Reserved
  */
    'use strict';

    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);
    const arrDate = [];
    const arrFont = [];
    const arrFont1 = [];
    const arrHour = [];
    const arrHeart = [];
    const arrMinute = [];
    const arrMonth = [];
    const arrSecond = [];
    const arrSteps = [];
    const arrWeather = [];
    const arrWeek = [];
    for (let i = 0; i < 10; i++) {
      arrDate.push(`images/date/${i}.png`)
      arrFont.push(`images/font/${i}.png`)
      arrFont1.push(`images/font1/${i}.png`)
      arrHour.push(`images/h/${i}.png`)
      arrHeart.push(`images/heart/${i}.png`)
      arrMinute.push(`images/m/${i}.png`)
      arrSecond.push(`images/s/${i}.png`)
    }
    for (let i = 1; i < 13; i++) {
      arrMonth.push(`images/month/${i}.png`)
    }
    for (let i = 1; i < 11; i++) {
      arrSteps.push(`images/steps/${i}.png`)
    }
    for (let i = 1; i < 8; i++) {
      arrWeek.push(`images/week/${i}.png`)
    }
    for (let i = 0; i < 29; i++) {
      arrWeather.push(`images/weather/${i}.png`)
    }
    let nPosMonthX = 90 //
    let nPosMonthY = 98 //
    let nPosDayX = 158 //
    let nPosDayY = 92 //
    let nSpace = 0
    let nPosHourX = 32
    let nPosHourY = 188 //
    let nPosMinuteX = 138  //  
    let nPosAmPmX = 240 //
    let nPosAmPmY = 98  //
    let nPosAmPmAodX = 238
    let nPosAmPmAodY = 175
    let nPosSecondX = 252  //
    let nPosSecondY = 188 // 
    let objDate = {
      month_startX: nPosMonthX,
      month_startY: nPosMonthY,
      month_en_array: arrMonth,
      month_align: hmUI.align.LEFT,
      month_is_character: true,
      day_startX: nPosDayX,
      day_startY: nPosDayY,
      day_zero: true,
      day_en_array: arrDate,
      day_space: nSpace + 1,
      day_align: hmUI.align.LEFT,
      show_level: hmUI.show_level.ONLY_NORMAL
    }
    let objTimeHM = {
      hour_zero: true,
      hour_startX: nPosHourX,
      hour_startY: nPosHourY,
      hour_array: arrHour,
      hour_space: nSpace + 6,
      hour_align: hmUI.align.LEFT,
      minute_startX: nPosMinuteX,
      minute_startY: nPosHourY,
      minute_zero: true,
      minute_follow: false,
      minute_array: arrMinute,
      minute_space: nSpace + 6,
      minute_align: hmUI.align.LEFT,
      show_level: hmUI.show_level.ALL,
    }
    let objTimeAPS = {
      am_x: nPosAmPmX,
      am_y: nPosAmPmY,
      am_sc_path: "images/ap/am.png",
      am_en_path: "images/ap/am.png",
      pm_x: nPosAmPmX,
      pm_y: nPosAmPmY,
      pm_sc_path: "images/ap/pm.png",
      pm_en_path: "images/ap/pm.png",
      second_zero: true,
      second_startX: nPosSecondX,
      second_startY: nPosSecondY,
      second_array: arrSecond,
      second_space: nSpace - 2,
      second_align: hmUI.align.LEFT,
      show_level: hmUI.show_level.ONLY_NORMAL,
    }
    let objTimeAPSAod = {
      am_x: nPosAmPmAodX,
      am_y: nPosAmPmAodY,
      am_sc_path: "images/ap/xpam.png",
      am_en_path: "images/ap/xpam.png",
      pm_x: nPosAmPmAodX,
      pm_y: nPosAmPmAodY,
      pm_sc_path: "images/ap/xppm.png",
      pm_en_path: "images/ap/xppm.png",
      show_level: hmUI.show_level.ONAL_AOD,
    }
    function fnSetBgImg(nWidth, nHeight, strImg, showType) {
      hmUI.createWidget(hmUI.widget.IMG, {
        x: 0,
        y: 0,
        w: nWidth,
        h: nHeight,
        src: strImg,
        show_level: showType
      })
    }
    //高低温跟随
    function fnGetTemperature(xPos, yPos, groupType, strUnit) {
      let objTemperature = {
        x: xPos,
        y: yPos,
        type: groupType,
        font_array: arrFont1,
        unit_sc: strUnit,
        unit_en: strUnit,
        unit_tc: strUnit,
        negative_image: "images/font1/fuhao.png",
        invalid_image: "images/font/none.png",
        show_level: hmUI.show_level.ONLY_NORMAL
      }
      if (groupType == hmUI.data_type.WEATHER_HIGH) {
        objTemperature.invalid_image = "images/font1/none2.png"
      }
      return hmUI.createWidget(hmUI.widget.TEXT_IMG, objTemperature);
    }
    function fnGroupText(xPos, yPos, groupType, align = hmUI.align.CENTER_H, arrGroupFont = arrFont) {
      let objText = {
        x: xPos,
        y: yPos,
        w: 150,
        type: groupType,
        font_array: arrGroupFont,
        h_space: -2,
        align_h: align,
        unit_sc: "images/font/baifenhao.png",
        unit_tc: "images/font/baifenhao.png",
        unit_en: "images/font/baifenhao.png",
        dot_image: "images/font/dian.png",
        invalid_image: "images/font/none.png",
        padding: false,
        show_level: hmUI.show_level.ONLY_NORMAL
      }
      if (groupType != hmUI.data_type.BATTERY && groupType != hmUI.data_type.HUMIDITY) {
        delete objText['unit_sc']
        delete objText['unit_tc']
        delete objText['unit_en']
      }
      if (groupType == hmUI.data_type.BATTERY || groupType == hmUI.data_type.PAI_DAILY || groupType == hmUI.data_type.CAL || groupType == hmUI.data_type.STEP) {
        delete objText['invalid_image']
      }
      if (groupType != hmUI.data_type.SUN_RISE && groupType != hmUI.data_type.SUN_SET && groupType != hmUI.data_type.DISTANCE) {
        delete objText['dot_image']
      }
      if (groupType == hmUI.data_type.SUN_RISE || groupType == hmUI.data_type.SUN_SET) {
        objText.dot_image = "images/font1/maohao.png"
      }
      hmUI.createWidget(hmUI.widget.TEXT_IMG, objText);
    }
    function fnState(xPos, groupType, imgPath) {
      hmUI.createWidget(hmUI.widget.IMG_STATUS, { x: xPos, y: 118, type: groupType, src: imgPath, show_level: hmUI.show_level.ONLY_NORMAL });
    }
    function fnImgLevel(nPosX, nPosY, arrData, dataType, bShow = hmUI.show_level.ONLY_NORMAL) {
      hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
        x: nPosX,
        y: nPosY,
        image_array: arrData,
        image_length: arrData.length,
        type: dataType,
        show_level: bShow,
      })
    }
    class Time {
      createImgTextTime(option) {
        this.widget = hmUI.createWidget(hmUI.widget.IMG_TIME, option);
      }
      createImgWeek(nPosX, nPosY, arrWeek, bShow = hmUI.show_level.ONLY_NORMAL) {
        this.widget = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
          x: nPosX,
          y: nPosY,
          week_tc: arrWeek,
          week_sc: arrWeek,
          week_en: arrWeek,
          show_level: bShow,
        });
      }
      createImgDate(option) {
        this.widget = hmUI.createWidget(hmUI.widget.IMG_DATE, option);
      }
    }
    const logger = DeviceRuntimeCore.HmLogger.getLogger("defult");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        const timeText = new Time();
        fnSetBgImg(416, 416, "images/bg.png", hmUI.show_level.ONLY_NORMAL);
        timeText.createImgWeek(90, 130, arrWeek);
        timeText.createImgDate(objDate);
        timeText.createImgTextTime(objTimeHM);
        timeText.createImgTextTime(objTimeAPS);
        timeText.createImgTextTime(objTimeAPSAod);
        fnGroupText(67, 58, hmUI.data_type.PAI_WEEKLY);
        fnGroupText(148, 25, hmUI.data_type.BATTERY);
        fnGroupText(235, 58, hmUI.data_type.CAL);

        fnGroupText(78, 301, hmUI.data_type.STEP, hmUI.align.LEFT);
        fnGroupText(212, 301, hmUI.data_type.DISTANCE, hmUI.align.LEFT);
        fnGroupText(340, 301, hmUI.data_type.HUMIDITY, hmUI.align.LEFT);

        fnGroupText(76, 396, hmUI.data_type.UVI);
        fnGroupText(150, 396, hmUI.data_type.HEART, hmUI.align.CENTER_H, arrHeart);
        fnGroupText(226, 396, hmUI.data_type.AQI);

        fnGroupText(360, 219, hmUI.data_type.SUN_RISE, hmUI.align.LEFT, arrFont1);
        fnGroupText(360, 265, hmUI.data_type.SUN_SET, hmUI.align.LEFT, arrFont1);
        fnImgLevel(320, 172, arrWeather, hmUI.data_type.WEATHER);
        fnImgLevel(56, 349, arrSteps, hmUI.data_type.STEP);  //                   
        var weatherLow = fnGetTemperature(360, 182, hmUI.data_type.WEATHER_LOW, "images/font1/fenhao.png");
        var weatherHigh = fnGetTemperature(383, 182, hmUI.data_type.WEATHER_HIGH, "images/font1/du.png");
        weatherHigh.layoutChange(function (obj) {
          var end_X = weatherLow.getProperty(hmUI.prop.END_X);
          weatherHigh.setProperty(hmUI.prop.X, end_X);
        });
        fnState(49, hmUI.system_status.DISTURB, "images/disturb.png");     
        fnState(375, hmUI.system_status.CLOCK, "images/alarm.png")
      },

      onInit() {
        console.log('index page.js on init invoke');

        this.init_view();


      },

      onReady() {
        console.log('index page.js on ready invoke')
      },

      onShow() {
        console.log('index page.js on show invoke')
      },

      onHide() {
        console.log('index page.js on hide invoke')
      },

      onDestory() {
        console.log('index page.js on destory invoke')
      },
    });
    /*
    * end js
    */
  })()
} catch (e) {
  console.log(e)
}