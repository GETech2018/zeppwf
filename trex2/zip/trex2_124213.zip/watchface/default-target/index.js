try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$lunar$_$festival_or_solar_term = '';
        let normal$_$lunar$_$lunar_date = '';
        let timeSensor = '';
        let lunarText = '';
        let lunar_month = '';
        let lunar_day = '';
        let festival = '';
        let normal$_$temperature$_$low$_$text_img = '';
        let normal$_$temperature$_$high$_$text_img = '';
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 454,
                    h: 454,
                    src: '4.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$lunar$_$festival_or_solar_term = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 233,
                    y: 182,
                    w: 170,
                    h: 20,
                    text: '',
                    color: '0xFFCECECE',
                    text_size: 13,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$lunar$_$lunar_date = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 233,
                    y: 133,
                    w: 70,
                    h: 26,
                    text: '',
                    color: '0xFFCECECE',
                    text_size: 16,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                function isVoid(value) {
                    return value === 'INVALID';
                }
                function getLunarText() {
                    lunar_month = timeSensor.lunar_month;
                    lunar_day = timeSensor.lunar_day;
                    festival = timeSensor.getShowFestival();
                    festival = isVoid(festival) ? '' : festival;
                    if (!isVoid(lunar_month)) {
                        if (lunar_month.indexOf('闰') > -1) {
                            lunarText = lunar_month;
                        } else if (!isVoid(lunar_day)) {
                            lunarText = lunar_month + lunar_day;
                        }
                    }
                    normal$_$lunar$_$lunar_date.setProperty(hmUI.prop.MORE, { text: lunarText });
                    normal$_$lunar$_$festival_or_solar_term.setProperty(hmUI.prop.MORE, { text: festival });
                }
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 275,
                    y: 348,
                    type: hmUI.data_type.STEP,
                    font_array: [
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 267,
                    y: 326,
                    src: '15.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$temperature$_$low$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 308,
                    y: 101,
                    type: hmUI.data_type.WEATHER_LOW,
                    font_array: [
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '28.png',
                    unit_tc: '28.png',
                    unit_en: '28.png',
                    negative_image: '27.png',
                    invalid_image: '26.png',
                    padding: false,
                    isCharacter: false
                });
                normal$_$temperature$_$high$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 0,
                    y: 0,
                    type: hmUI.data_type.WEATHER_HIGH,
                    font_array: [
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png'
                    ],
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '31.png',
                    unit_tc: '31.png',
                    unit_en: '31.png',
                    negative_image: '30.png',
                    invalid_image: '29.png',
                    padding: false,
                    isCharacter: false
                });
                normal$_$temperature$_$low$_$text_img.layoutChange(function (obj) {
                    const end_X = normal$_$temperature$_$low$_$text_img.getProperty(hmUI.prop.END_X);
                    const y = normal$_$temperature$_$low$_$text_img.getProperty(hmUI.prop.Y);
                    normal$_$temperature$_$high$_$text_img.setProperty(hmUI.prop.X, end_X);
                    normal$_$temperature$_$high$_$text_img.setProperty(hmUI.prop.Y, y);
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 308,
                    y: 74,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: [
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '44.png',
                    unit_tc: '44.png',
                    unit_en: '44.png',
                    negative_image: '43.png',
                    invalid_image: '42.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 137,
                    y: 279,
                    type: hmUI.data_type.BATTERY,
                    font_array: [
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '45.png',
                    unit_tc: '45.png',
                    unit_en: '45.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 67,
                    y: 277,
                    src: '46.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 324,
                    y: 299,
                    type: hmUI.data_type.CAL,
                    font_array: [
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 305,
                    y: 277,
                    src: '47.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    year_startX: 233,
                    year_startY: 159,
                    year_sc_array: [
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png',
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png'
                    ],
                    year_tc_array: [
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png',
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png'
                    ],
                    year_en_array: [
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png',
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png'
                    ],
                    year_align: hmUI.align.LEFT,
                    year_zero: 1,
                    year_space: 0,
                    year_is_character: false,
                    month_sc_array: [
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png',
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png'
                    ],
                    month_tc_array: [
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png',
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png'
                    ],
                    month_en_array: [
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png',
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png'
                    ],
                    month_zero: 1,
                    month_follow: 1,
                    month_is_character: false,
                    day_sc_array: [
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png',
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png'
                    ],
                    day_tc_array: [
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png',
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png'
                    ],
                    day_en_array: [
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png',
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png'
                    ],
                    day_zero: 1,
                    day_follow: 1,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 358,
                    y: 164,
                    week_en: [
                        '58.png',
                        '59.png',
                        '60.png',
                        '61.png',
                        '62.png',
                        '63.png',
                        '64.png'
                    ],
                    week_tc: [
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png',
                        '71.png'
                    ],
                    week_sc: [
                        '72.png',
                        '73.png',
                        '74.png',
                        '75.png',
                        '76.png',
                        '77.png',
                        '78.png'
                    ],
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 257,
                    y: 87,
                    image_array: [
                        '79.png',
                        '80.png',
                        '81.png',
                        '82.png',
                        '83.png',
                        '84.png',
                        '85.png',
                        '86.png',
                        '87.png',
                        '88.png',
                        '89.png',
                        '90.png',
                        '91.png',
                        '92.png',
                        '93.png',
                        '94.png',
                        '95.png',
                        '96.png',
                        '97.png',
                        '98.png',
                        '99.png',
                        '100.png',
                        '101.png',
                        '102.png',
                        '103.png',
                        '104.png',
                        '105.png',
                        '106.png',
                        '107.png'
                    ],
                    image_length: 29,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_val: new Date().getHours(),
                    hour_zero: 1,
                    hour_startX: 75,
                    hour_startY: 202,
                    hour_array: [
                        '108.png',
                        '109.png',
                        '110.png',
                        '111.png',
                        '112.png',
                        '113.png',
                        '114.png',
                        '115.png',
                        '116.png',
                        '117.png'
                    ],
                    hour_space: 0,
                    hour_unit_sc: '118.png',
                    hour_unit_tc: '118.png',
                    hour_unit_en: '118.png',
                    hour_align: hmUI.align.CENTER_H,
                    minute_zero: 1,
                    minute_array: [
                        '108.png',
                        '109.png',
                        '110.png',
                        '111.png',
                        '112.png',
                        '113.png',
                        '114.png',
                        '115.png',
                        '116.png',
                        '117.png'
                    ],
                    minute_unit_sc: '119.png',
                    minute_unit_tc: '119.png',
                    minute_unit_en: '119.png',
                    minute_follow: 1,
                    second_zero: 1,
                    second_array: [
                        '108.png',
                        '109.png',
                        '110.png',
                        '111.png',
                        '112.png',
                        '113.png',
                        '114.png',
                        '115.png',
                        '116.png',
                        '117.png'
                    ],
                    second_follow: 1,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 251,
                    y: 299,
                    type: hmUI.data_type.HEART,
                    font_array: [
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '120.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 244,
                    y: 278,
                    src: '121.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 122,
                    y: 173,
                    type: hmUI.data_type.ALTIMETER,
                    font_array: [
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '122.png',
                    padding: true,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 49,
                    y: 172,
                    src: '123.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 172,
                    y: 348,
                    type: hmUI.data_type.UVI,
                    font_array: [
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '124.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 72,
                    y: 347,
                    src: '125.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 206,
                    y: 384,
                    type: hmUI.data_type.SUN_RISE,
                    font_array: [
                        '126.png',
                        '127.png',
                        '128.png',
                        '129.png',
                        '130.png',
                        '131.png',
                        '132.png',
                        '133.png',
                        '134.png',
                        '135.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    dot_image: '137.png',
                    invalid_image: '136.png',
                    padding: true,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 174,
                    y: 382,
                    w: 26,
                    h: 19,
                    src: '138.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 206,
                    y: 409,
                    type: hmUI.data_type.SUN_SET,
                    font_array: [
                        '126.png',
                        '127.png',
                        '128.png',
                        '129.png',
                        '130.png',
                        '131.png',
                        '132.png',
                        '133.png',
                        '134.png',
                        '135.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    dot_image: '140.png',
                    invalid_image: '139.png',
                    padding: true,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 174,
                    y: 407,
                    w: 26,
                    h: 19,
                    src: '141.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 156,
                    y: 313,
                    type: hmUI.data_type.PAI_WEEKLY,
                    font_array: [
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 62,
                    y: 312,
                    src: '142.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 276,
                    y: 74,
                    w: 92,
                    h: 58,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 313,
                    y: 278,
                    w: 58,
                    h: 91,
                    type: hmUI.data_type.CAL,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 233,
                    y: 264,
                    w: 63,
                    h: 64,
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 78,
                    y: 174,
                    w: 105,
                    h: 27,
                    type: hmUI.data_type.ALTIMETER,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 172,
                    y: 369,
                    w: 108,
                    h: 58,
                    type: hmUI.data_type.SUN_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 90,
                    y: 302,
                    w: 112,
                    h: 44,
                    type: hmUI.data_type.PAI_WEEKLY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        getLunarText();
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}