try {
    (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;

        var __$$module$$__ = __$$app$$__.current;
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        /*
         * huamiOS bundle tool v1.0.17
         * Copyright © Huami. All Rights Reserved
         * 天气 271F
         */
        'use strict';
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

            init_view() {
                let rootPath = "images/";
                let weekArr = [
                    rootPath + 'week/week_1.png',
                    rootPath + 'week/week_2.png',
                    rootPath + 'week/week_3.png',
                    rootPath + 'week/week_4.png',
                    rootPath + 'week/week_5.png',
                    rootPath + 'week/week_6.png',
                    rootPath + 'week/week_7.png'
                ];
                let monthArr = [
                    rootPath + 'month/1.png',
                    rootPath + 'month/2.png',
                    rootPath + 'month/3.png',
                    rootPath + 'month/4.png',
                    rootPath + 'month/5.png',
                    rootPath + 'month/6.png',
                    rootPath + 'month/7.png',
                    rootPath + 'month/8.png',
                    rootPath + 'month/9.png',
                    rootPath + 'month/10.png',
                    rootPath + 'month/11.png',
                    rootPath + 'month/12.png'
                ];
                let dayArr = [
                    rootPath + 'day/date_0.png',
                    rootPath + 'day/date_1.png',
                    rootPath + 'day/date_2.png',
                    rootPath + 'day/date_3.png',
                    rootPath + 'day/date_4.png',
                    rootPath + 'day/date_5.png',
                    rootPath + 'day/date_6.png',
                    rootPath + 'day/date_7.png',
                    rootPath + 'day/date_8.png',
                    rootPath + 'day/date_9.png',
                ];
                let fontArr = [
                    rootPath + 'font/0.png',
                    rootPath + 'font/1.png',
                    rootPath + 'font/2.png',
                    rootPath + 'font/3.png',
                    rootPath + 'font/4.png',
                    rootPath + 'font/5.png',
                    rootPath + 'font/6.png',
                    rootPath + 'font/7.png',
                    rootPath + 'font/8.png',
                    rootPath + 'font/9.png',
                ];
                let weatherArr = []
                for (let i = 0; i < 29; i++) {
                    if (i < 10) {
                        weatherArr.push(rootPath + 'weather/0' + i + '.png')
                    } else {
                        weatherArr.push(rootPath + 'weather/' + i + '.png')
                    }
                }
                const pointerConfig = [{
                        id: 1,
                        hour: {
                            centerX: 227,
                            centerY: 227,
                            posX: 18 * 0.9458,
                            posY: 152 * 0.9458,
                            path: rootPath + '/pointer/h.png',
                        },
                        minute: {
                            centerX: 227,
                            centerY: 227,
                            posX: 22 * 0.9458,
                            posY: 235 * 0.9458,
                            path: rootPath + '/pointer/m.png',
                        },
                        preview: rootPath + 'pointer/preview.png',
                    },
                    {
                        id: 2,
                        hour: {
                            centerX: 227,
                            centerY: 227,
                            posX: 22 * 0.9458,
                            posY: 156 * 0.9458,
                            path: rootPath + '/pointer/h2.png',
                        },
                        minute: {
                            centerX: 227,
                            centerY: 227,
                            posX: 37 * 0.9458,
                            posY: 257 * 0.9458,
                            path: rootPath + '/pointer/m2.png',
                        },
                        second: {
                            centerX: 227,
                            centerY: 227,
                            posX: 15 * 0.9458,
                            posY: 249 * 0.9458,
                            path: rootPath + '/pointer/s2.png',
                        },
                        preview: rootPath + '/pointer/preview2.png'
                    },
                    {
                        id: 3,
                        hour: {
                            centerX: 227,
                            centerY: 227,
                            posX: 39 * 0.9458,
                            posY: 230 * 0.9458,
                            path: rootPath + '/pointer/h3.png',
                        },
                        minute: {
                            centerX: 227,
                            centerY: 227,
                            posX: 47 * 0.9458,
                            posY: 259 * 0.9458,
                            path: rootPath + '/pointer/m3.png',
                        },
                        second: {
                            centerX: 227,
                            centerY: 227,
                            posX: 25 * 0.9458,
                            posY: 256 * 0.9458,
                            path: rootPath + '/pointer/s3.png',
                        },
                        preview: rootPath + '/pointer/preview3.png'
                    },
                ];
                let greenArr = [];
                let blueArr = [];
                let orangeArr = [];
                let purpleArr = [];
                let redArr = []
                let sleep = hmSensor.createSensor(hmSensor.id.SLEEP);
                for (let i = 1; i < 11; i++) {
                    greenArr.push(rootPath + 'greenLevel/' + i + '.png');
                    blueArr.push(rootPath + 'blueLevel/' + i + '.png');
                    orangeArr.push(rootPath + 'orangeLevel/' + i + '.png');
                    purpleArr.push(rootPath + 'purpleLevel/' + i + '.png');
                    redArr.push(rootPath + 'redLevel2/' + i + '.png');
                }
                // 息屏状态
                var screenType = hmSetting.getScreenType();
                if (screenType == hmSetting.screen_type.AOD) {
                    //edit bg
                    const editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
                        edit_id: 103,
                        x: 0,
                        y: 0,
                        bg_config: [{
                                id: 1,
                                preview: rootPath + '/bg/1.png',
                                path: rootPath + '/bg/1.png'
                            },
                            {
                                id: 2,
                                preview: rootPath + '/bg/2.png',
                                path: rootPath + '/bg/2.png'
                            },
                            {
                                id: 3,
                                preview: rootPath + '/bg/3.png',
                                path: rootPath + '/bg/3.png'
                            },
                        ],
                        count: 3,
                        default_id: 1,
                        fg: rootPath + '/mask/bgmask.png',
                        tips_x: 178,
                        tips_y: 408,
                        tips_bg: rootPath + '/tip/bgTips.png',
                        tips_width:104,
                        tips_margin:10
                    });

                    //week
                    hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                        x: 232,
                        y: 114,
                        week_en: weekArr,
                        week_tc: weekArr,
                        week_sc: weekArr,
                        show_level: hmUI.show_level.ONAL_AOD,
                    });
                    //month
                    hmUI.createWidget(hmUI.widget.IMG_DATE, {
                        month_startX: 153,
                        month_startY: 114,
                        month_unit_sc: rootPath + '/month/unit.png', //单位
                        month_unit_tc: rootPath + '/month/unit.png',
                        month_unit_en: rootPath + '/month/unit.png',
                        month_align: hmUI.align.LEFT,
                        month_space: 0, //文字间隔
                        month_zero: 0, //是否补零
                        month_follow: 0, //是否跟随
                        month_en_array: monthArr,
                        month_sc_array: monthArr,
                        month_tc_array: monthArr,
                        month_is_character: true,

                        day_startX: 204,
                        day_startY: 51,
                        day_align: hmUI.align.LEFT,
                        day_space: 0, //文字间隔
                        day_zero: 1, //是否补零
                        day_follow: 0, //是否跟随
                        day_en_array: dayArr,
                        day_sc_array: dayArr,
                        day_tc_array: dayArr,
                        day_is_character: false,
                        show_level: hmUI.show_level.ONAL_AOD,
                    });

                    let pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER, {
                        edit_id: 120,
                        x: 0,
                        y: 0,
                        config: pointerConfig,
                        count: pointerConfig.length,
                        default_id: 1,
                        fg: rootPath + '/mask/bgmask.png',
                        tips_x: 178,
                        tips_y: 408,
                        tips_bg: rootPath + '/tip/bgTips.png',
                        tips_width:104,
                        tips_margin:10
                    });
                    const screenType = hmSetting.getScreenType();
                    const aodModel = screenType == hmSetting.screen_type.AOD;
                    const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG, !aodModel);
                    pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp)
                } else {
                    //edit bg
                    const editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
                        edit_id: 103,
                        x: 0,
                        y: 0,
                        bg_config: [{
                                id: 1,
                                preview: rootPath + '/bg/1.png',
                                path: rootPath + '/bg/1.png'
                            },
                            {
                                id: 2,
                                preview: rootPath + '/bg/2.png',
                                path: rootPath + '/bg/2.png'
                            },
                            {
                                id: 3,
                                preview: rootPath + '/bg/3.png',
                                path: rootPath + '/bg/3.png'
                            },
                        ],
                        count: 3,
                        default_id: 3,
                        fg: rootPath + '/mask/bgmask.png',
                        tips_x: 178,
                        tips_y: 408,
                        tips_bg: rootPath + '/tip/bgTips.png',
                        tips_width:104,
                        tips_margin:10
                    });
                    //week
                    hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                        x: 232,
                        y: 114,
                        week_en: weekArr,
                        week_tc: weekArr,
                        week_sc: weekArr,
                        // show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD,
                    });
                    //month
                    hmUI.createWidget(hmUI.widget.IMG_DATE, {
                        month_startX: 153,
                        month_startY: 114,
                        month_unit_sc: rootPath + '/month/unit.png', //单位
                        month_unit_tc: rootPath + '/month/unit.png',
                        month_unit_en: rootPath + '/month/unit.png',
                        month_align: hmUI.align.LEFT,
                        month_space: 0, //文字间隔
                        month_zero: 0, //是否补零
                        month_follow: 0, //是否跟随
                        month_en_array: monthArr,
                        month_sc_array: monthArr,
                        month_tc_array: monthArr,
                        month_is_character: true,

                        day_startX: 204,
                        day_startY: 51,
                        day_align: hmUI.align.LEFT,
                        day_space: 0, //文字间隔
                        day_zero: 1, //是否补零
                        day_follow: 0, //是否跟随
                        day_en_array: dayArr,
                        day_sc_array: dayArr,
                        day_tc_array: dayArr,
                        day_is_character: false,
                        // show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD,
                    });

                    function Rect() {
                        this.x = 0
                        this.y = 0
                        this.w = 0
                        this.h = 0
                        this.color = 0x000000
                        this.create()
                        this.hide()
                    }
                    Rect.prototype.create = function () {
                        this.widget = hmUI.createWidget(hmUI.widget.FILL_RECT)
                    }
                    Rect.prototype.setRect = function (xpos, ypos, w, h, color) {
                        this.widget.setProperty(hmUI.prop.MORE, {
                            x: xpos,
                            y: ypos,
                            w: w,
                            h: h,
                            color: color
                        })
                    }
                    Rect.prototype.hide = function() {
                        this.widget.setProperty(hmUI.prop.VISIBLE,false)
                    }
                    Rect.prototype.show = function() {
                        this.widget.setProperty(hmUI.prop.VISIBLE,true)
                    }
                    let rectArr = [] //存储矩形控件对象
                    // let starttext = null
                    let starttext = hmUI.createWidget(hmUI.widget.TEXT)
                    let endtext = hmUI.createWidget(hmUI.widget.TEXT)
                    let totaltext = hmUI.createWidget(hmUI.widget.TEXT)
                    let lastSleepStageArray = null
                    let clockTimer = null
                    function getSleepData() {
                        if (clockTimer) {
                            timer.stopTimer(clockTimer)
                        }
                        clockTimer = timer.createTimer(
                            0, 100, (function (option) {
                                let sleepStageArray = sleep.getSleepStageData();
                                if (sleepStageArray && sleepStageArray.length != 0) {
                                    timer.stopTimer(clockTimer)
                                    const basicInfo = sleep.getBasicInfo()
                                    if (basicInfo.endTime == -1) {
                                        for (let i = 0; i < rectArr.length; i++) {
                                            rectArr[i].setRect(0, 0, 0, 0, 0x000000)
                                            rectArr[i].hide()
                                        }
                                        starttext.setProperty(hmUI.prop.VISIBLE,false);
                                        endtext.setProperty(hmUI.prop.VISIBLE,false);
                                        totaltext.setProperty(hmUI.prop.VISIBLE,false);
                                        return
                                    }
                                    if (JSON.stringify(sleepStageArray) == JSON.stringify(lastSleepStageArray)) {
                                        return
                                    }
                                    starttext.setProperty(hmUI.prop.VISIBLE,true)
                                    endtext.setProperty(hmUI.prop.VISIBLE,true)
                                    totaltext.setProperty(hmUI.prop.VISIBLE,true)
                                    for (let i = 0; i < rectArr.length; i++) {
                                        rectArr[i].setRect(0, 0, 0, 0, 0x000000)
                                        rectArr[i].show()
                                    }
                                    lastSleepStageArray = sleepStageArray
                                    var per = 250 * 0.9458 / (sleepStageArray[(sleepStageArray.length - 1)].stop - sleepStageArray[0].start + 1);
                                    let sober = 0  //记录清醒时长
                                    for (var i = 0; i < sleepStageArray.length; i++) {
                                        const data = sleepStageArray[i];
                                        var xpos = 102 + (data.start - sleepStageArray[0].start) * per; //柱状图 x
                                        var ypos = 364; //柱状图 y
                                        var w = (data.stop - data.start + 1) * per;
                                        if (w < 1) {
                                            w = 1
                                        }
                                        var space = 8; //柱状图间隔
                                        switch (data.model) {
                                            case 4: // .LIGHT_STAGE 浅睡 blue
                                                rectArr[i].setRect(xpos + space, ypos - 10, w, 10, 0x259FBE)
                                                break;
                                            case 5: // DEEP_STAGE:5  深睡 purple
                                                rectArr[i].setRect(xpos + space, ypos - 26, w, 26, 0x864BE1)
                                                break;
                                            case 7: // WAKE_STAGE:7 清醒 yellow(red)
                                                rectArr[i].setRect(xpos + space, ypos - 55, w, 55, 0xD05D20)
                                                sober = data.stop - data.start + 1 + sober
                                                break;
                                            case 8: // .REM_STAGE REM green
                                                rectArr[i].setRect(xpos + space, ypos - 43, w, 43, 0x0CB462)
                                                break;
                                            default:
                                        }
                                    }
                                    //格式化数据 （保留一位小数）
                                    var fomatFloat = function (value, n) {
                                        var f = Math.round(value * Math.pow(10, n)) / Math.pow(10, n);
                                        var s = f.toString();
                                        var rs = s.indexOf('.');
                                        if (rs < 0) {
                                            s += '.';
                                        }
                                        for (var i = s.length - s.indexOf('.'); i <= n; i++) {
                                            s += "0";
                                        }
                                        return s;
                                    }
                                    const sleeptime = sleep.getTotalTime()
                                    const num = sleep.getBasicInfo()
                                    const startTime = num.startTime
                                    const endTime = num.endTime + 1
                                    const totalTime = fomatFloat((endTime - startTime - sober) / 60, 2)
                                    const totalTimeArr = totalTime.split(".")
                                    const totalTime1 = totalTimeArr[0]
                                    const totalTime2 = totalTimeArr[1]
                                    if (startTime) {
                                        var startTime1 = JSON.stringify(startTime)
                                        var endTime1 = JSON.stringify(endTime)
                                        var H1 = parseInt(endTime1 / 60)
                                        var M1 = parseInt(endTime1 % 60)
                                        let SLEEP_REFERENCE_ZERO = 24 * 60
                                        if (startTime1 >= SLEEP_REFERENCE_ZERO) {
                                            H = parseInt((startTime1 - SLEEP_REFERENCE_ZERO) / 60)
                                            M = parseInt((startTime1 - SLEEP_REFERENCE_ZERO) % 60)
                                        } else {
                                            H = parseInt(startTime1 / 60)
                                            M = parseInt(startTime1 % 60)
                                        }
                                        if (endTime1 >= SLEEP_REFERENCE_ZERO) {
                                            H1 = parseInt((endTime1 - SLEEP_REFERENCE_ZERO) / 60)
                                            M1 = parseInt((endTime1 - SLEEP_REFERENCE_ZERO) % 60)
                                        } else {
                                            H1 = parseInt(endTime1 / 60)
                                            M1 = parseInt(endTime1 % 60)
                                        }
                                        H = H >= 10 ? H : '0' + H
                                        M = M >= 10 ? M : '0' + M
                                        M1 = M1 >= 10 ? M1 : '0' + M1
                                        H1 = H1 >= 10 ? H1 : '0' + H1
                                        starttext.setProperty(hmUI.prop.MORE,{
                                            x: 110,
                                            y: 365,
                                            text: H + ':' + M,
                                            color: 0xffffff,
                                            hAlign: hmUI.align.LEFT
                                        })
                                        endtext.setProperty(hmUI.prop.MORE,{
                                            x: 299,
                                            y: 365,
                                            text: H1 + ':' + M1,
                                            color: 0xffffff,
                                            hAlign: hmUI.align.LEFT,
                                        })
                                        totaltext.setProperty(hmUI.prop.MORE,{
                                            x: 193,
                                            y: 395,
                                            text: totalTime1 + '.' + totalTime2 + 'H',
                                            color: 0xffffff,
                                            hAlign: hmUI.align.LEFT,
                                        })
                                    }
                                }
                            }), {})

                    }
                    //edit widget
                    let right_icon = hmUI.createWidget(hmUI.widget.IMG);
                    let right_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL);
                    let right_bg = hmUI.createWidget(hmUI.widget.IMG);
                    let right_text = hmUI.createWidget(hmUI.widget.TEXT_IMG);
                    let right_point = hmUI.createWidget(hmUI.widget.IMG_POINTER);

                    let left_icon = hmUI.createWidget(hmUI.widget.IMG);
                    let left_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL);
                    let left_bg = hmUI.createWidget(hmUI.widget.IMG);
                    let left_text = hmUI.createWidget(hmUI.widget.TEXT_IMG);
                    let left_point = hmUI.createWidget(hmUI.widget.IMG_POINTER);

                    //bottom
                    let bottom_bg = hmUI.createWidget(hmUI.widget.IMG);

                    function Icon(x, y, src) {
                        let config = {
                            x: x,
                            y: y,
                            src: src,
                        }
                        let icon_config = {}
                        for (let key in config) {
                            if (config[key]) {
                                icon_config[key] = config[key]
                            }
                        }
                        return icon_config
                    }

                    function text(x, y, type, font_array, unit, imperial, negative, dot, invalid) {
                        let config = {
                            x: x,
                            y: y,
                            w: 60,
                            type: type,
                            font_array: font_array,
                            h_space: 0, //图片间隔
                            align_h: hmUI.align.CENTER_H,
                            unit_sc: unit, //单位
                            unit_tc: unit, //单位
                            unit_en: unit, //单位
                            imperial_unit_sc: imperial, //英制单位只有里程使用
                            imperial_unit_tc: imperial,
                            imperial_unit_en: imperial,
                            negative_image: negative, //负号图片
                            dot_image: dot, //小数点图片
                            invalid_image: invalid, // 无数据时显示的图片
                            padding: false, //是否补零 true为补零
                        }
                        let text_config = {}
                        for (let key in config) {
                            if (config[key]) {
                                text_config[key] = config[key]
                            }
                        }
                        return text_config
                    }

                    function level(x, y, image_array, type) {
                        let config = {
                            x: x,
                            y: y,
                            image_array: image_array,
                            image_length: image_array.length, //长度
                            type: type,
                        }
                        let level_config = {}
                        for (let key in config) {
                            if (config[key]) {
                                level_config[key] = config[key]
                            }
                        }
                        return level_config
                    }

                    function bg(x, y, src, alpha = 255) {
                        let config = {
                            x: x,
                            y: y,
                            src: src,
                            alpha: alpha
                        }
                        let bg_config = {}
                        for (let key in config) {
                            if (config[key]) {
                                bg_config[key] = config[key]
                            }
                        }
                        return bg_config
                    }

                    function point(src, center_x, center_y, x, y, type, start_angle, end_angle) {
                        let config = {
                            src: src,
                            center_x: center_x,
                            center_y: center_y,
                            x: x,
                            y: y,
                            type: type,
                            start_angle: start_angle,
                            end_angle: end_angle,
                        }
                        let point_config = {}
                        for (let key in config) {
                            if (config[key]) {
                                point_config[key] = config[key]
                            }
                        }
                        return point_config
                    }

                    function line(x, y, w, h, type) {
                        let config = {
                            x: x,
                            y: y,
                            w: w,
                            h: h,
                            type: type
                        }
                        let line_config = {}
                        for (let key in config) {
                            if (config[key]) {
                                line_config[key] = config[key]
                            }
                        }
                        return line_config
                    }

                    let left_groupX = 41;
                    let left_groupY = 147
                    let groupArr = [{
                            type: hmUI.edit_type.HEART,
                            preview: rootPath + "widgetPreview/heart.png"
                        },
                        {
                            type: hmUI.edit_type.STEP,
                            preview: rootPath + "widgetPreview/step.png"
                        },
                        // { type: hmUI.edit_type.AQI, preview: rootPath + "widgetPreview/AQI.png" },
                        {
                            type: hmUI.edit_type.UVI,
                            preview: rootPath + "widgetPreview/UVI.png"
                        },
                        {
                            type: hmUI.edit_type.WEATHER,
                            preview: rootPath + "widgetPreview/weather.png"
                        },
                        {
                            type: hmUI.edit_type.BATTERY,
                            preview: rootPath + "widgetPreview/power.png"
                        },
                        {
                            type: hmUI.edit_type.WIND,
                            preview: rootPath + "widgetPreview/wind.png"
                        },
                        // {
                        //     type: hmUI.edit_type.SPO2,
                        //     preview: rootPath + "widgetPreview/spo2.png"
                        // },
                        {
                            type: hmUI.edit_type.PAI,
                            preview: rootPath + "widgetPreview/pai.png"
                        },
                        {
                            type: hmUI.edit_type.CAL,
                            preview: rootPath + "widgetPreview/cal.png"
                        },
                        {
                            type: hmUI.edit_type.DISTANCE,
                            preview: rootPath + "widgetPreview/distance.png"
                        },
                        {
                            type: hmUI.edit_type.SLEEP,
                            preview: rootPath + "widgetPreview/sleep.png"
                        },
                        // { type: hmUI.edit_type.BODY_TEMP, preview: rootPath + "widgetPreview/TEMPERATURE.png" },
                        {
                            type: hmUI.edit_type.HUMIDITY,
                            preview: rootPath + "widgetPreview/humidity.png"
                        },
                        // { type: hmUI.edit_type.FAT_BURN, preview: rootPath + "widgetPreview/fatBurn.png" },
                        {
                            type: hmUI.edit_type.ALTIMETER,
                            preview: rootPath + "widgetPreview/KPA.png"
                        },
                    ]
                    let editGroup = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                        edit_id: 101,
                        x: left_groupX,
                        y: left_groupY,
                        w: 132,
                        h: 132,
                        select_image: rootPath + "select/select.png",
                        un_select_image: rootPath + "select/unselect.png",
                        default_type: hmUI.edit_type.HEART,
                        optional_types: groupArr,
                        count: groupArr.length,
                        tips_BG: rootPath + "tip/bgTips.png",
                        tips_x: 18,
                        tips_y: -38,
                        tips_width: 104,
                        tips_margin:10
                    });
                    let editType = editGroup.getProperty(hmUI.prop.CURRENT_TYPE);
                    let left_icon_config = null
                    let left_text_config = null
                    let left_level_config = null
                    let left_bg_config = null
                    let left_point_config = null
                    switch (editType) {
                        case
                        hmUI.edit_type.HEART:
                            left_icon_config = Icon(91, 198, rootPath + '/icon/heart.png')
                            left_text_config = text(80, 142, hmUI.data_type.HEART, fontArr, '', '', '', '', rootPath + 'font/none.png')
                            left_level_config = level('', '', '', '')
                            left_bg_config = bg(41, 147, rootPath + 'redLevel/1.png')
                            left_point_config = point(rootPath + 'round_dot/round.png', 106, 213, 7, 68, hmUI.data_type.HEART, 35, 325)

                            left_icon.setProperty(hmUI.prop.MORE, left_icon_config);
                            left_text.setProperty(hmUI.prop.MORE, left_text_config);
                            left_level.setProperty(hmUI.prop.MORE, left_level_config);
                            left_bg.setProperty(hmUI.prop.MORE, left_bg_config);
                            left_point.setProperty(hmUI.prop.MORE, left_point_config)
                            break;
                        case
                        hmUI.edit_type.STEP:
                            left_icon_config = Icon(91, 198, rootPath + '/icon/step.png')
                            left_text_config = text(76, 142, hmUI.data_type.STEP, fontArr, '', '', '', '', '')
                            left_bg_config = bg(41, 147, rootPath + 'blueLevel/10.png', 96)
                            left_level_config = level(41, 147, blueArr, hmUI.data_type.STEP)
                            left_point_config = point('', '', '', '', '', '', '', '')

                            left_icon.setProperty(hmUI.prop.MORE, left_icon_config);
                            left_text.setProperty(hmUI.prop.MORE, left_text_config);
                            left_bg.setProperty(hmUI.prop.MORE, left_bg_config);
                            left_level.setProperty(hmUI.prop.MORE, left_level_config);
                            left_point.setProperty(hmUI.prop.MORE, left_point_config)
                            break;
                            // case
                            //     hmUI.edit_type.AQI:
                            //     left_icon_config = Icon(91, 198, rootPath + '/icon/AQI.png')
                            //     left_text_config = text(78, 142, hmUI.data_type.AQI, fontArr, '', '', '', '', rootPath + 'font/none.png')
                            //     left_bg_config = bg(41, 147, rootPath + 'blueLevel/10.png', 96)
                            //     left_level_config = level(41, 147, blueArr, hmUI.data_type.AQI)
                            //     left_point_config = point('', '', '', '', '', '', '', '')

                            //     left_icon.setProperty(hmUI.prop.MORE, left_icon_config);
                            //     left_text.setProperty(hmUI.prop.MORE, left_text_config);
                            //     left_bg.setProperty(hmUI.prop.MORE, left_bg_config);
                            //     left_level.setProperty(hmUI.prop.MORE, left_level_config);
                            //     left_point.setProperty(hmUI.prop.MORE, left_point_config)
                            //     break;
                        case
                        hmUI.edit_type.UVI:
                            left_icon_config = Icon(91, 198, rootPath + '/icon/UVI.png')
                            left_bg_config = bg(41, 147, rootPath + 'purpleLevel/10.png', 96)
                            left_level_config = level(41, 147, purpleArr, hmUI.data_type.UVI)
                            left_point_config = point('', '', '', '', '', '', '', '')
                            left_text_config = text(80, 142, hmUI.data_type.UVI, fontArr, '', '', '', '', rootPath + 'font/none.png')

                            left_icon.setProperty(hmUI.prop.MORE, left_icon_config);
                            left_bg.setProperty(hmUI.prop.MORE, left_bg_config);
                            left_level.setProperty(hmUI.prop.MORE, left_level_config);
                            left_point.setProperty(hmUI.prop.MORE, left_point_config)
                            left_text.setProperty(hmUI.prop.MORE, left_text_config);
                            break;
                        case
                        hmUI.edit_type.WEATHER:
                            left_icon_config = Icon('', '', '')
                            let weatherLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                                x: 91,
                                y: 198,
                                image_array: weatherArr,
                                image_length: weatherArr.length, //长度
                                type: hmUI.data_type.WEATHER,
                            });
                            left_text_config = text(82, 142, hmUI.data_type.WEATHER_CURRENT, fontArr, rootPath + 'font/temp.png', '', rootPath + 'font/fuhao.png', '', rootPath + 'font/none.png')
                            left_bg_config = bg(41, 147, rootPath + 'yellowLevel/1.png')
                            left_level_config = level('', '', '', '')
                            left_point_config = point(rootPath + 'round_dot/round.png', 106, 213, 7, 68, hmUI.data_type.WEATHER_CURRENT, 35, 325)

                            left_icon.setProperty(hmUI.prop.MORE, left_icon_config);
                            left_bg.setProperty(hmUI.prop.MORE, left_bg_config);
                            left_level.setProperty(hmUI.prop.MORE, left_level_config);
                            left_point.setProperty(hmUI.prop.MORE, left_point_config)
                            left_text.setProperty(hmUI.prop.MORE, left_text_config);
                            break;
                        case
                        hmUI.edit_type.BATTERY:
                            left_icon_config = Icon(91, 198, rootPath + '/icon/power.png')
                            left_text_config = text(78, 142, hmUI.data_type.BATTERY, fontArr, '', '', '', '', '')
                            left_bg_config = bg(41, 147, rootPath + 'greenLevel/10.png', 96)
                            left_level_config = level(41, 147, greenArr, hmUI.data_type.BATTERY)
                            left_point_config = point('', '', '', '', '', '', '', '')

                            left_icon.setProperty(hmUI.prop.MORE, left_icon_config);
                            left_text.setProperty(hmUI.prop.MORE, left_text_config);
                            left_bg.setProperty(hmUI.prop.MORE, left_bg_config);
                            left_level.setProperty(hmUI.prop.MORE, left_level_config);
                            left_point.setProperty(hmUI.prop.MORE, left_point_config)
                            break;
                        case
                        hmUI.edit_type.WIND:
                            left_icon_config = Icon(91, 198, rootPath + '/icon/wind.png')
                            left_text_config = text(80, 142, hmUI.data_type.WIND, fontArr, '', '', '', '', rootPath + 'font/none.png')
                            left_bg_config = bg(41, 147, rootPath + 'blueLevel/10.png', 96)
                            left_level_config = level(41, 147, blueArr, hmUI.data_type.WIND)
                            left_point_config = point('', '', '', '', '', '', '', '')

                            left_icon.setProperty(hmUI.prop.MORE, left_icon_config);
                            left_bg.setProperty(hmUI.prop.MORE, left_bg_config);
                            left_level.setProperty(hmUI.prop.MORE, left_level_config);
                            left_point.setProperty(hmUI.prop.MORE, left_point_config)
                            left_text.setProperty(hmUI.prop.MORE, left_text_config);
                            break
                        // case
                        // hmUI.edit_type.SPO2:
                        //     left_icon_config = Icon(91, 198, rootPath + '/icon/spo2.png')
                        //     left_text_config = text(80, 142, hmUI.data_type.SPO2, fontArr, rootPath + 'font/bfh.png', '', '', '', rootPath + 'font/none.png')
                        //     left_bg_config = bg(41, 147, rootPath + 'redLevel2/10.png', 96)
                        //     left_level_config = level(41, 147, redArr, hmUI.data_type.SPO2)
                        //     left_point_config = point('', '', '', '', '', '', '', '')

                        //     left_icon.setProperty(hmUI.prop.MORE, left_icon_config);
                        //     left_text.setProperty(hmUI.prop.MORE, left_text_config);
                        //     left_bg.setProperty(hmUI.prop.MORE, left_bg_config);
                        //     left_level.setProperty(hmUI.prop.MORE, left_level_config);
                        //     left_point.setProperty(hmUI.prop.MORE, left_point_config)
                        //     break
                        case
                        hmUI.edit_type.PAI:
                            left_icon_config = Icon(91, 198, rootPath + '/icon/PAI.png')
                            left_text_config = text(80, 142, hmUI.data_type.PAI_DAILY, fontArr, '', '', '', '', '')
                            left_bg_config = bg(41, 147, rootPath + 'purpleLevel/10.png', 96)
                            left_level_config = level(41, 147, purpleArr, hmUI.data_type.PAI_DAILY)
                            left_point_config = point('', '', '', '', '', '', '', '')

                            left_icon.setProperty(hmUI.prop.MORE, left_icon_config);
                            left_text.setProperty(hmUI.prop.MORE, left_text_config);
                            left_bg.setProperty(hmUI.prop.MORE, left_bg_config);
                            left_level.setProperty(hmUI.prop.MORE, left_level_config);
                            left_point.setProperty(hmUI.prop.MORE, left_point_config)
                            break;
                        case
                        hmUI.edit_type.CAL:
                            left_icon_config = Icon(91, 198, rootPath + '/icon/cal.png')
                            left_text_config = text(80, 142, hmUI.data_type.CAL, fontArr, '', '', '', '', '')
                            left_bg_config = bg(41, 147, rootPath + 'orangeLevel/10.png', 96)
                            left_level_config = level(41, 147, orangeArr, hmUI.data_type.CAL)
                            left_point_config = point('', '', '', '', '', '', '', '')

                            left_icon.setProperty(hmUI.prop.MORE, left_icon_config);
                            left_text.setProperty(hmUI.prop.MORE, left_text_config);
                            left_bg.setProperty(hmUI.prop.MORE, left_bg_config);
                            left_level.setProperty(hmUI.prop.MORE, left_level_config);
                            left_point.setProperty(hmUI.prop.MORE, left_point_config)
                            break;
                        case
                        hmUI.edit_type.DISTANCE:
                            left_icon_config = Icon(91, 198, rootPath + '/icon/distance.png')
                            left_text_config = text(80, 142, hmUI.data_type.DISTANCE, fontArr, '', '', '', rootPath + 'font/dot.png', rootPath + 'font/none.png')
                            left_bg_config = bg(41, 147, rootPath + 'blueLevel/10.png', 96)
                            left_level_config = level(41, 147, blueArr, hmUI.data_type.STEP)
                            left_point_config = point('', '', '', '', '', '', '', '')

                            left_icon.setProperty(hmUI.prop.MORE, left_icon_config);
                            left_text.setProperty(hmUI.prop.MORE, left_text_config);
                            left_bg.setProperty(hmUI.prop.MORE, left_bg_config);
                            left_level.setProperty(hmUI.prop.MORE, left_level_config);
                            left_point.setProperty(hmUI.prop.MORE, left_point_config)
                            break;
                        case
                        hmUI.edit_type.SLEEP:
                            left_icon_config = Icon(91, 198, rootPath + '/icon/sleep.png')
                            left_text_config = text(80, 142, hmUI.data_type.SLEEP, fontArr, rootPath + 'font/h.png', '', '', rootPath + 'font/dot.png', rootPath + 'font/none.png')
                            left_bg_config = bg(41, 147, rootPath + 'purpleLevel/10.png', 96)
                            left_level_config = level(41, 147, purpleArr, hmUI.data_type.SLEEP)
                            left_point_config = point('', '', '', '', '', '', '', '')

                            left_icon.setProperty(hmUI.prop.MORE, left_icon_config);
                            left_text.setProperty(hmUI.prop.MORE, left_text_config);
                            left_bg.setProperty(hmUI.prop.MORE, left_bg_config);
                            left_level.setProperty(hmUI.prop.MORE, left_level_config);
                            left_point.setProperty(hmUI.prop.MORE, left_point_config)
                            break;
                        case
                        hmUI.edit_type.HUMIDITY:
                            left_icon_config = Icon(91, 198, rootPath + '/icon/humidity.png')
                            left_text_config = text(80, 142, hmUI.data_type.HUMIDITY, fontArr, rootPath + 'font/bfh.png', '', '', '', rootPath + 'font/none.png')
                            left_bg_config = bg(41, 147, rootPath + 'blueLevel/10.png', 96)
                            left_level_config = level(41, 147, blueArr, hmUI.data_type.HUMIDITY)
                            left_point_config = point('', '', '', '', '', '', '', '')

                            left_icon.setProperty(hmUI.prop.MORE, left_icon_config);
                            left_text.setProperty(hmUI.prop.MORE, left_text_config);
                            left_bg.setProperty(hmUI.prop.MORE, left_bg_config);
                            left_level.setProperty(hmUI.prop.MORE, left_level_config);
                            left_point.setProperty(hmUI.prop.MORE, left_point_config)
                            break;
                        case
                        hmUI.edit_type.ALTIMETER:
                            left_icon_config = Icon(91, 198, rootPath + '/icon/KPA.png')
                            left_text_config = text(78, 142, hmUI.data_type.ALTIMETER, fontArr, '', '', '', '', rootPath + 'font/none.png')
                            left_bg_config = bg(41, 147, rootPath + 'blueLevel/10.png', 96)
                            left_level_config = level(41, 147, blueArr, hmUI.data_type.ALTIMETER)
                            left_point_config = point('', '', '', '', '', '', '', '')

                            left_icon.setProperty(hmUI.prop.MORE, left_icon_config);
                            left_text.setProperty(hmUI.prop.MORE, left_text_config);
                            left_bg.setProperty(hmUI.prop.MORE, left_bg_config);
                            left_level.setProperty(hmUI.prop.MORE, left_level_config);
                            left_point.setProperty(hmUI.prop.MORE, left_point_config)
                            break;
                    }

                    let right_groupX = 281;
                    let right_groupY = 147
                    let editGroup_right = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                        edit_id: 102,
                        x: right_groupX,
                        y: right_groupY,
                        w: 132,
                        h: 132,
                        select_image: rootPath + "select/select.png",
                        un_select_image: rootPath + "select/unselect.png",
                        default_type: hmUI.edit_type.BATTERY,
                        optional_types: groupArr,
                        count: groupArr.length,
                        tips_BG: rootPath + "tip/bgTips.png",
                        tips_x: 18,
                        tips_y: -38,
                        tips_width:104,
                        tips_margin:10
                    });
                    let editType_right = editGroup_right.getProperty(hmUI.prop.CURRENT_TYPE);
                    let right_icon_config = null
                    let right_text_config = null
                    let right_level_config = null
                    let right_bg_config = null
                    let right_point_config = null
                    switch (editType_right) {
                        case
                        hmUI.edit_type.HEART:
                            right_icon_config = Icon(331, 198, rootPath + '/icon/heart.png')
                            right_text_config = text(320, 142, hmUI.data_type.HEART, fontArr, '', '', '', '', rootPath + 'font/none.png')
                            right_level_config = level('', '', '', '')
                            right_bg_config = bg(281, 147, rootPath + 'redLevel/1.png')
                            right_point_config = point(rootPath + 'round_dot/round.png', 346, 213, 7, 68, hmUI.data_type.HEART, 35, 325)

                            right_icon.setProperty(hmUI.prop.MORE, right_icon_config);
                            right_text.setProperty(hmUI.prop.MORE, right_text_config);
                            right_level.setProperty(hmUI.prop.MORE, right_level_config);
                            right_bg.setProperty(hmUI.prop.MORE, right_bg_config);
                            right_point.setProperty(hmUI.prop.MORE, right_point_config)
                            break;
                        case
                        hmUI.edit_type.STEP:
                            right_icon_config = Icon(331, 198, rootPath + '/icon/step.png')
                            right_text_config = text(318, 142, hmUI.data_type.STEP, fontArr, '', '', '', '', '')
                            right_bg_config = bg(281, 147, rootPath + 'blueLevel/10.png', 96)
                            right_level_config = level(281, 147, blueArr, hmUI.data_type.STEP)
                            right_point_config = point('', '', '', '', '', '', '', '')

                            right_icon.setProperty(hmUI.prop.MORE, right_icon_config);
                            right_text.setProperty(hmUI.prop.MORE, right_text_config);
                            right_bg.setProperty(hmUI.prop.MORE, right_bg_config);
                            right_level.setProperty(hmUI.prop.MORE, right_level_config);
                            right_point.setProperty(hmUI.prop.MORE, right_point_config)
                            break;
                            // case
                            //     hmUI.edit_type.AQI:
                            //     right_icon_config = Icon(331, 198, rootPath + '/icon/AQI.png')
                            //     right_text_config = text(320, 142, hmUI.data_type.AQI, fontArr, '', '', '', '', rootPath + 'font/none.png')
                            //     right_bg_config = bg(281, 147, rootPath + 'blueLevel/10.png', 96)
                            //     right_level_config = level(281, 147, blueArr, hmUI.data_type.AQI)
                            //     right_point_config = point('', '', '', '', '', '', '', '')

                            //     right_icon.setProperty(hmUI.prop.MORE, right_icon_config);
                            //     right_text.setProperty(hmUI.prop.MORE, right_text_config);
                            //     right_bg.setProperty(hmUI.prop.MORE, right_bg_config);
                            //     right_level.setProperty(hmUI.prop.MORE, right_level_config);
                            //     right_point.setProperty(hmUI.prop.MORE, right_point_config)
                            //     break;
                        case
                        hmUI.edit_type.UVI:
                            right_icon_config = Icon(331, 198, rootPath + '/icon/UVI.png')
                            right_text_config = text(320, 142, hmUI.data_type.UVI, fontArr, '', '', '', '', rootPath + 'font/none.png')
                            right_bg_config = bg(281, 147, rootPath + 'purpleLevel/10.png', 96)
                            right_level_config = level(281, 147, purpleArr, hmUI.data_type.UVI)
                            right_point_config = point('', '', '', '', '', '', '', '')

                            right_icon.setProperty(hmUI.prop.MORE, right_icon_config);
                            right_text.setProperty(hmUI.prop.MORE, right_text_config);
                            right_bg.setProperty(hmUI.prop.MORE, right_bg_config);
                            right_level.setProperty(hmUI.prop.MORE, right_level_config);
                            right_point.setProperty(hmUI.prop.MORE, right_point_config)
                            break;
                        case
                        hmUI.edit_type.WEATHER:
                            right_icon_config = Icon('', '', '')
                            right_text_config = text(320, 142, hmUI.data_type.WEATHER_CURRENT, fontArr, rootPath + 'font/temp.png', '', rootPath + 'font/fuhao.png', '', rootPath + 'font/none.png')
                            right_bg_config = bg(281, 147, rootPath + 'yellowLevel/1.png')
                            right_level_config = level(281, 147, purpleArr, hmUI.data_type.WEATHER_CURRENT)
                            right_point_config = point(rootPath + 'round_dot/round.png', 346, 213, 7, 68, hmUI.data_type.WEATHER_CURRENT, 35, 325)

                            right_icon.setProperty(hmUI.prop.MORE, right_icon_config);
                            right_text.setProperty(hmUI.prop.MORE, right_text_config);
                            right_bg.setProperty(hmUI.prop.MORE, right_bg_config);
                            right_level.setProperty(hmUI.prop.MORE, right_level_config);
                            right_point.setProperty(hmUI.prop.MORE, right_point_config)
                            let weatherLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                                x: 331,
                                y: 198,
                                image_array: weatherArr,
                                image_length: weatherArr.length, //长度
                                type: hmUI.data_type.WEATHER,
                            });
                            break;
                        case
                        hmUI.edit_type.BATTERY:
                            right_icon_config = Icon(331, 198, rootPath + '/icon/power.png')
                            right_text_config = text(318, 142, hmUI.data_type.BATTERY, fontArr, '', '', '', '', '')
                            right_bg_config = bg(281, 147, rootPath + 'greenLevel/10.png', 96)
                            right_level_config = level(281, 147, greenArr, hmUI.data_type.BATTERY)
                            right_point_config = point('', '', '', '', '', '', '', '')

                            right_icon.setProperty(hmUI.prop.MORE, right_icon_config);
                            right_text.setProperty(hmUI.prop.MORE, right_text_config);
                            right_bg.setProperty(hmUI.prop.MORE, right_bg_config);
                            right_level.setProperty(hmUI.prop.MORE, right_level_config);
                            right_point.setProperty(hmUI.prop.MORE, right_point_config)
                            break;
                        case
                        hmUI.edit_type.WIND:
                            right_icon_config = Icon(331, 198, rootPath + '/icon/wind.png')
                            right_text_config = text(320, 142, hmUI.data_type.WIND, fontArr, '', '', '', '', rootPath + 'font/none.png')
                            right_bg_config = bg(281, 147, rootPath + 'blueLevel/10.png', 96)
                            right_level_config = level(281, 147, blueArr, hmUI.data_type.WIND)
                            right_point_config = point('', '', '', '', '', '', '', '')

                            right_icon.setProperty(hmUI.prop.MORE, right_icon_config);
                            right_text.setProperty(hmUI.prop.MORE, right_text_config);
                            right_bg.setProperty(hmUI.prop.MORE, right_bg_config);
                            right_level.setProperty(hmUI.prop.MORE, right_level_config);
                            right_point.setProperty(hmUI.prop.MORE, right_point_config)
                            break
                        // case
                        // hmUI.edit_type.SPO2:
                        //     right_icon_config = Icon(331, 198, rootPath + '/icon/spo2.png')
                        //     right_text_config = text(320, 142, hmUI.data_type.SPO2, fontArr, rootPath + 'font/bfh.png', '', '', '', rootPath + 'font/none.png')
                        //     right_bg_config = bg(281, 147, rootPath + 'redLevel2/10.png', 96)
                        //     right_level_config = level(281, 147, redArr, hmUI.data_type.SPO2)
                        //     right_point_config = point('', '', '', '', '', '', '', '')

                        //     right_icon.setProperty(hmUI.prop.MORE, right_icon_config);
                        //     right_text.setProperty(hmUI.prop.MORE, right_text_config);
                        //     right_bg.setProperty(hmUI.prop.MORE, right_bg_config);
                        //     right_level.setProperty(hmUI.prop.MORE, right_level_config);
                        //     right_point.setProperty(hmUI.prop.MORE, right_point_config)
                        //     break
                        case
                        hmUI.edit_type.PAI:
                            right_icon_config = Icon(331, 198, rootPath + '/icon/PAI.png')
                            right_text_config = text(318, 142, hmUI.data_type.PAI_DAILY, fontArr, '', '', '', '', '')
                            right_bg_config = bg(281, 147, rootPath + 'purpleLevel/10.png', 96)
                            right_level_config = level(281, 147, purpleArr, hmUI.data_type.PAI_DAILY)
                            right_point_config = point('', '', '', '', '', '', '', '')

                            right_icon.setProperty(hmUI.prop.MORE, right_icon_config);
                            right_text.setProperty(hmUI.prop.MORE, right_text_config);
                            right_bg.setProperty(hmUI.prop.MORE, right_bg_config);
                            right_level.setProperty(hmUI.prop.MORE, right_level_config);
                            right_point.setProperty(hmUI.prop.MORE, right_point_config)
                            break;
                        case
                        hmUI.edit_type.CAL:
                            right_icon_config = Icon(331, 198, rootPath + '/icon/cal.png')
                            right_text_config = text(318, 142, hmUI.data_type.CAL, fontArr, '', '', '', '', '')
                            right_bg_config = bg(281, 147, rootPath + 'orangeLevel/10.png', 96)
                            right_level_config = level(281, 147, orangeArr, hmUI.data_type.CAL)
                            right_point_config = point('', '', '', '', '', '', '', '')

                            right_icon.setProperty(hmUI.prop.MORE, right_icon_config);
                            right_text.setProperty(hmUI.prop.MORE, right_text_config);
                            right_bg.setProperty(hmUI.prop.MORE, right_bg_config);
                            right_level.setProperty(hmUI.prop.MORE, right_level_config);
                            right_point.setProperty(hmUI.prop.MORE, right_point_config)
                            break;
                        case
                        hmUI.edit_type.DISTANCE:
                            right_icon_config = Icon(331, 198, rootPath + '/icon/distance.png')
                            right_text_config = text(318, 142, hmUI.data_type.DISTANCE, fontArr, '', '', '', rootPath + 'font/dot.png', rootPath + 'font/none.png')
                            right_bg_config = bg(281, 147, rootPath + 'blueLevel/10.png', 96)
                            right_level_config = level(281, 147, blueArr, hmUI.data_type.STEP)
                            right_point_config = point('', '', '', '', '', '', '', '')

                            right_icon.setProperty(hmUI.prop.MORE, right_icon_config);
                            right_text.setProperty(hmUI.prop.MORE, right_text_config);
                            right_bg.setProperty(hmUI.prop.MORE, right_bg_config);
                            right_level.setProperty(hmUI.prop.MORE, right_level_config);
                            right_point.setProperty(hmUI.prop.MORE, right_point_config)
                            break;
                        case
                        hmUI.edit_type.SLEEP:
                            right_icon_config = Icon(331, 198, rootPath + '/icon/sleep.png')
                            right_text_config = text(320, 142, hmUI.data_type.SLEEP, fontArr, rootPath + 'font/h.png', '', '', rootPath + 'font/dot.png', rootPath + 'font/none.png')
                            right_bg_config = bg(281, 147, rootPath + 'purpleLevel/10.png', 96)
                            right_level_config = level(281, 147, purpleArr, hmUI.data_type.SLEEP)
                            right_point_config = point('', '', '', '', '', '', '', '')

                            right_icon.setProperty(hmUI.prop.MORE, right_icon_config);
                            right_text.setProperty(hmUI.prop.MORE, right_text_config);
                            right_bg.setProperty(hmUI.prop.MORE, right_bg_config);
                            right_level.setProperty(hmUI.prop.MORE, right_level_config);
                            right_point.setProperty(hmUI.prop.MORE, right_point_config)
                            break;
                        case
                        hmUI.edit_type.HUMIDITY:
                            right_icon_config = Icon(331, 198, rootPath + '/icon/humidity.png')
                            right_text_config = text(320, 142, hmUI.data_type.HUMIDITY, fontArr, rootPath + 'font/bfh.png', '', '', '', rootPath + 'font/none.png')
                            right_bg_config = bg(281, 147, rootPath + 'blueLevel/10.png', 96)
                            right_level_config = level(281, 147, blueArr, hmUI.data_type.HUMIDITY)
                            right_point_config = point('', '', '', '', '', '', '', '')

                            right_icon.setProperty(hmUI.prop.MORE, right_icon_config);
                            right_text.setProperty(hmUI.prop.MORE, right_text_config);
                            right_bg.setProperty(hmUI.prop.MORE, right_bg_config);
                            right_level.setProperty(hmUI.prop.MORE, right_level_config);
                            right_point.setProperty(hmUI.prop.MORE, right_point_config)
                            break;
                        case
                        hmUI.edit_type.ALTIMETER:
                            right_icon_config = Icon(331, 198, rootPath + '/icon/KPA.png')
                            right_text_config = text(318, 142, hmUI.data_type.ALTIMETER, fontArr, '', '', '', '', rootPath + 'font/none.png')
                            right_bg_config = bg(281, 147, rootPath + 'blueLevel/10.png', 96)
                            right_level_config = level(281, 147, blueArr, hmUI.data_type.ALTIMETER)
                            right_point_config = point('', '', '', '', '', '', '', '')

                            right_icon.setProperty(hmUI.prop.MORE, right_icon_config);
                            right_text.setProperty(hmUI.prop.MORE, right_text_config);
                            right_bg.setProperty(hmUI.prop.MORE, right_bg_config);
                            right_level.setProperty(hmUI.prop.MORE, right_level_config);
                            right_point.setProperty(hmUI.prop.MORE, right_point_config)
                            break;
                    }

                    //bottom
                    let bottom_groupX = 85;
                    let bottom_groupY = 267
                    let bottom_groupArr = [{
                            type: hmUI.edit_type.HEART,
                            preview: rootPath + "widgetPreview/line.png"
                        },
                        {
                            type: hmUI.edit_type.SLEEP,
                            preview: rootPath + "widgetPreview/bar.png"
                        },
                    ]
                    let editGroup3 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                        edit_id: 104,
                        x: bottom_groupX,
                        y: bottom_groupY,
                        w: 284,
                        h: 152,
                        select_image: rootPath + "select/select2.png",
                        un_select_image: rootPath + "select/unselect2.png",
                        default_type: hmUI.edit_type.HEART,
                        optional_types: bottom_groupArr,
                        count: bottom_groupArr.length,
                        tips_BG: rootPath + "tip/bgTips.png",
                        tips_x: 90,
                        tips_y: -38,
                        tips_width:104,
                        tips_margin:10
                    });

                    let editType3 = editGroup3.getProperty(hmUI.prop.CURRENT_TYPE);
                    let bottom_bg_config = null
                    let bottom_line_config = null
                    switch (editType3) {
                        case
                        hmUI.edit_type.SLEEP:
                            for (let i = 0; i < 50; i++) {
                                let rect = new Rect()
                                rectArr.push(rect)
                            }
                            var jstime = hmSensor.createSensor(hmSensor.id.TIME);
                            var is24 = jstime.is24Hour;
                            if (is24) {
                                bottom_bg_config = bg(110, 267, rootPath + 'lineChart/sleepBg.png')
                            } else {
                                bottom_bg_config = bg(110, 267, rootPath + 'lineChart/sleepBg2.png')
                            }
                            bottom_bg.setProperty(hmUI.prop.MORE, bottom_bg_config);
                            const sleepDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                                resume_call: (function () {
                                    getSleepData()
                                }),
                                pause_call: (function () {
                                    console.log('ui pause');
                                })
                            })
                            break;
                        case
                        hmUI.edit_type.HEART:
                            var jstime = hmSensor.createSensor(hmSensor.id.TIME);
                            var is24 = jstime.is24Hour;
                            if (is24) {
                                bottom_bg_config = bg(90, 267, rootPath + 'lineChart/heartBg.png')
                            } else {
                                bottom_bg_config = bg(90, 267, rootPath + 'lineChart/heartBg2.png')
                            }
                            bottom_bg.setProperty(hmUI.prop.MORE, bottom_bg_config);
                            let heartArr = hmSensor.createSensor(hmSensor.id.HEART).today;
                            let min_heart = Math.min(...heartArr)
                            let max_heart = Math.max(...heartArr)
                            let maxText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                                x: 334,
                                y: 302,
                                text: max_heart,
                                type: hmUI.data_type.HEART,
                                font_array: fontArr,
                                h_space: 0,
                                align_h: hmUI.align.LEFT,
                                padding: false,
                                isCharacter: true,
                            });
                            let minText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                                x: 334,
                                y: 352,
                                text: min_heart,
                                type: hmUI.data_type.HEART,
                                font_array: fontArr,
                                h_space: 0,
                                align_h: hmUI.align.LEFT,
                                padding: false,
                                isCharacter: true,
                            });
                            let heart_num = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                                x: 188,
                                y: 402,
                                type: hmUI.data_type.HEART,
                                font_array: fontArr,
                                h_space: 0,
                                align_h: hmUI.align.CENTER_H,
                                padding: false,
                                isCharacter: true,
                                invalid_image: rootPath + "font/none.png",
                            });
                            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                                resume_call: (function () {
                                    var jstime = hmSensor.createSensor(hmSensor.id.TIME);
                                    var is24 = jstime.is24Hour;
                                    if (is24) {
                                        bottom_bg_config = bg(90, 267, rootPath + 'lineChart/heartBg.png')
                                    } else {
                                        bottom_bg_config = bg(90, 267, rootPath + 'lineChart/heartBg2.png')
                                    }
                                    bottom_bg.setProperty(hmUI.prop.MORE, bottom_bg_config);
                                    let heartArr = hmSensor.createSensor(hmSensor.id.HEART).today;
                                    let min_heart = Math.min(...heartArr)
                                    let max_heart = Math.max(...heartArr)
                                    maxText.setProperty(hmUI.prop.MORE, {
                                        x: 334,
                                        y: 302,
                                        text: max_heart,
                                        type: hmUI.data_type.HEART,
                                        font_array: fontArr,
                                        h_space: 0,
                                        align_h: hmUI.align.LEFT,
                                        padding: false,
                                        isCharacter: true,
                                    });
                                    minText.setProperty(hmUI.prop.MORE, {
                                        x: 334,
                                        y: 352,
                                        text: min_heart,
                                        type: hmUI.data_type.HEART,
                                        font_array: fontArr,
                                        h_space: 0,
                                        align_h: hmUI.align.LEFT,
                                        padding: false,
                                        isCharacter: true,
                                    });
                                    heart_num.setProperty(hmUI.prop.MORE, {
                                        x: 188,
                                        y: 402,
                                        type: hmUI.data_type.HEART,
                                        font_array: fontArr,
                                        h_space: 0,
                                        align_h: hmUI.align.CENTER_H,
                                        padding: false,
                                        isCharacter: true,
                                        invalid_image: rootPath + "font/none.png",
                                    });

                                }),
                                pause_call: (function () {
                                    console.log('ui pause');
                                }),
                            });

                            let bottom_line = hmUI.createWidget(hmUI.widget.GRADKIENT_POLYLINE, {
                                x: 90,
                                y: 307,
                                w: 237,
                                h: 57,
                                type: hmUI.data_type.HEART,
                            });
                            let heart_s = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                                x: 238,
                                y: 402,
                                text: 'BPM',
                                type: hmUI.data_type.HEART,
                                font_array: fontArr,
                                h_space: 2,
                                align_h: hmUI.align.CENTER_H,
                                padding: false,
                                isCharacter: true,
                                unit_sc: rootPath + "font/bpm.png",
                                unit_tc: rootPath + "font/bpm.png",
                                unit_en: rootPath + "font/bpm.png",
                            });

                            break;
                    }
                    let pointer = null //指针控件
                    function pointer_fn() {
                        let pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER, {
                            edit_id: 120,
                            x: 0,
                            y: 0,
                            config: pointerConfig,
                            count: pointerConfig.length,
                            default_id: 1,
                            fg: rootPath + '/mask/bgmask.png',
                            tips_x: 178,
                            tips_y: 408,
                            tips_bg: rootPath + '/tip/bgTips.png',
                            tips_width:104,
                            tips_margin:10
                        });
                        const screenType = hmSetting.getScreenType();
                        const aodModel = screenType == hmSetting.screen_type.AOD;
                        const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG, !aodModel);
                        pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp)
                    }
                    pointer_fn()
                    //70%msk
                    mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
                        x: 0,
                        y: 0,
                        w: 454,
                        h: 454,
                        src: rootPath + "mask/70mask.png",
                        show_level: hmUI.show_level.ONLY_EDIT,
                    });
                }
            },

            onInit() {
                console.log('index page.js on init invoke')
                this.init_view();

            },

            onReady() {
                console.log('index page.js on ready invoke')
            },

            onShow() {
                console.log('index page.js on show invoke')
            },

            onHide() {
                console.log('index page.js on hide invoke')
            },

            onDestory() {
                console.log('index page.js on destory invoke')
            },
        });
        /*
         * end js
         */
    })()
} catch (e) {
    console.log(e)
}