try {
    (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;

        var __$$module$$__ = __$$app$$__.current;
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        /*
    * huamiOS bundle tool v1.0.17
    * Copyright © Huami. All Rights Reserved
    */
        'use strict';

        console.log("----->>>current")
        console.log(__$$hmAppManager$$__.currentApp.pid)
        console.log(__$$hmAppManager$$__.currentApp.current)
        const WIDGET_LEFT_ID = 101;
        const WIDGET_TOP_ID = 102;
        const WIDGET_BOTTOM_ID = 103;

        const WIDGET_BG_ID = 106;
        const WIDGET_TOP = 1;
        const WIDGET_LEFT = 2;
        const WIDGET_BOTTOM = 3;

        const WIDGET_EDIT_SIZE = 145;
        const WIDGET_TIPS_WIDTH = 104;
        const ROOTPATH = "images/";
        const WIDGET_BG_PATH = ROOTPATH + "widget/bg/";
        const WIDGET_ICON_PATH = ROOTPATH + "widget/icon/";
        const WIDGET_POINTER_PATH = ROOTPATH + "widget/pointer.png";
        const WIDGET_FONT_ARRAY = [
            ROOTPATH + "widget/font/number_0.png",
            ROOTPATH + "widget/font/number_1.png",
            ROOTPATH + "widget/font/number_2.png",
            ROOTPATH + "widget/font/number_3.png",
            ROOTPATH + "widget/font/number_4.png",
            ROOTPATH + "widget/font/number_5.png",
            ROOTPATH + "widget/font/number_6.png",
            ROOTPATH + "widget/font/number_7.png",
            ROOTPATH + "widget/font/number_8.png",
            ROOTPATH + "widget/font/number_9.png",
        ];
        const pointPath = ROOTPATH + "pointer/";
        const widgetPreview = ROOTPATH + "widget_preview/"
        const TIPS_ROOT = ROOTPATH + "tips/"
 
        // const  "images/tips/bg_tips.png" = TIPS_ROOT + "bg_tips.png";
        const BGROOT = ROOTPATH + "bg_edit/"
        let select = null

        let editBg = null
        let topWidget = null
        let leftWidget = null
        let bottomWidget = null
        let mask = null

        let pointer;
        let week = null;
        let day = null;


        const logger = DeviceRuntimeCore.HmLogger.getLogger("sanjiao");
        __$$module$$__.module = DeviceRuntimeCore.Page({
            parseWidgetConfig(editType) {
                let config = {
                    bgPath: null, //背景图
                    iconPath: null, //图标
                    dataType: null,//数据类型
                    nonePath:  ROOTPATH + "img/invalid.png",//无数据的图片
                    unitEnPath: null,//单位
                    unitScPath: null,
                    unitTcPath: null,
                    dot_image: null,
                    negative_image:null,
                    startAngle: 0, //指针开始角度
                    endAngle: 360, //指针结束角度
                };
                switch (editType) {
                    case hmUI.edit_type.STEP:
                        config.bgPath = "steps_bg.png";
                        config.nonePath = null;//无数据时显示 0 ;
                        config.dataType = hmUI.data_type.STEP;
                        break;
                    case hmUI.edit_type.CAL:
                        config.bgPath = "kcal_bg.png";
                        config.nonePath = null;//无数据时显示 0 ;
                        config.dataType = hmUI.data_type.CAL;
                        break;
                    case hmUI.edit_type.PAI_WEEKLY:
                        config.bgPath = "pai_bg.png";
                        config.nonePath = null; //无数据时显示 0 ;
                        config.dataType = hmUI.data_type.PAI_WEEKLY;
                        break;
                    case hmUI.edit_type.DISTANCE:
                        config.bgPath = "dist_bg.png";
                        config.dataType = hmUI.data_type.DISTANCE;
                        config.dot_image =   ROOTPATH + "img/dot.png";//小数点图片
                        break;
                    case hmUI.edit_type.KPA:
                        config.bgPath = "kpa_bg.png";
                        config.dataType = hmUI.data_type.KPA;
                        break;
                    case hmUI.edit_type.BATTERY:
                        config.bgPath = "power_bg.png";
                        config.dataType = hmUI.data_type.BATTERY;
                        break;
                    case hmUI.edit_type.STAND:
                        config.bgPath = "stand_bg.png";
                        config.dot_image =   ROOTPATH + "img/line.png";//小数点图片
                        config.nonePath = null; //无数据时显示 0 ;
                        config.dataType = hmUI.data_type.STAND;
                        break;
                    case hmUI.edit_type.SPO2:
                        config.bgPath = "spo2_bg.png";
                        //config.iconPath = "spo2.png";
                        config.dataType = hmUI.data_type.SPO2;
                        break;
                    // case hmUI.edit_type.STRESS:
                    //     config.bgPath = "stress_bg.png";
                    //     //config.iconPath = "stress.png";
                    //     config.dataType = hmUI.data_type.STRESS;
                    //     break;
                    case hmUI.edit_type.WIND:
                        config.bgPath = "wind_bg.png";
                        config.dataType = hmUI.data_type.WIND;
                        break;
                    case hmUI.edit_type.HUMIDITY:
                        config.bgPath = "rh_bg.png";
                       // config.iconPath = "hum.png";
                       config.unitEnPath = ROOTPATH + "img/per.png";//单位
                       config.unitScPath = ROOTPATH + "img/per.png";//单位
                       config.unitTcPath = ROOTPATH + "img/per.png";//单位
                       config.dataType = hmUI.data_type.HUMIDITY;
                        break;
                    case hmUI.edit_type.UVI:
                        config.bgPath = "uvi_bg.png";
                        config.dataType = hmUI.data_type.UVI;
                        break;
                    // case hmUI.edit_type.AQI:
                    //     config.bgPath = "aqi_bg.png";
                    //     config.dataType = hmUI.data_type.AQI;
                    //     break;
                    case hmUI.edit_type.TEMPERATURE:
                        //TODO
                        config.bgPath = "temp_bg.png";
                        config.unitEnPath = ROOTPATH + "img/degree.png";//单位
                        config.unitScPath = ROOTPATH + "img/degree.png";//单位
                        config.unitTcPath = ROOTPATH + "img/degree.png";//单位
                        config.negative_image = ROOTPATH + "img/minus.png";//单位
                        config.dataType = hmUI.data_type.WEATHER_CURRENT;
                        break;
                    case hmUI.edit_type.HEART:
                        //TODO
                        config.bgPath = "bpm_bg.png";
                        config.dataType = hmUI.data_type.HEART;
                        break;
                    default:
                      
                        return config;
                }
                if (config.bgPath != null) {
                    config.bgPath = WIDGET_BG_PATH + config.bgPath;
                }
                // if (config.iconPath != null) {
                //     config.iconPath = WIDGET_ICON_PATH + config.iconPath;
                // }
                return config;
            },
            drawWidget(widgetType, editType) {
                let bgX = 0;
                let bgY = 0;
                switch (widgetType) {
                    case WIDGET_TOP:
                        bgX = 158;
                        bgY = 49;
                        break;
                    case WIDGET_LEFT:
                        bgX = 45;
                        bgY = 158;
                        break;
                    case WIDGET_BOTTOM:
                  
                        bgX = 160;
                        bgY = 267;
                        break;
                    default:
                      
                        return;
                }
                const bgSize = 138;
                const iconX = bgX + 51;
                const iconY = bgY + 17;
                const textX = bgX + 2;
                const textY = bgY + 32; //
                const textWidth = 134; // 16
                const textHeight = 34;//  22
                const iconSize = 32;
                const config = this.parseWidgetConfig(editType);
                if (config.bgPath == null) {
             
                    return;
                }
                // if (config.iconPath == null) {
         
                //     return;
                // }
                if (config.dataType == null) {
              
                    return;
                }
                //widgetbg
                hmUI.createWidget(hmUI.widget.IMG,{
                    x:bgX,
                    y:bgY,
                    w:bgSize,
                    h:bgSize,
                    src:config.bgPath,
                });

                let dataProp = {
                    x:textX,
                    y:textY,
                    w:textWidth,
                    h:textHeight,
                    align_h: hmUI.align.CENTER_H,
                    type:config.dataType,
                    h_space:1,
                    font_array:WIDGET_FONT_ARRAY,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                };
                if(config.unitEnPath != null){
                    dataProp.unit_en = config.unitEnPath;
                }
                if(config.unitScPath != null){
                    dataProp.unit_sc = config.unitScPath;
                }
                if(config.unitTcPath != null){
                    dataProp.unit_tc = config.unitTcPath;
                }
                if(config.nonePath != null){
                    dataProp.invalid_image = config.nonePath;
                }
                if(config.negativeImage != null){
                    dataProp.negative_image = config.negativeImage;
                }
                if(config.dot_image != null){
                    dataProp.dot_image = config.dot_image;
                }
                //数据
                hmUI.createWidget(hmUI.widget.TEXT_IMG,dataProp);
                if(config.dataType == hmUI.data_type.DISTANCE){
                  config.dataType = hmUI.data_type.STEP
                }
                //指针
                hmUI.createWidget(hmUI.widget.IMG_POINTER,{
                    center_x:bgX + bgSize/2,
                    center_y:bgY + bgSize/2,
                    x:10,
                    y:60,
                    src: WIDGET_POINTER_PATH,
                    type: config.dataType,
                    start_angle:config.startAngle,
                    end_angle:config.endAngle,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                });
            },
            init_view() {
                let fontArray = [
                    ROOTPATH + "date/date_0.png",
                    ROOTPATH + "date/date_1.png",
                    ROOTPATH + "date/date_2.png",
                    ROOTPATH + "date/date_3.png",
                    ROOTPATH + "date/date_4.png",
                    ROOTPATH + "date/date_5.png",
                    ROOTPATH + "date/date_6.png",
                    ROOTPATH + "date/date_7.png",
                    ROOTPATH + "date/date_8.png",
                    ROOTPATH + "date/date_9.png",
                ];

                select = ROOTPATH + "select/"

                editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
                    edit_id: WIDGET_BG_ID,
                    x: 0,
                    y: 0,
                    bg_config: [
                        { id: 1, preview: BGROOT + "bg_edit_1.png", path: BGROOT + "preview_1.png" },
                        { id: 2, preview: BGROOT + "bg_edit_2.png", path: BGROOT + "preview_2.png" },
                        { id: 3, preview: BGROOT + "bg_edit_3.png", path: BGROOT + "preview_3.png" },
                    ],
                    count: 3,
                    default_id: 1,
                    fg: BGROOT + "fg.png",
                    tips_x: 165,
                    tips_y: 406,
                    tips_bg:  "images/tips/bg_tips.png",
                    tips_width: 132,
                    tips_margin: 10,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                });

                let widgetOptionalArray = [
                    { type: hmUI.edit_type.STEP, preview: widgetPreview + "step.png" },
                
                    { type: hmUI.edit_type.CAL, preview: widgetPreview + "kcal.png" },
                    { type: hmUI.edit_type.PAI_WEEKLY, preview: widgetPreview + "pai.png" },
                    { type: hmUI.edit_type.DISTANCE, preview: widgetPreview + "dist.png" },
                    { type: hmUI.edit_type.WIND, preview: widgetPreview + "wind.png" },
                    { type: hmUI.edit_type.BATTERY, preview: widgetPreview + "power.png" },
                    { type: hmUI.edit_type.STAND, preview: widgetPreview + "stand.png" },
                    { type: hmUI.edit_type.SPO2, preview: widgetPreview + "spo2.png" },
                    // { type: hmUI.edit_type.STRESS, preview: widgetPreview + "stress.png" },
                    { type: hmUI.edit_type.TEMPERATURE, preview: widgetPreview + "temp.png" },
                    { type: hmUI.edit_type.HUMIDITY, preview: widgetPreview + "rh.png" },
                    { type: hmUI.edit_type.UVI, preview: widgetPreview + "uvi.png" },
                    // { type: hmUI.edit_type.AQI, preview: widgetPreview + "aqi.png" },
                    { type: hmUI.edit_type.HEART, preview: widgetPreview + "bpm.png" },

                ];
    
                let groupX = 152;
         
                let groupY = 43;
                topWidget = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: WIDGET_TOP_ID,
                    x: groupX,
                    y: groupY,
                
                    // w: WIDGET_EDIT_SIZE,
                    w: 148,
                    // h: WIDGET_EDIT_SIZE,
                    h: 148,
                    select_image: select + "select.png",
                    un_select_image: select + "unselect.png",
                    default_type: hmUI.edit_type.BATTERY,
                    optional_types: widgetOptionalArray,
                    count: widgetOptionalArray.length,
                    tips_BG: "images/tips/bg_tips.png",
            
                    tips_x: 9,
                    // tips_x: 4,
                    tips_y: 7 - groupY, 
                    tips_width: 132,
                    tips_margin: 10,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                });
                var editType = topWidget.getProperty(hmUI.prop.CURRENT_TYPE);
                this.drawWidget(WIDGET_TOP,editType);

                groupX = 40;
                groupY = 154;
                leftWidget = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: WIDGET_LEFT_ID,
                    x: groupX,
                    y: groupY,
             
                    w: WIDGET_EDIT_SIZE+4,
                    h: WIDGET_EDIT_SIZE+4,
                    select_image: select + "select.png",
                    un_select_image: select + "unselect.png",
                    default_type: hmUI.edit_type.HEART,
                    optional_types: widgetOptionalArray,
                    count: widgetOptionalArray.length,
                    tips_BG:  "images/tips/bg_tips.png",
             
                    tips_x: 9,
                    tips_y: 116 - groupY,
          
                    tips_width: 132,
                    tips_margin: 10,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                });
                editType = leftWidget.getProperty(hmUI.prop.CURRENT_TYPE);
                this.drawWidget(WIDGET_LEFT,editType);

           
                groupX = 155;
                groupY = 262;
         
                bottomWidget = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: WIDGET_BOTTOM_ID,
                    x: groupX,
                    y: groupY,
        
                    w: WIDGET_EDIT_SIZE+4,
                    h: WIDGET_EDIT_SIZE+4,
                    select_image: select + "select.png",
                    un_select_image: select + "unselect.png",
                    default_type: hmUI.edit_type.STEP,
                    optional_types: widgetOptionalArray,
                    count: widgetOptionalArray.length,
                    tips_BG:  "images/tips/bg_tips.png",
        
                    tips_x: 9,
                    tips_y: 223 - groupY,
     
                    tips_width: 132,
                    tips_margin: 10,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                });
                editType = bottomWidget.getProperty(hmUI.prop.CURRENT_TYPE);
                this.drawWidget(WIDGET_BOTTOM,editType);

                let weekArray = [
                    ROOTPATH + "week/week_1.png",
                    ROOTPATH + "week/week_2.png",
                    ROOTPATH + "week/week_3.png",
                    ROOTPATH + "week/week_4.png",
                    ROOTPATH + "week/week_5.png",
                    ROOTPATH + "week/week_6.png",
                    ROOTPATH + "week/week_7.png",
                ];
                week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {

                    x: 294,
                    y: 215,
                    week_tc: weekArray,
                    week_sc: weekArray,
                    week_en: weekArray,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                });
                day = hmUI.createWidget(hmUI.widget.IMG_DATE, {

                    day_startX: 366,
                    day_startY: 216,
                    day_zero: true,
                    day_en_array: fontArray,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                });

                const centerXValue = 227;
                const centerYValue = 227;
                // const secondProp = {
                //         centerX: centerXValue,
                //         centerY: centerYValue,
                //         posX: 13,
                //         posY: 227,
                //         path: pointPath + "hand_all_s.png",
                // };
                const pointerConfig = [
                    {
                        id: 1,
                        hour: {
                            centerX: centerXValue,
                            centerY: centerYValue,
                            posX: 23,
                            posY: 150,
                            path: pointPath + "hand_1_h.png",
                        },
                        minute: {
                            centerX: centerXValue,
                            centerY: centerYValue,
                            posX: 23,
                            posY: 226,
                            path: pointPath + "hand_1_m.png",
                        },
                        second:{
                            centerX: centerXValue,
                            centerY: centerYValue,
                            posX: 13,
                            posY: 227,
                            path: pointPath + "hand_1_s.png",
                        },
                        preview:pointPath + "hand_1_p.png",
                    },
                    {
                        id: 2,
                        hour: {
                            centerX: centerXValue,
                            centerY: centerYValue,
                            posX: 23,
                            posY: 148,
                            path: pointPath + "hand_2_h.png",
                        },
                        minute: {
                            centerX: centerXValue,
                            centerY: centerYValue,
                            posX: 22,
                            posY: 236,
                            path: pointPath + "hand_2_m.png",
                        },
                        preview:pointPath + "hand_2_p.png",
                       // second: secondProp,  样式 2 无秒针
                    },
                    {
                        id: 3,
                        hour: {
                            centerX: centerXValue,
                            centerY: centerYValue,
                            posX: 24,
                            posY: 153,
                            path: pointPath + "hand_3_h.png",
                        },
                        minute: {
                            centerX: centerXValue,
                            centerY: centerYValue,
                            posX: 24,
                            posY: 213,
                            path: pointPath + "hand_3_m.png",
                        },
                        second:{
                            centerX: centerXValue,
                            centerY: centerYValue,
                            posX: 14,
                            posY: 226,
                            path: pointPath + "hand_3_s.png",
                        },
                        preview:pointPath + "hand_3_p.png",
                    },

                ];

                let pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER,{
                    edit_id: 120,
                    x: 0,
                    y: 0,
                    config:pointerConfig,
                    count: pointerConfig.length,
                    default_id: 1,
                    fg: BGROOT + "fg.png",
                    tips_x: 165,
                    tips_y: 406,
                    tips_bg:  "images/tips/bg_tips.png",
                    tips_width: 132,
                    tips_margin:10
                    
                });
                const screenType = hmSetting.getScreenType();
                const aodModel = screenType == hmSetting.screen_type.AOD;
                const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG,!aodModel);
                pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp);

                mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
                    x: 0,
                    y: 0,
                    w: 454,
                    h: 454,
                    src: ROOTPATH + "mask70.png",
                    show_level: hmUI.show_level.ONLY_EDIT,
                });

            },

            onInit() {
                console.log('index page.js on init invoke')

                this.init_view();
            },

            onReady() {
                console.log('index page.js on ready invoke')
            },

            onShow() {
                console.log('index page.js on show invoke')
            },

            onHide() {
                console.log('index page.js on hide invoke')
            },

            onDestory() {
                console.log('index page.js on destory invoke')
            },
        });
        /*
        * end js
        */
    })()
} catch (e) {
    console.log(e)
}
