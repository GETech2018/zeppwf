try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_aacf2010342c47f99575cf842a5b9857 = '';
        let dateFormat = '';
        let dateFormatMap = '';
        let normal$_$text_e6c4e5d168b34304954d3c715cc367af = '';
        let normal$_$text_eee2f02bccd6452fa2d170240b345b86 = '';
        let normal$_$text_4aca5b4238904101ab629b26bed8c4e2 = '';
        let idle$_$text_cab9bf5b8ae74cfe8d5a66d0b8264ffc = '';
        let idle$_$text_f09052ea37734f52802e22c7f7811fc9 = '';
        let timeSensor = '';
        let batterySensor = '';
        const logger = Logger.getLogger('watchface6');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 454,
                    h: 454,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_aacf2010342c47f99575cf842a5b9857 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 77,
                    y: 84,
                    w: 300,
                    h: 40,
                    text: '[DAY_Z].[MON_Z].[YEAR]',
                    color: '0xFF000000',
                    text_size: 32,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_e6c4e5d168b34304954d3c715cc367af = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 77,
                    y: 43,
                    w: 300,
                    h: 40,
                    text: '[WEEK_EN_F]',
                    color: '0xFF000000',
                    text_size: 32,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_eee2f02bccd6452fa2d170240b345b86 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 52,
                    y: 192,
                    w: 350,
                    h: 70,
                    text: '[HOUR_24_Z]:[MIN_Z]:[SEC_Z]',
                    color: '0xFF000000',
                    text_size: 60,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_4aca5b4238904101ab629b26bed8c4e2 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 167,
                    y: 409,
                    w: 120,
                    h: 40,
                    text: '[BATT_PER]%',
                    color: '0xFF000000',
                    text_size: 24,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                idle$_$text_cab9bf5b8ae74cfe8d5a66d0b8264ffc = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 52,
                    y: 192,
                    w: 350,
                    h: 70,
                    text: '[HOUR_24_Z]:[MIN_Z]:[SEC_Z]',
                    color: '0xFFffffff',
                    text_size: 60,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                idle$_$text_f09052ea37734f52802e22c7f7811fc9 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 167,
                    y: 409,
                    w: 120,
                    h: 40,
                    text: '[BATT_PER]%',
                    color: '0xFFffffff',
                    text_size: 24,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                if (!timeSensor) {
                    timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                }
                if (!batterySensor) {
                    batterySensor = hmSensor.createSensor(hmSensor.id.BATTERY);
                }
                timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_aacf2010342c47f99575cf842a5b9857.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }.${ String(timeSensor.month).padStart(2, '0') }.${ String(timeSensor.day).padStart(2, '0') }` });
                        },
                        () => {
                            normal$_$text_aacf2010342c47f99575cf842a5b9857.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }.${ String(timeSensor.month).padStart(2, '0') }.${ timeSensor.year }` });
                        },
                        () => {
                            normal$_$text_aacf2010342c47f99575cf842a5b9857.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }.${ String(timeSensor.day).padStart(2, '0') }.${ timeSensor.year }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                    const WEEK_EN_F = function (val) {
                        const valueMap = {
                            '1': 'Monday',
                            '2': 'Tuesday',
                            '3': 'Wednesday',
                            '4': 'Thursday',
                            '5': 'Friday',
                            '6': 'Saturday',
                            '7': 'Sunday'
                        };
                        return valueMap[val];
                    };
                    normal$_$text_e6c4e5d168b34304954d3c715cc367af.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_F(timeSensor.week) }` });
                }), timeSensor.addEventListener(timeSensor.event.MINUTEEND, function () {
                    normal$_$text_eee2f02bccd6452fa2d170240b345b86.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }:${ String(timeSensor.minute).padStart(2, '0') }:${ String(timeSensor.second).padStart(2, '0') }` });
                    idle$_$text_cab9bf5b8ae74cfe8d5a66d0b8264ffc.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }:${ String(timeSensor.minute).padStart(2, '0') }:${ String(timeSensor.second).padStart(2, '0') }` });
                }), batterySensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_4aca5b4238904101ab629b26bed8c4e2.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }%` });
                    idle$_$text_f09052ea37734f52802e22c7f7811fc9.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }%` });
                });
                normal$_$text_eee2f02bccd6452fa2d170240b345b86.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }:${ String(timeSensor.minute).padStart(2, '0') }:${ String(timeSensor.second).padStart(2, '0') }` });
                idle$_$text_cab9bf5b8ae74cfe8d5a66d0b8264ffc.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }:${ String(timeSensor.minute).padStart(2, '0') }:${ String(timeSensor.second).padStart(2, '0') }` });
                timer.createTimer(0, 1000, function (timeSensor2) {
                    normal$_$text_eee2f02bccd6452fa2d170240b345b86.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor2.hour).padStart(2, '0') }:${ String(timeSensor2.minute).padStart(2, '0') }:${ String(timeSensor2.second).padStart(2, '0') }` });
                    idle$_$text_cab9bf5b8ae74cfe8d5a66d0b8264ffc.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor2.hour).padStart(2, '0') }:${ String(timeSensor2.minute).padStart(2, '0') }:${ String(timeSensor2.second).padStart(2, '0') }` });
                }, timeSensor);
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                normal$_$text_aacf2010342c47f99575cf842a5b9857.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }.${ String(timeSensor.month).padStart(2, '0') }.${ String(timeSensor.day).padStart(2, '0') }` });
                            },
                            () => {
                                normal$_$text_aacf2010342c47f99575cf842a5b9857.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }.${ String(timeSensor.month).padStart(2, '0') }.${ timeSensor.year }` });
                            },
                            () => {
                                normal$_$text_aacf2010342c47f99575cf842a5b9857.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }.${ String(timeSensor.day).padStart(2, '0') }.${ timeSensor.year }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                        const WEEK_EN_F = function (val) {
                            const valueMap = {
                                '1': 'Monday',
                                '2': 'Tuesday',
                                '3': 'Wednesday',
                                '4': 'Thursday',
                                '5': 'Friday',
                                '6': 'Saturday',
                                '7': 'Sunday'
                            };
                            return valueMap[val];
                        };
                        normal$_$text_e6c4e5d168b34304954d3c715cc367af.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_F(timeSensor.week) }` });
                        normal$_$text_eee2f02bccd6452fa2d170240b345b86.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }:${ String(timeSensor.minute).padStart(2, '0') }:${ String(timeSensor.second).padStart(2, '0') }` });
                        normal$_$text_4aca5b4238904101ab629b26bed8c4e2.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }%` });
                        idle$_$text_cab9bf5b8ae74cfe8d5a66d0b8264ffc.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }:${ String(timeSensor.minute).padStart(2, '0') }:${ String(timeSensor.second).padStart(2, '0') }` });
                        idle$_$text_f09052ea37734f52802e22c7f7811fc9.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }%` });
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}