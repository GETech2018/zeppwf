try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_baae548c4eb54fe1a634b83ef3591509 = '';
        let normal$_$text_b9e84b4069824a3b86ead61237a97ea7 = '';
        let normal$_$text_79cbe4b4fb814f9f88ad2d92608056f3 = '';
        let dateFormat = '';
        let dateFormatMap = '';
        let normal$_$text_b0f5b33ba5e44177979ecc9a0398ae42 = '';
        let normal$_$text_e374d7210ec5425f8491c284d3323248 = '';
        let normal$_$text_6c7fe9aa5cb64379bc5b80a74194f52d = '';
        let normal$_$text_d6a31faed28a439ab176dae4f97322fb = '';
        let normal$_$text_cfaec398fce041e891a5fa10d8792651 = '';
        let normal$_$text_57e09371a6ec4fdfbb8feb7eef563d4a = '';
        let idle$_$text_066ff7aeb5e74f73b73ba941de76033e = '';
        let idle$_$text_b0e538dd501e419c85919ec13669ed54 = '';
        let idle$_$text_2860e7ad763341269b6ab25784aa51b7 = '';
        let idle$_$text_6165cac081344ef1a5d11bcd8ada6ef7 = '';
        let timeSensor = '';
        let heartSensor = '';
        let batterySensor = '';
        let calorieSensor = '';
        const logger = Logger.getLogger('watchface6');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 454,
                    h: 454,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_baae548c4eb54fe1a634b83ef3591509 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 76,
                    y: 279,
                    w: 300,
                    h: 60,
                    text: '[HOUR_24_Z]:[MIN_Z]:[SEC_Z]',
                    color: '0xFFABABAB',
                    text_size: 60,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_b9e84b4069824a3b86ead61237a97ea7 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 126,
                    y: 389,
                    w: 200,
                    h: 40,
                    text: '[WEEK_EN_F]',
                    color: '0xFFABABAB',
                    text_size: 18,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_79cbe4b4fb814f9f88ad2d92608056f3 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 176,
                    y: 343,
                    w: 100,
                    h: 40,
                    text: '[YEAR]-[MON_Z]-[DAY_Z]',
                    color: '0xFFABABAB',
                    text_size: 17,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_b0f5b33ba5e44177979ecc9a0398ae42 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 244,
                    y: 101,
                    w: 120,
                    h: 30,
                    text: '[HR_Z]',
                    color: '0xFF000000',
                    text_size: 24,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_e374d7210ec5425f8491c284d3323248 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 256,
                    y: 59,
                    w: 120,
                    h: 30,
                    text: '[BATT_PER]%',
                    color: '0xFF000000',
                    text_size: 24,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_6c7fe9aa5cb64379bc5b80a74194f52d = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 244,
                    y: 134,
                    w: 160,
                    h: 30,
                    text: 'HEART RATE',
                    color: '0xFF000000',
                    text_size: 24,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_d6a31faed28a439ab176dae4f97322fb = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 95,
                    y: 59,
                    w: 160,
                    h: 30,
                    text: 'BATTERY',
                    color: '0xFF000000',
                    text_size: 24,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.RIGHT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_cfaec398fce041e891a5fa10d8792651 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 55,
                    y: 133,
                    w: 160,
                    h: 30,
                    text: 'STEP COUNT',
                    color: '0xFF000000',
                    text_size: 24,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.RIGHT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_57e09371a6ec4fdfbb8feb7eef563d4a = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 96,
                    y: 101,
                    w: 120,
                    h: 30,
                    text: '[CAL]',
                    color: '0xFF000000',
                    text_size: 24,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.RIGHT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 76,
                    y: 205,
                    type: hmUI.data_type.DISTANCE,
                    font_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '14.png',
                    unit_tc: '14.png',
                    unit_en: '14.png',
                    imperial_unit_sc: '15.png',
                    imperial_unit_tc: '15.png',
                    imperial_unit_en: '15.png',
                    dot_image: '13.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 149,
                    y: 187,
                    src: '16.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 315,
                    y: 204,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: [
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '29.png',
                    unit_tc: '29.png',
                    unit_en: '29.png',
                    negative_image: '28.png',
                    invalid_image: '27.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 211,
                    y: 15,
                    src: '30.png',
                    type: hmUI.system_status.LOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                idle$_$text_066ff7aeb5e74f73b73ba941de76033e = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 76,
                    y: 279,
                    w: 300,
                    h: 60,
                    text: '[HOUR_24_Z]:[MIN_Z]',
                    color: '0xFFABABAB',
                    text_size: 60,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                idle$_$text_b0e538dd501e419c85919ec13669ed54 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 126,
                    y: 389,
                    w: 200,
                    h: 40,
                    text: '[WEEK_EN_F]',
                    color: '0xFFABABAB',
                    text_size: 18,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                idle$_$text_2860e7ad763341269b6ab25784aa51b7 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 176,
                    y: 347,
                    w: 100,
                    h: 40,
                    text: '[YEAR]-[MON_Z]-[DAY_Z]',
                    color: '0xFFABABAB',
                    text_size: 17,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                idle$_$text_6165cac081344ef1a5d11bcd8ada6ef7 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 201,
                    y: 426,
                    w: 50,
                    h: 20,
                    text: '[BATT_PER]%',
                    color: '0xFFABABAB',
                    text_size: 14,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                if (!timeSensor) {
                    timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                }
                if (!heartSensor) {
                    heartSensor = hmSensor.createSensor(hmSensor.id.HEART);
                }
                if (!batterySensor) {
                    batterySensor = hmSensor.createSensor(hmSensor.id.BATTERY);
                }
                if (!calorieSensor) {
                    calorieSensor = hmSensor.createSensor(hmSensor.id.CALORIE);
                }
                timeSensor.addEventListener(timeSensor.event.MINUTEEND, function () {
                    normal$_$text_baae548c4eb54fe1a634b83ef3591509.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }:${ String(timeSensor.minute).padStart(2, '0') }:${ String(timeSensor.second).padStart(2, '0') }` });
                    idle$_$text_066ff7aeb5e74f73b73ba941de76033e.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }:${ String(timeSensor.minute).padStart(2, '0') }` });
                }), timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
                    const WEEK_EN_F = function (val) {
                        const valueMap = {
                            '1': 'Monday',
                            '2': 'Tuesday',
                            '3': 'Wednesday',
                            '4': 'Thursday',
                            '5': 'Friday',
                            '6': 'Saturday',
                            '7': 'Sunday'
                        };
                        return valueMap[val];
                    };
                    normal$_$text_b9e84b4069824a3b86ead61237a97ea7.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_F(timeSensor.week) }` });
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_79cbe4b4fb814f9f88ad2d92608056f3.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }-${ String(timeSensor.month).padStart(2, '0') }-${ String(timeSensor.day).padStart(2, '0') }` });
                        },
                        () => {
                            normal$_$text_79cbe4b4fb814f9f88ad2d92608056f3.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }-${ String(timeSensor.month).padStart(2, '0') }-${ timeSensor.year }` });
                        },
                        () => {
                            normal$_$text_79cbe4b4fb814f9f88ad2d92608056f3.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }-${ String(timeSensor.day).padStart(2, '0') }-${ timeSensor.year }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                    idle$_$text_b0e538dd501e419c85919ec13669ed54.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_F(timeSensor.week) }` });
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            idle$_$text_2860e7ad763341269b6ab25784aa51b7.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }-${ String(timeSensor.month).padStart(2, '0') }-${ String(timeSensor.day).padStart(2, '0') }` });
                        },
                        () => {
                            idle$_$text_2860e7ad763341269b6ab25784aa51b7.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }-${ String(timeSensor.month).padStart(2, '0') }-${ timeSensor.year }` });
                        },
                        () => {
                            idle$_$text_2860e7ad763341269b6ab25784aa51b7.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }-${ String(timeSensor.day).padStart(2, '0') }-${ timeSensor.year }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                }), heartSensor.addEventListener(heartSensor.event.LAST, function () {
                    normal$_$text_b0f5b33ba5e44177979ecc9a0398ae42.setProperty(hmUI.prop.MORE, { text: `${ String(heartSensor.last).padStart(3, '0') }` });
                }), batterySensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_e374d7210ec5425f8491c284d3323248.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }%` });
                    idle$_$text_6165cac081344ef1a5d11bcd8ada6ef7.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }%` });
                }), calorieSensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_57e09371a6ec4fdfbb8feb7eef563d4a.setProperty(hmUI.prop.MORE, { text: `${ calorieSensor.current }` });
                });
                normal$_$text_baae548c4eb54fe1a634b83ef3591509.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }:${ String(timeSensor.minute).padStart(2, '0') }:${ String(timeSensor.second).padStart(2, '0') }` });
                idle$_$text_066ff7aeb5e74f73b73ba941de76033e.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }:${ String(timeSensor.minute).padStart(2, '0') }` });
                timer.createTimer(0, 1000, function (timeSensor2) {
                    normal$_$text_baae548c4eb54fe1a634b83ef3591509.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor2.hour).padStart(2, '0') }:${ String(timeSensor2.minute).padStart(2, '0') }:${ String(timeSensor2.second).padStart(2, '0') }` });
                    idle$_$text_066ff7aeb5e74f73b73ba941de76033e.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor2.hour).padStart(2, '0') }:${ String(timeSensor2.minute).padStart(2, '0') }` });
                }, timeSensor);
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 0,
                    y: 0,
                    w: 0,
                    h: 0,
                    type: hmUI.data_type.DISTANCE,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 0,
                    y: 0,
                    w: 0,
                    h: 0,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        normal$_$text_baae548c4eb54fe1a634b83ef3591509.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }:${ String(timeSensor.minute).padStart(2, '0') }:${ String(timeSensor.second).padStart(2, '0') }` });
                        const WEEK_EN_F = function (val) {
                            const valueMap = {
                                '1': 'Monday',
                                '2': 'Tuesday',
                                '3': 'Wednesday',
                                '4': 'Thursday',
                                '5': 'Friday',
                                '6': 'Saturday',
                                '7': 'Sunday'
                            };
                            return valueMap[val];
                        };
                        normal$_$text_b9e84b4069824a3b86ead61237a97ea7.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_F(timeSensor.week) }` });
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                normal$_$text_79cbe4b4fb814f9f88ad2d92608056f3.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }-${ String(timeSensor.month).padStart(2, '0') }-${ String(timeSensor.day).padStart(2, '0') }` });
                            },
                            () => {
                                normal$_$text_79cbe4b4fb814f9f88ad2d92608056f3.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }-${ String(timeSensor.month).padStart(2, '0') }-${ timeSensor.year }` });
                            },
                            () => {
                                normal$_$text_79cbe4b4fb814f9f88ad2d92608056f3.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }-${ String(timeSensor.day).padStart(2, '0') }-${ timeSensor.year }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                        normal$_$text_b0f5b33ba5e44177979ecc9a0398ae42.setProperty(hmUI.prop.MORE, { text: `${ String(heartSensor.last).padStart(3, '0') }` });
                        normal$_$text_e374d7210ec5425f8491c284d3323248.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }%` });
                        normal$_$text_6c7fe9aa5cb64379bc5b80a74194f52d.setProperty(hmUI.prop.MORE, { text: `HEART RATE` });
                        normal$_$text_d6a31faed28a439ab176dae4f97322fb.setProperty(hmUI.prop.MORE, { text: `BATTERY` });
                        normal$_$text_cfaec398fce041e891a5fa10d8792651.setProperty(hmUI.prop.MORE, { text: `STEP COUNT` });
                        normal$_$text_57e09371a6ec4fdfbb8feb7eef563d4a.setProperty(hmUI.prop.MORE, { text: `${ calorieSensor.current }` });
                        idle$_$text_066ff7aeb5e74f73b73ba941de76033e.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }:${ String(timeSensor.minute).padStart(2, '0') }` });
                        idle$_$text_b0e538dd501e419c85919ec13669ed54.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_F(timeSensor.week) }` });
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                idle$_$text_2860e7ad763341269b6ab25784aa51b7.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }-${ String(timeSensor.month).padStart(2, '0') }-${ String(timeSensor.day).padStart(2, '0') }` });
                            },
                            () => {
                                idle$_$text_2860e7ad763341269b6ab25784aa51b7.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }-${ String(timeSensor.month).padStart(2, '0') }-${ timeSensor.year }` });
                            },
                            () => {
                                idle$_$text_2860e7ad763341269b6ab25784aa51b7.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }-${ String(timeSensor.day).padStart(2, '0') }-${ timeSensor.year }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                        idle$_$text_6165cac081344ef1a5d11bcd8ada6ef7.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }%` });
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}