try {
    (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;

        var __$$module$$__ = __$$app$$__.current;
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        /*
    * huamiOS bundle tool v1.0.17
    * Copyright © Huami. All Rights Reserved
    */
        'use strict';

        console.log("----->>>current")
        console.log(__$$hmAppManager$$__.currentApp.pid)
        console.log(__$$hmAppManager$$__.currentApp.current)
        const WIDGET_LEFT_ID = 101;
        const WIDGET_RIGHT_ID = 102;
        const WIDGET_LEFT = 1;
        const WIDGET_RIGHT = 2;

        const WIDGET_EDIT_SIZE = 122;
        const WIDGET_TIPS_WIDTH = 104;
        const ROOTPATH = "images/";

        const ROOTWEEK = ROOTPATH + "clever/week/"
        const ROOTDATE = ROOTPATH + "clever/date/"
        const ROOTHOUR = ROOTPATH + "clever/hour/"
        const MINHOUR = ROOTPATH + "clever/min/"

        const ROOTXP = ROOTPATH + "clever/xp_number/"

        const NUMBER_SMALL = ROOTPATH + "clever/date-s/"

        const widgetPreview = ROOTPATH + "clever/widget_preview/"

        const select = ROOTPATH + "clever/mask/"

        const ROOT_LEVEL_LEFT = [
            ROOTPATH + 'clever/level1/1.png',
            ROOTPATH + 'clever/level1/2.png',
            ROOTPATH + 'clever/level1/3.png',
            ROOTPATH + 'clever/level1/4.png',
            ROOTPATH + 'clever/level1/5.png',
            ROOTPATH + 'clever/level1/6.png',
        ]
        const ROOT_LEVEL_RIGHT = [
            ROOTPATH + 'clever/level2/1.png',
            ROOTPATH + 'clever/level2/2.png',
            ROOTPATH + 'clever/level2/3.png',
            ROOTPATH + 'clever/level2/4.png',
            ROOTPATH + 'clever/level2/5.png',
            ROOTPATH + 'clever/level2/6.png',
        ]

        const week_arr = [
            ROOTWEEK + '1.png',
            ROOTWEEK + '2.png',
            ROOTWEEK + '3.png',
            ROOTWEEK + '4.png',
            ROOTWEEK + '5.png',
            ROOTWEEK + '6.png',
            ROOTWEEK + '7.png',
        ]
        const dateImg = [
            ROOTDATE + 'data_0.png',
            ROOTDATE + 'data_1.png',
            ROOTDATE + 'data_2.png',
            ROOTDATE + 'data_3.png',
            ROOTDATE + 'data_4.png',
            ROOTDATE + 'data_5.png',
            ROOTDATE + 'data_6.png',
            ROOTDATE + 'data_7.png',
            ROOTDATE + 'data_8.png',
            ROOTDATE + 'data_9.png',
        ]
        let time_hour_Array = [
            ROOTHOUR + 'hour_0.png',
            ROOTHOUR + 'hour_1.png',
            ROOTHOUR + 'hour_2.png',
            ROOTHOUR + 'hour_3.png',
            ROOTHOUR + 'hour_4.png',
            ROOTHOUR + 'hour_5.png',
            ROOTHOUR + 'hour_6.png',
            ROOTHOUR + 'hour_7.png',
            ROOTHOUR + 'hour_8.png',
            ROOTHOUR + 'hour_9.png',
        ]
        let time_min_Array = [
            MINHOUR + 'min_0.png',
            MINHOUR + 'min_1.png',
            MINHOUR + 'min_2.png',
            MINHOUR + 'min_3.png',
            MINHOUR + 'min_4.png',
            MINHOUR + 'min_5.png',
            MINHOUR + 'min_6.png',
            MINHOUR + 'min_7.png',
            MINHOUR + 'min_8.png',
            MINHOUR + 'min_9.png',
        ]
        const xp_img_Array = [
            ROOTXP + '0.png',
            ROOTXP + '1.png',
            ROOTXP + '2.png',
            ROOTXP + '3.png',
            ROOTXP + '4.png',
            ROOTXP + '5.png',
            ROOTXP + '6.png',
            ROOTXP + '7.png',
            ROOTXP + '8.png',
            ROOTXP + '9.png',
        ]
        const number_small_Array = [
            NUMBER_SMALL + 'date_0.png',
            NUMBER_SMALL + 'date_1.png',
            NUMBER_SMALL + 'date_2.png',
            NUMBER_SMALL + 'date_3.png',
            NUMBER_SMALL + 'date_4.png',
            NUMBER_SMALL + 'date_5.png',
            NUMBER_SMALL + 'date_6.png',
            NUMBER_SMALL + 'date_7.png',
            NUMBER_SMALL + 'date_8.png',
            NUMBER_SMALL + 'date_9.png',
        ]



        const logger = DeviceRuntimeCore.HmLogger.getLogger("sanjiao");
        __$$module$$__.module = DeviceRuntimeCore.Page({
            parseWidgetConfig(editType, widgetType) {
                let config = {
                    bgPath: null, //背景图
                    iconPath: null, //图标
                    dataType: null,//数据类型
                    nonePath: null,//无数据的图片 
                    unitEnPath: null,//单位
                    unitScPath: null,
                    unitTcPath: null,
                    dwPath: null,
                    textX: 0,
                    textY: 0,
                };
                switch (editType) {
                    case hmUI.edit_type.PAI:
                        config.bgPath = "pai.png";
                        config.dataType = hmUI.data_type.PAI_WEEKLY;
                        config.textX = 20;
                        config.textY = 170;
                        break;
                    case hmUI.edit_type.BATTERY:
                        config.bgPath = "bat.png";
                        config.dataType = hmUI.data_type.BATTERY;
                        config.textX = 20;
                        config.textY = 170;
                        break;
                    case hmUI.edit_type.HEART:
                        config.bgPath = "heart.png";
                        config.dataType = hmUI.data_type.HEART;
                        config.textX = 20;
                        config.textY = 170;
                        // dataProp.invalid_image = 
                        break;
                    default:
                       
                        return config;
                }
                if (widgetType == WIDGET_LEFT) {
                    config.bgPath = ROOTPATH + 'clever/icon/left/' + config.bgPath;
                    config.textY = 120 + config.textY;
                }
                if (widgetType == WIDGET_RIGHT) {
                    config.bgPath = ROOTPATH + 'clever/icon/right/' + config.bgPath;
                    config.textX = 280 + config.textX;
                }
                config.nonePath = NUMBER_SMALL + 'none.png'
                return config;
            },
            drawWidget(widgetType, editType) {
                let bgX = 0;
                let bgY = 0;
                let levelImg = null
                switch (widgetType) {
                    case WIDGET_LEFT:
                        bgX = 60;
                        bgY = 237;
                        textY = bgY + 54;
                        levelImg = ROOT_LEVEL_LEFT
                        break;
                    case WIDGET_RIGHT:
                        bgX = 340;
                        bgY = 119;
                        textY = bgY + 55;
                        levelImg = ROOT_LEVEL_RIGHT
                        break;
                    default:
                       
                        return;
                }
                const bgSize = 36;
                const textWidth = 100;
                const textHeight = 30;
               
                const config = this.parseWidgetConfig(editType, widgetType);
             
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: bgX,
                    y: bgY,
                    w: bgSize,
                    h: bgSize,
                    src: config.bgPath,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
                });
                let dataProp = {
                    x: config.textX,
                    y: config.textY,
                    w: textWidth,
                    h: textHeight,
                    align_h: hmUI.align.CENTER_H,
                    type: config.dataType,
                    h_space: -4,
                    font_array: dateImg,
                    // padding:!0,
                    invalid_image: config.nonePath,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
                };
                //数据
                hmUI.createWidget(hmUI.widget.TEXT_IMG, dataProp);

                let imageLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: bgX + 53,
                    y: bgY + 14,
                    w: 32,
                    //宽高可省略
                    h: 74,
                    image_array: levelImg,
                    image_length: levelImg.length,//长度
                    type: config.dataType,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
                });
            },
            getIcon(options){
                let { x, y, src  } = options
                let icon = hmUI.createWidget(hmUI.widget.IMG, {
                  x: x,
                  y: y,
                  src: src,
                  show_level: hmUI.show_level.ONLY_EDIT, //ONLY_EDIT
                })
               
            },
            init_view() {
                // let bgcolor = hmUI.createWidget(hmUI.widget.FILL_RECT, {
                //     x: 0,
                //     y: 0,
                //     w: 454,
                //     h: 454,
                //     color: 0x000000,
                //     show_level: hmUI.show_level.ONAL_AOD
                // });

                let bg = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 454,
                    h: 454,
                    src: ROOTPATH + "clever/bg/bg.png",
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
                });
                // //------------------------------
                // this.getIcon({ x: 48, y: 88, src: ROOTPATH + "clever/hour/hour_1.png",})
                // this.getIcon({ x: 168, y: 88, src: ROOTPATH + "clever/hour/hour_0.png",})
                // this.getIcon({ x: 145, y: 238, src: ROOTPATH + "clever/min/min_2.png",})
                // this.getIcon({ x: 268, y: 238, src: ROOTPATH + "clever/min/min_9.png",})
                // this.getIcon({ x: 113, y: 251, src: ROOTPATH + "clever/level1/3.png",})
                // this.getIcon({ x: 392, y: 133, src: ROOTPATH + "clever/level2/3.png",})

                var dateObj = {
                    day_startX: 246,
                    day_startY: 36,
                    day_space: -4,//文字间隔
                    day_zero: 0,//是否补零 
                    day_follow: 0,//是否跟随
                    day_en_array: dateImg,
                    day_sc_array: dateImg,
                    day_tc_array: dateImg,
                    day_is_character: false,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
                }
                hmUI.createWidget(hmUI.widget.IMG_DATE, dateObj);
                let weekImg = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 148,
                    y: 38,
                    week_en: week_arr,
                    week_tc: week_arr,
                    week_sc: week_arr,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
                });

                var screenType = hmSetting.getScreenType();
                if (screenType == hmSetting.screen_type.AOD) { 
                    time_hour_Array = xp_img_Array
                    time_min_Array = xp_img_Array
                }
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1, //是否补零
                    hour_startX: 48,
                    hour_startY: 88,
                    hour_array: time_hour_Array,
                    hour_space: -26, //每个数组间的间隔
                    //单位 
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1, //是否补零
                    minute_startX: 145,
                    minute_startY: 238,
                    minute_array: time_min_Array,
                    minute_space: -26, //每个数组间的间隔
                    //单位 
                    minute_align: hmUI.align.LEFT,
                    am_x: 332,
                    am_y: 92,
                    am_sc_path: ROOTPATH + "clever/ampm/AM.png",
                    am_en_path: ROOTPATH + "clever/ampm/AM.png",
                    pm_x: 332,
                    pm_y: 92,
                    pm_sc_path: ROOTPATH + "clever/ampm/PM.png",
                    pm_en_path: ROOTPATH + "clever/ampm/PM.png",
                    show_level: hmUI.show_level.ONLY_NORMAL|hmUI.show_level.ONLY_AOD,
                });

                //熄屏背景渲染
               
                let text = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 135,
                    y: 394,
                    w: 190,
                    h: 60,
                    icon: ROOTPATH + "clever/icon/step.png",
                    icon_space:10,
                    type: hmUI.data_type.STEP,
                    font_array: number_small_Array,
                    h_space: -4,
                    align_h: hmUI.align.CENTER_H,
                    invalid_image: NUMBER_SMALL + "none.png",
                    padding: !1,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
                });
                //==========================================================================
                let groupX = 0;
                let groupY = 0;
            
                let widgetOptionalArray_left = [
                    { type: hmUI.edit_type.BATTERY, preview: widgetPreview + "bat_l.png" },
                    { type: hmUI.edit_type.HEART, preview: widgetPreview + "heart_l.png" },
                    { type: hmUI.edit_type.PAI, preview: widgetPreview + "pai_l.png" },
                ];
                groupX = 15;
                groupY = 235;
                //可编辑组件
                let leftWidget = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: WIDGET_LEFT_ID,
                    x: groupX + 8,
                    y: groupY,
                    w: 110,
                    h: 95,
                    select_image: select + "select.png",
                    un_select_image: select + "unselect.png",
                    default_type: hmUI.edit_type.BATTERY,
                    optional_types: widgetOptionalArray_left,
                    count: widgetOptionalArray_left.length,
                    tips_BG: ROOTPATH + "clever/tip.png",
                    tips_x: 20,
                    tips_y: -40,
                    tips_width: WIDGET_TIPS_WIDTH,
                    tips_margin:10

                });
                var editType = leftWidget.getProperty(hmUI.prop.CURRENT_TYPE);
                this.drawWidget(WIDGET_LEFT, editType);

                //right
                let widgetOptionalArray_right = [
                    // { type: hmUI.edit_type.AQI, preview: widgetPreview + "aqi_r.png" },
                    { type: hmUI.edit_type.BATTERY, preview: widgetPreview + "bat_r.png" },
                    { type: hmUI.edit_type.HEART, preview: widgetPreview + "heart_r.png" },
                    { type: hmUI.edit_type.PAI, preview: widgetPreview + "pai_r.png" },
                ];
                groupX = 292;
                groupY = 119;
                //可编辑组件
                let rightWidget = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: WIDGET_RIGHT_ID,
                    x: groupX + 4,
                    y: groupY,
                    w: 110,
                    h: 95,
                    select_image: select + "select.png",
                    un_select_image: select + "unselect.png",
                    default_type: hmUI.edit_type.HEART,
                    optional_types: widgetOptionalArray_right,
                    count: widgetOptionalArray_right.length,
                    tips_BG: ROOTPATH + "clever/tip.png",
                    tips_x: -10,
                    tips_y: 105,
                    tips_width: WIDGET_TIPS_WIDTH,
                    tips_margin:10
                });
                var editType = rightWidget.getProperty(hmUI.prop.CURRENT_TYPE);
                this.drawWidget(WIDGET_RIGHT, editType);

                let mask100 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
                    x: 0,
                    y: 0,
                    w: 454,
                    h: 454,
                    src: ROOTPATH + "clever/mask/mask1000.png",
                    show_level: hmUI.show_level.ONLY_EDIT,
                });
                let mask70 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
                    x: 0,
                    y: 0,
                    w: 454,
                    h: 454,
                    src: ROOTPATH + "clever/mask/mask70.png",
                    show_level: hmUI.show_level.ONLY_EDIT,
                });

            },

            onInit() {
                console.log('index page.js on init invoke')
                this.init_view();
            },

            onReady() {
                console.log('index page.js on ready invoke')
            },

            onShow() {
                console.log('index page.js on show invoke')
            },

            onHide() {
                console.log('index page.js on hide invoke')
            },

            onDestory() {
                console.log('index page.js on destory invoke')
            },
        });
        /*
        * end js
        */
    })()
} catch (e) {
    console.log(e)
}
