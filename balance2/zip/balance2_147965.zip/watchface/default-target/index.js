try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_c976c0814e3e43ddb2801371b9ae6f96 = '';
        let normal$_$text_ac5c4fabd95947fc9d9eaf0add12bcd6 = '';
        let dateFormat = '';
        let dateFormatMap = '';
        let normal$_$text_8e26f013905f4a05a5e117aff0e4de62 = '';
        let stepSensor = '';
        let timeSensor = '';
        let batterySensor = '';
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 7,
                    y: 143,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '3.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_c976c0814e3e43ddb2801371b9ae6f96 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 276,
                    y: 220,
                    w: 100,
                    h: 40,
                    text: '[SC]',
                    color: '0xFFffffff',
                    text_size: 27,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_ac5c4fabd95947fc9d9eaf0add12bcd6 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 198,
                    y: 301,
                    w: 82,
                    h: 40,
                    text: '[DAY_Z]',
                    color: '0xFFffffff',
                    text_size: 27,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 142,
                    y: 179,
                    src: '4.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 327,
                    center_y: 240,
                    radius: 49,
                    start_angle: 26,
                    end_angle: 335,
                    color: 4293484036,
                    line_width: 6,
                    src_bg: '5.png',
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 155,
                    center_y: 240,
                    radius: 49,
                    start_angle: 26,
                    end_angle: 335,
                    color: 4293484036,
                    line_width: 6,
                    src_bg: '6.png',
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 310,
                    y: 183,
                    src: '7.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 240,
                    hour_centerY: 240,
                    hour_posX: 33,
                    hour_posY: 158,
                    hour_path: '8.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 240,
                    minute_centerY: 240,
                    minute_posX: 32,
                    minute_posY: 235,
                    minute_path: '9.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    second_centerX: 240,
                    second_centerY: 240,
                    second_posX: 19,
                    second_posY: 234,
                    second_path: '11.png',
                    second_cover_path: '10.png',
                    second_cover_x: 205,
                    second_cover_y: 209,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 216,
                    y: 109,
                    image_array: [
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png'
                    ],
                    image_length: 29,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_8e26f013905f4a05a5e117aff0e4de62 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 104,
                    y: 220,
                    w: 100,
                    h: 40,
                    text: '[BATT_PER]',
                    color: '0xFFffffff',
                    text_size: 27,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 186,
                    y: 265,
                    week_en: [
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png'
                    ],
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 225,
                    y: 163,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: [
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png',
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '60.png',
                    unit_tc: '60.png',
                    unit_en: '60.png',
                    negative_image: '59.png',
                    invalid_image: '58.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '61.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 240,
                    hour_centerY: 240,
                    hour_posX: 33,
                    hour_posY: 158,
                    hour_path: '8.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 240,
                    minute_centerY: 240,
                    minute_posX: 32,
                    minute_posY: 235,
                    minute_path: '9.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                if (!stepSensor) {
                    stepSensor = hmSensor.createSensor(hmSensor.id.STEP);
                }
                if (!timeSensor) {
                    timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                }
                if (!batterySensor) {
                    batterySensor = hmSensor.createSensor(hmSensor.id.BATTERY);
                }
                stepSensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_c976c0814e3e43ddb2801371b9ae6f96.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                }), timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_ac5c4fabd95947fc9d9eaf0add12bcd6.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }` });
                        },
                        () => {
                            normal$_$text_ac5c4fabd95947fc9d9eaf0add12bcd6.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }` });
                        },
                        () => {
                            normal$_$text_ac5c4fabd95947fc9d9eaf0add12bcd6.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                }), batterySensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_8e26f013905f4a05a5e117aff0e4de62.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }` });
                });
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        normal$_$text_c976c0814e3e43ddb2801371b9ae6f96.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                normal$_$text_ac5c4fabd95947fc9d9eaf0add12bcd6.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }` });
                            },
                            () => {
                                normal$_$text_ac5c4fabd95947fc9d9eaf0add12bcd6.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }` });
                            },
                            () => {
                                normal$_$text_ac5c4fabd95947fc9d9eaf0add12bcd6.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                        normal$_$text_8e26f013905f4a05a5e117aff0e4de62.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }` });
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}