try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
                    edit_id: 1,
                    x: 0,
                    y: 0,
                    bg_config: [
                        {
                            'id': 1,
                            'path': '4.png',
                            'preview': '4.png'
                        },
                        {
                            'id': 2,
                            'path': '5.png',
                            'preview': '5.png'
                        }
                    ],
                    count: 2,
                    default_id: 1,
                    fg: '3.png',
                    tips_x: 0,
                    tips_y: 0,
                    tips_bg: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                });
                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: '6.png',
                    center_x: 358,
                    center_y: 240,
                    x: 17,
                    y: 62,
                    type: hmUI.data_type.STEP,
                    start_angle: -122,
                    end_angle: 122,
                    cover_x: 0,
                    cover_y: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 240,
                    hour_centerY: 240,
                    hour_posX: 43,
                    hour_posY: 154,
                    hour_path: '7.png',
                    hour_cover_x: 69,
                    hour_cover_y: 211,
                    minute_centerX: 240,
                    minute_centerY: 240,
                    minute_posX: 48,
                    minute_posY: 218,
                    minute_path: '8.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    second_centerX: 240,
                    second_centerY: 240,
                    second_posX: 16,
                    second_posY: 229,
                    second_path: '9.png',
                    second_cover_x: 0,
                    second_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    day_startX: 225,
                    day_startY: 405,
                    day_sc_array: [
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png'
                    ],
                    day_tc_array: [
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png'
                    ],
                    day_en_array: [
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png'
                    ],
                    day_align: hmUI.align.LEFT,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 0,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: '20.png',
                    center_x: 122,
                    center_y: 240,
                    x: 17,
                    y: 62,
                    type: hmUI.data_type.BATTERY,
                    start_angle: -122,
                    end_angle: 122,
                    cover_x: 0,
                    cover_y: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '21.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 240,
                    hour_centerY: 240,
                    hour_posX: 43,
                    hour_posY: 154,
                    hour_path: '22.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 240,
                    minute_centerY: 240,
                    minute_posX: 48,
                    minute_posY: 218,
                    minute_path: '23.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 289,
                    y: 166,
                    w: 140,
                    h: 140,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 45,
                    y: 160,
                    w: 150,
                    h: 148,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}