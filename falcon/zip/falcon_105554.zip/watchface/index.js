try {
  ;(() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp

    var __$$module$$__ = __$$app$$__.current
    var h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__),
      'drink'
    )

    /*
     * huamiOS bundle tool v1.0.17
     * Copyright © Huami. All Rights Reserved
     */
    ;('use strict')

    console.log('----->>>current')
    console.log(__$$hmAppManager$$__.currentApp.pid)
    console.log(__$$hmAppManager$$__.currentApp.current)

    let rootPath = 'images/'
    let bigPath = rootPath + 'big/'
    let iconPath = rootPath + 'icon/'
    let maskPath = rootPath + 'mask/'
    let previewPath = rootPath + 'preview/'
    let smallPath = rootPath + 'small/'
    let week_cnPath = rootPath + 'week_cn/'
    let week_enPath = rootPath + 'week_en/'

    let week, month, time, item_text

    const logger = DeviceRuntimeCore.HmLogger.getLogger('defult')
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      drawWidget(item) {
        config = {
          iconX: 45,
          iconY: 275,
          iconImg: null,
          unit: null,
          type: null,
          invalid: null,
        }
        switch (item) {
          case hmUI.edit_type.HEART:
            config.iconImg = iconPath + 'hr.png'
            config.type = hmUI.data_type.HEART
            config.invalid = smallPath + 'null.png'

            break
          case hmUI.edit_type.BATTERY:
            config.iconImg = iconPath + 'bt.png'
            config.type = hmUI.data_type.BATTERY
            config.unit = smallPath + 'baifen.png'

            break
          case hmUI.edit_type.STEP:
            config.iconImg = iconPath + 'st.png'
            config.type = hmUI.data_type.STEP

            break
          case hmUI.edit_type.CAL:
            config.iconImg = iconPath + 'cal.png'
            config.type = hmUI.data_type.CAL
            break
          case hmUI.edit_type.HUMIDITY:
            config.iconImg = iconPath + 'wd.png'
            config.type = hmUI.data_type.HUMIDITY
            config.unit = smallPath + 'baifen.png'
            config.invalid = smallPath + 'null.png'

            break
          default:
            return config
            break
        }

        let edit_obj = {
          x: config.iconX - 30,
          y: config.iconY,
          w: 160,
          icon: config.iconImg,
          icon_space: 3,
          type: config.type,
          font_array: small_num_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          padding: false,
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
        }

        if (config.unit) {
          edit_obj.unit_sc = config.unit
          edit_obj.unit_tc = config.unit
          edit_obj.unit_en = config.unit
        }

        if (config.invalid) {
          edit_obj.invalid_image = config.invalid
        }

        item_text = hmUI.createWidget(hmUI.widget.TEXT_IMG, edit_obj)
      },

      init_view() {
        week_cn_array = [] // 星期中文
        week_en_array = [] // 星期英文
        for (let i = 1; i < 8; i++) {
          week_cn_array.push(week_cnPath + '0' + i + '.png')
          week_en_array.push(week_enPath + '0' + i + '.png')
        }
        // time & date
        big_num_array = []
        small_num_array = []
        for (let i = 0; i < 10; i++) {
          big_num_array.push(bigPath + '0' + i + '.png')
          small_num_array.push(smallPath + '0' + i + '.png')
        }
        let bg = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 416,
          h: 416,
          src: rootPath + 'bg.png',
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
        })

        // 星期

        week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
          x: 147,
          y: 116,
          week_tc: week_cn_array,
          week_sc: week_cn_array,
          week_en: week_en_array,
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
        })

        // 年月日
        month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
          month_startX: 44,
          month_startY: 119,
          month_zero: true,
          month_en_array: small_num_array,
          month_align: hmUI.align.RIGHT,
          month_unit_sc: smallPath + 'xie.png',
          month_unit_tc: smallPath + 'xie.png',
          month_unit_en: smallPath + 'xie.png',
          day_startX: 103,
          day_startY: 119,
          day_zero: true,
          day_en_array: small_num_array,
          day_align: hmUI.align.LEFT,
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
        })

        // 时间
        time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          hour_zero: true,
          hour_startX: 21,
          hour_startY: 164,
          hour_array: big_num_array,
          hour_space: 0,
          hour_unit_sc: bigPath + 'maohao.png', //单位
          hour_unit_tc: bigPath + 'maohao.png',
          hour_unit_en: bigPath + 'maohao.png',
          hour_align: hmUI.align.LEFT,
          minute_zero: 1, //是否补零 1为补零
          minute_follow: true, //是否跟随
          minute_array: big_num_array,
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
        })

        let optionWidgets = [
          {
            type: hmUI.edit_type.HEART,
            preview: previewPath + 'hr.png',
          },
          {
            type: hmUI.edit_type.BATTERY,
            preview: previewPath + 'bt.png',
          },
          {
            type: hmUI.edit_type.STEP,
            preview: previewPath + 'st.png',
          },
          {
            type: hmUI.edit_type.CAL,
            preview: previewPath + 'cal.png',
          },
          {
            type: hmUI.edit_type.HUMIDITY,
            preview: previewPath + 'wd.png',
          },
        ]

        let groupX = 35
        let groupY = 265

        let Group = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 101,
          x: groupX,
          y: groupY,
          w: 150,
          h: 53,
          select_image: maskPath + 'select.png',
          un_select_image: maskPath + 'select.png',
          default_type: hmUI.edit_type.STEP,
          optional_types: optionWidgets,
          count: optionWidgets.length,
          tips_BG: maskPath + 'tips.png',
          tips_x: 67 - groupX,
          tips_y: 230 - groupY - 3,
          tips_width: 91,
          tips_margin: 10, //加margin
        })

        let item1 = Group.getProperty(hmUI.prop.CURRENT_TYPE)
        this.drawWidget(item1)

        //100%mask
        let maskCover = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK, {
          x: 0,
          y: 0,
          w: 416,
          h: 416,
          src: maskPath + 'mask100.png',
          show_level: hmUI.show_level.ONLY_EDIT,
        })

        //70%msk
        let mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
          x: 0,
          y: 0,
          w: 416,
          h: 416,
          src: maskPath + 'mask70.png',
          show_level: hmUI.show_level.ONLY_EDIT,
        })

        let getColor = readColor()
        try {
          week.setColor(getColor)
          month.setColor(getColor)
          time.setColor(getColor)
          item_text.setColor(getColor)
        } catch (error) {
          console.log(error)
        }

        function readColor() {
          const file_name = 'config.json'
          const [file_stat, err] = hmFS.stat_asset(file_name)
          if (err == 0) {
            console.log('file size:', file_stat.size)
          } else {
            console.log('err:', err)
          }
          var test_buf = new Uint8Array(file_stat.size)
          var fd = hmFS.open_asset(file_name, hmFS.O_RDONLY)
          hmFS.seek(fd, 0, hmFS.SEEK_SET)
          hmFS.read(fd, test_buf.buffer, 0, test_buf.length)
          hmFS.close(fd)
          const val = String.fromCharCode.apply(null, test_buf)
          contentObj = val ? JSON.parse(val) : {}
          const colors = parseInt('0x' + contentObj.foreground.color)
          return colors
        }
      },

      onInit() {
        console.log('index page.js on init invoke')

        this.init_view()
      },

      onReady() {
        console.log('index page.js on ready invoke')
      },

      onShow() {
        console.log('index page.js on show invoke')
      },

      onHide() {
        console.log('index page.js on hide invoke')
      },

      onDestory() {
        console.log('index page.js on destory invoke')
      },
    })
    /*
     * end js
     */
  })()
} catch (e) {
  console.log(e)
}
