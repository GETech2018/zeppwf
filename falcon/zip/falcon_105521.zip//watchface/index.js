
    /*
    ** huamiOS bundle tool v1.0.17
    * *huamiOS watchface js version v1.0.1
    * *Copyright © Huami. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start
        let normal$_$background$_$bg = ''
        let normal$_$date$_$img_date = ''
        let normal$_$battery$_$image_progress$_$img_level = ''
        let normal$_$week$_$week = ''
        let normal$_$step$_$current$_$text_img = ''
        let normal$_$step$_$pointer_progress$_$img_pointer = ''
        let normal$_$analog_clock$_$time_pointer = ''
        let idle$_$analog_clock$_$time_pointer = ''
        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            normal$_$background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 416,
              h: 416,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$date$_$img_date = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 194,
              day_startY: 97,
              day_sc_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              day_tc_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              day_en_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              day_align: hmUI.align.CENTER_H,
              day_zero: 1,
              day_follow: 0,
              day_space: 0,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$battery$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 144,
              y: 248,
              image_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$week$_$week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 13,
              y: 135,
              week_en: ["22.png","23.png","24.png","25.png","26.png","27.png","28.png"],
              week_tc: ["22.png","23.png","24.png","25.png","26.png","27.png","28.png"],
              week_sc: ["22.png","23.png","24.png","25.png","26.png","27.png","28.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$step$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 297,
              y: 224,
              type: hmUI.data_type.STEP,
              font_array: ["29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$step$_$pointer_progress$_$img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '40.png',
              center_x: 328,
              center_y: 209,
              x: 18,
              y: 73,
              type: hmUI.data_type.STEP,
              start_angle: -150,
              end_angle: 150,
              cover_path: '39.png',
              cover_x: 310,
              cover_y: 136,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$analog_clock$_$time_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_centerX: 208,
              hour_centerY: 208,
              hour_posX: 42,
              hour_posY: 208,
              hour_path: '42.png',
              hour_cover_path: '41.png',
              hour_cover_x: 166,
              hour_cover_y: 0,
              minute_centerX: 208,
              minute_centerY: 208,
              minute_posX: 42,
              minute_posY: 208,
              minute_path: '44.png',
              minute_cover_path: '43.png',
              minute_cover_x: 166,
              minute_cover_y: 0,
              second_centerX: 208,
              second_centerY: 208,
              second_posX: 42,
              second_posY: 208,
              second_path: '46.png',
              second_cover_path: '45.png',
              second_cover_x: 166,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            idle$_$analog_clock$_$time_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_centerX: 208,
              hour_centerY: 208,
              hour_posX: 42,
              hour_posY: 208,
              hour_path: '47.png',
              hour_cover_path: '',
              hour_cover_x: 166,
              hour_cover_y: 0,
              minute_centerX: 208,
              minute_centerY: 208,
              minute_posX: 42,
              minute_posY: 208,
              minute_path: '48.png',
              minute_cover_path: '',
              minute_cover_x: 166,
              minute_cover_y: 0,
              show_level: hmUI.show_level.ONAL_AOD,
            });
  
            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  