/*
 * =====================================================================================
 *
 *  Copyright (C) 2021. Huami Ltd, unpublished work. This computer program includes
 *  Confidential, Proprietary Information and is a Trade Secret of Huami Ltd.
 *  All use, disclosure, and/or reproduction is prohibited unless authorized in writing.
 *  All Rights Reserved.
 *
 *  Author: hmkj
 *
 * =====================================================================================
 */
try {
  (() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');
    /*
     * huamiOS bundle tool v1.0.17
     * Copyright © Huami. All Rights Reserved
     */
    'use strict';
    const arrWeek = []
    const arrDay = []
    const arrFont = []
    const arrLevel = []
    const arrWeather = []
    for(let i = 1; i < 7;i++) {
      arrWeek.push("images/week/" + i + ".png")
    }
    for(let i = 0;i < 10;i++) {
      arrDay.push("images/day/" + i + ".png")
      arrFont.push("images/font/" + i + ".png")
    }
    for(let i = 1;i < 9;i++) {
      arrLevel.push("images/level/" + i + ".png")
    }
    for(let i = 0; i < 29;i++) {
      arrWeather.push("images/weather/" + i + ".png")
    }
    function deepClone(target,changeObj = null) {
      let result;
      if (typeof target === 'object') {
          if (Array.isArray(target)) {
              result = []; 
              for (let i in target) {
                  result.push(deepClone(target[i]))
              }
          } else if (target === null) {
              result = null;
          } else if (target.constructor === RegExp) {
              result = target;
          } else {
              result = {};
              for (let i in target) {
                  result[i] = deepClone(target[i]);
              }
          }
      } else {
          result = target;
      }
      if(changeObj != null) {
        for(let key in changeObj) {
          result[key] = changeObj[key]
        }
      }
      return result
    }
    const optionalTypes = [
      // { type:hmUI.edit_type.AQI,      preview:"images/widgetpreview/aqi.png",     invalid_image:"images/font/null.png"},
      { type:hmUI.edit_type.BATTERY,  preview:"images/widgetpreview/battery.png", unit_sc:"images/font/per.png",unit_tc:"images/font/per.png",unit_en:"images/font/per.png"},
      { type:hmUI.edit_type.CAL,      preview:"images/widgetpreview/cal.png"},
      { type:hmUI.edit_type.FAT_BURN, preview:"images/widgetpreview/fatburn.png", unit_sc:"images/font/h.png",unit_tc:"images/font/h.png",unit_en:"images/font/h.png",invalid_image:"images/font/null.png"},
      { type:hmUI.edit_type.HEART,    preview:"images/widgetpreview/heart.png",   invalid_image:"images/font/null.png"},
      { type:hmUI.edit_type.HUMIDITY, preview:"images/widgetpreview/humidity.png",unit_sc:"images/font/per.png",unit_tc:"images/font/per.png",unit_en:"images/font/per.png",invalid_image:"images/font/null.png"},
      { type:hmUI.edit_type.ALTIMETER,preview:"images/widgetpreview/kpa.png",     invalid_image:"images/font/null.png"},
      { type:hmUI.edit_type.PAI,      preview:"images/widgetpreview/pai.png",},
      { type:hmUI.edit_type.STEP,     preview:"images/widgetpreview/step.png",},
      { type:hmUI.edit_type.UVI,      preview:"images/widgetpreview/uvi.png",invalid_image:"images/font/null.png"},
      { type:hmUI.edit_type.WEATHER,  preview:"images/widgetpreview/weather.png", unit_sc:"images/font/du.png",unit_tc:"images/font/du.png",unit_en:"images/font/du.png",invalid_image:"images/font/null.png"},
      { type:hmUI.edit_type.WIND,     preview:"images/widgetpreview/wind.png",invalid_image:"images/font/null.png"},
    ]
    //topGroup
    const GroupOption = {
      edit_id:101,
      x:154,
      y:12,
      w:110,
      h:110,
      select_image:"images/mask/select.png",
      un_select_image:"images/mask/unselect.png",
      default_type:hmUI.edit_type.BATTERY,
      optional_types: optionalTypes,
      count:optionalTypes.length,
      tips_BG:"images/mask/tip.png",
      tips_x:6,
      tips_y:108,
      tips_width:89,
      tips_margin:10,
      show_level:hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
    }
    const GroupImgOption = {
      x:196,
      y:32,
      src:[
        // { type:hmUI.edit_type.AQI,       path:"images/icon/aqi.png"     },
        { type:hmUI.edit_type.BATTERY,   path:"images/icon/battery.png" },
        { type:hmUI.edit_type.CAL,       path:"images/icon/cal.png"     },
        { type:hmUI.edit_type.FAT_BURN,  path:"images/icon/fatburn.png" },
        { type:hmUI.edit_type.HEART,     path:"images/icon/heart.png"   },
        { type:hmUI.edit_type.HUMIDITY,  path:"images/icon/humidity.png"},
        { type:hmUI.edit_type.ALTIMETER, path:"images/icon/kpa.png"     },
        { type:hmUI.edit_type.PAI,       path:"images/icon/pai.png"     },
        { type:hmUI.edit_type.STEP,      path:"images/icon/step.png"    },
        { type:hmUI.edit_type.UVI,       path:"images/icon/uvi.png"     },
        { type:hmUI.edit_type.WIND,      path:"images/icon/wind.png"    },
      ]
    }
    const weatherLevelOption = {
      x:190,
      y:24,
      image_array:arrWeather,
      image_length:29,
      type:hmUI.data_type.WEATHER_CURRENT,
    }
    const GroupLevelOption = {x:158,y:16,image_array:arrLevel,image_length:8}
    const GroupTextOPtion = {
      x:174, 
      y:76,
      w:70,
      font_array:arrFont,
      h_space: 0, 
      align_h:hmUI.align.CENTER_H,
      optional_types:optionalTypes,
      padding:false
    }
    const GroupLevelOption2 = {
      src: "images/pointer/little.png",
      center_x:208,
      center_y:65,
      x: 14,
      y: 49,
      start_angle:0,
      end_angle:360,
    }
    const mask70Option = {x:0,y:0,w:416,h:416,src:"images/mask/mask70.png",show_level:hmUI.show_level.ONLY_EDIT}
    const mask100Option = deepClone(mask70Option,{src:"images/mask/mask100.png"})
    const timePointerOption = {
      hour_centerX:208,
      hour_centerY:208,
      hour_posX:29,
      hour_posY:208,
      hour_path:"images/img/hour.png",
      minute_centerX:208,
      minute_centerY:208,
      minute_posX:29,
      minute_posY:208,
      minute_path:"images/img/minute.png",
    }
    const timePointerOption2 = deepClone(timePointerOption,{
      hour_path:"images/aod/hour.png",
      minute_path:"images/aod/minute.png",
      show_level:hmUI.show_level.ONAL_AOD
    })
    const objWeekOption = {x:184,y:290,week_en:arrWeek,week_sc:arrWeek,week_tc:arrWeek,show_level:hmUI.show_level.ONLY_NORMAL}
    const objDayOption = {day_startX:188,day_startY:310,day_zero:1,day_en_array:arrDay,day_sc_array:arrDay,day_tc_array:arrDay,show_level:hmUI.show_level.ONLY_NORMAL}
    const objAnimateOption = {
      x:0,
      y:0,
      anim_path:"images/animate",
      anim_prefix:"anim",
      anim_ext:"png",
      anim_fps:15,
      anim_size:40,
      repeat_count:0,
      anim_repeat:true,
      anim_status:hmUI.anim_status.START,
      display_on_restart:true
    }
    const objNormalBgOPtion = {x:0,y:0,src:"images/img/bg.png",show_level:hmUI.show_level.ONLY_NORMAL}
    const objAodBgOption = deepClone(objNormalBgOPtion,{src:"images/aod/bg.png",show_level:hmUI.show_level.ONAL_AOD})
    class Time {
      constructor() {
        
      }
      pointer(option) {
        this.pointWidget = hmUI.createWidget(hmUI.widget.TIME_POINTER,option)
      }
      week(option) {
        this.weekWidget = hmUI.createWidget(hmUI.widget.IMG_WEEK,option)
      }
      date(option) {
        this.dateWidget = hmUI.createWidget(hmUI.widget.IMG_DATE,option)
      }
    }
    class Img {
      constructor(option) {
         this.widget = hmUI.createWidget(hmUI.widget.IMG,option)
         "url" in option && this.href(option.url)
      }
      href(url) {
        this.widget.addEventListener(hmUI.event.CLICK_UP, (function (info) {    
          hmApp.startApp({url:url,native:true});
        }));
      }
    }
    class Text {
      constructor(option,editType) {
        this.option = option
        this.editType = editType
        if(!this.editType) {
          this.widget =  hmUI.createWidget(hmUI.widget.TEXT_IMG,this.option)
          return
        }
        for(let i = 0,len = this.option.optional_types.length;i < len;i++) {
          if(this.option.optional_types[i].type == this.editType) {
            for(let key in this.option.optional_types[i]) {
              if(key != "preview" && key != "type") {
                this.option[key] = this.option.optional_types[i][key]
              }
            }
            delete this.option['optional_types']
            this.widget =  hmUI.createWidget(hmUI.widget.TEXT_IMG,this.option)
            break;
          }
        }
      }
    }
    class Animate {
      constructor(option) {
        this.widget = hmUI.createWidget(hmUI.widget.IMG_ANIM,option)
      }
    }
    class Level {
      constructor(option,editType) {
        this.option = option
        this.editType = editType
      }
      colorLevel() {
        if(!this.editType) {
          this.Widget = hmUI.createWidget(hmUI.widget.ARC_PROGRESS,this.option)
          return
        }
        if(typeof this.option.color == "number") {
          this.Widget = hmUI.createWidget(hmUI.widget.ARC_PROGRESS,this.option)
          return
        }
        for(let i = 0,len = this.option.color.length;i < len;i++) {
          if(this.option.color[i].type == this.editType) {
            this.option.color = this.option.color[i].color
            this.Widget = hmUI.createWidget(hmUI.widget.ARC_PROGRESS,this.option)
            break;
          }
        }
      }
      pointerLevel() {
        if(!this.editType) {
          this.Widget = hmUI.createWidget(hmUI.widget.IMG_POINTER,this.option)
          return
        }
        if(typeof this.option.src == "string") {
          this.Widget = hmUI.createWidget(hmUI.widget.IMG_POINTER,this.option)
          return
        }
        for(let i = 0,len = this.option.src.length;i < len;i++) {
          if(this.option.src[i].type == this.editType) {
            this.option.src = this.option.src[i].path
            this.Widget = hmUI.createWidget(hmUI.widget.IMG_POINTER,this.option)
            break;
          }
        }
      }
      imgLevel() {
        if(!this.editType) {
          this.widget = hmUI.createWidget(hmUI.widget.IMG_LEVEL,this.option)
          return
        }
        if(typeof this.option.image_array[0] == "string") {
          this.widget = hmUI.createWidget(hmUI.widget.IMG_LEVEL,this.option)
          return
        }
        this.widget = hmUI.createWidget(hmUI.widget.IMG_LEVEL,this.option)
      }
    }
    const executeList = []
    class Group {
      constructor(option) {
        this.editGroup = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP,option)
        this.editType = this.editGroup.getProperty(hmUI.prop.CURRENT_TYPE)
        this.skewX = 0
        this.skewY = 0
        this.dateType()
      }
      dateType() {
        switch(this.editType) {
          case hmUI.edit_type.STEP:
            this.dataType = hmUI.data_type.STEP;
            break;
          case hmUI.edit_type.BATTERY:
            this.dataType = hmUI.data_type.BATTERY
            break;
          case hmUI.edit_type.HEART:
            this.dataType = hmUI.data_type.HEART
            break;
          case hmUI.edit_type.CAL:
            this.dataType = hmUI.data_type.CAL
            break;
          case hmUI.edit_type.PAI:
            this.dataType = hmUI.data_type.PAI_DAILY
            break;
          case hmUI.edit_type.DISTANCE:
            this.dataType = hmUI.data_type.DISTANCE
            break;
          case hmUI.edit_type.AQI:
            this.dataType = hmUI.data_type.AQI
            break;
          case hmUI.edit_type.HUMIDITY:
            this.dataType = hmUI.data_type.HUMIDITY
            break;
          case hmUI.edit_type.UVI:
            this.dataType = hmUI.data_type.UVI
            break;
          case hmUI.edit_type.STAND:
            this.dataType = hmUI.data_type.STAND
            break;
          case hmUI.edit_type.WIND:
            this.dataType = hmUI.data_type.WIND
            break;
          case hmUI.edit_type.SPO2:
            this.dataType = hmUI.data_type.SPO2
            break;
          case hmUI.edit_type.STRESS:
            this.dataType = hmUI.data_type.STRESS
            break;
          case hmUI.edit_type.FAT_BURN:
            this.dataType = hmUI.data_type.FAT_BURNING
            break;
          case hmUI.edit_type.WEATHER:
            this.dataType = hmUI.data_type.WEATHER_CURRENT
            break;
          case hmUI.edit_type.ALTIMETER:
            this.dataType = hmUI.data_type.ALTIMETER
            break;
        }
      }
      groupImg(option) {
        this.groupImgOption = deepClone(option)
        this.groupImgOption.x += this.skewX
        this.groupImgOption.y += this.skewY
        for(let i = 0,len = this.groupImgOption.src.length;i < len;i++) {
          if(this.groupImgOption.src[i].type == this.editType) {
            this.groupImgOption.src = this.groupImgOption.src[i].path
            this.imgWidget = new Img(this.groupImgOption)
            break;
          }
        }
      }
      groupLevel(option) {
        option.type = this.dataType
        this.groupLevelOption = deepClone(option)
        if("color" in this.groupLevelOption) {
          this.groupLevelOption.center_x += this.skewX
          this.groupLevelOption.center_y += this.skewY
          new Level(this.groupLevelOption,this.editType).colorLevel()
        }else if("image_array" in option) {
          this.groupLevelOption.x += this.skewX
          this.groupLevelOption.y += this.skewY
          new Level(this.groupLevelOption,this.editType).imgLevel()
        }else {
          this.groupLevelOption.center_x += this.skewX
          this.groupLevelOption.center_y += this.skewY
          new Level(this.groupLevelOption,this.editType).pointerLevel()
        }
      }
      groupText(option) {
        option.type = this.dataType
        this.groupTextOption = deepClone(option)
        this.groupTextOption.x += this.skewX
        this.groupTextOption.y += this.skewY
        new Text(this.groupTextOption,this.editType)
      }
      execute(arr,callback) {
        executeList.push({arr,callback})
        arr.includes(this.editType) && callback.apply(this)
      }
      move(skewX,skewY) {
        this.skewX = skewX
        this.skewY = skewY
        for(let i = 0,len = executeList.length;i < len;i++) {
          const bool = executeList[i].arr.includes(this.editType)
          bool && executeList[i].callback.apply(this)
        }
      }
    }
    class Mask {
      constructor(option) {
        this.widget = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK,option)
      }
    }
    const logger = DeviceRuntimeCore.HmLogger.getLogger("default2");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        new Animate(objAnimateOption)
        new Img(objNormalBgOPtion)
        new Img(objAodBgOption)
        const arrWidgetFirst = [
          hmUI.edit_type.AQI,
          hmUI.edit_type.BATTERY,
          hmUI.edit_type.CAL,
          hmUI.edit_type.FAT_BURN,
          hmUI.edit_type.HEART,
          hmUI.edit_type.HUMIDITY,
          hmUI.edit_type.ALTIMETER,
          hmUI.edit_type.PAI,
          hmUI.edit_type.STEP,
          hmUI.edit_type.UVI,
          hmUI.edit_type.WIND
        ]
        const arrWidgetSecond = [hmUI.edit_type.WEATHER]
        const topGroup = new Group(GroupOption)
        topGroup.execute(arrWidgetFirst,function() {
          this.groupImg(GroupImgOption)
          this.groupLevel(GroupLevelOption)
          this.groupText(GroupTextOPtion)
          this.groupLevel(GroupLevelOption2)
        })
        topGroup.execute(arrWidgetSecond,function() {
          this.groupLevel(weatherLevelOption)
          this.groupLevel(GroupLevelOption)
          this.groupText(GroupTextOPtion)
          this.groupLevel(GroupLevelOption2)
        })
        //bottomLeft
        const bottomLeftGroupOption = deepClone(GroupOption,{edit_id:102,x:30,y:227,default_type:hmUI.edit_type.CAL,tips_y:-40,})
        const bottomLeftGroup = new Group(bottomLeftGroupOption)
        bottomLeftGroup.move(-124,215)
        //bottomRight
        const bottomRightGroupOption = deepClone(GroupOption,{edit_id:103,x:280,y:227,default_type:hmUI.edit_type.STEP,tips_y:-40})
        const bottomRightGroup = new Group(bottomRightGroupOption)
        bottomRightGroup.move(125,215)
        //mask
        new Mask(mask100Option)
        new Mask(mask70Option)
        const time = new Time()
        time.week(objWeekOption)
        time.date(objDayOption)
        time.pointer({
          ...timePointerOption,
          second_centerX:208,
          second_centerY:208,
          second_posX:27,
          second_posY:208,
          second_path:"images/img/second.png",
          show_level:hmUI.show_level.ONLY_NORMAL
        })
        time.pointer(timePointerOption2)
      },
      onInit() {
        this.init_view();
      },
      onReady() {
        console.log('index page.js on ready invoke')
      },
      onShow() {
        console.log('index page.js on show invoke')
      },
      onHide() {
        console.log('index page.js on hide invoke')
      },
      onDestory() {
        console.log('index page.js on destory invoke')
      },
    });
    /*
     * end js
     */
  })()
} catch (e) {}