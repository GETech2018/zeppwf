try {
  (() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__),
      "drink"
    );

    /*
     * huamiOS bundle tool v1.0.17
     * Copyright © Huami. All Rights Reserved
     */
    ("use strict");

    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);
    //=================================================================
    //=================定义静态资源数据数组============================
    //=================================================================
    const arrNum = []; //日期数组
    const arrMonth = []; //日期数组
    const arrDate = []; //日期数组
    const arrStep = []; //脚步
    const arrHour = []; //小时
    const arrSecond = []; //秒数
    const arrHourAod = []; //小时
    const arrWeekEn = []; //英文星期数组
    const arrWeekSc = []; //中文简体星期数组
    const arrWeekTc = []; //中文繁体星期数组
    const arrBatLevel = []; //电池进度条
    const arrStepLevel = []; //步数
    const arrMoonLevel = []; //满月进度条

    const { width: DEVICE_WIDTH } = hmSetting.getDeviceInfo();
    const num1 = DEVICE_WIDTH / 454; //454为从454圆表机型适配，是有圆表适用于这种适配方法
    // const num = num1.toFixed(2)
    const num = 0.9; //不需要适配时候开放
    const jstime = hmSensor.createSensor(hmSensor.id.TIME);
    //================================================================
    //=================定义动态向数组添加路径=========================
    //================================================================

    for (i = 1; i < 8; i++) {
      arrWeekEn.push(`images/weeken/${i}.png`);
      arrWeekSc.push(`images/weeksc/${i}.png`);
      arrWeekTc.push(`images/weeksc/${i}.png`);
    }
    for (i = 0; i < 10; i++) {
      arrNum.push(`images/num/${i}.png`);
      arrDate.push(`images/date/${i}.png`);
      arrHour.push(`images/time/hour/${i}.png`);
      arrSecond.push(`images/time/second/${i}.png`);
      arrHourAod.push(`images/aod/hour/${i}.png`);
      arrStep.push(`images/step/num/${i}.png`);
    }
    for (i = 1; i < 11; i++) {
      arrBatLevel.push(`images/bat/level/${i}.png`);
      arrStepLevel.push(`images/step/level/${i}.png`);
    }
    for (i = 1; i < 13; i++) {
      arrMonth.push(`images/month/${i}.png`);
    }

    for (i = 1; i < 31; i++) {
      arrMoonLevel.push(`images/moon/${i}.png`);
    }

    //================================================================
    //=======================定义页面样式参数=========================
    //================================================================
    //亮屏背景
    let bgImg = {
      x: 0,
      y: 0,
      src: "images/background_en.png",
      show_level: hmUI.show_level.ONLY_NORMAL,
    };

    //星期亮屏
    let objWeek = {
      x: 291 * num,
      y: 135 * num,
      week_en: arrWeekEn,
      week_sc: arrWeekSc,
      week_tc: arrWeekTc,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    // 时间亮屏
    let objTime = {
      hour_zero: true, //是否补零
      hour_startX: 109 * num,
      hour_startY: 301 * num,
      hour_array: arrHour,
      hour_space: 0, //每个数组间的间隔
      hour_unit_sc: "images/time/hour/dot.png",
      hour_unit_tc: "images/time/hour/dot.png",
      hour_unit_en: "images/time/hour/dot.png",
      hour_align: hmUI.align.LEFT, //靠左对齐

      minute_zero: true, //是否补零
      minute_startX: 241 * num,
      minute_startY: 301 * num,
      minute_array: arrHour,
      minute_space: 0, //每个数组间的间隔
      minute_align: hmUI.align.LEFT, //靠左对齐

      second_zero: true, //是否补零
      second_startX: 361 * num,
      second_startY: 296 * num,
      second_array: arrSecond,
      second_space: 0, //每个数组间的间隔
      second_align: hmUI.align.LEFT, //靠左对齐

      am_x: 50 * num,
      am_y: 282 * num,
      am_sc_path: "images/ampm/amsc.png",
      am_tc_path: "images/ampm/amsc.png",
      am_en_path: "images/ampm/am.png",
      pm_x: 50 * num,
      pm_y: 282 * num,
      pm_sc_path: "images/ampm/pmsc.png",
      pm_tc_path: "images/ampm/pmsc.png",
      pm_en_path: "images/ampm/pm.png",
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    // 时间息屏
    let objTimeAod = {
      hour_zero: true, //是否补零
      hour_startX: 109 * num,
      hour_startY: 301 * num,
      hour_array: arrHourAod,
      hour_space: 0, //每个数组间的间隔
      hour_unit_sc: "images/aod/hour/dot.png",
      hour_unit_tc: "images/aod/hour/dot.png",
      hour_unit_en: "images/aod/hour/dot.png",
      hour_align: hmUI.align.LEFT, //靠左对齐

      minute_zero: true, //是否补零
      minute_startX: 241 * num,
      minute_startY: 301 * num,
      minute_array: arrHourAod,
      minute_space: 0, //每个数组间的间隔
      minute_align: hmUI.align.LEFT, //靠左对齐

      am_x: 54 * num,
      am_y: 300 * num,
      am_sc_path: "images/aod/ampm/amsc.png",
      am_tc_path: "images/aod/ampm/amsc.png",
      am_en_path: "images/aod/ampm/am.png",
      pm_x: 54 * num,
      pm_y: 300 * num,
      pm_sc_path: "images/aod/ampm/pmsc.png",
      pm_tc_path: "images/aod/ampm/pmsc.png",
      pm_en_path: "images/aod/ampm/pm.png",
      show_level: hmUI.show_level.ONAL_AOD,
    };

    //日期月份
    let objMonth = {
      month_startX: 170 * num,
      month_startY: 424 * num,
      month_align: hmUI.align.LEFT,
      month_en_array: arrMonth,
      month_sc_array: arrMonth,
      month_tc_array: arrMonth,
      month_zero: 0, //是否补零
      month_is_character: true, //年份此字段无效 默认为false 为true时 传入的图片为月份12张 日31张
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    let objDate = {
      day_zero: 1, //是否补零
      day_startX: 302 * num,
      day_startY: 96 * num,
      day_en_array: arrDate,
      day_sc_array: arrDate,
      day_tc_array: arrDate,
      // month_is_character: true, //年份此字段无效 默认为false 为true时 传入的图片为月份12张 日31张
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    // 步数
    let objStep = {
      x: 57 * num,
      y: 196 * num,
      w: 90 * num,
      type: hmUI.data_type.STEP, //监听数据类型
      font_array: arrStep, //数字图片数组
      h_space: 0, //图片间隔
      align_h: hmUI.align.RIGHT, //对其方式
      show_level: hmUI.show_level.ONLY_NORMAL, //亮屏状态下显示
      padding: true, //补零
    };
    // 电量
    let objBat = {
      x: 295 * num,
      y: 207 * num,
      w: 90 * num,
      type: hmUI.data_type.BATTERY, //监听数据类型
      font_array: arrNum, //数字图片数组
      h_space: 0, //图片间隔
      unit_sc: "images/num/symbol.png", //单位
      unit_tc: "images/num/symbol.png", //单位
      unit_en: "images/num/symbol.png", //单位
      align_h: hmUI.align.RIGHT, //对其方式
      show_level: hmUI.show_level.ONLY_NORMAL, //亮屏状态下显示
      // padding: true, //补零
    };
    // 气压
    let objALTIMETER = {
      x: 3 * num,
      y: 258 * num,
      w: 90 * num,
      type: hmUI.data_type.ALTIMETER, //监听数据类型
      font_array: arrNum, //数字图片数组
      h_space: 0, //图片间隔
      align_h: hmUI.align.RIGHT, //对其方式
      invalid_image: "images/num/null.png", //空
      show_level: hmUI.show_level.ONLY_NORMAL, //亮屏状态下显示
      // padding: true, //补零
    };
    // 海拔
    let objALTITUDE = {
      x: 336 * num,
      y: 247 * num,
      w: 90 * num,
      type: hmUI.data_type.ALTITUDE, //监听数据类型
      font_array: arrNum, //数字图片数组
      h_space: 0, //图片间隔
      align_h: hmUI.align.LEFT, //对其方式
      invalid_image: "images/num/null.png", //空
      negative_image: "images/num/fu.png", //负号图片
      show_level: hmUI.show_level.ONLY_NORMAL, //亮屏状态下显示
      // padding: true, //补零
    };
    // 心率
    let objHeart = {
      x: 149 * num,
      y: 131 * num,
      w: 90 * num,
      type: hmUI.data_type.HEART, //监听数据类型
      font_array: arrNum, //数字图片数组
      h_space: 0, //图片间隔
      align_h: hmUI.align.CENTER_H, //对其方式
      invalid_image: "images/num/null.png", //空
      show_level: hmUI.show_level.ONLY_NORMAL, //亮屏状态下显示
      padding: true, //补零
    };
    // cal
    let objCal = {
      x: 43 * num,
      y: 131 * num,
      w: 90 * num,
      type: hmUI.data_type.CAL, //监听数据类型
      font_array: arrNum, //数字图片数组
      h_space: 0, //图片间隔
      align_h: hmUI.align.CENTER_H, //对其方式
      invalid_image: "images/bottomnum/null.png", //空
      show_level: hmUI.show_level.ONLY_NORMAL, //亮屏状态下显示
      // padding: true, //补零
    };
    // 距离
    let objDISTANCE = {
      x: 121 * num,
      y: 94 * num,
      w: 90 * num,
      type: hmUI.data_type.DISTANCE, //监听数据类型
      font_array: arrNum, //数字图片数组
      h_space: 0, //图片间隔
      align_h: hmUI.align.LEFT, //对其方式
      dot_image: "images/num/dot.png", //单位
      dot_image: "images/num/dot.png", //单位
      dot_image: "images/num/dot.png", //单位
      // unit_sc: "images/num/m.png", //单位
      // unit_tc: "images/num/m.png", //单位
      // unit_en: "images/num/m.png", //单位
      // invalid_image: 'images/bottomnum/null.png', //空
      show_level: hmUI.show_level.ONLY_NORMAL, //亮屏状态下显示
      padding: true, //补零
    };
    // PAI
    let objPai = {
      x: 131 * num,
      y: 20 * num,
      w: 90 * num,
      type: hmUI.data_type.PAI_WEEKLY, //监听数据类型
      font_array: arrNum, //数字图片数组
      h_space: 0, //图片间隔
      align_h: hmUI.align.RIGHT, //对其方式
      // invalid_image: 'images/painum/null.png', //空
      show_level: hmUI.show_level.ONLY_NORMAL, //亮屏状态下显示
      padding: true, //补零
    };
    // UVI
    let objUVI = {
      x: 77 * num,
      y: 57 * num,
      w: 90 * num,
      type: hmUI.data_type.UVI, //监听数据类型
      font_array: arrNum, //数字图片数组
      h_space: 0, //图片间隔
      align_h: hmUI.align.RIGHT, //对其方式
      invalid_image: "images/num/null.png", //空
      show_level: hmUI.show_level.ONLY_NORMAL, //亮屏状态下显示
      padding: true, //补零
    };

    //电量进度条
    let objBatLevel = {
      x: 406 * num,
      y: 154 * num, //宽高可省略
      image_array: arrBatLevel,
      image_length: arrBatLevel.length, //长度
      type: hmUI.data_type.BATTERY,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };

    //步数进度条
    let objStepLevel = {
      x: 13 * num,
      y: 227 * num, //宽高可省略
      image_array: arrStepLevel,
      image_length: arrStepLevel.length, //长度
      type: hmUI.data_type.STEP,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };

    //月圆进度条
    let objMoonLevel = {
      x: 199 * num,
      y: 234 * num, //宽高可省略
      image_array: arrMoonLevel,
      image_length: arrMoonLevel.length, //长度
      type: hmUI.data_type.MOON,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };

    const logger = DeviceRuntimeCore.HmLogger.getLogger("sanjiao"); //导入打印工具
    //==================================================================
    //这里可以直接不写function，定义的方法写这里
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      //封装好的方法在这里使用
      init_view() {
        let bgNor = hmUI.createWidget(hmUI.widget.IMG, bgImg); //亮屏背景
        hmUI.createWidget(hmUI.widget.IMG_WEEK, objWeek); //星期
        let widgetMon = hmUI.createWidget(hmUI.widget.IMG_DATE, objMonth); //亮屏月份
        hmUI.createWidget(hmUI.widget.IMG_DATE, objDate); //亮屏月份
        hmUI.createWidget(hmUI.widget.IMG_TIME, objTime); //时间
        hmUI.createWidget(hmUI.widget.IMG_TIME, objTimeAod); //时间
        hmUI.createWidget(hmUI.widget.TEXT_IMG, objDISTANCE); //日出
        hmUI.createWidget(hmUI.widget.TEXT_IMG, objStep); //步数
        hmUI.createWidget(hmUI.widget.TEXT_IMG, objBat); //电量
        hmUI.createWidget(hmUI.widget.TEXT_IMG, objALTIMETER); //气压
        hmUI.createWidget(hmUI.widget.TEXT_IMG, objALTITUDE); //海拔
        hmUI.createWidget(hmUI.widget.TEXT_IMG, objHeart); //心率
        hmUI.createWidget(hmUI.widget.TEXT_IMG, objCal); //cal
        hmUI.createWidget(hmUI.widget.IMG_LEVEL, objBatLevel); //电量进度条
        hmUI.createWidget(hmUI.widget.IMG_LEVEL, objStepLevel); //步数进度条
        hmUI.createWidget(hmUI.widget.IMG_LEVEL, objMoonLevel); //月相进度条
        hmUI.createWidget(hmUI.widget.TEXT_IMG, objPai);
        hmUI.createWidget(hmUI.widget.TEXT_IMG, objUVI);

        //------------------------------------------------------------------
        //---------------农历日期--------------------
        let objLunar = "",
          lunarText = "",
          lunarMonth = "",
          lunarDay = "",
          lunarDate = "",
          lunarCurrent = "";

        function n(n) {
          return "INVALID" === n;
        }
        objLunar = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 155 * num,
          y: 402 * num,
          w: 140 * num,
          h: 40,
          text: "--",
          color: "0xced1d6",
          text_size: 24,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.NONE,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        objLunar.setProperty(hmUI.prop.VISIBLE, false);

        setNongLi(); //设置农历
        function getLunar() {
          language = hmSetting.getLanguage();
          // if (deviceSource == 419) {
          //   return;
          // }
          if (language == 1 || language == 0) {
            //中文情况下才展示农历
            objLunar.setProperty(hmUI.prop.VISIBLE, true);
            lunarMonth = jstime.lunar_month;
            lunarDay = jstime.lunar_day;
            lunarCurrent = jstime.getShowFestival();
            // let dateFormat = hmSetting.getDateFormat();
            if (lunarMonth === `一月`) {
              lunarMonth = `正月`;
            }
            lunarDate = lunarMonth + lunarDay;

            lunarCurrent = n(lunarCurrent) ? "" : lunarCurrent;
            // n(lunarMonth) || (lunarMonth.indexOf("闰") > -1 ? lunarText = (lunarMonth + lunarDay) : n(lunarDay) || (lunarText = lunarDate));

            n(lunarMonth) ||
              (lunarMonth.indexOf("闰") > -1
                ? (lunarText = lunarMonth + lunarDay)
                : n(lunarDay) || (lunarText = lunarDate));

            /**
             * 腊八节  小年 春节  元宵节 端午节  七夕  中元节  中秋节    重阳节  除夕  龙抬头   显示这十一个节日（国内海外版本一致）    
             注：
             七夕情人节   只显示七夕    
             元旦  有就显示没有就不显示（非leiden 平台）
             `立春`, `惊蛰`, `清明`, `立夏`, `芒种`, `小暑`, `立秋`, `白露`, `寒露`, `立冬`, `大雪`, `小寒`,
             `雨水`, `春分`, `谷雨`, `小满`, `夏至`, `大暑`, `处暑`, `秋分`, `霜降`, `小雪`, `冬至`, `大寒`
             */
            let lunar = [
              `腊八节`,
              `小年`,
              `春节`,
              `元宵节`,
              `端午节`,
              `七夕情人节`,
              `中元节`,
              `中秋节`,
              `重阳节`,
              `除夕`,
              `龙抬头`,
              `元旦`,
              `立春`,
              `惊蛰`,
              `清明`,
              `立夏`,
              `芒种`,
              `小暑`,
              `立秋`,
              `白露`,
              `寒露`,
              `立冬`,
              `大雪`,
              `小寒`,
              `雨水`,
              `春分`,
              `谷雨`,
              `小满`,
              `夏至`,
              `大暑`,
              `处暑`,
              `秋分`,
              `霜降`,
              `小雪`,
              `冬至`,
              `大寒`,
            ];
            if (lunar.indexOf(lunarCurrent) > -1) {
              if (lunarCurrent == `七夕情人节`) {
                lunarCurrent = `七夕`;
              }
              lunarText = lunarCurrent;
            } else {
              lunarText = lunarDate;
            }

            //----------------

            objLunar.setProperty(hmUI.prop.MORE, {
              text: lunarText,
              // text: lunarCurrent || lunarText
            });
          } else {
            objLunar.setProperty(hmUI.prop.VISIBLE, false);
          }
        }

        function setNongLi() {
          const deviceInfo = hmSetting.getDeviceInfo();
          var languge1 = hmSetting.getLanguage(); //返回当前语言的序号
          widgetMon.setProperty(hmUI.prop.VISIBLE, false);

          if (deviceInfo.deviceSource == 419) {
            //如果是国际版泰德维也纳
            if (languge1 == 0) {
              bgNor.setProperty(hmUI.prop.SRC, "images/background_sc.png"); //如果背景特别需要处理的情况下用（如果不用这里就直接换成正常背景或者直接注释掉）
            } else if (languge1 == 1) {
              bgNor.setProperty(hmUI.prop.SRC, "images/background_tc.png"); //如果背景特别需要处理的情况下用（如果不用这里就直接换成正常背景或者直接注释掉）
            } else {
              bgNor.setProperty(hmUI.prop.SRC, "images/background_en.png"); //如果背景特别需要处理的情况下用（如果不用这里就直接换成正常背景或者直接注释掉）
            }
            widgetMon.setProperty(hmUI.prop.VISIBLE, true);
          } else {
            //不是国际版时候

            if (languge1 == 0) {
              getLunar(); //获取阳历
              bgNor.setProperty(hmUI.prop.SRC, "images/background_sc.png");
            } else if (languge1 == 1) {
              getLunar(); //获取阳历
              bgNor.setProperty(hmUI.prop.SRC, "images/background_tc.png");
            } else {
              widgetMon.setProperty(hmUI.prop.VISIBLE, true);
              getLunar(); //获取阳历
              bgNor.setProperty(hmUI.prop.SRC, "images/background_en.png");
            }
          }
        }

        //===================点击事件===================
        //============================================================
        // let paiClick = hmUI.createWidget(hmUI.widget.IMG_CLICK, { //使用IMGCLICK控件传入组件对应类型
        //   x: 180 * num,
        //   y: 16 * num,
        //   w: 88 * num,
        //   h: 29 * num,
        //   type: hmUI.data_type.PAI_WEEKLY,
        // })
        // let uviClick = hmUI.createWidget(hmUI.widget.IMG_CLICK, { //使用IMGCLICK控件传入组件对应类型
        //   x: 131 * num,
        //   y: 55 * num,
        //   w: 115 * num,
        //   h: 27 * num,
        //   type: hmUI.data_type.UVI,
        // })
        // let stepClick = hmUI.createWidget(hmUI.widget.IMG_CLICK, { //使用IMGCLICK控件传入组件对应类型
        //   x: 82 * num,
        //   y: 91 * num,
        //   w: 137 * num,
        //   h: 25 * num,
        //   type: hmUI.data_type.STEP,
        // })
        // let stepClick1 = hmUI.createWidget(hmUI.widget.IMG_CLICK, { //使用IMGCLICK控件传入组件对应类型
        //   x: 21 * num,
        //   y: 194 * num,
        //   w: 176 * num,
        //   h: 53 * num,
        //   type: hmUI.data_type.STEP,
        // })
        // let kpaClick = hmUI.createWidget(hmUI.widget.IMG_CLICK, { //使用IMGCLICK控件传入组件对应类型
        //   x: 29 * num,
        //   y: 253 * num,
        //   w: 129 * num,
        //   h: 29 * num,
        //   type: hmUI.data_type.ALTIMETER,
        // })
        // let altClick = hmUI.createWidget(hmUI.widget.IMG_CLICK, { //使用IMGCLICK控件传入组件对应类型
        //   x: 280 * num,
        //   y: 242 * num,
        //   w: 103 * num,
        //   h: 27 * num,
        //   type: hmUI.data_type.ALTITUDE,
        // })
        // let heartClick = hmUI.createWidget(hmUI.widget.IMG_CLICK, { //使用IMGCLICK控件传入组件对应类型
        //   x: 62 * num,
        //   y: 130 * num,
        //   w: 51 * num,
        //   h: 52 * num,
        //   type: hmUI.data_type.HEART,
        // })
        // let calClick = hmUI.createWidget(hmUI.widget.IMG_CLICK, { //使用IMGCLICK控件传入组件对应类型
        //   x: 169 * num,
        //   y: 129 * num,
        //   w: 55 * num,
        //   h: 52 * num,
        //   type: hmUI.data_type.CAL,
        // })
        // let moonClick = hmUI.createWidget(hmUI.widget.IMG_CLICK, { //使用IMGCLICK控件传入组件对应类型
        //   x: 198 * num,
        //   y: 233 * num,
        //   w: 50 * num,
        //   h: 50 * num,
        //   type: hmUI.data_type.MOON,
        // })

        hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: function () {
            setNongLi(); //获取阳历
          },
          pause_call: function () {},
        });
      },
      onInit() {
        console.log("index page.js on init invoke");
        this.init_view();
      },

      onReady() {
        console.log("index page.js on ready invoke");
      },

      onShow() {
        console.log("index page.js on show invoke");
      },

      onHide() {
        console.log("index page.js on hide invoke");
      },

      onDestory() {
        console.log("index page.js on destory invoke");
      },
    });
    /*
     * end js
     */
  })();
} catch (e) {
  console.log(e);
}
