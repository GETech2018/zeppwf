try {
  (() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__),
      "drink"
    );

    /*
     * huamiOS bundle tool v1.0.17
     * Copyright © Huami. All Rights Reserved
     */
    ("use strict");

    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);
    //=================定义静态资源数据数组============================
    let textSrcPath = "";

    let rootPath = "images/";
    let dataPath = rootPath + "data/";
    let timePath = rootPath + "time/";
    let dateEnPath = rootPath + "date/en/";
    let dateScPath = rootPath + "date/sc/";
    let monthPath = rootPath + "month/";

    let week_enPath = rootPath + "week/en/";
    let week_scPath = rootPath + "week/sc/";

    let weatherPath = dataPath + "weather/";
    let batPath = dataPath + "bat/";
    let stepPath = dataPath + "step/"; // 心率步数通用
    let tempCurPath = dataPath + "temp/current/";
    let tempLowPath = dataPath + "temp/high/";
    let calPath = dataPath + "cal/"; // 最大摄氧和卡路里 通用
    let textScPath = dataPath + "text/sc/";
    let textEnPath = dataPath + "text/en/";
    let textTcPath = dataPath + "text/tc/";

    let hourPath = timePath + "hour/";
    let secondPath = timePath + "second/";
    let ampmPath = timePath + "ampm/";

    const arrWeekEn = []; //英文星期数组
    const arrWeekSc = []; //中文简体星期数组
    const arrWeekTc = []; //中文繁体星期数组
    const arrdateEnNum = []; //日期数组-英文
    const arrdateScNum = []; //日期数组-中文
    const arrStepNum = []; //步数数组
    const arrCalNum = []; //卡路里数组
    const arrBatNum = []; //卡路里数组
    const arrWeather = []; //天气图标

    const arrCurTempNum = []; //实时温度数组
    const arrLowTempNum = []; //高低温数组

    // const arrpaiNum = [] //日期数组
    const arrMonth = []; //日期数组

    const arrTimeNorNum = []; //时间数字
    const arrTimeSedNorNum = []; //时间秒
    const arrTimeAodNum = []; //时间数字 息屏

    const num = 0.916; //不需要适配时候开放
    const jstime = hmSensor.createSensor(hmSensor.id.TIME);

    //================================================================
    function getPathByLanguage(lan, type) {
      switch (lan) {
        case 2:
          textSrcPath = textEnPath + type + ".png";
          break;
        case 0:
          textSrcPath = textScPath + type + ".png";
          break;
        case 1:
          textSrcPath = textTcPath + type + ".png";
          break;
        default:
          textSrcPath = textEnPath + type + ".png";
      }
      return textSrcPath;
    }
    //高低温跟随
    function fnGetTemperature(xPos, yPos, groupType) {
      let objTemperature = {
        x: xPos,
        y: yPos,
        type: groupType,
        font_array: arrLowTempNum,
        h_space: 0, //图片间隔
        align_h: hmUI.align.LEFT, //对其方式
        unit_sc: tempLowPath + "du.png", //单位,
        unit_en: tempLowPath + "du.png", //单位,
        unit_tc: tempLowPath + "du.png", //单位,
        negative_image: tempLowPath + "dot.png", //单位,
        invalid_image: tempLowPath + "null.png", //单位,
        show_level: hmUI.show_level.ONLY_NORMAL,
      };
      return hmUI.createWidget(hmUI.widget.TEXT_IMG, objTemperature);
    }
    for (let i = 1; i < 8; i++) {
      arrWeekEn.push(week_enPath + i + ".png");
      arrWeekSc.push(week_scPath + i + ".png");
      arrWeekTc.push(week_scPath + i + ".png");
    }
    for (let i = 0; i < 10; i++) {
      arrdateEnNum.push(dateEnPath + i + ".png");
      arrdateScNum.push(dateScPath + i + ".png");

      arrCurTempNum.push(tempCurPath + i + ".png");
      arrLowTempNum.push(tempLowPath + i + ".png");

      arrStepNum.push(stepPath + i + ".png");
      arrCalNum.push(calPath + i + ".png");
      arrBatNum.push(batPath + i + ".png");
      arrTimeAodNum.push("images/timeXp/" + i + ".png");
      arrTimeNorNum.push(hourPath + i + ".png");
      arrTimeSedNorNum.push(secondPath + i + ".png");
    }
    // // 月份
    for (i = 1; i < 13; i++) {
      arrMonth.push(`images/month/${i}.png`);
    }
    // // 天气图标
    for (i = 0; i < 29; i++) {
      arrWeather.push(weatherPath + i + ".png");
    }

    //================================================================
    //亮屏背景
    let bgImg = {
      x: 0,
      y: 0,
      src: "images/bg.png",
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    let ambgImg = {
      x: 333 * num,
      y: 112 * num,
      src: ampmPath + "ambg.png",
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    let gangImg = {
      x: 249 * num,
      y: 65 * num,
      src: tempLowPath + "gang.png",
      show_level: hmUI.show_level.ONLY_NORMAL,
    };

    //星期农历
    let objNlWeek = {
      x: 333 * num,
      y: 273 * num,
      week_en: arrWeekSc,
      week_sc: arrWeekSc,
      week_tc: arrWeekTc,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    //星期阳历
    let objYlWeek = {
      x: 240 * num,
      y: 270 * num,
      week_en: arrWeekEn,
      week_sc: arrWeekEn,
      week_tc: arrWeekEn,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    let iconHeart = {
      x: 72 * num,
      y: 326 * num,
      src: rootPath + "heart.png",
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    let iconStep = {
      x: 243 * num,
      y: 326 * num,
      src: rootPath + "step.png",
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    let iconBat = {
      x: 142 * num,
      y: 26 * num,
      src: rootPath + "bat.png",
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    let obj_text_cal = {
      x: 239 * num,
      y: 375 * num,
      src: textEnPath + "cal.png",
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    let obj_text_maxo = {
      x: 112 * num,
      y: 375 * num,
      src: textEnPath + "maxo.png",
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    //最大摄氧量
    let obj_maxo = {
      x: 120 * num,
      y: 405 * num,
      w: 90 * num,
      type: hmUI.data_type.VO2MAX,
      font_array: arrCalNum,
      invalid_image: calPath + "null.png",
      h_space: 0,
      align_h: hmUI.align.RIGHT,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    //消耗
    let obj_cal = {
      x: 244 * num,
      y: 405 * num,
      w: 60 * num,
      type: hmUI.data_type.CAL,
      font_array: arrCalNum,
      invalid_image: calPath + "null.png",
      h_space: 0,
      align_h: hmUI.align.LEFT,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    // 时间亮屏
    let objTime = {
      hour_zero: true, //是否补零
      hour_startX: 42 * num,
      hour_startY: 111 * num,
      hour_array: arrTimeNorNum,
      hour_space: 0, //每个数组间的间隔
      hour_unit_sc: hourPath + "mao.png",
      hour_unit_tc: hourPath + "mao.png",
      hour_unit_en: hourPath + "mao.png",
      hour_align: hmUI.align.LEFT, //靠左对齐

      minute_zero: true, //是否补零
      minute_startX: 195 * num,
      minute_startY: 111 * num,
      minute_array: arrTimeNorNum,
      minute_space: 0, //每个数组间的间隔
      minute_align: hmUI.align.LEFT, //靠左对齐

      second_zero: true, //是否补零
      second_startX: 336 * num,
      second_startY: 148 * num,
      second_array: arrTimeSedNorNum,
      second_space: 0, //每个数组间的间隔
      second_align: hmUI.align.LEFT, //靠左对齐

      am_x: 333 * num,
      am_y: 112 * num,
      am_sc_path: ampmPath + "am_sc.png",
      am_en_path: ampmPath + "am_en.png",
      pm_x: 333 * num,
      pm_y: 112 * num,
      pm_sc_path: ampmPath + "pm_sc.png",
      pm_en_path: ampmPath + "pm_en.png",

      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    // 时间息屏
    let objTimeAod = {
      hour_zero: true, //是否补零
      hour_startX: 42 * num,
      hour_startY: 111 * num,
      hour_array: arrTimeAodNum,
      hour_space: 0, //每个数组间的间隔
      hour_unit_sc: "images/timeXp/mao.png",
      hour_unit_tc: "images/timeXp/mao.png",
      hour_unit_en: "images/timeXp/mao.png",
      hour_align: hmUI.align.LEFT, //靠左对齐

      minute_zero: true, //是否补零
      minute_startX: 195 * num,
      minute_startY: 111 * num,
      minute_array: arrTimeAodNum,
      minute_space: 0, //每个数组间的间隔
      minute_align: hmUI.align.LEFT, //靠左对齐
      show_level: hmUI.show_level.ONLY_AOD,
    };

    //日期月份
    let objNlDate = {
      month_startX: 242 * num,
      month_startY: 274 * num,
      month_align: hmUI.align.LEFT,
      month_en_array: arrdateScNum,
      month_sc_array: arrdateScNum,
      month_tc_array: arrdateScNum,
      month_unit_sc: "images/date/sc/dot.png", //单位
      month_unit_tc: "images/date/sc/dot.png",
      month_unit_en: "images/date/sc/dot.png",
      month_zero: 1, //是否补零

      day_follow: 1, //是否跟随
      day_zero: 1, //是否补零
      day_en_array: arrdateScNum,
      day_sc_array: arrdateScNum,
      day_tc_array: arrdateScNum,
      // month_is_character: true, //年份此字段无效 默认为false 为true时 传入的图片为月份12张 日31张
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    let objYlDate = {
      month_startX: 240 * num,
      month_startY: 232 * num,
      month_align: hmUI.align.LEFT,
      month_en_array: arrMonth,
      month_sc_array: arrMonth,
      month_tc_array: arrMonth,
      month_zero: 0,
      month_follow: 0,
      month_space: 0,
      month_is_character: true,

      day_startX: 311 * num,
      day_startY: 232 * num,
      day_align: hmUI.align.LEFT,
      day_follow: 0, //是否跟随
      day_zero: 1, //是否补零
      day_en_array: arrdateEnNum,
      day_sc_array: arrdateEnNum,
      day_tc_array: arrdateEnNum,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    //温度
    let objDu = {
      x: 264 * num,
      y: 28 * num,
      w: 50 * num,
      type: hmUI.data_type.WEATHER_CURRENT, //监听数据类型
      font_array: arrCurTempNum, //数字图片数组
      h_space: 0, //图片间隔
      align_h: hmUI.align.LEFT, //对其方式
      // padding: true, //补零
      invalid_image: tempCurPath + "null.png", //空
      negative_image: tempCurPath + "dot.png", //负号图片
      unit_sc: tempCurPath + "du.png", //单位
      unit_tc: tempCurPath + "du.png", //单位
      unit_en: tempCurPath + "du.png", //单位
      show_level: hmUI.show_level.ONLY_NORMAL, //亮屏状态下显示
    };
    // // 步数
    let objStep = {
      x: 287 * num,
      y: 326 * num,
      w: 90 * num,
      type: hmUI.data_type.STEP, //监听数据类型
      font_array: arrStepNum, //数字图片数组
      h_space: 0, //图片间隔
      align_h: hmUI.align.LEFT, //对其方式
      show_level: hmUI.show_level.ONLY_NORMAL, //亮屏状态下显示
      // padding: true, //补零
    };
    // // 电量
    let objBat = {
      x: 93 * num,
      y: 61 * num,
      w: 80 * num,
      type: hmUI.data_type.BATTERY, //监听数据类型
      font_array: arrBatNum, //数字图片数组
      h_space: 0, //图片间隔
      unit_sc: batPath + "dot.png", //单位
      unit_tc: batPath + "dot.png", //单位
      unit_en: batPath + "dot.png", //单位
      align_h: hmUI.align.RIGHT, //对其方式
      show_level: hmUI.show_level.ONLY_NORMAL, //亮屏状态下显示
      // padding: true, //补零
    };
    // // 心率
    let objHeart = {
      x: 116 * num,
      y: 327 * num,
      w: 60 * num,
      type: hmUI.data_type.HEART, //监听数据类型
      font_array: arrStepNum, //数字图片数组
      h_space: 0, //图片间隔
      align_h: hmUI.align.LEFT, //对其方式
      invalid_image: stepPath + "null.png", //空
      show_level: hmUI.show_level.ONLY_NORMAL, //亮屏状态下显示
      // padding: true, //补零
    };

    // //天气图标
    let objWeather = {
      x: 212 * num,
      y: 19 * num, //宽高可省略
      image_array: arrWeather,
      image_length: arrWeather.length, //长度
      type: hmUI.data_type.WEATHER,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };

    const logger = DeviceRuntimeCore.HmLogger.getLogger("yuhangyuan"); //导入打印工具
    //==================================================================
    //这里可以直接不写function，定义的方法写这里
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      //封装好的方法在这里使用
      init_view() {
        let bgNor = hmUI.createWidget(hmUI.widget.IMG, bgImg); //亮屏背景
        hmUI.createWidget(hmUI.widget.IMG_ANIM, {
          x: 0,
          y: 0,
          w: 416,
          h: 416,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          anim_path: rootPath + "anim",
          anim_prefix: "yhy",
          anim_ext: "png",
          anim_fps: 30,
          anim_size: 50,
          anim_repeat: true,
          repeat_count: 0,
          anim_status: 1,
          display_on_restart: true,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        hmUI.createWidget(hmUI.widget.IMG, ambgImg);
        hmUI.createWidget(hmUI.widget.IMG, iconBat);
        hmUI.createWidget(hmUI.widget.IMG, iconHeart);
        hmUI.createWidget(hmUI.widget.IMG, iconStep);

        let calText = hmUI.createWidget(hmUI.widget.IMG, obj_text_cal);
        let maxoText = hmUI.createWidget(hmUI.widget.IMG, obj_text_maxo);

        let languge = hmSetting.getLanguage(); //返回当前语言的序号
        calText.setProperty(hmUI.prop.SRC, getPathByLanguage(languge, "cal"));
        maxoText.setProperty(hmUI.prop.SRC, getPathByLanguage(languge, "maxo"));

        hmUI.createWidget(hmUI.widget.TEXT_IMG, obj_maxo);
        hmUI.createWidget(hmUI.widget.TEXT_IMG, obj_cal);
        hmUI.createWidget(hmUI.widget.IMG_TIME, objTime); //时间
        hmUI.createWidget(hmUI.widget.IMG_TIME, objTimeAod); //时间
        hmUI.createWidget(hmUI.widget.TEXT_IMG, objDu); //温度
        // hmUI.createWidget(hmUI.widget.TEXT_IMG, objHightDu) //温度最高
        // hmUI.createWidget(hmUI.widget.TEXT_IMG, objLowDu) //温度最高

        var weatherLow = fnGetTemperature(
          216 * num,
          64 * num,
          hmUI.data_type.WEATHER_LOW
        );
        var weatherHigh = fnGetTemperature(
          264 * num,
          64 * num,
          hmUI.data_type.WEATHER_HIGH
        );
        var gangWidget = hmUI.createWidget(hmUI.widget.IMG, gangImg);

        weatherHigh.layoutChange(function (obj) {
          var end_X = weatherLow.getProperty(hmUI.prop.END_X);
          let gangX = end_X + 4;
          let highX = end_X + 18;
          gangWidget.setProperty(hmUI.prop.X, gangX);
          weatherHigh.setProperty(hmUI.prop.X, highX);
        });

        hmUI.createWidget(hmUI.widget.TEXT_IMG, objStep); //步数
        hmUI.createWidget(hmUI.widget.TEXT_IMG, objBat); //电量
        hmUI.createWidget(hmUI.widget.TEXT_IMG, objHeart); //心率
        hmUI.createWidget(hmUI.widget.IMG_LEVEL, objWeather); //天气图标

        let widgetYlWeek = hmUI.createWidget(hmUI.widget.IMG_WEEK, objYlWeek); //星期
        let widgetYlDate = hmUI.createWidget(hmUI.widget.IMG_DATE, objYlDate); //阳历日期

        let widgetNlWeek = hmUI.createWidget(hmUI.widget.IMG_WEEK, objNlWeek); //星期
        let widgetNlDate = hmUI.createWidget(hmUI.widget.IMG_DATE, objNlDate); //农历日期

        widgetNlWeek.setProperty(hmUI.prop.VISIBLE, false);
        widgetNlDate.setProperty(hmUI.prop.VISIBLE, false);

        widgetYlWeek.setProperty(hmUI.prop.VISIBLE, false);
        widgetYlDate.setProperty(hmUI.prop.VISIBLE, false);

        // //---------------农历日期--------------------
        let objLunar = "",
          lunarText = "",
          lunarMonth = "",
          lunarDay = "",
          lunarDate = "",
          lunarCurrent = "";

        function n(n) {
          return "INVALID" === n;
        }
        objLunar = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 242 * num,
          y: 229 * num,
          w: 155 * num,
          h: 35 * num,
          text: "--",
          color: "0x4C4C4C",
          text_size: 31 * num,
          align_h: hmUI.align.LEFT,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.NONE,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        objLunar.setProperty(hmUI.prop.VISIBLE, false);

        setNongLi(); //设置农历

        function getLunar() {
          language = hmSetting.getLanguage();
          // if (deviceSource == 419) {
          //   return;
          // }
          if (language == 1 || language == 0) {
            //中文情况下才展示农历
            objLunar.setProperty(hmUI.prop.VISIBLE, true);
            lunarMonth = jstime.lunar_month;
            lunarDay = jstime.lunar_day;
            lunarCurrent = jstime.getShowFestival();
            // let dateFormat = hmSetting.getDateFormat();
            if (lunarMonth === `一月`) {
              lunarMonth = `正月`;
            }
            lunarDate = lunarMonth + lunarDay;

            lunarCurrent = n(lunarCurrent) ? "" : lunarCurrent;
            // n(lunarMonth) || (lunarMonth.indexOf("闰") > -1 ? lunarText = (lunarMonth + lunarDay) : n(lunarDay) || (lunarText = lunarDate));

            n(lunarMonth) ||
              (lunarMonth.indexOf("闰") > -1
                ? (lunarText = lunarMonth + lunarDay)
                : n(lunarDay) || (lunarText = lunarDate));

            /**
             * 腊八节  小年 春节  元宵节 端午节  七夕  中元节  中秋节    重阳节  除夕  龙抬头   显示这十一个节日（国内海外版本一致）
             注：
             七夕情人节   只显示七夕
             元旦  有就显示没有就不显示（非leiden 平台）
             `立春`, `惊蛰`, `清明`, `立夏`, `芒种`, `小暑`, `立秋`, `白露`, `寒露`, `立冬`, `大雪`, `小寒`,
             `雨水`, `春分`, `谷雨`, `小满`, `夏至`, `大暑`, `处暑`, `秋分`, `霜降`, `小雪`, `冬至`, `大寒`
             */
            let lunar = [
              `腊八节`,
              `小年`,
              `春节`,
              `元宵节`,
              `端午节`,
              `七夕情人节`,
              `中元节`,
              `中秋节`,
              `重阳节`,
              `除夕`,
              `龙抬头`,
              `元旦`,
              `立春`,
              `惊蛰`,
              `清明`,
              `立夏`,
              `芒种`,
              `小暑`,
              `立秋`,
              `白露`,
              `寒露`,
              `立冬`,
              `大雪`,
              `小寒`,
              `雨水`,
              `春分`,
              `谷雨`,
              `小满`,
              `夏至`,
              `大暑`,
              `处暑`,
              `秋分`,
              `霜降`,
              `小雪`,
              `冬至`,
              `大寒`,
            ];
            if (lunar.indexOf(lunarCurrent) > -1) {
              if (lunarCurrent == `七夕情人节`) {
                lunarCurrent = `七夕`;
              }
              lunarText = lunarCurrent;
            } else {
              lunarText = lunarDate;
            }

            //----------------

            objLunar.setProperty(hmUI.prop.MORE, {
              // color,
              text: lunarText,
              // text: lunarCurrent || lunarText
            });
          } else {
            objLunar.setProperty(hmUI.prop.VISIBLE, false);
          }
        }

        function showData(isEn) {
          //isHaiwai：是否是海外表
          widgetYlDate.setProperty(hmUI.prop.VISIBLE, isEn);
          widgetYlWeek.setProperty(hmUI.prop.VISIBLE, isEn);

          widgetNlWeek.setProperty(hmUI.prop.VISIBLE, !isEn);
          widgetNlDate.setProperty(hmUI.prop.VISIBLE, !isEn);
        }

        function setNongLi() {
          let languge1 = hmSetting.getLanguage(); //返回当前语言的序号
          if (languge1 == 0 || languge1 == 1) {
            // 简体中文或繁体中文
            showData(false);
            getLunar();
          } else {
            showData(true);
            objLunar.setProperty(hmUI.prop.VISIBLE, false);
          }
        }

        let weatherClick = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          //使用IMGCLICK控件传入组件对应类型
          x: 206 * num,
          y: 18 * num,
          w: 100 * num,
          h: 70 * num,
          type: hmUI.data_type.WEATHER,
        });
        let stepClick = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          //使用IMGCLICK控件传入组件对应类型
          x: 235 * num,
          y: 323 * num,
          w: 146 * num,
          h: 36 * num,
          type: hmUI.data_type.STEP,
        });
        let vo2maxClick = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          //使用IMGCLICK控件传入组件对应类型
          x: 127 * num,
          y: 375 * num,
          w: 100 * num,
          h: 57 * num,
          type: hmUI.data_type.VO2MAX,
        });
        let heartClick = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          //使用IMGCLICK控件传入组件对应类型
          x: 72 * num,
          y: 322 * num,
          w: 105 * num,
          h: 38 * num,
          type: hmUI.data_type.HEART,
        });
        let calClick = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          //使用IMGCLICK控件传入组件对应类型
          x: 236 * num,
          y: 375 * num,
          w: 90 * num,
          h: 55 * num,
          type: hmUI.data_type.CAL,
        });

        hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: function () {
            let lan = hmSetting.getLanguage(); //返回当前语言的序号
            calText.setProperty(hmUI.prop.SRC, getPathByLanguage(lan, "cal"));
            maxoText.setProperty(hmUI.prop.SRC, getPathByLanguage(lan, "maxo"));
            setNongLi();
          },
          pause_call: function () {
            console.log("ui pause");
          },
        });
      },
      onInit() {
        console.log("index page.js on init invoke");
        this.init_view();
      },

      onReady() {
        console.log("index page.js on ready invoke");
      },

      onShow() {
        console.log("index page.js on show invoke");
      },

      onHide() {
        console.log("index page.js on hide invoke");
      },

      onDestory() {
        console.log("index page.js on destory invoke");
      },
    });
    /*
     * end js
     */
  })();
} catch (e) {
  console.log(e);
}
