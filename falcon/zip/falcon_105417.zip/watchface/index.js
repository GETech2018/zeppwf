/*
 * =====================================================================================
 *
 *  Copyright (C) 2021. Huami Ltd, unpublished work. This computer program includes
 *  Confidential, Proprietary Information and is a Trade Secret of Huami Ltd.
 *  All use, disclosure, and/or reproduction is prohibited unless authorized in writing.
 *  All Rights Reserved.
 *
 *  Author: hmkj
 *
 * =====================================================================================
 */
try {
  (() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');
    /*
     * huamiOS bundle tool v1.0.17
     * Copyright © Huami. All Rights Reserved
     */
    'use strict';
    const arrHeartLevel = []
    const arrHeartFont = []
    const arrMoon = []
    const arrWeek = []
    const arrTime = []
    const arrSecond = []
    const arrData = []
    const arrWeather = []
    const arrWeatherFont = []
    const arrMonth = []
    const arrAodTime = []
    for(let i = 1;i < 7;i++) {
      arrHeartLevel.push("images/heartlevel/" + i + ".png")
    }
    for(let i = 0; i < 10;i++) {
      arrHeartFont.push("images/heartfont/" + i + ".png")
    }
    for(let i = 1; i < 8;i++) {    
      arrWeek.push("images/week/" + i + ".png")
    }
    for(let i = 1; i < 31;i++) {
      arrMoon.push("images/moon/" + i + ".png")     
    }
    for(let i = 0; i < 10;i++) {
      arrTime.push("images/time/" + i + ".png")
      arrAodTime.push("images/aod/" + i + ".png")
      arrSecond.push("images/second/" + i + ".png")
      arrData.push("images/data/" + i + ".png")
      arrWeatherFont.push("images/weatherfont/" + i + ".png")
    }
    for(let i = 0; i < 29;i++) {
      if(i >= 1 && i <= 12) {
        arrMonth.push("images/month/" + i + ".png")
      }
      arrWeather.push("images/weather/" + i + ".png")
    }
    function deepClone(target, changeObj) {
      let result;
      if (typeof target === 'object') {
          if (Array.isArray(target)) {
              result = []; 
              for (let i in target) {
                  result.push(deepClone(target[i]))
              }
          } else if (target === null) {
              result = null;
          } else if (target.constructor === RegExp) {
              result = target;
          } else {
              result = {};
              for (let i in target) {
                  result[i] = deepClone(target[i]);
              }
          }
      } else {
          result = target;
      }
      for(let key in changeObj) {
          result[key] = changeObj[key]
      }
      return result
    }
    class Time {
      constructor() {
        
      }
      pointer(option) {
        this.Pointerwidget = hmUI.createWidget(hmUI.widget.TIME_POINTER,option)
      }
      week(option) {
        this.weekWidget = hmUI.createWidget(hmUI.widget.IMG_WEEK,option)
      }
      data(option) {
        this.widget = hmUI.createWidget(hmUI.widget.IMG_TIME,option)
      }
      date(option) {
        this.widget = hmUI.createWidget(hmUI.widget.IMG_DATE,option)
      }
    }
    class Img {
      constructor(option) {
        this.widget = hmUI.createWidget(hmUI.widget.IMG,option)
      }
    }
    class Text {
      constructor(option,editType) {
        this.option = option
        this.editType = editType
        if(!this.editType) {
          this.widget =  hmUI.createWidget(hmUI.widget.TEXT_IMG,this.option)
        }
        if(this.editType) {
          for(let i = 0,len = this.option.optional_types.length;i < len;i++) {
            if(this.option.optional_types[i].type == this.editType) {
              for(let key in this.option.optional_types[i]) {
                if(key != "preview" && key != "type") {
                  this.option[key] = this.option.optional_types[i][key]
                }
              }
              delete this.option['optional_types']
              this.widget =  hmUI.createWidget(hmUI.widget.TEXT_IMG,this.option)
              break;
            }
          }
        }
      }
    }
    class Animate {
      constructor(option) {
        this.widget = hmUI.createWidget(hmUI.widget.IMG_ANIM,option)
      }
    }
    class Level {
      constructor(option,editType) {
        this.option = option
        this.editType = editType
      }
      imgLevel() {
        if(!this.editType) {
          this.widget = hmUI.createWidget(hmUI.widget.IMG_LEVEL,this.option)
        }
        if(typeof this.option.image_array[0] == "string") {
          this.widget = hmUI.createWidget(hmUI.widget.IMG_LEVEL,this.option)
          return
        }
        this.widget = hmUI.createWidget(hmUI.widget.IMG_LEVEL,this.option)
      }
    }
    const logger = DeviceRuntimeCore.HmLogger.getLogger("default2");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        const objBgOPtion = {x:0,y:0,src:"images/img/bg.png",show_level:hmUI.show_level.ONLY_NORMAL}
        const objHeartLevelOption = {x:165,y:52,image_array:arrHeartLevel,image_length:6,type:hmUI.data_type.HEART,show_level:hmUI.show_level.ONLY_NORMAL}
        const objMoonOption = deepClone(objHeartLevelOption,{x:69,y:86,image_array:arrMoon,image_length:arrMoon.length,type:hmUI.data_type.MOON})
        const objWeatherOption = deepClone(objHeartLevelOption,{x:328,y:213,image_array:arrWeather,image_length:29,type:hmUI.data_type.WEATHER_CURRENT})
        const objHeartTextOPtion = {
          x:220, 
          y:23,
          type:hmUI.data_type.HEART,
          font_array:arrHeartFont,
          h_space:0, 
          align_h:hmUI.align.LEFT,
          invalid_image:"images/heartfont/null.png",         
          show_level:hmUI.show_level.ONLY_NORMAL
        }
        const objWeatherTextOption = deepClone(objHeartTextOPtion,{
          x:270, 
          y:184,
          type:hmUI.data_type.WEATHER_CURRENT,
          font_array:arrWeatherFont,
          unit_en:"images/weatherfont/du.png",
          unit_sc:"images/weatherfont/du.png",
          unit_tc:"images/weatherfont/du.png",
          negative_image:"images/weatherfont/fuhao.png",
          invalid_image:"images/weatherfont/null.png",
          padding:false,
          show_level:hmUI.show_level.ONLY_NORMAL
        })
        const objWeekOption = {x:76,y:185,week_en:arrWeek,week_sc:arrWeek,week_tc:arrWeek,show_level:hmUI.show_level.ONLY_NORMAL}
        const objMaoOPtion = deepClone(objBgOPtion,{x:188,y:215,src:"images/time/mao.png",show_level:hmUI.show_level.ONLY_NORMAL})
        const objAodMaoOption = deepClone(objMaoOPtion,{src:"images/aod/mao.png",show_level:hmUI.show_level.ONAL_AOD})
        const objTimeTextOption = {
          hour_zero:1,
          hour_startX:72,
          hour_startY:215,
          hour_array:arrTime,
          hour_space:0, 
          hour_align:hmUI.align.LEFT,
          minute_zero:1,
          minute_startX:204,
          minute_startY:215,
          minute_array:arrTime,
          minute_space:0, 
          minute_align:hmUI.align.LEFT,
          second_zero:1,
          second_startX:320,
          second_startY:257,
          second_array:arrSecond,
          second_space:0, 
          second_align:hmUI.align.LEFT,
          am_x:24,
          am_y:227,
          am_sc_path:"images/img/am.png",
          am_en_path:"images/img/am.png",
          pm_x:24,
          pm_y:227,
          pm_sc_path:"images/img/pm.png",
          pm_en_path:"images/img/pm.png",
          show_level:hmUI.show_level.ONLY_NORMAL
        }
        const objAodTimeTextOption = {
          hour_zero:1,
          hour_startX:72,
          hour_startY:215,
          hour_array:arrAodTime,
          hour_space:0, 
          hour_align:hmUI.align.LEFT,
          minute_zero:1,
          minute_startX:204,
          minute_startY:215,
          minute_array:arrAodTime,
          minute_space:0, 
          minute_align:hmUI.align.LEFT,
          show_level:hmUI.show_level.ONAL_AOD
        }
        const objDateOption = {
          month_startX:138,
          month_startY:383,
          month_align:hmUI.align.LEFT,
          month_space:1,
          month_zero:0,
          month_follow:0,
          month_en_array:arrMonth,
          month_sc_array:arrMonth,
          month_tc_array:arrMonth,
          month_is_character:true, 
          show_level:hmUI.show_level.ONLY_NORMAL
        }
        const objStepOption = {
          x:218, 
          y:327,
          w:88,
          type:hmUI.data_type.STEP,
          font_array:arrData,
          h_space:2, 
          align_h:hmUI.align.RIGHT,
          padding:false,
          show_level:hmUI.show_level.ONLY_NORMAL
        }
        const objBatteryOption = deepClone(objStepOption,{
          x:147, 
          y:327,
          w:56,
          type:hmUI.data_type.BATTERY,
          font_array:arrData,
          h_space:3, 
          show_level:hmUI.show_level.ONLY_NORMAL
        })
        const objUviOption = deepClone(objStepOption,{
          x:347, 
          y:104,
          w:40,
          type:hmUI.data_type.UVI,
          font_array:arrData,
          h_space:0, 
          align_h:hmUI.align.CENTER_H,
          invalid_image:"images/weatherfont/null.png",
          show_level:hmUI.show_level.ONLY_NORMAL
        })
        const objHeartLineOption = {
          x:158,
          y:102,
          w:146,
          h:50,
          type:hmUI.data_type.HEART,
          show_level:hmUI.show_level.ONLY_NORMAL
        }
        new Img(objBgOPtion)
        new Level(objHeartLevelOption).imgLevel()
        new Level(objMoonOption).imgLevel()
        new Level(objWeatherOption).imgLevel()
        new Text(objHeartTextOPtion)
        new Text(objWeatherTextOption)
        const time = new Time()
        const aodTime = new Time()
        time.week(objWeekOption)
        new Img(objMaoOPtion)
        new Img(objAodMaoOption)
        time.data(objTimeTextOption)
        aodTime.data(objAodTimeTextOption)
        time.date(objDateOption)
        for(let i = 0;i < 5;i++) {
          let nPosx = 218 + i*18
          const option ={x:nPosx,y:327,src:"images/data/8.png",show_level:hmUI.show_level.ONLY_NORMAL,alpha:40}
          new Img(option)
        }
        for(let i = 0; i < 3;i++) {
          let nPosx = 147 + i*18
          const option ={x:nPosx,y:327,src:"images/data/8.png",show_level:hmUI.show_level.ONLY_NORMAL,alpha:40}
          new Img(option)
        }
        new Text(objUviOption)
        new Text(objBatteryOption)
        new Text(objStepOption)
        const heartLine = hmUI.createWidget(hmUI.widget.GRADKIENT_POLYLINE,objHeartLineOption);     
      },
      onInit() {
        this.init_view();
      },
      onReady() {
        console.log('index page.js on ready invoke')
      },
      onShow() {
        console.log('index page.js on show invoke')
      },
      onHide() {
        console.log('index page.js on hide invoke')
      },
      onDestory() {
        console.log('index page.js on destory invoke')
      },
    });
    /*
     * end js
     */
  })()
} catch (e) {}