try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            image_background() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    src: 'bg/bg.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
            },
            create_widget({x, y, w, h, color, text = '', text_size, align_h = '', show_level = hmUI.show_level.ONLY_NORMAL}) {
                return hmUI.createWidget(hmUI.widget.TEXT, {
                    x: px(x),
                    y: px(y),
                    w: px(w),
                    h: px(h),
                    color,
                    text,
                    text_size: px(text_size),
                    align_h,
                    show_level
                });
            },
            data_module(x, y, w, h, color, text, text_size, sensor_id, sensor_event, get_sensor_value, align_h, show_level) {
                let widget = this.create_widget({
                    x,
                    y,
                    w,
                    h,
                    color,
                    text_size,
                    align_h,
                    show_level
                });
                let sensor = hmSensor.createSensor(hmSensor.id[sensor_id]);
                let event_id = hmSensor.event[sensor_event];
                let update = () => widget.setProperty(hmUI.prop.MORE, get_sensor_value(sensor));
                sensor.addEventListener(event_id, update);
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, { resume_call: update });
                if (sensor_id === 'TIME') {
                    timer.createTimer(0, 1000, update);
                }
            },
            digital_time() {
                this.data_module(166, 182, 260, 80, '0xFFFFFFFF', '', 50, 'TIME', 'MINUTEEND', sensor => ({ text: `${ String(sensor.hour).padStart(2, '0') }:${ String(sensor.minute).padStart(2, '0') }` }), '', hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD);
            },
            date() {
                this.data_module(290, 152, 200, 80, '0xFFFFFFFF', '', 24, 'TIME', 'MINUTEEND', sensor => ({
                    text: `${ [
                        'Jan',
                        'Feb',
                        'Mar',
                        'Apr',
                        'May',
                        'Jun',
                        'Jul',
                        'Aug',
                        'Sep',
                        'Oct',
                        'Nov',
                        'Dec'
                    ][sensor.month - 1] } ${ String(sensor.day).padStart(2, '0') }`
                }));
            },
            weekday() {
                this.data_module(230, 152, 200, 80, '0xFFFFFFFF', '', 24, 'TIME', 'MINUTEEND', sensor => ({
                    text: `${ [
                        'Mon.',
                        'Tue.',
                        'Wed.',
                        'Thu.',
                        'Fri.',
                        'Sat.',
                        'Sun.'
                    ][sensor.week - 1] }`
                }));
            },
            battery() {
                this.data_module(243, 342, 100, 80, '0xFFFFFFFF', '', 36, 'BATTERY', 'CHANGE', sensor => ({ text: `${ sensor.current }%` }));
            },
            heart_rate() {
                this.data_module(260, 294, 78, 80, '0xFFFFFFFF', '', 36, 'HEART', 'LAST', sensor => ({ text: `${ sensor.last || '--' }` }), hmUI.align.CENTER_H);
            },
            step_count() {
                this.data_module(333, 242, 140, 50, '0xFFFFFFFF', '', 36, 'STEP', 'CHANGE', sensor => ({ text: `${ sensor.current }` }));
            },
            static_text() {
                this.create_widget({
                    x: 128,
                    y: 72,
                    w: 220,
                    h: 35,
                    color: '0xFFFFFFFF',
                    text: 'How was my day ?',
                    text_size: 24
                });
                this.create_widget({
                    x: 128,
                    y: 152,
                    w: 200,
                    h: 35,
                    color: '0xFFFFFFFF',
                    text: 'Today is ',
                    text_size: 24
                });
                this.create_widget({
                    x: 128,
                    y: 202,
                    w: 200,
                    h: 35,
                    color: '0xFFFFFFFF',
                    text: 'It\'s ',
                    text_size: 24
                });
                this.create_widget({
                    x: 128,
                    y: 252,
                    w: 220,
                    h: 35,
                    color: '0xFFFFFFFF',
                    text: 'Your step count is ',
                    text_size: 24
                });
                this.create_widget({
                    x: 128,
                    y: 302,
                    w: 200,
                    h: 35,
                    color: '0xFFFFFFFF',
                    text: 'Heart rate is ',
                    text_size: 24
                });
                this.create_widget({
                    x: 335,
                    y: 302,
                    w: 200,
                    h: 35,
                    color: '0xFFFFFFFF',
                    text: ' BPM',
                    text_size: 23
                });
                this.create_widget({
                    x: 128,
                    y: 352,
                    w: 200,
                    h: 35,
                    color: '0xFFFFFFFF',
                    text: 'Battery is ',
                    text_size: 24
                });
            },
            init_view() {
                this.image_background();
                this.static_text();
                this.digital_time();
                this.weekday();
                this.date();
                this.battery();
                this.heart_rate();
                this.step_count();
            },
            build() {
                this.init_view();
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}