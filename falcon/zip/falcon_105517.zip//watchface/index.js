
    /*
    ** huamiOS bundle tool v1.0.17
    * *huamiOS watchface js version v1.0.1
    * *Copyright © Huami. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start
        let normal$_$background$_$bg = ''
        let normal$_$digital_clock$_$img_time = ''
        let normal$_$step$_$current$_$text_img = ''
        let normal$_$step$_$pointer_progress$_$img_pointer = ''
        let normal$_$date$_$img_date = ''
        let normal$_$battery$_$image_progress$_$img_level = ''
        let normal$_$calorie$_$image_progress$_$img_level = ''
        let normal$_$heart_rate$_$text$_$text_img = ''
        let normal$_$heart_rate$_$pointer_progress$_$img_pointer = ''
        let normal$_$week$_$week = ''
        let normal$_$analog_clock$_$time_pointer = ''
        let idle$_$idle_background$_$bg = ''
        let idle$_$analog_clock$_$time_pointer = ''
        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            normal$_$background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 416,
              h: 416,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$digital_clock$_$img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_zero: 1,
              hour_startX: 160,
              hour_startY: 82,
              hour_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              hour_space: 0,
              hour_align: hmUI.align.RIGHT,
              minute_zero: 1,
              minute_startX: 213,
              minute_startY: 82,
              minute_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              minute_space: 0,
              minute_align: hmUI.align.LEFT,
              minute_follow: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$step$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 252,
              y: 212,
              type: hmUI.data_type.STEP,
              font_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: '22.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$step$_$pointer_progress$_$img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '23.png',
              center_x: 295,
              center_y: 194,
              x: 15,
              y: 61,
              type: hmUI.data_type.STEP,
              start_angle: 0,
              end_angle: 360,
              cover_path: '',
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$date$_$img_date = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 158,
              month_startY: 62,
              month_sc_array: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png"],
              month_tc_array: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png"],
              month_en_array: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png"],
              month_align: hmUI.align.LEFT,
              month_zero: 0,
              month_follow: 0,
              month_space: 0,
              month_is_character: true,
              day_startX: 186,
              day_startY: 311,
              day_sc_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              day_tc_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              day_en_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              day_align: hmUI.align.LEFT,
              day_zero: 1,
              day_follow: 0,
              day_space: 0,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$battery$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 84,
              y: 276,
              image_array: ["36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$calorie$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 280,
              y: 276,
              image_array: ["46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png"],
              image_length: 10,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$heart_rate$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 82,
              y: 212,
              type: hmUI.data_type.HEART,
              font_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: '56.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$heart_rate$_$pointer_progress$_$img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '57.png',
              center_x: 108,
              center_y: 194,
              x: 15,
              y: 61,
              type: hmUI.data_type.HEART,
              start_angle: 0,
              end_angle: 360,
              cover_path: '',
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$week$_$week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 139,
              y: 230,
              week_en: ["58.png","59.png","60.png","61.png","62.png","63.png","64.png"],
              week_tc: ["58.png","59.png","60.png","61.png","62.png","63.png","64.png"],
              week_sc: ["58.png","59.png","60.png","61.png","62.png","63.png","64.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$analog_clock$_$time_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_centerX: 208,
              hour_centerY: 208,
              hour_posX: 34,
              hour_posY: 208,
              hour_path: '65.png',
              hour_cover_path: '',
              hour_cover_x: 0,
              hour_cover_y: 0,
              minute_centerX: 208,
              minute_centerY: 208,
              minute_posX: 34,
              minute_posY: 208,
              minute_path: '66.png',
              minute_cover_path: '',
              minute_cover_x: 0,
              minute_cover_y: 0,
              second_centerX: 208,
              second_centerY: 208,
              second_posX: 34,
              second_posY: 208,
              second_path: '67.png',
              second_cover_path: '',
              second_cover_x: 0,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            idle$_$idle_background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 416,
              h: 416,
              src: '68.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

                    
            idle$_$analog_clock$_$time_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_centerX: 208,
              hour_centerY: 208,
              hour_posX: 34,
              hour_posY: 208,
              hour_path: '69.png',
              hour_cover_path: '',
              hour_cover_x: 0,
              hour_cover_y: 0,
              minute_centerX: 208,
              minute_centerY: 208,
              minute_posX: 34,
              minute_posY: 208,
              minute_path: '70.png',
              minute_cover_path: '',
              minute_cover_x: 0,
              minute_cover_y: 0,
              show_level: hmUI.show_level.ONAL_AOD,
            });
  
            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  