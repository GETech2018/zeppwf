/*
 * =====================================================================================
 *
 *  Copyright (C) 2021. Huami Ltd, unpublished work. This computer program includes
 *  Confidential, Proprietary Information and is a Trade Secret of Huami Ltd.
 *  All use, disclosure, and/or reproduction is prohibited unless authorized in writing.
 *  All Rights Reserved.
 *
 *  Author: hmkj
 *
 * =====================================================================================
 */
try {
  (() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');
    /*
     * huamiOS bundle tool v1.0.17
     * Copyright © Huami. All Rights Reserved
     */
    'use strict';
    const arrStepLevel = []
    const arrData = []
    const arrWeek = []
    const arrMonth = []
    const arrDay = []
    const arrMoon = []
    for(let i = 1;i < 15;i++) {
      if(i <= 7) {
        arrWeek.push("images/week/" + i + ".png")
      }
      if(i <= 12) {
        arrMonth.push("images/month/" + i + ".png")
      }
      if(i <= 13) {
        arrMoon.push("images/moon/" + i + ".png")
      }
      arrStepLevel.push("images/steplevel/" + i + ".png")
    }
    for(let i = 0; i < 10;i++) {
      arrData.push("images/data/" + i + ".png")
      arrDay.push("images/day/" + i + ".png")
    }
    function deepClone(target,changeObj = null) {
      let result;
      if (typeof target === 'object') {
          if (Array.isArray(target)) {
              result = []; 
              for (let i in target) {
                  result.push(deepClone(target[i]))
              }
          } else if (target === null) {
              result = null;
          } else if (target.constructor === RegExp) {
              result = target;
          } else {
              result = {};
              for (let i in target) {
                  result[i] = deepClone(target[i]);
              }
          }
      } else {
          result = target;
      }
      if(changeObj != null) {
        for(let key in changeObj) {
          result[key] = changeObj[key]
        }
      }
      return result
    }
    class Time {
      constructor() {
        
      }
      pointer(option) {
        this.Pointerwidget = hmUI.createWidget(hmUI.widget.TIME_POINTER,option)
      }
      week(option) {
        this.weekWidget = hmUI.createWidget(hmUI.widget.IMG_WEEK,option)
      }
      date(option) {
        this.widget = hmUI.createWidget(hmUI.widget.IMG_DATE,option)
      }
    }
    class Img {
      constructor(option) {
         this.widget = hmUI.createWidget(hmUI.widget.IMG,option)
         "url" in option && this.href(option.url)
      }
      href(url) {
        this.widget.addEventListener(hmUI.event.CLICK_UP, (function (info) {    
          hmApp.startApp({url:url,native:true});
        }));
      }
    }
    class Text {
      constructor(option,editType) {
        this.option = option
        this.editType = editType
        if(!this.editType) {
          this.widget =  hmUI.createWidget(hmUI.widget.TEXT_IMG,this.option)
        }
        if(this.editType) {
          for(let i = 0,len = this.option.optional_types.length;i < len;i++) {
            if(this.option.optional_types[i].type == this.editType) {
              for(let key in this.option.optional_types[i]) {
                if(key != "preview" && key != "type") {
                  this.option[key] = this.option.optional_types[i][key]
                }
              }
              delete this.option['optional_types']
              this.widget =  hmUI.createWidget(hmUI.widget.TEXT_IMG,this.option)
              break;
            }
          }
        }
      }
    }
    class Animate {
      constructor(option) {
        this.widget = hmUI.createWidget(hmUI.widget.IMG_ANIM,option)
      }
    }
    class Level {
      constructor(option,editType) {
        this.option = option
        this.editType = editType
      }
      pointerLevel() {
        if(!this.editType) {
          this.Widget = hmUI.createWidget(hmUI.widget.IMG_POINTER,this.option)
        }
        if(typeof this.option.src == "string") {
          this.Widget = hmUI.createWidget(hmUI.widget.IMG_POINTER,this.option)
          return
        }
        for(let i = 0,len = this.option.src.length;i < len;i++) {
          if(this.option.src[i].type == this.editType) {
            this.option.src = this.option.src[i].path
            this.Widget = hmUI.createWidget(hmUI.widget.IMG_POINTER,this.option)
            break;
          }
        }
      }
      imgLevel() {
        if(!this.editType) {
          this.widget = hmUI.createWidget(hmUI.widget.IMG_LEVEL,this.option)
        }
        if(typeof this.option.image_array[0] == "string") {
          this.widget = hmUI.createWidget(hmUI.widget.IMG_LEVEL,this.option)
          return
        }
        this.widget = hmUI.createWidget(hmUI.widget.IMG_LEVEL,this.option)
      }
    }
    let objVo2 = {
      x:160, 
      y:119,
      w:100,
      h_space: -2, 
      invalid_image:"images/none.png",
      align_h:hmUI.align.CENTER_H,
      // type:hmUI.data_type.STRESS,         //调试用
      type:hmUI.data_type.VO2MAX,         
      font_array: arrData , 
      show_level:hmUI.show_level.ONLY_NORMAL,
    }
    const logger = DeviceRuntimeCore.HmLogger.getLogger("default2");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        const objBgOption = {x:0,y:0,src:"images/img/bg.png",show_level:hmUI.show_level.ONLY_NORMAL}
        const objStepLevelOption = {x:155,y:254,image_array: arrStepLevel,image_length:14,type:hmUI.data_type.STEP,show_level:hmUI.show_level.ONLY_NORMAL}
        const objStepTextOption = {
          x:166, 
          y:298,
          w:85,
          type:hmUI.data_type.STEP,
          font_array:arrData,
          h_space:0, 
          align_h:hmUI.align.CENTER_H,
          padding:false,
          show_level:hmUI.show_level.ONLY_NORMAL
        }
        const objWeekOption = {x:267,y:192,week_en:arrWeek,week_tc:arrWeek,week_sc:arrWeek,show_level:hmUI.show_level.ONLY_NORMAL}
        const objDateOption = {
          month_startX:267,
          month_startY:213,
          month_align:hmUI.align.LEFT,
          month_space:0,
          month_zero:0,
          month_follow:0,
          month_en_array:arrMonth,
          month_sc_array:arrMonth,
          month_tc_array:arrMonth,
          month_is_character:true,
          day_startX:333,
          day_startY:192,
          day_align:hmUI.align.LEFT,
          day_space:0,
          day_zero:1,
          day_follow:0,
          day_en_array:arrDay,
          day_sc_array:arrDay,
          day_tc_array:arrDay,
          day_is_character:false,
          show_level:hmUI.show_level.ONLY_NORMAL
        }
        const objPaiLevelOption = {
          src: "images/pointer/pai.png",
          center_x: 116,
          center_y: 207,
          x: 30,
          y: 83,
          type:hmUI.data_type.PAI_DAILY,
          start_angle:220,
          end_angle:360,
          show_level:hmUI.show_level.ONLY_NORMAL
        }
        const objVo2LevelOption = {
          src: "images/pointer/vo2max.png",
          center_x: 208,
          center_y: 107,
          x: 27,
          y: 42,
          type:hmUI.data_type.VO2MAX,
          start_angle:220,
          end_angle:360,
          show_level:hmUI.show_level.ONLY_NORMAL
        }
        const objAodTimePointer = {
          hour_centerX:208,
          hour_centerY:208,
          hour_posX:41,
          hour_posY:143,
          hour_path:"images/aodpointer/h.png",
          minute_centerX:208,
          minute_centerY:208,
          minute_posX:41,
          minute_posY:198,
          minute_path:"images/aodpointer/m.png",
          show_level:hmUI.show_level.ONAL_AOD,
        }
        const objTimePointerOption = deepClone(objAodTimePointer,{
          hour_path:"images/pointer/h.png",
          minute_path:"images/pointer/m.png",
          second_centerX:208, 
          second_centerY:208,
          second_posX:32,
          second_posY:211, 
          second_path:"images/pointer/s.png",
          show_level:hmUI.show_level.ONLY_NORMAL,
        })
        const compassImgOption = {
          x:291,
          y:245,
          w:60,
          h:60,
          url:"CompassScreen"
        }
        const objMoonOption = {x:293,y:115,image_array:arrMoon,image_length:13,type:hmUI.data_type.MOON,show_level:hmUI.show_level.ONLY_NORMAL,shortcut:true}

        new Img(objBgOption)
        new Level(objStepLevelOption).imgLevel()
        new Level(objPaiLevelOption).pointerLevel()
        let vO2Text = hmUI.createWidget(hmUI.widget.TEXT_IMG, objVo2);
        new Level(objVo2LevelOption).pointerLevel()       
        new Text(objStepTextOption)
        const time = new Time()
        const second = new Time()
        time.week(objWeekOption)
        time.date(objDateOption)
        new Level(objMoonOption).imgLevel()
        time.pointer(objTimePointerOption)
        time.pointer(objAodTimePointer)
        //跳转
        const compass = new Img(compassImgOption)
      },
      onInit() {
        this.init_view();
      },
      onReady() {
        console.log('index page.js on ready invoke')
      },
      onShow() {
        console.log('index page.js on show invoke')
      },
      onHide() {
        console.log('index page.js on hide invoke')
      },
      onDestory() {
        console.log('index page.js on destory invoke')
      },
    });
    /*
     * end js
     */
  })()
} catch (e) {}