try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 416,
                    h: 416,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 99,
                    y: 196,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    negative_image: '14.png',
                    invalid_image: '13.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: '16.png',
                    center_x: 123,
                    center_y: 282,
                    x: 4,
                    y: 61,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    start_angle: -60,
                    end_angle: 60,
                    cover_path: '15.png',
                    cover_x: 116,
                    cover_y: 276,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: '18.png',
                    center_x: 293,
                    center_y: 282,
                    x: 4,
                    y: 61,
                    type: hmUI.data_type.BATTERY,
                    start_angle: -60,
                    end_angle: 60,
                    cover_path: '17.png',
                    cover_x: 286,
                    cover_y: 276,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 160,
                    y: 312,
                    type: hmUI.data_type.STEP,
                    font_array: [
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: 2,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: true,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 208,
                    hour_centerY: 208,
                    hour_posX: 11,
                    hour_posY: 143,
                    hour_path: '29.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 208,
                    minute_centerY: 208,
                    minute_posX: 12,
                    minute_posY: 187,
                    minute_path: '30.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    second_centerX: 208,
                    second_centerY: 208,
                    second_posX: 5,
                    second_posY: 179,
                    second_path: '32.png',
                    second_cover_path: '31.png',
                    second_cover_x: 187,
                    second_cover_y: 187,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 59,
                    y: 191,
                    w: 125,
                    h: 125,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 230,
                    y: 191,
                    w: 125,
                    h: 125,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 158,
                    y: 303,
                    w: 100,
                    h: 62,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}