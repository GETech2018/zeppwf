
    /*
    ** huamiOS bundle tool v1.0.17
    * *huamiOS watchface js version v1.0.1
    * *Copyright © Huami. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start
        let normal$_$background$_$bg = ''
        let normal$_$pai$_$weekly$_$text_img = ''
        let normal$_$heart_rate$_$text$_$text_img = ''
        let normal$_$step$_$current$_$text_img = ''
        let normal$_$step$_$image_progress$_$img_level = ''
        let normal$_$battery$_$text$_$text_img = ''
        let normal$_$battery$_$image_progress$_$img_level = ''
        let normal$_$digital_clock$_$img_time = ''
        let normal$_$date$_$img_date = ''
        let normal$_$week$_$week = ''
        let idle$_$digital_clock$_$img_time = ''
        let idle$_$date$_$img_date = ''
        let idle$_$week$_$week = ''
        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            normal$_$background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 416,
              h: 416,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$pai$_$weekly$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 74,
              y: 143,
              type: hmUI.data_type.PAI_WEEKLY,
              font_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: '12.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$heart_rate$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 198,
              y: 81,
              type: hmUI.data_type.HEART,
              font_array: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: '23.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$step$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 219,
              y: 116,
              type: hmUI.data_type.STEP,
              font_array: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              align_h: hmUI.align.LEFT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: '24.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$step$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 120,
              y: 45,
              image_array: ["25.png","26.png","27.png","28.png","29.png","30.png","31.png"],
              image_length: 7,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$battery$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 328,
              y: 215,
              type: hmUI.data_type.BATTERY,
              font_array: ["32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png"],
              align_h: hmUI.align.LEFT,
              h_space: 3,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: '43.png',//单位
              unit_tc: '43.png',//单位
              unit_en: '43.png',//单位
              invalid_image: '42.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$battery$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 177,
              y: 176,
              image_array: ["44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png"],
              image_length: 8,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$digital_clock$_$img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_zero: 1,
              hour_startX: 139,
              hour_startY: 256,
              hour_array: ["52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png","61.png"],
              hour_space: 0,
              hour_unit_sc: '62.png',
              hour_unit_tc: '62.png',
              hour_unit_en: '62.png',
              hour_align: hmUI.align.LEFT,
              minute_zero: 1,
              minute_startX: 229,
              minute_startY: 255,
              minute_array: ["63.png","64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png"],
              minute_space: 0,
              minute_align: hmUI.align.LEFT,
              minute_follow: 0,
              second_zero: 1,
              second_startX: 301,
              second_startY: 257,
              second_array: ["73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png"],
              second_space: 0,
              second_align: hmUI.align.LEFT,
              second_follow: 0,
              am_x: 94,
              am_y: 268,
              am_en_path: '83.png',
              pm_x: 94,
              pm_y: 268,
              pm_en_path: '84.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$date$_$img_date = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 150,
              month_startY: 334,
              month_sc_array: ["85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png","93.png","94.png","95.png","96.png"],
              month_tc_array: ["85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png","93.png","94.png","95.png","96.png"],
              month_en_array: ["85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png","93.png","94.png","95.png","96.png"],
              month_align: hmUI.align.LEFT,
              month_zero: 0,
              month_follow: 0,
              month_space: 0,
              month_is_character: true,
              day_startX: 198,
              day_startY: 335,
              day_sc_array: ["97.png","98.png","99.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png"],
              day_tc_array: ["97.png","98.png","99.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png"],
              day_en_array: ["97.png","98.png","99.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png"],
              day_align: hmUI.align.CENTER_H,
              day_zero: 1,
              day_follow: 0,
              day_space: 0,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$week$_$week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 228,
              y: 334,
              week_en: ["107.png","108.png","109.png","110.png","111.png","112.png","113.png"],
              week_tc: ["107.png","108.png","109.png","110.png","111.png","112.png","113.png"],
              week_sc: ["107.png","108.png","109.png","110.png","111.png","112.png","113.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            idle$_$digital_clock$_$img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_zero: 1,
              hour_startX: 139,
              hour_startY: 256,
              hour_array: ["114.png","115.png","116.png","117.png","118.png","119.png","120.png","121.png","122.png","123.png"],
              hour_space: 0,
              hour_unit_sc: '124.png',
              hour_unit_tc: '124.png',
              hour_unit_en: '124.png',
              hour_align: hmUI.align.LEFT,
              minute_zero: 1,
              minute_startX: 229,
              minute_startY: 255,
              minute_array: ["125.png","126.png","127.png","128.png","129.png","130.png","131.png","132.png","133.png","134.png"],
              minute_space: 0,
              minute_align: hmUI.align.LEFT,
              minute_follow: 0,
              am_x: 94,
              am_y: 268,
              am_en_path: '135.png',
              pm_x: 94,
              pm_y: 268,
              pm_en_path: '136.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

                    
            idle$_$date$_$img_date = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 150,
              month_startY: 334,
              month_sc_array: ["137.png","138.png","139.png","140.png","141.png","142.png","143.png","144.png","145.png","146.png","147.png","148.png"],
              month_tc_array: ["137.png","138.png","139.png","140.png","141.png","142.png","143.png","144.png","145.png","146.png","147.png","148.png"],
              month_en_array: ["137.png","138.png","139.png","140.png","141.png","142.png","143.png","144.png","145.png","146.png","147.png","148.png"],
              month_align: hmUI.align.LEFT,
              month_zero: 0,
              month_follow: 0,
              month_space: 0,
              month_is_character: true,
              day_startX: 198,
              day_startY: 335,
              day_sc_array: ["149.png","150.png","151.png","152.png","153.png","154.png","155.png","156.png","157.png","158.png"],
              day_tc_array: ["149.png","150.png","151.png","152.png","153.png","154.png","155.png","156.png","157.png","158.png"],
              day_en_array: ["149.png","150.png","151.png","152.png","153.png","154.png","155.png","156.png","157.png","158.png"],
              day_align: hmUI.align.CENTER_H,
              day_zero: 1,
              day_follow: 0,
              day_space: 0,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });
  
                    
            idle$_$week$_$week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 228,
              y: 334,
              week_en: ["159.png","160.png","161.png","162.png","163.png","164.png","165.png"],
              week_tc: ["159.png","160.png","161.png","162.png","163.png","164.png","165.png"],
              week_sc: ["159.png","160.png","161.png","162.png","163.png","164.png","165.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });
  
            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  