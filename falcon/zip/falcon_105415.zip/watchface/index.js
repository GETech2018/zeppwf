/*
* =====================================================================================
*
*  Copyright (C) 2021. Huami Ltd, unpublished work. This computer program includes
*  Confidential, Proprietary Information and is a Trade Secret of Huami Ltd.
*  All use, disclosure, and/or reproduction is prohibited unless authorized in writing.
*  All Rights Reserved.
*
*  Author: huami
*
* =====================================================================================
*/
try {
  (() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');
    /*
     * huamiOS bundle tool v1.0.17
     * Copyright © Huami. All Rights Reserved
     */
    'use strict';
    /*params声明*/
    let strRootPath = "images/"
    let nX = 0
    let nY = 0
    let nWidth = 416
    let nHeight = 416
    let nPageX = 208
    let nPageY = 208
    let nTimeX = 272
    let nTimeY = 247
    let arrDay = []
    let arrCalBat = []
    let arrStepBat = []
    let arrRainBat = []
    let arrPowerBat = []
    let arrMinFont = []
    let arrMaxFont = []
    let arrWeather = []
    let arrEnWeek = []
    let arrScWeek = []
    let arrUnitFont = []
  
    /*遍历数组*/
    for (let i = 0; i < 29; i++){
      if(i < 6){
        arrCalBat.push(strRootPath + "cal_bat/" + i + ".png")
        arrStepBat.push(strRootPath + "steps_bat/" + i + ".png")
      }
      if(i < 7){
        arrEnWeek.push(strRootPath + "week/" + i + ".png")
        arrScWeek.push(strRootPath + "sc_week/" + i + ".png")
        arrUnitFont.push(strRootPath + "unit_font/" + i + ".png")
      }
      if(i < 10){
        arrDay.push(strRootPath + "day/" + i +".png")
        arrMinFont.push(strRootPath + "min_font/" + i + ".png")
        arrMaxFont.push(strRootPath + "max_font/" + i + ".png")
        arrRainBat.push(strRootPath + "rain_bat/" + i + ".png")
        arrPowerBat.push(strRootPath + "power_bat/" + i + ".png")
      }
      arrWeather.push(strRootPath + "weather/" + i + ".png") 
    }

    /*定义fn*/
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      /* 获取背景 */
      getBackground(){
         //normal背景
         let norBg = hmUI.createWidget(hmUI.widget.IMG, {
          x: nX,
          y: nY,
          w: nWidth,
          h: nHeight,
          src: strRootPath + "bg.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        })
        //aod 背景
        let aodBg = hmUI.createWidget(hmUI.widget.IMG, {
          x: nX,
          y: nY,
          w: nWidth,
          h: nHeight,
          // src: null,
          show_level: hmUI.show_level.ONAL_AOD,
        })
      },
      /* 获取数值--电量/湿度/步数/卡路里/天气温度/PAI/心率 */
      getFont(options){
        let objConfig = {
          x:0,
          y:0,
          w:0,
          type:"",
          font_array:arrMinFont,
          h_space:0,
          align_h:hmUI.align.CENTER_H,
          unit_sc:"",
          unit_tc:"",
          unit_en:"",
          invalid_image: "images/min_font/zhanwei.png",
          padding: false,
          negative_image:"", 
          show_level:hmUI.show_level.ONLY_NORMAL
        }
        for(let key in options) {
          if(key in objConfig) {
            objConfig[key] = options[key]
          }
        }
        for(let key in objConfig) {
          if(!objConfig[key]) {
            delete objConfig[key]
          }
        }
        let text = hmUI.createWidget(hmUI.widget.TEXT_IMG,objConfig)

      },
      /* 获取进度--电量/湿度/步数/卡路里 */
      getLevel(options){
        let {x,y,arr,type} = options
        let progress = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: x,
          y: y,
          image_array: arr,
          image_length: arr.length, //长度
          type: type,
          show_level:hmUI.show_level.ONLY_NORMAL
        })
      },
      /* 设置单位--电量/湿度/步数/卡路里 */
      setCompany(options){
        let {x,y,w,arr,type,unit,unit_en} = options
        let progress = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x:x, 
          y:y,
          w:w,
          text: 0,
          font_array: arr,
          type: type,
          h_space: 0, 
          align_h:hmUI.align.RIGHT,
          unit_sc:unit,
          unit_tc:unit,
          unit_en:unit_en,
          padding:false, 
          show_level:hmUI.show_level.ONLY_NORMAL
        });
      },
      /* 获取日期/星期/时间/指针的控件 */
      getControl(){
        /* 日期 */
        let ndayX = 331
        let ndayY = 165
        let nWeekX = 254
        let nWeekY = 164
        let timeMonth = hmUI.createWidget(hmUI.widget.IMG_DATE,{
          day_startX:ndayX,
          day_startY:ndayY,
          day_align:hmUI.align.LEFT,
          day_space:0,
          day_zero:1,
          day_follow:0,
          day_en_array: arrDay,
          day_sc_array: arrDay,
          day_tc_array: arrDay,
          show_level: hmUI.show_level.ONLY_NORMAL,
        })
        /* 星期  */
        let timeWeek = hmUI.createWidget(hmUI.widget.IMG_WEEK,{
          x:nWeekX,
          y:nWeekY,
          week_en:arrEnWeek,
          week_tc:arrScWeek,
          week_sc:arrScWeek, 
          show_level: hmUI.show_level.ONLY_NORMAL,
        })
        /* 时间 */
        let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          am_x:nTimeX,
          am_y:nTimeY,
          am_sc_path: strRootPath + "am.png",
          am_en_path: strRootPath + "am.png",

          pm_x:nTimeX,
          pm_y:nTimeY,
          pm_sc_path: strRootPath + "pm.png",
          pm_en_path: strRootPath + "pm.png",
          show_level:hmUI.show_level.ONLY_NORMAL
        });
        /* 指针 ----normal */
        let nHourX = 16
        let nHourY = 127
        let nMinX = 30
        let nMinY = 199
        let nSecX = 12
        let nSecY = 192
        let norTimePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_centerX: nPageX, 
          hour_centerY: nPageY, 
          hour_posX: nHourX, 
          hour_posY: nHourY, 
          hour_path: "images/pointer/h.png",

          minute_centerX: nPageX, 
          minute_centerY: nPageY, 
          minute_posX: nMinX, 
          minute_posY: nMinY, 
          minute_path: "images/pointer/m.png",

          second_centerX: nPageX, 
          second_centerY: nPageY, 
          second_posX: nSecX, 
          second_posY: nSecY, 
          second_path: "images/pointer/s.png",
          show_level:hmUI.show_level.ONLY_NORMAL
        })
        /* 指针 ----aod */
        let nAodHourX = 16
        let nAodHourY = 127
        let nAodMinX = 30
        let nAodMinY = 199
        let aodTimePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_centerX: nPageX, 
          hour_centerY: nPageY, 
          hour_posX: nAodHourX, 
          hour_posY: nAodHourY, 
          hour_path: "images/aod_pointer/h.png",

          minute_centerX: nPageX, 
          minute_centerY: nPageY, 
          minute_posX: nAodMinX, 
          minute_posY: nAodMinY, 
          minute_path: "images/aod_pointer/m.png",
          show_level:hmUI.show_level.ONAL_AOD
        })
      },

      /* 表盘控件初始化 */
      init_view() {
        /* 正常/息屏背景 */
        this.getBackground();
        /* PAI数值  */
        this.getFont({x:178, y:78, w:60, type:hmUI.data_type.PAI_DAILY, font_array:arrMaxFont})
        /* 卡路里数值 */
        this.getFont({x:76, y:200, w:70, type:hmUI.data_type.CAL, font_array:arrMaxFont})
        /* 步数数值 */
        this.getFont({x:168, y:295, w:80, type:hmUI.data_type.STEP, font_array:arrMaxFont})
        /* 天气数值 */
        this.getFont({x:288, y:122, w:50, type:hmUI.data_type.WEATHER_CURRENT,unit_sc:"images/min_font/du.png",unit_tc:"images/min_font/du.png",unit_en:"images/min_font/du.png", invalid_image: "images/min_font/null.png",negative_image:"images/min_font/fuhao.png"})
        /* 电量数值 */
        this.getFont({x:68, y:97, w:50, type:hmUI.data_type.BATTERY,unit_sc:"images/min_font/baifen.png",unit_tc:"images/min_font/baifen.png",unit_en:"images/min_font/baifen.png"})
        /* 湿度数值 */
        this.getFont({x:298, y:313, w:50, type:hmUI.data_type.HUMIDITY,unit_sc:"images/min_font/baifen.png",unit_tc:"images/min_font/baifen.png",unit_en:"images/min_font/baifen.png"})
        /* 心率数值 */
        this.getFont({x:81, y:316, w:50, type:hmUI.data_type.HEART})
        
        /* 卡路里进度 */
        this.getLevel({x:51, y:147, arr:arrCalBat, type:hmUI.data_type.CAL})
        /* 步数进度 */
        this.getLevel({x:147, y:305, arr:arrStepBat, type:hmUI.data_type.STEP})
        /* 电量进度 */
        this.getLevel({x:12, y:10, arr:arrPowerBat, type:hmUI.data_type.BATTERY})
        /* 湿度进度 */
        this.getLevel({x:208, y:210, arr:arrRainBat, type:hmUI.data_type.HUMIDITY})
        /* 天气icon */
        this.getLevel({x:296, y:88, arr:arrWeather, type:hmUI.data_type.WEATHER})

        /* 步数--中/英单位 */
        this.setCompany({x:187, y:267,w:54,arr:arrMinFont, type:hmUI.data_type.STEP, unit:"images/sc_step.png",unit_en:"images/steps.png"})
        /* 消耗--中/英单位 */
        this.setCompany({x:71, y:175,w:72,arr:arrUnitFont, type:hmUI.data_type.CAL, unit:"images/sc_cal.png",unit_en:"images/cal.png"})
        
        /* 日期/星期/时间/指针的控件 */
        this.getControl()
   
      },

      onInit() {
        console.log('index page.js on init invoke');
        this.init_view();
      },
      onReady() {
        console.log('index page.js on ready invoke')
      },
      onShow() {
        console.log('index page.js on show invoke')
      },
      onHide() {
        console.log('index page.js on hide invoke')
      },
      onDestory() {
        console.log('index page.js on destory invoke')
      },
    });
  })()
} catch (e) {
  console.log(e)
}