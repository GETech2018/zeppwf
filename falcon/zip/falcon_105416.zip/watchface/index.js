try {
    (() => {

    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

      /*
    * huamiOS bundle tool v1.0.17
    * Copyright © Huami. All Rights Reserved
    */
    'use strict';

    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let weekArray = []
    let weekXpArray = []

    let img_bg = null

    let timePointer = null
    let monthArray = []
    let moonArray = []
    let dayArray = []
    let dayArrayXp = []
    let dataArray = []
    let vo2MaxArray = []
    let trainingArray = []
    let weekLevel = null
    let prevDay = null
    let nextDay = null
    let yearArray = []
    let mask70 = null
    let mask100 = null
    let leftTxt = null
    let upTxt = null
    let downTxt = null
    let leftPointer = null
    let upPointer = null
    let downPointer = null
    let leftBg = null
    let upBg = null
    let downBg = null
    let downLevel = null
    const upX  = 136
    const upY = 13
    const downX = 135
    const downY = 258

    const leftX = 35
    const leftY = 150
    const  ROOTPATH = "images/"
    let jsTime = null
    const  CENTER_X = 208

    let pai
    let sport_effect
    let vo2_sensor_current
    let pai_today
    let jstime
    let pai_pointer
    let vox_Pointer
    const logger = DeviceRuntimeCore.HmLogger.getLogger("defult");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({

        init_view() {

            img_bg = hmUI.createWidget(hmUI.widget.IMG,{
                x: 0,
                y: 0,
                w: 416,
                h: 416,
            });
            creatAllArr();
            weekLevel = hmUI.createWidget(hmUI.widget.IMG_WEEK);
            var screenType = hmSetting.getScreenType();
            if(screenType == hmSetting.screen_type.AOD){
                img_bg.setProperty(hmUI.prop.SRC, ROOTPATH + "xp/bg.png");
                let imgDay = hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    day_startX: 345,
                    day_startY: 199,
                    day_en_array: dayArrayXp,
                    day_sc_array: dayArrayXp,
                    day_tc_array: dayArrayXp,
                    day_space: 0,
                    //day_zero: 1,
                    day_is_character:true,
                    day_align: hmUI.align.LEFT,
                    //show_level:hmUI.show_level.ONLY_AOD,
                });
                weekLevel.setProperty(hmUI.prop.MORE, {
                    x: 276,
                    y: 198,
                    week_sc: weekXpArray,
                    week_tc: weekXpArray,
                    week_en: weekXpArray,
                    //show_level: hmUI.show_level.AOD,
                });
                timePointer  = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: CENTER_X,
                    hour_centerY: CENTER_X,
                    hour_posX: 32,
                    hour_posY: 166,
                    hour_path: ROOTPATH+"xp/hour.png",

                    minute_centerX: CENTER_X,
                    minute_centerY: CENTER_X,
                    minute_posX: 28,
                    minute_posY: 208,
                    minute_path: ROOTPATH+"xp/min.png",
                });
            }else{ // if(screenType == hmSetting.screen_type.WATCHFACE)
                img_bg.setProperty(hmUI.prop.SRC, ROOTPATH + "img/bg.png");
                prevDay = hmUI.createWidget(hmUI.widget.IMG,{
                    x: 345,
                    y: 166,
                    w: 31,
                    h: 18,
                });

                nextDay = hmUI.createWidget(hmUI.widget.IMG,{
                    x: 345,
                    y: 234,
                    w: 31,
                    h: 18,
                });
                let dateMask = hmUI.createWidget(hmUI.widget.IMG,{
                    x: 345,
                    y: 163,
                    w: 33,
                    h: 92,
                    src: ROOTPATH + "img/dateMask.png",
                    show_level:hmUI.show_level.ONLY_NORMAL,
                });
                let date = hmUI.createWidget(hmUI.widget.IMG_DATE,{
                    year_startX: 283,
                    year_startY: 177 ,
                    year_align: hmUI.align.LEFT,
                    year_space: 0,
                    year_zero: 1,//是否补零  0:21  1:2021
                    year_follow: 0,
                    //year_is_character: true, //年份此字段无效 默认为false 为true时 传入的图片为月份12张 日31张
                    year_en_array: yearArray,
                    year_sc_array: yearArray,
                    year_tc_array: yearArray,

                    month_startX: 270,
                    month_startY: 226 ,
                    month_align: hmUI.align.LEFT,
                    month_space: 0,
                    month_zero: 1,
                    month_follow: 0,
                    month_is_character: true,
                    month_en_array: monthArray,
                    month_sc_array: monthArray,
                    month_tc_array: monthArray,

                    day_startX: 345,
                    day_startY: 199,
                    day_en_array: dayArray,
                    day_sc_array: dayArray,
                    day_tc_array: dayArray,
                    day_space: 0,
                    //day_zero: 1,
                    day_is_character: true,
                    day_align: hmUI.align.LEFT,
                    show_level:hmUI.show_level.ONLY_NORMAL,
                });

                weekLevel.setProperty(hmUI.prop.MORE, {
                    x: 276,
                    y: 198,
                    w: 59,
                    h: 20,
                    week_sc: weekArray,
                    week_tc: weekArray,
                    week_en: weekArray,
                   // show_level: hmUI.show_level.ONLY_NORMAL,
                });


                leftBg = hmUI.createWidget(hmUI.widget.IMG, {
                    x: leftX,
                    y: leftY,
                    w: 114,
                    h: 114,
                });
                upBg = hmUI.createWidget(hmUI.widget.IMG, {
                    x: upX,
                    y: upY,
                    w: 148,
                    h: 148,
                });
                downBg = hmUI.createWidget(hmUI.widget.IMG, {
                    x: downX,
                    y: downY,
                    w: 148,
                    h: 148,
                });
                downLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                });
                leftTxt  = hmUI.createWidget(hmUI.widget.TEXT_IMG);
                upTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG);
                downTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG);

                // let paiPointer = hmUI.createWidget(hmUI.widget.IMG_POINTER,{
                //     x: 27,
                //     y: 208,
                //     center_x: CENTER_X,
                //     center_y: CENTER_X,
                //     start_angle: 210,
                //     end_angle: 360,
                //     src: ROOTPATH + "img/redPointer.png",
                //     type: hmUI.data_type.PAI_WEEKLY,
                //     show_level:hmUI.show_level.ONLY_NORMAL,
                // });


                // let voxPointer = hmUI.createWidget(hmUI.widget.IMG_POINTER,{
                //     x: 27,
                //     y: 208,
                //     center_x: CENTER_X,
                //     center_y: CENTER_X,
                //     start_angle: 150,
                //     end_angle: 0,
                //     src: ROOTPATH + "img/redPointer.png",
                //     type: hmUI.data_type.VO2MAX,  //最大摄氧量
                //     show_level:hmUI.show_level.ONLY_NORMAL,
                // });

                pai_pointer = hmUI.createWidget(hmUI.widget.IMG,{
                    x: 0,
                    y: 0,
                    w: 416,
                    h: 416,
                    center_x: CENTER_X,
                    center_y: CENTER_X,
                    pos_x: (416 -54) / 2,
                    pos_y: (416 - 416) / 2,
                    src: ROOTPATH + "img/redPointer.png",
                    angle: 210,
                    show_level:hmUI.show_level.ONLY_NORMAL,
                });


                vox_Pointer = hmUI.createWidget(hmUI.widget.IMG,{
                    x: 0,
                    y: 0,
                    w: 416,
                    h: 416,
                    center_x: CENTER_X,
                    center_y: CENTER_X,
                    pos_x: (416 -54) / 2,
                    pos_y: (416 - 416) / 2,
                    angle: 150,
                    src: ROOTPATH + "img/redPointer.png",
                    show_level:hmUI.show_level.ONLY_NORMAL,
                });

                pai = hmSensor.createSensor(hmSensor.id.PAI);
                sport_effect = hmSensor.createSensor(hmSensor.id.SPORT)
                vo2_sensor_current =   sport_effect.vo2max
                pai_today = pai.dailypai

                // 避免数据获取不到时存在问题
                if(!vo2_sensor_current) vo2_sensor_current = 0
                if(!pai.dailypai) pai.dailypai = 0

                // 初始化
                pai_pointer.setProperty(hmUI.prop.ANGLE, 210 + pai.dailypai * 1.5 )
                vox_Pointer.setProperty(hmUI.prop.ANGLE, 150 - vo2_sensor_current * 1.5 )


                // 每分钟更新数据
                jstime = hmSensor.createSensor(hmSensor.id.TIME);
                // let jstime = hmSensor.createSensor(hmSensor.id.TIME);
                jstime.addEventListener(jstime.event.MINUTEEND, function() {
                    vo2_sensor_current =   sport_effect.vo2max
                     // 避免数据获取不到时存在问题
                    if(!vo2_sensor_current) vo2_sensor_current = 0
                    if(!pai.dailypai) pai.dailypai = 0
                    pai_pointer.setProperty(hmUI.prop.ANGLE, 210 + pai.dailypai * 1.5 )
                    vox_Pointer.setProperty(hmUI.prop.ANGLE, 150 - vo2_sensor_current * 1.5 )
                });

                leftPointer = hmUI.createWidget(hmUI.widget.IMG_POINTER,);
                upPointer = hmUI.createWidget(hmUI.widget.IMG_POINTER);
                downPointer = hmUI.createWidget(hmUI.widget.IMG_POINTER);

                jumpPage();
                let moon = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 71,
                    y: 285,
                    w: 42,
                    h: 42,
                    image_array: moonArray,
                    image_length: moonArray.length,
                    type: hmUI.data_type.MOON,
                    shortcut: true, // 月相跳转
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                 //left
                var editLeft = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP,{
                    edit_id: 112,
                    x: leftX,
                    y: leftY,
                    w: 114,
                    h: 114,
                    select_image: ROOTPATH + "mask/selected114.png",
                    un_select_image: ROOTPATH + "mask/unselected114.png",
                    default_type: hmUI.edit_type.BATTERY,
                    optional_types: [
                    { type: hmUI.edit_type.BATTERY,preview: ROOTPATH + "editLeft/bat.png" },
                    { type: hmUI.edit_type.CAL,preview: ROOTPATH + "editLeft/cal.png" },
                    { type: hmUI.edit_type.HEART,preview: ROOTPATH + "editLeft/bpm.png" },
                    { type: hmUI.edit_type.PAI_WEEKLY,preview: ROOTPATH + "editLeft/pai.png" },
                    ],
                    count: 4,
                    tips_BG: ROOTPATH + "mask/text_tag.png",
                    tips_x: 38 - leftX,
                    tips_y: 118 - leftY,
                    tips_width: 106,
                    tips_margin:10,
                    });
                    //通过这个函数来获取当前的保存的数据项类型来绘制组件
                    var leftType = editLeft.getProperty(hmUI.prop.CURRENT_TYPE);
                    switch (leftType) {
                        case hmUI.edit_type.PAI_WEEKLY:

                            leftBg.setProperty(hmUI.prop.SRC, ROOTPATH + "editLeft/pai_bg.png");
                            setTxtCom(leftTxt,70,220,hmUI.data_type.PAI_WEEKLY,null);
                            setPointerCom(leftPointer,17,46,91,208,0,360,ROOTPATH + "img/batPointer.png",hmUI.data_type.PAI_WEEKLY);
                            break;
                        case hmUI.edit_type.CAL:
                            leftBg.setProperty(hmUI.prop.SRC, ROOTPATH + "editLeft/cal_bg.png");
                            setTxtCom(leftTxt,62,220,hmUI.data_type.CAL,null);
                            setPointerCom(leftPointer,17,46,91,208,0,360,ROOTPATH + "img/batPointer.png",hmUI.data_type.CAL);
                            break;
                        case hmUI.edit_type.BATTERY:
                            leftBg.setProperty(hmUI.prop.SRC, ROOTPATH + "editLeft/bat_bg.png");
                            setTxtCom(leftTxt,69,220,hmUI.data_type.BATTERY,null);
                            setPointerCom(leftPointer,17,46,91,208,0,360,ROOTPATH + "img/batPointer.png",hmUI.data_type.BATTERY);
                            break;
                        case hmUI.edit_type.HEART:
                            leftBg.setProperty(hmUI.prop.SRC, ROOTPATH + "editLeft/bpm_bg.png");
                            setTxtCom(leftTxt,70,220,hmUI.data_type.HEART,ROOTPATH + "img/invalid.png");
                            setPointerCom(leftPointer,17,46,91,208,0,360,ROOTPATH + "img/batPointer.png",hmUI.data_type.HEART);
                            break;
                        default:
                            leftBg.setProperty(hmUI.prop.SRC, ROOTPATH + "editLeft/bat_bg.png");
                            setTxtCom(leftTxt,69,220,hmUI.data_type.BATTERY,null);
                            setPointerCom(leftPointer,17,46,91,208,0,360,ROOTPATH + "img/batPointer.png",hmUI.data_type.BATTERY);
                    }
                //up--
                var editUp = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP,{
                    edit_id: 102,
                    x: upX,
                    y: upY,
                    w: 148,
                    h: 148,
                    select_image: ROOTPATH + "mask/selected144.png",
                    un_select_image: ROOTPATH + "mask/unselected144.png",
                    default_type: hmUI.edit_type.STEP,
                    optional_types: [
                    { type: hmUI.edit_type.BATTERY,preview: ROOTPATH + "up/bat.png" },
                    { type: hmUI.edit_type.CAL,preview: ROOTPATH + "up/cal.png" },
                    { type: hmUI.edit_type.HEART,preview: ROOTPATH + "up/bpm.png" },
                    { type: hmUI.edit_type.PAI_WEEKLY,preview: ROOTPATH + "up/pai.png" },
                    { type: hmUI.edit_type.STEP,preview: ROOTPATH + "up/step.png" },
                    ],
                    count: 5,
                    tips_BG: ROOTPATH + "mask/text_tag.png",
                    tips_x: 156 - upX,
                    tips_y: 162 - upY,
                    tips_width: 106,
                    tips_margin:10,
                });

                var upType = editUp.getProperty(hmUI.prop.CURRENT_TYPE);
                switch (upType) {
                    case hmUI.edit_type.PAI_WEEKLY:
                        case hmUI.edit_type.PAI_DAILY:
                        upBg.setProperty(hmUI.prop.SRC, ROOTPATH + "up/pai_bg.png");
                        setTxtCom(upTxt,188,110,hmUI.data_type.PAI_WEEKLY,null);
                        setPointerCom(upPointer,20,58,208,90,0,360,ROOTPATH + "img/pointer.png",hmUI.data_type.PAI_WEEKLY);
                        break;
                    case hmUI.edit_type.CAL:
                        upBg.setProperty(hmUI.prop.SRC,ROOTPATH + "up/cal_bg.png");
                        setTxtCom(upTxt,180,110,hmUI.data_type.CAL,null);
                        setPointerCom(upPointer,20,58,208,90,0,360,ROOTPATH + "img/pointer.png",hmUI.data_type.CAL);
                        break;
                    case hmUI.edit_type.BATTERY:
                        upBg.setProperty(hmUI.prop.SRC, ROOTPATH + "up/bat_bg.png");
                        setTxtCom(upTxt,188,110,hmUI.data_type.BATTERY,null);
                        setPointerCom(upPointer,20,58,208,90,0,360,ROOTPATH + "img/pointer.png",hmUI.data_type.BATTERY);
                        break;
                    case hmUI.edit_type.HEART:
                        upBg.setProperty(hmUI.prop.SRC, ROOTPATH + "up/bpm_bg.png");
                        setTxtCom(upTxt,187,110,hmUI.data_type.HEART,ROOTPATH + "img/invalid.png");
                        setPointerCom(upPointer,20,58,208,80,0,360,ROOTPATH + "img/pointer.png",hmUI.data_type.HEART);
                        break;
                    case hmUI.edit_type.STEP:
                        upBg.setProperty(hmUI.prop.SRC, ROOTPATH + "up/step_bg.png");
                        setTxtCom(upTxt,171,110,hmUI.data_type.STEP,null);
                        setPointerCom(upPointer,20,58,208,90,0,360,ROOTPATH + "img/pointer.png",hmUI.data_type.STEP);
                        break;
                    default:
                        upBg.setProperty(hmUI.prop.SRC, ROOTPATH + "up/step_bg.png");
                        setTxtCom(upTxt,171,110,hmUI.data_type.STEP,null);
                        setPointerCom(upPointer,20,58,208,90,0,360,ROOTPATH + "img/pointer.png",hmUI.data_type.STEP);
                }
                //down
                var editDown = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP,{
                    edit_id: 183,
                    x: downX,
                    y: downY,
                    w: 148,
                    h: 148,
                    select_image: ROOTPATH + "mask/selected144.png",
                    un_select_image: ROOTPATH + "mask/unselected144.png",
                    default_type: hmUI.edit_type.VO2MAX,
                    optional_types: [
                        { type: hmUI.edit_type.CAL,preview: ROOTPATH + "down/cal.png" },//
                        { type: hmUI.edit_type.TRAINING_LOAD,preview: ROOTPATH + "down/training.png" },
                        { type: hmUI.edit_type.PAI_WEEKLY,preview: ROOTPATH + "down/pai.png" },//
                        { type: hmUI.edit_type.STEP,preview: ROOTPATH + "down/step.png" },//
                        { type: hmUI.edit_type.VO2MAX,preview: ROOTPATH + "down/max.png" },
                        ],
                    count: 5,
                    tips_BG: ROOTPATH + "mask/text_tag.png",
                    tips_x: 156 - downX,
                    tips_y: 223 - downY,
                    tips_width: 106,
                    tips_margin:10,
                });

                var downType = editDown.getProperty(hmUI.prop.CURRENT_TYPE);
                switch (downType) {
                    case hmUI.edit_type.PAI_WEEKLY:
                    //case hmUI.edit_type.PAI_DAILY:
                        downBg.setProperty(hmUI.prop.SRC, ROOTPATH + "down/pai_bg.png");
                        setTxtCom(downTxt,188,352,hmUI.data_type.PAI_WEEKLY,null);
                        setPointerCom(downPointer,20,58,208,333,0,360,ROOTPATH + "img/pointer.png",hmUI.data_type.PAI_WEEKLY);
                    break;
                    case hmUI.edit_type.CAL:
                        downBg.setProperty(hmUI.prop.SRC, ROOTPATH + "down/cal_bg.png");
                        setTxtCom(downTxt,180,352,hmUI.data_type.CAL,null);
                        setPointerCom(downPointer,20,58,208,333,0,360,ROOTPATH + "img/pointer.png",hmUI.data_type.CAL);
                        break;
                    case hmUI.edit_type.VO2MAX:// 最大摄氧量
                        downBg.setProperty(hmUI.prop.SRC, ROOTPATH + "down/max_bg.png");
                        setTxtCom(downTxt,195,352,hmUI.data_type.VO2MAX,ROOTPATH + "img/invalid.png");
                       setLevelCom(vo2MaxArray,hmUI.data_type.VO2MAX);
                        break;
                    case hmUI.edit_type.STEP:
                        downBg.setProperty(hmUI.prop.SRC, ROOTPATH + "down/step_bg.png");
                        setTxtCom(downTxt,172,352,hmUI.data_type.STEP,null);
                        setPointerCom(downPointer,20,58,208,333,0,360,ROOTPATH + "img/pointer.png",hmUI.data_type.STEP);
                            break;
                    case hmUI.edit_type.TRAINING_LOAD:// 训练负荷，
                        downBg.setProperty(hmUI.prop.SRC, ROOTPATH + "down/training_bg.png");
                        setTxtCom(downTxt,188,352,hmUI.data_type.TRAINING_LOAD,ROOTPATH + "img/invalid.png");
                        //setPointerCom(downPointer,20,58,208,333,125,360,ROOTPATH + "img/pointer.png",hmUI.data_type.TRAINING_LOAD);
                        setLevelCom(trainingArray,hmUI.data_type.TRAINING_LOAD);
                        break;
                    default:

                        downBg.setProperty(hmUI.prop.SRC, ROOTPATH + "down/training_bg.png");
                        setTxtCom(downTxt,188,352,hmUI.data_type.TRAINING_LOAD,ROOTPATH + "img/invalid.png");
                        setLevelCom(trainingArray,hmUI.data_type.TRAINING_LOAD);

                }

            }


            timePointer  = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                hour_centerX: CENTER_X,
                hour_centerY: CENTER_X,
                hour_posX: 32,
                hour_posY: 166,
                hour_path: ROOTPATH+"img/hour.png",

                minute_centerX: CENTER_X,
                minute_centerY: CENTER_X,
                minute_posX: 28,
                minute_posY: 208,
                minute_path: ROOTPATH+"img/min.png",

                second_centerX: CENTER_X,
                second_centerY: CENTER_X,
                second_posX: 14,
                second_posY: 208,
                second_path: ROOTPATH+"img/sec.png",
                show_level:hmUI.show_level.ONLY_NORMAL,
                });
                mask100 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK,{
                    x: 0,
                    y: 0,
                    w: 416,
                    h: 416,
                    src: ROOTPATH + "mask/mask100.png",
                    show_level: hmUI.show_level.ONLY_EDIT,
                });

                mask70 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK,{
                    x: 0,
                    y: 0,
                    w: 416,
                    h: 416,
                    src: ROOTPATH + "mask/mask70.png",
                    show_level: hmUI.show_level.ONLY_EDIT,
               });
            function jumpPage(){
                let compass = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 64,
                    y: 81,
                    w: 55,
                    h: 56,
                    src:   ROOTPATH + "img/compass.png",
                });
                compass.addEventListener(hmUI.event.CLICK_UP, (function (info) {

                    hmApp.startApp({url:"CompassScreen",native:true});
                }));
            }

            function setPointerCom(p,xpos,ypos,centerX,centerY,start,end,path,type)
            {
                p = hmUI.createWidget(hmUI.widget.IMG_POINTER,{
                    x: xpos,
                    y: ypos,
                    center_x: centerX,
                    center_y: centerY,
                    start_angle: start,
                    end_angle: end,
                    src: path,
                    type: type,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
            }
            function  setLevelCom(arr,type)
            {
                downLevel.setProperty(hmUI.prop.MORE, {
                    x: downX,
                    y: downY,
                    w: 148,
                    h: 148,
                    image_array: arr,
                    image_length: arr.length,
                    type: type,
                   // shortcut: true,
                });
            }
            function setTxtCom(txt,xpos,ypos,type,validImg){
                txt.setProperty(hmUI.prop.MORE, {
                    x: xpos,
                    y: ypos,
                    type: type,
                    font_array:  dataArray,
                    h_space: 0, //图片间隔
                    align_h: hmUI.align.CENTER_H,
                    padding:false, //是否补零 true为补零
                    invalid_image:  validImg,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
            }
            function creatAllArr()
            {
                // dayArray.push("images/day/day1.png");
                // dayArrayXp.push("images/day_xp/1.png");
                trainingArray=["images/trainingProgress/1.png","images/trainingProgress/2.png","images/trainingProgress/3.png"]
                for(let n=1; n<=31; n++)
                {
                    var path1 = "images/day/day"+n+".png";
                    var path2 = "images/day_xp/"+n+".png";
                    dayArray.push(path1);
                    dayArrayXp.push(path2);
                }
                for(let n=0; n<=9; n++)
                {
                    dataArray.push( ROOTPATH + "data/0"+n+".png");
                    yearArray.push( ROOTPATH + "year/0"+n+".png");
                }
                for(let n=1; n<=7; n++)
                {
                        weekArray.push( ROOTPATH + "week/0"+n+".png");
                        weekXpArray.push( ROOTPATH + "week_xp/0"+n+".png");
                        vo2MaxArray.push( ROOTPATH + "vo2MaxProgress/0"+n+".png");
                }
                for(let n=1; n<=12; n++)
                {
                    monthArray.push(ROOTPATH +"month/"+n+".png");
                }
                for(let n=1; n<=30; n++)
                {
                    var path3= ROOTPATH +"moon/"+"moon"+n+".png";
                    moonArray.push(path3);
                }
                // console.log("dayarr==length"+dayArray.length+"==dayxparr="+dayArrayXp.length)
            }
            function setPrevNextDay()
            {
                // 已全局声明时间传感器
                // var jsTime = hmSensor.createSensor(hmSensor.id.TIME);
                var year= parseInt(jstime.year);
                var month=parseInt(jstime.month);
                var day = parseInt(jstime.day);
                var prev= day-1;
                var next= day+1;
                if(month == 2)
                {
                    if(year % 4 == 0 && (year % 100!=0 || year % 400==0))
                    {//闰年2月29天
                        if(day == 29 )  next = 1;
                    }else {//平年2月28天
                        if(day == 28 ) next = 1;
                    }
                    if(day == 1 )  prev = 31;

                }else if( month == 4 || month == 6 || month == 9 || month ==11 )//30天
                {
                    if(day == 30 ) next = 1;
                    if(day == 1 )  prev = 31; //prev = 30

                }else {//31天
                    if(month==3 && day==1){
                        if(year % 4 == 0 && (year % 100!=0 || year % 400==0))
                        {
                            prev=29;
                        }else{
                            prev=28;
                        }
                    }else {
                        if(day == 31 ) next = 1;
                        if(month==1 || month==8) {
                        if(day == 1 ) prev = 31;
                       }else{
                        if(day == 1 ) prev = 30;
                       }

                    }
                }
                prevDay.setProperty(hmUI.prop.SRC, dayArray[prev -1]);
                nextDay.setProperty(hmUI.prop.SRC, dayArray[next -1]);
              //  console.log("-----------day="+day+" -----------prve= "+prev+"----------- next= "+next);
            }

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                resume_call: (function () {
                    setPrevNextDay();
                    let pai_current = pai.dailypai
                    let vo2_max_resume = sport_effect.vo2max

                    // 避免数据获取不到时存在问题
                    if(!pai_current) pai_current = 0
                    if(!vo2_max_resume) vo2_max_resume = 0

                    if(pai_current != pai_today) {
                        pai_today =  pai_current
                        pai_pointer.setProperty(hmUI.prop.ANGLE, 210 + pai_current * 1.5 )
                    }
                    if(vo2_max_resume != vo2_sensor_current) {
                        vo2_sensor_current = vo2_max_resume
                        vox_Pointer.setProperty(hmUI.prop.ANGLE, 150  - vo2_max_resume * 1.5 )
                    }

                }),
                pause_call: (function () {
                }),

            });
        },

        onInit() {
            console.log('index page.js on init invoke');

            this.init_view();


        },

        onReady() {
            console.log('index page.js on ready invoke')
        },

        onShow() {
            console.log('index page.js on show invoke')
        },

        onHide() {
            console.log('index page.js on hide invoke')
        },

        onDestory() {
            console.log('index page.js on destory invoke')
        },
    });
    /*
    * end js
    */
        })()
    } catch (e) {
        console.log(e)
    }