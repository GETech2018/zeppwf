/*
* =====================================================================================
*
*  Copyright (C) 2021. Huami Ltd, unpublished work. This computer program includes
*  Confidential, Proprietary Information and is a Trade Secret of Huami Ltd.
*  All use, disclosure, and/or reproduction is prohibited unless authorized in writing.
*  All Rights Reserved.
*
*  Author: huami
*
* =====================================================================================
*/
try {
  (() => {

    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

    /*
     * huamiOS bundle tool v1.0.17
     * Copyright © Huami. All Rights Reserved
     */
    'use strict';
    /* params声明 */

    let strRootPath = "images/"
    let calorie = null
    let cal = null
    let nX = 0
    let nY = 0
    let nWidth = 416
    let nHeight = 416
    let nPageX = 208
    let nPageY = 208
    let nCalX = 160
    let nCalY = 29
    let nIconX = 237
    let nIconY = 236
    let arrAodDay = []
    let arrNorDay = []
    let arrWeek = []
    let arrMonth = []
    let arrCalLine = []
    let arrBatLine = []
    let arrWeather = []
    let arrMoon = []
    let arrPointerConfig = [
      {
        id: 1,
        second:{
            centerX: nPageX,
            centerY: nPageY,
            posX: 14,
            posY: nPageY,
            path: strRootPath + "pointer/sec.png",
        },
        preview:strRootPath+"pointer/red1.png",
      },
      {
        id: 2,
        second:{
            centerX: nPageX,
            centerY: nPageY,
            posX: 14,
            posY: nPageY,
            path: strRootPath + "pointer/sec_green.png",
        },
        preview:strRootPath+"pointer/green1.png",
      },
      {
        id: 3,
        second:{
            centerX: nPageX,
            centerY: nPageY,
            posX: 14,
            posY: nPageY,
            path: strRootPath + "pointer/sec_yellow.png",
        },
        preview:strRootPath+"pointer/yellow1.png",
      },
      {
        id: 4,
        second:{
            centerX: nPageX,
            centerY: nPageY,
            posX: 14,
            posY: nPageY,
            path: strRootPath + "pointer/sec_blue.png",
        },
        preview:strRootPath+"pointer/blue1.png",
      },

    ]

    /* 遍历数组 */
    for (let i = 0; i < 30; i++){

      if(i < 8){
        arrWeek.push(strRootPath + "week/" + i + ".png")
      }
      if(i < 10){
        arrNorDay.push(strRootPath + "data_font/" + i + ".png")
        arrAodDay.push(strRootPath + "day_font/" + i + ".png")
        arrCalLine.push(strRootPath + "cal/" + i + ".png")
        arrBatLine.push(strRootPath + "bat/" + i + ".png")
      }
      if(i < 12){
        arrMonth.push(strRootPath + "month/" + i + ".png")
      }
      if(i < 29){
        arrWeather.push(strRootPath + "weather/" + i + ".png")
      }
      arrMoon.push(strRootPath + "moon/" + i + ".png")
    }
     let objCalMask = {
      x: nCalX,
      show_level: hmUI.show_level.ONLY_NORMAL,
    }
    let objCalTextHide = {
      y: nCalY,
      src: strRootPath + "cal/wu.png",
    }
    let objCalTextDisplay = {
      y: -nCalY,
      src: "images/data_font/du.png",
    }
    calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
    function setImgPath(obj) {
      cal.setProperty(hmUI.prop.MORE, obj);
    }
    function fn(){
      let cal_current = calorie.current
      let cal_target = calorie.target
      if (cal_current <= cal_target * (0.01)) {
        setImgPath(objCalTextHide)
      } else {
        setImgPath(objCalTextDisplay)
      }
    }
    /* 定义fn */
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      /* 背景为可编辑背景/息屏背景 */
      getEditBg(){
        /* 可编辑背景 */
        let nEditBgId = 103
        let nTipsX = 155
        let nTipsY = 358
        let editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
          edit_id: nEditBgId,
          x: nX,
          y: nY,
          bg_config: [
              { id: 1, preview: strRootPath + "preview/preview_red.png", path: strRootPath + "mask/bg_red.png" },
              { id: 2, preview: strRootPath + "preview/preview_blue.png", path: strRootPath + "mask/bg_blue.png" },
              { id: 3, preview: strRootPath + "preview/preview_yellow.png", path: strRootPath + "mask/bg_yellow.png" },
              { id: 4, preview: strRootPath + "preview/preview_green.png", path: strRootPath + "mask/bg_green.png" },
              { id: 5, preview: strRootPath + "preview/preview_1.png", path: strRootPath + "mask/bg_1.png" },
            ],
          count: 5,
          default_id: 1,
          fg: strRootPath + "mask/mask-70-1green.png",
          tips_x: nTipsX,
          tips_y: nTipsY,
          tips_bg: strRootPath + "mask/tips.png",
        });
        /* 息屏背景 */
        let aodBg = hmUI.createWidget(hmUI.widget.IMG, {
          x: nX,
          y: nY,
          w: nWidth,
          h: nHeight,
          src: strRootPath + "aod/BG.png",
          show_level: hmUI.show_level.ONAL_AOD,
        })
      },
      /* 电量/天气/卡路里 数值 */
      getFont(options){
        let objConfig = {
          x:0,
          y:0,
          w:0,
          type:"",
          font_array:arrNorDay,
          h_space:0,
          align_h:hmUI.align.CENTER_H,
          unit_sc:"",
          unit_tc:"",
          unit_en:"",
          invalid_image: "images/data_font/null.png",
          padding: false,
          negative_image:"",
          show_level:hmUI.show_level.ONLY_NORMAL
        }
        for(let key in options) {
          if(key in objConfig) {
            objConfig[key] = options[key]
          }
        }
        for(let key in objConfig) {
          if(!objConfig[key]) {
            delete objConfig[key]
          }
        }
        let text = hmUI.createWidget(hmUI.widget.TEXT_IMG,objConfig)

      },
      /* 电量/卡路里 进度 */
      getLevel(options){
        let {x,y,arr,type} = options
        let progress = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: x,
          y: y,
          image_array: arr,
          image_length: arr.length, //长度
          type: type,
          show_level:hmUI.show_level.ONLY_NORMAL,

        })
      },
      /* 月份/日期/星期 */
      getTimeControl(){
          /* 月份/日期 */
          let nMonthX = 100
          let nMonthY = 213
          let nDatX = 52
          let nDatY = 197
          let timeMonth = hmUI.createWidget(hmUI.widget.IMG_DATE,{
            month_startX:nMonthX,
            month_startY:nMonthY,
            month_zero:1,//是否补零
            month_follow:0,//是否跟随
            month_en_array: arrMonth,
            month_sc_array: arrMonth,
            month_tc_array: arrMonth,
            month_is_character:true,
            day_startX:nDatX,
            day_startY:nDatY,
            day_align:hmUI.align.LEFT,
            day_space:0,//文字间隔
            day_zero:1,//是否补零
            day_follow:0,//是否跟随
            day_en_array: arrAodDay,
            day_sc_array: arrAodDay,
            day_tc_array: arrAodDay,
            show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD,
          })
          /* 星期 */
          let nWeekX = 101
          let nWeekY = 190
          let timeWeek = hmUI.createWidget(hmUI.widget.IMG_WEEK,{
            x:nWeekX,
            y:nWeekY,
            week_en:arrWeek,
            week_tc:arrWeek,
            week_sc:arrWeek,
            show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD,
          })
      },
      /* 获取时钟指针 */
      getPointerControl(){
        /*指针 ----正常状态*/
        let nHourX = 31
        let nHourY = 153
        let nMinX = 21
        let nMinY = 209
        let timePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
        hour_centerX: nPageX,
        hour_centerY: nPageY,
        hour_posX: nHourX,
        hour_posY: nHourY,
        hour_path: strRootPath + "pointer/hour.png",

        minute_centerX: nPageX,
        minute_centerY: nPageY,
        minute_posX: nMinX,
        minute_posY: nMinY,
        minute_path: strRootPath + "pointer/min.png",
        show_level:hmUI.show_level.ONLY_NORMAL
        })
        /*指针 ----息屏状态*/
        let nAodHourX = 31
        let nAodHourY = 153
        let nAodMinX = 21
        let nAodMinY = 209
        let timePointers = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_centerX: nPageX,
          hour_centerY: nPageY,
          hour_posX: nAodHourX,
          hour_posY: nAodHourY,
          hour_path: strRootPath + "aod/hour.png",

          minute_centerX: nPageX,
          minute_centerY: nPageY,
          minute_posX: nAodMinX,
          minute_posY: nAodMinY,
          minute_path: strRootPath + "aod/min.png",
          show_level:hmUI.show_level.ONAL_AOD
        })

        /* 可编辑指针 */
        let nEditPointId = 120
        let nTipX = 155
        let nTipY = 120
        let pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER,{
            edit_id:nEditPointId,
            x: nX,
            y: nY,
            config:arrPointerConfig,
            count: arrPointerConfig.length,
            default_id: 1,
            fg: strRootPath + "mask/mask-70-1.png",
            tips_x: nTipX,
            tips_y: nTipY,
            tips_bg: strRootPath + "mask/tips.png",
        });
        let screenType = hmSetting.getScreenType();
        let aodModel = screenType == hmSetting.screen_type.AOD;
        let pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG,!aodModel);
        pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp);
      },
      /* mask遮罩 */
      getMask(){
          /* 70%mask */
          mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK,{
            x: nX,
            y: nY,
            w: nWidth,
            h: nHeight,
            src: strRootPath + "mask/mask-70-1.png",
            show_level:hmUI.show_level.ONLY_EDIT,
      });
      },

      /* 表盘控件初始化 */
      init_view() {
        /* 获取可编辑背景/息屏背景 */
        this.getEditBg();
        /* 卡路里数值 */
        this.getFont({x:158,y:82,w:100,type:hmUI.data_type.CAL})
        /* 电量数值 */
        this.getFont({x:292,y:209,w:95,type:hmUI.data_type.BATTERY,unit_sc:"images/data_font/per.png",unit_tc:"images/data_font/per.png",unit_en:"images/data_font/per.png"})
        /* 电量进度 */
        this.getLevel({x:292,y:160,arr:arrBatLine,type: hmUI.data_type.BATTERY})

        /* 天气数值 */
        this.getFont({x:162,y:343,w:95,type:hmUI.data_type.WEATHER_CURRENT,
          unit_sc:"images/data_font/du.png",unit_tc:"images/data_font/du.png",
          unit_en:"images/data_font/du.png",negative_image:"images/data_font/fuhao.png"})
        /* 天气icon */
        this.getLevel({x:193,y:305,arr:arrWeather,type:hmUI.data_type.WEATHER})
        cal = hmUI.createWidget(hmUI.widget.IMG, objCalMask)
        /*传感器监听卡路里为0/电量为0 当卡路里达到30才会有进度显示*/

        fn()
        /*传感器监听卡路里为0/电量为0 */
        calorie.addEventListener(hmSensor.event.CHANGE, function() {
        fn()
        });
        hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: (function () {
            fn()
          }),
          pause_call: (function () {
              console.log('ui pause');
          }),
      });
        this.getLevel({x:160,y:30,arr:arrCalLine,type:hmUI.data_type.CAL})
        /* 获取时间数值控件 */
        this.getTimeControl();

        /* 指南针icon */
        let nIconW = 70
        let cpIcon = hmUI.createWidget(hmUI.widget.IMG, {
          x: nIconX,
          y: nIconY,
          w: nIconW,
          h: nIconW,
          src: "images/compass.png",
          enable: true, //false不接收点击事件
          show_level: hmUI.show_level.ONLY_NORMAL,
        })
        /* 月相icon */
        let mIconX = 237
        let mIconY = 123
        let moonIcon = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: mIconX,
          y: mIconY,
          image_array: arrMoon,
          image_length: arrMoon.length, //长度
          type: hmUI.data_type.MOON,
          shortcut: true,
          show_level:hmUI.show_level.ONLY_NORMAL,
        })

        /* 获取时间指针控件 */
        this.getPointerControl();

        /*监听点击指南针跳转页面*/
        cpIcon.addEventListener(hmUI.event.CLICK_UP, function (info) {
          hmApp.startApp({url: "CompassScreen",native: true});
        });

        /*点击区域跳转指定位置--还未提供接口 1.6之前提供*/
        //blke
        let blkeX = 51
        let blkeY = 58
        let regionW = 40
        let regionH = 35
        let blkeClick = hmUI.createWidget(hmUI.widget.IMG_CLICK,{
          x:blkeX,
          y:blkeY,
          w:regionW,
          h:regionH,
          enable: true,
          type:hmUI.data_type.OUTDOOR_CYCLING,
          show_level:hmUI.show_level.ONLY_NORMAL
        })
         //running
         let runX = 318
         let runY = 57
         let runClick = hmUI.createWidget(hmUI.widget.IMG_CLICK,{
           x:runX,
           y:runY,
           w:regionW,
           h:regionH,
           enable: true,
           type:hmUI.data_type.OUTDOOR_RUNNING,
           show_level:hmUI.show_level.ONLY_NORMAL
         })
        //swimming
        let swimX = 51
        let swimY = 336
        let swimClick = hmUI.createWidget(hmUI.widget.IMG_CLICK,{
          x:swimX,
          y:swimY,
          w:regionW,
          h:regionH,
          enable: true,
          type:hmUI.data_type.POOL_SWIMMING,
          show_level:hmUI.show_level.ONLY_NORMAL
        })
        //walk
        let walkX = 309
        let walkY = 336
        let walkClick = hmUI.createWidget(hmUI.widget.IMG_CLICK,{
          x:walkX,
          y:walkY,
          w:regionW,
          h:regionH,
          enable: true,
          type:hmUI.data_type.WALKING,
          show_level:hmUI.show_level.ONLY_NORMAL
        })

        /* 获取70%mask遮罩 */
        this.getMask();

      },
      onInit() {
        console.log('index page.js on init invoke');
        this.init_view();
      },
      onReady() {
        console.log('index page.js on ready invoke')
      },
      onShow() {
        console.log('index page.js on show invoke')
      },
      onHide() {
        console.log('index page.js on hide invoke')
      },
      onDestory() {
        console.log('index page.js on destory invoke')
      },
    });
  })()
} catch (e) {
  console.log(e)
}