try {
  (() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');
    /*
  * huamiOS bundle tool v1.0.17
  * Copyright © Huami. All Rights Reserved
  */
    'use strict';
    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);
    let nPosMonthX = 76;
    let nPosMonthY = 158.5;
    let nPosDayX = 72;
    let nPosDayY = 189.5;
    let nSpace = 0;
    let nPosHourX = 179;
    let nPosHourY = 168;
    let nPosMinuteX = 308;
    let nPosAmPmX = 183;
    let nPosAmPmY = 138;
    let nPosSecondX = 297;
    let nPosSecondY = 221;
    let arrTraininf = [];
    let arrData = [];
    let arrDay = [];
    let arrHour = [];
    let arrMinute = [];
    let arrMonth = [];
    let arrMoon = [];
    let arrPower = [];
    let arrSecond = [];
    let arrSteps = [];
    let arrWeek = [];
    let arrAodHour = [];
    let arrAodMinute = [];
    let arrVox = [];
    for (let i = 1; i < 14; i++ ){
      arrMoon.push("images/moon/" + i + ".png");
    }
    for (let i = 1; i < 8; i++) {     
      arrWeek.push("images/week/" + i + ".png");
      arrVox.push("images/vox/" + i + ".png");
    }
    for (let i = 0; i < 3; i++) {
      arrTraininf.push("images/battery/" + i + ".png");
    }
    for (let i = 0; i < 10; i++) {
      arrData.push("images/datafont/" + i + ".png");
      arrDay.push("images/dayfont/" + i + ".png");
      arrHour.push("images/hour/" + i + ".png");
      arrMinute.push("images/minute/" + i + ".png");
      arrPower.push("images/power/" + i + ".png");
      arrSecond.push("images/second/" + i + ".png");
      arrSteps.push("images/steps/" + i + ".png");
      arrAodHour.push(`images/aod/hour/${i}.png`);
      arrAodMinute.push(`images/aod/minute/${i}.png`);
    }
    for (let i = 1; i < 13; i++) {
      arrMonth.push("images/month/" + i + ".png");
    }
    let arrWidget = [
      { type: hmUI.edit_type.STEP, preview: "images/mask/iconpreview/stepsp.png" },
      { type: hmUI.edit_type.CAL, preview: "images/mask/iconpreview/calp.png" },
      { type: hmUI.edit_type.PAI, preview: "images/mask/iconpreview/paip.png" },
      { type: hmUI.edit_type.VO2MAX, preview: "images/mask/iconpreview/vo2p.png" },     
    ];
    function fnGroup(nEditId, nXPos, nYPos, nDefaultType = hmUI.edit_type.STEP, nTipsYPos = 118) {
      let nSelectImgW = 185
      let nSelectImgH = 32
      let nTipsWidth = 97
      return hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
        edit_id: nEditId,
        x: nXPos,
        y: nYPos,
        w: nSelectImgW,
        h: nSelectImgH,
        select_image: "images/mask/select.png",
        un_select_image: "images/mask/unselect.png",
        default_type: nDefaultType,
        optional_types: arrWidget,
        count: arrWidget.length,
        tips_BG: "images/mask/tips.png",
        tips_x: (nSelectImgW - nTipsWidth) / 2,
        tips_y: nTipsYPos,
        tips_width: nTipsWidth,
        tips_margin: 10,
      });
    };
    let objDate = {
      month_startX: nPosMonthX,
      month_startY: nPosMonthY,
      month_zero: false,
      month_en_array: arrMonth,
      month_align: hmUI.align.LEFT,
      month_is_character: true,
      day_startX: nPosDayX,
      day_startY: nPosDayY,
      day_zero: true,
      day_en_array: arrDay,
      day_space: nSpace - 6,
      day_align: hmUI.align.LEFT,
      show_level: hmUI.show_level.ONLY_NORMAL
    }
    let objTimeAPS = {
      am_x: nPosAmPmX,
      am_y: nPosAmPmY,
      am_sc_path: "images/ampm/am.png",
      am_en_path: "images/ampm/am.png",
      pm_x: nPosAmPmX,
      pm_y: nPosAmPmY,
      pm_sc_path: "images/ampm/pm.png",
      pm_en_path: "images/ampm/pm.png",
      second_zero: true,
      second_startX: nPosSecondX,
      second_startY: nPosSecondY,
      second_array: arrSecond,
      second_space: nSpace,
      second_align: hmUI.align.LEFT,
      show_level: hmUI.show_level.ONLY_NORMAL,
    }
    let objTimeHM = {
      hour_zero: true,
      hour_startX: nPosHourX,
      hour_startY: nPosHourY,
      hour_array: arrHour,
      hour_space: nSpace - 10,
      hour_align: hmUI.align.LEFT,
      minute_startX: nPosMinuteX,
      minute_startY: nPosHourY,
      minute_zero: true, //是否补零 1为补零
      minute_follow: false, //是否跟随
      minute_array: arrMinute,
      minute_space: nSpace - 5,
      minute_align: hmUI.align.LEFT,
      show_level: hmUI.show_level.ONLY_NORMAL,    
    }
    let objTimeAodHM = { ...objTimeHM }
    objTimeAodHM.hour_array = arrAodHour
    objTimeAodHM.minute_array = arrAodMinute
    objTimeAodHM.show_level = hmUI.show_level.ONAL_AOD 
    function fnSetBgImg(nWidth, nHeight, strImg, bShow) {
      hmUI.createWidget(hmUI.widget.IMG, {
        x: 0,
        y: 0,
        w: nWidth,
        h: nHeight,
        src: strImg,
        show_level: bShow
      })
    }
    function fnImgLevel(nPosX, nPosY, arrData, dataType, bShow = hmUI.show_level.ONLY_NORMAL) {
      hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
        x: nPosX,
        y: nPosY,
        image_array: arrData,
        image_length: arrData.length,
        type: dataType,
        show_level: bShow,
        shortcut: true
      })
    }
    function fnSetAnim(nFps, nSize, bRepeat, bDisplay) {
      hmUI.createWidget(hmUI.widget.IMG_ANIM, {
        x: 0,
        y: 0,
        anim_path: "images/anim",
        anim_prefix: "anim",
        anim_ext: "png",
        anim_fps: nFps,
        anim_size: nSize,
        anim_repeat: bRepeat,
        repeat_count: 1,
        anim_status: 1,
        display_on_restart: bDisplay,
        show_level: hmUI.show_level.ONLY_NORMAL,
      })
    }
    function fnSetColor(nXPos, nYPos, nWidth, nHeight, color) {
      hmUI.createWidget(hmUI.widget.FILL_RECT, {
        x: nXPos,
        y: nYPos,
        w: nWidth,
        h: nHeight,
        color: color,
        show_level: hmUI.show_level.ONLY_EDIT
      });
    }
    function fnMask(nWidth, nHeight, strImgSrc) {
      hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
        x: 0,
        y: 0,
        w: nWidth,
        h: nHeight,
        src: strImgSrc,
        show_level: hmUI.show_level.ONLY_EDIT,
      });
    }
    function fnDrawWidget(objType, id) {
      let config = {};
      config.h = -3;
      let nCustomTypeId = 103
      switch (id) {
        case 101:
          config.bgx = 180;
          config.bgy = 261;
          config.bgw = 100;
          config.numX = 230;
          config.numY = 261;
          break;
        default:
          return;
      }
      function fnImgBg(imgsrc) { //绘制组件背景
        hmUI.createWidget(hmUI.widget.IMG, {
          x: config.bgx,
          y: config.bgy,
          src: imgsrc,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
      }
      function fnIconText() { //组件数值
        let objText = {
          x: config.numX,
          y: config.numY,
          w: config.bgw,
          type: config.dataType,
          font_array: arrData,
          h_space: config.h,
          align_h: hmUI.align.RIGHT,
          padding: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        }
        hmUI.createWidget(hmUI.widget.TEXT_IMG, objText);
      }
      switch (objType) {
        case hmUI.edit_type.STEP:
          config.id = nCustomTypeId
          config.dataType = hmUI.data_type.STEP;
          config.bgimg1 = "images/mask/icon/steps.png";
          break;
        case hmUI.edit_type.CAL:
          config.id = nCustomTypeId
          config.dataType = hmUI.data_type.CAL;
          config.bgimg1 = "images/mask/icon/cal.png";
          break;
        case hmUI.edit_type.PAI:
          config.id = nCustomTypeId
          config.dataType = hmUI.data_type.PAI_DAILY;
          config.bgimg1 = "images/mask/icon/pai.png";
          break;
        case hmUI.edit_type.VO2MAX:
          config.id = nCustomTypeId
          config.dataType = hmUI.data_type.VO2MAX;
          config.bgimg1 = "images/mask/icon/vo2.png";
          break;
        default:
          console.log("invalid objType type=" + objType);
          return config;
      }
      if (config.id == nCustomTypeId) {
        let arrText = null
        fnImgBg(config.bgimg1);
        fnIconText();
        if(objType == hmUI.edit_type.VO2MAX){
          arrText = arrVox
        }else{
          arrText = arrSteps
        }
        // console.log("555555555555555555555555555=="+arrText);
        fnImgLevel(162, 284, arrText, config.dataType, bShow = hmUI.show_level.ONLY_NORMAL)
        
      }
    }
    class Time {
      createImgTextTime(option) {
        this.widget = hmUI.createWidget(hmUI.widget.IMG_TIME, option);
      }
      createImgWeek(nPosX, nPosY, arrWeek, bShow = hmUI.show_level.ONLY_NORMAL) {
        this.widget = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
          x: nPosX,
          y: nPosY,
          week_tc: arrWeek,
          week_sc: arrWeek,
          week_en: arrWeek,
          show_level: bShow,
        });
      }
      createImgDate(option) {
        this.widget = hmUI.createWidget(hmUI.widget.IMG_DATE, option);
      }
    }
    const logger = DeviceRuntimeCore.HmLogger.getLogger("defult");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        const timeText = new Time();
        fnSetAnim(25, 40, true, true);
        fnSetBgImg(416, 416, "images/bg.png", hmUI.show_level.ONLY_NORMAL);
        timeText.createImgWeek(21, 116, arrWeek);
        timeText.createImgDate(objDate);
        timeText.createImgTextTime(objTimeHM);
        timeText.createImgTextTime(objTimeAodHM);
        timeText.createImgTextTime(objTimeAPS);
        fnImgLevel(49, 289, arrMoon, hmUI.data_type.MOON);
        fnImgLevel(153, 359, arrTraininf, hmUI.data_type.TRAINING_LOAD);
        fnImgLevel(337, 227, arrPower, hmUI.data_type.BATTERY);
        fnSetColor(165, 252, 185, 32, 0x414752);
        fnDrawWidget(fnGroup(101, 162, 250, hmUI.edit_type.STEP, -40).getProperty(hmUI.prop.CURRENT_TYPE), 101);
        fnMask(416, 416, "images/mask/mask.png");
        fnMask(416, 416, "images/mask/mask70.png")
      },
      onInit() {
        console.log('index page.js on init invoke');
        this.init_view();
      },
      onReady() {
        console.log('index page.js on ready invoke')
      },
      onShow() {
        console.log('index page.js on show invoke')
      },
      onHide() {
        console.log('index page.js on hide invoke')
      },
      onDestory() {
        console.log('index page.js on destory invoke')
      },
    });
    /*
    * end js
    */
  })()
} catch (e) {
  console.log(e)
}