try {
    (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;

        var __$$module$$__ = __$$app$$__.current;
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        /*
         * huamiOS bundle tool v1.0.17
         * Copyright © Huami. All Rights Reserved
         */
        'use strict';

        console.log("----->>>current");
        console.log(__$$hmAppManager$$__.currentApp.pid);
        console.log(__$$hmAppManager$$__.currentApp.current);
        const { width } = hmSetting.getDeviceInfo(); 
        function rem(num) {
            return num * (width / 480); //andes
            // return num * (466 / 480);  //berlin          
        }

        let SBname = `vienna/`;
        // let SBname = `berlin/`;

        const WIDGET_OUT_ID = 101;
        const WIDGET_MID_ID = 102;
        const WIDGET_INNER_ID = 103;
        const WIDGET_UP_ID = 104;
        const WIDGET_DOWN_ID = 105;

        const WIDGET_EDIT_LEFT_SIZE = rem(48); //預覽圖圖片大小
        const WIDGET_INNER = 1;
        const WIDGET_MID = 2;
        const WIDGET_OUT = 3;
        const WIDGET_RIGHT_1 = 4;
        const WIDGET_RIGHT_2 = 5;

        const WIDGET_TIPS_WIDTH = rem(102);
        const ROOTPATH = "images/" + SBname;
        const WIDGET_BG_PATH = ROOTPATH + "fast/";

        const widget_Small_Preview = ROOTPATH + "fast/";
        const widget_Big_Preview = ROOTPATH + "widget_preview_right/";

        const TIPS_ROOT = ROOTPATH + "tips/";
        const WIDGET_TIPS_PATH = TIPS_ROOT + "widget_tips.png";

        let select = null;
        let innerWidget = null;
        let midWidget = null;
        let outWidget = null;
        let rightWidget1 = null;
        let rightWidget2 = null;

        let baseURL = '';
        let imgLevelBg = '';

        let groupX = 0;
        let groupY = 0;
        let arrRedImg = [];
        let arrGreenImg = [];
        let arrBlueImg = [];

        const arrFontRed = [];
        const arrFontGreen = [];
        const arrFontBlue = [];
        const arrTime = [];
        const arrWeather = [];
        const arrFontRight = [];
        for (let i = 0; i < 10; i++) {
            arrFontRed.push(ROOTPATH + `fast/font_red/0` + i + `.png`);
            arrFontGreen.push(ROOTPATH + `fast/font_green/0` + i + `.png`);
            arrFontBlue.push(ROOTPATH + `fast/font_blue/0` + i + `.png`);
            arrTime.push(ROOTPATH + `fast/time/0` + i + `.png`);
            arrFontRight.push(ROOTPATH + `fast/fonts/0` + i + `.png`);
        }
        for (let i = 0; i < 29; i++) {
            arrWeather.push(ROOTPATH + `fast/weather/` + i + `.png`);
        }
        for (let i = 1; i < 11; i++) {
            arrRedImg.push(ROOTPATH + 'fast/red/' + i + '.png');
            arrGreenImg.push(ROOTPATH + 'fast/green/' + i + '.png');
            arrBlueImg.push(ROOTPATH + 'fast/blue/' + i + '.png');
        }
        let edit_list_config = { //编辑列表配置
            title_font_size: 34,
            title_align_h: hmUI.align.CENTER_H,
            list_item_vspace: 8,
            list_bg_color: 0x000000,
            list_bg_radius: 30,
            list_group_text_font_size: 32,
            list_group_text_align_h: hmUI.align.CENTER_H,
            list_tips_text_font_size: 32,
            list_tips_text_align_h: hmUI.align.LEFT,
            // list_group_text_align_h: hmUI.align.CENTER_H,
        };

        const logger = DeviceRuntimeCore.HmLogger.getLogger("sanjiao");
        __$$module$$__.module = DeviceRuntimeCore.Page({
            parseWidgetConfig_right(editType) {
                let config = {
                    bgPath: null, //背景图
                    iconPath: null, //图标
                    dataType: null, //数据类型
                    nonePath: null, //无数据的图片
                    negativeImage: null,
                    unitEnPath: null, //单位
                    unitScPath: null,
                    unitTcPath: null,
                    spPath: null,
                    textX: rem(305)
                };
                switch (editType) {
                    case hmUI.edit_type.STEP:
                        config.bgPath = ROOTPATH + "widget_right/step.png";
                        config.dataType = hmUI.data_type.STEP;
                        break;
                    case hmUI.edit_type.HEART:
                        config.bgPath = ROOTPATH + "widget_right/heart.png";
                        config.dataType = hmUI.data_type.HEART;
                        break;
                    case hmUI.edit_type.WEATHER:
                        config.dataType = hmUI.data_type.WEATHER_CURRENT;
                        config.unitEnPath = ROOTPATH + "widget_right/du.png";
                        config.unitScPath = ROOTPATH + "widget_right/du.png";
                        config.unitTcPath = ROOTPATH + "widget_right/du.png";
                        break;
                    case hmUI.edit_type.HUMIDITY:
                        config.bgPath = ROOTPATH + "widget_right/hum.png";
                        config.dataType = hmUI.data_type.HUMIDITY;
                        // config.unitEnPath = ROOTPATH + "widget_right/precent.png";
                        // config.unitScPath = ROOTPATH + "widget_right/precent.png";
                        // config.unitTcPath = ROOTPATH + "widget_right/precent.png";
                        break;
                    case hmUI.edit_type.UVI:
                        config.bgPath = ROOTPATH + "widget_right/uvi.png";
                        config.dataType = hmUI.data_type.UVI;
                        break;
                    case hmUI.edit_type.AQI:
                        config.bgPath = ROOTPATH + "widget_right/aqi.png";
                        config.dataType = hmUI.data_type.AQI;
                        break;
                    default:
                        // console.log("invalid editType type=" + editType);
                        return config;
                }
                return config;
            },
            parseWidgetConfig(editType, baseURL) {
                let config = {
                    bgPath: null, //背景图
                    iconPath: null, //图标
                    dataType: null, //数据类型
                    nonePath: "none.png", //无数据的图片
                    negativeImage: null,
                    unitEnPath: null, //单位
                    unitScPath: null,
                    unitTcPath: null,
                    spPath: null,
                    pointerType: null,
                    startAngle: 0, //指针开始角度
                    endAngle: 360, //指针结束角度
                    imgLevelBg: null,
                    textX: rem(270)
                };

                switch (editType) {
                    case hmUI.edit_type.STEP:
                        config.bgPath = baseURL + "step.png";
                        config.dataType = hmUI.data_type.STEP;
                        break;
                    case hmUI.edit_type.CAL:
                        config.bgPath = baseURL + "cal.png";
                        config.dataType = hmUI.data_type.CAL;
                        break;
                    case hmUI.edit_type.PAI_WEEKLY:
                        config.bgPath = baseURL + "pai.png";
                        config.dataType = hmUI.data_type.PAI_WEEKLY;
                        break;
                    case hmUI.edit_type.HEART:
                        config.bgPath = baseURL + "heart.png";
                        config.dataType = hmUI.data_type.HEART;
                        break;
                    case hmUI.edit_type.BATTERY:
                        config.bgPath = baseURL + "bat.png";
                        config.dataType = hmUI.data_type.BATTERY;
                        config.unitEnPath = "precent.png";
                        config.unitScPath = "precent.png";
                        config.unitTcPath = "precent.png";
                        break;
                    case hmUI.edit_type.HUMIDITY:
                        config.bgPath = baseURL + "hum.png";
                        config.dataType = hmUI.data_type.HUMIDITY;
                        // config.unitEnPath = "precent.png";
                        // config.unitScPath = "precent.png";
                        // config.unitTcPath = "precent.png";                       
                        break;
                    default:
                        // console.log("invalid editType type=" + editType);
                        return config;
                }
                if (config.bgPath != null) {
                    config.bgPath = WIDGET_BG_PATH + config.bgPath;
                }
                if (config.pointerType == null) {
                    config.pointerType = config.dataType;
                }
                return config;
            },
            drawWidget(widgetType, editType) {

                let bgX = 0;
                let bgY = 0;
                let right_flag = false;
                const bgSize = rem(56);
                switch (widgetType) { //弧形icon  
                    case WIDGET_INNER:
                        bgX = rem(265);
                        bgY = rem(330);
                        baseURL = 'red_icon/';
                        imgLevelBg = 'red/';
                        right_flag = false;
                        break;
                    case WIDGET_MID:
                        bgX = rem(265);
                        bgY = rem(380);
                        baseURL = 'green_icon/';
                        imgLevelBg = 'green/';
                        right_flag = false;
                        break;
                    case WIDGET_OUT:
                        bgX = rem(265);
                        bgY = rem(430);
                        baseURL = 'blue_icon/';
                        imgLevelBg = 'blue/';
                        right_flag = false;
                        break;
                    case WIDGET_RIGHT_1:
                        bgY = rem(92);
                        right_flag = true;
                        break;
                    case WIDGET_RIGHT_2:
                        bgY = rem(325);
                        right_flag = true;
                        break;
                    default:
                        // console.log("invalid widgetType type=" + widgetType);
                        return;
                }


                let config = null;
                if (right_flag) {
                    config = this.parseWidgetConfig_right(editType);
                } else {
                    config = this.parseWidgetConfig(editType, baseURL);
                    config.imgLevelBg = imgLevelBg;
                }

                var imgArr = [];
                var level_x = 0;
                var level_y = 0;
                var text_y = 0;

                if (right_flag) {
                    var prop_obj2 = null;
                    //右侧: 两编辑框文字的渲染
                    prop_obj2 = {
                        x: config.textX + rem(6),
                        y: bgY + rem(46),
                        w: rem(132),
                        type: config.dataType,
                        font_array: arrFontRight,
                        h_space: 0,
                        //图片间隔
                        align_h: hmUI.align.CENTER_H,
                        invalid_image: ROOTPATH + 'widget_right/none.png',
                        padding: false,
                        //是否补零 true为补零 
                        negative_image: ROOTPATH + 'widget_right/fuhao.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    };
                    if (config.unitEnPath) {
                        prop_obj2.unit_sc = config.unitScPath;
                        prop_obj2.unit_tc = config.unitTcPath;
                        prop_obj2.unit_en = config.unitEnPath;
                    }
                    let text2 = hmUI.createWidget(hmUI.widget.TEXT_IMG, prop_obj2);

                    if (config.dataType != hmUI.data_type.WEATHER_CURRENT) {
                        var img_prop = {
                            x: rem(349) + 4,
                            y: bgY - rem(5),
                            w: 44,
                            h: 44,
                            src: config.bgPath,
                            //表示只在正常表盘和息屏下显示 在可编辑下会不创建 会返回一个虚拟控件 保证js不报错
                            show_level: hmUI.show_level.ONLY_NORMAL
                        };
                        hmUI.createWidget(hmUI.widget.IMG, img_prop);

                    } else {
                        hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                            x: rem(350) - 2,
                            y: bgY - rem(5),
                            w: 50,
                            h: 50,
                            image_array: arrWeather,
                            image_length: arrWeather.length,
                            type: hmUI.data_type.WEATHER_CURRENT,
                            show_level: hmUI.show_level.ONLY_NORMAL
                        });

                    }

                } else {
                    var fontColorType = null;
                    if (config.imgLevelBg == 'red/') {
                        if (config.unitEnPath) {
                            config.unitEnPath = ROOTPATH + "fast/red/precent.png";
                            config.unitScPath = ROOTPATH + "fast/red/precent.png";
                            config.unitTcPath = ROOTPATH + "fast/red/precent.png";
                        }
                        config.nonePath = ROOTPATH + "fast/red/none.png";
                        level_x = rem(109);
                        level_y = rem(108);
                        text_y = rem(116);
                        fontColorType = arrFontRed;
                        imgArr = arrRedImg;

                    }
                    if (config.imgLevelBg == 'green/') {
                        if (config.unitEnPath) {
                            config.unitEnPath = ROOTPATH + "fast/green/precent.png"; // du
                            config.unitScPath = ROOTPATH + "fast/green/precent.png";
                            config.unitTcPath = ROOTPATH + "fast/green/precent.png";
                        }
                        config.nonePath = ROOTPATH + "fast/green/none.png";
                        level_x = Math.ceil(rem(55));
                        level_y = rem(57);
                        text_y = rem(68);
                        fontColorType = arrFontGreen;
                        imgArr = arrGreenImg;

                    }
                    if (config.imgLevelBg == 'blue/') {
                        if (config.unitEnPath) {
                            config.unitEnPath = ROOTPATH + "fast/blue/precent.png";
                            config.unitScPath = ROOTPATH + "fast/blue/precent.png";
                            config.unitTcPath = ROOTPATH + "fast/blue/precent.png";
                        }
                        config.nonePath = ROOTPATH + "fast/blue/none.png";
                        level_x = rem(7);
                        level_y = rem(9);
                        text_y = rem(19);
                        fontColorType = arrFontBlue;
                        imgArr = arrBlueImg;

                    }




                    hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                        x: level_x,
                        y: level_y,
                        image_array: imgArr,
                        image_length: imgArr.length,
                        type: config.dataType,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });

                    var prop_obj = null;
                    prop_obj = {
                        x: config.textX,
                        y: text_y,
                        type: config.dataType,
                        font_array: fontColorType,
                        h_space: 0,
                        //图片间隔
                        align_h: hmUI.align.LEFT,
                        invalid_image: config.nonePath,
                        padding: false,
                        show_level: hmUI.show_level.ONLY_NORMAL
                        //是否补零 true为补零 
                    };
                    var unitObj = {};
                    if (config.unitEnPath) {
                        var unitObj = {
                            unit_sc: config.unitScPath,
                            //单位
                            unit_tc: config.unitTcPath,
                            //单位
                            unit_en: config.unitEnPath,
                            //单位  
                        };
                    }
                    let newObj = Object.assign(prop_obj, unitObj);
                    let text = hmUI.createWidget(hmUI.widget.TEXT_IMG, newObj);

                    if (config.dataType == hmUI.data_type.BATTERY ||
                        config.dataType == hmUI.data_type.CAL ||
                        config.dataType == hmUI.data_type.HUMIDITY ||
                        config.dataType == hmUI.data_type.PAI_WEEKLY ||
                        config.dataType == hmUI.data_type.STEP ||
                        config.dataType == hmUI.data_type.HEART) {
                        hmUI.createWidget(hmUI.widget.IMG, {
                            x: bgX,
                            y: bgY,
                            w: bgSize,
                            h: bgSize,
                            src: config.bgPath,
                            show_level: hmUI.show_level.ONLY_NORMAL
                        });
                    }
                }

            },
            init_view() {
                select = ROOTPATH + "select/";
                var img_bg1 = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    // w: 466,
                    // h: 466,
                    src: ROOTPATH + "bg/bg.png",
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                let red_WidgetOptionalArray = [{
                        type: hmUI.edit_type.STEP,
                        preview: widget_Small_Preview + "red_icon/step.png"
                    },
                    {
                        type: hmUI.edit_type.CAL,
                        preview: widget_Small_Preview + "red_icon/cal.png"
                    },
                    {
                        type: hmUI.edit_type.PAI_WEEKLY,
                        preview: widget_Small_Preview + "red_icon/pai.png"
                    },
                    {
                        type: hmUI.edit_type.BATTERY,
                        preview: widget_Small_Preview + "red_icon/bat.png"
                    },
                    {
                        type: hmUI.edit_type.HUMIDITY,
                        preview: widget_Small_Preview + "red_icon/hum.png"
                    },
                    {
                        type: hmUI.edit_type.HEART,
                        preview: widget_Small_Preview + "red_icon/heart.png"
                    },
                ];
                       
                groupX = rem(259);
                groupY = rem(329);
                //可编辑组件
                innerWidget = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {  // 左上
                    edit_id: WIDGET_INNER_ID,
                    x: groupX,
                    y: groupY,
                    w: WIDGET_EDIT_LEFT_SIZE,
                    h: WIDGET_EDIT_LEFT_SIZE,
                    select_image: select + "select_small.png",
                    un_select_image: select + "unselect_small.png",
                    default_type: hmUI.edit_type.PAI_WEEKLY,
                    optional_types: red_WidgetOptionalArray,
                    count: red_WidgetOptionalArray.length,
                    tips_BG: WIDGET_TIPS_PATH,
                    tips_x: -106,
                    tips_y: 5,
                    tips_width: WIDGET_TIPS_WIDTH,
                    tips_margin: 10,
                    select_list: edit_list_config,
                });
                var editTypeTop = innerWidget.getProperty(hmUI.prop.CURRENT_TYPE);
                this.drawWidget(WIDGET_INNER, editTypeTop);


                let green_WidgetOptionalArray = [{
                        type: hmUI.edit_type.STEP,
                        preview: widget_Small_Preview + "green_icon/step.png"
                    },
                    {
                        type: hmUI.edit_type.CAL,
                        preview: widget_Small_Preview + "green_icon/cal.png"
                    },
                    {
                        type: hmUI.edit_type.PAI_WEEKLY,
                        preview: widget_Small_Preview + "green_icon/pai.png"
                    },
                    {
                        type: hmUI.edit_type.BATTERY,
                        preview: widget_Small_Preview + "green_icon/bat.png"
                    },
                    {
                        type: hmUI.edit_type.HUMIDITY,
                        preview: widget_Small_Preview + "green_icon/hum.png"
                    },
                    {
                        type: hmUI.edit_type.HEART,
                        preview: widget_Small_Preview + "green_icon/heart.png"
                    },
                ];
                groupX = rem(259);
                groupY = rem(377);
                midWidget = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {//左中
                    edit_id: WIDGET_MID_ID,
                    x: groupX,
                    y: groupY,
                    w: WIDGET_EDIT_LEFT_SIZE,
                    h: WIDGET_EDIT_LEFT_SIZE,
                    select_image: select + "select_small.png",
                    un_select_image: select + "unselect_small.png",
                    default_type: hmUI.edit_type.STEP,
                    optional_types: green_WidgetOptionalArray,
                    count: green_WidgetOptionalArray.length,
                    tips_BG: WIDGET_TIPS_PATH,
                    tips_x: -106,
                    tips_y: 5,
                    tips_width: WIDGET_TIPS_WIDTH,
                    tips_margin: 10,
                    select_list: edit_list_config,
                });
                let editTypeCenter = midWidget.getProperty(hmUI.prop.CURRENT_TYPE);
                this.drawWidget(WIDGET_MID, editTypeCenter);

                let blue_WidgetOptionalArray = [{
                        type: hmUI.edit_type.STEP,
                        preview: widget_Small_Preview + "blue_icon/step.png"
                    },
                    {
                        type: hmUI.edit_type.CAL,
                        preview: widget_Small_Preview + "blue_icon/cal.png"
                    },
                    {
                        type: hmUI.edit_type.PAI_WEEKLY,
                        preview: widget_Small_Preview + "blue_icon/pai.png"
                    },
                    {
                        type: hmUI.edit_type.BATTERY,
                        preview: widget_Small_Preview + "blue_icon/bat.png"
                    },
                    {
                        type: hmUI.edit_type.HUMIDITY,
                        preview: widget_Small_Preview + "blue_icon/hum.png"
                    },
                    {
                        type: hmUI.edit_type.HEART,
                        preview: widget_Small_Preview + "blue_icon/heart.png"
                    },
                ];
                groupX = rem(259);
                groupY = rem(425);
                outWidget = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {//左下
                    edit_id: WIDGET_OUT_ID,
                    x: groupX,
                    y: groupY,
                    w: WIDGET_EDIT_LEFT_SIZE,
                    h: WIDGET_EDIT_LEFT_SIZE,
                    select_image: select + "select_small.png",
                    un_select_image: select + "unselect_small.png",
                    default_type: hmUI.edit_type.BATTERY,
                    optional_types: blue_WidgetOptionalArray,
                    count: blue_WidgetOptionalArray.length,
                    tips_BG: WIDGET_TIPS_PATH,
                    tips_x: -106,
                    tips_y: 5,
                    tips_width: WIDGET_TIPS_WIDTH,
                    tips_margin: 10,
                    select_list: edit_list_config,
                });
                let editTypeBottom = outWidget.getProperty(hmUI.prop.CURRENT_TYPE);
                this.drawWidget(WIDGET_OUT, editTypeBottom);
                // -----------------------------------------------------------------s
                let right_WidgetOptionalArray = [{
                        type: hmUI.edit_type.STEP,
                        preview: widget_Big_Preview + "step.png"
                    },
                    {
                        type: hmUI.edit_type.UVI,
                        preview: widget_Big_Preview + "uvi.png"
                    },
                    {
                        type: hmUI.edit_type.WEATHER,
                        preview: widget_Big_Preview + "weather.png"
                    },
                    {
                        type: hmUI.edit_type.HUMIDITY,
                        preview: widget_Big_Preview + "hum.png"
                    },
                    {
                        type: hmUI.edit_type.HEART,
                        preview: widget_Big_Preview + "heart.png"
                    },
                    // { type: hmUI.edit_type.AQI, preview: widget_Big_Preview + "aqi.png" },
                ];

                groupX = rem(326);
                groupY = rem(87);
                rightWidget1 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, { //右上组件
                    edit_id: WIDGET_UP_ID,
                    x: groupX,
                    y: groupY,
                    w: rem(103),
                    h: rem(103),
                    select_image: select + "select_big.png",
                    un_select_image: select + "unselect_big.png",
                    default_type: hmUI.edit_type.WEATHER,
                    optional_types: right_WidgetOptionalArray,
                    count: right_WidgetOptionalArray.length,
                    tips_BG: WIDGET_TIPS_PATH,
                    tips_x: 0,
                    tips_y: 104,
                    tips_width: WIDGET_TIPS_WIDTH,
                    tips_margin: 10,
                    select_list: edit_list_config,
                });
                let editTypeRT = rightWidget1.getProperty(hmUI.prop.CURRENT_TYPE);
                this.drawWidget(WIDGET_RIGHT_1, editTypeRT);

                groupX = rem(326);
                groupY = rem(306);
                rightWidget2 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, { //右下组件
                    edit_id: WIDGET_DOWN_ID,
                    x: groupX,
                    y: groupY,
                    w: rem(103),
                    h: rem(103),
                    select_image: select + "select_big.png",
                    un_select_image: select + "unselect_big.png",
                    default_type: hmUI.edit_type.HEART,
                    optional_types: right_WidgetOptionalArray,
                    count: right_WidgetOptionalArray.length,
                    tips_BG: WIDGET_TIPS_PATH,
                    tips_x: 0,
                    tips_y: -38,
                    tips_width: WIDGET_TIPS_WIDTH,
                    tips_margin: 10,
                    select_list: edit_list_config,
                });
                let editTypeRB = rightWidget2.getProperty(hmUI.prop.CURRENT_TYPE);
                this.drawWidget(WIDGET_RIGHT_2, editTypeRB);


                function fn(type) {
                    const groupJump = {};
                    switch (type) {
                        case hmUI.edit_type.HEART:
                            groupJump.type = hmUI.data_type.HEART;
                            break;
                        case hmUI.edit_type.STEP:
                            groupJump.type = hmUI.data_type.STEP;
                            break;
                        case hmUI.edit_type.UVI:
                            groupJump.type = hmUI.data_type.UVI;
                            break;
                        case hmUI.edit_type.WEATHER:
                            groupJump.type = hmUI.data_type.WEATHER;
                            break;
                        case hmUI.edit_type.HUMIDITY:
                            groupJump.type = hmUI.data_type.HUMIDITY;
                            break;
                        case hmUI.edit_type.PAI_WEEKLY:
                            groupJump.type = hmUI.data_type.PAI_WEEKLY;
                            break;
                        case hmUI.edit_type.BATTERY:
                            groupJump.type = hmUI.data_type.BATTERY;
                            break;
                        case hmUI.edit_type.CAL:
                            groupJump.type = hmUI.data_type.CAL;
                            break;
                    }
                    return groupJump.type;
                }

                //   //-----------------跳转应用执行----------------

                //------------------------------------------------------------------------------- 
                // 息屏状态
                var point_prop = {
                    hour_zero: 1, //是否补零
                    hour_startX: rem(160.46),
                    hour_startY: rem(198.46),
                    hour_array: arrTime,
                    hour_space: 0, //每个数组间的间隔
                    //单位
                    hour_unit_sc: ROOTPATH + "fast/time/10.png",
                    hour_unit_tc: ROOTPATH + "fast/time/10.png",
                    hour_unit_en: ROOTPATH + "fast/time/10.png",
                    hour_align: hmUI.align.LEFT,

                    minute_zero: 1, //是否补零
                    minute_startX: rem(330.31),
                    minute_startY: rem(198.46),
                    minute_array: arrTime,
                    minute_space: 0, //每个数组间的间隔
                    //单位 
                    minute_align: hmUI.align.LEFT,

                    am_x: rem(269.46),
                    am_y: rem(160),
                    am_sc_path: ROOTPATH + "fast/AM/AM.png",
                    am_en_path: ROOTPATH + "fast/AM/AM.png",

                    pm_x: rem(269.46),
                    pm_y: rem(160),
                    pm_sc_path: ROOTPATH + "fast/AM/PM.png",
                    pm_en_path: ROOTPATH + "fast/AM/PM.png",

                    //pm同上 前缀由am改为pm
                };

                let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, point_prop);

                function jumpApp(x, y, w, h, type) {
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x:rem(x),
                        y:rem(y),
                        w:rem(w),
                        h:rem(h),
                        type //type必写 跳转的action
                    });
                }
                if (fn(editTypeBottom)) {
                    jumpApp(233, 0, 84, 44, fn(editTypeBottom));
                    jumpApp(233, 422, 84, 44, fn(editTypeBottom));
                }
                if (fn(editTypeCenter)) {
                    jumpApp(233, 377, 84, 30, fn(editTypeCenter));
                    jumpApp(233, 61, 84, 30, fn(editTypeCenter));
                }
                if (fn(editTypeTop)) {
                    jumpApp(233, 317, 84, 44, fn(editTypeTop));
                    jumpApp(233, 106, 84, 44, fn(editTypeTop));
                }

                if (fn(editTypeRT)) {
                    jumpApp(333, 91, 60, 80, fn(editTypeRT));
                }
                if (fn(editTypeRB)) {
                    jumpApp(333, 308, 60, 80, fn(editTypeRB));
                }

                let mask70 = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    // w: 466,
                    // h: 466,
                    src: ROOTPATH + "100.png",
                    show_level: hmUI.show_level.ONLY_EDIT,
                });
                let mask100 = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    // w: 466,
                    // h: 466,
                    src: ROOTPATH + "70.png",
                    show_level: hmUI.show_level.ONLY_EDIT,
                });
            },

            onInit() {
                console.log('index page.js on init invoke');
                this.init_view();
            },

            onReady() {
                console.log('index page.js on ready invoke');
            },

            onShow() {
                console.log('index page.js on show invoke');
            },

            onHide() {
                console.log('index page.js on hide invoke');
            },

            onDestory() {
                console.log('index page.js on destory invoke');
            },
        });
        /*
         * end js
         */
    })();
} catch (e) {
    console.log(e);
}