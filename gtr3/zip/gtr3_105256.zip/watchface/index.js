try {
    (() => {
    
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
  
    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');
  
      /*
    * hugray_small_numiOS bundle tool v1.0.17
    * Copyright © Hugray_small_numi. All Rights Reserved
    */
    'use strict';
  
    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let rootPath = null
 
    let animType = null
    let animDuration = null
    let timeArray = null
    let timeArray_xp =null 
    let dataArray = null
    let bg = null
    let stepArray = null
    let weekArr=null 
    let monthImg = null
    let batArray = null
    let animateMoon = null 
    let moon_timer = null
    const logger = DeviceRuntimeCore.HmLogger.getLogger("default2");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({

     

        init_view() {
           
            rootPath = "images/",
            animType = "easein";
            animDuration = 1200;
            timeArray = [
                rootPath +  "time/time_font_0.png",
                rootPath +  "time/time_font_1.png",
                rootPath +  "time/time_font_2.png",
                rootPath +  "time/time_font_3.png",
                rootPath +  "time/time_font_4.png",
                rootPath +  "time/time_font_5.png",
                rootPath +  "time/time_font_6.png",
                rootPath +  "time/time_font_7.png",
                rootPath +  "time/time_font_8.png",
                rootPath +  "time/time_font_9.png",
            ]
            dateArray = [
                rootPath + "date/date_font_00.png",
                rootPath + "date/date_font_01.png",
                rootPath + "date/date_font_02.png",
                rootPath + "date/date_font_03.png",
                rootPath + "date/date_font_04.png",
                rootPath + "date/date_font_05.png",
                rootPath + "date/date_font_06.png",
                rootPath + "date/date_font_07.png",
                rootPath + "date/date_font_08.png",
                rootPath + "date/date_font_09.png",
            ]
            stepArray = [
                rootPath + "step/steps_font_0.png",
                rootPath + "step/steps_font_1.png",
                rootPath + "step/steps_font_2.png",
                rootPath + "step/steps_font_3.png",
                rootPath + "step/steps_font_4.png",
                rootPath + "step/steps_font_5.png",
                rootPath + "step/steps_font_6.png",
                rootPath + "step/steps_font_7.png",
                rootPath + "step/steps_font_8.png",
                rootPath + "step/steps_font_9.png",

            ]
            batArray = [
                rootPath + "bat_progress/01.png",
                rootPath + "bat_progress/02.png",
                rootPath + "bat_progress/03.png",
                rootPath + "bat_progress/04.png",
                rootPath + "bat_progress/05.png",
                rootPath + "bat_progress/06.png",
                rootPath + "bat_progress/07.png",
                rootPath + "bat_progress/08.png",
                rootPath + "bat_progress/09.png",
                rootPath + "bat_progress/10.png",
            ]

            var screenType = hmSetting.getScreenType();
                if(screenType == hmSetting.screen_type.AOD){
                    bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
                        x: 0,
                        y: 0,
                        w: 454,
                        h: 454,
                        color: 0x000000,
                    });
                    timer.stopTimer(moon_timer);
                }else{
                    bg = hmUI.createWidget(hmUI.widget.IMG,{
                        x: 0,
                        y: 0,
                        w: 454,
                        h: 454,
                        src:  rootPath + "img/bg.png",
                    });
                    showDate();
                   
                }   
                let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 57,
                    hour_startY: 150,
                    hour_array: timeArray,
                    hour_space: 0,
                    // hour_unit_sc: rootPath +"img/colon.png", //单位
                    // hour_unit_tc: rootPath+"img/colon.png",
                    // hour_unit_en: rootPath+"img/colon.png",
                    hour_align: hmUI.align.LEFT,

                    minute_zero: 1, //是否补零 1为补零
                    minute_startX: 57,
                    minute_startY: 233,
                    minute_array: timeArray,
                    minute_space: 0, //两个图片间隔 对应GT2的interval
                    minute_follow: 0, //是否跟随
                    minute_align: hmUI.align.LEFT,
                    show_level: hmUI.show_level.ALL,
                    });

                    monthImg = hmUI.createWidget(hmUI.widget.IMG_DATE,{
                        month_startX: 57,
                        month_startY: 111 ,
                        month_unit_sc: rootPath + "img/line.png",
                        month_unit_tc: rootPath + "img/line.png",
                        month_unit_en: rootPath + "img/line.png",
                        month_align: hmUI.align.LEFT,
                        month_space: 0,
                        month_zero: 1,
                        month_follow: 0,
                        month_is_character: false, 
                        month_en_array: dateArray,
                        month_sc_array: dateArray,
                        month_tc_array: dateArray,

                        day_align: hmUI.align.LEFT,
                        day_space: 0,
                        day_zero: 1,
                        day_follow: 1,
                        day_en_array: dateArray,
                        day_sc_array: dateArray,
                        day_tc_array: dateArray,
                       day_is_character: false, 
                       show_level: hmUI.show_level.ALL,
                    });

                    function showDate()
                    { 
                        let batTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                            x: 224,
                            y: 22,
                            type:hmUI.data_type.BATTERY,
                            font_array:  dateArray ,
                            h_space: 0, //图片间隔
                            align_h:hmUI.align.LEFT,
                            unit_sc: rootPath +"img/per.png", //单位
                            unit_tc: rootPath +"img/per.png", //单位
                            unit_en: rootPath +"img/per.png", //单位
                            
                            padding:false, //是否补零 true为补零
                            show_level: hmUI.show_level.ONLY_NORMAL,
                            });  
                        let batLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                            x: 186,
                            y: 24,
                            image_array: batArray,
                            image_length: batArray.length,
                            type:hmUI.data_type.BATTERY,
                            show_level: hmUI.show_level.ONLY_NORMAL,
                        });
                        let stepIcon = hmUI.createWidget(hmUI.widget.IMG,{
                            x: 166,
                            y: 400,
                            w: 27,
                            h: 31,
                            src:  rootPath + "img/steps.png",
                        });
                        let stepTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                            x: 197,
                            y: 403,
                            type: hmUI.data_type.STEP,
                            font_array:  stepArray ,
                            h_space: 0, //图片间隔
                            align_h:hmUI.align.LEFT,
                            padding:false, //是否补零 true为补零
                            });  
                        animateMoon = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                            x: 0,
                            y: 0,
                            anim_path: rootPath + "moonMotion",
                            anim_prefix: "moon",
                            anim_ext: "png",
                            anim_fps: 25,
                            anim_size: 65,
                            anim_repeat: false,
                            repeat_count: 1,
                            anim_status: 1,
                            // anim_complete_call:animNext,
                        });   
                        moon_timer = timer.createTimer(5000, 5000, (function (option) {
                        //回调
                            animateMoon.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                        }));
            }

        },

        onInit() {
            console.log('index page.js on init invoke');

            this.init_view();
        },

        onReady() {
            console.log('index page.js on ready invoke')
        },

        onShow() {
            console.log('index page.js on show invoke')
        },

        onHide() {
            console.log('index page.js on hide invoke')
        },

        onDestory() {
            console.log('index page.js on destory invoke')
            timer.stopTimer(clock_timer);
            timer.stopTimer(moon_timer);
        },
    });
    /*
    * end js
    */
        })()
    } catch (e) {
        console.log(e)
    }
