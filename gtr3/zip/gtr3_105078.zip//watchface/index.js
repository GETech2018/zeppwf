
    /*
    ** huamiOS bundle tool v1.0.17
    * *huamiOS watchface js version v1.0.1
    * *Copyright © Huami. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start
        let normal$_$background$_$bg = ''
        let normal$_$date$_$img_date = ''
        let normal$_$week$_$week = ''
        let normal$_$analog_clock$_$time_pointer = ''
        let idle$_$date$_$img_date = ''
        let idle$_$week$_$week = ''
        let idle$_$analog_clock$_$time_pointer = ''
        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            normal$_$background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$date$_$img_date = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 152,
              month_startY: 44,
              month_sc_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              month_tc_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              month_en_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              month_unit_sc: '12.png',
              month_unit_tc: '12.png',
              month_unit_en: '12.png',
              month_align: hmUI.align.RIGHT,
              month_zero: 0,
              month_follow: 0,
              month_space: 0,
              month_is_character: false,
              day_startX: 190,
              day_startY: 44,
              day_sc_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              day_tc_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              day_en_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              day_align: hmUI.align.LEFT,
              day_zero: 1,
              day_follow: 0,
              day_space: 0,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$week$_$week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 225,
              y: 44,
              week_en: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
              week_tc: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
              week_sc: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$analog_clock$_$time_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 29,
              hour_posY: 227,
              hour_path: '20.png',
              hour_cover_path: '',
              hour_cover_x: 0,
              hour_cover_y: 0,
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 29,
              minute_posY: 227,
              minute_path: '21.png',
              minute_cover_path: '',
              minute_cover_x: 0,
              minute_cover_y: 0,
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 29,
              second_posY: 227,
              second_path: '23.png',
              second_cover_path: '22.png',
              second_cover_x: 208,
              second_cover_y: 208,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            idle$_$date$_$img_date = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 152,
              month_startY: 44,
              month_sc_array: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png"],
              month_tc_array: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png"],
              month_en_array: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png"],
              month_unit_sc: '34.png',
              month_unit_tc: '34.png',
              month_unit_en: '34.png',
              month_align: hmUI.align.RIGHT,
              month_zero: 0,
              month_follow: 0,
              month_space: 0,
              month_is_character: false,
              day_startX: 190,
              day_startY: 44,
              day_sc_array: ["35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png"],
              day_tc_array: ["35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png"],
              day_en_array: ["35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png"],
              day_align: hmUI.align.LEFT,
              day_zero: 1,
              day_follow: 0,
              day_space: 0,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });
  
                    
            idle$_$week$_$week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 225,
              y: 43,
              week_en: ["45.png","46.png","47.png","48.png","49.png","50.png","51.png"],
              week_tc: ["45.png","46.png","47.png","48.png","49.png","50.png","51.png"],
              week_sc: ["45.png","46.png","47.png","48.png","49.png","50.png","51.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });
  
                    
            idle$_$analog_clock$_$time_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 29,
              hour_posY: 227,
              hour_path: '52.png',
              hour_cover_path: '',
              hour_cover_x: 0,
              hour_cover_y: 0,
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 29,
              minute_posY: 227,
              minute_path: '54.png',
              minute_cover_path: '53.png',
              minute_cover_x: 208,
              minute_cover_y: 208,
              show_level: hmUI.show_level.ONAL_AOD,
            });
  
            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  