try {
    (() => {
    
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
  
    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');
  
      /*
    * huamiOS bundle tool v1.0.17
    * Copyright © Huami. All Rights Reserved
    */
    'use strict';
  
    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let rootPath = null
    let timeRootPath = null
    let animType = null
    let animDuration = null
    let timeArray = null
    let dateArray = null
    let bg = null
    let animCreate = null
    let animResident = null
    let minuteHigh = null
    let minuteLow = null
    let hourHigh = null
    let hourLow = null
    let ampm = null
    let stepIcon = null
    let stepText = null
    let hourDelay = null
    let minuteDelay = null
    let clock_timer = null
    let timeSensor = null
    let weekArr_en =null 
    let weekArr_sc =null 
    let weekArr_tc =null 

    const logger = DeviceRuntimeCore.HmLogger.getLogger("default2");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({

     

        init_view() {
           // timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            rootPath = "images/",
            timeRootPath = rootPath + "time/"
            animType = "easein";
            animDuration = 1200;
            timeArray = [
                rootPath +  "time/time_0.png",
                rootPath +  "time/time_1.png",
                rootPath +  "time/time_2.png",
                rootPath +  "time/time_3.png",
                rootPath +  "time/time_4.png",
                rootPath +  "time/time_5.png",
                rootPath +  "time/time_6.png",
                rootPath +  "time/time_7.png",
                rootPath +  "time/time_8.png",
                rootPath +  "time/time_9.png",
            ]
            dateArray = [
                rootPath + "date/date_number_0.png",
                rootPath + "date/date_number_1.png",
                rootPath + "date/date_number_2.png",
                rootPath + "date/date_number_3.png",
                rootPath + "date/date_number_4.png",
                rootPath + "date/date_number_5.png",
                rootPath + "date/date_number_6.png",
                rootPath + "date/date_number_7.png",
                rootPath + "date/date_number_8.png",
                rootPath + "date/date_number_9.png",
            ]
            weekArr_en = [
                rootPath + "week_en/week_en_1.png",
                rootPath + "week_en/week_en_2.png",
                rootPath + "week_en/week_en_3.png",
                rootPath + "week_en/week_en_4.png",
                rootPath + "week_en/week_en_5.png",
                rootPath + "week_en/week_en_6.png",
                rootPath + "week_en/week_en_7.png",
            ]
            weekArr_sc = [
                rootPath + "week_sc/week_sc_1.png",
                rootPath + "week_sc/week_sc_2.png",
                rootPath + "week_sc/week_sc_3.png",
                rootPath + "week_sc/week_sc_4.png",
                rootPath + "week_sc/week_sc_5.png",
                rootPath + "week_sc/week_sc_6.png",
                rootPath + "week_sc/week_sc_7.png",
            ]
            weekArr_tc = [
                rootPath + "week_tc/week_sc_1.png",
                rootPath + "week_tc/week_sc_2.png",
                rootPath + "week_tc/week_sc_3.png",
                rootPath + "week_tc/week_sc_4.png",
                rootPath + "week_tc/week_sc_5.png",
                rootPath + "week_tc/week_sc_6.png",
                rootPath + "week_tc/week_sc_7.png",
            ]

            var screenType = hmSetting.getScreenType();
                    if(screenType == hmSetting.screen_type.AOD){
          
                        bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
                            x: 0,
                            y: 0,
                            w: 454,
                            h: 454,
                            color: 0x000000,
                        });
                    
                    }else{
                        bg = hmUI.createWidget(hmUI.widget.IMG,{
                            x: 0,
                            y: 0,
                            w: 454,
                            h: 454,
                            src:  rootPath + "img/_0.png",
                        });
                        animCreate = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                            x: 0,
                            y: 0,
                            anim_path: rootPath + "bg_animte",
                            anim_prefix: "",
                            anim_ext: "png",
                            anim_fps: 25,
                            anim_size: 44,
                            anim_repeat: false,
                            repeat_count: 1,
                            anim_status: 1,
                            anim_complete_call:this._animNext,
                        });
                    }

                let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 103,
                    hour_startY: 257,
                    hour_array: timeArray,
                    hour_space: 0,
                    hour_unit_sc: rootPath+"img/colon.png", //单位
                    hour_unit_tc: rootPath+"img/colon.png",
                    hour_unit_en: rootPath+"img/colon.png",
                    hour_align: hmUI.align.LEFT,

                    minute_zero: 1, //是否补零 1为补零
                    minute_startX: 242,
                    minute_startY: 257,
                    minute_array: timeArray,
                    minute_space: 0, //两个图片间隔 对应GT2的interval
                    minute_follow: 1, //是否跟随
                    minute_align: hmUI.align.LEFT,
                     
                     
                    am_x: 188,
                    am_y: 66,
                    am_sc_path: rootPath+"img/am_cn.png",
                    am_en_path: rootPath+"img/am_en.png",
                    pm_x: 188,
                    pm_y: 66,
                    pm_sc_path: rootPath+"img/pm_cn.png",
                    pm_en_path: rootPath+"img/pm_en.png",
                    show_level: hmUI.show_level.ALL,
                    });

                    let week = hmUI.createWidget(hmUI.widget.IMG_WEEK,{
                        x: 124,
                        y: 371,
                        week_en: weekArr_en,
                        week_tc: weekArr_tc,
                        week_sc: weekArr_sc,
                        show_level: hmUI.show_level.ALL,
                    });

                    let status = hmUI.createWidget(hmUI.widget.IMG_DATE,{
                        month_startX: 210,
                        month_startY: 371 ,
                        month_unit_sc: rootPath + "img/point.png",
                        month_unit_tc: rootPath + "img/point.png",
                        month_unit_en: rootPath + "img/point.png",
                        month_align: hmUI.align.LEFT,
                        month_space: 0,
                        month_zero: 1,
                        month_follow: 0,
                        month_en_array: dateArray,
                        month_sc_array: dateArray,
                        month_tc_array: dateArray,
                        //month_is_character: true, //年份此字段无效  默认为true  为false时 传入的图片为月份12张 日31张
                        //月日同上 需要替换前缀为month/day

                        day_startX: 280,
                        day_startY: 371 ,
                        day_align: hmUI.align.LEFT,
                        day_space: 0,
                        day_zero: 1,
                        day_follow: 0,
                        day_en_array: dateArray,
                        day_sc_array: dateArray,
                        day_tc_array: dateArray,
                       // day_is_character: true, 
                        
                        show_level: hmUI.show_level.ALL,
                    });
                    
            
           
           
           
           

        },

        onInit() {
            console.log('index page.js on init invoke');

            this.init_view();
       
            


        },

        onReady() {
            console.log('index page.js on ready invoke')
        },

        onShow() {
            console.log('index page.js on show invoke')
        },

        onHide() {
            console.log('index page.js on hide invoke')
        },

        onDestory() {
            console.log('index page.js on destory invoke')
            timer.stopTimer(clock_timer);
        },
    });
    /*
    * end js
    */
        })()
    } catch (e) {
        console.log(e)
    }
