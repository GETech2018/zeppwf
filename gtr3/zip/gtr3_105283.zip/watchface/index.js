try {
  (() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__),
      "drink"
    );

    /*
     * huamiOS bundle tool v1.0.17
     * Copyright © Huami. All Rights Reserved
     */
    ("use strict");

    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    const ROOTPATH = "images/";

    const ROOTNUMBER = ROOTPATH + "sky/number/";
    const ROOTWEEK = ROOTPATH + "sky/week/";
    const time1Path = ROOTPATH + "sky/time1/";
    const time2Path = ROOTPATH + "sky/time2/";

    const weekArray = [
      ROOTWEEK + "2.png",
      ROOTWEEK + "3.png",
      ROOTWEEK + "4.png",
      ROOTWEEK + "5.png",
      ROOTWEEK + "6.png",
      ROOTWEEK + "7.png",
      ROOTWEEK + "1.png",
    ];
    const number_arr = [
      ROOTNUMBER + "steps_font_00.png",
      ROOTNUMBER + "steps_font_01.png",
      ROOTNUMBER + "steps_font_02.png",
      ROOTNUMBER + "steps_font_03.png",
      ROOTNUMBER + "steps_font_04.png",
      ROOTNUMBER + "steps_font_05.png",
      ROOTNUMBER + "steps_font_06.png",
      ROOTNUMBER + "steps_font_07.png",
      ROOTNUMBER + "steps_font_08.png",
      ROOTNUMBER + "steps_font_09.png",
    ];
    const time1_array = [
      time1Path + "0.png",
      time1Path + "1.png",
      time1Path + "2.png",
      time1Path + "3.png",
      time1Path + "4.png",
      time1Path + "5.png",
      time1Path + "6.png",
      time1Path + "7.png",
      time1Path + "8.png",
      time1Path + "9.png",
    ];
    const time2_array = [
      time2Path + "0.png",
      time2Path + "1.png",
      time2Path + "2.png",
      time2Path + "3.png",
      time2Path + "4.png",
      time2Path + "5.png",
      time2Path + "6.png",
      time2Path + "7.png",
      time2Path + "8.png",
      time2Path + "9.png",
    ];

    
    const logger = DeviceRuntimeCore.HmLogger.getLogger("sanjiao");
    __$$module$$__.module = DeviceRuntimeCore.Page({
     

      init_view() {
        let bg = hmUI.createWidget(hmUI.widget.IMG, {
          //背景图片
          x: 0,
          y: 0,
          w: 454,
          h: 454,
          src: ROOTPATH + "sky/bg/BG.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

     
        var animDemo = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
          y: 0,
          x: 0,

          // w: 192,
          // h: 150,
          align_h: hmUI.align.CENTER_H, // 横轴
          align_v: hmUI.align.CENTER_V, // 竖轴
          anim_path: ROOTPATH + "animsY", //文件路径   文件夹的名称
          anim_prefix: "Madrid", //相当于图片的前缀
          anim_ext: "png", //图片的后缀以或者图片的格式
          anim_fps: 8, //图片的播放速度
          anim_size: 122, //图片的数量
          anim_repeat: true, //开启循环播放         
          repeat_count: 0, //0位无限重复
          anim_status: 1, //  1  开启动画   0  //  关闭动画         
          // display_on_restart: false, //从息屏到亮屏是否自动重复播放
          // anim_complete_call: animCall, //动画结束回调 无限重复永远不会调用到
        });

        //======================================================
        let week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
          //   周数
          x: 40,
          y: 165,
          week_en: weekArray,
          week_tc: weekArray,
          week_sc: weekArray,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        let step = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          // 脚步
          x: 19,
          y: 234,
          W: 150,
          type: hmUI.data_type.STEP,
          font_array: number_arr,
          h_space: -6,
          //图片间隔
          align_h: hmUI.align.CENTER_H,

          padding: false, //不补零  //是否补零 true为补零

          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        let battery = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          //电量
          x: 139,
          y: 397,
          W: 100,
          type: hmUI.data_type.BATTERY,
          font_array: number_arr,
          h_space: -3,
          //图片间隔
          align_h: hmUI.align.CENTER_H,
          unit_sc: "images/sky/number/unit.png",
          // //单位
          unit_tc: "images/sky/number/unit.png",
          // //单位
          unit_en: "images/sky/number/unit.png",

          // invalid_image: "images/sky/number/none.png",
          // 无数据时显示的图片
          padding: false, //不补零  //是否补零 true为补零

          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        let heart = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 286,
          y: 322,
          W: 96,
          type: hmUI.data_type.HEART,
          font_array: number_arr,
          h_space: -5, //图片间隔

          align_h: hmUI.align.CENTER_H,
          padding: false, //不补零  //是否补零 true为补零

          invalid_image: "images/sky/number/none.png", // 无数据时显示的图片

          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          hour_zero: 1, //补零
          hour_startX: 91,
          hour_startY: 41,
          hour_array: time1_array,
          hour_space: 0, //每个字间的间隔
          minute_zero: 1, //补零
          minute_startX: 241,
          minute_startY: 41,
          minute_array: time1_array,
          minute_space: 0, //每个数字间的间隔
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        let maohao_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 219,
          y: 41,
          src: "images/sky/time1/maohao.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        let AOD_timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          hour_zero: 1, //补零
          hour_startX: 91,
          hour_startY: 41,
          hour_array: time2_array,
          hour_space: 0, //每个数字间的间隔
          minute_zero: 1, //补零
          minute_startX: 241,
          minute_startY: 41,
          minute_array: time2_array,
          minute_space: 0, //每个数字间的间隔
          show_level: hmUI.show_level.ONAL_AOD,
        });

        let AOD_maohao_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 219,
          y: 41,
          src: "images/sky/time2/maohao.png",
          show_level: hmUI.show_level.ONAL_AOD,
        });
      },

      onInit() {
        console.log("index page.js on init invoke");
        this.init_view();
      },

      onReady() {
        console.log("index page.js on ready invoke");
      },

      onShow() {
        console.log("index page.js on show invoke");
      },

      onHide() {
        console.log("index page.js on hide invoke");
      },

      onDestory() {
        console.log("index page.js on destory invoke");
      },
    });
    /*
     * end js
     */
  })();
} catch (e) {
  console.log(e);
}
