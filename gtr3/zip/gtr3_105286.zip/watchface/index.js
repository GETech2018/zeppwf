try {
  (() => {

    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

    /*
  * huamiOS bundle tool v1.0.17
  * Copyright © Huami. All Rights Reserved
  */
    'use strict';

    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let rootPath = null
    let am_pmPath = null
    let batteryPath = null
    let bgPath = null
    let heartPath = null
    let number_paiPath = null
    let number_sPath = null
    let timePath = null
    let weatherPath = null
    let weekPath = null

    let battery_array = null
    let heart_array = null
    let number_pai_array = null
    let number_s_array = null
    let time_array = null
    let weather_array = null
    let week_array = null
    const logger = DeviceRuntimeCore.HmLogger.getLogger("defult");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({


      init_view() {
        rootPath = "images/";
        am_pmPath = rootPath + "am_pm/"
        batteryPath = rootPath + "battery/"
        bgPath = rootPath + "bg/"
        heartPath = rootPath + "heart/"
        number_paiPath = rootPath + "number_pai/"
        number_sPath = rootPath + "number_s/"
        weatherPath = rootPath + "weather/"
        timePath = rootPath + "time/"
        weekPath = rootPath + "week/"

        bg_array = [
          bgPath + "0.png",
          bgPath + "1.png",
          bgPath + "2.png",
          bgPath + "3.png",
          bgPath + "4.png",
          bgPath + "5.png",
          bgPath + "6.png",
          bgPath + "7.png",
          bgPath + "8.png",
          bgPath + "9.png",
          bgPath + "10.png",
          bgPath + "11.png",
          bgPath + "12.png",
          bgPath + "13.png",
          bgPath + "14.png",
          bgPath + "15.png",
          bgPath + "16.png",
          bgPath + "17.png",
          bgPath + "18.png",
          bgPath + "19.png",
          bgPath + "20.png",
          bgPath + "21.png",
          bgPath + "22.png",
          bgPath + "23.png",
          bgPath + "24.png",
          bgPath + "25.png",
          bgPath + "26.png",
          bgPath + "27.png",
          bgPath + "28.png",
          bgPath + "29.png",
        ]

        battery_array = [
          batteryPath + "1.png",
          batteryPath + "2.png",
          batteryPath + "3.png",
          batteryPath + "4.png",
          batteryPath + "5.png",
          batteryPath + "6.png",
          batteryPath + "7.png",
          batteryPath + "8.png",
          batteryPath + "9.png",
          batteryPath + "10.png",
        ]

        heart_array = [
          heartPath + "1.png",
          heartPath + "2.png",
          heartPath + "3.png",
          heartPath + "4.png",
          heartPath + "5.png",
          heartPath + "6.png",
        ]

        number_pai_array = [
          number_paiPath + "0.png",
          number_paiPath + "1.png",
          number_paiPath + "2.png",
          number_paiPath + "3.png",
          number_paiPath + "4.png",
          number_paiPath + "5.png",
          number_paiPath + "6.png",
          number_paiPath + "7.png",
          number_paiPath + "8.png",
          number_paiPath + "9.png",
        ]

        number_s_array = [
          number_sPath + "0.png",
          number_sPath + "1.png",
          number_sPath + "2.png",
          number_sPath + "3.png",
          number_sPath + "4.png",
          number_sPath + "5.png",
          number_sPath + "6.png",
          number_sPath + "7.png",
          number_sPath + "8.png",
          number_sPath + "9.png",
        ]

        time_array = [
          timePath + "0.png",
          timePath + "1.png",
          timePath + "2.png",
          timePath + "3.png",
          timePath + "4.png",
          timePath + "5.png",
          timePath + "6.png",
          timePath + "7.png",
          timePath + "8.png",
          timePath + "9.png",
        ]
        weather_array = [
          weatherPath + "00.png",
          weatherPath + "01.png",
          weatherPath + "02.png",
          weatherPath + "03.png",
          weatherPath + "04.png",
          weatherPath + "05.png",
          weatherPath + "06.png",
          weatherPath + "07.png",
          weatherPath + "08.png",
          weatherPath + "09.png",
          weatherPath + "10.png",
          weatherPath + "11.png",
          weatherPath + "12.png",
          weatherPath + "13.png",
          weatherPath + "14.png",
          weatherPath + "15.png",
          weatherPath + "16.png",
          weatherPath + "17.png",
          weatherPath + "18.png",
          weatherPath + "19.png",
          weatherPath + "20.png",
          weatherPath + "21.png",
          weatherPath + "22.png",
          weatherPath + "23.png",
          weatherPath + "24.png",
          weatherPath + "25.png",
          weatherPath + "26.png",
          weatherPath + "27.png",
          weatherPath + "28.png",
        ]

        week_array = [
          weekPath + "1.png",
          weekPath + "2.png",
          weekPath + "3.png",
          weekPath + "4.png",
          weekPath + "5.png",
          weekPath + "6.png",
          weekPath + "7.png",
        ]

        var animDemo = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
          x: 0,
          y: 0,

          anim_path: rootPath + "bg", //必须从0开始 可以询问君成 张莉

          anim_prefix: "anim",

          anim_ext: "png",
          // anim_0 
          anim_fps: 25,

          anim_size: 29,

          repeat_count: 1, //0位无限重复
          anim_repeat: true,//是否重复
          anim_status: hmUI.anim_status.START,
          display_on_restart: false,//从息屏到亮屏是否自动重复播放
          // anim_complete_call:animCall,//动画结束回调 无限重复永远不会调用到

        });
        //设置动画状态
        animDemo.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.PAUSE)

        let stepText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 134,
          y: 83,
          type: hmUI.data_type.STEP,
          font_array: number_s_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NORMAL,
          // invalid_image: number_sPath + "null.png",
          // padding:true
        });

        let calText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 247,
          y: 83,
          type: hmUI.data_type.CAL,
          font_array: number_s_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NORMAL,
          // invalid_image: number_sPath + "null.png",
          // padding:true
        });
        let uviText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 30,
          y: 317,
          type: hmUI.data_type.UVI,
          font_array: number_s_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NORMAL,
          invalid_image: number_sPath + "null.png",
          // padding:true
        });
        let paiText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 215,
          y: 353,
          type: hmUI.data_type.PAI_DAILY,
          font_array: number_pai_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NORMAL,
          // invalid_image: number_sPath + "null.png",
          // padding:true
        });

        let heartText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 385,
          y: 135,
          W: 55,
          type: hmUI.data_type.HEART,
          font_array: number_s_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NORMAL,
          invalid_image: number_sPath + "null.png",
          // padding:true
        });

        let WEATHER_LOWText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 239,
          y: 276,
          type: hmUI.data_type.WEATHER_LOW,
          font_array: number_s_array,
          h_space: 0,
          unit_sc: number_sPath + "spl.png",
          unit_tc: number_sPath + "spl.png",
          unit_en: number_sPath + "spl.png",
          negative_image: number_sPath + "min.png",
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NORMAL,
          invalid_image: number_sPath + "null.png",
          // padding:true
        });

        let WEATHER_HIGHText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 286,
          y: 276,
          type: hmUI.data_type.WEATHER_HIGH,
          font_array: number_s_array,
          h_space: 0,
          unit_sc: number_sPath + "du.png",
          unit_tc: number_sPath + "du.png",
          unit_en: number_sPath + "du.png",
          negative_image: number_sPath + "min.png",
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NORMAL,
          invalid_image: number_sPath + "null.png",
          // padding:true
        });

        let weather_img = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 125,
          y: 334,
          image_array: weather_array,
          image_length: weather_array.length,
          type: hmUI.data_type.WEATHER,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        let battery_img = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 350,
          y: 320,
          image_array: battery_array,
          image_length: battery_array.length,
          type: hmUI.data_type.BATTERY,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        let heart_img = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 407,
          y: 176,
          image_array: heart_array,
          image_length: heart_array.length,
          type: hmUI.data_type.HEART,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          hour_zero: 1, //是否补零
          hour_startX: 77,
          hour_startY: 185,
          hour_array: time_array,
          hour_space: 0, //每个数组间的间隔
          hour_unit_sc: timePath + "col.png",
          hour_unit_tc: timePath + "col.png",
          hour_unit_en: timePath + "col.png",
          minute_zero: 1, //是否补零
          minute_startX: 236,
          minute_startY: 185,
          minute_array: time_array,
          minute_space: 0, //每个数组间的间隔
          // second_zero: 1, //是否补零
          // second_startX: 223,
          // second_startY: 232,
          // second_array: date_s_array,
          // second_space: 0, //每个数组间的间隔
          //单位
          hour_align: hmUI.align.LEFT,


          am_x: 286,
          am_y: 159,
          am_sc_path: am_pmPath + "am.png",
          am_en_path: am_pmPath + "am.png",
          pm_x: 286,
          pm_y: 159,
          pm_sc_path: am_pmPath + "pm.png",
          pm_en_path: am_pmPath + "pm.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let weekText = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
          x: 213,
          y: 159,
          week_en: week_array,
          week_tc: week_array,
          week_sc: week_array,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let dataText = hmUI.createWidget(hmUI.widget.IMG_DATE, {

          month_startX: 128,
          month_startY: 162,
          month_align: hmUI.align.LEFT,
          month_en_array: number_s_array,
          month_sc_array: number_s_array,
          month_tc_array: number_s_array,
          month_unit_sc: number_sPath + "dot.png", //单位
          month_unit_tc: number_sPath + "dot.png",
          month_unit_en: number_sPath + "dot.png",
          day_startX: 169,
          day_startY: 162,
          day_align: hmUI.align.LEFT,
          day_en_array: number_s_array,
          day_sc_array: number_s_array,
          day_tc_array: number_s_array,
          day_follow: 1,//是否跟随
          show_level: hmUI.show_level.ONLY_NORMAL,
          //月日同上 需要替换前缀为month/day
        });

        let AOD_timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          hour_zero: 1, //是否补零
          hour_startX: 77,
          hour_startY: 185,
          hour_array: time_array,
          hour_space: 0, //每个数组间的间隔
          hour_unit_sc: timePath + "col.png",
          hour_unit_tc: timePath + "col.png",
          hour_unit_en: timePath + "col.png",
          minute_zero: 1, //是否补零
          minute_startX: 236,
          minute_startY: 185,
          minute_array: time_array,
          minute_space: 0, //每个数组间的间隔
          // second_zero: 1, //是否补零
          // second_startX: 223,
          // second_startY: 232,
          // second_array: date_s_array,
          // second_space: 0, //每个数组间的间隔
          //单位
          hour_align: hmUI.align.LEFT,


          // am_x: 286,
          // am_y: 159,
          // am_sc_path: am_pmPath + "am.png",
          // am_en_path: am_pmPath + "am.png",
          // pm_x: 286,
          // pm_y: 159,
          // pm_sc_path: am_pmPath + "pm.png",
          // pm_en_path: am_pmPath + "pm.png",
          show_level: hmUI.show_level.ONLY_AOD,
        });
      },



      onInit() {
        console.log('index page.js on init invoke');

        this.init_view();


      },

      onReady() {
        console.log('index page.js on ready invoke')
      },

      onShow() {
        console.log('index page.js on show invoke')
      },

      onHide() {
        console.log('index page.js on hide invoke')
      },

      onDestory() {
        console.log('index page.js on destory invoke')
      },
    });
    /*
    * end js
    */
  })()
} catch (e) {
  console.log(e)
}