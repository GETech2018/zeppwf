try {
    (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;

        var __$$module$$__ = __$$app$$__.current;
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        /*
      * huamiOS bundle tool v1.0.17
      * Copyright © Huami. All Rights Reserved
      */
        'use strict';

        console.log("----->>>current");
        console.log(__$$hmAppManager$$__.currentApp.pid);
        console.log(__$$hmAppManager$$__.currentApp.current);

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

            init_view() {
                let rootPath = "images/";
                let screenType = hmSetting.getScreenType()
                let timeArr = []
                let interestArr = []
                let batteryArr = []
                let calArr = []
                for (let i = 0;i < 10;i++) {
                    if(i >= 1 && i <= 7) {
                        batteryArr.push(rootPath + "battery/" + i + ".png")
                        calArr.push(rootPath + "CAL/" + i + ".png")
                    }
                    timeArr.push(rootPath + "time/" + i + ".png")
                    interestArr.push(rootPath + "interest/" + i + ".png")
                }
                if (screenType == hmSetting.screen_type.AOD) {

                      //time
                     let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                        hour_zero: 1,
                        hour_startX: 100,
                        hour_startY: 24,
                        hour_array: interestArr,
                        hour_unit_sc: rootPath+"interest/maohao.png", 
                        hour_unit_tc: rootPath+"interest/maohao.png",
                        hour_unit_en: rootPath+"interest/maohao.png",
                        hour_space: 0,
                        hour_align: hmUI.align.LEFT,

                        minute_zero: 1,
                        minute_startX: 236,
                        minute_startY: 24,
                        minute_array: interestArr,
                        minute_space: 0,
                        minute_align: hmUI.align.LEFT,
                    });
                } else {
                    // animate
                    let animate = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                        x: 0,
                        y: 0,
                        anim_path: rootPath + "animate", //必须从0开始 可以询问君成 张莉
                        anim_prefix: "anim",
                        anim_ext: "png",
                        anim_fps: 25,
                        anim_size: 12,
                        repeat_count: 0, //0位无限重复
                        anim_repeat: true,//是否重复
                        anim_status: hmUI.anim_status.START,
                        display_on_restart: false,//从息屏到亮屏是否自动重复播放
                    });
                    //time
                     let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                        hour_zero: 1,
                        hour_startX: 100,
                        hour_startY: 24,
                        hour_array: timeArr,
                        hour_unit_sc: rootPath+"time/maohao.png", 
                        hour_unit_tc: rootPath+"time/maohao.png",
                        hour_unit_en: rootPath+"time/maohao.png",
                        hour_space: 0,
                        hour_align: hmUI.align.LEFT,

                        minute_zero: 1,
                        minute_startX: 236,
                        minute_startY: 24,
                        minute_array: timeArr,
                        minute_space: 0,
                        minute_align: hmUI.align.LEFT,
                    });
                    //battery level
                    let stepLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                        x: 10,
                        y: 80,
                        image_array: batteryArr,
                        image_length: batteryArr.length,
                        type: hmUI.data_type.BATTERY,
                    });
                    //cal level
                    let calLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                        x: 368,
                        y: 81,
                        image_array: calArr,
                        image_length: calArr.length,
                        type: hmUI.data_type.CAL,
                    });
                }

            },

            onInit() {
                console.log('index page.js on init invoke')

                this.init_view();
            },

            onReady() {
                console.log('index page.js on ready invoke')
            },

            onShow() {
                console.log('index page.js on show invoke')
            },

            onHide() {
                console.log('index page.js on hide invoke')
            },

            onDestory() {
                console.log('index page.js on destory invoke')
                timer.stopTimer(timerSupport)
            },
        });
        /*
        * end js
        */
    })()
} catch (e) {
    console.log(e)
}