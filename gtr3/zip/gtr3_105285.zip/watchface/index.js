try {
  (() => {

    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

    /*
  * huamiOS bundle tool v1.0.17
  * Copyright © Huami. All Rights Reserved
  */
    'use strict';

    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let rootPath = null
    let bgPath = null
    let iconPath = null
    let numberPath = null
    let time1Path = null
    let time2Path = null
    let icon_array = null
    let number_array = null
    let time1_array = null
    let time2_array = null
    const logger = DeviceRuntimeCore.HmLogger.getLogger("defult");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({


      init_view() {
        rootPath = "images/";
        bgPath = rootPath + "bg/"
        iconPath = rootPath + "icon/"
        numberPath = rootPath + "number/"
        time1Path = rootPath + "time01/"
        time2Path = rootPath + "time02/"

        icon_array = [
          iconPath + "1.png",
          iconPath + "2.png",
          iconPath + "3.png",
          iconPath + "4.png",
          iconPath + "5.png",
          iconPath + "6.png",
        ]

        number_array = [
          numberPath + "0.png",
          numberPath + "1.png",
          numberPath + "2.png",
          numberPath + "3.png",
          numberPath + "4.png",
          numberPath + "5.png",
          numberPath + "6.png",
          numberPath + "7.png",
          numberPath + "8.png",
          numberPath + "9.png",
        ]

        time1_array = [
          time1Path + "0.png",
          time1Path + "1.png",
          time1Path + "2.png",
          time1Path + "3.png",
          time1Path + "4.png",
          time1Path + "5.png",
          time1Path + "6.png",
          time1Path + "7.png",
          time1Path + "8.png",
          time1Path + "9.png",
        ]

        time2_array = [
          time2Path + "0.png",
          time2Path + "1.png",
          time2Path + "2.png",
          time2Path + "3.png",
          time2Path + "4.png",
          time2Path + "5.png",
          time2Path + "6.png",
          time2Path + "7.png",
          time2Path + "8.png",
          time2Path + "9.png",
        ]

        let bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 454,
          h: 454,
          src: bgPath + "bg.png",
          show_level: hmUI.show_level.ONLY_NORMAL
        })

        let animA = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
          x: 0,
          y: 0,

          anim_path: rootPath + "bg",

          anim_prefix: "a",

          anim_ext: "png",
          // anim_0 
          anim_fps: 25,

          anim_size: 23,

          repeat_count: 1, //0位无限重复
          anim_repeat: false,//是否重复
          anim_status: hmUI.anim_status.START,
          display_on_restart: false,//从息屏到亮屏是否自动重复播放
          // anim_complete_call:animCall,//动画结束回调 无限重复永远不会调用到

        });
        //设置动画状态
        // animA.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.PAUSE)
        function startTime() {
          let anim_time = timer.createTimer(3000, 10000, (
            function (option) {
              animA.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.START);
            }))
        }

        let batteryLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 63,
          y: 278,
          image_array: icon_array,
          image_length: icon_array.length,//长度
          type: hmUI.data_type.BATTERY,

          show_level: hmUI.show_level.ONLY_NORMAL
        });

        let batteryText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 85,
          y: 277,
          type: hmUI.data_type.BATTERY,
          font_array: number_array,
          h_space: 0,
          align_h: hmUI.align.LEFT,
          invalid_image: numberPath + "null.png",
          // padding: true,
          unit_sc: numberPath + "baifen.png",
          unit_tc: numberPath + "baifen.png",
          unit_en: numberPath + "baifen.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let heartText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 373,
          y: 192,
          type: hmUI.data_type.HEART,
          font_array: number_array,
          h_space: -3,
          align_h: hmUI.align.LEFT,
          invalid_image: numberPath + "null.png",
          // padding: true,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          hour_zero: 1, //是否补零
          hour_startX: 89,
          hour_startY: 50,
          hour_array: time1_array,
          hour_space: 0, //每个数组间的间隔
          minute_zero: 1, //是否补零
          minute_startX: 243,
          minute_startY: 50,
          minute_array: time1_array,
          minute_space: 0, //每个数组间的间隔
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        let AOD_timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          hour_zero: 1, //是否补零
          hour_startX: 89,
          hour_startY: 50,
          hour_array: time2_array,
          hour_space: 0, //每个数组间的间隔
          minute_zero: 1, //是否补零
          minute_startX: 243,
          minute_startY: 50,
          minute_array: time2_array,
          minute_space: 0, //每个数组间的间隔
          show_level: hmUI.show_level.ONAL_AOD
        });

        let maohao_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 219,
          y: 50,
          src: time1Path + "maohao.png",
          show_level: hmUI.show_level.ONLY_NORMAL
        })

        let AOD_maohao_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 219,
          y: 50,
          src: time2Path + "maohao.png",
          show_level: hmUI.show_level.ONAL_AOD
        })

        const vDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: (function () {
            startTime()
          }),
          pause_call: (function () {
            timer.stopTimer(anim_time)
            console.log('ui pause');
          }),

        });
      },

      onInit() {
        console.log('index page.js on init invoke');

        this.init_view();


      },

      onReady() {
        console.log('index page.js on ready invoke')
      },

      onShow() {
        console.log('index page.js on show invoke')
      },

      onHide() {
        console.log('index page.js on hide invoke')
      },

      onDestory() {
        console.log('index page.js on destory invoke')
      },
    });
    /*
    * end js
    */
  })()
} catch (e) {
  console.log(e)
}