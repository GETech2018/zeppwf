try {
  (() => {

    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

    /*
  * huamiOS bundle tool v1.0.17
  * Copyright © Huami. All Rights Reserved
  */
    'use strict';

    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let rootPath = null
    let am_pmPath = null
    let bgPath = null
    let batteryPath = null
    let dayPath = null
    let heartPath = null
    let weekPath = null
    let calPath = null
    let iconPath = null
    let numberPath = null
    let hourPath = null
    let hour_2Path = null
    let battery_progressPath = null
    let cal_progressPath = null

    let battery_progress_array = null
    let day_array = null
    let heart_array = null
    let cal_num_array = null
    let cal_progress_array = null
    let hour_array = null
    let hour2_array = null
    let week_array = null
    let number_array = null

    const logger = DeviceRuntimeCore.HmLogger.getLogger("defult");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({


      init_view() {
        rootPath = "images/";
        am_pmPath = rootPath + "am_pm/"
        bgPath = rootPath + "bg/"
        calPath = rootPath + "cal/"
        dayPath = rootPath + "day/"
        heartPath = rootPath + "heart/"
        hourPath = rootPath + "hour/"
        hour_2Path = rootPath + "hour_2/"
        iconPath = rootPath + "icon/"
        batteryPath = rootPath + "battery/"
        numberPath = rootPath + "number/"
        weekPath = rootPath + "week/"
        battery_progressPath = batteryPath + "progress/"
        cal_progressPath = calPath + "progress/"

        battery_progress_array = [
          battery_progressPath + "1.png",
          battery_progressPath + "2.png",
          battery_progressPath + "3.png",
          battery_progressPath + "4.png",
          battery_progressPath + "5.png",
          battery_progressPath + "6.png",
        ]

        day_array = [
          dayPath + "0.png",
          dayPath + "1.png",
          dayPath + "2.png",
          dayPath + "3.png",
          dayPath + "4.png",
          dayPath + "5.png",
          dayPath + "6.png",
          dayPath + "7.png",
          dayPath + "8.png",
          dayPath + "9.png",
        ]

        heart_array = [
          heartPath + "0.png",
          heartPath + "1.png",
          heartPath + "2.png",
          heartPath + "3.png",
          heartPath + "4.png",
          heartPath + "5.png",
          heartPath + "6.png",
          heartPath + "7.png",
          heartPath + "8.png",
          heartPath + "9.png",
        ]

        cal_num_array = [
          calPath + "0.png",
          calPath + "1.png",
          calPath + "2.png",
          calPath + "3.png",
          calPath + "4.png",
          calPath + "5.png",
          calPath + "6.png",
          calPath + "7.png",
          calPath + "8.png",
          calPath + "9.png",
        ]

        cal_progress_array = [
          cal_progressPath + "1.png",
          cal_progressPath + "2.png",
          cal_progressPath + "3.png",
          cal_progressPath + "4.png",
          cal_progressPath + "5.png",
          cal_progressPath + "6.png",
        ]

        hour_array = [
          hourPath + "0.png",
          hourPath + "1.png",
          hourPath + "2.png",
          hourPath + "3.png",
          hourPath + "4.png",
          hourPath + "5.png",
          hourPath + "6.png",
          hourPath + "7.png",
          hourPath + "8.png",
          hourPath + "9.png",
        ]
        hour2_array = [
          hour_2Path + "0.png",
          hour_2Path + "1.png",
          hour_2Path + "2.png",
          hour_2Path + "3.png",
          hour_2Path + "4.png",
          hour_2Path + "5.png",
          hour_2Path + "6.png",
          hour_2Path + "7.png",
          hour_2Path + "8.png",
          hour_2Path + "9.png",
        ]

        week_array = [
          weekPath + "1.png",
          weekPath + "2.png",
          weekPath + "3.png",
          weekPath + "4.png",
          weekPath + "5.png",
          weekPath + "6.png",
          weekPath + "7.png",
        ]

        number_array = [
          numberPath + "0.png",
          numberPath + "1.png",
          numberPath + "2.png",
          numberPath + "3.png",
          numberPath + "4.png",
          numberPath + "5.png",
          numberPath + "6.png",
          numberPath + "7.png",
          numberPath + "8.png",
          numberPath + "9.png",
        ]

        let bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 454,
          h: 454,
          src: bgPath + "bg.png",
          show_level: hmUI.show_level.ONLY_NORMAL
        })

        let disturbStatus = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
          x: 203,
          y: 103,
          type: hmUI.system_status.DISTURB,
          src: iconPath + "moon.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let lockStatus = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
          x: 266,
          y: 103,
          type: hmUI.system_status.LOCK,

          src: iconPath + "lock.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let disconnectStatus = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
          x: 235,
          y: 103,
          type: hmUI.system_status.DISCONNECT,
          src: iconPath + "relieve.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let clockStatus = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
          x: 169,
          y: 103,
          type: hmUI.system_status.CLOCK,
          src: iconPath + "clock.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let batteryLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 388,
          y: 240,
          image_array: battery_progress_array,
          image_length: battery_progress_array.length,//长度
          type: hmUI.data_type.BATTERY,
          show_level: hmUI.show_level.ONLY_NORMAL
        })

        let calLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 32,
          y: 239,
          image_array: cal_progress_array,
          image_length: cal_progress_array.length,//长度
          type: hmUI.data_type.CAL,
          show_level: hmUI.show_level.ONLY_NORMAL
        })

        let calText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 73,
          y: 299,
          type: hmUI.data_type.CAL,
          font_array: number_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NORMAL,
          invalid_image: numberPath + "null.png",
          // padding: true
        })

        let batteryText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 325,
          y: 299,
          type: hmUI.data_type.BATTERY,
          font_array: number_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NORMAL,
          invalid_image: numberPath + "null.png",
          unit_sc: numberPath + "baifen.png",
          //单位
          unit_tc: numberPath + "baifen.png",
          //单位
          unit_en: numberPath + "baifen.png",
          // padding: true
        });

        let heartText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 284,
          y: 52,
          type: hmUI.data_type.HEART,
          font_array: heart_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NORMAL,
          invalid_image: heartPath + "null.png",
          // padding: true
        });

        let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          hour_zero: 1, //是否补零
          hour_startX: 81,
          hour_startY: 133,
          hour_array: hour_array,
          hour_space: 0, //每个数组间的间隔

          minute_zero: 1, //是否补零
          minute_startX: 277,
          minute_startY: 133,
          minute_array: hour_array,
          minute_space: 0, //每个数组间的间隔

          am_x: 184,
          am_y: 138,
          am_sc_path: am_pmPath + "am.png",
          am_en_path: am_pmPath + "am.png",
          pm_x: 184,
          pm_y: 138,
          pm_sc_path: am_pmPath + "pm.png",
          pm_en_path: am_pmPath + "pm.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let weekText = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
          x: 195,
          y: 379,
          week_en: week_array,
          week_tc: week_array,
          week_sc: week_array,
          
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let dayText = hmUI.createWidget(hmUI.widget.IMG_DATE, {
          day_startX: 198,
          day_startY: 333,
          day_align: hmUI.align.LEFT,
          day_space: 0,//文字间隔
          day_zero: 1,//是否补零 
          day_en_array: day_array,
          day_sc_array: day_array,
          day_tc_array: day_array,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let AOD_timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          hour_zero: 1, //是否补零
          hour_startX: 81,
          hour_startY: 133,
          hour_array: hour2_array,
          hour_space: 0, //每个数组间的间隔

          minute_zero: 1, //是否补零
          minute_startX: 277,
          minute_startY: 133,
          minute_array: hour2_array,
          minute_space: 0, //每个数组间的间隔
          show_level: hmUI.show_level.ONAL_AOD,
        });

        let AOD_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 217,
          y: 131,
          src: numberPath + "maohao.png",
          show_level: hmUI.show_level.ONAL_AOD
        })
      },

      onInit() {
        console.log('index page.js on init invoke');

        this.init_view();


      },

      onReady() {
        console.log('index page.js on ready invoke')
      },

      onShow() {
        console.log('index page.js on show invoke')
      },

      onHide() {
        console.log('index page.js on hide invoke')
      },

      onDestory() {
        console.log('index page.js on destory invoke')
      },
    });
    /*
    * end js
    */
  })()
} catch (e) {
  console.log(e)
}