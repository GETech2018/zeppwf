try {
  ;(() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp

    var __$$module$$__ = __$$app$$__.current
    var h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__),
      'drink'
    )

    /*
     * huamiOS bundle tool v1.0.17
     * Copyright © Huami. All Rights Reserved
     */
    ;('use strict')

    console.log('----->>>current')
    console.log(__$$hmAppManager$$__.currentApp.pid)
    console.log(__$$hmAppManager$$__.currentApp.current)

    const WIDGET_TOP_ID = 102
    const WIDGET_BG_ID = 105
    const WIDGET_TOP = 1

    const ROOTPATH = 'images/'
    const ROOTMONTH = ROOTPATH + 'sky/month/'
    const ROOTNUMBER = ROOTPATH + 'sky/number/'
    const ROOTPOINT = ROOTPATH + 'sky/point/'
    const ROOTWEEK = ROOTPATH + 'sky/week/'    
    const widgetPreview = ROOTPATH + 'sky/widget_preview/'


    let numberArr = []
    for (let i = 0; i < 10; i++) {
      numberArr.push(ROOTNUMBER + i + '.png')
    }
    let monthArr = []
    for (let i = 1; i < 13; i++) {
      monthArr.push(ROOTMONTH + i + '.png')
    }
    let weekArr = []
    for (let i = 1; i < 8; i++) {
      weekArr.push(ROOTWEEK + i + '.png')
    }

    let select = null
    let topWidget = null

    const logger = DeviceRuntimeCore.HmLogger.getLogger('sanjiao')
    __$$module$$__.module = DeviceRuntimeCore.Page({
      parseWidgetConfig(editType) {
        let config = {
          bgPath: null, //背景图
          iconPath: null, //图标
          dataType: null, //数据类型
          nonePath: null, //无数据的图片
          unitEnPath: null, //单位
          unitScPath: null,
          unitTcPath: null,
          dwPath: null,
          textX: null,
        }
        switch (editType) {
          case hmUI.edit_type.HUMIDITY:
            config.bgPath = 'hum.png'
            config.dataType = hmUI.data_type.HUMIDITY
            config.dwPath = 'precent.png'
            config.textX = 133
            config.nonePath = true
            break
          case hmUI.edit_type.BATTERY:
            config.bgPath = 'bat.png'
            config.dataType = hmUI.data_type.BATTERY
            config.dwPath = 'precent.png'
            config.textX = 133
            break
          case hmUI.edit_type.STEP:
            config.bgPath = 'step.png'
            config.dataType = hmUI.data_type.STEP
            config.textX = 133
            break
          case hmUI.edit_type.CAL:
            config.bgPath = 'cal.png'
            config.dataType = hmUI.data_type.CAL
            config.textX = 133
            break
          case hmUI.edit_type.HEART:
            config.bgPath = 'heart.png'
            config.dataType = hmUI.data_type.HEART
            config.textX = 133
            config.nonePath = true
            break
          default:
            // console.log("invalid editType type=" + editType);
            return config
        }
        if (config.bgPath != null) {
          config.bgPath = ROOTPATH + 'sky/icon/' + config.bgPath
        }
        if (config.dwPath !== null) {
          config.dwPath = ROOTPATH + 'sky/symbol/' + config.dwPath
        }
        // config.nonePath =  ROOTPATH + 'sky/symbol/none.png'
        return config
      },
      drawWidget(widgetType, editType) {
        let bgX = 0
        let bgY = 0
        switch (widgetType) {
          case WIDGET_TOP:
            bgX = 205
            bgY = 300
            textY = bgY + 55
            break
          default:
            // console.log("invalid widgetType type=" + widgetType);
            return
        }
        const bgSize = 140
        const textWidth = 188
        const textHeight = 34

        const config = this.parseWidgetConfig(editType)
        hmUI.createWidget(hmUI.widget.IMG, {
          x: bgX - 12,
          y: bgY,
          w: bgSize,
          h: bgSize,
          src: config.bgPath,
          show_level: hmUI.show_level.ONLY_NORMAL,
        })

        let dataProp = {
          x: config.textX,
          y: textY,
          w: textWidth,
          h: textHeight,
          align_h: hmUI.align.CENTER_H,
          type: config.dataType,
          h_space: 0,
          font_array: numberArr,

          show_level: hmUI.show_level.ONLY_NORMAL,
        }
        if (config.nonePath) {
          // 无数据时显示的图片
          dataProp.invalid_image = ROOTPATH + 'sky/symbol/none.png'
        }
        if (config.dwPath != null) {
          //  单位
          dataProp.unit_en = config.dwPath
          dataProp.unit_sc = config.dwPath
          dataProp.unit_tc = config.dwPath
        }
        if (config.negativeImage != null) {
          //负号图片
          dataProp.negative_image = config.negativeImage
        }
        hmUI.createWidget(hmUI.widget.TEXT_IMG, dataProp)
      },
      init_view() {
        //edit bg
        select = ROOTPATH + 'sky/select/'
        editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
          edit_id: WIDGET_BG_ID,
          x: 0,
          y: 0,
          bg_config: [
            {
              id: 1,
              preview: ROOTPATH + 'sky/bg/1.png',
              path: ROOTPATH + 'sky/bg/bg1.png',
            },
            {
              id: 2,
              preview: ROOTPATH + 'sky/bg/2.png',
              path: ROOTPATH + 'sky/bg/bg2.png',
            },
            {
              id: 3,
              preview: ROOTPATH + 'sky/bg/3.png',
              path: ROOTPATH + 'sky/bg/bg3.png',
            },
          ],
          count: 3,
          default_id: 1,
          fg: ROOTPATH + 'sky/mask/mask2.png',
          tips_x: 178,
          tips_y: 400,
          tips_bg: ROOTPATH + 'sky/tip.png',
          tips_width: 98,
          tips_margin: 10,
        })

        // outLine bg
        let ruleNum = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 454,
          h: 454,
          src: ROOTPATH + 'sky/bg/ruleNum.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        })
       
        let jstime = hmSensor.createSensor(hmSensor.id.TIME)
        let day1 = hmUI.createWidget(hmUI.widget.IMG, { show_level: hmUI.show_level.ONLY_NORMAL,
        })
        let day2 = hmUI.createWidget(hmUI.widget.IMG, { show_level: hmUI.show_level.ONLY_NORMAL,
        })
        let month = hmUI.createWidget(hmUI.widget.IMG, { show_level: hmUI.show_level.ONLY_NORMAL,
        })
        function setDate() {
          let mon = jstime.month
          let d1 = parseInt(jstime.day / 10)
          let d2 = jstime.day % 10
          console.log(333333333333333333333, mon);
          console.log(444444444444444444444, d1);
          console.log(555555555555555555555, d2);
          src0 = monthArr[mon-1]
          src1 = numberArr[d1]
          src2 = numberArr[d2]
          let objDate = {}
          objDate.startY = 141
          switch (mon) {
            case 1:
              objDate.month_startX = 103
              objDate.day_startX = 280
              break
            case 10:
              objDate.month_startX = 102
              objDate.day_startX = 280
              break
            case 2:
              objDate.month_startX = 110
              objDate.day_startX = 287
              break
            case 11:
              objDate.month_startX = 114
              objDate.day_startX = 292
              break
            case 12:
              objDate.month_startX = 110
              objDate.day_startX = 288
              break
            case 5:
              objDate.month_startX = 66
              objDate.day_startX = 244
              break
            case 6:
              objDate.month_startX = 73
              objDate.day_startX = 250
              break
            case 7:
              objDate.month_startX = 73
              objDate.day_startX = 250
              break
            case 3:
              objDate.month_startX = 88
              objDate.day_startX = 265
              break
            case 4:
              objDate.month_startX = 78
              objDate.day_startX = 255
              break
            case 8:
              objDate.month_startX = 92
              objDate.day_startX = 270
              break
            case 9:
              objDate.month_startX = 114
              objDate.day_startX = 296
              break
          }
          month.setProperty(hmUI.prop.MORE, {
            x: objDate.month_startX,
            y: objDate.startY,
            src: src0,
          })
          day1.setProperty(hmUI.prop.MORE, {
            x: objDate.day_startX,
            y: objDate.startY,
            src: src1,
          })
          day2.setProperty(hmUI.prop.MORE, {
            x: objDate.day_startX + 20,
            y: objDate.startY,
            src: src2,
          })
        }
        // this.setDate()
        setDate()
        jstime.addEventListener(jstime.event.DAYCHANGE, function() {
          setDate()
          // this.setDate()
       });

       /* 滑屏幕事件 */
       let widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
        resume_call: function () {
          // this.getShow()
          // this.setDate()
          setDate()
        },
        pause_call: function () {
          console.log('ui pause')
        },
      })
        // week
        let weekImg = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
          x: 140,
          y: 100,
          week_en: weekArr,
          week_tc: weekArr,
          week_sc: weekArr,
          show_level: hmUI.show_level.ONLY_NORMAL,
        })

        //熄屏背景渲染
        let xpmask = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 454,
          h: 454,
          src: ROOTPATH + 'sky/bg/xpBg.png',
          show_level: hmUI.show_level.ONAL_AOD,
        })

        //==========================================================================
        //可编辑组件
        let widgetOptionalArray = [
          { type: hmUI.edit_type.STEP, preview: widgetPreview + 'step.png' },
          { type: hmUI.edit_type.CAL, preview: widgetPreview + 'cal.png' },
          { type: hmUI.edit_type.BATTERY, preview: widgetPreview + 'bat.png' },
          { type: hmUI.edit_type.HEART, preview: widgetPreview + 'heart.png' },
          { type: hmUI.edit_type.HUMIDITY, preview: widgetPreview + 'hum.png' },
        ]
        let groupX = 155
        let groupY = 258

        topWidget = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: WIDGET_TOP_ID,
          x: groupX,
          y: groupY,
          w: 140,
          h: 140,
          select_image: select + 'select.png',
          un_select_image: select + 'unselect.png',
          default_type: hmUI.edit_type.STEP,
          optional_types: widgetOptionalArray,
          count: widgetOptionalArray.length,
          tips_BG: ROOTPATH + 'sky/tip.png',
          tips_x: 18,
          tips_y: -40,
          tips_width: 98,
          tips_margin: 10,
        })
        var editType = topWidget.getProperty(hmUI.prop.CURRENT_TYPE)
        this.drawWidget(WIDGET_TOP, editType)

        // piont
        var pointObj = {
          hour_centerX: 227, //指针旋转中心 对应centerX
          hour_centerY: 227, //指针旋转中心 对应centerY
          hour_posX: 17, //指针自身旋转中心 对应positioin中的x
          hour_posY: 142, //指针自身旋转中心 对应positioin中的y
          hour_path: ROOTPOINT + 'h.png',
          //指针路径

          minute_centerX: 227, //指针旋转中心 对应centerX
          minute_centerY: 227, //指针旋转中心 对应centerY
          minute_posX: 16, //指针自身旋转中心 对应positioin中的x
          minute_posY: 209, //指针自身旋转中心 对应positioin中的y
          minute_path: ROOTPOINT + 'm.png',
          //指针路径
          minute_cover_path: ROOTPOINT + 'centerPng.png',
          //指针圆心图片
          minute_cover_y: 205,
          minute_cover_x: 205,
          //指针路径
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD,
        }
        var screenType = hmSetting.getScreenType()
        if (screenType !== hmSetting.screen_type.AOD) {
          var point_prop = Object.assign(pointObj, {
            second_centerX: 227, //指针旋转中心 对应centerX
            second_centerY: 227, //指针旋转中心 对应centerY
            second_posX: 2, //指针自身旋转中心 对应positioin中的x
            second_posY: 222, //指针自身旋转中心 对应positioin中的y
            second_path: ROOTPOINT + 's.png',
            //指针路径
            second_cover_path: ROOTPOINT + 'centerPng.png',
            //指针圆心图片
            second_cover_y: 205,
            second_cover_x: 205,
          })
        } else {
          var point_prop = pointObj
        }
        hmUI.createWidget(hmUI.widget.TIME_POINTER, point_prop)

        //==================================================================
        //mask 70
        let mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
          x: 0,
          y: 0,
          w: 454,
          h: 454,
          src: ROOTPATH + 'sky/mask/mask70.png',
          show_level: hmUI.show_level.ONLY_EDIT,
        })
      },

      onInit() {
        console.log('index page.js on init invoke')
        this.init_view()
      },
      onReady() {
        console.log('index page.js on ready invoke')
      },
      onShow() {
        console.log('index page.js on show invoke')
      },
      onHide() {
        console.log('index page.js on hide invoke')
      },
      onDestory() {
        timer.stopTimer(clockTimer)
        console.log('index page.js on destory invoke')
      },
    })
    /*
     * end js
     */
  })()
} catch (e) {
  console.log(e)
}
