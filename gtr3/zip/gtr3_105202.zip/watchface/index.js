try {
  (() => {

    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

    /*
  * huamiOS bundle tool v1.0.17
  * Copyright © Huami. All Rights Reserved
  */
    'use strict';

    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let rootPath = null
    let bgPath = null
    let functionPath = null
    let numberPath = null
    let pointerPath = null
    let week_ePath = null
    let week_sPath = null
    let fun_circualPath = null
    let fun_iconPath = null
    let fun_square1Path = null
    let fun_square2Path = null
    let fun_titlePath = null

    let num_array = null
    let week_e_array = null
    let week_s_array = null
    let square1_array = null
    let square2_array = null
    let fun_circual_array = null
    let fun_uvi_array = null 
    const logger = DeviceRuntimeCore.HmLogger.getLogger("defult");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      drawWidget(item, id) {
        config = {
          bgx: null,
          bgy: null,
          bgw: null,
          bgImg: null,
          iconX: null,
          iconY: null,
          iconImg: null,
          numX: null,
          numY: null,
          titleImg: null,
          level_array: null,
          type: null,
          src: null,
          num_array: null,
          h: 0,
          invalid: null
        }

        switch (id) {
          case 101:
            config.bgx = 53,
              config.bgy = 161,
              config.bgw = 132,
              config.numX = 91,
              config.numY = 224,
              config.titleX = 77,
              config.titleY = 189
            config.iconX = 107,
              config.iconY = 263
            break;
          case 103:
            config.bgx = 186,
              config.bgy = 287,
              config.bgw = 82,
              config.numX = 200,
              config.numY = 316,
              config.iconX = 215,
              config.iconY = 339
            break;
          default:
        }
        if (id == 101) {
          switch (item) {
            case hmUI.edit_type.STEP:
              config.level_array = square1_array;
              config.titleImg = fun_titlePath + "title1.png";
              config.iconImg = fun_iconPath + "icon1.png"
              config.num_array = num_array;
              config.type = hmUI.data_type.STEP;
              config.numX = config.numX - 19
              config.invalid = numberPath + "null.png"

              break;
            case hmUI.edit_type.CAL:
              config.level_array = square1_array;
              config.titleImg = fun_titlePath + "title2.png";
              config.iconImg = fun_iconPath + "icon2.png"
              config.num_array = num_array;
              config.type = hmUI.data_type.CAL;
              config.numX = config.numX - 10

              break;
            case hmUI.edit_type.BATTERY:
              config.level_array = square1_array;
              config.titleImg = fun_titlePath + "title6.png";
              config.iconImg = fun_iconPath + "icon6.png"
              config.num_array = num_array;
              config.type = hmUI.data_type.BATTERY;

              break;
            case hmUI.edit_type.STAND:
              config.level_array = square1_array;
              config.titleImg = fun_titlePath + "title5.png";
              config.iconImg = fun_iconPath + "icon5.png"
              config.num_array = num_array;
              config.type = hmUI.data_type.STAND;
              config.numX = config.numX - 10
              config.invalid = numberPath + "null.png"
              break;
            case hmUI.edit_type.PAI:
              config.level_array = square1_array;
              config.titleImg = fun_titlePath + "title4.png";
              config.iconImg = fun_iconPath + "icon4.png"
              config.num_array = num_array;
              config.type = hmUI.data_type.PAI_WEEKLY;
              break;
            // case hmUI.edit_type.AQI:
            //   config.level_array = square1_array;
            //   config.titleImg = fun_titlePath + "title3.png";
            //   config.iconImg = fun_iconPath + "icon3.png"
            //   config.num_array = num_array;
            //   config.type = hmUI.data_type.AQI;
            //   config.invalid = numberPath + "null.png"
            //   break;
            default:
              return config
              break;
          }
          let itemLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
            x: config.bgx,
            y: config.bgy,
            image_array: config.level_array,
            image_length: config.level_array.length,//长度
            type: config.type,
            show_level: hmUI.show_level.ONLY_NORMAL
          });
        } else {
          switch (item) {
            case hmUI.edit_type.CAL:
              config.iconImg = fun_iconPath + "icon2.png";
              // config.bgImg = fun_circualPath + "cal.png"
              config.bgImg = fun_circual_array
              config.num_array = num_array2;
              config.type = hmUI.data_type.CAL;
              // config.h = -3


              break;
            case hmUI.edit_type.BATTERY:
              config.bgImg = fun_circual_array
              config.iconImg = fun_iconPath + "icon6.png"
              config.num_array = num_array2;
              config.type = hmUI.data_type.BATTERY;
              config.numX = config.numX + 7

              break;
              break;
            case hmUI.edit_type.UVI:
              config.bgImg = fun_uvi_array
              config.iconImg = fun_iconPath + "icon7.png"
              config.num_array = num_array2;
              config.type = hmUI.data_type.UVI;
              config.numX = config.numX + 15;
              config.invalid = numberPath + "numberNull.png"

              break;
            // case hmUI.edit_type.AQI:
            //   config.bgImg = fun_circual_array
            //   config.iconImg = fun_iconPath + "icon3.png"
            //   config.num_array = num_array2;
            //   config.type = hmUI.data_type.AQI;
            //   config.invalid = numberPath + "numberNull.png"
            //   config.numX = config.numX + 7
            //   break;
            default:
              return config
          }
    let item_Level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
            x: config.bgx,
            y: config.bgy,
            image_array: config.bgImg,
            image_length: config.bgImg.length,//长度
            type: config.type,
            show_level: hmUI.show_level.ONLY_NORMAL
          });
        }

        console.log(config.numX + "1111111")
        // let item_bgImg = hmUI.createWidget(hmUI.widget.IMG, {
        //   x: config.bgx,
        //   y: config.bgy,
        //   src: config.bgImg,
        //   show_level: hmUI.show_level.ONLY_NORMAL
        // })

      

        let item_titleImg = hmUI.createWidget(hmUI.widget.IMG, {
          x: config.titleX,
          y: config.titleY,
          src: config.titleImg,
          show_level: hmUI.show_level.ONLY_NORMAL
        })

        let item_iconImg = hmUI.createWidget(hmUI.widget.IMG, {
          x: config.iconX,
          y: config.iconY,
          src: config.iconImg,
          show_level: hmUI.show_level.ONLY_NORMAL
        })



        let item_Text = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: config.numX,
          y: config.numY,
          type: config.type,
          font_array: config.num_array,
          h_space: config.h,
          align_h: hmUI.align.CENTER_H,
          invalid_image: config.invalid,
          show_level: hmUI.show_level.ONLY_NORMAL,
          // padding: true
        });

        
        
       
        


      },

      init_view() {
        rootPath = "images/";
        bgPath = rootPath + "bg/"
        functionPath = rootPath + "function/"
        numberPath = rootPath + "number/"
        pointerPath = rootPath + "pointer/"
        week_ePath = rootPath + "week_e/"
        week_sPath = rootPath + "week_s/"
        fun_circualPath = functionPath + "circular/"
        fun_iconPath = functionPath + "icon/"
        fun_square1Path = functionPath + "square1/"
        fun_square2Path = functionPath + "square2/"
        fun_titlePath = functionPath + "title/"

        num_array2 = [
          numberPath + "number0.png",
          numberPath + "number1.png",
          numberPath + "number2.png",
          numberPath + "number3.png",
          numberPath + "number4.png",
          numberPath + "number5.png",
          numberPath + "number6.png",
          numberPath + "number7.png",
          numberPath + "number8.png",
          numberPath + "number9.png",
        ]

        num_array = [
          numberPath + "0.png",
          numberPath + "1.png",
          numberPath + "2.png",
          numberPath + "3.png",
          numberPath + "4.png",
          numberPath + "5.png",
          numberPath + "6.png",
          numberPath + "7.png",
          numberPath + "8.png",
          numberPath + "9.png",
        ]

        week_e_array = [
          week_ePath + "1.png",
          week_ePath + "2.png",
          week_ePath + "3.png",
          week_ePath + "4.png",
          week_ePath + "5.png",
          week_ePath + "6.png",
          week_ePath + "7.png",
        ]

        week_s_array = [
          week_sPath + "1.png",
          week_sPath + "2.png",
          week_sPath + "3.png",
          week_sPath + "4.png",
          week_sPath + "5.png",
          week_sPath + "6.png",
          week_sPath + "7.png",
        ]

        square1_array = [
          fun_square1Path + "1.png",
          fun_square1Path + "2.png",
          fun_square1Path + "3.png",
          fun_square1Path + "4.png",
          fun_square1Path + "5.png",
          fun_square1Path + "6.png",
          fun_square1Path + "7.png",
          fun_square1Path + "8.png",
          fun_square1Path + "9.png",
          fun_square1Path + "10.png",
        ]

        square2_array = [
          fun_square2Path + "BPM1.png",
          fun_square2Path + "BPM2.png",
          fun_square2Path + "BPM3.png",
          fun_square2Path + "BPM4.png",
          fun_square2Path + "BPM5.png",
          fun_square2Path + "BPM6.png",
        ]

        fun_circual_array = [
          fun_circualPath + "1.png",
          fun_circualPath + "2.png",
          fun_circualPath + "3.png",
          fun_circualPath + "4.png",
          fun_circualPath + "5.png",
          fun_circualPath + "6.png",
          fun_circualPath + "7.png",
          fun_circualPath + "8.png",
          fun_circualPath + "9.png",
        ]
        fun_uvi_array= [
          functionPath + "uvi/01.png",
          functionPath + "uvi/02.png",
          functionPath + "uvi/03.png",
          functionPath + "uvi/04.png",
          functionPath + "uvi/05.png",
        ]
        let bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 454,
          h: 454,
          src: bgPath + "bg.png",
          show_level: hmUI.show_level.ONLY_NORMAL
        })

        let heartLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 268,
          y: 161,
          image_array: square2_array,
          image_length: square2_array.length,//长度
          type: hmUI.data_type.HEART,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        let heartText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 307,
          y: 224,
          type: hmUI.data_type.HEART,
          font_array: num_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NORMAL,
          invalid_image: numberPath + "null.png",
          // padding:true
        });

        let weekText = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
          x: 191,
          y: 114,
          week_en: week_e_array,
          week_tc: week_s_array,
          week_sc: week_s_array,
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD
        });



        let AOD_timePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_centerX: 227, //指针旋转中心 对应centerX
          hour_centerY: 227, //指针旋转中心 对应centerY
          hour_posX: 38, //指针自身旋转中心 对应positioin中的x
          hour_posY: 170, //指针自身旋转中心 对应positioin中的y
          hour_path: pointerPath + "h.png",
          minute_centerX: 227, //指针旋转中心 对应centerX
          minute_centerY: 227, //指针旋转中心 对应centerY
          minute_posX: 38, //指针自身旋转中心 对应positioin中的x
          minute_posY: 220, //指针自身旋转中心 对应positioin中的y
          minute_path: pointerPath + "m.png",
          show_level: hmUI.show_level.ONLY_AOD
        })
        // let bg_img1 = hmUI.createWidget(hmUI.widget.IMG, {
        //   x: 208,
        //   y: 208,
        //   src: pointerPath + "spot.png",
        //   show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD
        // })

        let widgetOptionalArray = [
          { type: hmUI.edit_type.STEP, preview: functionPath + "steps.png" },
          { type: hmUI.edit_type.CAL, preview: functionPath + "calorie.png" },
          { type: hmUI.edit_type.BATTERY, preview: functionPath + "BATTERY.png" },
          { type: hmUI.edit_type.STAND, preview: functionPath + "STAND.png" },
          { type: hmUI.edit_type.PAI, preview: functionPath + "pai.png" },
          // { type: hmUI.edit_type.AQI, preview: functionPath + "AQI.png" },
        ];

        let widgetOptionalArray2 = [
          { type: hmUI.edit_type.UVI, preview: functionPath + "uvi.png" },
          { type: hmUI.edit_type.CAL, preview: functionPath + "calorie_s.png" },
          { type: hmUI.edit_type.BATTERY, preview: functionPath + "BATTERY_s.png" },
          // { type: hmUI.edit_type.AQI, preview: functionPath + "AQI_s.png" },
        ]

        let groupX2 = 53;
        let groupY2 = 161
        let Group2 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 102,
          x: groupX2,
          y: groupY2,
          w: 132,
          h: 132,
          select_image: functionPath + "select.png",
          un_select_image: functionPath + "unchecked.png",
          default_type: hmUI.edit_type.STEP,
          optional_types: widgetOptionalArray,
          count: widgetOptionalArray.length,
          tips_BG: functionPath + "tag.png",
          tips_x: 16,
          tips_y: -38,
          tips_width: 104,
          tips_margin:10,
        });
        var item2 = Group2.getProperty(hmUI.prop.CURRENT_TYPE);
        this.drawWidget(item2, 101);


        let groupX3 = 186;
        let groupY3 = 287

        let Group3 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 103,
          x: groupX3,
          y: groupY3,
          w: 82,
          h: 82,
          select_image: functionPath + "select2.png",
          un_select_image: functionPath + "unselect2.png",
          default_type: hmUI.edit_type.UVI,
          optional_types: widgetOptionalArray2,
          count: widgetOptionalArray2.length,
          tips_BG: functionPath + "tag.png",
          tips_x: -11,
          tips_y: -38,
          tips_width: 104,
          tips_margin:10,
        });
        var item3 = Group3.getProperty(hmUI.prop.CURRENT_TYPE);
        this.drawWidget(item3, 103);

        let timePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_centerX: 227, //指针旋转中心 对应centerX
          hour_centerY: 227, //指针旋转中心 对应centerY
          hour_posX: 38, //指针自身旋转中心 对应positioin中的x
          hour_posY: 170, //指针自身旋转中心 对应positioin中的y
          hour_path: pointerPath + "h.png",
          minute_centerX: 227, //指针旋转中心 对应centerX
          minute_centerY: 227, //指针旋转中心 对应centerY
          minute_posX: 38, //指针自身旋转中心 对应positioin中的x
          minute_posY: 220, //指针自身旋转中心 对应positioin中的y
          minute_path: pointerPath + "m.png",
          second_centerX: 227, //指针旋转中心 对应centerX
          second_centerY: 227, //指针旋转中心 对应centerY
          second_posX: 23, //指针自身旋转中心 对应positioin中的x
          second_posY: 242, //指针自身旋转中心 对应positioin中的y
          second_path: pointerPath + "s.png",
          show_level: hmUI.show_level.ONLY_NORMAL
        })


        let maskCover = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK, {
          x: 0,
          y: 0,
          w: 454,
          h: 454,
          src: functionPath + "mask100.png",
          show_level: hmUI.show_level.ONLY_EDIT,
        });

        let mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
          x: 0,
          y: 0,
          w: 454,
          h: 454,
          src: functionPath + "mask70.png",
          show_level: hmUI.show_level.ONLY_EDIT,
        });
      },

      onInit() {
        console.log('index page.js on init invoke');

        this.init_view();


      },

      onReady() {
        console.log('index page.js on ready invoke')
      },

      onShow() {
        console.log('index page.js on show invoke')
      },

      onHide() {
        console.log('index page.js on hide invoke')
      },

      onDestory() {
        console.log('index page.js on destory invoke')
      },
    });
    /*
    * end js
    */
  })()
} catch (e) {
  console.log(e)
}