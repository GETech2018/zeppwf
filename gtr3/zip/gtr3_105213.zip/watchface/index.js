try {
    (() => {
    
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
  
    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');
  
      /*
    * huamiOS bundle tool v1.0.17
    * Copyright © Huami. All Rights Reserved
    */
    'use strict';
  
    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let rootPath = null
    let timeRootPath = null
    let animType = null
    let animDuration = null
    let timeArray = null
    let timeArray_xp = null
    let dateArray = null
    let bg = null
    let animateUp = null
    let animateDown = null
    let animResident = null
    let minuteHigh = null
    let minuteLow = null
    let hourHigh = null
    let hourLow = null
    let ampm = null
    let stepIcon = null
    let stepText = null
    let hourDelay = null
    let minuteDelay = null
    let clock_timer = null
    let timeSensor = null
    let weekArr_en =null 
    let weekArr_sc =null 
    let weekArr_tc =null 
    let animate_sec = null 
    let animate_quan =null
    let batArray = null
    let stepArray = null

    const logger = DeviceRuntimeCore.HmLogger.getLogger("default2");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({

     

        init_view() {
           // timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            rootPath = "images/",
           
            timeArray = [
                rootPath +  "time/0.png",
                rootPath +  "time/1.png",
                rootPath +  "time/2.png",
                rootPath +  "time/3.png",
                rootPath +  "time/4.png",
                rootPath +  "time/5.png",
                rootPath +  "time/6.png",
                rootPath +  "time/7.png",
                rootPath +  "time/8.png",
                rootPath +  "time/9.png",
            ]
            timeArray_xp = [
                rootPath +  "time_xp/0.png",
                rootPath +  "time_xp/1.png",
                rootPath +  "time_xp/2.png",
                rootPath +  "time_xp/3.png",
                rootPath +  "time_xp/4.png",
                rootPath +  "time_xp/5.png",
                rootPath +  "time_xp/6.png",
                rootPath +  "time_xp/7.png",
                rootPath +  "time_xp/8.png",
                rootPath +  "time_xp/9.png",
            ]
            dateArray = [
                rootPath + "date/0.png",
                rootPath + "date/1.png",
                rootPath + "date/2.png",
                rootPath + "date/3.png",
                rootPath + "date/4.png",
                rootPath + "date/5.png",
                rootPath + "date/6.png",
                rootPath + "date/7.png",
                rootPath + "date/8.png",
                rootPath + "date/9.png",
            ]
            weekArr_en = [
                rootPath + "week_en/1.png",
                rootPath + "week_en/2.png",
                rootPath + "week_en/3.png",
                rootPath + "week_en/4.png",
                rootPath + "week_en/5.png",
                rootPath + "week_en/6.png",
                rootPath + "week_en/7.png",
            ]
            weekArr_sc = [
                rootPath + "week_sc/1.png",
                rootPath + "week_sc/2.png",
                rootPath + "week_sc/3.png",
                rootPath + "week_sc/4.png",
                rootPath + "week_sc/5.png",
                rootPath + "week_sc/6.png",
                rootPath + "week_sc/7.png",
            ]
           
            batArray = [
                rootPath + "bat/1.png",
                rootPath + "bat/2.png",
                rootPath + "bat/3.png",
                rootPath + "bat/4.png",
                rootPath + "bat/5.png",
                rootPath + "bat/6.png",
            ]
            stepArray = [
                rootPath + "step/0.png",
                rootPath + "step/1.png",
                rootPath + "step/2.png",
                rootPath + "step/3.png",
                rootPath + "step/4.png",
                rootPath + "step/5.png",
            ]
            var screenType = hmSetting.getScreenType();
                    if(screenType == hmSetting.screen_type.AOD){
                        bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
                            x: 0,
                            y: 0,
                            w: 454,
                            h: 454,
                            color: 0x000000,
                        });
                        let timeText2 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                            hour_zero: 1,
                            hour_startX: 157,
                            hour_startY: 107,
                            hour_array: timeArray_xp,
                            hour_space: 0,
                       
                            hour_align: hmUI.align.LEFT,
        
                            minute_zero: 1, //是否补零 1为补零
                            minute_startX: 157,
                            minute_startY: 232,
                            minute_array: timeArray_xp,
                            minute_space: 0, //两个图片间隔 对应GT2的interval
                            minute_follow: 0, //是否跟随
                            minute_align: hmUI.align.LEFT,
                             
                             
                            am_x: 295,
                            am_y: 176,
                            am_sc_path: rootPath+"img/am_sc_xp.png",
                            am_en_path: rootPath+"img/am_en_xp.png",
                            pm_x: 295,
                            pm_y: 176,
                            pm_sc_path: rootPath+"img/pm_sc_xp.png",
                            pm_en_path: rootPath+"img/pm_en_xp.png",
                            show_level: hmUI.show_level.ONAL_AOD,
                            });
        
                    }else{
                        bg = hmUI.createWidget(hmUI.widget.IMG,{
                            x: 0,
                            y: 0,
                            w: 454,
                            h: 454,
                            src:  rootPath + "img/bg.png",
                        });
                        let up = hmUI.createWidget(hmUI.widget.IMG,{
                            x: 80,
                            y: 24,
                            w: 216,
                            h: 110,
                            src:  rootPath + "img/bat.png",
                        });
                        let down = hmUI.createWidget(hmUI.widget.IMG,{
                            x: 160,
                            y: 321,
                            w: 216,
                            h: 110,
                            src:  rootPath + "img/step.png",
                        });
                        let  bat = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                            x: 80,
                            y: 24,
                            w: 216,
                            h: 110,
                            image_array: batArray,
                            image_length: batArray.length,//长度
                            type:hmUI.data_type.BATTERY,
                        });
                        let step = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                            x: 160,
                            y: 321,
                            w: 216,
                            h: 110,
                            image_array: stepArray,
                            image_length: stepArray.length,//长度
                            type:hmUI.data_type.STEP,
                        });
                        animate_quan = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                            x: 0,
                            y: 0,
                            anim_path: rootPath + "quan",
                            anim_prefix: "quan",
                            anim_ext: "png",
                            anim_fps: 25,
                            anim_size: 27,
                            anim_repeat: false,
                            repeat_count: 1,
                            anim_status: 1,//
                            anim_complete_call:secAnimatePlay,
                        });
                        animate_sec = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                            x: 0,
                            y: 0,
                            anim_path: rootPath + "sec",
                            anim_prefix: "sec",
                            anim_ext: "png",
                            anim_fps: 11,
                            anim_size: 11,
                            anim_repeat: false,
                            repeat_count: 0,
                            anim_status: 1,
                        });
                   

                let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 157,
                    hour_startY: 107,
                    hour_array: timeArray,
                    hour_space: 0,
               
                    hour_align: hmUI.align.LEFT,

                    minute_zero: 1, //是否补零 1为补零
                    minute_startX: 157,
                    minute_startY: 232,
                    minute_array: timeArray,
                    minute_space: 0, //两个图片间隔 对应GT2的interval
                    minute_follow: 0, //是否跟随
                    minute_align: hmUI.align.LEFT,
                     
                     
                    am_x: 295,
                    am_y: 176,
                    am_sc_path: rootPath+"img/am_sc.png",
                    am_en_path: rootPath+"img/am_en.png",
                    pm_x: 295,
                    pm_y: 176,
                    pm_sc_path: rootPath+"img/pm_sc.png",
                    pm_en_path: rootPath+"img/pm_en.png",
                    show_level: hmUI.show_level.ALL,
                    });

                    let week = hmUI.createWidget(hmUI.widget.IMG_WEEK,{
                        x: 308,
                        y: 254,
                        week_en: weekArr_en,
                        week_tc: weekArr_sc,
                        week_sc: weekArr_sc,
                        show_level: hmUI.show_level.ONLY_NORMAL,

                    });

                    let status = hmUI.createWidget(hmUI.widget.IMG_DATE,{
                        month_startX: 315,
                        month_startY: 242,
                        month_unit_sc: rootPath + "img/mon.png",
                        month_unit_tc: rootPath + "img/mon.png",
                        month_unit_en: rootPath + "img/mon.png",
                        month_align: hmUI.align.LEFT,
                        month_space: -4,
                        month_zero: 1,
                        month_follow: 0,
                        month_en_array: dateArray,
                        month_sc_array: dateArray,
                        month_tc_array: dateArray,
                       // month_is_character: true, //年份此字段无效  默认为true  为false时 传入的图片为月份12张 日31张
                        //月日同上 需要替换前缀为month/day

                        day_startX: 380,
                        day_startY: 242,
                        day_align: hmUI.align.LEFT,
                        day_space: -4,
                        day_zero: 1,
                        day_follow: 0,
                        day_en_array: dateArray,
                        day_sc_array: dateArray,
                        day_tc_array: dateArray,
                        //day_is_character: true, 
                        
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                    
                }
           
           
                function secAnimatePlay()
                {  
                     animate_sec.setProperty(hmUI.prop.VISIBLE, true);
                     animate_sec.setProperty(hmUI.ANIM_STATUS,hmUI.anim_status.START);
                     console.log('sec play-----------------------555555555555555555---');
                }
                const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                 resume_call: (function () {
                   console.log('ui resume');
                   animate_quan.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                 }),
                 pause_call: (function () {
                   console.log('ui pause');
                   animate_quan.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                   animate_sec.setProperty(hmUI.prop.VISIBLE,false);
                 }),
     
               });

        },

        onInit() {
            console.log('index page.js on init invoke');

            this.init_view();
       
            


        },

        onReady() {
            console.log('index page.js on ready invoke')
        },

        onShow() {
            console.log('index page.js on show invoke')
        },

        onHide() {
            console.log('index page.js on hide invoke')
        },

        onDestory() {
            console.log('index page.js on destory invoke')
            timer.stopTimer(clock_timer);
        },
    });
    /*
    * end js
    */
        })()
    } catch (e) {
        console.log(e)
    }
