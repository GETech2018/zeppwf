try {
    (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;

        var __$$module$$__ = __$$app$$__.current;
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        /*
    * huamiOS bundle tool v1.0.17
    * Copyright © Huami. All Rights Reserved
    */
        'use strict';

        console.log("----->>>current")
        console.log(__$$hmAppManager$$__.currentApp.pid)
        console.log(__$$hmAppManager$$__.currentApp.current)
      
        const ROOTPATH = "images/";  

        const numberImgArr = [ 
            ROOTPATH + 'number/0.png',
            ROOTPATH + 'number/1.png',
            ROOTPATH + 'number/2.png',
            ROOTPATH + 'number/3.png',
            ROOTPATH + 'number/4.png',
            ROOTPATH + 'number/5.png',
            ROOTPATH + 'number/6.png',
            ROOTPATH + 'number/7.png',
            ROOTPATH + 'number/8.png',
            ROOTPATH + 'number/9.png',  
        ]
        const weekImgArr = [
            ROOTPATH + 'week/1.png',
            ROOTPATH + 'week/2.png',
            ROOTPATH + 'week/3.png',
            ROOTPATH + 'week/4.png',
            ROOTPATH + 'week/5.png',
            ROOTPATH + 'week/6.png',
            ROOTPATH + 'week/7.png', 
        ]
        const time1ImgArr = [
            ROOTPATH + 'time1/0.png',
            ROOTPATH + 'time1/1.png',
            ROOTPATH + 'time1/2.png',
            ROOTPATH + 'time1/3.png',
            ROOTPATH + 'time1/4.png',
            ROOTPATH + 'time1/5.png',
            ROOTPATH + 'time1/6.png',
            ROOTPATH + 'time1/7.png',
            ROOTPATH + 'time1/8.png',
            ROOTPATH + 'time1/9.png',  
        ]
        const time2ImgArr = [
            ROOTPATH + 'time2/0.png',
            ROOTPATH + 'time2/1.png',
            ROOTPATH + 'time2/2.png',
            ROOTPATH + 'time2/3.png',
            ROOTPATH + 'time2/4.png',
            ROOTPATH + 'time2/5.png',
            ROOTPATH + 'time2/6.png',
            ROOTPATH + 'time2/7.png',
            ROOTPATH + 'time2/8.png',
            ROOTPATH + 'time2/9.png',  
        ]
         const batLevelImgArr = [ 
            ROOTPATH + 'batLevel/1.png',
            ROOTPATH + 'batLevel/2.png',
            ROOTPATH + 'batLevel/3.png',
            ROOTPATH + 'batLevel/4.png',
            ROOTPATH + 'batLevel/5.png',
            ROOTPATH + 'batLevel/6.png',
            ROOTPATH + 'batLevel/7.png',
            ROOTPATH + 'batLevel/8.png',
            ROOTPATH + 'batLevel/9.png',  
            ROOTPATH + 'batLevel/10.png',
        ]
  
        const logger = DeviceRuntimeCore.HmLogger.getLogger("sanjiao");
        __$$module$$__.module = DeviceRuntimeCore.Page({ 
            init_view() {   
                let bg = hmUI.createWidget(hmUI.widget.IMG,{
                    x:0,
                    y:0,
                    w:454,
                    h:454,
                    src: ROOTPATH + "bg/bg.png",
                    show_level:hmUI.show_level.ONLY_NORMAL 
                }); 
               let weekImg = hmUI.createWidget(hmUI.widget.IMG_WEEK,{
                    x:201,
                    y:18,
                    week_en:weekImgArr,
                    week_tc:weekImgArr,
                    week_sc:weekImgArr,
                    show_level:hmUI.show_level.ONLY_NORMAL
                }); 
                //==========================================================================
                var timeTypeArr = null
                var timeFhPath = null
                var h_x = 0
                var h_y = 0
                var space = 0
                var screenType = hmSetting.getScreenType();
                if(screenType == hmSetting.screen_type.AOD){ 
                     timeTypeArr = time2ImgArr
                     timeFhPath = ROOTPATH+"time2/fh.png"
                     h_x = 106
                     h_y = 45
                     space = 6
                } else {
                    var timeTypeArr = time1ImgArr
                    var timeFhPath = ROOTPATH+"time1/fh.png"
                    h_x = 106
                    h_y = 45
                    space = 1
                }
                 let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, { 
                    hour_zero: 1,      //是否补零
                    hour_startX: h_x ,
                    hour_startY: h_y,
                    hour_array: timeTypeArr,
                    hour_space: space,  //每个数组间的间隔
                    //单位
                    hour_unit_sc: timeFhPath, 
                    hour_unit_tc: timeFhPath,
                    hour_unit_en: timeFhPath,

                    hour_align:hmUI.align.LEFT, 
                    minute_zero:1, //是否补零
                    minute_startX:243,
                    minute_startY:h_y,
                    minute_array: timeTypeArr,
                    minute_space:0,  //每个数组间的间隔 
                    minute_align:hmUI.align.LEFT,    
                });

                
                let heartText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x:60, 
                    y:175,
                    type:hmUI.data_type.HEART,
                    font_array: numberImgArr ,
                    h_space: -2, 
                    //图片间隔
                    align_h:hmUI.align.CENTER_H, 
                    invalid_image: ROOTPATH + "number/none.png",  
                    padding:false, 
                    //是否补零 true为补零 
                     show_level:hmUI.show_level.ONLY_NORMAL
                });
                let calText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x:53, 
                    y:270,
                    type:hmUI.data_type.CAL,
                    font_array: numberImgArr ,
                    h_space: -2, 
                    //图片间隔
                    align_h:hmUI.align.CENTER_H, 
                    invalid_image: ROOTPATH + "number/none.png",  
                    padding:false, 
                    show_level:hmUI.show_level.ONLY_NORMAL
                    //是否补零 true为补零 
                });
                let paiText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x:334, 
                    y:230,
                    type:hmUI.data_type.PAI_WEEKLY,
                    font_array: numberImgArr ,
                    h_space: -2, 
                    //图片间隔
                    align_h:hmUI.align.CENTER_H, 
                    invalid_image: ROOTPATH + "number/none.png",  
                    padding:false, 
                    //是否补零 true为补零 
                    show_level:hmUI.show_level.ONLY_NORMAL
                });
                let stepText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x:302, 
                    y:372,
                    type:hmUI.data_type.STEP,
                    font_array: numberImgArr ,
                    h_space: -2, 
                    //图片间隔
                    align_h:hmUI.align.CENTER_H, 
                    invalid_image: ROOTPATH + "number/none.png",  
                    padding:false, 
                    //是否补零 true为补零 
                    show_level:hmUI.show_level.ONLY_NORMAL
                });

 
                 let batLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 110.5,
                    y: 178,
                    w: 18,  
                    h: 88,
                    image_array: batLevelImgArr,
                    image_length: batLevelImgArr.length,//长度
                    type:hmUI.data_type.BATTERY,
                    show_level:hmUI.show_level.ONLY_NORMAL
                });
                
              
            },

            onInit() {
                console.log('index page.js on init invoke') 
                this.init_view();
            },

            onReady() {
                console.log('index page.js on ready invoke')
            },

            onShow() {
                console.log('index page.js on show invoke')
            },

            onHide() {
                console.log('index page.js on hide invoke')
            },

            onDestory() {
                console.log('index page.js on destory invoke')
            },
        });
        /*
        * end js
        */
    })()
} catch (e) {
    console.log(e)
}
