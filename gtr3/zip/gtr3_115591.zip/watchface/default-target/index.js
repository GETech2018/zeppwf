try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_c759ff720d64400789bc66a39d5dc62c = '';
        let timeSensor = '';
        const logger = Logger.getLogger('watchface6');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                    x: 0,
                    y: 0,
                    anim_path: '',
                    anim_prefix: 'first_anim_sswym',
                    anim_ext: 'png',
                    anim_fps: 31,
                    anim_size: 28,
                    display_on_restart: true,
                    repeat_count: 1,
                    anim_status: hmUI.anim_status.START,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 353,
                    y: 213,
                    type: hmUI.data_type.BATTERY,
                    font_array: [
                        '2.png',
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 415,
                    y: 209,
                    src: '12.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 185,
                    y: 24,
                    type: hmUI.data_type.STEP,
                    font_array: [
                        '2.png',
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '13.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 164,
                    y: 24,
                    src: '14.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 37,
                    y: 213,
                    type: hmUI.data_type.DISTANCE,
                    font_array: [
                        '2.png',
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    dot_image: '15.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 10,
                    y: 215,
                    src: '16.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 227,
                    hour_centerY: 227,
                    hour_posX: 10,
                    hour_posY: 146,
                    hour_path: '17.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 227,
                    minute_centerY: 227,
                    minute_posX: 15,
                    minute_posY: 210,
                    minute_path: '18.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    second_centerX: 227,
                    second_centerY: 227,
                    second_posX: 5,
                    second_posY: 232,
                    second_path: '19.png',
                    second_cover_x: 0,
                    second_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 136,
                    hour_startY: 300,
                    hour_array: [
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png'
                    ],
                    hour_space: 4,
                    hour_align: hmUI.align.RIGHT,
                    minute_zero: 1,
                    minute_startX: 250,
                    minute_startY: 300,
                    minute_array: [
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png'
                    ],
                    minute_space: 4,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_c759ff720d64400789bc66a39d5dc62c = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 177,
                    y: 362,
                    w: 100,
                    h: 40,
                    text: '[SEC]',
                    color: '0xFFbe0303',
                    text_size: 29,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 205,
                    y: 53,
                    type: hmUI.data_type.HEART,
                    font_array: [
                        '2.png',
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '30.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 164,
                    y: 58,
                    src: '31.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 227,
                    hour_centerY: 227,
                    hour_posX: 10,
                    hour_posY: 147,
                    hour_path: '32.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 227,
                    minute_centerY: 227,
                    minute_posX: 15,
                    minute_posY: 210,
                    minute_path: '33.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                if (!timeSensor) {
                    timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                }
                normal$_$text_c759ff720d64400789bc66a39d5dc62c.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.second }` });
                timer.createTimer(0, 1000, function (timeSensor2) {
                    normal$_$text_c759ff720d64400789bc66a39d5dc62c.setProperty(hmUI.prop.MORE, { text: `${ timeSensor2.second }` });
                }, timeSensor);
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        normal$_$text_c759ff720d64400789bc66a39d5dc62c.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.second }` });
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}