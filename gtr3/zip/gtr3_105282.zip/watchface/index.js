try {
    (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;

        var __$$module$$__ = __$$app$$__.current;
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        /*
    * huamiOS bundle tool v1.0.17
    * Copyright © Huami. All Rights Reserved
    */
        'use strict';

        console.log("----->>>current")
        console.log(__$$hmAppManager$$__.currentApp.pid)
        console.log(__$$hmAppManager$$__.currentApp.current)
  
        const ROOTPATH = "images/";  
        const pointPath = ROOTPATH + "colors/point/" 
        
        const logger = DeviceRuntimeCore.HmLogger.getLogger("sanjiao");
        __$$module$$__.module = DeviceRuntimeCore.Page({ 
            init_view() {   
                let editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
                    edit_id: 123,
                    x: 0,
                    y: 0,
                    bg_config: [
                        // { id: 1, preview: ROOTPATH + "colors/preview_bg/bg1.png", path: ROOTPATH + "colors/bg/bg1.png" },
                        // { id: 2, preview: ROOTPATH + "colors/preview_bg/bg2.png", path: ROOTPATH + "colors/bg/bg2.png" },
                        // { id: 3, preview: ROOTPATH + "colors/preview_bg/bg3.png", path: ROOTPATH + "colors/bg/bg3.png" },
                         { id: 1, preview: ROOTPATH + "colors/bg/bg1.png" , path: ROOTPATH + "colors/bg/bg1.png" },
                        { id: 2, preview: ROOTPATH + "colors/bg/bg2.png" , path: ROOTPATH + "colors/bg/bg2.png" },
                        { id: 3, preview: ROOTPATH + "colors/bg/bg3.png" , path: ROOTPATH + "colors/bg/bg3.png" }, 
                    ],
                    count: 3,
                    default_id: 1,
                    fg: ROOTPATH + "colors/mask/bgMask.png",
                    tips_x: 180,
                    tips_y: 413,
                    tips_bg: ROOTPATH + "colors/mask/tip.png", 
                });
               
             
                const centerXValue = 227;
                const centerYValue = 227;  
                const pointerConfig = [
                    {
                        id: 1,
                        hour: {
                            centerX: centerXValue,
                            centerY: centerYValue,
                            posX: 28,
                            posY: 165,
                            path: pointPath + "point1/h.png",
                        },
                        minute: {
                            centerX: centerXValue,
                            centerY: centerYValue,
                            posX: 16,
                            posY: 218,
                            path: pointPath + "point1/m.png",
                        },
                        second:{
                            centerX: centerXValue,
                            centerY: centerYValue,
                            posX: 6,
                            posY: 237,
                            path: pointPath + "point1/s.png",
                        },
                        preview:  pointPath + "1.png",
                    },
                    {
                        id: 2,
                        hour: {
                            centerX: centerXValue,
                            centerY: centerYValue,
                            posX: 14,
                            posY: 162,
                            path: pointPath + "point2/h.png",
                        },
                        minute: {
                            centerX: centerXValue,
                            centerY: centerYValue,
                            posX: 17,
                            posY: 216,
                            path: pointPath +  "point2/m.png",
                        },
                         second:{
                            centerX: centerXValue,
                            centerY: centerYValue,
                            posX: 6,
                            posY: 237,
                            path: pointPath +  "point2/s.png",
                        },
                        preview:  pointPath + "2.png",
                    },
                    {
                        id: 3,
                        hour: {
                            centerX: centerXValue,
                            centerY: centerYValue,
                            posX: 26,
                            posY: 158,
                            path: pointPath + "point3/h.png",
                        },
                        minute: {
                            centerX: centerXValue,
                            centerY: centerYValue,
                            posX: 18,
                            posY: 223,
                            path: pointPath + "point3/m.png",
                        }, 
                         second:{
                            centerX: centerXValue,
                            centerY: centerYValue,
                            posX: 10,
                            posY: 224,
                            path: pointPath + "point3/s.png",
                        },
                        preview:  pointPath + "3.png",
                    }, 
                ]; 
                let pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER,{
                    edit_id:120,
                    x: 0,
                    y: 0,
                    config:pointerConfig,
                    count: pointerConfig.length,
                    default_id: 1,
                    fg: ROOTPATH + "colors/mask/bgMask.png",
                    tips_x: 180,
                    tips_y: 410,
                    tips_bg: ROOTPATH + "colors/mask/tip.png", 
                });
                const screenType = hmSetting.getScreenType();
                const aodModel = screenType == hmSetting.screen_type.AOD;
                const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG,!aodModel);
                let pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp);  

                let mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
                    x: 0,
                    y: 0,
                    w: 454,
                    h: 454,
                    src: ROOTPATH + "colors/mask/bgMask.png",
                    show_level: hmUI.show_level.ONLY_EDIT,
                }); 
            },

            onInit() {
                console.log('index page.js on init invoke') 
                this.init_view();
            },

            onReady() {
                console.log('index page.js on ready invoke')
            },

            onShow() {
                console.log('index page.js on show invoke')
            },

            onHide() {
                console.log('index page.js on hide invoke')
            },

            onDestory() {
                console.log('index page.js on destory invoke')
            },
        });
        /*
        * end js
        */
    })()
} catch (e) {
    console.log(e)
}
