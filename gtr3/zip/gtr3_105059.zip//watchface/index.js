
    /*
    ** huamiOS bundle tool v1.0.17
    * *huamiOS watchface js version v1.0.1
    * *Copyright © Huami. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start
        let normal$_$background$_$bg = ''
        let normal$_$pai$_$pointer_progress$_$img_pointer = ''
        let normal$_$battery$_$pointer_progress$_$img_pointer = ''
        let normal$_$analog_clock$_$time_pointer = ''
        let idle$_$analog_clock$_$time_pointer = ''
        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            normal$_$background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$pai$_$pointer_progress$_$img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '2.png',
              center_x: 227,
              center_y: 132,
              x: 9,
              y: 68,
              type: hmUI.data_type.PAI_WEEKLY,
              start_angle: 0,
              end_angle: 360,
              cover_path: '',
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$battery$_$pointer_progress$_$img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '3.png',
              center_x: 227,
              center_y: 322,
              x: 9,
              y: 68,
              type: hmUI.data_type.BATTERY,
              start_angle: 0,
              end_angle: 360,
              cover_path: '',
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$analog_clock$_$time_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 15,
              hour_posY: 162,
              hour_path: '4.png',
              hour_cover_path: '',
              hour_cover_x: 0,
              hour_cover_y: 0,
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 14,
              minute_posY: 201,
              minute_path: '5.png',
              minute_cover_path: '',
              minute_cover_x: 0,
              minute_cover_y: 0,
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 14,
              second_posY: 216,
              second_path: '6.png',
              second_cover_path: '',
              second_cover_x: 0,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            idle$_$analog_clock$_$time_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 15,
              hour_posY: 161,
              hour_path: '7.png',
              hour_cover_path: '',
              hour_cover_x: 0,
              hour_cover_y: 0,
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 13,
              minute_posY: 201,
              minute_path: '8.png',
              minute_cover_path: '',
              minute_cover_x: 0,
              minute_cover_y: 0,
              show_level: hmUI.show_level.ONAL_AOD,
            });
  
            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  