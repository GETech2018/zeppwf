try {
    (() => {
    
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
  
    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');
  
      /*
    * hugray_small_numiOS bundle tool v1.0.17
    * Copyright © Hugray_small_numi. All Rights Reserved
    * 超越 80 
    */
    'use strict';
  
    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let rootPath = null
 
    let animType = null
    let animDuration = null
    let timeArray = null
    let timeArray_xp =null 
    let dataArray = null
    let bg = null
    let monthArr = null
    let weekArr=null 
    let monthImg = null
    let batArray = null
    let bgAnim = null 
    let bg_timer = null
    const logger = DeviceRuntimeCore.HmLogger.getLogger("default2");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({

     

        init_view() {
           
            rootPath = "images/",
            animType = "easein";
            animDuration = 1200;
            timeArray = [
                rootPath +  "time/0.png",
                rootPath +  "time/1.png",
                rootPath +  "time/2.png",
                rootPath +  "time/3.png",
                rootPath +  "time/4.png",
                rootPath +  "time/5.png",
                rootPath +  "time/6.png",
                rootPath +  "time/7.png",
                rootPath +  "time/8.png",
                rootPath +  "time/9.png",
            ]
            timeArray_xp = [
                rootPath +  "time_xp/0.png",
                rootPath +  "time_xp/1.png",
                rootPath +  "time_xp/2.png",
                rootPath +  "time_xp/3.png",
                rootPath +  "time_xp/4.png",
                rootPath +  "time_xp/5.png",
                rootPath +  "time_xp/6.png",
                rootPath +  "time_xp/7.png",
                rootPath +  "time_xp/8.png",
                rootPath +  "time_xp/9.png",
            ]
            dataArray = [
                rootPath + "data/0.png",
                rootPath + "data/1.png",
                rootPath + "data/2.png",
                rootPath + "data/3.png",
                rootPath + "data/4.png",
                rootPath + "data/5.png",
                rootPath + "data/6.png",
                rootPath + "data/7.png",
                rootPath + "data/8.png",
                rootPath + "data/9.png",
            ]
            monthArr = [
                rootPath + "month/0.png",
                rootPath + "month/1.png",
                rootPath + "month/2.png",
                rootPath + "month/3.png",
                rootPath + "month/4.png",
                rootPath + "month/5.png",
                rootPath + "month/6.png",
                rootPath + "month/7.png",
                rootPath + "month/8.png",
                rootPath + "month/9.png",
                rootPath + "month/10.png",
                rootPath + "month/11.png",

            ]
            weekArr = [
                rootPath + "week/1.png",
                rootPath + "week/2.png",
                rootPath + "week/3.png",
                rootPath + "week/4.png",
                rootPath + "week/5.png",
                rootPath + "week/6.png",
                rootPath + "week/7.png",
            ]
            batArray = [
                rootPath + "bat_progress/1.png",
                rootPath + "bat_progress/2.png",
                rootPath + "bat_progress/3.png",
                rootPath + "bat_progress/4.png",
                rootPath + "bat_progress/5.png",
                rootPath + "bat_progress/6.png",
                rootPath + "bat_progress/7.png",
            ]

            var screenType = hmSetting.getScreenType();
                if(screenType == hmSetting.screen_type.AOD){
                    bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
                        x: 0,
                        y: 0,
                        w: 454,
                        h: 454,
                        color: 0x000000,
                    });
                    let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                        hour_zero: 1,
                        hour_startX: 28,
                        hour_startY: 152,
                        hour_array: timeArray_xp,
                        hour_space: -9,
                        hour_unit_sc: rootPath+"img/colon_xp.png", //单位
                        hour_unit_tc: rootPath+"img/colon_xp.png",
                        hour_unit_en: rootPath+"img/colon_xp.png",
                        hour_align: hmUI.align.LEFT,
    
                        minute_zero: 1, //是否补零 1为补零
                        minute_startX: 254,
                        minute_startY: 152,
                        minute_array: timeArray_xp,
                        minute_space: -9, //两个图片间隔 对应GT2的interval
                        minute_follow: 0, //是否跟随
                        minute_align: hmUI.align.LEFT,
                        am_x: 365,
                        am_y: 108,
                        am_sc_path: rootPath+"img/am_xp.png",
                        am_en_path: rootPath+"img/am_xp.png",
                        pm_x: 365,
                        pm_y: 108,
                        pm_sc_path: rootPath+"img/pm_xp.png",
                        pm_en_path: rootPath+"img/pm_xp.png",
                        show_level: hmUI.show_level.AOD,
                        });
                
                }else{
                    bg = hmUI.createWidget(hmUI.widget.IMG,{
                        x: 0,
                        y: 0,
                        w: 454,
                        h: 454,
                        src:  rootPath + "img/bg.png",
                    });
                bgAnim = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                        x: 0,
                        y: 0,
                        anim_path: rootPath + "bg_animte",
                        anim_prefix: "bgAnimate",
                        anim_ext: "png",
                        anim_fps: 25,
                        anim_size: 7,
                        anim_repeat: false,
                        repeat_count: 1,
                        anim_status: 1,
                        //anim_complete_call:this._animNext,
                    });  
                    // bg_timer = timer.createTimer(3000, 3000, (function (option) {
                    //     //回调
                    //     bgAnim.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                    
                    // })); 
                let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 28,
                    hour_startY: 152,
                    hour_array: timeArray,
                    hour_space: -9,
                    hour_unit_sc: rootPath +"img/colon.png", //单位
                    hour_unit_tc: rootPath+"img/colon.png",
                    hour_unit_en: rootPath+"img/colon.png",
                    hour_align: hmUI.align.LEFT,

                    minute_zero: 1, //是否补零 1为补零
                    minute_startX: 254,
                    minute_startY: 152,
                    minute_array: timeArray,
                    minute_space: -9, //两个图片间隔 对应GT2的interval
                    minute_follow: 0, //是否跟随
                    minute_align: hmUI.align.LEFT,
                    am_x: 365,
                    am_y: 108,
                    am_sc_path: rootPath+"img/am.png",
                    am_en_path: rootPath+"img/am.png",
                    pm_x: 365,
                    pm_y: 108,
                    pm_sc_path: rootPath+"img/pm.png",
                    pm_en_path: rootPath+"img/pm.png",
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    });

    
                    let week = hmUI.createWidget(hmUI.widget.IMG_WEEK,{
                        x: 88,
                        y: 275,
                        week_en: weekArr,
                        week_tc: weekArr,
                        week_sc: weekArr,
                        });
                    monthImg = hmUI.createWidget(hmUI.widget.IMG_DATE,{
                        month_startX: 96,
                        month_startY: 69 ,
                        // month_unit_sc: rootPath + "img/dot.png",
                        // month_unit_tc: rootPath + "img/dot.png",
                        // month_unit_en: rootPath + "img/dot.png",
                        month_align: hmUI.align.LEFT,
                        month_space: 0,
                        month_zero: 1,
                        month_follow: 0,
                        month_is_character: true, 
                        month_en_array: monthArr,
                        month_sc_array: monthArr,
                        month_tc_array: monthArr,
                       show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                    let calicon = hmUI.createWidget(hmUI.widget.IMG,{
                        x: 181,
                        y: 30,
                        w: 29,
                        h: 34,
                        src:  rootPath + "img/cal.png",
                    });
                    let calTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 218,
                        y: 24,
                        type:hmUI.data_type.CAL,
                        font_array:  dataArray ,
                        h_space: 0, //图片间隔
                        align_h:hmUI.align.LEFT,
                        padding:false, //是否补零 true为补零
                        }); 
                        let baticon = hmUI.createWidget(hmUI.widget.IMG,{
                            x: 328,
                            y: 67,
                            w: 41,
                            h: 59,
                            src:  rootPath + "img/bat.png",
                        }); 
                    let batTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 223,
                        y: 74,
                        type:hmUI.data_type.BATTERY,
                        font_array:  dataArray ,
                        h_space: 0, //图片间隔
                        align_h:hmUI.align.LEFT,
                        unit_sc: rootPath +"data/per.png", //单位
                        unit_tc: rootPath +"data/per.png", //单位
                        unit_en: rootPath +"data/per.png", //单位
                        invalid_image: rootPath +"data/invalid.png",// 无数据时显示的图片
                        padding:false, //是否补零 true为补零
                        });  
                    let batLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                        x: 223,
                        y: 127,
                        w: 136, //宽高可省略
                        h: 13,
                        image_array: batArray,
                        image_length: batArray.length,
                        type:hmUI.data_type.BATTERY,
                    });
                    let stepicon = hmUI.createWidget(hmUI.widget.IMG,{
                        x: 167,
                        y: 378,
                        w: 36,
                        h: 40,
                        src:  rootPath + "img/step.png",
                    }); 
                    let stepTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 209,
                        y: 376,
                        type: hmUI.data_type.STEP,
                        font_array:  dataArray ,
                        h_space: 0, //图片间隔
                        align_h:hmUI.align.LEFT,
                        padding:false, //是否补零 true为补零
                    });  
                    let weekicon = hmUI.createWidget(hmUI.widget.IMG,{
                        x: 183,
                        y: 334,
                        w: 195,
                        h: 40,
                        src:  rootPath + "img/week1.png",
                    }); 
            }


            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                resume_call: (function () {
                   // console.log('ui resume');
                   bgAnim.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.START);
                }),
                pause_call: (function () {
                   // console.log('ui pause');
                }),

            });
        },

        onInit() {
            console.log('index page.js on init invoke');

            this.init_view();
        },

        onReady() {
            console.log('index page.js on ready invoke')
        },

        onShow() {
            console.log('index page.js on show invoke')
        },

        onHide() {
            console.log('index page.js on hide invoke')
        },

        onDestory() {
            console.log('index page.js on destory invoke')
            timer.stopTimer(clock_timer);
        },
    });
    /*
    * end js
    */
        })()
    } catch (e) {
        console.log(e)
    }
