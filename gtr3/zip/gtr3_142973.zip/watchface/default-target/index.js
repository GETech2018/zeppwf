try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$component_0$_$component = '';
        let normal$_$component_1$_$component = '';
        let normal$_$component_2$_$component = '';
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                    x: 0,
                    y: 0,
                    anim_path: '',
                    anim_prefix: 'first_anim_krhvq',
                    anim_ext: 'png',
                    anim_fps: 10,
                    anim_size: 4,
                    display_on_restart: false,
                    repeat_count: 0,
                    anim_status: hmUI.anim_status.START,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$component_0$_$component = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: 1,
                    x: 92,
                    y: 334,
                    w: 149,
                    h: 45,
                    select_image: '2.png',
                    un_select_image: '3.png',
                    default_type: hmUI.edit_type.HEART,
                    optional_types: [
                        {
                            'type': hmUI.edit_type.HEART,
                            'preview': '5.png'
                        },
                        {
                            'type': hmUI.edit_type.SPO2,
                            'preview': '6.png'
                        },
                        {
                            'type': hmUI.edit_type.STEP,
                            'preview': '7.png'
                        },
                        {
                            'type': hmUI.edit_type.BATTERY,
                            'preview': '8.png'
                        },
                        {
                            'type': hmUI.edit_type.CAL,
                            'preview': '9.png'
                        }
                    ],
                    count: 5,
                    tips_BG: '4.png',
                    tips_x: 0,
                    tips_y: -40,
                    tips_width: 149,
                    tips_margin: 0
                });
                editType = normal$_$component_0$_$component.getProperty(hmUI.prop.CURRENT_TYPE);
                switch (editType) {
                case hmUI.edit_type.STEP:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 130,
                        y: 340,
                        type: hmUI.data_type.STEP,
                        font_array: [
                            '10.png',
                            '11.png',
                            '12.png',
                            '13.png',
                            '14.png',
                            '15.png',
                            '16.png',
                            '17.png',
                            '18.png',
                            '19.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '20.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 105,
                        y: 340,
                        src: '21.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.BATTERY:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 135,
                        y: 340,
                        type: hmUI.data_type.BATTERY,
                        font_array: [
                            '10.png',
                            '11.png',
                            '12.png',
                            '13.png',
                            '14.png',
                            '15.png',
                            '16.png',
                            '17.png',
                            '18.png',
                            '19.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        unit_sc: '23.png',
                        unit_tc: '23.png',
                        unit_en: '23.png',
                        invalid_image: '22.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 102,
                        y: 340,
                        src: '24.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.HEART:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 155,
                        y: 340,
                        type: hmUI.data_type.HEART,
                        font_array: [
                            '10.png',
                            '11.png',
                            '12.png',
                            '13.png',
                            '14.png',
                            '15.png',
                            '16.png',
                            '17.png',
                            '18.png',
                            '19.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '25.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 115,
                        y: 340,
                        src: '26.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.CAL:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 135,
                        y: 340,
                        type: hmUI.data_type.CAL,
                        font_array: [
                            '10.png',
                            '11.png',
                            '12.png',
                            '13.png',
                            '14.png',
                            '15.png',
                            '16.png',
                            '17.png',
                            '18.png',
                            '19.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '27.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 105,
                        y: 340,
                        src: '28.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.PAI_DAILY:
                    break;
                case hmUI.edit_type.DISTANCE:
                    break;
                case hmUI.edit_type.AQI:
                    break;
                case hmUI.edit_type.HUMIDITY:
                    break;
                case hmUI.edit_type.ALTIMETER:
                    break;
                case hmUI.edit_type.STRESS:
                    break;
                case hmUI.edit_type.WIND:
                    break;
                case hmUI.edit_type.SPO2:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 130,
                        y: 340,
                        type: hmUI.data_type.SPO2,
                        font_array: [
                            '10.png',
                            '11.png',
                            '12.png',
                            '13.png',
                            '14.png',
                            '15.png',
                            '16.png',
                            '17.png',
                            '18.png',
                            '19.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        unit_sc: '30.png',
                        unit_tc: '30.png',
                        unit_en: '30.png',
                        invalid_image: '29.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 105,
                        y: 340,
                        src: '31.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.TRAINING_LOAD:
                    break;
                case hmUI.edit_type.VO2MAX:
                    break;
                case hmUI.edit_type.UVI:
                    break;
                case hmUI.edit_type.DATE:
                    break;
                case hmUI.edit_type.WEEK:
                    break;
                case hmUI.edit_type.WEATHER:
                    break;
                case hmUI.edit_type.TEMPERATURE:
                    break;
                case hmUI.edit_type.SUN:
                    break;
                }
                normal$_$component_1$_$component = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: 2,
                    x: 165,
                    y: 384,
                    w: 149,
                    h: 45,
                    select_image: '32.png',
                    un_select_image: '33.png',
                    default_type: hmUI.edit_type.STEP,
                    optional_types: [
                        {
                            'type': hmUI.edit_type.STEP,
                            'preview': '35.png'
                        },
                        {
                            'type': hmUI.edit_type.SPO2,
                            'preview': '36.png'
                        },
                        {
                            'type': hmUI.edit_type.BATTERY,
                            'preview': '37.png'
                        },
                        {
                            'type': hmUI.edit_type.CAL,
                            'preview': '38.png'
                        },
                        {
                            'type': hmUI.edit_type.HEART,
                            'preview': '39.png'
                        }
                    ],
                    count: 5,
                    tips_BG: '34.png',
                    tips_x: 0,
                    tips_y: -40,
                    tips_width: 149,
                    tips_margin: 0
                });
                editType = normal$_$component_1$_$component.getProperty(hmUI.prop.CURRENT_TYPE);
                switch (editType) {
                case hmUI.edit_type.STEP:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 205,
                        y: 390,
                        type: hmUI.data_type.STEP,
                        font_array: [
                            '10.png',
                            '11.png',
                            '12.png',
                            '13.png',
                            '14.png',
                            '15.png',
                            '16.png',
                            '17.png',
                            '18.png',
                            '19.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '40.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 180,
                        y: 390,
                        src: '41.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.BATTERY:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 205,
                        y: 390,
                        type: hmUI.data_type.BATTERY,
                        font_array: [
                            '10.png',
                            '11.png',
                            '12.png',
                            '13.png',
                            '14.png',
                            '15.png',
                            '16.png',
                            '17.png',
                            '18.png',
                            '19.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        unit_sc: '43.png',
                        unit_tc: '43.png',
                        unit_en: '43.png',
                        invalid_image: '42.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 170,
                        y: 390,
                        src: '44.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.HEART:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 230,
                        y: 390,
                        type: hmUI.data_type.HEART,
                        font_array: [
                            '10.png',
                            '11.png',
                            '12.png',
                            '13.png',
                            '14.png',
                            '15.png',
                            '16.png',
                            '17.png',
                            '18.png',
                            '19.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '45.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 185,
                        y: 390,
                        src: '46.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.CAL:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 215,
                        y: 390,
                        type: hmUI.data_type.CAL,
                        font_array: [
                            '10.png',
                            '11.png',
                            '12.png',
                            '13.png',
                            '14.png',
                            '15.png',
                            '16.png',
                            '17.png',
                            '18.png',
                            '19.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '47.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 185,
                        y: 390,
                        src: '48.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.PAI_DAILY:
                    break;
                case hmUI.edit_type.DISTANCE:
                    break;
                case hmUI.edit_type.AQI:
                    break;
                case hmUI.edit_type.HUMIDITY:
                    break;
                case hmUI.edit_type.ALTIMETER:
                    break;
                case hmUI.edit_type.STRESS:
                    break;
                case hmUI.edit_type.WIND:
                    break;
                case hmUI.edit_type.SPO2:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 210,
                        y: 390,
                        type: hmUI.data_type.SPO2,
                        font_array: [
                            '10.png',
                            '11.png',
                            '12.png',
                            '13.png',
                            '14.png',
                            '15.png',
                            '16.png',
                            '17.png',
                            '18.png',
                            '19.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        unit_sc: '50.png',
                        unit_tc: '50.png',
                        unit_en: '50.png',
                        invalid_image: '49.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 180,
                        y: 390,
                        src: '51.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.TRAINING_LOAD:
                    break;
                case hmUI.edit_type.VO2MAX:
                    break;
                case hmUI.edit_type.UVI:
                    break;
                case hmUI.edit_type.DATE:
                    break;
                case hmUI.edit_type.WEEK:
                    break;
                case hmUI.edit_type.WEATHER:
                    break;
                case hmUI.edit_type.TEMPERATURE:
                    break;
                case hmUI.edit_type.SUN:
                    break;
                }
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 39,
                    hour_startY: 58,
                    hour_array: [
                        '52.png',
                        '53.png',
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png',
                        '58.png',
                        '59.png',
                        '60.png',
                        '61.png'
                    ],
                    hour_space: -40,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 137,
                    minute_startY: 159,
                    minute_array: [
                        '52.png',
                        '53.png',
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png',
                        '58.png',
                        '59.png',
                        '60.png',
                        '61.png'
                    ],
                    minute_space: -40,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    second_zero: 1,
                    second_startX: 236,
                    second_startY: 270,
                    second_array: [
                        '52.png',
                        '53.png',
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png',
                        '58.png',
                        '59.png',
                        '60.png',
                        '61.png'
                    ],
                    second_space: -40,
                    second_align: hmUI.align.LEFT,
                    second_follow: 0,
                    am_x: 210,
                    am_y: 130,
                    am_sc_path: '62.png',
                    am_en_path: '63.png',
                    pm_x: 210,
                    pm_y: 130,
                    pm_sc_path: '64.png',
                    pm_en_path: '65.png',
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 370,
                    month_startY: 225,
                    month_en_array: [
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png',
                        '71.png',
                        '72.png',
                        '73.png',
                        '74.png',
                        '75.png',
                        '76.png',
                        '77.png'
                    ],
                    month_align: hmUI.align.LEFT,
                    month_zero: 0,
                    month_follow: 0,
                    month_space: 0,
                    month_is_character: true,
                    day_startX: 365,
                    day_startY: 185,
                    day_sc_array: [
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png'
                    ],
                    day_tc_array: [
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png'
                    ],
                    day_en_array: [
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png'
                    ],
                    day_align: hmUI.align.LEFT,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 0,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 230,
                    y: 10,
                    src: '78.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 190,
                    y: 10,
                    src: '79.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 190,
                    y: 10,
                    src: '80.png',
                    type: hmUI.system_status.DISCONNECT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 150,
                    y: 20,
                    src: '81.png',
                    type: hmUI.system_status.DISTURB,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 230,
                    y: 10,
                    src: '82.png',
                    type: hmUI.system_status.LOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 275,
                    y: 20,
                    src: '83.png',
                    type: hmUI.system_status.CLOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$component_2$_$component = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: 3,
                    x: 57,
                    y: 271,
                    w: 149,
                    h: 45,
                    select_image: '84.png',
                    un_select_image: '85.png',
                    default_type: hmUI.edit_type.BATTERY,
                    optional_types: [
                        {
                            'type': hmUI.edit_type.BATTERY,
                            'preview': '87.png'
                        },
                        {
                            'type': hmUI.edit_type.SPO2,
                            'preview': '88.png'
                        },
                        {
                            'type': hmUI.edit_type.STEP,
                            'preview': '89.png'
                        },
                        {
                            'type': hmUI.edit_type.CAL,
                            'preview': '90.png'
                        },
                        {
                            'type': hmUI.edit_type.HEART,
                            'preview': '91.png'
                        }
                    ],
                    count: 5,
                    tips_BG: '86.png',
                    tips_x: 0,
                    tips_y: -40,
                    tips_width: 149,
                    tips_margin: 0
                });
                editType = normal$_$component_2$_$component.getProperty(hmUI.prop.CURRENT_TYPE);
                switch (editType) {
                case hmUI.edit_type.STEP:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 100,
                        y: 280,
                        type: hmUI.data_type.STEP,
                        font_array: [
                            '10.png',
                            '11.png',
                            '12.png',
                            '13.png',
                            '14.png',
                            '15.png',
                            '16.png',
                            '17.png',
                            '18.png',
                            '19.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 70,
                        y: 280,
                        src: '92.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.BATTERY:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 100,
                        y: 280,
                        type: hmUI.data_type.BATTERY,
                        font_array: [
                            '10.png',
                            '11.png',
                            '12.png',
                            '13.png',
                            '14.png',
                            '15.png',
                            '16.png',
                            '17.png',
                            '18.png',
                            '19.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        unit_sc: '93.png',
                        unit_tc: '93.png',
                        unit_en: '93.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 65,
                        y: 280,
                        src: '94.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.HEART:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 115,
                        y: 280,
                        type: hmUI.data_type.HEART,
                        font_array: [
                            '10.png',
                            '11.png',
                            '12.png',
                            '13.png',
                            '14.png',
                            '15.png',
                            '16.png',
                            '17.png',
                            '18.png',
                            '19.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '95.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 75,
                        y: 280,
                        src: '96.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.CAL:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 110,
                        y: 280,
                        type: hmUI.data_type.CAL,
                        font_array: [
                            '10.png',
                            '11.png',
                            '12.png',
                            '13.png',
                            '14.png',
                            '15.png',
                            '16.png',
                            '17.png',
                            '18.png',
                            '19.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 75,
                        y: 280,
                        src: '97.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.PAI_DAILY:
                    break;
                case hmUI.edit_type.DISTANCE:
                    break;
                case hmUI.edit_type.AQI:
                    break;
                case hmUI.edit_type.HUMIDITY:
                    break;
                case hmUI.edit_type.ALTIMETER:
                    break;
                case hmUI.edit_type.STRESS:
                    break;
                case hmUI.edit_type.WIND:
                    break;
                case hmUI.edit_type.SPO2:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 110,
                        y: 280,
                        type: hmUI.data_type.SPO2,
                        font_array: [
                            '10.png',
                            '11.png',
                            '12.png',
                            '13.png',
                            '14.png',
                            '15.png',
                            '16.png',
                            '17.png',
                            '18.png',
                            '19.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        unit_sc: '99.png',
                        unit_tc: '99.png',
                        unit_en: '99.png',
                        invalid_image: '98.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 75,
                        y: 280,
                        src: '100.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.TRAINING_LOAD:
                    break;
                case hmUI.edit_type.VO2MAX:
                    break;
                case hmUI.edit_type.UVI:
                    break;
                case hmUI.edit_type.DATE:
                    break;
                case hmUI.edit_type.WEEK:
                    break;
                case hmUI.edit_type.WEATHER:
                    break;
                case hmUI.edit_type.TEMPERATURE:
                    break;
                case hmUI.edit_type.SUN:
                    break;
                }
                hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK, {
                    x: 0,
                    y: 0,
                    w: 454,
                    h: 454,
                    src: '101.png',
                    show_level: hmUI.show_level.ONLY_EDIT
                });
                hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
                    x: 0,
                    y: 0,
                    w: 454,
                    h: 454,
                    src: '102.png',
                    show_level: hmUI.show_level.ONLY_EDIT
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 454,
                    h: 454,
                    src: '103.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 114,
                    hour_startY: 125,
                    hour_array: [
                        '52.png',
                        '53.png',
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png',
                        '58.png',
                        '59.png',
                        '60.png',
                        '61.png'
                    ],
                    hour_space: -40,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 224,
                    minute_startY: 234,
                    minute_array: [
                        '52.png',
                        '53.png',
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png',
                        '58.png',
                        '59.png',
                        '60.png',
                        '61.png'
                    ],
                    minute_space: -40,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    am_x: 297,
                    am_y: 197,
                    am_sc_path: '62.png',
                    am_en_path: '63.png',
                    pm_x: 297,
                    pm_y: 197,
                    pm_sc_path: '64.png',
                    pm_en_path: '65.png',
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 151,
                    month_startY: 289,
                    month_en_array: [
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png',
                        '71.png',
                        '72.png',
                        '73.png',
                        '74.png',
                        '75.png',
                        '76.png',
                        '77.png'
                    ],
                    month_align: hmUI.align.LEFT,
                    month_zero: 0,
                    month_follow: 0,
                    month_space: 0,
                    month_is_character: true,
                    day_startX: 180,
                    day_startY: 251,
                    day_sc_array: [
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png'
                    ],
                    day_tc_array: [
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png'
                    ],
                    day_en_array: [
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png'
                    ],
                    day_align: hmUI.align.LEFT,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 0,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}