try {
  (() => {

    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

    /*
  * huamiOS bundle tool v1.0.17
  * Copyright © Huami. All Rights Reserved
  */
    'use strict';

    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);


    const rootPath = "images/";
    const bgPath = rootPath + "BG/"
    const numberPath = rootPath + "number/"
    const ampmPath = rootPath + "AMPM/"
    const batteryPath = rootPath + "battery/"
    const hourPath = rootPath + "hour/"
    const minutePath = rootPath + "minute/"
    const paiPath = rootPath + "PAI/"
    const stepPath = rootPath + "step/"
    const weekPath = rootPath + "week/"
    const xphourPath = rootPath + "xphour/"
    const xpminutePath = rootPath + "xpminute/"
    const number_array = [
      numberPath + "0.png",
      numberPath + "1.png",
      numberPath + "2.png",
      numberPath + "3.png",
      numberPath + "4.png",
      numberPath + "5.png",
      numberPath + "6.png",
      numberPath + "7.png",
      numberPath + "8.png",
      numberPath + "9.png",
    ]

    const battery_array = [
      batteryPath + "0.png",
      batteryPath + "1.png",
      batteryPath + "2.png",
      batteryPath + "3.png",
      batteryPath + "4.png",
      batteryPath + "5.png",
      batteryPath + "6.png",
      batteryPath + "7.png",
      batteryPath + "8.png",
      batteryPath + "9.png",
    ]
    const hour_array = [
      hourPath + "0.png",
      hourPath + "1.png",
      hourPath + "2.png",
      hourPath + "3.png",
      hourPath + "4.png",
      hourPath + "5.png",
      hourPath + "6.png",
      hourPath + "7.png",
      hourPath + "8.png",
      hourPath + "9.png",
    ]
    const minute_array = [
      minutePath + "0.png",
      minutePath + "1.png",
      minutePath + "2.png",
      minutePath + "3.png",
      minutePath + "4.png",
      minutePath + "5.png",
      minutePath + "6.png",
      minutePath + "7.png",
      minutePath + "8.png",
      minutePath + "9.png",

    ]
    const xphour_array = [
      xphourPath + "0.png",
      xphourPath + "1.png",
      xphourPath + "2.png",
      xphourPath + "3.png",
      xphourPath + "4.png",
      xphourPath + "5.png",
      xphourPath + "6.png",
      xphourPath + "7.png",
      xphourPath + "8.png",
      xphourPath + "9.png",
    ]
    const xpminute_array = [
      xpminutePath + "0.png",
      xpminutePath + "1.png",
      xpminutePath + "2.png",
      xpminutePath + "3.png",
      xpminutePath + "4.png",
      xpminutePath + "5.png",
      xpminutePath + "6.png",
      xpminutePath + "7.png",
      xpminutePath + "8.png",
      xpminutePath + "9.png",

    ]
    const pai_array = [
      paiPath + "0.png",
      paiPath + "1.png",
      paiPath + "2.png",
      paiPath + "3.png",
      paiPath + "4.png",
      paiPath + "5.png",
      paiPath + "6.png",
      paiPath + "7.png",
      paiPath + "8.png",
      paiPath + "9.png",
    ]
    const step_array = [
      stepPath + "0.png",
      stepPath + "1.png",
      stepPath + "2.png",
      stepPath + "3.png",
      stepPath + "4.png",
      stepPath + "5.png",
      stepPath + "6.png",
      stepPath + "7.png",
      stepPath + "8.png",
      stepPath + "9.png"
    ]
    const week_array = [
      weekPath + '1.png',
      weekPath + '2.png',
      weekPath + '3.png',
      weekPath + '4.png',
      weekPath + '5.png',
      weekPath + '6.png',
      weekPath + '7.png',

    ]



    let batterySensor = null;//
    const batteryWidgetArray = new Array(4);//
    batterySensor = hmSensor.createSensor(hmSensor.id.BATTERY); //创建传感器  电量传感器获取电量

    function setImgPath(widget, path) {
      widget.setProperty(hmUI.prop.SRC, path);
      widget.setProperty(hmUI.prop.VISIBLE, true);
    }
    function refreshBattery() {  //绘制电量
      for (var i = 0; i < 4; i++) {
        batteryWidgetArray[i].setProperty(hmUI.prop.VISIBLE, false);
      }
      const battery = batterySensor.current; //获取当前电量


      if (battery == 100) {

        setImgPath(batteryWidgetArray[0], battery_array[1]);
        setImgPath(batteryWidgetArray[1], battery_array[0]);
        setImgPath(batteryWidgetArray[2], battery_array[0]);
        setImgPath(batteryWidgetArray[3], rootPath + 'battery/baifenhao.png');

      }
      let v1 = parseInt(battery / 10 % 10);
      let v2 = parseInt(battery % 10)
      if (battery <= 99 && battery >= 10) {
        setImgPath(batteryWidgetArray[0], battery_array[v1]);
        setImgPath(batteryWidgetArray[1], battery_array[v2]);
        setImgPath(batteryWidgetArray[2], rootPath + 'battery/baifenhao.png');

      }

      if (battery < 10) {
        setImgPath(batteryWidgetArray[0], battery_array[battery]);
        setImgPath(batteryWidgetArray[1], rootPath + 'battery/baifenhao.png');
      }

    }
    const logger = DeviceRuntimeCore.HmLogger.getLogger("defult");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({


      init_view() {
        let bg_img = hmUI.createWidget(hmUI.widget.IMG, {  //背景图片
          x: 0,
          y: 0,
          w: 454,
          h: 454,
          src: bgPath + "bg.png",
          show_level: hmUI.show_level.ONLY_NORMAL
        })


        for (let i = 0; i < 4; i++) {
          batteryWidgetArray[i] = hmUI.createWidget(hmUI.widget.IMG, {  //动态创建电量的位置
            x: 415,
            y: 220 + i * 14,
            show_level: hmUI.show_level.ONLY_NORMAL
          });
        }

        refreshBattery();
        batterySensor.addEventListener(hmSensor.event.CHANGE, function () {
          refreshBattery();
        });
        hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: (function () {
            refreshBattery();
          }),
          pause_call: (function () {
            console.log('ui pause');
          }),
        });


        let week = hmUI.createWidget(hmUI.widget.IMG_WEEK, { //周数
          x: 237,
          y: 48,
          week_en: week_array,
          week_tc: week_array,
          week_sc: week_array,
          show_level: hmUI.show_level.ONLY_NORMAL

        })
        let pai = hmUI.createWidget(hmUI.widget.TEXT_IMG, {   //
          x: 112,
          y: 281,
          type: hmUI.data_type.PAI_WEEKLY,
          font_array: pai_array,
          h_space: 0,
          align_h: hmUI.align.LEFT,

          padding: false,  //不补零
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let stepText = hmUI.createWidget(hmUI.widget.TEXT_IMG, { //步数
          x: 144,
          y: 358,
          type: hmUI.data_type.STEP,
          font_array: step_array,
          h_space: -2,
          align_h: hmUI.align.LEFT,
          padding: false,   //不补零
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, { //shijian
          hour_zero: 1, //补零
          hour_startX: 70,
          hour_startY: 129,
          hour_array: hour_array,
          hour_space: 0, //每个数字间的间隔
          minute_zero: 1, //补零
          minute_startX: 249,
          minute_startY: 179.5,
          minute_array: minute_array,
          minute_space: 0, //每个数字间的间隔
          am_x: 13,
          am_y: 201,
          am_sc_path: ampmPath + "AM.png", //上午图片  
          am_en_path: ampmPath + "AM.png",
          pm_x: 13,
          pm_y: 201,
          pm_sc_path: ampmPath + "PM.png", // 下午图片
          pm_en_path: ampmPath + "PM.png",

          show_level: hmUI.show_level.ONLY_NORMAL
        });

        //年月日
        let YTD = hmUI.createWidget(hmUI.widget.IMG_DATE, {
          year_startX: 320,
          year_startY: 97.5,

          year_align: hmUI.align.CENTER_H,
          year_space: -2,//文字间隔
          year_zero: 1,//补零 
          year_follow: 0,//是否跟随   不跟随
          year_en_array: number_array,
          year_sc_array: number_array,
          year_tc_array: number_array,
          // year_is_character: true, //年份此字段无效 默认为false  
          //月日同上 需要替换前缀为month/day
          month_startX: 282,
          month_startY: 97.5,
          month_unit_sc: numberPath + "xiaoshudian.png", //单位
          month_unit_tc: numberPath + "xiaoshudian.png",
          month_unit_en: numberPath + "xiaoshudian.png",
          month_align: hmUI.align.CENTER_H,
          month_space: -1,//文字间隔
          month_zero: 1,//补零
          month_follow: 0,//是否跟随  不跟随
          month_en_array: number_array,
          month_sc_array: number_array,
          month_tc_array: number_array,
          //  month_is_character: true,  //会影响补零   为true时 传入的图片为月份12张

          day_startX: 244,
          day_startY: 97.5,
          day_unit_sc: numberPath + "xiaoshudian.png", //单位
          day_unit_tc: numberPath + "xiaoshudian.png",
          day_unit_en: numberPath + "xiaoshudian.png",
          day_align: hmUI.align.CENTER_H,
          day_space: -1,//文字间隔
          day_zero: 1,//补零 
          day_follow: 0,//是否跟随 不跟随
          day_en_array: number_array,
          day_sc_array: number_array,
          day_tc_array: number_array,
          // day_is_character: true,   //会影响补零   为true时 传入的图片为日31张
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let AOD_timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          hour_zero: 1, //是否补零
          hour_startX: 70,
          hour_startY: 129,
          hour_array: xphour_array,
          hour_space: 0, //每个数组间的间隔
          minute_zero: 1, //是否补零
          minute_startX: 256,
          minute_startY: 179.5,
          minute_array: xpminute_array,
          minute_space: 0, //每个数组间的间隔
          show_level: hmUI.show_level.ONAL_AOD
        });

        let AOD_maohao_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 218,
          y: 126,
          src: xphourPath + "maohao.png",
          show_level: hmUI.show_level.ONAL_AOD
        })


      },

      onInit() {
        console.log('index page.js on init invoke');

        this.init_view();


      },

      onReady() {
        console.log('index page.js on ready invoke')
      },

      onShow() {
        console.log('index page.js on show invoke')
      },

      onHide() {
        console.log('index page.js on hide invoke')
      },

      onDestory() {
        console.log('index page.js on destory invoke')
      },
    });
    /*
    * end js
    */
  })()
} catch (e) {
  console.log(e)
}