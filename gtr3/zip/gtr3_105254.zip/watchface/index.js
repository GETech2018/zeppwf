try {
    (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;

        var __$$module$$__ = __$$app$$__.current;
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        /*
      * huamiOS bundle tool v1.0.17
      * Copyright © Huami. All Rights Reserved
      */
        'use strict';

        console.log("----->>>current");
        console.log(__$$hmAppManager$$__.currentApp.pid);
        console.log(__$$hmAppManager$$__.currentApp.current);

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

            init_view() {
                let rootPath = "images/";
                let screenType = hmSetting.getScreenType()
                let timeArr = []
                let interestArr = []
                let batteryArr = []
                let weekArr = []
                let monthArr = []
                let levelArr = []
                let distance = hmSensor.createSensor(hmSensor.id.DISTANCE).current
                for (let i = 0; i < 10; i++) {
                    if (i >= 1 && i <= 7) {
                        weekArr.push(rootPath + "week/" + i + ".png")
                    }
                    batteryArr.push(rootPath + "battery/" + i + ".png")
                    timeArr.push(rootPath + "time/" + i + ".png")
                    interestArr.push(rootPath + "interest/" + i + ".png")
                    monthArr.push(rootPath + "month/" + i + ".png")
                    levelArr.push(rootPath + "level/" + i + ".png")
                }
                if (screenType == hmSetting.screen_type.AOD) {
                    //time
                    let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                        hour_zero: 1,
                        hour_startX: 76.61,
                        hour_startY: 192,
                        hour_array: timeArr,
                        hour_unit_sc: rootPath + "time/maohao.png",
                        hour_unit_tc: rootPath + "time/maohao.png",
                        hour_unit_en: rootPath + "time/maohao.png",
                        hour_space: 0,
                        hour_align: hmUI.align.LEFT,

                        minute_zero: 1,
                        minute_startX: 180.65,
                        minute_startY: 192,
                        minute_array: timeArr,
                        minute_space: 0,
                        minute_align: hmUI.align.LEFT,
                    });
                } else {
                    // animate
                    let animate = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                        x: 0,
                        y: 0,
                        anim_path: rootPath + "animate", //必须从0开始 可以询问君成 张莉
                        anim_prefix: "anim",
                        anim_ext: "png",
                        anim_fps: 25,
                        anim_size: 19,
                        repeat_count: 0, //0位无限重复
                        anim_repeat: true,//是否重复
                        anim_status: hmUI.anim_status.START,
                        display_on_restart: false,//从息屏到亮屏是否自动重复播放
                    });
                    //time
                    let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                        hour_zero: 1,
                        hour_startX: 76.61,
                        hour_startY: 192,
                        hour_array: timeArr,
                        hour_unit_sc: rootPath + "time/maohao.png",
                        hour_unit_tc: rootPath + "time/maohao.png",
                        hour_unit_en: rootPath + "time/maohao.png",
                        hour_space: 5,
                        hour_align: hmUI.align.LEFT,

                        minute_zero: 1,
                        minute_startX: 185.65,
                        minute_startY: 192,
                        minute_unit_sc: rootPath + "time/maohao.png",
                        minute_unit_tc: rootPath + "time/maohao.png",
                        minute_unit_en: rootPath + "time/maohao.png",
                        minute_array: timeArr,
                        minute_space: 5,
                        minute_align: hmUI.align.LEFT,

                        second_zero: 1,
                        second_startX: 292.26,
                        second_startY: 192,
                        second_array: timeArr,
                        second_space: 5,
                        second_align: hmUI.align.LEFT,
                    });
                    //week
                    hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                        x: 247,
                        y: 153,
                        week_en: weekArr,
                        week_tc: weekArr,
                        week_sc: weekArr,
                    });
                    //month day
                    let month_num = hmUI.createWidget(hmUI.widget.IMG_DATE, {
                        month_startX: 155.12,
                        month_startY: 153.23,
                        month_align: hmUI.align.LEFT,
                        month_space: 0,
                        month_zero: 1,
                        month_follow: 0,
                        month_unit_sc: rootPath + "month/line.png", //单位
                        month_unit_tc: rootPath + "month/line.png",
                        month_unit_en: rootPath + "month/line.png",
                        month_en_array: monthArr,
                        month_sc_array: monthArr,
                        month_tc_array: monthArr,
                        month_is_character: false,

                        day_startX: 199,
                        day_startY: 153,
                        day_align: hmUI.align.LEFT,
                        day_space: 0,
                        day_zero: 1,
                        day_follow: 0,
                        day_en_array: monthArr,
                        day_sc_array: monthArr,
                        day_tc_array: monthArr,
                        day_is_character: false,
                    });
                    //distance
                    let disTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 55.8,
                        y: 327.26,
                        type: hmUI.data_type.DISTANCE,
                        font_array: monthArr,
                        dot_image:rootPath + "month/dot.png",
                        invalid_image:rootPath + "month/none.png",
                        h_space: 0,
                        align_h: hmUI.align.LEFT,
                        padding: false,
                        isCharacter: true,
                    });
                    //heart
                    let heartTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 204.87,
                        y: 327.26,
                        type: hmUI.data_type.HEART,   // 获取心率数字，自动获取
                        invalid_image:rootPath + "month/none.png",
                        font_array: monthArr,   //心率数字图片
                        h_space: 0,  //数字之间的间隔
                        align_h: hmUI.align.CENTER_H,   //数字的对齐方式
                        padding: false, //是否补零 true为补零
                        isCharacter: true, //true为文字图片
                    });
                    //step
                    let stepTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 321.77,
                        y: 327.26,
                        type: hmUI.data_type.STEP,   // 获取心率数字，自动获取
                        invalid_image:rootPath + "month/none.png",
                        font_array: monthArr,   //心率数字图片
                        h_space: 0,  //数字之间的间隔
                        align_h: hmUI.align.RIGHT,   //数字的对齐方式
                        padding: false, //是否补零 true为补零
                        isCharacter: true, //true为文字图片
                    });
                    //battery
                    let batteryTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 256.32,
                        y: 37.83,
                        type: hmUI.data_type.BATTERY,   // 获取心率数字，自动获取
                        font_array: batteryArr,   //心率数字图片
                        unit_sc: rootPath + "battery/unit.png",
                        unit_tc: rootPath + "battery/unit.png",
                        unit_en: rootPath + "battery/unit.png",
                        invalid_image: rootPath + "battery/none.png",
                        h_space: 0,  //数字之间的间隔
                        align_h: hmUI.align.LEFT,   //数字的对齐方式
                        padding: false, //是否补零 true为补零
                        isCharacter: true, //true为文字图片
                    });

                    //battery level
                    let batteryLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                        x: 167,
                        y: 52,
                        image_array: levelArr,
                        image_length: levelArr.length,
                        type: hmUI.data_type.BATTERY,
                    });
                }
            },

            onInit() {
                console.log('index page.js on init invoke')

                this.init_view();
            },

            onReady() {
                console.log('index page.js on ready invoke')
            },

            onShow() {
                console.log('index page.js on show invoke')
            },

            onHide() {
                console.log('index page.js on hide invoke')
            },

            onDestory() {
                console.log('index page.js on destory invoke')
                timer.stopTimer(timerSupport)
            },
        });
        /*
        * end js
        */
    })()
} catch (e) {
    console.log(e)
}