try {
    (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;

        var __$$module$$__ = __$$app$$__.current;
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        /*
    * huamiOS bundle tool v1.0.17
    * Copyright © Huami. All Rights Reserved
    * 10020 多数据
    */
        'use strict';

        console.log("----->>>current")
        console.log(__$$hmAppManager$$__.currentApp.pid)
        console.log(__$$hmAppManager$$__.currentApp.current)

        let rootPath = null
        let heartLevel = null
        let img_bg = null
        let timeText = null
        let timeArray = null
        let dataArray = null
        let sleepWidgetArray = new Array(3);
        let sleepArray = null
        let swsArr = new Array(4);
        let clockTimer = null
        let sleep = null
        let isDraw = false
        let sleepCurrentStart = 0
        let sleepCurrentStop = 0
        let heartLine = null
        let sleepRectArr = new Array();
        let sleepTxt1 = null
        let sleepTxt2 = null
        let sleepTxt3 = null
        let sleepTxt4 = null
        let fillRectScroe = null
        let objScroeNone = null
        // var jstime = hmSensor.createSensor(hmSensor.id.TIME); //打印时间
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

            init_view() {
                rootPath = "images/"
                timeArray = [
                    rootPath + "time/00.png",
                    rootPath + "time/01.png",
                    rootPath + "time/02.png",
                    rootPath + "time/03.png",
                    rootPath + "time/04.png",
                    rootPath + "time/05.png",
                    rootPath + "time/06.png",
                    rootPath + "time/07.png",
                    rootPath + "time/08.png",
                    rootPath + "time/09.png",
                ]

                let fontArr = [
                    rootPath + '/font/0.png',
                    rootPath + '/font/1.png',
                    rootPath + '/font/2.png',
                    rootPath + '/font/3.png',
                    rootPath + '/font/4.png',
                    rootPath + '/font/5.png',
                    rootPath + '/font/6.png',
                    rootPath + '/font/7.png',
                    rootPath + '/font/8.png',
                    rootPath + '/font/9.png',
                ];
                dataArray = [
                    rootPath + "data/00.png",
                    rootPath + "data/01.png",
                    rootPath + "data/02.png",
                    rootPath + "data/03.png",
                    rootPath + "data/04.png",
                    rootPath + "data/05.png",
                    rootPath + "data/06.png",
                    rootPath + "data/07.png",
                    rootPath + "data/08.png",
                    rootPath + "data/09.png",
                ]

                heartLevel = [
                    rootPath + "heartLevel/01.png",
                    rootPath + "heartLevel/02.png",
                    rootPath + "heartLevel/03.png",
                    rootPath + "heartLevel/04.png",
                    rootPath + "heartLevel/05.png",
                    rootPath + "heartLevel/06.png",
                ]

                var screenType = hmSetting.getScreenType();
                if (screenType == hmSetting.screen_type.AOD) {
                    img_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
                        x: 0,
                        y: 0,
                        w: 454,
                        h: 454,
                        color: 0x000000,
                    });
                    showTime();

                } else {

                    img_bg = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 0,
                        y: 0,
                        w: 454,
                        h: 454,
                        src: rootPath + "img/bg.png",
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                    nullTip = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 180,
                        y: 218,
                        w: 121,
                        h: 28,
                        src: rootPath + "img/no_data.png",
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                    showTime();
                    showSec();
                    let heart = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                        x: 157,
                        y: 14,
                        w: 140, //宽高可省略
                        h: 140,
                        image_array: heartLevel,
                        image_length: 6,
                        type: hmUI.data_type.HEART,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                    let heartIcon = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 192,
                        y: 90,
                        w: 70,
                        h: 25,
                        src: rootPath + "img/bpm.png",
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                    let hearTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 196,
                        y: 53,  //236
                        type: hmUI.data_type.HEART,
                        font_array: dataArray,
                        h_space: 0, //图片间隔
                        align_h: hmUI.align.CENTER_H,
                        invalid_image: rootPath + "img/invalid.png",
                        padding: false, //是否补零 true为补零
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                    let batteryTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 208,
                        y: 409,  //236
                        type: hmUI.data_type.BATTERY,
                        font_array: dataArray,
                        h_space: 0, //图片间隔
                        align_h: hmUI.align.LEFT,
                        unit_sc: rootPath + "img/per.png",//单位
                        unit_tc: rootPath + "img/per.png",//单位
                        unit_en: rootPath + "img/per.png",//单位
                        padding: false, //是否补零 true为补零
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                    //scroe
                    for (var i = 0; i < 3; i++) {
                        sleepWidgetArray[i] = hmUI.createWidget(hmUI.widget.IMG, {
                            x: 90 + i * 20,//132-i*20,
                            y: 70,
                            w: 21,
                            h: 28,
                        });
                    }
                    //sws----
                    for (var i = 0; i < 4; i++) {
                        swsArr[i] = hmUI.createWidget(hmUI.widget.IMG);
                    }
                    //睡眠起始时间
                    sleepTxt1 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    });
                    sleepTxt2 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    })
                    sleepTxt3 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    });
                    sleepTxt4 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    });
                    //睡眠柱状图
                    for (var j = 0; j < 200; j++) {
                        sleepRectArr[j] = hmUI.createWidget(hmUI.widget.FILL_RECT);
                        sleepRectArr[j].setProperty(hmUI.prop.VISIBLE, false);
                    }
                    //睡眠心率
                    //heartLine = hmUI.createWidget(hmUI.widget.GRADKIENT_POLYLINE);
                    // drawHeartLine();
                    heartLine = hmUI.createWidget(hmUI.widget.GRADKIENT_POLYLINE, {
                        x: 30, // 心率折现起点 x
                        y: 157, // 心率折现起点 y
                        w: 400,  // 心率框 w
                        h: 130,// 心率框 h
                        type: hmUI.data_type.SLEEP, //SLEEP 
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });//
                    sleep = hmSensor.createSensor(hmSensor.id.SLEEP);
                    getSleepScroe();
                    getSleepData();   
                    fillRectScroe = hmUI.createWidget(hmUI.widget.FILL_RECT, {  //睡眠得分的遮罩
                        x: 56,
                        y: 56,
                        w: 80,
                        h: 50,
                        radius: 6,
                        color: 0x000000,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    })
                    objScroeNone = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 85,
                        y: 76,      
                        src: "images/img/invalid.png",                      
                    });
                }

                function getSleepScroe() {
                    //sleep--------                
                    const sleepScroe = sleep.getBasicInfo().score;
                    const deepth = sleep.getBasicInfo().deepMin;

                    // sleepScroe =Math.floor( Math.random()*100);
                    //deepth =Math.floor( Math.random()*150);
                    // const deepth = 150;
                    // console.log("basicInfo score==========="+sleepScroe); //睡眠得分
                    // console.log("basicInfo deepMin=========="+deepth);//深睡时间 单位分

                    let index = 0;
                    let v1 = parseInt(sleepScroe / 100);
                    let hasFirst = false;
                    //可以优化
                    if (v1 > 0 || hasFirst) {
                        hasFirst = true;
                        setImgPath(sleepWidgetArray[index++], dataArray[v1]);
                    }
                    v1 = parseInt(sleepScroe / 10 % 10);
                    if (v1 > 0 || hasFirst) {
                        hasFirst = true;
                        setImgPath(sleepWidgetArray[index++], dataArray[v1]);
                    }

                    setImgPath(sleepWidgetArray[index++], dataArray[parseInt(sleepScroe % 10)]);
                    for (var i = index; i < 3; i++) {
                        sleepWidgetArray[i].setProperty(hmUI.prop.VISIBLE, false);
                    }

                    // deepth min to hour 
                    let swsHour = parseInt(deepth / 60);
                    let swsMin = Math.floor(((deepth % 60) / 60) * 10);
                    drawTextImg(swsArr[0], 315, 70, 21, 28, dataArray[swsHour]);
                    drawTextImg(swsArr[1], 335, 70, 21, 28, rootPath + "img/dot.png");
                    drawTextImg(swsArr[2], 345, 70, 21, 28, dataArray[swsMin]);
                    drawTextImg(swsArr[3], 370, 70, 21, 28, rootPath + "img/h.png");
                    //console.log(swsMin+ "sleep:++++++++++++++ swsHour :"+ swsHour);
                }
                function Rect(fillrect, xpos, ypos, w, h, color) {
                    fillrect.setProperty(hmUI.prop.MORE, {
                        x: xpos,
                        y: ypos,
                        w: w,
                        h: h,
                        color: color,
                    });
                    fillrect.setProperty(hmUI.prop.VISIBLE, true);
                }
                function getSleepData() {
                    // console.log(`sssssssssssssssssssssssssssssss商城=定时器上`);
                    clockTimer = timer.createTimer(
                        100, 100, (function (option) {
                            // console.log(`cccccccccccccccccccccccccccccccccc商城=定时器内部`);
                            drawSleepRect();
                        })
                        , {})
                }
                function drawSleepRect() {
                    // console.log(" utc: " + jstime.utc +
                    //     " year: " + jstime.year +
                    //     " month: " + jstime.month +
                    //     " day: " + jstime.day +
                    //     " hour: " + jstime.hour +
                    //     " minute: " + jstime.minute +
                    //     " second: " + jstime.second + "\r\n");
                    // console.log(`-------------------------------睡眠数据函数调用`)
                    let sleepStageArray = sleep.getSleepStageData();
                    const sleeptime = sleep.getTotalTime();
                    const num = sleep.getBasicInfo();
                    const startTime = num.startTime;
                    const endTime = num.endTime + 1;
                    if (startTime) {
                        var startTime1 = JSON.stringify(startTime)
                        var endTime1 = JSON.stringify(endTime)
                        var H1 = parseInt(endTime1 / 60)
                        var M1 = parseInt(endTime1 % 60)
                        let SLEEP_REFERENCE_ZERO = 24 * 60

                        if (startTime1 >= SLEEP_REFERENCE_ZERO) {
                            H = parseInt((startTime1 - SLEEP_REFERENCE_ZERO) / 60)
                            M = parseInt((startTime1 - SLEEP_REFERENCE_ZERO) % 60)
                        } else {
                            H = parseInt(startTime1 / 60)
                            M = parseInt(startTime1 % 60)
                        }

                        if (endTime1 >= SLEEP_REFERENCE_ZERO) {
                            H1 = parseInt((endTime1 - SLEEP_REFERENCE_ZERO) / 60)
                            M1 = parseInt((endTime1 - SLEEP_REFERENCE_ZERO) % 60)
                        } else {
                            H1 = parseInt(endTime1 / 60)
                            M1 = parseInt(endTime1 % 60)
                        }
                        H = H >= 10 ? H : '0' + H
                        M = M >= 10 ? M : '0' + M
                        M1 = M1 >= 10 ? M1 : '0' + M1
                        H1 = H1 >= 10 ? H1 : '0' + H1

                        // console.log(`hhhhhhhhhhhhhhhhhhhhhhh==HMH1M1==` + H + `/` + M + `/` + H1 + `/` + M1)
                        sleepTxt1.setProperty(hmUI.prop.VISIBLE, true);
                        sleepTxt2.setProperty(hmUI.prop.VISIBLE, true);
                        sleepTxt3.setProperty(hmUI.prop.VISIBLE, true);
                        sleepTxt4.setProperty(hmUI.prop.VISIBLE, true);
                        sleepTxt1.setProperty(hmUI.prop.MORE, {
                            x: 6,
                            y: 300,
                            text: H,
                            font_array: fontArr,
                            h_space: 0,
                            align_h: hmUI.align.CENTER_H,
                            unit_sc: "images/font/maohao.png",
                            unit_tc: "images/font/maohao.png",
                            unit_en: "images/font/maohao.png",
                        });
                        sleepTxt2.setProperty(hmUI.prop.MORE, {
                            x: 36,
                            y: 300,
                            text: M,
                            font_array: fontArr,
                            h_space: 0,
                            align_h: hmUI.align.CENTER_H,
                        })
                        sleepTxt3.setProperty(hmUI.prop.MORE, {
                            x: 356,
                            y: 300,
                            text: H1,
                            font_array: fontArr,
                            h_space: 0,
                            align_h: hmUI.align.CENTER_H,
                            unit_sc: "images/font/maohao.png",
                            unit_tc: "images/font/maohao.png",
                            unit_en: "images/font/maohao.png",
                        });
                        sleepTxt4.setProperty(hmUI.prop.MORE, {
                            x: 386,
                            y: 300,
                            text: M1,
                            font_array: fontArr,
                            h_space: 0,
                            align_h: hmUI.align.CENTER_H,
                        });
                    } else {
                        sleepTxt1.setProperty(hmUI.prop.VISIBLE, false);
                        sleepTxt2.setProperty(hmUI.prop.VISIBLE, false);
                        sleepTxt3.setProperty(hmUI.prop.VISIBLE, false);
                        sleepTxt4.setProperty(hmUI.prop.VISIBLE, false);
                    }
                    // console.log(`1111111111111111111111111111111111==sleepStageArray==` + JSON.stringify(sleepStageArray))
                    // console.log(`2222222222222222222222222222222222==sleepStageArray.length==` + sleepStageArray.length)
                    if (sleepStageArray && sleepStageArray.length != 0) { //无数据的时候是空数组 长度为0  有数据时才进入该判断
                        // 表盘显示柱状图的宽度                        
                        // console.log(`3333333333333333333333333333==有数据进入绘制if判断绘制睡眠柱状图==`)
                        // console.log(`4444444444444444444444444444==sleepStageArray[sleepStageArray.length - 1].stop==` + sleepStageArray[sleepStageArray.length - 1].stop)
                        // console.log(`5555555555555555555555555555==sleepStageArray[sleepStageArray.length - 1].start==` + sleepStageArray[sleepStageArray.length - 1].start)
                        if (sleepCurrentStop == sleepStageArray[sleepStageArray.length - 1].stop || sleepCurrentStart == sleepStageArray[sleepStageArray.length - 1].start) {
                            // console.log(`nnnnnnnnnnnnnnn没有新数据产生，不再执行下面的代码`)
                            timer.stopTimer(clockTimer);
                            return;
                        }
                        sleepCurrentStop = sleepStageArray[sleepStageArray.length - 1].stop;
                        sleepCurrentStart = sleepStageArray[sleepStageArray.length - 1].start;
                        var per = 400 / (sleepStageArray[(sleepStageArray.length - 1)].stop - sleepStageArray[0].start);
                        for (var i = 0; i < sleepStageArray.length; i++) {
                            const data = sleepStageArray[i];
                            // console.log("sleep:_______________________data.model:" + data.model);
                            // console.log("sleep:_______________________data.start:" + data.start);
                            // console.log("sleep:_______________________data.stop:" + data.stop);
                            var xpos = 20 + (data.start - sleepStageArray[0].start) * per; //柱状图 x 
                            var ypos = 287; //柱状图 y 
                            var w = (data.stop - data.start) * per;
                            var space = 6; //柱状图间隔
                            switch (data.model) {
                                case 4:// .LIGHT_STAGE 浅睡 blue
                                    Rect(sleepRectArr[i], xpos + space, ypos - 30, w, 30, 0x259FBE);
                                    break;
                                case 5:// DEEP_STAGE:5  深睡 purple
                                    Rect(sleepRectArr[i], xpos + space, ypos - 60, w, 60, 0x864BE1);
                                    break;
                                case 7:// WAKE_STAGE:7 清醒 yellow(red)
                                    Rect(sleepRectArr[i], xpos + space, ypos - 118, w, 118, 0xD05D20);
                                    break;
                                case 8:// .REM_STAGE 8 REM green
                                    Rect(sleepRectArr[i], xpos + space, ypos - 90, w, 90, 0x0CB462);
                                    break;
                                default:

                            }
                        }
                        for (var j = i; j < 200; j++) {
                            sleepRectArr[j].setProperty(hmUI.prop.VISIBLE, false);
                        }
                        heartLine.setProperty(hmUI.prop.VISIBLE, true); //睡眠曲线显示
                        nullTip.setProperty(hmUI.prop.VISIBLE, false);  //no_data 隐藏
                        fillRectScroe.setProperty(hmUI.prop.VISIBLE, false);  //无睡眠时得分遮罩隐藏
                        objScroeNone.setProperty(hmUI.prop.VISIBLE, false);  //无数据图片 -- 隐藏
                        isDraw = true;
                        timer.stopTimer(clockTimer);
                    } else {
                        // console.log(`0000000000000000000000000000000000000==无睡眠数据开始`)
                        heartLine.setProperty(hmUI.prop.VISIBLE, false);  //睡眠曲线隐藏
                        for (var n = 0; n < 200; n++) {
                            sleepRectArr[n].setProperty(hmUI.prop.VISIBLE, false);
                        }
                        nullTip.setProperty(hmUI.prop.VISIBLE, true); //no_data 显示
                        fillRectScroe.setProperty(hmUI.prop.VISIBLE, true);  // 无睡眠时得分遮罩显示
                        objScroeNone.setProperty(hmUI.prop.VISIBLE, true);   //无数据图片 -- 显示                    
                        // console.log(`0000000000000000000000000000000000000==无睡眠数据结速`)
                    }
                }
                function drawTextImg(swsIcon, xpos, ypos, w, h, path) {
                    swsIcon.setProperty(hmUI.prop.MORE, {
                        x: xpos,
                        y: ypos,
                        w: w,
                        h: h,
                        src: path,
                    });
                }
                function setImgPath(widget, path) {
                    widget.setProperty(hmUI.prop.SRC, path);
                    widget.setProperty(hmUI.prop.VISIBLE, true);
                }
                function showTime() {
                    timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                        hour_zero: 1,
                        hour_startX: 113,
                        hour_startY: 331,
                        hour_array: timeArray,
                        hour_space: 0,
                        hour_unit_sc: rootPath + "img/colon.png", //单位
                        hour_unit_tc: rootPath + "img/colon.png",
                        hour_unit_en: rootPath + "img/colon.png",
                        hour_align: hmUI.align.LEFT,

                        minute_zero: 1, //是否补零 1为补零
                        minute_startX: 236,
                        minute_startY: 331,
                        minute_array: timeArray,
                        minute_space: 0, //两个图片间隔 对应GT2的interval
                        minute_follow: 0, //是否跟随
                        minute_align: hmUI.align.LEFT,
                        am_x: 70,
                        am_y: 340,
                        am_sc_path: rootPath + "img/am.png",
                        am_en_path: rootPath + "img/am.png",//pm同上 前缀由am改为pm
                        pm_x: 70,
                        pm_y: 340,
                        pm_sc_path: rootPath + "img/pm.png",
                        pm_en_path: rootPath + "img/pm.png",//pm同上 前缀由am改为pm
                        show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD,
                    });
                }
                function showSec() {
                    let secText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                        second_zero: 1, //是否补零 1为补零
                        second_startX: 348,
                        second_startY: 331,
                        second_array: dataArray,
                        second_space: 0, //两个图片间隔 对应GT2的interval
                        second_follow: 0, //是否跟随
                        second_align: hmUI.align.LEFT,
                    });
                };
                // 睡眠数据更新
                const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: (function () {
                        // console.log(`99999999999999999999999999999商城==滑屏事件`)
                        // console.log('ui resume');
                        getSleepScroe();
                        drawSleepRect();
                    }),
                    pause_call: (function () {
                        // console.log('ui pause');

                    }),

                });
            },

            onInit() {
                console.log('index page.js on init invoke')

                this.init_view();

            },

            onReady() {
                console.log('index page.js on ready invoke')
            },

            onShow() {
                console.log('index page.js on show invoke')
            },

            onHide() {
                console.log('index page.js on hide invoke')
            },

            onDestory() {
                console.log('index page.js on destory invoke')
            },
        });
        /*
        * end js
        */
    })()
} catch (e) {
    console.log(e)
}
