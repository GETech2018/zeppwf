try {
    (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;

        var __$$module$$__ = __$$app$$__.current;
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        /*
    * huamiOS bundle tool v1.0.17
    * Copyright © Huami. All Rights Reserved
    */
        'use strict';

        console.log("----->>>current")
        console.log(__$$hmAppManager$$__.currentApp.pid)
        console.log(__$$hmAppManager$$__.currentApp.current)

        const ROOTPATH = "images/";

        const batteryPath = ROOTPATH + "battery/"
        const bgPath = ROOTPATH + "bg/"
        const dataPath = ROOTPATH + "data/"
        const heartPath = ROOTPATH + "heart/"
      
        const stepPath = ROOTPATH + "step/"
        const tPath = ROOTPATH + "T/"
        const timePath = ROOTPATH + "time/"
        const weekPath = ROOTPATH + "week/"
      
        const battery_array = [
            batteryPath + "0.png",
            batteryPath + "1.png",
            batteryPath + "2.png",
            batteryPath + "3.png",
            batteryPath + "4.png",
            batteryPath + "5.png",
            batteryPath + "6.png",
            batteryPath + "7.png",
            batteryPath + "8.png",
            batteryPath + "9.png",


        ]
        const data_array = [
            dataPath + "0.png",
            dataPath + "1.png",
            dataPath + "2.png",
            dataPath + "3.png",
            dataPath + "4.png",
            dataPath + "5.png",
            dataPath + "6.png",
            dataPath + "7.png",
            dataPath + "8.png",
            dataPath + "9.png",



        ]
        const heart_array = [
            heartPath + "0.png",
            heartPath + "1.png",
            heartPath + "2.png",
            heartPath + "3.png",
            heartPath + "4.png",
            heartPath + "5.png",
            heartPath + "6.png",
            heartPath + "7.png",
            heartPath + "8.png",
            heartPath + "9.png",
        ]
    
        const step_array = [
            stepPath + "0.png",
            stepPath + "1.png",
            stepPath + "2.png",
            stepPath + "3.png",
            stepPath + "4.png",
            stepPath + "5.png",
            stepPath + "6.png",
            stepPath + "7.png",
            stepPath + "8.png",
            stepPath + "9.png",
        ]

        const t_array = [
            tPath + "0.png",
            tPath + "1.png",
            tPath + "2.png",
            tPath + "3.png",
            tPath + "4.png",
            tPath + "5.png",
            tPath + "6.png",
            tPath + "7.png",
            tPath + "8.png",
            tPath + "9.png",
        ]
        const week_array = [

            weekPath + "1.png",
            weekPath + "2.png",
            weekPath + "3.png",
            weekPath + "4.png",
            weekPath + "5.png",
            weekPath + "6.png",
            weekPath + "7.png",

        ]
        const time_array = [
            timePath + "0.png",
            timePath + "1.png",
            timePath + "2.png",
            timePath + "3.png",
            timePath + "4.png",
            timePath + "5.png",
            timePath + "6.png",
            timePath + "7.png",
            timePath + "8.png",
            timePath + "9.png",
        ]
     
        let animResident = null
        let animCreate = null
        const logger = DeviceRuntimeCore.HmLogger.getLogger("sanjiao");
        __$$module$$__.module = DeviceRuntimeCore.Page({

            _animNext() {
                animResident.setProperty(hmUI.prop.ANIM_STATUS, 1);
                animCreate.setProperty(hmUI.prop.VISIBLE, false);
                animResidentY.setProperty(hmUI.prop.ANIM_STATUS, 1);
                animCreateY.setProperty(hmUI.prop.VISIBLE, false);
            },

            init_view() {

                let bg_img = hmUI.createWidget(hmUI.widget.IMG, {  //背景
                    x: 0,
                    y: 0,
                    w: 454,
                    h: 454,
                    src: bgPath + "bg.png",
                    show_level: hmUI.show_level.ONLY_NORMAL
                })

                //===========================animation========================


                var screenType = hmSetting.getScreenType();
                var nomalModel = screenType == hmSetting.screen_type.APP || screenType == hmSetting.screen_type.WATCHFACE;
                var aodModel = screenType == hmSetting.screen_type.AOD;
                if (nomalModel) {
                    // bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
                    //     x: 0,
                    //     y: 0,
                    //     // w: 480,
                    //     // h: 480,
                    //     color: 0x000000,
                    // });
                    animResident = hmUI.createWidget(hmUI.widget.IMG_ANIM);
                    animResident.setProperty(hmUI.prop.MORE, {

                        y: 266,
                        x: 2,
                        w: 192,
                        h: 150,
                        align_h: hmUI.align.CENTER_H, // 横轴  
                        align_v: hmUI.align.CENTER_V,// 竖轴
                        anim_path: ROOTPATH + "anims", //文件路径   文件夹的名称
                        anim_prefix: "Madrid", //相当于图片的前缀
                        anim_ext: "png", //图片的后缀以或者图片的格式
                        anim_fps: 10, //图片的播放速度
                        anim_size: 9,//图片的数量
                        anim_repeat: true, //开启循环播放                     
                        repeat_count: 1,//0位无限重复
                        anim_status: 1, //  1  开启动画   0  //  关闭动画

                    });
                    animResidentY = hmUI.createWidget(hmUI.widget.IMG_ANIM);
                    animResidentY.setProperty(hmUI.prop.MORE, {
                        x: 2,
                        y: 232.78,
                        w: 454,
                        h: 37,
                        align_h: hmUI.align.CENTER_H,
                        align_v: hmUI.align.CENTER_V,
                        anim_path: ROOTPATH + "animsY",
                        anim_prefix: "Madrid",
                        anim_ext: "png",
                        anim_fps: 12, //播放速度
                        anim_size: 13,//图片的数量                       
                        anim_repeat: true,
                        repeat_count: 210,
                        anim_status: 1,
                    });
                }

                //==================================================================


                let step = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 30,
                    y: 253,
                    type: hmUI.data_type.STEP,
                    font_array: step_array,
                    h_space: -2,   //图片间隔                   
                    align_h: hmUI.align.LEFT,
                    padding: false, //不需要补零  //是否补零 true为补零                       
                    show_level: hmUI.show_level.ONLY_NORMAL


                });
                let weather = hmUI.createWidget(hmUI.widget.TEXT_IMG, {  //温度
                    x: 315,
                    y: 41,                  
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: t_array,
                    h_space: 1,
                    //图片间隔
                    align_h: hmUI.align.LEFT,
                    unit_sc: "images/T/dushu.png",
                    // //单位
                    unit_tc: "images/T/dushu.png",
                    // //单位
                    unit_en: "images/T/dushu.png",
                    negative_image: "images/T/fushu.png",  //负号图片
                    
                    padding: false,  //不需要补零   //是否补零 true为补零   
                    

                    invalid_image: "images/T/none.png",  //无数据显示
                    show_level: hmUI.show_level.ONLY_NORMAL


                });
                let battery = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 330,
                    y: 164,
                    type: hmUI.data_type.BATTERY,
                    font_array: battery_array,
                    h_space: 0,
                    //图片间隔
                    align_h: hmUI.align.RIGHT,

                    unit_sc: "images/battery/baifenhao.png",
                    // //单位
                    unit_tc: "images/battery/baifenhao.png",
                    // //单位
                    unit_en: "images/battery/baifenhao.png",

                    // invalid_image: "images/sky/number/none.png",
                    // 无数据时显示的图片
                    padding: false,//不需要补零   //是否补零 true为补零  
                                 
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                let heart = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 93,
                    y: 155,
                    type: hmUI.data_type.HEART,
                    font_array: heart_array,
                    h_space: 0,  //图片间隔                    
                    align_h: hmUI.align.RIGHT,
                    padding: true,   //不需要补零   //是否补零 true为补零                         
                    invalid_image: "images/heart/none.png",    // 无数据时显示的图片                   
                    show_level: hmUI.show_level.ONLY_NORMAL
                });


                let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1, //补零
                    hour_startX: 151,
                    hour_startY: 27,
                    hour_array: time_array,
                    hour_space: 0, //每个数组间的间隔
                    minute_zero: 1, //补零
                    minute_startX: 239,
                    minute_startY: 27,
                    minute_array: time_array,
                    minute_space: 0, //每个数组间的间隔
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                let maohao_img = hmUI.createWidget(hmUI.widget.IMG, { //冒号
                    x: 215,
                    y: 38,
                    src: "images/time/maohao.png",
                    show_level: hmUI.show_level.ONLY_NORMAL
                })

                let YTD = hmUI.createWidget(hmUI.widget.IMG_DATE, {

                    month_startX: 151,
                    month_startY: 85,
                    month_unit_sc: dataPath + "henggang.png", //单位
                    month_unit_tc: dataPath + "henggang.png",
                    month_unit_en: dataPath + "henggang.png",
                    month_align: hmUI.align.CENTER_H,
                    month_space: -1,//文字间隔
                    month_zero: 1,//补零
                    month_follow: 0,//不跟随
                    month_en_array: data_array,
                    month_sc_array: data_array,
                    month_tc_array: data_array,
                    //  month_is_character: true,  //会影响补零

                    day_startX: 197,
                    day_startY: 85,
                    day_unit_sc: dataPath + "henggang.png", //单位
                    day_unit_tc: dataPath + "henggang.png",
                    day_unit_en: dataPath + "henggang.png",
                    day_align: hmUI.align.CENTER_H,
                    day_space: -1,//文字间隔
                    day_zero: 1,//补零 
                    day_follow: 0,//不跟随
                    day_en_array: data_array,
                    day_sc_array: data_array,
                    day_tc_array: data_array,
                    // day_is_character: true,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });


                let week = hmUI.createWidget(hmUI.widget.IMG_WEEK, { //周
                    x: 244,
                    y: 85,
                    week_en: week_array,
                    week_tc: week_array,
                    week_sc: week_array,
                    show_level: hmUI.show_level.ONLY_NORMAL

                });
                let AOD_timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1, //补零
                    hour_startX: 151,
                    hour_startY: 27,
                    hour_array: time_array,
                    hour_space: 0, //每个字间的间隔
                    minute_zero: 1, //补零
                    minute_startX: 239,
                    minute_startY: 27,
                    minute_array: time_array,
                    minute_space: 0, //每个数字间的间隔

                    show_level: hmUI.show_level.ONAL_AOD
                });

                let AOD_maohao_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 215,
                    y: 38,
                    src: "images/time/maohao.png",
                    show_level: hmUI.show_level.ONAL_AOD
                })


            },

            onInit() {
                console.log('index page.js on init invoke')
                this.init_view();
            },

            onReady() {
                console.log('index page.js on ready invoke')
            },

            onShow() {
                console.log('index page.js on show invoke')
            },

            onHide() {
                console.log('index page.js on hide invoke')
            },

            onDestory() {
                console.log('index page.js on destory invoke')
            },
        });
        /*
        * end js
        */
    })()
} catch (e) {
    console.log(e)
}
