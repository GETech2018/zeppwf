try {
  (() => {
    var e = __$$hmAppManager$$__.currentApp;
    const n = e.current,
      { px: _ } =
        (new DeviceRuntimeCore.WidgetFactory(
          new DeviceRuntimeCore.HmDomApi(e, n)
        ),
        e.app.__globals__),
      o = Logger.getLogger("watchface6");
    n.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
          edit_id: 1,
          x: 0,
          y: 0,
          bg_config: [
            { id: 1, path: "4.png", preview: "4.png" },
            { id: 2, path: "5.png", preview: "5.png" },
            { id: 3, path: "6.png", preview: "6.png" },
          ],
          count: 3,
          default_id: 1,
          fg: "3.png",
          tips_x: 147,
          tips_y: 20,
          tips_bg: "2.png",
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
        }),
          hmUI.createWidget(hmUI.widget.TIME_POINTER, {
            hour_centerX: 227,
            hour_centerY: 227,
            hour_posX: 227,
            hour_posY: 227,
            hour_path: "7.png",
            hour_cover_x: 227,
            hour_cover_y: 227,
            enable: !1,
            show_level: hmUI.show_level.ONLY_NORMAL,
          }),
          hmUI.createWidget(hmUI.widget.TIME_POINTER, {
            second_centerX: 227,
            second_centerY: 227,
            second_posX: 227,
            second_posY: 227,
            second_path: "9.png",
            second_cover_x: 227,
            second_cover_y: 227,
            enable: !1,
            show_level: hmUI.show_level.ONLY_NORMAL,
          }),
          hmUI.createWidget(hmUI.widget.TIME_POINTER, {
            minute_centerX: 227,
            minute_centerY: 227,
            minute_posX: 8,
            minute_posY: 227,
            minute_path: "8.png",
            minute_cover_x: 0,
            minute_cover_y: 0,
            enable: !1,
            show_level: hmUI.show_level.ONLY_NORMAL,
          }),
          hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
            center_x: 227,
            center_y: 227,
            radius: 226,
            start_angle: 180,
            end_angle: -180,
            color: 4286348412,
            line_width: 3,
            type: hmUI.data_type.STEP,
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
      },
      onInit() {
        o.log("index page.js on init invoke");
      },
      build() {
        this.init_view(), o.log("index page.js on ready invoke");
      },
      onDestory() {
        o.log("index page.js on destory invoke");
      },
    });
  })();
} catch (e) {
  console.log(e);
}
