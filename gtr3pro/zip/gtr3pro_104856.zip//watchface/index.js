
    /*
    ** huamiOS bundle tool v1.0.17
    * *huamiOS watchface js version v1.0.1
    * *Copyright © Huami. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start
        let normal$_$background$_$bg = ''
        let normal$_$analog_clock$_$time_pointer = ''
        let idle$_$analog_clock$_$time_pointer = ''
        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            normal$_$background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$analog_clock$_$time_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 25,
              hour_posY: 240,
              hour_path: '2.png',
              hour_cover_path: '',
              hour_cover_x: 0,
              hour_cover_y: 0,
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 25,
              minute_posY: 240,
              minute_path: '3.png',
              minute_cover_path: '',
              minute_cover_x: 0,
              minute_cover_y: 0,
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 25,
              second_posY: 240,
              second_path: '4.png',
              second_cover_path: '',
              second_cover_x: 0,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            idle$_$analog_clock$_$time_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 25,
              hour_posY: 240,
              hour_path: '5.png',
              hour_cover_path: '',
              hour_cover_x: 0,
              hour_cover_y: 0,
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 25,
              minute_posY: 240,
              minute_path: '7.png',
              minute_cover_path: '6.png',
              minute_cover_x: 224,
              minute_cover_y: 224,
              show_level: hmUI.show_level.ONAL_AOD,
            });
  
            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  