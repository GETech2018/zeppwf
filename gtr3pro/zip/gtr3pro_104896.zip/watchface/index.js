try {
    (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;

        var __$$module$$__ = __$$app$$__.current;
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        /*
    * huamiOS bundle tool v1.0.17
    * Copyright © Huami. All Rights Reserved
    */
        'use strict';

        console.log("----->>>current")
        console.log(__$$hmAppManager$$__.currentApp.pid)
        console.log(__$$hmAppManager$$__.currentApp.current)
        const ASCII_START = 65; //A
        const rootPath = "images/";
        let worldCount = 0

        let img_bg = null

        let world_clock = null;
        let timePointer = null;
        let worldPointer = null;
        let timeSec = null;
        let timeZone = null;
        let timeHourImg = null;
        let gmtImg = null;
        let dataArr = null;
        const cityArrayImg = new Array(3);
        const ASSIC_MAX_COUNT = 26;
        const ASCIIARRAY = new Array(ASSIC_MAX_COUNT);

        function setJsWidgetVisible(widget,visible){
            if(widget != null){
                widget.setProperty(hmUI.prop.VISIBLE, visible);
            }
        }
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            
            showTimeZone(timeZoneHour) {
                var path = rootPath + "img/jian.png";
                if (timeZoneHour > 0) {
                    path = rootPath + "img/jia.png";
                }

                //console.log("timeZoneHour====================+++++++++++++++++====" + timeZoneHour);
                var path2 = rootPath + "hour/" + Math.abs(timeZoneHour) + ".png";
                timeZone.setProperty(hmUI.prop.SRC, path);
                timeHourImg.setProperty(hmUI.prop.SRC, path2);
            },
            showCity(cityCode) {
                let index = 0;
                let maxWidth = 0;
                let path = 0;
                let sizeArray = new Array(3);

                for (let char of cityCode) {
                    const charCode = char.charCodeAt();
                    if (charCode < ASCII_START) {
                        continue;
                    }
                    if (index >= 3) {
                        break;
                    }
                    path = ASCIIARRAY[charCode - ASCII_START];
                    const imageInfo = hmUI.getImageInfo(path);
                    sizeArray[index] = imageInfo.width;
                    maxWidth += imageInfo.width;
                    cityArrayImg[index++].setProperty(hmUI.prop.SRC, ASCIIARRAY[charCode - ASCII_START]);
                }
                const bMWidth = 132;
                const baseX = 174;
                let startX = baseX + (bMWidth - maxWidth) / 2;
                for (var i = 0; i < 3; i++) {
                    cityArrayImg[i].setProperty(hmUI.prop.X, startX);
                    startX += sizeArray[i];
                }

            },
            setWorldAngle(hour,min) {
                var angle = 15 * hour + min * 0.25;  //min= 360/24/60=0.25; hour= 360/24=15;
                console.log(hour+"==hour angle====================+++++++++++++++++====:" + angle);
                worldPointer.setProperty(hmUI.prop.ANGLE, angle);

            },
            // setWorldAngle(hour,min) {
            //     var angle = 15 * hour + min;
            //     console.log(hour+"==hour angle====================+++++++++++++++++====:" + angle);
            //     worldPointer.setProperty(hmUI.prop.ANGLE, angle);

            // },
            init_view() {
                let assicIndex = 0;
                for (var i = ASCII_START; i < ASCII_START + 26; i++) {
                    const path = rootPath + "cityCode/" + String.fromCharCode(i) + ".png";
                    ASCIIARRAY[assicIndex++] = path;
                    console.log("assic path =" + path);
                }
                dataArr = [
                    rootPath + "data/0.png",
                    rootPath + "data/1.png",
                    rootPath + "data/2.png",
                    rootPath + "data/3.png",
                    rootPath + "data/4.png",
                    rootPath + "data/5.png",
                    rootPath + "data/6.png",
                    rootPath + "data/7.png",
                    rootPath + "data/8.png",
                    rootPath + "data/9.png",
                ]

                var screenType = hmSetting.getScreenType();
                world_clock = hmSensor.createSensor(hmSensor.id.WORLD_CLOCK);
                if (screenType == hmSetting.screen_type.AOD) {
                    img_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
                        x: 0,
                        y: 0,
                        w: 480,
                        h: 480,
                        color: 0x000000,
                        show_level: hmUI.show_level.ONAL_AOD,
                    })
                } else {
                    img_bg = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 0,
                        y: 0,
                        w: 480,
                        h: 480,
                        src: rootPath + "img/bg.png",
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                }   

                gmtImg = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 214,
                    y: 345,
                    w: 32,
                    h: 22,
                    src: rootPath + "img/GMT.png",
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                let calPointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    center_x: 128,
                    center_y: 240,
                    x: 25,
                    y: 78,
                    start_angle: 0,
                    end_angle: 360,
                    type: hmUI.data_type.CAL,
                    src: rootPath + "img/pointer.png",
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                let calTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 112,
                    y: 258,
                    type: hmUI.data_type.CAL,
                    font_array: dataArr,
                    h_space: 0, //图片间隔
                    align_h: hmUI.align.CENTER_H,
                    //invalid_image:"none.png",// 无数据时显示的图片
                    padding: false, //是否补零 true为补零
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                let stepPointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    center_x: 240,
                    center_y: 150,
                    x: 25,
                    y: 78,
                    start_angle: 0,
                    end_angle: 360,
                    type: hmUI.data_type.STEP,
                    src: rootPath + "img/pointer.png",
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                let stepTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 219,
                    y: 170,
                    type: hmUI.data_type.STEP,
                    font_array: dataArr,
                    h_space: 0, //图片间隔
                    align_h: hmUI.align.CENTER_H,
                    padding: false, //是否补零 true为补零
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                let paiPointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    center_x: 353,
                    center_y: 240,
                    x: 25,
                    y: 78,
                    start_angle: 0,
                    end_angle: 360,
                    type: hmUI.data_type.PAI_DAILY,
                    src: rootPath + "img/pointer.png",
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    
                });
                let paiTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 342,
                    y: 258,
                    type: hmUI.data_type.PAI_DAILY,
                    font_array: dataArr,
                    h_space: 0, //图片间隔
                    align_h: hmUI.align.CENTER_H,
                    padding: false, //是否补零 true为补零
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
  
                    //world  clock=-----------------
                    for (var i = 0; i < 3; i++) {
                        cityArrayImg[i] = hmUI.createWidget(hmUI.widget.IMG, {
                            x: 211,
                            y: 297,
                            // w: 20,
                            // h: 28,
                            show_level: hmUI.show_level.ONLY_NORMAL,
                        });
                    }
                    timeZone = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 245,
                        y: 346,
                        w: 10,
                        h: 22,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                    timeHourImg = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 258,
                        y: 346,
                        w: 20,
                        h: 22,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                var noData = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 212,
                    y: 305,
                    w: 56,
                    h: 56,  
                    src: rootPath + "img/nodata.png",
                    show_level: hmUI.show_level.ONLY_NORMAL,
                })
                noData.setProperty(hmUI.prop.VISIBLE, false);
                worldPointer = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 480,//display screen width
                    h: 480,//display screen height
                    pos_x: 240 - 25,
                    pos_y: 240 - 235,
                    center_x: 240,
                    center_y: 240,
                    angle: 0,
                    src: rootPath + "img/worldPointer.png",
                });
                timePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER);
                // timePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                //     hour_centerX: 240,
                //     hour_centerY: 240,
                //     hour_posX: 28,
                //     hour_posY: 188,
                //     hour_path: rootPath + "img/hour.png",

                //     minute_centerX: 240,
                //     minute_centerY: 240,
                //     minute_posX: 26,
                //     minute_posY: 228,
                //     minute_path: rootPath + "img/min.png",

                //     // minute_cover_path: rootPath + "img/min_cover.png", //指针圆心图片
                //     // minute_cover_y: 227,
                //     // minute_cover_x: 227,
                //     show_level: hmUI.show_level.ALL,
                // });

               
                world_clock.init();
                worldCount = world_clock.getWorldClockCount();
                //console.log("count====10014========================+++++++++++++++++:::::" + worldCount);
                if (worldCount > 0) {
                    noData.setProperty(hmUI.prop.VISIBLE, false);
                    setJsWidgetVisible(worldPointer,true);
                    setJsWidgetVisible(timeZone,true);
                    setJsWidgetVisible(timeHourImg,true);
                    setJsWidgetVisible(gmtImg,true);
                    let worldData = world_clock.getWorldClockInfo(0);

                    //console.log("worldCityName====================" + worldData.city);
                    console.log("worldCityCode====================" + worldData.city);
                    console.log("worldHour=====================" + worldData.hour);
                    console.log("worldMinute===================== ------------------------- "+worldData.minute);   
                    if (screenType != hmSetting.screen_type.AOD) {
                        this.showCity(worldData.cityCode);
                        this.showTimeZone(worldData.timeZoneHour);
                    }
                    this.setWorldAngle(worldData.hour,worldData.minute);
                } else {
                    for (var i = 0; i < 3; i++) {
                        cityArrayImg[i].setProperty(hmUI.prop.VISIBLE, false);
                    }
                    worldPointer.setProperty(hmUI.prop.VISIBLE, false);
                    timeZone.setProperty(hmUI.prop.VISIBLE,false);
                    timeHourImg.setProperty(hmUI.prop.VISIBLE,false);
                    gmtImg.setProperty(hmUI.prop.VISIBLE,false);
                    noData.setProperty(hmUI.prop.VISIBLE, true);
                }
                world_clock.uninit();
                if (screenType == hmSetting.screen_type.AOD) {
                    timePointer.setProperty(hmUI.prop.MORE, {
                        hour_centerX: 240,
                        hour_centerY: 240,
                        hour_posX: 28,
                        hour_posY: 188,
                        hour_path: rootPath + "img/hour.png",
    
                        minute_centerX: 240,
                        minute_centerY: 240,
                        minute_posX: 26,
                        minute_posY: 228,
                        minute_path: rootPath + "img/min.png",
    
                        minute_cover_path: rootPath + "img/cover_xp.png", 
                        minute_cover_x: 227,
                        minute_cover_y: 227,
                        show_level: hmUI.show_level.ONAL_AOD,
                    });

                } else {
                    timePointer.setProperty(hmUI.prop.MORE, {
                        hour_centerX: 240,
                        hour_centerY: 240,
                        hour_posX: 28,
                        hour_posY: 188,
                        hour_path: rootPath + "img/hour.png",
    
                        minute_centerX: 240,
                        minute_centerY: 240,
                        minute_posX: 26,
                        minute_posY: 228,
                        minute_path: rootPath + "img/min.png",
 
                        second_centerX: 240,
                        second_centerY: 240,
                        second_posX: 17,
                        second_posY: 230,
                        second_path: rootPath + "img/sec.png",

                        second_cover_path: rootPath + "img/sec_cover.png", //指针圆心图片
                        second_cover_y: 232,
                        second_cover_x: 232,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                };
                const vDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: (function () {
                        console.log('ui resume');
                        world_clock.init();
                        worldCount = world_clock.getWorldClockCount();
                        if (worldCount > 0) {
                             noData.setProperty(hmUI.prop.VISIBLE, false);
                            worldPointer.setProperty(hmUI.prop.VISIBLE, true);
                            timeZone.setProperty(hmUI.prop.VISIBLE,true);
                            timeHourImg.setProperty(hmUI.prop.VISIBLE,true);
                            gmtImg.setProperty(hmUI.prop.VISIBLE,true);
                            let worldData = world_clock.getWorldClockInfo(0);
                            let hour = worldData.hour;
                            let min = worldData.minute;
                            var angle = 15 * hour + min * 0.25;  //min= 360/24/60=0.25; hour= 360/24=15;
                            console.log( worldData.hour+ "=hour angle====================+++++++++++++++++====min" + min);
                            worldPointer.setProperty(hmUI.prop.ANGLE, angle);
                            if (!(screenType == hmSetting.screen_type.AOD)) {
                                let index = 0;
                                let maxWidth = 0;
                                let path = 0;
                                let sizeArray = new Array(3);
                
                                for (let char of worldData.cityCode) {
                                    const charCode = char.charCodeAt();
                                    if (charCode < ASCII_START) {
                                        continue;
                                    }
                                    if (index >= 3) {
                                        break;
                                    }
                                    path = ASCIIARRAY[charCode - ASCII_START];
                                    const imageInfo = hmUI.getImageInfo(path);
                                    sizeArray[index] = imageInfo.width;
                                    maxWidth += imageInfo.width;
                                    cityArrayImg[index].setProperty(hmUI.prop.VISIBLE,true);
                                    cityArrayImg[index++].setProperty(hmUI.prop.SRC, ASCIIARRAY[charCode - ASCII_START]);

                                }
                                const bMWidth = 132;
                                const baseX = 174;
                                let startX = baseX + (bMWidth - maxWidth) / 2;
                                for (var i = 0; i < 3; i++) {
                                    cityArrayImg[i].setProperty(hmUI.prop.X, startX);
                                    startX += sizeArray[i];
                                }
                                // this.showTimeZone(worldData.timeZoneHour);
                                path = rootPath + "img/jian.png";
                                if (worldData.timeZoneHour > 0) {
                                    path = rootPath + "img/jia.png";
                                }
                
                                console.log("timeZoneHour====================+++++++++++++++++====" + worldData.timeZoneHour);
                                var path2 = rootPath + "hour/" + Math.abs(worldData.timeZoneHour) + ".png";
                                timeZone.setProperty(hmUI.prop.SRC, path);
                                timeHourImg.setProperty(hmUI.prop.SRC, path2);
                            }
                        }else{
                            for (var i = 0; i < 3; i++) {
                                cityArrayImg[i].setProperty(hmUI.prop.VISIBLE, false);
                            }
                            worldPointer.setProperty(hmUI.prop.VISIBLE, false);
                            timeZone.setProperty(hmUI.prop.VISIBLE,false);
                            timeHourImg.setProperty(hmUI.prop.VISIBLE,false);
                            gmtImg.setProperty(hmUI.prop.VISIBLE,false);
                            noData.setProperty(hmUI.prop.VISIBLE, true);
                            
                        }
                        world_clock.uninit();
                    }),
                    pause_call: (function () {
                        console.log('ui pause');
                    }),

                });
            },

            onInit() {
                console.log('index page.js on init invoke')

                this.init_view();



            },

            onReady() {
                console.log('index page.js on ready invoke')
            },

            onShow() {
                console.log('index page.js on show invoke')
            },

            onHide() {
                console.log('index page.js on hide invoke')
            },

            onDestory() {
                console.log('index page.js on destory invoke');
              
            },
        });
        /*
        * end js
        */
    })()
} catch (e) {
    console.log(e)
}
