try {
    (() => {
    
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
  
    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');
  
      /*
    * huamiOS bundle tool v1.0.17
    * Copyright © Huami. All Rights Reserved
    */
    'use strict';
  
    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let rootPath = null
    let weekScArray = null
    let weekEnArray = null
    let fontArray = null
    let timeArray = null
    let dontPath = null
    let bg = null
    let btText = null
    let btIcon = null
    let week = null
    let month = null
    let animCreate = null
    let time = null
    let size = 'middle'
    let editGroup = null
    const logger = DeviceRuntimeCore.HmLogger.getLogger("defult");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
        
       

        init_view() {
            rootPath = "images/";
            weekScArray = [
                 rootPath+"num/"+size+"/week_sc/01.png",
                 rootPath+"num/"+size+"/week_sc/02.png",
                 rootPath+"num/"+size+"/week_sc/03.png",
                 rootPath+"num/"+size+"/week_sc/04.png",
                 rootPath+"num/"+size+"/week_sc/05.png",
                 rootPath+"num/"+size+"/week_sc/06.png",
                 rootPath+"num/"+size+"/week_sc/07.png",
            ];
            weekEnArray = [
                 rootPath+"num/"+size+"/week_en/01.png",
                 rootPath+"num/"+size+"/week_en/02.png",
                 rootPath+"num/"+size+"/week_en/03.png",
                 rootPath+"num/"+size+"/week_en/04.png",
                 rootPath+"num/"+size+"/week_en/05.png",
                 rootPath+"num/"+size+"/week_en/06.png",
                 rootPath+"num/"+size+"/week_en/07.png",
            ];
            fontArray = [
                 rootPath+"num/"+size+"/data/00.png",
                 rootPath+"num/"+size+"/data/01.png",
                 rootPath+"num/"+size+"/data/02.png",
                 rootPath+"num/"+size+"/data/03.png",
                 rootPath+"num/"+size+"/data/04.png",
                 rootPath+"num/"+size+"/data/05.png",
                 rootPath+"num/"+size+"/data/06.png",
                 rootPath+"num/"+size+"/data/07.png",
                 rootPath+"num/"+size+"/data/08.png",
                 rootPath+"num/"+size+"/data/09.png",
            ];
            timeArray = [
                rootPath+"num/"+size+"/time/00.png",
                rootPath+"num/"+size+"/time/01.png",
                rootPath+"num/"+size+"/time/02.png",
                rootPath+"num/"+size+"/time/03.png",
                rootPath+"num/"+size+"/time/04.png",
                rootPath+"num/"+size+"/time/05.png",
                rootPath+"num/"+size+"/time/06.png",
                rootPath+"num/"+size+"/time/07.png",
                rootPath+"num/"+size+"/time/08.png",
                rootPath+"num/"+size+"/time/09.png",
            ]
            
            dontPath = rootPath + "num/"+size+"/data/gan.png";
            var screenType = hmSetting.getScreenType();
            var nomalModel = screenType == hmSetting.screen_type.APP || screenType == hmSetting.screen_type.WATCHFACE;
            var aodModel = screenType == hmSetting.screen_type.AOD;
            
            let bg =  hmUI.createWidget(hmUI.widget.IMG,{
                x: 0,
                y: 0,
                w:480,
                h:480,
                src: rootPath + "bg.png",
                show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
              })
     
            btIcon = hmUI.createWidget(hmUI.widget.IMG,{

                show_level:hmUI.show_level.ONLY_NORMAL | hmSetting.screen_type.AOD
            });
           
            btText = hmUI.createWidget(hmUI.widget.TEXT_IMG,{
                
                show_level:hmUI.show_level.ONLY_NORMAL | hmSetting.screen_type.AOD,
            });
 
            week = hmUI.createWidget(hmUI.widget.IMG_WEEK,{
                x: 325,
                y: 130,
                week_tc:weekScArray,
                week_sc:weekScArray,
                week_en:weekEnArray,
                show_level:hmUI.show_level.ONLY_NORMAL | hmSetting.screen_type.AOD,
            });
            month = hmUI.createWidget(hmUI.widget.IMG_DATE,{
                show_level:hmUI.show_level.ALL,
                month_startX: 200,
                month_startY: 135,
                month_zero:true,
                month_en_array:fontArray,
                month_align:hmUI.align.LEFT,
                month_unit_sc:dontPath,
                month_unit_tc:dontPath,
                month_unit_en:dontPath,
                day_follow:true,
                day_zero:true,
                day_en_array:fontArray,
                show_level:hmUI.show_level.ONLY_NORMAL | hmSetting.screen_type.AOD,
            });
            

            time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                hour_zero: true,
                hour_startX: 120,
                hour_startY: 190,
                hour_array: timeArray,
                hour_space: 0,
                hour_unit_sc: rootPath + "num/"+size+"/time/colon.png", 
                hour_unit_tc: rootPath + "num/"+size+"/time/colon.png", 
                hour_unit_en: rootPath + "num/"+size+"/time/colon.png", 
                hour_align: hmUI.align.LEFT,
                minute_zero: 1, //是否补零 1为补零
                minute_follow: true, //是否跟随
                minute_array:timeArray,
                show_level:hmUI.show_level.ONLY_NORMAL | hmSetting.screen_type.AOD,
            });

        var editConfig = [
            { type: hmUI.edit_type.BATTERY, preview: rootPath + "icon/"+size+"/bat_preview.png" },
            { type: hmUI.edit_type.CAL, preview: rootPath + "icon/"+size+"/cal_preview.png" },
            { type: hmUI.edit_type.HEART, preview: rootPath + "icon/"+size+"/heart_preview.png" },
            { type: hmUI.edit_type.STEP, preview: rootPath + "icon/"+size+"/step_preview.png" },
            { type: hmUI.edit_type.HUMIDITY, preview: rootPath + "icon/"+size+"/humi_preview.png" },
        ];
        editGroup = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
            show_level: hmUI.show_level.ALL,
            edit_id: 101,
            x: 268,
            y: 308,
            w: 165,
            h: 57,
            select_image: rootPath + "edit/selected.png",
            un_select_image: rootPath + "edit/selected.png",
            default_type: hmUI.edit_type.STEP,
            optional_types: editConfig,
            count: editConfig.length,
            tips_BG: rootPath + "edit/tag.png",
            tips_x: 321-288,
            tips_y: 262-308,
            tips_width: 104,
            tips_margin: 10,
        });
        var editType = editGroup.getProperty(hmUI.prop.CURRENT_TYPE);
        var topProp = {
            x: 230,
            y: 308,
            w: 200,
            h: 45,
            h_space: 0,
            align_h: hmUI.align.RIGHT,
            icon_space: 0,
            font_array: fontArray,
        }

        switch (editType) {
            case hmUI.edit_type.HEART:
                topProp.invalid_image = rootPath + "num/"+size+"/data/invalid.png",
                topProp.type = hmUI.data_type.HEART;
                topProp.icon = rootPath + "icon/"+size+"/heart.png";
                btText = hmUI.createWidget(hmUI.widget.TEXT_IMG, topProp);
                break;
            case hmUI.edit_type.BATTERY:
                topProp.invalid_image = rootPath + "num/"+size+"/data/invalid.png",
                topProp.type = hmUI.data_type.BATTERY;
                topProp.icon =  rootPath + "icon/"+size+"/bat.png";
                topProp.unit_en = rootPath + "num/"+size+"/data/per.png",
                topProp.unit_sc = rootPath + "num/"+size+"/data/per.png",
                topProp.unit_tc = rootPath + "num/"+size+"/data/per.png",
                btText = hmUI.createWidget(hmUI.widget.TEXT_IMG, topProp);
                 break;
            case hmUI.edit_type.STEP:
                topProp.type = hmUI.data_type.STEP;
                topProp.icon =  rootPath + "icon/"+size+"/step.png";
                btText = hmUI.createWidget(hmUI.widget.TEXT_IMG, topProp);
                break;
            case hmUI.edit_type.CAL:
                topProp.type = hmUI.data_type.CAL;
                topProp.icon =  rootPath + "icon/"+size+"/cal.png";
                btText = hmUI.createWidget(hmUI.widget.TEXT_IMG, topProp);
                break;
            case hmUI.edit_type.HUMIDITY:
                topProp.type = hmUI.data_type.HUMIDITY;
                topProp.invalid_image = rootPath + "num/"+size+"/data/invalid.png",
                topProp.icon =  rootPath + "icon/"+size+"/humi.png";
                topProp.unit_en = rootPath + "num/"+size+"/data/per.png",
                topProp.unit_sc = rootPath + "num/"+size+"/data/per.png",
                topProp.unit_tc = rootPath + "num/"+size+"/data/per.png",
                btText = hmUI.createWidget(hmUI.widget.TEXT_IMG, topProp);
                break;
        }
        mask100 =  hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK,{
            x: 0,
            y: 0,
            w: 480,
            h: 480,
            src: rootPath + "edit/you.png",
            show_level: hmUI.show_level.ONLY_EDIT,
        }); 

        mask70 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK,{
            x: 0,
            y: 0,
            w: 480,
            h: 480,
            src: rootPath+"edit/mask70.png",
            show_level: hmUI.show_level.ONLY_EDIT,
        });         
            
        
        },

        onInit() {
            console.log('index page.js on init invoke');

            this.init_view();

            
        },

        onReady() {
            console.log('index page.js on ready invoke')
        },

        onShow() {
            console.log('index page.js on show invoke')
        },

        onHide() {
            console.log('index page.js on hide invoke')
        },

        onDestory() {
            console.log('index page.js on destory invoke')
        },
    });
    /*
    * end js
    */
        })()
    } catch (e) {
        console.log(e)
    }