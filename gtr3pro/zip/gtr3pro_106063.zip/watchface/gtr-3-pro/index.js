
try {
  (() => {
  
var __$$app$$__ = __$$hmAppManager$$__.currentApp;

function noTreeShaking() {}

function getApp() {
  return __$$app$$__.app;
}

function getCurrentPage() {
  return __$$app$$__.current && __$$app$$__.current.module;
}

var __$$module$$__ = __$$app$$__.current;
var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
var { px } = getApp().__globals__;

  /*
* ZeppOS bundle tool v2.1.49
* Copyright © Zepp. All Rights Reserved
*/
'use strict';

let min_h = null;
let min_l = null;
let t = new Date();
const logger = Logger.getLogger('watchface');
const img = function (type) {
    return path => type + '/' + path;
}('images');
__$$module$$__.module = DeviceRuntimeCore.WatchFace({
    init_view() {
        time_imgs = [];
        time_dim_imgs = [];
        min_high_imgs = [];
        for (let i = 0; i < 10; i++) {
            time_imgs.push(img(`time/time_0${ i }.png`));
            time_dim_imgs.push(img(`time_dim/time_0${ i }.png`));
            min_high_imgs.push(img(`min_h/time_0${ i }.png`));
        }
        date_imgs = [];
        date_dim_imgs = [];
        for (let i = 0; i < 10; i++) {
            date_imgs.push(img(`date/date_0${ i }.png`));
            date_dim_imgs.push(img(`date_dim/date_0${ i }.png`));
        }
        week_tc_imgs = [];
        week_sc_imgs = [];
        week_en_imgs = [];
        week_tc_dim_imgs = [];
        week_sc_dim_imgs = [];
        week_en_dim_imgs = [];
        for (let i = 1; i <= 7; i++) {
            week_tc_imgs.push(img(`week/week_${ i }_tc.png`));
            week_sc_imgs.push(img(`week/week_${ i }_cn.png`));
            week_en_imgs.push(img(`week/week_${ i }_en.png`));
            week_tc_dim_imgs.push(img(`week_dim/week_${ i }_tc.png`));
            week_sc_dim_imgs.push(img(`week_dim/week_${ i }_cn.png`));
            week_en_dim_imgs.push(img(`week_dim/week_${ i }_en.png`));
        }
        hmUI.createWidget(hmUI.widget.IMG, {
            x: px(0),
            y: px(0),
            w: px(480),
            h: px(480),
            src: img('bg.png'),
            show_level: hmUI.show_level.ONLY_NORMAL
        });
        hmUI.createWidget(hmUI.widget.IMG_ANIM, {
            x: px(0),
            y: px(0),
            anim_path: img('anim'),
            anim_prefix: 'anim',
            anim_ext: 'png',
            anim_fps: 10,
            anim_size: 16,
            anim_repeat: true,
            repeat_count: 255,
            anim_status: hmUI.anim_status.START,
            show_level: hmUI.show_level.ONLY_NORMAL
        });
        hmUI.createWidget(hmUI.widget.IMG_TIME, {
            hour_zero: 1,
            hour_startX: px(75),
            hour_startY: px(123),
            hour_array: time_imgs,
            hour_space: px(7),
            hour_align: hmUI.align.LEFT,
            minute_zero: 1,
            minute_startX: px(254),
            minute_startY: px(102),
            minute_array: [],
            minute_space: px(3),
            minute_align: hmUI.align.LEFT,
            minute_follow: 0,
            am_x: px(86),
            am_y: px(85),
            am_sc_path: img('am_cn.png'),
            am_en_path: img('am_en.png'),
            pm_x: px(86),
            pm_y: px(85),
            pm_sc_path: img('pm_cn.png'),
            pm_en_path: img('pm_en.png'),
            show_level: hmUI.show_level.ONLY_NORMAL
        });
        hmUI.createWidget(hmUI.widget.IMG, {
            x: px(208),
            y: px(123),
            w: px(65),
            h: px(93),
            src: img('time/time_m.png'),
            show_level: hmUI.show_level.ONLY_NORMAL
        });
        hmUI.createWidget(hmUI.widget.IMG_TIME, {
            hour_zero: 1,
            hour_startX: px(75),
            hour_startY: px(123),
            hour_array: time_dim_imgs,
            hour_space: px(7),
            hour_align: hmUI.align.LEFT,
            minute_zero: 1,
            minute_startX: px(268),
            minute_startY: px(123),
            minute_array: time_dim_imgs,
            minute_space: px(7),
            minute_align: hmUI.align.LEFT,
            minute_follow: 0,
            am_x: px(86),
            am_y: px(85),
            am_sc_path: img('am_cn.png'),
            am_en_path: img('am_en.png'),
            pm_x: px(86),
            pm_y: px(85),
            pm_sc_path: img('pm_cn.png'),
            pm_en_path: img('pm_en.png'),
            show_level: hmUI.show_level.ONLY_AOD
        });
        hmUI.createWidget(hmUI.widget.IMG, {
            x: px(208),
            y: px(123),
            w: px(65),
            h: px(93),
            src: img('time_dim/time_m.png'),
            show_level: hmUI.show_level.ONLY_AOD
        });
        min_h = hmUI.createWidget(hmUI.widget.IMG, {
            x: px(268),
            y: px(123),
            w: px(65),
            h: px(93),
            src: '',
            show_level: hmUI.show_level.ONLY_NORMAL
        });
        min_l = hmUI.createWidget(hmUI.widget.IMG, {
            x: px(339),
            y: px(123),
            w: px(65),
            h: px(93),
            src: '',
            show_level: hmUI.show_level.ONLY_NORMAL
        });
        hmUI.createWidget(hmUI.widget.IMG_DATE, {
            month_unit_sc: img('date/date_s.png'),
            month_unit_tc: img('date/date_s.png'),
            month_unit_en: img('date/date_s.png'),
            month_startX: px(271),
            month_startY: px(85),
            month_sc_array: date_imgs,
            month_tc_array: date_imgs,
            month_en_array: date_imgs,
            month_align: hmUI.align.LEFT,
            month_zero: 1,
            month_follow: 0,
            month_space: px(0),
            month_is_character: false,
            day_startX: px(355),
            day_startY: px(85),
            day_sc_array: date_imgs,
            day_tc_array: date_imgs,
            day_en_array: date_imgs,
            day_align: hmUI.align.LEFT,
            day_zero: 1,
            day_follow: 1,
            day_space: px(0),
            day_is_character: false,
            show_level: hmUI.show_level.ONLY_NORMAL
        });
        hmUI.createWidget(hmUI.widget.IMG_DATE, {
            month_unit_sc: img('date_dim/date_s.png'),
            month_unit_tc: img('date_dim/date_s.png'),
            month_unit_en: img('date_dim/date_s.png'),
            month_startX: px(271),
            month_startY: px(85),
            month_sc_array: date_dim_imgs,
            month_tc_array: date_dim_imgs,
            month_en_array: date_dim_imgs,
            month_align: hmUI.align.LEFT,
            month_zero: 1,
            month_follow: 0,
            month_space: px(0),
            month_is_character: false,
            day_startX: px(355),
            day_startY: px(85),
            day_sc_array: date_dim_imgs,
            day_tc_array: date_dim_imgs,
            day_en_array: date_dim_imgs,
            day_align: hmUI.align.LEFT,
            day_zero: 1,
            day_follow: 1,
            day_space: px(0),
            day_is_character: false,
            show_level: hmUI.show_level.ONLY_AOD
        });
        hmUI.createWidget(hmUI.widget.IMG_WEEK, {
            x: 144,
            y: 85,
            week_en: week_en_imgs,
            week_tc: week_tc_imgs,
            week_sc: week_sc_imgs,
            show_level: hmUI.show_level.ONLY_NORMAL
        });
        hmUI.createWidget(hmUI.widget.IMG_WEEK, {
            x: 144,
            y: 85,
            week_en: week_en_dim_imgs,
            week_tc: week_tc_dim_imgs,
            week_sc: week_sc_dim_imgs,
            show_level: hmUI.show_level.ONLY_AOD
        });
        function setMin() {
            t.setTime(Date.now());
            min_h.setProperty(hmUI.prop.SRC, min_high_imgs[parseInt(t.getMinutes() / 10)]);
            min_l.setProperty(hmUI.prop.SRC, time_imgs[parseInt(t.getMinutes() % 10)]);
        }
        setMin();
        hourtimer = timer.createTimer(10, 1000, setMin, {});
    },
    onInit() {
        logger.log('index page.js on init invoke');
    },
    build() {
        logger.log('index page.js on build invoke');
        this.init_view();
    },
    onDestory() {
        logger.log('index page.js on destory invoke');
    }
});
/*
* end js
*/

  ;
  })()
} catch(e) {
  console.log(e)
  /* todo */
}