try {
    (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;

        var __$$module$$__ = __$$app$$__.current;
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        /*
      * huamiOS bundle tool v1.0.17
      * Copyright © Huami. All Rights Reserved
      */
        'use strict';

        console.log("----->>>current");
        console.log(__$$hmAppManager$$__.currentApp.pid);
        console.log(__$$hmAppManager$$__.currentApp.current);

        let rootPath = null
        let timeArray = null

        let dataArray = null
        let img_bkg = null
        let monthArray = null
        let timePointer = null
        let week = null
        let weekArray = null
        let batArr = null
        let stepArr = null

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

            init_view() {
                let rootPath = "images/";
                let screenType = hmSetting.getScreenType()
                if (screenType == hmSetting.screen_type.AOD) {
                    let img_bg = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 0,
                        y: 0,
                        w: 480,
                        h: 480,
                        src: rootPath + "background/black.png",
                    })

                    let twelve_bg = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 171.88,
                        y: 35.76,
                        src: rootPath + "img/12.png",
                    })

                    let three_bg = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 368.14,
                        y: 202.76,
                        src: rootPath + "img/3.png",
                    })

                    let six_bg = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 203,
                        y: 375,
                        src: rootPath + "img/6.png",
                    })

                    let nine_bg = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 34.67,
                        y: 201.89,
                        src: rootPath + "img/9.png",
                    })

                    let timePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                        hour_centerX: 240,
                        hour_centerY: 240,
                        hour_posX: 22,
                        hour_posY: 201,
                        hour_path: rootPath + 'img/hour.png',

                        minute_centerX: 240,
                        minute_centerY: 240,
                        minute_posX: 16,
                        minute_posY: 239,
                        minute_path: rootPath + 'img/minute.png',
                    });

                    let center_bg = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 228.5,
                        y: 228.5,
                        src: rootPath + "img/center.png",
                    })
                } else {
                    let jstime = hmSensor.createSensor(hmSensor.id.TIME);
                    let h = jstime.hour >= 12 ? jstime.hour - 12 : jstime.hour;
                    let m = jstime.minute;
                    var hDeg = (h * 3600 + m * 60) / (3600 * 12) * 360;
                    var mDeg = (m * 60) / 3600 * 360;
                    let start
                    let end
                    let start2
                    let end2
                    let color

                    //可编辑背景
                    let bgConfig = [
                        { id: 1, preview: rootPath + "editBg/1.png", path: rootPath + "bgColor/1.png" },
                        { id: 2, preview: rootPath + "editBg/2.png", path: rootPath + "bgColor/2.png" },
                        { id: 3, preview: rootPath + "editBg/3.png", path: rootPath + "bgColor/3.png" },
                        { id: 4, preview: rootPath + "editBg/4.png", path: rootPath + "bgColor/4.png" },
                        { id: 5, preview: rootPath + "editBg/5.png", path: rootPath + "bgColor/5.png" },
                        { id: 6, preview: rootPath + "editBg/6.png", path: rootPath + "bgColor/6.png" },
                    ]
                    const editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
                        edit_id: 103,
                        x: 0,
                        y: 0,
                        bg_config: bgConfig,
                        count: 6,
                        default_id: 1,
                        fg: rootPath + "mask/mask.png",
                        tips_x: 178,
                        tips_y: 428,
                        tips_bg: rootPath + "tips/bg_tips.png",
                    });
                    let bgId = editBg.getProperty(hmUI.prop.CURRENT_TYPE);
                    switch (bgId) {
                        case 1:
                            color = '0xF45D26'
                            break;
                        case 2:
                            color = '0x00B943'
                            break;
                        case 3:
                            color = '0xDB55A5'
                            break;
                        case 4:
                            color = '0x9155D8'
                            break;
                        case 5:
                            color = '0x3471D1'
                            break;
                        case 6:
                            color = '0xE63C45'
                            break;
                    }
                    let timer1 = timer.createTimer(0, 1000, (function (option) {
                        h = jstime.hour >= 12 ? jstime.hour - 12 : jstime.hour;
                        m = jstime.minute >= 60 ? 0 : jstime.minute;
                        hDeg = (h * 3600 + m * 60) / (3600 * 12) * 360;
                        mDeg = (m * 60) / 3600 * 360;
                        bgId = editBg.getProperty(hmUI.prop.CURRENT_TYPE);
                        switch (bgId) {
                            case 1:
                                color = '0xF45D26'
                                break;
                            case 2:
                                color = '0x00B943'
                                break;
                            case 3:
                                color = '0xDB55A5'
                                break;
                            case 4:
                                color = '0x9155D8'
                                break;
                            case 5:
                                color = '0x3471D1'
                                break;
                            case 6:
                                color = '0xE63C45'
                                break;
                        }
                        if (h == 0 && m >= 33 && m <= 40) {
                            black_bg.setProperty(hmUI.prop.VISIBLE, false)
                            color = '0x000000'
                            start = hDeg - 90
                            end = (mDeg - hDeg) / 2 + hDeg - 90 + 1
                            start2 = (mDeg - hDeg) / 2 + hDeg - 90
                            end2 = mDeg - 90
                        } else if (h == 1 && m >= 39 && m <= 41) {
                            black_bg.setProperty(hmUI.prop.VISIBLE, false)
                            color = '0x000000'
                            start = hDeg - 90
                            end = (mDeg - hDeg) / 2 + hDeg - 90 + 1
                            start2 = (mDeg - hDeg) / 2 + hDeg - 90
                            end2 = mDeg - 90
                        } else if (h == 3 && m >= 52 && m <= 58) {
                            black_bg.setProperty(hmUI.prop.VISIBLE, false)
                            color = '0x000000'
                            start = hDeg - 90
                            end = (mDeg - hDeg) / 2 + hDeg - 90 + 1
                            start2 = (mDeg - hDeg) / 2 + hDeg - 90
                            end2 = mDeg - 90
                        } else if (h == 4 && m >= 55 && m <= 59) {
                            black_bg.setProperty(hmUI.prop.VISIBLE, false)
                            color = '0x000000'
                            start = hDeg - 90
                            end = (mDeg - hDeg) / 2 + hDeg - 90 + 1
                            start2 = (mDeg - hDeg) / 2 + hDeg - 90
                            end2 = mDeg - 90
                        } else if (h == 7 && m >= 0 && m <= 6) {
                            black_bg.setProperty(hmUI.prop.VISIBLE, false)
                            color = '0x000000'
                            start = mDeg - 90
                            end = (hDeg - mDeg) / 2 + mDeg - 90 + 1
                            start2 = (hDeg - mDeg) / 2 + mDeg - 90 + 1
                            end2 = hDeg - 90
                        } else if (h == 8 && m == 0) {
                            black_bg.setProperty(hmUI.prop.VISIBLE, true)
                            start = 150
                            end = 211
                            start2 = 210
                            end2 = 270
                        } else if (h == 8 && m == 1) {
                            black_bg.setProperty(hmUI.prop.VISIBLE, true)
                            start = 150
                            end = 210
                            start2 = 210
                            end2 = 276
                        }else if (h == 8 && m >= 2 && m <= 9) {
                            black_bg.setProperty(hmUI.prop.VISIBLE, false)
                            color = '0x000000'
                            start = mDeg - 90
                            end = (hDeg - mDeg) / 2 + mDeg - 90 + 1
                            start2 = (hDeg - mDeg) / 2 + mDeg - 90 + 1
                            end2 = hDeg - 90
                        } else if (h == 10 && m >= 20 && m <= 21) {
                            black_bg.setProperty(hmUI.prop.VISIBLE, false)
                            color = '0x000000'
                            start = mDeg - 90
                            end = (hDeg - mDeg) / 2 + mDeg - 90 + 1
                            start2 = (hDeg - mDeg) / 2 + mDeg - 90 + 1
                            end2 = hDeg - 90
                        } else if (h == 11 && m >= 20 && m <= 27) {
                            black_bg.setProperty(hmUI.prop.VISIBLE, false)
                            color = '0x000000'
                            start = mDeg - 90
                            end = (hDeg - mDeg) / 2 + mDeg - 90 + 1
                            start2 = (hDeg - mDeg) / 2 + mDeg - 90 + 1
                            end2 = hDeg - 90
                        }
                        else {
                            if (hDeg >= mDeg) {
                                if (hDeg - mDeg <= 180) {
                                    black_bg.setProperty(hmUI.prop.VISIBLE, true)
                                    start = mDeg - 90
                                    end = (hDeg - mDeg) / 2 + mDeg + 1 - 90
                                    start2 = (hDeg - mDeg) / 2 + mDeg - 90
                                    end2 = hDeg - 90
                                } else {
                                    black_bg.setProperty(hmUI.prop.VISIBLE, true)
                                    start = hDeg - 90
                                    end = 270
                                    start2 = -90
                                    end2 = mDeg - 90
                                }
                            } else {
                                if (mDeg - hDeg <= 180) {
                                    black_bg.setProperty(hmUI.prop.VISIBLE, true)
                                    start = hDeg - 90
                                    end = (mDeg - hDeg) / 2 + hDeg + 1 - 90
                                    start2 = (mDeg - hDeg) / 2 + hDeg - 90
                                    end2 = mDeg - 90
                                } else {
                                    black_bg.setProperty(hmUI.prop.VISIBLE, true)
                                    start = mDeg - 90
                                    end = 270
                                    start2 = -90
                                    end2 = hDeg - 90
                                }
                            }
                        }
                        changeBg.setProperty(hmUI.prop.MORE, {
                            x: 0,
                            y: 0,
                            w: 480,
                            h: 480,
                            center_x: 240,
                            center_y: 240,
                            radius: 240,
                            start_angle: start,
                            end_angle: end,
                            color: color,
                            line_width: 240,
                            show_level: hmUI.show_level.ONLY_NORMAL
                        })
                        changeBg2.setProperty(hmUI.prop.MORE, {
                            x: 0,
                            y: 0,
                            w: 480,
                            h: 480,
                            center_x: 240,
                            center_y: 240,
                            radius: 240,
                            start_angle: start2,
                            end_angle: end2,
                            color: color,
                            line_width: 240,
                            show_level: hmUI.show_level.ONLY_NORMAL
                        })
                    }), {

                    })
                    let black_bg = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 0,
                        y: 0,
                        w: 480,
                        h: 480,
                        src: rootPath + "background/black.png",
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    if (hDeg >= mDeg) {
                        if (hDeg - mDeg <= 180) {
                            black_bg.setProperty(hmUI.prop.VISIBLE, true)
                            start = mDeg - 90
                            end = (hDeg - mDeg) / 2 + mDeg + 1 - 90
                            start2 = (hDeg - mDeg) / 2 + mDeg - 90
                            end2 = hDeg - 90
                        } else {
                            black_bg.setProperty(hmUI.prop.VISIBLE, true)
                            start = hDeg - 90
                            end = 270
                            start2 = -90
                            end2 = mDeg - 90
                        }
                    } else {
                        if (mDeg - hDeg <= 180) {
                            black_bg.setProperty(hmUI.prop.VISIBLE, true)
                            start = hDeg - 90
                            end = (mDeg - hDeg) / 2 + hDeg + 1 - 90
                            start2 = (mDeg - hDeg) / 2 + hDeg - 90
                            end2 = mDeg - 90
                        } else {
                            black_bg.setProperty(hmUI.prop.VISIBLE, true)
                            start = mDeg - 90
                            end = 270
                            start2 = -90
                            end2 = hDeg - 90
                        }
                    }
                    var changeBg = hmUI.createWidget(hmUI.widget.ARC, {
                        x: 0,
                        y: 0,
                        w: 480,
                        h: 480,
                        center_x: 240,
                        center_y: 240,
                        radius: 240,
                        start_angle: start,
                        end_angle: end,
                        color: color,
                        line_width: 240,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    var changeBg2 = hmUI.createWidget(hmUI.widget.ARC, {
                        x: 0,
                        y: 0,
                        w: 480,
                        h: 480,
                        center_x: 240,
                        center_y: 240,
                        radius: 240,
                        start_angle: start2,
                        end_angle: end2,
                        color: color,
                        line_width: 240,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    let bg = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 0,
                        y: 0,
                        w: 480,
                        h: 480,
                        src: rootPath + "background/bg.png",
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });

                    let timePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                        hour_centerX: 240,
                        hour_centerY: 240,
                        hour_posX: 22,
                        hour_posY: 201,
                        hour_path: rootPath + 'img/hour.png',

                        minute_centerX: 240,
                        minute_centerY: 240,
                        minute_posX: 16,
                        minute_posY: 239,
                        minute_path: rootPath + 'img/minute.png',

                        second_centerX: 240,
                        second_centerY: 240,
                        second_posX: 11,
                        second_posY: 237,
                        second_path: rootPath + 'img/seconds.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    let img_bg = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 228.5,
                        y: 228.5,
                        src: rootPath + "img/center.png",
                        show_level: hmUI.show_level.ONLY_NORMAL
                    })
                }

            },

            onInit() {
                console.log('index page.js on init invoke')

                this.init_view();
            },

            onReady() {
                console.log('index page.js on ready invoke')
            },

            onShow() {
                console.log('index page.js on show invoke')
            },

            onHide() {
                console.log('index page.js on hide invoke')
            },

            onDestory() {
                console.log('index page.js on destory invoke')
                timer.stopTimer(timerSupport)
            },
        });
        /*
        * end js
        */
    })()
} catch (e) {
    console.log(e)
}