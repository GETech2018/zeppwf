try {
    (() => {
    
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
  
    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');
  
      /*
    * huamiOS bundle tool v1.0.17
    * Copyright © Huami. All Rights Reserved
    */
    'use strict';
  
    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let rootPath = null
    let weekStr = null
    let weekScArray = null
    let weekTcArray = null
    let weekEnArray = null
    let fontArray = null
    let dontPath = null
    let bg = null
    let animResident = null
    let btText = null
    let btIcon = null
    let week = null
    let month = null
    let animCreate = null
    let timePointer = null
    let editGroup = null
    let maskCover = null
    let editBg = null

    const logger = DeviceRuntimeCore.HmLogger.getLogger("defult");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
        
        _animNext() {
            animResident.setProperty(hmUI.prop.ANIM_STATUS,1);


            // month.setProperty(hmUI.prop.VISIBLE,true);
            // day.setProperty(hmUI.prop.VISIBLE,true);
            bg.setProperty(hmUI.prop.VISIBLE,false);    
            animCreate.setProperty(hmUI.prop.VISIBLE,false);
            // hmUI.deleteWidget(animCreate);
        },
        _animAutoResume() {
            animResident.setProperty(hmUI.prop.ANIM_STATUS,1);


            // month.setProperty(hmUI.prop.VISIBLE,true);
            // day.setProperty(hmUI.prop.VISIBLE,true);
            animCreate.setProperty(hmUI.prop.VISIBLE,true);
            // hmUI.deleteWidget(animCreate);
        },

        init_view() {
            // let world_clock = hmSensor.createSensor(hmSensor.id.WORLD_CLOCK);
            // world_clock.init();
            // let count = world_clock.getWorldClockCount();
            // if(count > 0){
            //     let worldData = world_clock.getWorldClockInfo(0);
            //     console.log("worldName="+worldData.city);
            //     console.log("worldHour="+worldData.hour);
            //     console.log("worldMinute="+worldData.minute);
            // }
            // world_clock.uninit();
            // let weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
            //获取天气信息
            // const weatherData = weatherSensor.getForecastWeather();
            //获取预报天气结构体
            // const forecastData = weatherData.forecastData;
            // console.log("weatherCount="+forecastData.count);
            //获取预报天气信息 索引为0为今天
            // for (let index = 0; index < forecastData.data.length; index++) {
            //     const element = forecastData.data[index];
            //     console.log("weather info high="+element.high+" low=" + element.low + " index="+ element.index);
            // }
            rootPath = "images/";
            weekStr = ["sun","mon","thu","wed","tue","fri","sat"];
            weekScArray = [
                rootPath+"week_sc/1.png",
                rootPath+"week_sc/2.png",
                rootPath+"week_sc/3.png",
                rootPath+"week_sc/4.png",
                rootPath+"week_sc/5.png",
                rootPath+"week_sc/6.png",
                rootPath+"week_sc/7.png",
            ];
            weekTcArray = [
                rootPath+"week_tc/1.png",
                rootPath+"week_tc/2.png",
                rootPath+"week_tc/3.png",
                rootPath+"week_tc/4.png",
                rootPath+"week_tc/5.png",
                rootPath+"week_tc/6.png",
                rootPath+"week_tc/7.png",
            ];
            weekEnArray = [
                rootPath+"week/1.png",
                rootPath+"week/2.png",
                rootPath+"week/3.png",
                rootPath+"week/4.png",
                rootPath+"week/5.png",
                rootPath+"week/6.png",
                rootPath+"week/7.png",
            ];
            fontArray = [
                rootPath+"font/0.png",
                rootPath+"font/1.png",
                rootPath+"font/2.png",
                rootPath+"font/3.png",
                rootPath+"font/4.png",
                rootPath+"font/5.png",
                rootPath+"font/6.png",
                rootPath+"font/7.png",
                rootPath+"font/8.png",
                rootPath+"font/9.png",
            ];
            dontPath = rootPath + "font/dot.png";
            var screenType = hmSetting.getScreenType();
            var nomalModel = screenType == hmSetting.screen_type.APP || screenType == hmSetting.screen_type.WATCHFACE;
            var aodModel = screenType == hmSetting.screen_type.AOD;
            if(nomalModel){
                
                animResident = hmUI.createWidget(hmUI.widget.IMG_ANIM);
                animResident.setProperty(hmUI.prop.MORE, {
                    x: 0,
                    y: 0,
                    w:480,
                    h:480,
                    align_h:hmUI.align.CENTER_H,
                    align_v:hmUI.align.CENTER_V,
                    anim_path: rootPath + "anim",
                    anim_prefix: "anim",
                    anim_ext: "png",
                    anim_fps: 18,
                    anim_size: 25,
                    anim_repeat: true,
                    repeat_count: 1,
                    anim_status: 1,
                });
                bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    color: 0x000000,
                });
            }

            if(nomalModel){
                animCreate = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                    x: 0,
                    y: 0,
                    w:480,
                    h:480,
                    align_h:hmUI.align.CENTER_H,
                    align_v:hmUI.align.CENTER_V,
                    anim_path: rootPath + "start",
                    anim_prefix: "anim",
                    anim_ext: "png",
                    anim_fps: 18,
                    anim_size: 24,
                    anim_repeat: false,
                    repeat_count: 1,
                    anim_status: 1,
                    display_on_restart:true,
                    anim_complete_call:this._animNext,
                    anim_auto_resume_call:this._animAutoResume,
                });
            }
           
            btText = hmUI.createWidget(hmUI.widget.TEXT_IMG,{
                show_level:hmUI.show_level.ALL,

            });
            btIcon = hmUI.createWidget(hmUI.widget.IMG,{
                show_level:hmUI.show_level.ALL,

            });
            week = hmUI.createWidget(hmUI.widget.IMG_WEEK,{
                show_level:hmUI.show_level.ALL,

            });
            month = hmUI.createWidget(hmUI.widget.IMG_DATE,{
                show_level:hmUI.show_level.ALL,

            });
            



            if(nomalModel || aodModel){
                week.setProperty(hmUI.prop.MORE, {
                    show_level:hmUI.show_level.ALL,
                    x: 198,
                    y: 89,
                    week_tc:weekTcArray,
                    week_sc:weekScArray,
                    week_en:weekEnArray,
                });
                month.setProperty(hmUI.prop.MORE, {
                    month_startX:196,
                    month_startY:126,
                    month_zero:true,
                    month_en_array:fontArray,
                    month_unit_sc:dontPath,
                    month_unit_tc:dontPath,
                    month_unit_en:dontPath,
                    day_follow:true,
                    day_zero:true,
                    day_en_array:fontArray,
                });
            }
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK,{
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                src: rootPath+"edit/edit_bg.png",
                show_level:hmUI.show_level.ONLY_EDIT,
            });
            var editConfig = [
                { type: hmUI.edit_type.HEART, preview: rootPath + "preview/heart.png"},
                { type: hmUI.edit_type.PAI, preview: rootPath + "preview/pai.png",},
                { type: hmUI.edit_type.STEP, preview: rootPath + "preview/step.png"},
                { type: hmUI.edit_type.CAL, preview: rootPath + "preview/cal.png"},
                { type: hmUI.edit_type.BATTERY, preview: rootPath + "preview/bat.png"},
                { type: hmUI.edit_type.AQI, preview: rootPath + "preview/aqi.png"},
                { type: hmUI.edit_type.HUMIDITY, preview: rootPath + "preview/hum.png"},
                { type: hmUI.edit_type.UVI, preview: rootPath + "preview/uvi.png" },
                { type: hmUI.edit_type.STAND, preview: rootPath + "preview/stand.png" },
                { type: hmUI.edit_type.SUN_SET, preview: rootPath + "preview/sunset.png" },
                { type: hmUI.edit_type.SUN_RISE, preview: rootPath + "preview/sunrise.png" },
                { type: hmUI.edit_type.WIND, preview: rootPath + "preview/wind.png" },
            ];
            editGroup = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP,{
                show_level:hmUI.show_level.ALL,
                edit_id:101,
                x:177,
                y:338,
                w:127,
                h:85,
                select_image:rootPath + "edit/select.png",
                un_select_image:rootPath + "edit/un_select.png",
                default_type:hmUI.edit_type.HEART,
                optional_types: editConfig,
                count: editConfig.length,
                tips_BG:rootPath+"edit/text_tag.png",
                tips_x:0,
                tips_y:288 - 328,
                tips_width:128,
            });
            var editType = editGroup.getProperty(hmUI.prop.CURRENT_TYPE);
            switch (editType) {
                case hmUI.edit_type.HEART:
                    btText.setProperty(hmUI.prop.MORE, {
                        x: 211,
                        y: 381,
                        type:hmUI.data_type.HEART,
                        font_array: fontArray,
                        h_space: 0,
                        align_h: hmUI.align.CENTER_H,
                        invalid_image: rootPath + "font/minu.png",
                    });
                    btIcon.setProperty(hmUI.prop.MORE, {
                        x: 217,
                        y: 333,
                        w: 47,
                        h: 47,
                        src: rootPath + "img/heart.png",
                    });
                    break;
                case hmUI.edit_type.STEP:
                    btText.setProperty(hmUI.prop.MORE, {
                        x: 192,
                        y: 381,
                        type: hmUI.data_type.STEP,
                        font_array: fontArray,
                        h_space: 0,
                        align_h: hmUI.align.CENTER_H,
                    });
                    btIcon.setProperty(hmUI.prop.MORE, {
                        x: 217,
                        y: 333,
                        w: 47,
                        h: 47,
                        src: rootPath + "img/step.png",
                    });
                    break;
                case hmUI.edit_type.SUN_SET:
                    btText.setProperty(hmUI.prop.MORE, {
                        x: 196,
                        y: 381,
                        type: hmUI.data_type.SUN_SET,
                        font_array: fontArray,
                        h_space: 0,
                        align_h: hmUI.align.CENTER_H,
                        dot_image:rootPath+"font/colon.png",
                    });
                    btIcon.setProperty(hmUI.prop.MORE, {
                        x: 217,
                        y: 333,
                        w: 47,
                        h: 47,
                        src: rootPath + "img/sunset.png",
                        
                    });
                    break;
                case hmUI.edit_type.SUN_RISE:
                    btText.setProperty(hmUI.prop.MORE, {
                        x: 196,
                        y: 381,
                        type: hmUI.data_type.SUN_RISE,
                        font_array: fontArray,
                        h_space: 0,
                        align_h: hmUI.align.CENTER_H,
                        dot_image:rootPath+"font/colon.png",
                    });
                    btIcon.setProperty(hmUI.prop.MORE, {
                        x: 217,
                        y: 333,
                        w: 47,
                        h: 47,
                        src: rootPath + "img/sunrise.png",
                        
                    });
                    break;
                case hmUI.edit_type.STAND:
                    btText.setProperty(hmUI.prop.MORE, {
                        x: 192,
                        y: 381,
                        type: hmUI.data_type.STAND,
                        font_array: fontArray,
                        h_space: 0,
                        align_h: hmUI.align.CENTER_H,
                        dot_image:rootPath+"font/slant.png",
                    });
                    btIcon.setProperty(hmUI.prop.MORE, {
                        x: 217,
                        y: 333,
                        w: 47,
                        h: 47,
                        src: rootPath + "img/stand.png",
                    });
                    break;
                case hmUI.edit_type.PAI:
                    btText.setProperty(hmUI.prop.MORE, {
                        x: 211,
                        y: 381,
                        type: hmUI.data_type.PAI_WEEKLY,
                        font_array: fontArray,
                        h_space: 0,
                        align_h: hmUI.align.CENTER_H,
                    });
                    btIcon.setProperty(hmUI.prop.MORE, {
                        x: 217,
                        y: 333,
                        w: 47,
                        h: 47,
                        src: rootPath + "img/pai.png",
                    });
                    break;
                case hmUI.edit_type.CAL:
                    btText.setProperty(hmUI.prop.MORE, {
                        x: 202,
                        y: 381,
                        type: hmUI.data_type.CAL,
                        font_array: fontArray,
                        h_space: 0,
                        align_h: hmUI.align.CENTER_H,
                    });
                    btIcon.setProperty(hmUI.prop.MORE, {
                        x: 217,
                        y: 333,
                        w: 47,
                        h: 47,
                        src: rootPath + "img/cal.png",
                    });
                    break;
                case hmUI.edit_type.BATTERY:
                    btText.setProperty(hmUI.prop.MORE, {
                        x: 198,
                        y: 381,
                        type: hmUI.data_type.BATTERY,
                        font_array: fontArray,
                        h_space: 0,
                        unit_sc:rootPath+"font/percent.png",
                        unit_tc:rootPath+"font/percent.png",
                        unit_en:rootPath+"font/percent.png",
                        align_h: hmUI.align.CENTER_H,
                    });
                    btIcon.setProperty(hmUI.prop.MORE, {
                        x: 217,
                        y: 333,
                        w: 47,
                        h: 47,
                        src: rootPath + "img/battery.png",
                    });
                    break;    
                case hmUI.edit_type.AQI:
                    btText.setProperty(hmUI.prop.MORE, {
                        x: 211,
                        y: 381,
                        type: hmUI.data_type.AQI,
                        font_array: fontArray,
                        h_space: 0,
                        align_h: hmUI.align.CENTER_H,
                    });
                    btIcon.setProperty(hmUI.prop.MORE, {
                        x: 217,
                        y: 333,
                        w: 47,
                        h: 47,
                        src: rootPath + "img/aqi.png",
                    });
                    break;    
                case hmUI.edit_type.UVI:
                    btText.setProperty(hmUI.prop.MORE, {
                        x: 221,
                        y: 381,
                        type: hmUI.data_type.UVI,
                        font_array: fontArray,
                        h_space: 0,
                        align_h: hmUI.align.CENTER_H,
                    });
                    btIcon.setProperty(hmUI.prop.MORE, {
                        x: 217,
                        y: 333,
                        w: 47,
                        h: 47,
                        src: rootPath + "img/uvi.png",
                    });
                    break;
                case hmUI.edit_type.WIND:
                    btText.setProperty(hmUI.prop.MORE, {
                        x: 221,
                        y: 381,
                        type: hmUI.data_type.WIND,
                        font_array: fontArray,
                        h_space: 0,
                        align_h: hmUI.align.CENTER_H,
                    });
                    btIcon.setProperty(hmUI.prop.MORE, {
                        x: 217,
                        y: 333,
                        w: 47,
                        h: 47,
                        src: rootPath + "img/wind.png",
                    });
                    break;
                case hmUI.edit_type.HUMIDITY:
                    btText.setProperty(hmUI.prop.MORE, {
                        x: 198,
                        y: 381,
                        type: hmUI.data_type.HUMIDITY,
                        font_array: fontArray,
                        h_space: 0,
                        align_h: hmUI.align.CENTER_H,
                        unit_sc:rootPath+"font/percent.png",
                        unit_tc:rootPath+"font/percent.png",
                        unit_en:rootPath+"font/percent.png",
                    });
                    btIcon.setProperty(hmUI.prop.MORE, {
                        x: 217,
                        y: 333,
                        w: 47,
                        h: 47,
                        src: rootPath + "img/hum.png",
                    });
                    break;    
            };
            maskCover = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK,{
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                src: rootPath+"edit/mask_100.png",
                show_level:hmUI.show_level.ONLY_EDIT,
            });

            timePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER,{
                show_level:hmUI.show_level.ALL,
            });
            
            var timePointerProp = {
                hour_centerX: 240,
                hour_centerY: 240,
                hour_posX: 31,
                hour_posY: 180,
                hour_path: rootPath + "hour.png",
                minute_centerX: 240,
                minute_centerY: 240,
                minute_posX: 31,
                minute_posY: 225,
                minute_path: rootPath + "min.png",
            };

            if(!aodModel){
                timePointerProp.second_centerX = 240;
                timePointerProp.second_centerY = 240;
                timePointerProp.second_posX = 31;
                timePointerProp.second_posY = 234;
                timePointerProp.second_path = rootPath + "sec.png";
            }else{
                timePointerProp.minute_path = rootPath + "min_aod.png";
            }

            timePointer.setProperty(hmUI.prop.MORE, timePointerProp);
            
            mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK,{
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                src: rootPath+"edit/mask_70.png",
                show_level:hmUI.show_level.ONLY_EDIT,
            }); 
           

           
          
            
        },

        onInit() {
            console.log('index page.js on init invoke');

            this.init_view();

            
        },

        onReady() {
            console.log('index page.js on ready invoke')
        },

        onShow() {
            console.log('index page.js on show invoke')
        },

        onHide() {
            console.log('index page.js on hide invoke')
        },

        onDestory() {
            console.log('index page.js on destory invoke')
        },
    });
    /*
    * end js
    */
        })()
    } catch (e) {
        console.log(e+"");
    }