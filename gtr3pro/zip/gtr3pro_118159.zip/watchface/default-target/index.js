try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_46d81a5cbcfc4826965bcce4c7d84a58 = '';
        let normal$_$temperature$_$low$_$text_img = '';
        let normal$_$temperature$_$high$_$text_img = '';
        let normal$_$lunar$_$lunar_date = '';
        let timeSensor = '';
        let lunarText = '';
        let lunar_month = '';
        let lunar_day = '';
        let festival = '';
        let normal$_$text_16987878aa44452f85a326842fbbbb00 = '';
        let normal$_$text_6a48b974a1a34e41b2f393d1a0db4e1d = '';
        const logger = Logger.getLogger('watchface6');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '3.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 107,
                    hour_startY: 58,
                    hour_array: [
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png'
                    ],
                    hour_space: 0,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 149,
                    minute_startY: 34,
                    minute_array: [
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png'
                    ],
                    minute_space: 0,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    second_zero: 1,
                    second_startX: 198,
                    second_startY: 20,
                    second_array: [
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png'
                    ],
                    second_space: 0,
                    second_align: hmUI.align.LEFT,
                    second_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 273,
                    month_startY: 27,
                    month_sc_array: [
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png'
                    ],
                    month_tc_array: [
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png'
                    ],
                    month_en_array: [
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png'
                    ],
                    month_align: hmUI.align.LEFT,
                    month_zero: 1,
                    month_follow: 0,
                    month_space: 0,
                    month_is_character: false,
                    day_startX: 324,
                    day_startY: 45,
                    day_sc_array: [
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png'
                    ],
                    day_tc_array: [
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png'
                    ],
                    day_en_array: [
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png'
                    ],
                    day_align: hmUI.align.LEFT,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 0,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 395,
                    y: 104,
                    type: hmUI.data_type.PAI_DAILY,
                    font_array: [
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: false,
                    isCharacter: false
                });
                normal$_$text_46d81a5cbcfc4826965bcce4c7d84a58 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 388,
                    y: 86,
                    w: 50,
                    h: 50,
                    text: 'PAI',
                    color: '0xFFba944e',
                    text_size: 14,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$temperature$_$low$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 387,
                    y: 281,
                    type: hmUI.data_type.WEATHER_LOW,
                    font_array: [
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 1,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '26.png',
                    unit_tc: '26.png',
                    unit_en: '26.png',
                    negative_image: '25.png',
                    invalid_image: '24.png',
                    padding: false,
                    isCharacter: false
                });
                normal$_$temperature$_$high$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 0,
                    y: 0,
                    type: hmUI.data_type.WEATHER_HIGH,
                    font_array: [
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png'
                    ],
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '29.png',
                    unit_tc: '29.png',
                    unit_en: '29.png',
                    negative_image: '28.png',
                    invalid_image: '27.png',
                    padding: false,
                    isCharacter: false
                });
                normal$_$temperature$_$low$_$text_img.layoutChange(function (obj) {
                    const end_X = normal$_$temperature$_$low$_$text_img.getProperty(hmUI.prop.END_X);
                    const y = normal$_$temperature$_$low$_$text_img.getProperty(hmUI.prop.Y);
                    normal$_$temperature$_$high$_$text_img.setProperty(hmUI.prop.X, end_X);
                    normal$_$temperature$_$high$_$text_img.setProperty(hmUI.prop.Y, y);
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 64,
                    y: 99,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: [
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 1,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '32.png',
                    unit_tc: '32.png',
                    unit_en: '32.png',
                    negative_image: '31.png',
                    invalid_image: '30.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 34,
                    y: 159,
                    type: hmUI.data_type.AQI,
                    font_array: [
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '33.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 209,
                    y: 78,
                    image_array: [
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png'
                    ],
                    image_length: 5,
                    type: hmUI.data_type.SPO2,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 218,
                    y: 57,
                    type: hmUI.data_type.SPO2,
                    font_array: [
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '40.png',
                    unit_tc: '40.png',
                    unit_en: '40.png',
                    invalid_image: '39.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 198,
                    y: 204,
                    image_array: [
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png'
                    ],
                    image_length: 5,
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 215,
                    y: 225,
                    type: hmUI.data_type.HEART,
                    font_array: [
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '47.png',
                    unit_tc: '47.png',
                    unit_en: '47.png',
                    invalid_image: '46.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 107,
                    y: 144,
                    type: hmUI.data_type.CAL,
                    font_array: [
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '48.png',
                    unit_tc: '48.png',
                    unit_en: '48.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 107,
                    y: 164,
                    image_array: [
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png'
                    ],
                    image_length: 5,
                    type: hmUI.data_type.CAL,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 78,
                    y: 290,
                    type: hmUI.data_type.STEP,
                    font_array: [
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '55.png',
                    unit_tc: '55.png',
                    unit_en: '55.png',
                    invalid_image: '54.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 78,
                    y: 310,
                    image_array: [
                        '56.png',
                        '57.png',
                        '58.png',
                        '59.png',
                        '60.png'
                    ],
                    image_length: 5,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 324,
                    y: 294,
                    type: hmUI.data_type.DISTANCE,
                    font_array: [
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '63.png',
                    unit_tc: '63.png',
                    unit_en: '63.png',
                    imperial_unit_sc: '64.png',
                    imperial_unit_tc: '64.png',
                    imperial_unit_en: '64.png',
                    dot_image: '62.png',
                    invalid_image: '61.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 300,
                    y: 313,
                    src: '65.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 254,
                    y: 396,
                    type: hmUI.data_type.BATTERY,
                    font_array: [
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '66.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 187,
                    y: 394,
                    src: '67.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 53,
                    y: 370,
                    src: '68.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 105,
                    y: 416,
                    src: '69.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 166,
                    y: 446,
                    src: '70.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 244,
                    y: 452,
                    src: '71.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 306,
                    y: 437,
                    src: '72.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 360,
                    y: 402,
                    src: '73.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 402,
                    y: 352,
                    src: '74.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$lunar$_$lunar_date = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 206,
                    y: 410,
                    w: 100,
                    h: 100,
                    text: '',
                    color: '0xFFba944e',
                    text_size: 13,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                function isVoid(value) {
                    return value === 'INVALID';
                }
                function getLunarText() {
                    lunar_month = timeSensor.lunar_month;
                    lunar_day = timeSensor.lunar_day;
                    festival = timeSensor.getShowFestival();
                    festival = isVoid(festival) ? '' : festival;
                    if (!isVoid(lunar_month)) {
                        if (lunar_month.indexOf('闰') > -1) {
                            lunarText = lunar_month;
                        } else if (!isVoid(lunar_day)) {
                            lunarText = lunar_month + lunar_day;
                        }
                    }
                    normal$_$lunar$_$lunar_date.setProperty(hmUI.prop.MORE, { text: festival || lunarText });
                }
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 209,
                    y: 432,
                    week_en: [
                        '75.png',
                        '76.png',
                        '77.png',
                        '78.png',
                        '79.png',
                        '80.png',
                        '81.png'
                    ],
                    week_sc: [
                        '82.png',
                        '83.png',
                        '84.png',
                        '85.png',
                        '86.png',
                        '87.png',
                        '88.png'
                    ],
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 420,
                    y: 140,
                    type: hmUI.data_type.UVI,
                    font_array: [
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '89.png',
                    padding: false,
                    isCharacter: false
                });
                normal$_$text_16987878aa44452f85a326842fbbbb00 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 409,
                    y: 122,
                    w: 100,
                    h: 40,
                    text: 'UV',
                    color: '0xFFba944e',
                    text_size: 14,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_6a48b974a1a34e41b2f393d1a0db4e1d = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 40,
                    y: 138,
                    w: 100,
                    h: 40,
                    text: 'QIA',
                    color: '0xFFba944e',
                    text_size: 14,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 284,
                    y: 164,
                    image_array: [
                        '90.png',
                        '91.png',
                        '92.png',
                        '93.png',
                        '94.png'
                    ],
                    image_length: 5,
                    type: hmUI.data_type.STRESS,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 305,
                    y: 146,
                    type: hmUI.data_type.STRESS,
                    font_array: [
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 1,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '96.png',
                    unit_tc: '96.png',
                    unit_en: '96.png',
                    invalid_image: '95.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 386,
                    y: 216,
                    type: hmUI.data_type.VO2MAX,
                    font_array: [
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 4,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '98.png',
                    unit_tc: '98.png',
                    unit_en: '98.png',
                    invalid_image: '97.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 386,
                    y: 238,
                    type: hmUI.data_type.TRAINING_LOAD,
                    font_array: [
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 4,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '100.png',
                    unit_tc: '100.png',
                    unit_en: '100.png',
                    invalid_image: '99.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 57,
                    y: 115,
                    type: hmUI.data_type.HUMIDITY,
                    font_array: [
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '102.png',
                    unit_tc: '102.png',
                    unit_en: '102.png',
                    invalid_image: '101.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 387,
                    y: 259,
                    type: hmUI.data_type.STAND,
                    font_array: [
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 1,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '104.png',
                    unit_tc: '104.png',
                    unit_en: '104.png',
                    dot_image: '103.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 438,
                    y: 185,
                    type: hmUI.data_type.WIND,
                    font_array: [
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '105.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 415,
                    y: 169,
                    src: '106.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 78,
                    y: 310,
                    src: '107.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 107,
                    y: 164,
                    src: '108.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 304,
                    y: 164,
                    src: '109.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 320,
                    y: 313,
                    src: '110.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 34,
                    y: 180,
                    type: hmUI.data_type.ALTIMETER,
                    font_array: [
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '112.png',
                    unit_tc: '112.png',
                    unit_en: '112.png',
                    invalid_image: '111.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 23,
                    y: 285,
                    src: '113.png',
                    type: hmUI.system_status.DISCONNECT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 22,
                    y: 264,
                    src: '114.png',
                    type: hmUI.system_status.DISTURB,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 22,
                    y: 243,
                    src: '115.png',
                    type: hmUI.system_status.LOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 22,
                    y: 221,
                    src: '116.png',
                    type: hmUI.system_status.CLOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 2,
                    y: 2,
                    src: '117.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 240,
                    hour_centerY: 240,
                    hour_posX: 3,
                    hour_posY: 127,
                    hour_path: '118.png',
                    hour_cover_x: 0,
                    hour_cover_y: 1,
                    minute_centerX: 240,
                    minute_centerY: 240,
                    minute_posX: 3,
                    minute_posY: 214,
                    minute_path: '119.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        normal$_$text_46d81a5cbcfc4826965bcce4c7d84a58.setProperty(hmUI.prop.MORE, { text: `PAI` });
                        getLunarText();
                        normal$_$text_16987878aa44452f85a326842fbbbb00.setProperty(hmUI.prop.MORE, { text: `UV` });
                        normal$_$text_6a48b974a1a34e41b2f393d1a0db4e1d.setProperty(hmUI.prop.MORE, { text: `QIA` });
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}