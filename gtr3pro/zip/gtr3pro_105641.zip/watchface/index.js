try {
    (() => {
    
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
  
    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');
  
      /*
    * huamiOS bundle tool v1.0.17
    * Copyright © Huami. All Rights Reserved
    */
    'use strict';
  
    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let rootPath = null
    let weekAodArray = []
    let weekNorArray = []

    let dateNorArray = []
    let dateAodArray = []
    let heartArray=[]
    let week = null
    let month = null

    const logger = DeviceRuntimeCore.HmLogger.getLogger("defult");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
        
        init_view() {
         
            rootPath = "images/";
            
            for(let i=0;i<10;i++)
            {
                heartArray.push(rootPath+"heartNum/"+i+".png");
                dateNorArray.push(rootPath+"date_nor/"+i+".png");
                dateAodArray.push(rootPath+"date_aod/"+i+".png");
                if(i>0 && i<8)
                {
                    weekNorArray.push(rootPath+"week_nor/"+i+".png");
                    weekAodArray.push(rootPath+"week_aod/"+i+".png");
                }
            }
       
            var screenType = hmSetting.getScreenType();
            var nomalModel = screenType == hmSetting.screen_type.APP || screenType == hmSetting.screen_type.WATCHFACE;
            var aodModel = screenType == hmSetting.screen_type.AOD;

            img_bg = hmUI.createWidget(hmUI.widget.IMG,{
                x: 0,
                y: 0,
                w: 480,
                h: 480,
               // src: rootPath + "img/bg.png",
            });
            if(nomalModel){
                img_bg.setProperty(hmUI.prop.SRC, rootPath + "img/bg.png");
            }else{
                img_bg.setProperty(hmUI.prop.SRC, rootPath + "img/bg_aod.png");
            }
           
            
            week = hmUI.createWidget(hmUI.widget.IMG_WEEK,{
                show_level:hmUI.show_level.ALL,

            });
            month = hmUI.createWidget(hmUI.widget.IMG_DATE,{
                show_level:hmUI.show_level.ALL,

            });
            
            let heartIcon = hmUI.createWidget(hmUI.widget.IMG,{
                x: 220,
                y: 367,
                w: 40,
                h: 40,
                src: rootPath+"heartNum/heart_icon.png",
            });
            let heartText =  hmUI.createWidget(hmUI.widget.TEXT_IMG,{
                x: 213,
                y: 406,
                type: hmUI.data_type.HEART,
                font_array:  heartArray,
                h_space: 0, //图片间隔
                align_h: hmUI.align.CENTER_H,
                padding:false, //是否补零 true为补零
                invalid_image:  rootPath+"heartNum/heart_invalid.png",
                show_level: hmUI.show_level.ALL,
            });
            if(nomalModel){
                week.setProperty(hmUI.prop.MORE, {
                  //  show_level:hmUI.show_level.ALL,
                    x: 203,
                    y: 46,
                    week_tc:weekNorArray,
                    week_sc:weekNorArray,
                    week_en:weekNorArray,
                });
                month.setProperty(hmUI.prop.MORE, {
                    month_startX:192,
                    month_startY:79,
                    month_zero:true,
                    month_en_array:dateNorArray,
                    month_unit_sc:rootPath+"date_nor/dot.png",
                    month_unit_tc:rootPath+"date_nor/dot.png",
                    month_unit_en:rootPath+"date_nor/dot.png",
                    day_follow:true,
                    day_zero:true,
                    day_en_array:dateNorArray,
                });
            }else  if(aodModel){
                week.setProperty(hmUI.prop.MORE, {
                      x: 203,
                      y: 46,
                      week_tc:weekAodArray,
                      week_sc:weekAodArray,
                      week_en:weekAodArray,
                  });
                  month.setProperty(hmUI.prop.MORE, {
                    month_startX:192,
                    month_startY:79,
                    month_zero:true,
                    month_en_array:dateAodArray,
                    month_unit_sc:rootPath+"date_aod/dot.png",
                    month_unit_tc:rootPath+"date_aod/dot.png",
                    month_unit_en:rootPath+"date_aod/dot.png",
                    day_follow:true,
                    day_zero:true,
                    day_en_array:dateAodArray,
                });
            }
            timePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER,{
                show_level:hmUI.show_level.ALL,
            });
            
            var timePointerProp = {
                hour_centerX: 240,
                hour_centerY: 240,
                hour_posX: 12,
                hour_posY: 220,
                hour_path: rootPath + "img/hour.png",
                minute_centerX: 240,
                minute_centerY: 240,
                minute_posX: 12,
                minute_posY: 220,
                minute_path: rootPath + "img/minute.png",
            };

            if(!aodModel){
                timePointerProp.second_centerX = 240;
                timePointerProp.second_centerY = 240;
                timePointerProp.second_posX = 12;
                timePointerProp.second_posY = 220;
                timePointerProp.second_path = rootPath + "img/second.png";
            }else{
                timePointerProp.minute_path = rootPath + "img/minute_aod.png";
                timePointerProp.hour_path = rootPath + "img/hour_aod.png";
            }

            timePointer.setProperty(hmUI.prop.MORE, timePointerProp);
            
        },

        onInit() {
            console.log('index page.js on init invoke');

            this.init_view();

            
        },

        onReady() {
            console.log('index page.js on ready invoke')
        },

        onShow() {
            console.log('index page.js on show invoke')
        },

        onHide() {
            console.log('index page.js on hide invoke')
        },

        onDestory() {
            console.log('index page.js on destory invoke')
        },
    });
    /*
    * end js
    */
        })()
    } catch (e) {
        console.log(e+"");
    }