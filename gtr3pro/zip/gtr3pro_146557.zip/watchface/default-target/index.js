try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 188,
                    y: 49,
                    image_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png'
                    ],
                    image_length: 29,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 195,
                    y: 133,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: [
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: -1,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '44.png',
                    unit_tc: '44.png',
                    unit_en: '44.png',
                    negative_image: '43.png',
                    invalid_image: '42.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 279,
                    y: 74,
                    type: hmUI.data_type.WEATHER_HIGH,
                    font_array: [
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png',
                        '54.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: -1,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '57.png',
                    unit_tc: '57.png',
                    unit_en: '57.png',
                    negative_image: '56.png',
                    invalid_image: '55.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 127,
                    y: 73,
                    type: hmUI.data_type.WEATHER_LOW,
                    font_array: [
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png',
                        '54.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: -1,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '60.png',
                    unit_tc: '60.png',
                    unit_en: '60.png',
                    negative_image: '59.png',
                    invalid_image: '58.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 291,
                    y: 216,
                    week_en: [
                        '61.png',
                        '62.png',
                        '63.png',
                        '64.png',
                        '65.png',
                        '66.png',
                        '67.png'
                    ],
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 240,
                    center_y: 240,
                    radius: 238,
                    start_angle: 192,
                    end_angle: 258,
                    color: 4291823113,
                    line_width: 7,
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 94,
                    y: 291,
                    type: hmUI.data_type.HEART,
                    font_array: [
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: -1,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '68.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 93,
                    y: 339,
                    src: '69.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 221,
                    y: 376,
                    src: '70.png',
                    type: hmUI.system_status.DISCONNECT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 221,
                    y: 320,
                    src: '71.png',
                    type: hmUI.system_status.DISTURB,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 240,
                    center_y: 240,
                    radius: 238,
                    start_angle: 282,
                    end_angle: 348,
                    color: 4291874827,
                    line_width: 7,
                    type: hmUI.data_type.STRESS,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 94,
                    y: 147,
                    type: hmUI.data_type.STRESS,
                    font_array: [
                        '72.png',
                        '73.png',
                        '74.png',
                        '75.png',
                        '76.png',
                        '77.png',
                        '78.png',
                        '79.png',
                        '80.png',
                        '81.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: -1,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '82.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 93,
                    y: 100,
                    src: '83.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 242,
                    center_y: 242,
                    radius: 238,
                    start_angle: 168,
                    end_angle: 102,
                    color: 4279109583,
                    line_width: 7,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 274,
                    y: 291,
                    type: hmUI.data_type.STEP,
                    font_array: [
                        '72.png',
                        '73.png',
                        '74.png',
                        '75.png',
                        '76.png',
                        '77.png',
                        '78.png',
                        '79.png',
                        '80.png',
                        '81.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: -1,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 351,
                    y: 339,
                    src: '84.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 240,
                    center_y: 240,
                    radius: 238,
                    start_angle: 78,
                    end_angle: 12,
                    color: 4281062153,
                    line_width: 7,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 288,
                    y: 147,
                    type: hmUI.data_type.BATTERY,
                    font_array: [
                        '72.png',
                        '73.png',
                        '74.png',
                        '75.png',
                        '76.png',
                        '77.png',
                        '78.png',
                        '79.png',
                        '80.png',
                        '81.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: -1,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '85.png',
                    unit_tc: '85.png',
                    unit_en: '85.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 358,
                    y: 100,
                    src: '86.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    day_startX: 394,
                    day_startY: 210,
                    day_sc_array: [
                        '87.png',
                        '88.png',
                        '89.png',
                        '90.png',
                        '91.png',
                        '92.png',
                        '93.png',
                        '94.png',
                        '95.png',
                        '96.png'
                    ],
                    day_tc_array: [
                        '87.png',
                        '88.png',
                        '89.png',
                        '90.png',
                        '91.png',
                        '92.png',
                        '93.png',
                        '94.png',
                        '95.png',
                        '96.png'
                    ],
                    day_en_array: [
                        '87.png',
                        '88.png',
                        '89.png',
                        '90.png',
                        '91.png',
                        '92.png',
                        '93.png',
                        '94.png',
                        '95.png',
                        '96.png'
                    ],
                    day_align: hmUI.align.CENTER_H,
                    day_zero: 0,
                    day_follow: 0,
                    day_space: -3,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 240,
                    hour_centerY: 240,
                    hour_posX: 6,
                    hour_posY: 118,
                    hour_path: '97.png',
                    hour_cover_x: 140,
                    hour_cover_y: 140,
                    minute_centerX: 240,
                    minute_centerY: 240,
                    minute_posX: 4,
                    minute_posY: 217,
                    minute_path: '99.png',
                    minute_cover_path: '98.png',
                    minute_cover_x: 220,
                    minute_cover_y: 220,
                    second_centerX: 240,
                    second_centerY: 240,
                    second_posX: 10,
                    second_posY: 208,
                    second_path: '100.png',
                    second_cover_x: 0,
                    second_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 240,
                    hour_centerY: 240,
                    hour_posX: 6,
                    hour_posY: 118,
                    hour_path: '101.png',
                    hour_cover_x: 140,
                    hour_cover_y: 140,
                    minute_centerX: 240,
                    minute_centerY: 240,
                    minute_posX: 4,
                    minute_posY: 217,
                    minute_path: '103.png',
                    minute_cover_path: '102.png',
                    minute_cover_x: 220,
                    minute_cover_y: 220,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}