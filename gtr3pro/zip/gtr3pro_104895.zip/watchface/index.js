try {
    (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;

        var __$$module$$__ = __$$app$$__.current;
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        /*
    * huamiOS bundle tool v1.0.17
    * Copyright © Huami. All Rights Reserved
    */
        'use strict';

        console.log("----->>>current")
        console.log(__$$hmAppManager$$__.currentApp.pid)
        console.log(__$$hmAppManager$$__.currentApp.current)

        let rootPath = null
        let weekArray = null
        let dayArray = null
        let kpaArray = null
        let img_bg = null
        let timePointer = null
        let weekLevel = null
        let day_img = null

        let sunIcon = null
        let kpaText = null
        let sun_pointer = null
        let sunimgArray = null
        let moonArray = null
        let month = null
        let month_pointer = null
        let moonRootPath = null
        let moonLevel = null
        let kpa_pointer = null
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

            init_view() {
                rootPath = "images/"
                weekRootPath = rootPath + "week/"
                dayRootPath = rootPath + "date/"
                kapRootPath = rootPath + "kpa_num/"
                moonRootPath = rootPath + "moon/"
                weekArray = [
                    weekRootPath + "week_01.png",
                    weekRootPath + "week_02.png",
                    weekRootPath + "week_03.png",
                    weekRootPath + "week_04.png",
                    weekRootPath + "week_05.png",
                    weekRootPath + "week_06.png",
                    weekRootPath + "week_07.png",
                ]

                dayArray = [
                    dayRootPath + "day_00.png",
                    dayRootPath + "day_01.png",
                    dayRootPath + "day_02.png",
                    dayRootPath + "day_03.png",
                    dayRootPath + "day_04.png",
                    dayRootPath + "day_05.png",
                    dayRootPath + "day_06.png",
                    dayRootPath + "day_07.png",
                    dayRootPath + "day_08.png",
                    dayRootPath + "day_09.png",
                ]

                kpaArray = [
                    kapRootPath + "kpa_00.png",
                    kapRootPath + "kpa_01.png",
                    kapRootPath + "kpa_02.png",
                    kapRootPath + "kpa_03.png",
                    kapRootPath + "kpa_04.png",
                    kapRootPath + "kpa_05.png",
                    kapRootPath + "kpa_06.png",
                    kapRootPath + "kpa_07.png",
                    kapRootPath + "kpa_08.png",
                    kapRootPath + "kpa_09.png",
                ]
                moonArray = [
                    moonRootPath + "moon_01.png",
                    moonRootPath + "moon_02.png",
                    moonRootPath + "moon_03.png",
                    moonRootPath + "moon_04.png",
                    moonRootPath + "moon_05.png",
                    moonRootPath + "moon_06.png",
                    moonRootPath + "moon_07.png", ,
                ]
                sunimgArray = [
                    rootPath + "sunset/sunset_0.png",
                    rootPath + "sunset/sunset_1.png",
                    rootPath + "sunset/sunset_3.png",
                    rootPath + "sunset/sunset_4.png",
                    rootPath + "sunset/sunset_5.png",
                    rootPath + "sunset/sunset_6.png",
                    rootPath + "sunset/sunset_7.png",
                ]
                img_bg = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: rootPath + "bg.png",
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                weekLevel = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 219,
                    y: 340,
                    week_sc: weekArray,
                    week_tc: weekArray,
                    week_en: weekArray,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                day_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    day_startX: 227,
                    day_startY: 383,
                    day_en_array: dayArray,
                    day_space: 0,
                    day_zero: 1,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                month_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
                    src: rootPath + "img/data_1.png",
                    center_x: 240,
                    center_y: 368,
                    posX: 23,
                    posY: 55,
                    type: hmUI.date.MONTH,
                    start_angle: 0,
                    end_angle: 360,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                kpaText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 94,
                    y: 233,
                    font_array: kpaArray,
                    h_space: 0,
                    align_h: hmUI.align.CENTER_H,
                    type: hmUI.data_type.ALTIMETER,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                let min_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    minute_centerX: 120,
                    minute_centerY: 242,
                    minute_posX: 64,
                    minute_posY: 64,
                    minute_path: rootPath + "img/kpaPointer.png",
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                sunIcon = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: rootPath + "sun/0.png",
                    center_x: 362,
                    center_y: 242,
                    x: 16,
                    y: 39,
                    type: hmUI.data_type.SUN_CURRENT,
                    start_angle: -90,
                    end_angle: 80,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                var sunbg = hmUI.createWidget(hmUI.widget.IMG,{
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    x:310,
                    y:190,
                    w:104,
                    h:104,
                    src:rootPath + "sun/sun_bg.png",
                }); 
                var sunLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {

                    x: 330,
                    y: 258,
                    w: 65,
                    h: 15,
                    image_array: [rootPath + "sun/sunrise.png", rootPath + "sun/sunset.png"],
                    image_length: 2,
                    type: hmUI.data_type.SUN_TIME,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                sun_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: rootPath + "img/data_1.png",
                    center_x: 362,
                    center_y: 242,
                    x: 23,
                    y: 55,
                    type: hmUI.data_type.SUN_TIME,
                    start_angle: 0,
                    end_angle: 360,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                moonLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 162,
                    y: 33,
                    w: 156, //宽高可省略
                    h: 156,
                    image_array: moonArray,
                    image_length: 7,
                    type: hmUI.data_type.MOON,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                var screenType = hmSetting.getScreenType();
                var aodModel = screenType == hmSetting.screen_type.AOD;
                var pointerProp = {
                    hour_centerX: 240,
                    hour_centerY: 240,
                    hour_posX: 12,
                    hour_posY: 161,
                    hour_path: rootPath + "img/hour.png",
                    minute_centerX: 240,
                    minute_centerY: 240,
                    minute_posX: 15,
                    minute_posY: 236,
                    minute_path: rootPath + "img/min.png",
                    show_level: hmUI.show_level.ONLY_ALL,
                };
                if(!aodModel){
                    pointerProp.second_centerX = 240;
                    pointerProp.second_centerY = 240;
                    pointerProp.second_posX = 16;
                    pointerProp.second_posY = 239;
                    pointerProp.second_path = rootPath + "img/sec.png";
                }else{
                    pointerProp.hour_path =  rootPath + "img/hour_xp.png";
                    pointerProp.minute_path =  rootPath + "img/min_xp.png";
                }
                timePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp);
            },

            onInit() {
                console.log('index page.js on init invoke')

                this.init_view();

            },

            onReady() {
                console.log('index page.js on ready invoke')
            },

            onShow() {
                console.log('index page.js on show invoke')
            },

            onHide() {
                console.log('index page.js on hide invoke')
            },

            onDestory() {
                console.log('index page.js on destory invoke')
            },
        });
        /*
        * end js
        */
    })()
} catch (e) {
    console.log(e)
}
