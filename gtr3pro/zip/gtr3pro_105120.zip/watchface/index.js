try {
  (() => {

    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

    /*
  * huamiOS bundle tool v1.0.17
  * Copyright © Huami. All Rights Reserved
  */
    'use strict';

    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let rootPath = null
    let bgPath = null
    let coPath = null
    let heartPath = null
    let huanPath = null
    let stepPath = null
    let timePath = null
    let weatherPath = null
    let zhizhenPath = null

    let heart_array = null
    let co_array = null
    let huan_array = null
    let time_array = null
    let step_array = null
    let weather_array = null



    const logger = DeviceRuntimeCore.HmLogger.getLogger("defult");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({


      init_view() {
        rootPath = "images/";
        bgPath = rootPath + "bg/"
        coPath = rootPath + "co/"
        heartPath = rootPath + "heart/"
        huanPath = rootPath + "huan/"
        stepPath = rootPath + "step/"
        timePath = rootPath + "time/"
        weatherPath = rootPath + "weather/"
        zhizhenPath = rootPath + "zhizhen/"

        heart_array = [
          heartPath + "0.png",
          heartPath + "1.png",
          heartPath + "2.png",
          heartPath + "3.png",
          heartPath + "4.png",
          heartPath + "5.png",
        ]

        co_array = [
          coPath + "0.png",
          coPath + "1.png",
          coPath + "2.png",
          coPath + "3.png",
          coPath + "4.png",
          coPath + "5.png",
        ]

        step_array = [
          stepPath + "0.png",
          stepPath + "1.png",
          stepPath + "2.png",
          stepPath + "3.png",
          stepPath + "4.png",
          stepPath + "5.png",
        ]

        huan_array = [
          huanPath + "0.png",
          huanPath + "1.png",
          huanPath + "2.png",
          huanPath + "3.png",
          huanPath + "4.png",
          huanPath + "5.png",
        ]
        time_array = [
          timePath + "0.png",
          timePath + "1.png",
          timePath + "2.png",
          timePath + "3.png",
          timePath + "4.png",
          timePath + "5.png",
          timePath + "6.png",
          timePath + "7.png",
          timePath + "8.png",
          timePath + "9.png",
        ]
        weather_array = [
          weatherPath + "0.png",
          weatherPath + "1.png",
          weatherPath + "2.png",
          weatherPath + "3.png",
          weatherPath + "4.png",
          weatherPath + "5.png",
          weatherPath + "6.png",
          weatherPath + "7.png",
          weatherPath + "8.png",
          weatherPath + "9.png",
          weatherPath + "10.png",
          weatherPath + "11.png",
          weatherPath + "12.png",
          weatherPath + "13.png",
          weatherPath + "14.png",
          weatherPath + "15.png",
          weatherPath + "16.png",
          weatherPath + "17.png",
          weatherPath + "18.png",
          weatherPath + "19.png",
          weatherPath + "20.png",
          weatherPath + "21.png",
          weatherPath + "22.png",
          weatherPath + "23.png",
          weatherPath + "24.png",
          weatherPath + "25.png",
          weatherPath + "26.png",
          weatherPath + "27.png",
          weatherPath + "28.png",
        ]

        // bg_img = hmUI.createWidget(hmUI.widget.IMG, {
        //   x: 0,
        //   y: 0,
        //   w: 480,
        //   h: 480,
        //   src: bgPath + "bg2.png",
        //   show_level: hmUI.show_level.ONLY_NORMAL
        // })

        var animDemo = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
          x: 0,
          y: 0,

          anim_path: rootPath + "bg", 

          anim_prefix: "anim",

          anim_ext: "png",
          // anim_0 
          anim_fps: 25,

          anim_size: 4,

          repeat_count: 1, //0位无限重复
          anim_repeat: true,//是否重复
          anim_status: hmUI.anim_status.START,
          display_on_restart: false,//从息屏到亮屏是否自动重复播放
          // anim_complete_call:animCall,//动画结束回调 无限重复永远不会调用到

        });
        //设置动画状态
        animDemo.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.PAUSE)

        batter_img = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 0,
          y: 0,
          image_array: huan_array,
          image_length: huan_array.length,
          type: hmUI.data_type.BATTERY,
          show_level: hmUI.show_level.ONLY_NORMAL
        });
        step_img = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 0,
          y: 0,
          image_array: step_array,
          image_length: step_array.length,
          // type: hmUI.data_type.WEATHER,
          type: hmUI.data_type.STEP,
          show_level: hmUI.show_level.ONLY_NORMAL
        });
        cal_img = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 0,
          y: 0,
          image_array: heart_array,
          image_length: heart_array.length,
          type: hmUI.data_type.CAL,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        heart_img = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 0,
          y: 0,
          image_array: co_array,
          image_length: co_array.length,
          type: hmUI.data_type.HEART,
          show_level: hmUI.show_level.ONLY_NORMAL
        });


        humidity_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
          center_x: 373,
          center_y: 243,
          x: 13,
          y: 62,
          src: zhizhenPath + "dot.png",
          type: hmUI.data_type.HUMIDITY,
          start_angle: -45,
          end_angle: 215,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });


        weather_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
          center_x: 110,
          center_y: 242,
          x: 13,
          y: 62,
          src: zhizhenPath + "dot.png",
          type: hmUI.data_type.WEATHER_CURRENT,
          start_angle: 125,
          end_angle: 415,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });


        uvi_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
          center_x: 240,
          center_y: 370,
          x: 13,
          y: 62,
          src: zhizhenPath + "dot.png",
          type: hmUI.data_type.UVI,
          start_angle: 35,
          end_angle: 325,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });


        // aqi_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
        //   center_x: 240,
        //   center_y: 112,
        //   x: 13,
        //   y: 62,
        //   src: zhizhenPath + "dot.png",
        //   type: hmUI.data_type.AQI,
        //   start_angle: 215,
        //   end_angle: 505,
        //   show_level: hmUI.show_level.ONLY_NORMAL,
        // });
        pai_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
          center_x: 240,
          center_y: 112,
          x: 13,
          y: 62,
          src: zhizhenPath + "dot.png",
          type: hmUI.data_type.PAI_DAILY,
          start_angle: 215,
          end_angle: 505,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });




        // aqiText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
        //   x: 219,
        //   y: 96,
        //   type: hmUI.data_type.AQI,
        //   font_array: time_array,
        //   h_space: 0,
        //   align_h: hmUI.align.CENTER_H,
        //   show_level: hmUI.show_level.ONLY_NORMAL,
        //   invalid_image: timePath + "null.png",
        //   // padding:true
        // });
        paiText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 219,
          y: 96,
          type: hmUI.data_type.PAI_DAILY,
          font_array: time_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NORMAL,
          invalid_image: timePath + "null.png",
          // padding:true
        });
        uviText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 226,
          y: 354,
          type: hmUI.data_type.UVI,
          font_array: time_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NORMAL,
          invalid_image: timePath + "null.png",
          // padding:true
        });
        weatherText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 81,
          y: 226,
          type: hmUI.data_type.WEATHER_CURRENT,
          font_array: time_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          unit_sc: timePath + "10.png",
          unit_tc: timePath + "10.png",
          unit_en: timePath + "10.png",

          negative_image: timePath + "11.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
          invalid_image: timePath + "null.png",
          // padding:true
        });
        humidityText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 344,
          y: 226,
          type: hmUI.data_type.HUMIDITY,
          font_array: time_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          unit_sc: timePath + "12.png",
          unit_tc: timePath + "12.png",
          unit_en: timePath + "12.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
          invalid_image: timePath + "null.png",
          // padding:true
        });

        timePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_centerX: 240, //指针旋转中心 对应centerX
          hour_centerY: 240, //指针旋转中心 对应centerY
          hour_posX: 61, //指针自身旋转中心 对应positioin中的x
          hour_posY: 240, //指针自身旋转中心 对应positioin中的y
          hour_path: zhizhenPath + "hour.png",
          minute_centerX: 240, //指针旋转中心 对应centerX
          minute_centerY: 240, //指针旋转中心 对应centerY
          minute_posX: 60, //指针自身旋转中心 对应positioin中的x
          minute_posY: 240, //指针自身旋转中心 对应positioin中的y
          minute_path: zhizhenPath + "min.png",
          second_centerX: 240, //指针旋转中心 对应centerX
          second_centerY: 240, //指针旋转中心 对应centerY
          second_posX: 60, //指针自身旋转中心 对应positioin中的x
          second_posY: 240, //指针自身旋转中心 对应positioin中的y
          second_path: zhizhenPath + "s.png",
          show_level: hmUI.show_level.ONLY_NORMAL
        })




        timePointer1 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_centerX: 240, //指针旋转中心 对应centerX
          hour_centerY: 240, //指针旋转中心 对应centerY
          hour_posX: 61, //指针自身旋转中心 对应positioin中的x
          hour_posY: 240, //指针自身旋转中心 对应positioin中的y
          hour_path: zhizhenPath + "hour.png",
          minute_centerX: 240, //指针旋转中心 对应centerX
          minute_centerY: 240, //指针旋转中心 对应centerY
          minute_posX: 60, //指针自身旋转中心 对应positioin中的x
          minute_posY: 240, //指针自身旋转中心 对应positioin中的y
          minute_path: zhizhenPath + "min.png",
          show_level: hmUI.show_level.ONAL_AOD
        })

        bg_img1 = hmUI.createWidget(hmUI.widget.IMG, {
          x: 226,
          y: 226,
          // w: ,
          // h: ,
          src: zhizhenPath + "z.png",
          show_level: hmUI.show_level.ONAL_AOD
        })


      },

      onInit() {
        console.log('index page.js on init invoke');

        this.init_view();


      },

      onReady() {
        console.log('index page.js on ready invoke')
      },

      onShow() {
        console.log('index page.js on show invoke')
      },

      onHide() {
        console.log('index page.js on hide invoke')
      },

      onDestory() {
        console.log('index page.js on destory invoke')
      },
    });
    /*
    * end js
    */
  })()
} catch (e) {
  console.log(e)
}