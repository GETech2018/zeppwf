try {
  (() => {

    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

    /*
  * huamiOS bundle tool v1.0.17
  * Copyright © Huami. All Rights Reserved
  */
    'use strict';

    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let rootPath = null
    let batteryPath = null
    let bgPath = null
    let powerPath = null
    let stepPath = null
    let timePath = null
    let xpPath = null
    let battery_array = null
    let power_array = null
    let step_array = null
    let time_array = null
    let xp_array = null
    let anim_time = null
    const logger = DeviceRuntimeCore.HmLogger.getLogger("defult");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({


      init_view() {
        rootPath = "images/";
        batteryPath = rootPath + "battery/"
        bgPath = rootPath + "bg/"
        powerPath = rootPath + "power/"
        stepPath = rootPath + "step/"
        timePath = rootPath + "time/"
        xpPath = rootPath + "xp/"
        battery_array = [
          // batteryPath + "0.png",
          batteryPath + "1.png",
          batteryPath + "2.png",
          batteryPath + "3.png",
          batteryPath + "4.png",
          batteryPath + "5.png",
          batteryPath + "6.png",
        ]

        power_array = [
          powerPath + "0.png",
          powerPath + "1.png",
          powerPath + "2.png",
          powerPath + "3.png",
          powerPath + "4.png",
          powerPath + "5.png",
          powerPath + "6.png",
          powerPath + "7.png",
          powerPath + "8.png",
          powerPath + "9.png"
        ]

        step_array = [
          stepPath + "0.png",
          stepPath + "1.png",
          stepPath + "2.png",
          stepPath + "3.png",
          stepPath + "4.png",
          stepPath + "5.png",
          stepPath + "6.png",
          stepPath + "7.png",
          stepPath + "8.png",
          stepPath + "9.png"
        ]

        time_array = [
          timePath + "0.png",
          timePath + "1.png",
          timePath + "2.png",
          timePath + "3.png",
          timePath + "4.png",
          timePath + "5.png",
          timePath + "6.png",
          timePath + "7.png",
          timePath + "8.png",
          timePath + "9.png"
        ]

        xp_array = [
          xpPath + "0.png",
          xpPath + "1.png",
          xpPath + "2.png",
          xpPath + "3.png",
          xpPath + "4.png",
          xpPath + "5.png",
          xpPath + "6.png",
          xpPath + "7.png",
          xpPath + "8.png",
          xpPath + "9.png"
        ]

        let bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 480,
          h: 480,
          src: bgPath + "bg.png",
          show_level: hmUI.show_level.ONLY_NORMAL
        })

        let animA = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
          x: 0,
          y: 0,

          anim_path: rootPath + "bg",

          anim_prefix: "a",

          anim_ext: "png",
          // anim_0 
          anim_fps: 6,

          anim_size: 18,

          repeat_count: 1, //0位无限重复
          anim_repeat: true,//是否重复
          anim_status: hmUI.anim_status.START,
          display_on_restart: true,//从息屏到亮屏是否自动重复播放
          // anim_complete_call:animCall,//动画结束回调 无限重复永远不会调用到

        });
        //设置动画状态
        // animA.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.PAUSE)
        // function startTime() {
        //   anim_time = timer.createTimer(3000, 10000, (
        //     function (option) {
        //       animA.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.START);
        //     }))
        // }

        let batteryLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 183,
          y: 24,
          image_array: battery_array,
          image_length: battery_array.length,//长度
          type: hmUI.data_type.BATTERY,
          show_level: hmUI.show_level.ONLY_NORMAL
        })

        let batteryText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 240,
          y: 24,
          type: hmUI.data_type.BATTERY,
          font_array: power_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NORMAL,
          unit_sc: powerPath + "baifen.png",
          unit_tc: powerPath + "baifen.png",
          unit_en: powerPath + "baifen.png",
          // invalid_image: heartPath + "null.png",
          // padding: true
        });

        let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          hour_zero: 1, //是否补零
          hour_startX: 103,
          hour_startY: 74,
          hour_array: time_array,
          hour_space: 0, //每个数组间的间隔
          // hour_unit_sc: timePath + "maohao.png",
          // hour_unit_tc: timePath + "maohao.png",
          // hour_unit_en: timePath + "maohao.png",
          minute_zero: 1, //是否补零
          minute_startX: 261,
          minute_startY: 74,
          minute_array: time_array,
          minute_space: 0, //每个数组间的间隔
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let bg_img2 = hmUI.createWidget(hmUI.widget.IMG, {
          x: 233,
          y: 74,
          src: timePath + "maohao.png",
          show_level: hmUI.show_level.ONLY_NORMAL
        })

        let stepText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 218,
          y: 443,
          type: hmUI.data_type.STEP,
          font_array: step_array,
          h_space: 0,
          align_h: hmUI.align.LEFT,
          show_level: hmUI.show_level.ONLY_NORMAL,
        })

        let AOD_timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          hour_zero: 1, //是否补零
          hour_startX: 103,
          hour_startY: 74,
          hour_array: xp_array,
          hour_space: 0, //每个数组间的间隔
          // hour_unit_sc: xpPath + "maohao.png",
          // hour_unit_tc: xpPath + "maohao.png",
          // hour_unit_en: xpPath + "maohao.png",
          minute_zero: 1, //是否补零
          minute_startX: 261,
          minute_startY: 74,
          minute_array: xp_array,
          minute_space: 0, //每个数组间的间隔
          show_level: hmUI.show_level.ONAL_AOD,
        });

        let AOD_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 233,
          y: 74,
          src: xpPath + "maohao.png",
          show_level: hmUI.show_level.ONAL_AOD
        })

        // const vDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
        //   resume_call: (function () {
        //     startTime()
        //   }),
        //   pause_call: (function () {
        //     timer.stopTimer(anim_time)
        //     console.log('ui pause');
        //   }),

        // });
      },

      onInit() {
        console.log('index page.js on init invoke');

        this.init_view();


      },

      onReady() {
        console.log('index page.js on ready invoke')
      },

      onShow() {
        console.log('index page.js on show invoke')
      },

      onHide() {
        console.log('index page.js on hide invoke')
      },

      onDestory() {
        console.log('index page.js on destory invoke')
      },
    });
    /*
    * end js
    */
  })()
} catch (e) {
  console.log(e)
}