try {
    (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;

        var __$$module$$__ = __$$app$$__.current;
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        /*
      * huamiOS bundle tool v1.0.17
      * Copyright © Huami. All Rights Reserved
      */
        'use strict';

        console.log("----->>>current");
        console.log(__$$hmAppManager$$__.currentApp.pid);
        console.log(__$$hmAppManager$$__.currentApp.current);


        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

            init_view() {
                let rootPath = "images/";
                let weekArray = [
                    rootPath + "week/1.png",
                    rootPath + "week/2.png",
                    rootPath + "week/3.png",
                    rootPath + "week/4.png",
                    rootPath + "week/5.png",
                    rootPath + "week/6.png",
                    rootPath + "week/7.png",
                ]
                let dateArray = [
                    rootPath + "date/0.png",
                    rootPath + "date/1.png",
                    rootPath + "date/2.png",
                    rootPath + "date/3.png",
                    rootPath + "date/4.png",
                    rootPath + "date/5.png",
                    rootPath + "date/6.png",
                    rootPath + "date/7.png",
                    rootPath + "date/8.png",
                    rootPath + "date/9.png",
                ];
                let monthEnArray = [
                    rootPath + "month_en/1.png",
                    rootPath + "month_en/2.png",
                    rootPath + "month_en/3.png",
                    rootPath + "month_en/4.png",
                    rootPath + "month_en/5.png",
                    rootPath + "month_en/6.png",
                    rootPath + "month_en/7.png",
                    rootPath + "month_en/8.png",
                    rootPath + "month_en/9.png",
                    rootPath + "month_en/10.png",
                    rootPath + "month_en/11.png",
                    rootPath + "month_en/12.png",
                ]
                let timeArr = [
                    rootPath + "time/0.png",
                    rootPath + "time/1.png",
                    rootPath + "time/2.png",
                    rootPath + "time/3.png",
                    rootPath + "time/4.png",
                    rootPath + "time/5.png",
                    rootPath + "time/6.png",
                    rootPath + "time/7.png",
                    rootPath + "time/8.png",
                    rootPath + "time/9.png"
                ]
                let aodTime = [
                    rootPath + "aod/0.png",
                    rootPath + "aod/1.png",
                    rootPath + "aod/2.png",
                    rootPath + "aod/3.png",
                    rootPath + "aod/4.png",
                    rootPath + "aod/5.png",
                    rootPath + "aod/6.png",
                    rootPath + "aod/7.png",
                    rootPath + "aod/8.png",
                    rootPath + "aod/9.png"
                ]
                let stepArr = []
                let batteryArr = []
                for (let i = 1; i < 17; i++) {
                    stepArr.push(rootPath + "step/" + i + ".png",)
                    batteryArr.push(rootPath + "battery/" + i + ".png",)
                }

                let screenType = hmSetting.getScreenType()
                if (screenType == hmSetting.screen_type.AOD) {
                    let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                        hour_startX: 63,
                        hour_startY: 15,
                        hour_zero: 1,
                        hour_array: aodTime,
                        hour_space: 8,
                        hour_align: hmUI.align.LEFT,

                        minute_startX: 63,
                        minute_startY: 220,
                        minute_zero: 1,
                        minute_array: aodTime,
                        minute_space: 8,
                        minute_align: hmUI.align.LEFT,
                    });
                } else {
                    let img_bg = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 0,
                        y: 0,
                        w: 480,
                        h: 480,
                        src: rootPath + "img/bg.png",
                    });

                    let monthEn_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
                        month_startX: 72,
                        month_startY: 326,
                        month_en_array: monthEnArray,
                        month_sc_array: monthEnArray,
                        month_tc_array: monthEnArray,
                        month_is_character: true,
                        month_space: 0,
                        month_zero: 0,
                        month_align: hmUI.align.LEFT,

                        day_startX: 149,
                        day_startY: 196,
                        day_en_array: dateArray,
                        day_sc_array: dateArray,
                        day_tc_array: dateArray,
                        day_is_character: false,
                        day_space: 0,
                        day_zero: 1,
                        day_align: hmUI.align.LEFT,

                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                        x: 81,
                        y: 40,
                        week_en: weekArray,
                        week_tc: weekArray,
                        week_sc: weekArray,
                        show_level: hmUI.show_level.ONAL_NORML,
                    });


                    let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                        hour_startX: 63,
                        hour_startY: 15,
                        hour_zero: 1,
                        hour_array: timeArr,
                        hour_space: 8,
                        hour_align: hmUI.align.LEFT,

                        minute_startX: 63,
                        minute_startY: 220,
                        minute_zero: 1,
                        minute_array: timeArr,
                        minute_space: 8,
                        minute_align: hmUI.align.LEFT,
                    });
                    //step bg
                    let stepBg = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 405,
                        y: 206,
                        w: 70,
                        h: 70,
                        alpha: 60,
                        src: rootPath + 'step/16.png',
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                    let stepLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                        x: 405,
                        y: 206,
                        w: 70,
                        h: 70,
                        image_array: stepArr,
                        image_length: stepArr.length,
                        type: hmUI.data_type.STEP,
                    });
                    // battery bg
                    let batteryBg = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 4,
                        y: 206,
                        w: 70,
                        h: 70,
                        alpha: 60,
                        src: rootPath + 'battery/16.png',
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                    let batteryLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                        x: 4,
                        y: 206,
                        w: 70,
                        h: 70,
                        image_array: batteryArr,
                        image_length: batteryArr.length,
                        type: hmUI.data_type.BATTERY,
                    });
                }


            },

            onInit() {
                console.log('index page.js on init invoke')

                this.init_view();
            },

            onReady() {
                console.log('index page.js on ready invoke')
            },

            onShow() {
                console.log('index page.js on show invoke')
            },

            onHide() {
                console.log('index page.js on hide invoke')
            },

            onDestory() {
                console.log('index page.js on destory invoke')
                timer.stopTimer(timerSupport)
            },
        });
        /*
        * end js
        */
    })()
} catch (e) {
    console.log(e)
}