
    /*
    ** huamiOS bundle tool v1.0.17
    * *huamiOS watchface js version v1.0.1
    * *Copyright © Huami. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start
        let normal$_$background$_$bg = ''
        let normal$_$component_0$_$component = ''
        let normal$_$step$_$current$_$component_0$_$text_img = ''
        let normal$_$step$_$pointer_progress$_$component_0$_$img_pointer = ''
        let normal$_$battery$_$text$_$component_0$_$text_img = ''
        let normal$_$battery$_$pointer_progress$_$component_0$_$img_pointer = ''
        let normal$_$heart_rate$_$text$_$component_0$_$text_img = ''
        let normal$_$heart_rate$_$pointer_progress$_$component_0$_$img_pointer = ''
        let normal$_$calorie$_$current$_$component_0$_$text_img = ''
        let normal$_$calorie$_$pointer_progress$_$component_0$_$img_pointer = ''
        let normal$_$pai$_$weekly$_$component_0$_$text_img = ''
        let normal$_$pai$_$pointer_progress$_$component_0$_$img_pointer = ''
        let normal$_$component_1$_$component = ''
        let normal$_$battery$_$text$_$component_1$_$text_img = ''
        let normal$_$battery$_$pointer_progress$_$component_1$_$img_pointer = ''
        let normal$_$heart_rate$_$text$_$component_1$_$text_img = ''
        let normal$_$heart_rate$_$pointer_progress$_$component_1$_$img_pointer = ''
        let normal$_$calorie$_$current$_$component_1$_$text_img = ''
        let normal$_$calorie$_$pointer_progress$_$component_1$_$img_pointer = ''
        let normal$_$pai$_$weekly$_$component_1$_$text_img = ''
        let normal$_$pai$_$pointer_progress$_$component_1$_$img_pointer = ''
        let normal$_$component$_$cover = ''
        let normal$_$analog_clock$_$time_pointer = ''
        let normal$_$component$_$mask = ''
        let idle$_$analog_clock$_$time_pointer = ''
        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            normal$_$background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$component_0$_$component = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP,{
              edit_id: 0,
              x: 161,
              y: 46,
              w: 158,
              h: 158,
              select_image: '2.png',
              un_select_image: '3.png',
              default_type: hmUI.edit_type.PAI,
              optional_types: [{"type":hmUI.edit_type.PAI,"preview":"5.png"},{"type":hmUI.edit_type.STEP,"preview":"6.png"},{"type":hmUI.edit_type.BATTERY,"preview":"7.png"},{"type":hmUI.edit_type.CAL,"preview":"8.png"},{"type":hmUI.edit_type.HEART,"preview":"9.png"}],
              count: 5,
              tips_BG: '4.png',
              tips_x: 18,
              tips_y: 173,
              tips_width: 122,
            });
  
                    
            editType = normal$_$component_0$_$component.getProperty(hmUI.prop.CURRENT_TYPE);
        
            switch (editType) {
              case hmUI.edit_type.STEP:
                            
                normal$_$step$_$current$_$component_0$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 217,
                  y: 156,
                  type: hmUI.data_type.STEP,
                  font_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
                  align_h: hmUI.align.CENTER_H,
                  h_space: 0,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  invalid_image: '20.png',// 无数据时显示的图片
                  padding: false,
                  isCharacter: false
                });
  
                            
                normal$_$step$_$pointer_progress$_$component_0$_$img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '22.png',
                  center_x: 240,
                  center_y: 126,
                  x: 6,
                  y: 61,
                  type: hmUI.data_type.STEP,
                  start_angle: 0,
                  end_angle: 360,
                  cover_path: '',
                  cover_x: 0,
                  cover_y: 0,
                  scale_x: 161,
                  scale_y: 46,
                  scale_sc: '21.png',
                  scale_tc: '21.png',
                  scale_en: '21.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
  
                break;
              case hmUI.edit_type.BATTERY:
                            
                normal$_$battery$_$text$_$component_0$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 226,
                  y: 156,
                  type: hmUI.data_type.BATTERY,
                  font_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
                  align_h: hmUI.align.CENTER_H,
                  h_space: 0,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  unit_sc: '24.png',//单位
                  unit_tc: '24.png',//单位
                  unit_en: '24.png',//单位
                  invalid_image: '23.png',// 无数据时显示的图片
                  padding: false,
                  isCharacter: false
                });
  
                            
                normal$_$battery$_$pointer_progress$_$component_0$_$img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '26.png',
                  center_x: 240,
                  center_y: 126,
                  x: 6,
                  y: 61,
                  type: hmUI.data_type.BATTERY,
                  start_angle: 0,
                  end_angle: 360,
                  cover_path: '',
                  cover_x: 0,
                  cover_y: 0,
                  scale_x: 161,
                  scale_y: 46,
                  scale_sc: '25.png',
                  scale_tc: '25.png',
                  scale_en: '25.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
  
                break;
              case hmUI.edit_type.HEART:
                            
                normal$_$heart_rate$_$text$_$component_0$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 226,
                  y: 156,
                  type: hmUI.data_type.HEART,
                  font_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
                  align_h: hmUI.align.CENTER_H,
                  h_space: 0,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  invalid_image: '27.png',// 无数据时显示的图片
                  padding: false,
                  isCharacter: false
                });
  
                            
                normal$_$heart_rate$_$pointer_progress$_$component_0$_$img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '29.png',
                  center_x: 240,
                  center_y: 126,
                  x: 6,
                  y: 61,
                  type: hmUI.data_type.HEART,
                  start_angle: 0,
                  end_angle: 360,
                  cover_path: '',
                  cover_x: 0,
                  cover_y: 0,
                  scale_x: 161,
                  scale_y: 46,
                  scale_sc: '28.png',
                  scale_tc: '28.png',
                  scale_en: '28.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
  
                break;
              case hmUI.edit_type.CAL:
                            
                normal$_$calorie$_$current$_$component_0$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 222,
                  y: 156,
                  type: hmUI.data_type.CAL,
                  font_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
                  align_h: hmUI.align.CENTER_H,
                  h_space: 0,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  invalid_image: '30.png',// 无数据时显示的图片
                  padding: false,
                  isCharacter: false
                });
  
                            
                normal$_$calorie$_$pointer_progress$_$component_0$_$img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '32.png',
                  center_x: 240,
                  center_y: 126,
                  x: 6,
                  y: 61,
                  type: hmUI.data_type.CAL,
                  start_angle: 0,
                  end_angle: 360,
                  cover_path: '',
                  cover_x: 0,
                  cover_y: 0,
                  scale_x: 161,
                  scale_y: 46,
                  scale_sc: '31.png',
                  scale_tc: '31.png',
                  scale_en: '31.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
  
                break;
              case hmUI.edit_type.PAI:
                            
                normal$_$pai$_$weekly$_$component_0$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 226,
                  y: 156,
                  type: hmUI.data_type.PAI_WEEKLY,
                  font_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
                  align_h: hmUI.align.CENTER_H,
                  h_space: 0,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  invalid_image: '33.png',// 无数据时显示的图片
                  padding: false,
                  isCharacter: false
                });
  
                            
                normal$_$pai$_$pointer_progress$_$component_0$_$img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '35.png',
                  center_x: 240,
                  center_y: 126,
                  x: 6,
                  y: 61,
                  type: hmUI.data_type.PAI_WEEKLY,
                  start_angle: 0,
                  end_angle: 360,
                  cover_path: '',
                  cover_x: 0,
                  cover_y: 0,
                  scale_x: 161,
                  scale_y: 46,
                  scale_sc: '34.png',
                  scale_tc: '34.png',
                  scale_en: '34.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
  
                break;
              case hmUI.edit_type.DISTANCE:
                break;
              case hmUI.edit_type.AQI:
                break;
              case hmUI.edit_type.HUMIDITY:
                break;
              case hmUI.edit_type.UVI:
                break;
              case hmUI.edit_type.DATE:
                break;
              case hmUI.edit_type.WEEK:
                break;
              case hmUI.edit_type.WEATHER:
                break;
              case hmUI.edit_type.TEMPERATURE:
                break;
              case hmUI.edit_type.SUN:
                break;
              default:
                break
            }
  
                    
            normal$_$component_1$_$component = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP,{
              edit_id: 1,
              x: 161,
              y: 275,
              w: 158,
              h: 158,
              select_image: '36.png',
              un_select_image: '37.png',
              default_type: hmUI.edit_type.HEART,
              optional_types: [{"type":hmUI.edit_type.HEART,"preview":"39.png"},{"type":hmUI.edit_type.BATTERY,"preview":"40.png"},{"type":hmUI.edit_type.CAL,"preview":"41.png"},{"type":hmUI.edit_type.PAI,"preview":"42.png"}],
              count: 4,
              tips_BG: '38.png',
              tips_x: 18,
              tips_y: -56,
              tips_width: 122,
            });
  
                    
            editType = normal$_$component_1$_$component.getProperty(hmUI.prop.CURRENT_TYPE);
        
            switch (editType) {
              case hmUI.edit_type.STEP:
                break;
              case hmUI.edit_type.BATTERY:
                            
                normal$_$battery$_$text$_$component_1$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 226,
                  y: 385,
                  type: hmUI.data_type.BATTERY,
                  font_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
                  align_h: hmUI.align.CENTER_H,
                  h_space: 0,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  unit_sc: '44.png',//单位
                  unit_tc: '44.png',//单位
                  unit_en: '44.png',//单位
                  invalid_image: '43.png',// 无数据时显示的图片
                  padding: false,
                  isCharacter: false
                });
  
                            
                normal$_$battery$_$pointer_progress$_$component_1$_$img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '46.png',
                  center_x: 240,
                  center_y: 354,
                  x: 6,
                  y: 61,
                  type: hmUI.data_type.BATTERY,
                  start_angle: 0,
                  end_angle: 360,
                  cover_path: '',
                  cover_x: 0,
                  cover_y: 0,
                  scale_x: 161,
                  scale_y: 276,
                  scale_sc: '45.png',
                  scale_tc: '45.png',
                  scale_en: '45.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
  
                break;
              case hmUI.edit_type.HEART:
                            
                normal$_$heart_rate$_$text$_$component_1$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 226,
                  y: 385,
                  type: hmUI.data_type.HEART,
                  font_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
                  align_h: hmUI.align.CENTER_H,
                  h_space: 0,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  invalid_image: '47.png',// 无数据时显示的图片
                  padding: false,
                  isCharacter: false
                });
  
                            
                normal$_$heart_rate$_$pointer_progress$_$component_1$_$img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '49.png',
                  center_x: 240,
                  center_y: 354,
                  x: 6,
                  y: 61,
                  type: hmUI.data_type.HEART,
                  start_angle: 0,
                  end_angle: 360,
                  cover_path: '',
                  cover_x: 0,
                  cover_y: 0,
                  scale_x: 161,
                  scale_y: 276,
                  scale_sc: '48.png',
                  scale_tc: '48.png',
                  scale_en: '48.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
  
                break;
              case hmUI.edit_type.CAL:
                            
                normal$_$calorie$_$current$_$component_1$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 222,
                  y: 382,
                  type: hmUI.data_type.CAL,
                  font_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
                  align_h: hmUI.align.CENTER_H,
                  h_space: 0,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  invalid_image: '50.png',// 无数据时显示的图片
                  padding: false,
                  isCharacter: false
                });
  
                            
                normal$_$calorie$_$pointer_progress$_$component_1$_$img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '52.png',
                  center_x: 240,
                  center_y: 354,
                  x: 6,
                  y: 61,
                  type: hmUI.data_type.CAL,
                  start_angle: 0,
                  end_angle: 360,
                  cover_path: '',
                  cover_x: 0,
                  cover_y: 0,
                  scale_x: 161,
                  scale_y: 276,
                  scale_sc: '51.png',
                  scale_tc: '51.png',
                  scale_en: '51.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
  
                break;
              case hmUI.edit_type.PAI:
                            
                normal$_$pai$_$weekly$_$component_1$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 226,
                  y: 382,
                  type: hmUI.data_type.PAI_WEEKLY,
                  font_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
                  align_h: hmUI.align.CENTER_H,
                  h_space: 0,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  invalid_image: '53.png',// 无数据时显示的图片
                  padding: false,
                  isCharacter: false
                });
  
                            
                normal$_$pai$_$pointer_progress$_$component_1$_$img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '55.png',
                  center_x: 240,
                  center_y: 354,
                  x: 6,
                  y: 61,
                  type: hmUI.data_type.PAI_WEEKLY,
                  start_angle: 0,
                  end_angle: 360,
                  cover_path: '',
                  cover_x: 0,
                  cover_y: 0,
                  scale_x: 161,
                  scale_y: 276,
                  scale_sc: '54.png',
                  scale_tc: '54.png',
                  scale_en: '54.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
  
                break;
              case hmUI.edit_type.DISTANCE:
                break;
              case hmUI.edit_type.AQI:
                break;
              case hmUI.edit_type.HUMIDITY:
                break;
              case hmUI.edit_type.UVI:
                break;
              case hmUI.edit_type.DATE:
                break;
              case hmUI.edit_type.WEEK:
                break;
              case hmUI.edit_type.WEATHER:
                break;
              case hmUI.edit_type.TEMPERATURE:
                break;
              case hmUI.edit_type.SUN:
                break;
              default:
                break
            }
  
                    
            normal$_$component$_$cover = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK,{
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '56.png',
              show_level:hmUI.show_level.ONLY_EDIT,
            });
  
                    
            normal$_$analog_clock$_$time_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 11,
              hour_posY: 154,
              hour_path: '57.png',
              hour_cover_path: '',
              hour_cover_x: 0,
              hour_cover_y: 0,
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 15,
              minute_posY: 222,
              minute_path: '58.png',
              minute_cover_path: '',
              minute_cover_x: 0,
              minute_cover_y: 0,
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 9,
              second_posY: 232,
              second_path: '59.png',
              second_cover_path: '',
              second_cover_x: 0,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$component$_$mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK,{
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '60.png',
              show_level:hmUI.show_level.ONLY_EDIT,
            });
  
                    
            idle$_$analog_clock$_$time_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 11,
              hour_posY: 154,
              hour_path: '57.png',
              hour_cover_path: '',
              hour_cover_x: 0,
              hour_cover_y: 0,
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 15,
              minute_posY: 222,
              minute_path: '58.png',
              minute_cover_path: '',
              minute_cover_x: 0,
              minute_cover_y: 0,
              show_level: hmUI.show_level.ONAL_AOD,
            });
  
            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  