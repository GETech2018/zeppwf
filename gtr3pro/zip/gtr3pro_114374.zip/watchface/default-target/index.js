try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_3b49c47be37549e3ba0d1e4cb5d2ff4d = '';
        let normal$_$text_7585696391f846fc82ef100e2373d995 = '';
        let normal$_$text_cd3921fdfb3b4c5184c5a6ddf8f73dbe = '';
        let normal$_$text_b13643da0d6a4d038de9a3212ba4a182 = '';
        let stepSensor = '';
        let heartSensor = '';
        let calorieSensor = '';
        let batterySensor = '';
        const logger = Logger.getLogger('watchface6');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    day_startX: 209,
                    day_startY: 269,
                    day_sc_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    day_tc_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    day_en_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    day_align: hmUI.align.LEFT,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 6,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 176,
                    y: 269,
                    week_en: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png'
                    ],
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 109,
                    hour_startY: 134,
                    hour_array: [
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png'
                    ],
                    hour_space: 6,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 233,
                    minute_startY: 134,
                    minute_array: [
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png'
                    ],
                    minute_space: 6,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    am_x: 355,
                    am_y: 182,
                    am_sc_path: '37.png',
                    am_en_path: '38.png',
                    pm_x: 355,
                    pm_y: 182,
                    pm_sc_path: '39.png',
                    pm_en_path: '40.png',
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_3b49c47be37549e3ba0d1e4cb5d2ff4d = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 109,
                    y: 275,
                    w: 58,
                    h: 22,
                    text: '[SC]',
                    color: '0xFFf4cc33',
                    text_size: 17,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_7585696391f846fc82ef100e2373d995 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 352,
                    y: 300,
                    w: 48,
                    h: 25,
                    text: '[HR_Z]',
                    color: '0xFF000000',
                    text_size: 17,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_cd3921fdfb3b4c5184c5a6ddf8f73dbe = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 322,
                    y: 273,
                    w: 44,
                    h: 27,
                    text: '[CAL]',
                    color: '0xFF000000',
                    text_size: 18,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.RIGHT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    second_centerX: 377,
                    second_centerY: 156,
                    second_posX: 5,
                    second_posY: 23,
                    second_path: '41.png',
                    second_cover_x: 0,
                    second_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_b13643da0d6a4d038de9a3212ba4a182 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 183,
                    y: 392,
                    w: 58,
                    h: 34,
                    text: '[BATT_PER]',
                    color: '0xFFf5c402',
                    text_size: 22,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.RIGHT,
                    align_v: hmUI.align.BOTTOM,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 204,
                    y: 66,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: [
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: 1,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    negative_image: '53.png',
                    invalid_image: '52.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 94,
                    y: 301,
                    type: hmUI.data_type.DISTANCE,
                    font_array: [
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png',
                        '58.png',
                        '59.png',
                        '60.png',
                        '61.png',
                        '62.png',
                        '63.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    dot_image: '64.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '65.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 176,
                    y: 269,
                    week_en: [
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png',
                        '71.png',
                        '72.png'
                    ],
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 111,
                    hour_startY: 134,
                    hour_array: [
                        '73.png',
                        '74.png',
                        '75.png',
                        '76.png',
                        '77.png',
                        '78.png',
                        '79.png',
                        '80.png',
                        '81.png',
                        '82.png'
                    ],
                    hour_space: 11,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 251,
                    minute_startY: 134,
                    minute_array: [
                        '73.png',
                        '74.png',
                        '75.png',
                        '76.png',
                        '77.png',
                        '78.png',
                        '79.png',
                        '80.png',
                        '81.png',
                        '82.png'
                    ],
                    minute_space: 11,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                if (!stepSensor) {
                    stepSensor = hmSensor.createSensor(hmSensor.id.STEP);
                }
                if (!heartSensor) {
                    heartSensor = hmSensor.createSensor(hmSensor.id.HEART);
                }
                if (!calorieSensor) {
                    calorieSensor = hmSensor.createSensor(hmSensor.id.CALORIE);
                }
                if (!batterySensor) {
                    batterySensor = hmSensor.createSensor(hmSensor.id.BATTERY);
                }
                stepSensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_3b49c47be37549e3ba0d1e4cb5d2ff4d.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                }), heartSensor.addEventListener(heartSensor.event.LAST, function () {
                    normal$_$text_7585696391f846fc82ef100e2373d995.setProperty(hmUI.prop.MORE, { text: `${ String(heartSensor.last).padStart(3, '0') }` });
                }), calorieSensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_cd3921fdfb3b4c5184c5a6ddf8f73dbe.setProperty(hmUI.prop.MORE, { text: `${ calorieSensor.current }` });
                }), batterySensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_b13643da0d6a4d038de9a3212ba4a182.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }` });
                });
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        normal$_$text_3b49c47be37549e3ba0d1e4cb5d2ff4d.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                        normal$_$text_7585696391f846fc82ef100e2373d995.setProperty(hmUI.prop.MORE, { text: `${ String(heartSensor.last).padStart(3, '0') }` });
                        normal$_$text_cd3921fdfb3b4c5184c5a6ddf8f73dbe.setProperty(hmUI.prop.MORE, { text: `${ calorieSensor.current }` });
                        normal$_$text_b13643da0d6a4d038de9a3212ba4a182.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }` });
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}