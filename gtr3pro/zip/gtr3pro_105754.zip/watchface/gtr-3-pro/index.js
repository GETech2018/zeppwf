
try {
  (() => {
  
var __$$app$$__ = __$$hmAppManager$$__.currentApp;

function noTreeShaking() {}

function getApp() {
  return __$$app$$__.app;
}

function getCurrentPage() {
  return __$$app$$__.current && __$$app$$__.current.module;
}

var __$$module$$__ = __$$app$$__.current;
var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
var { px } = getApp().__globals__;

  /*
* ZeppOS bundle tool v2.1.49
* Copyright © Zepp. All Rights Reserved
*/
'use strict';

let hour_h = null;
let hour_l = null;
let t = new Date();
const logger = Logger.getLogger('watchface6');
const img = function (type) {
    return path => type + '/' + path;
}('images');
__$$module$$__.module = DeviceRuntimeCore.WatchFace({
    init_view() {
        times = [];
        times_dim = [];
        for (let i = 0; i < 10; i++) {
            times.push(img(`time/time_${ i }.png`));
            times_dim.push(img(`time_dim/time_${ i }.png`));
        }
        hours_low = [];
        for (let i = 0; i < 10; i++) {
            hours_low.push(img(`hour_low/hour_low_${ i }.png`));
        }
        dates = [];
        dates_dim = [];
        for (let i = 0; i < 10; i++) {
            dates.push(img(`date/date_${ i }.png`));
            dates_dim.push(img(`date_dim/date_${ i }.png`));
        }
        week_en = [];
        week_tc = [];
        week_sc = [];
        for (let i = 1; i < 8; i++) {
            week_en.push(img(`week/week_en_${ i }.png`));
            week_tc.push(img(`week/week_tc_${ i }.png`));
            week_sc.push(img(`week/week_sc_${ i }.png`));
        }
        hmUI.createWidget(hmUI.widget.IMG, {
            x: px(0),
            y: px(0),
            w: px(480),
            h: px(480),
            src: img('bg.png'),
            show_level: hmUI.show_level.ONLY_NORMAL
        });
        hmUI.createWidget(hmUI.widget.IMG_ANIM, {
            x: px(0),
            y: px(0),
            anim_path: 'images/anim',
            anim_prefix: 'anim',
            anim_ext: 'png',
            anim_fps: 8,
            anim_size: 24,
            anim_repeat: true,
            repeat_count: 255,
            anim_status: hmUI.anim_status.START
        });
        hour_h = hmUI.createWidget(hmUI.widget.IMG, {
            x: px(78),
            y: px(132),
            w: px(62),
            h: px(90),
            src: '',
            show_level: hmUI.show_level.ONLY_NORMAL
        });
        hour_l = hmUI.createWidget(hmUI.widget.IMG, {
            x: px(148),
            y: px(132),
            w: px(62),
            h: px(90),
            src: '',
            show_level: hmUI.show_level.ONLY_NORMAL
        });
        hmUI.createWidget(hmUI.widget.IMG_TIME, {
            hour_zero: 1,
            hour_startX: px(316),
            hour_startY: px(125),
            hour_array: [],
            hour_space: px(11),
            hour_align: hmUI.align.LEFT,
            minute_zero: 1,
            minute_startX: px(270),
            minute_startY: px(132),
            minute_array: times,
            minute_space: px(8),
            minute_align: hmUI.align.LEFT,
            minute_follow: 0,
            am_x: px(88),
            am_y: px(93),
            am_sc_path: img('am_cn.png'),
            am_en_path: img('am_en.png'),
            pm_x: px(88),
            pm_y: px(93),
            pm_sc_path: img('pm_cn.png'),
            pm_en_path: img('pm_en.png'),
            show_level: hmUI.show_level.ONLY_NORMAL
        });
        hmUI.createWidget(hmUI.widget.IMG, {
            x: px(209),
            y: px(132),
            w: px(62),
            h: px(90),
            src: img('time/time_s.png'),
            show_level: hmUI.show_level.ONLY_NORMAL
        });
        hmUI.createWidget(hmUI.widget.IMG_TIME, {
            hour_zero: 1,
            hour_startX: px(78),
            hour_startY: px(132),
            hour_array: times_dim,
            hour_space: px(8),
            hour_align: hmUI.align.LEFT,
            minute_zero: 1,
            minute_startX: px(270),
            minute_startY: px(132),
            minute_array: times_dim,
            minute_space: px(8),
            minute_align: hmUI.align.LEFT,
            minute_follow: 0,
            am_x: px(88),
            am_y: px(93),
            am_sc_path: img('am_cn_dim.png'),
            am_en_path: img('am_en_dim.png'),
            pm_x: px(88),
            pm_y: px(93),
            pm_sc_path: img('pm_cn_dim.png'),
            pm_en_path: img('pm_en_dim.png'),
            show_level: hmUI.show_level.ONLY_AOD
        });
        hmUI.createWidget(hmUI.widget.IMG, {
            x: px(209),
            y: px(132),
            w: px(62),
            h: px(90),
            src: img('time_dim/time_s.png'),
            show_level: hmUI.show_level.ONLY_AOD
        });
        hmUI.createWidget(hmUI.widget.IMG_DATE, {
            month_startX: px(271),
            month_startY: px(93),
            month_sc_array: dates,
            month_tc_array: dates,
            month_en_array: dates,
            month_align: hmUI.align.LEFT,
            month_zero: 1,
            month_follow: 0,
            month_space: px(0),
            month_is_character: false,
            day_startX: px(356),
            day_startY: px(93),
            day_sc_array: dates,
            day_tc_array: dates,
            day_en_array: dates,
            day_align: hmUI.align.LEFT,
            day_zero: 1,
            day_follow: 0,
            day_space: px(0),
            day_is_character: false,
            show_level: hmUI.show_level.ONLY_NORMAL
        });
        hmUI.createWidget(hmUI.widget.IMG, {
            x: px(325),
            y: px(93),
            w: px(22),
            h: px(32),
            src: img('date/date_s.png'),
            show_level: hmUI.show_level.ONLY_NORMAL
        });
        hmUI.createWidget(hmUI.widget.IMG_WEEK, {
            x: 149,
            y: 93,
            week_en: week_en,
            week_tc: week_tc,
            week_sc: week_sc,
            show_level: hmUI.show_level.ONLY_NORMAL
        });
        hmUI.createWidget(hmUI.widget.IMG_DATE, {
            month_startX: px(271),
            month_startY: px(93),
            month_sc_array: dates_dim,
            month_tc_array: dates_dim,
            month_en_array: dates_dim,
            month_align: hmUI.align.LEFT,
            month_zero: 1,
            month_follow: 0,
            month_space: px(0),
            month_is_character: false,
            day_startX: px(356),
            day_startY: px(93),
            day_sc_array: dates_dim,
            day_tc_array: dates_dim,
            day_en_array: dates_dim,
            day_align: hmUI.align.LEFT,
            day_zero: 1,
            day_follow: 0,
            day_space: px(0),
            day_is_character: false,
            show_level: hmUI.show_level.ONLY_AOD
        });
        hmUI.createWidget(hmUI.widget.IMG, {
            x: px(325),
            y: px(93),
            w: px(22),
            h: px(32),
            src: img('date_dim/date_s.png'),
            show_level: hmUI.show_level.ONLY_AOD
        });
        hmUI.createWidget(hmUI.widget.IMG_WEEK, {
            x: 149,
            y: 93,
            week_en: week_en,
            week_tc: week_tc,
            week_sc: week_sc,
            show_level: hmUI.show_level.ONLY_AOD
        });
        function setHour() {
            t.setTime(Date.now());
            h12 = (t.getHours() + 11) % 12 + 1;
            hour_h.setProperty(hmUI.prop.SRC, times[parseInt(h12 / 10)]);
            hour_l.setProperty(hmUI.prop.SRC, hours_low[parseInt(h12 % 10)]);
        }
        setHour();
        mintimer = timer.createTimer(10, 1000, setHour, {});
    },
    onInit() {
        logger.log('index page.js on init invoke');
    },
    build() {
        logger.log('index page.js on build invoke');
        this.init_view();
    },
    onDestory() {
        logger.log('index page.js on destory invoke');
    }
});
/*
* end js
*/

  ;
  })()
} catch(e) {
  console.log(e)
  /* todo */
}