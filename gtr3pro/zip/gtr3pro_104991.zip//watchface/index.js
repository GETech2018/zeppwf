
    /*
    ** huamiOS bundle tool v1.0.17
    * *huamiOS watchface js version v1.0.1
    * *Copyright © Huami. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start
        let normal$_$background$_$bg = ''
        let normal$_$temperature$_$current$_$text_img = ''
        let normal$_$date$_$img_date = ''
        let normal$_$week$_$week = ''
        let normal$_$heart_rate$_$text$_$text_img = ''
        let normal$_$heart_rate$_$text$_$separator_img = ''
        let normal$_$step$_$current$_$text_img = ''
        let normal$_$step$_$current$_$separator_img = ''
        let normal$_$battery$_$text$_$text_img = ''
        let normal$_$battery$_$pointer_progress$_$img_pointer = ''
        let normal$_$weather$_$image_progress$_$img_level = ''
        let normal$_$analog_clock$_$time_pointer = ''
        let idle$_$idle_background$_$bg = ''
        let idle$_$temperature$_$current$_$text_img = ''
        let idle$_$date$_$img_date = ''
        let idle$_$week$_$week = ''
        let idle$_$heart_rate$_$text$_$text_img = ''
        let idle$_$heart_rate$_$text$_$separator_img = ''
        let idle$_$step$_$current$_$text_img = ''
        let idle$_$step$_$current$_$separator_img = ''
        let idle$_$battery$_$text$_$text_img = ''
        let idle$_$battery$_$pointer_progress$_$img_pointer = ''
        let idle$_$weather$_$image_progress$_$img_level = ''
        let idle$_$analog_clock$_$time_pointer = ''
        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            normal$_$background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$temperature$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 216,
              y: 147,
              type: hmUI.data_type.WEATHER_CURRENT,
              font_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: '14.png',//单位
              unit_en: '15.png',//单位
              negative_image: '13.png', //负号图片
              invalid_image: '12.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$date$_$img_date = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 333,
              month_startY: 229,
              month_sc_array: ["16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png"],
              month_tc_array: ["16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png"],
              month_en_array: ["16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png"],
              month_align: hmUI.align.LEFT,
              month_zero: 0,
              month_follow: 0,
              month_space: 0,
              month_is_character: true,
              day_startX: 415,
              day_startY: 229,
              day_sc_array: ["28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png"],
              day_tc_array: ["28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png"],
              day_en_array: ["28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png"],
              day_align: hmUI.align.LEFT,
              day_zero: 1,
              day_follow: 0,
              day_space: 0,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$week$_$week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 141,
              y: 304,
              week_en: ["38.png","39.png","40.png","41.png","42.png","43.png","44.png"],
              week_tc: ["38.png","39.png","40.png","41.png","42.png","43.png","44.png"],
              week_sc: ["38.png","39.png","40.png","41.png","42.png","43.png","44.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$heart_rate$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 250,
              y: 369,
              type: hmUI.data_type.HEART,
              font_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              align_h: hmUI.align.LEFT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: '45.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$heart_rate$_$text$_$separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 188,
              y: 368,
              w: 55,
              h: 21,
              src: '46.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$step$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 250,
              y: 342,
              type: hmUI.data_type.STEP,
              font_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              align_h: hmUI.align.LEFT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: '47.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$step$_$current$_$separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 167,
              y: 342,
              w: 78,
              h: 21,
              src: '48.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$battery$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 122,
              y: 256,
              type: hmUI.data_type.BATTERY,
              font_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              align_h: hmUI.align.LEFT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: '50.png',//单位
              unit_tc: '50.png',//单位
              unit_en: '50.png',//单位
              invalid_image: '49.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$battery$_$pointer_progress$_$img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '51.png',
              center_x: 142,
              center_y: 237,
              x: 15,
              y: 81,
              type: hmUI.data_type.BATTERY,
              start_angle: -90,
              end_angle: 90,
              cover_path: '',
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$weather$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 219,
              y: 100,
              image_array: ["52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$analog_clock$_$time_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 42,
              hour_posY: 240,
              hour_path: '81.png',
              hour_cover_path: '',
              hour_cover_x: 0,
              hour_cover_y: 0,
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 42,
              minute_posY: 240,
              minute_path: '82.png',
              minute_cover_path: '',
              minute_cover_x: 0,
              minute_cover_y: 0,
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 42,
              second_posY: 240,
              second_path: '83.png',
              second_cover_path: '',
              second_cover_x: 0,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            idle$_$idle_background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '84.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

                    
            idle$_$temperature$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 208,
              y: 147,
              type: hmUI.data_type.WEATHER_CURRENT,
              font_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              align_h: hmUI.align.RIGHT,
              h_space: 0,
              show_level: hmUI.show_level.ONAL_AOD,
              unit_sc: '14.png',//单位
              negative_image: '13.png', //负号图片
              invalid_image: '12.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            idle$_$date$_$img_date = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 333,
              month_startY: 229,
              month_sc_array: ["85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png","93.png","94.png","95.png","96.png"],
              month_tc_array: ["85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png","93.png","94.png","95.png","96.png"],
              month_en_array: ["85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png","93.png","94.png","95.png","96.png"],
              month_align: hmUI.align.LEFT,
              month_zero: 0,
              month_follow: 0,
              month_space: 0,
              month_is_character: true,
              day_startX: 415,
              day_startY: 229,
              day_sc_array: ["97.png","98.png","99.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png"],
              day_tc_array: ["97.png","98.png","99.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png"],
              day_en_array: ["97.png","98.png","99.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png"],
              day_align: hmUI.align.LEFT,
              day_zero: 1,
              day_follow: 0,
              day_space: 0,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });
  
                    
            idle$_$week$_$week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 141,
              y: 304,
              week_en: ["107.png","108.png","109.png","110.png","111.png","112.png","113.png"],
              week_tc: ["107.png","108.png","109.png","110.png","111.png","112.png","113.png"],
              week_sc: ["107.png","108.png","109.png","110.png","111.png","112.png","113.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });
  
                    
            idle$_$heart_rate$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 250,
              y: 369,
              type: hmUI.data_type.HEART,
              font_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              align_h: hmUI.align.LEFT,
              h_space: 0,
              show_level: hmUI.show_level.ONAL_AOD,
              invalid_image: '45.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            idle$_$heart_rate$_$text$_$separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 188,
              y: 368,
              w: 55,
              h: 21,
              src: '46.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

                    
            idle$_$step$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 250,
              y: 342,
              type: hmUI.data_type.STEP,
              font_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              align_h: hmUI.align.LEFT,
              h_space: 0,
              show_level: hmUI.show_level.ONAL_AOD,
              invalid_image: '47.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            idle$_$step$_$current$_$separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 167,
              y: 342,
              w: 78,
              h: 21,
              src: '48.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

                    
            idle$_$battery$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 107,
              y: 256,
              type: hmUI.data_type.BATTERY,
              font_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              align_h: hmUI.align.RIGHT,
              h_space: 0,
              show_level: hmUI.show_level.ONAL_AOD,
              unit_sc: '50.png',//单位
              unit_tc: '50.png',//单位
              unit_en: '50.png',//单位
              invalid_image: '49.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            idle$_$battery$_$pointer_progress$_$img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '114.png',
              center_x: 142,
              center_y: 237,
              x: 15,
              y: 81,
              type: hmUI.data_type.BATTERY,
              start_angle: -90,
              end_angle: 90,
              cover_path: '',
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONAL_AOD,
            });
  
                    
            idle$_$weather$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 219,
              y: 100,
              image_array: ["115.png","116.png","117.png","118.png","119.png","120.png","121.png","122.png","123.png","124.png","125.png","126.png","127.png","128.png","129.png","130.png","131.png","132.png","133.png","134.png","135.png","136.png","137.png","138.png","139.png","140.png","141.png","142.png","143.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

                    
            idle$_$analog_clock$_$time_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 42,
              hour_posY: 240,
              hour_path: '144.png',
              hour_cover_path: '',
              hour_cover_x: 0,
              hour_cover_y: 0,
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 42,
              minute_posY: 240,
              minute_path: '145.png',
              minute_cover_path: '',
              minute_cover_x: 0,
              minute_cover_y: 0,
              show_level: hmUI.show_level.ONAL_AOD,
            });
  
            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  