try {
    (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;

        var __$$module$$__ = __$$app$$__.current;
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        /*
    * huamiOS bundle tool v1.0.17
    * Copyright © Huami. All Rights Reserved
    */
        'use strict';

        console.log("----->>>current")
        console.log(__$$hmAppManager$$__.currentApp.pid)
        console.log(__$$hmAppManager$$__.currentApp.current)

        const WIDGET_OUT_ID = 101;
        const WIDGET_MID_ID = 102;
        const WIDGET_INNER_ID = 103; 
        const WIDGET_UP_ID = 104;
        const WIDGET_DOWN_ID = 105; 

        const WIDGET_EDIT_LEFT_SIZE = 48;  
        const WIDGET_INNER = 1;
        const WIDGET_MID = 2;
        const WIDGET_OUT = 3;
        const WIDGET_RIGHT_1 = 4;
        const WIDGET_RIGHT_2 = 5;
      
        const WIDGET_TIPS_WIDTH = 102;
        const ROOTPATH = "images/";
        const WIDGET_BG_PATH = ROOTPATH + "fast/";
      
        const font_red_arr = [
            ROOTPATH + "fast/font_red/00.png",
            ROOTPATH + "fast/font_red/01.png",
            ROOTPATH + "fast/font_red/02.png",
            ROOTPATH + "fast/font_red/03.png",
            ROOTPATH + "fast/font_red/04.png",
            ROOTPATH + "fast/font_red/05.png",
            ROOTPATH + "fast/font_red/06.png",
            ROOTPATH + "fast/font_red/07.png",  
            ROOTPATH + "fast/font_red/08.png",
            ROOTPATH + "fast/font_red/09.png",  
        ] 
        const font_green_arr = [
            ROOTPATH + "fast/font_green/00.png",
            ROOTPATH + "fast/font_green/01.png",
            ROOTPATH + "fast/font_green/02.png",
            ROOTPATH + "fast/font_green/03.png",
            ROOTPATH + "fast/font_green/04.png",
            ROOTPATH + "fast/font_green/05.png",
            ROOTPATH + "fast/font_green/06.png",
            ROOTPATH + "fast/font_green/07.png",  
            ROOTPATH + "fast/font_green/08.png",
            ROOTPATH + "fast/font_green/09.png",  
        ] 
        const font_blue_arr = [
            ROOTPATH + "fast/font_blue/00.png",
            ROOTPATH + "fast/font_blue/01.png",
            ROOTPATH + "fast/font_blue/02.png",
            ROOTPATH + "fast/font_blue/03.png",
            ROOTPATH + "fast/font_blue/04.png",
            ROOTPATH + "fast/font_blue/05.png",
            ROOTPATH + "fast/font_blue/06.png",
            ROOTPATH + "fast/font_blue/07.png",  
            ROOTPATH + "fast/font_blue/08.png",
            ROOTPATH + "fast/font_blue/09.png",  
        ] 
        const weather_arr = [ 
            ROOTPATH + "fast/weather/00.png",
            ROOTPATH + "fast/weather/01.png",
            ROOTPATH + "fast/weather/02.png",
            ROOTPATH + "fast/weather/03.png",
            ROOTPATH + "fast/weather/04.png",
            ROOTPATH + "fast/weather/05.png",
            ROOTPATH + "fast/weather/06.png",
            ROOTPATH + "fast/weather/07.png",   
            ROOTPATH + "fast/weather/08.png",
            ROOTPATH + "fast/weather/09.png",  
            ROOTPATH + "fast/weather/10.png",
            ROOTPATH + "fast/weather/11.png",
            ROOTPATH + "fast/weather/12.png",
            ROOTPATH + "fast/weather/13.png",
            ROOTPATH + "fast/weather/14.png",
            ROOTPATH + "fast/weather/15.png",
            ROOTPATH + "fast/weather/16.png",
            ROOTPATH + "fast/weather/17.png",   
            ROOTPATH + "fast/weather/18.png",
            ROOTPATH + "fast/weather/19.png", 
            ROOTPATH + "fast/weather/20.png",
            ROOTPATH + "fast/weather/21.png",
            ROOTPATH + "fast/weather/22.png",
            ROOTPATH + "fast/weather/23.png",
            ROOTPATH + "fast/weather/24.png",
            ROOTPATH + "fast/weather/25.png",
            ROOTPATH + "fast/weather/26.png",
            ROOTPATH + "fast/weather/27.png",   
            ROOTPATH + "fast/weather/28.png", 
        ]
        const timeArray = [
            ROOTPATH + "fast/time/00.png",
            ROOTPATH + "fast/time/01.png",
            ROOTPATH + "fast/time/02.png",
            ROOTPATH + "fast/time/03.png",
            ROOTPATH + "fast/time/04.png",
            ROOTPATH + "fast/time/05.png",
            ROOTPATH + "fast/time/06.png",
            ROOTPATH + "fast/time/07.png",   
            ROOTPATH + "fast/time/08.png",
            ROOTPATH + "fast/time/09.png", 
        ] 
        let rightFontArr = [
            ROOTPATH + "fast/fonts/00.png",
            ROOTPATH + "fast/fonts/01.png",
            ROOTPATH + "fast/fonts/02.png",
            ROOTPATH + "fast/fonts/03.png",
            ROOTPATH + "fast/fonts/04.png",
            ROOTPATH + "fast/fonts/05.png",
            ROOTPATH + "fast/fonts/06.png",
            ROOTPATH + "fast/fonts/07.png",   
            ROOTPATH + "fast/fonts/08.png",
            ROOTPATH + "fast/fonts/09.png",
        ] 
        const widget_Small_Preview = ROOTPATH + "fast/" 
        const widget_Big_Preview = ROOTPATH + "widget_preview_right/"
          
        const TIPS_ROOT = ROOTPATH + "tips/"
        const WIDGET_TIPS_PATH = TIPS_ROOT + "widget_tips.png";
      
        let select = null 
        let innerWidget = null
        let midWidget = null
        let outWidget = null
        let rightWidget1 = null
        let rightWidget2 = null

        let baseURL = '' 
        let imgLevelBg = ''
 
        let groupX = 0;
        let groupY = 0;
        let arrRedImg = []
        let arrGreenImg = []
        let arrBlueImg = []
        /* 遍历数组 */
        for(let i = 1; i < 11; i++){
            arrRedImg.push( ROOTPATH + 'fast/red/' + i + '.png')
            arrGreenImg.push( ROOTPATH + 'fast/green/' + i + '.png')
            arrBlueImg.push( ROOTPATH + 'fast/blue/' + i + '.png')
        }
        
        const logger = DeviceRuntimeCore.HmLogger.getLogger("sanjiao");
        __$$module$$__.module = DeviceRuntimeCore.Page({
            parseWidgetConfig_right(editType) {
                let config = {
                    bgPath: null, //背景图
                    iconPath: null, //图标
                    dataType: null,//数据类型
                    nonePath: null,//无数据的图片
                    negativeImage:null,
                    unitEnPath: null,//单位
                    unitScPath: null,
                    unitTcPath: null,
                    spPath: null, 
                    textX:0 
                }; 
                switch (editType) {
                    case hmUI.edit_type.STEP:
                        config.bgPath = ROOTPATH + "widget_right/step.png";   
                        config.dataType = hmUI.data_type.STEP;  
                         config.textX = 305;   
                        break; 
                    case hmUI.edit_type.HEART:
                        config.bgPath = ROOTPATH + "widget_right/heart.png";  
                        config.dataType = hmUI.data_type.HEART;
                        config.textX = 305;    
                        break;  
                    case hmUI.edit_type.WEATHER:  
                        config.dataType = hmUI.data_type.WEATHER_CURRENT; 
                        config.unitEnPath = ROOTPATH + "widget_right/du.png";   
                        config.unitScPath = ROOTPATH + "widget_right/du.png"; 
                        config.unitTcPath = ROOTPATH + "widget_right/du.png"; 
                        config.textX = 309;   
                  
                        break;      
                    case hmUI.edit_type.HUMIDITY:
                        config.bgPath = ROOTPATH + "widget_right/hum.png";  
                        config.dataType = hmUI.data_type.HUMIDITY; 
                        config.unitEnPath = ROOTPATH + "widget_right/precent.png";   
                        config.unitScPath = ROOTPATH + "widget_right/precent.png";
                        config.unitTcPath = ROOTPATH + "widget_right/precent.png";  
                        config.textX = 305;  
                        break; 
                    case hmUI.edit_type.UVI:
                        config.bgPath = ROOTPATH + "widget_right/uvi.png"; 
                        config.dataType = hmUI.data_type.UVI; 
                        config.textX = 305;  
                        break;
                    case hmUI.edit_type.AQI: 
                        config.bgPath = ROOTPATH +"widget_right/aqi.png"; 
                        config.dataType = hmUI.data_type.AQI; 
                        config.textX = 305;  
                        break;
                    default:
                        // console.log("invalid editType type=" + editType);
                        return config;
                } 
                return config;
            },
            parseWidgetConfig(editType, baseURL) {
                let config = {
                    bgPath: null, //背景图
                    iconPath: null, //图标
                    dataType: null,//数据类型
                    nonePath: null,//无数据的图片
                    negativeImage:null,
                    unitEnPath: null,//单位
                    unitScPath: null,
                    unitTcPath: null,
                    spPath: null,
                    pointerType:null,
                    startAngle: 0, //指针开始角度
                    endAngle: 360, //指针结束角度
                    imgLevelBg:null,
                    textX:0
                };
          
                switch (editType) {
                    case hmUI.edit_type.STEP:
                        config.bgPath = baseURL + "step.png";  
                        config.nonePath =  "none.png";
                        config.dataType = hmUI.data_type.STEP; 
                        config.textX = 270
                        break;
                    case hmUI.edit_type.CAL:
                        config.bgPath = baseURL + "cal.png";  
                        config.nonePath =  "none.png";
                        config.dataType = hmUI.data_type.CAL; 
                        config.textX = 270
                        break;
                    case hmUI.edit_type.PAI:
                        config.bgPath = baseURL + "pai.png";  
                        config.nonePath =  "none.png";
                        config.dataType = hmUI.data_type.PAI_WEEKLY;   
                        config.textX = 270
                        break; 
                    case hmUI.edit_type.HEART:
                        config.bgPath = baseURL + "heart.png";  
                         config.nonePath =  "none.png";
                        config.dataType = hmUI.data_type.HEART; 
                         config.textX = 270
                        break;  
                    case hmUI.edit_type.BATTERY:
                        config.bgPath =  baseURL+ "bat.png";  
                        config.dataType = hmUI.data_type.BATTERY; 
                        config.nonePath =  "none.png";
                        config.unitEnPath = "precent.png";   
                        config.unitScPath =  "precent.png";
                        config.unitTcPath =  "precent.png";  
                         config.textX = 270
                        break;
                    case hmUI.edit_type.HUMIDITY:
                        config.bgPath = baseURL + "hum.png";  
                        config.dataType = hmUI.data_type.HUMIDITY;
                        config.nonePath =  "none.png";
                        config.unitEnPath = "precent.png";   
                        config.unitScPath = "precent.png";
                        config.unitTcPath = "precent.png";  
                        config.textX = 270
                        break;
                    
                    default:
                        // console.log("invalid editType type=" + editType);
                        return config;
                }
                if (config.bgPath != null) {
                    config.bgPath = WIDGET_BG_PATH + config.bgPath;
                }
                if (config.pointerType == null) {
                    config.pointerType = config.dataType;
                }
                return config;
            },
            drawWidget(widgetType, editType) {
              
                let bgX = 0;
                let bgY = 0; 
                let right_flag = false
                const bgSize = 56;  
                switch (widgetType) {
                    case WIDGET_INNER: 
                        bgX = 265;
                        bgY = 330;
                        baseURL = 'red_icon/'
                        imgLevelBg = 'red/' 
                        right_flag = false 
                        break;
                    case WIDGET_MID:
                        bgX = 265;
                        bgY = 380;
                        baseURL = 'green_icon/'
                        imgLevelBg = 'green/'
                         right_flag = false 
                        break;
                    case WIDGET_OUT:
                        bgX = 265;
                        bgY = 430; 
                        baseURL = 'blue_icon/'
                        imgLevelBg = 'blue/' 
                         right_flag = false
                        break;
                    case WIDGET_RIGHT_1: 
                        bgY = 92; 
                        right_flag = true
                       
                        break;   
                    case WIDGET_RIGHT_2: 
                        bgY = 325;
                        right_flag = true
                        break;      
                    default:
                        // console.log("invalid widgetType type=" + widgetType);
                        return;
                } 
             
                
                let config = null 
                if(right_flag){ 
                    config = this.parseWidgetConfig_right(editType);  
                } else {
                    config = this.parseWidgetConfig(editType, baseURL); 
                    config.imgLevelBg = imgLevelBg
                } 
                
                var imgArr = []
                var level_x = 0
                var level_y = 0
                var level_w = 0
                var level_h = 0
                var text_x = 0
                var text_y = 0
              
                if(right_flag){ 
                    var prop_obj2 = null 
                    //右侧: 两编辑框文字的渲染
                    prop_obj2 = {
                            x: config.textX, 
                            y: bgY + 48,
                            w: 132,
                            type: config.dataType,
                            font_array: rightFontArr,
                            h_space: 0, 
                            //图片间隔
                            align_h:hmUI.align.CENTER_H, 
                            invalid_image: ROOTPATH + 'widget_right/none.png',
                            padding:false, 
                            //是否补零 true为补零 
                            negative_image: ROOTPATH + 'widget_right/fuhao.png', 
                            show_level:hmUI.show_level. ONLY_NORMAL 
                    }
                    if(config.unitEnPath){
                        prop_obj2.unit_sc = config.unitScPath 
                        prop_obj2.unit_tc = config.unitTcPath 
                        prop_obj2.unit_en = config.unitEnPath 
                    }    
                    let text2 = hmUI.createWidget(hmUI.widget.TEXT_IMG, prop_obj2 );
                     
                    if(config.dataType != hmUI.data_type.WEATHER_CURRENT){
                        var img_prop = {
                            x: 331+18,
                            y: bgY-5,
                            w: 44,
                            h: 44, 
                            src: config.bgPath,
                            //表示只在正常表盘和息屏下显示 在可编辑下会不创建 会返回一个虚拟控件 保证js不报错
                            show_level:hmUI.show_level. ONLY_NORMAL 
                        }
                        hmUI.createWidget(hmUI.widget.IMG, img_prop );
                    
                    } else {
                        hmUI.createWidget(hmUI.widget.IMG_LEVEL,{
                            x: 350,
                            y: bgY-5,
                            w: 50,  
                            h: 50,
                            image_array:weather_arr,
                            image_length:weather_arr.length,
                            type: hmUI.data_type.WEATHER_CURRENT,
                            show_level:hmUI.show_level.ONLY_NORMAL
                         }); 

                    } 
 
                } else { 
                    var fontColorType = null  
                    if(config.imgLevelBg == 'red/'){ 
                        if(config.unitEnPath){
                            config.unitEnPath = ROOTPATH + "fast/red/precent.png";  
                            config.unitScPath = ROOTPATH + "fast/red/precent.png";
                            config.unitTcPath = ROOTPATH + "fast/red/precent.png";
                        }
                        config.nonePath = ROOTPATH + "fast/red/none.png";
                        level_x = 109
                        level_y = 108
                        level_w = 150
                        level_h = 264 
                        text_y = 115
                        fontColorType = font_red_arr
                        imgArr = arrRedImg
                        
                    }
                    if(config.imgLevelBg == 'green/' ){
                         if(config.unitEnPath){
                            config.unitEnPath = ROOTPATH + "fast/green/precent.png";  // du
                            config.unitScPath = ROOTPATH + "fast/green/precent.png";
                            config.unitTcPath = ROOTPATH + "fast/green/precent.png"; 
                        }
                        config.nonePath = ROOTPATH + "fast/green/none.png";
                        level_x = 55
                        level_y = 57
                        level_w = 210
                        // level_h = 266 
                        level_h = 366 
                        text_y = 65
                        fontColorType = font_green_arr
                        imgArr = arrGreenImg
                       
                    }
                    if(config.imgLevelBg == 'blue/' ){ 
                        if(config.unitEnPath){
                            config.unitEnPath = ROOTPATH + "fast/blue/precent.png";   
                            config.unitScPath = ROOTPATH + "fast/blue/precent.png";
                            config.unitTcPath = ROOTPATH + "fast/blue/precent.png"; 
                        }  
                        config.nonePath = ROOTPATH + "fast/blue/none.png";  
                        level_x = 7
                        level_y = 8
                        level_w = 258
                        level_h = 462 
                        text_y = 18
                        fontColorType = font_blue_arr 
                        imgArr = arrBlueImg
                       
                    }

                  
                    
                   
                    hmUI.createWidget(hmUI.widget.IMG_LEVEL,{
                        x: level_x,
                        y: level_y,
                        w: level_w,  
                        h: level_h,
                        image_array:imgArr,
                        image_length:imgArr.length,
                        type: config.dataType,
                        show_level:hmUI.show_level.ONLY_NORMAL
                    });
                   
                    var prop_obj = null
                     prop_obj = {
                            x: config.textX, 
                            y: text_y,
                            type: config.dataType,
                            font_array: fontColorType ,
                            h_space: 0, 
                            //图片间隔
                            align_h:hmUI.align.LEFT, 
                            invalid_image: config.nonePath,
                            padding:false, 
                            show_level:hmUI.show_level. ONLY_NORMAL 
                            //是否补零 true为补零 
                    }
                    var unitObj ={}
                    if(config.unitEnPath){
                        var  unitObj  = { 
                            unit_sc: config.unitScPath ,
                            //单位
                            unit_tc: config.unitTcPath,
                            //单位
                            unit_en: config.unitEnPath,
                            //单位  
                        }
                    }
                    let newObj = Object.assign(prop_obj,unitObj)  
                    let text = hmUI.createWidget(hmUI.widget.TEXT_IMG, newObj);

                    if(config.dataType == hmUI.data_type.BATTERY || 
                        config.dataType == hmUI.data_type.CAL ||
                        config.dataType == hmUI.data_type.HUMIDITY ||
                        config.dataType == hmUI.data_type.PAI_WEEKLY ||
                        config.dataType == hmUI.data_type.STEP || 
                        config.dataType == hmUI.data_type.HEART){ 
                            hmUI.createWidget(hmUI.widget.IMG,{
                                x: bgX,
                                y: bgY,
                                w: bgSize,
                                h: bgSize,
                                src: config.bgPath,
                                show_level:hmUI.show_level.ONLY_NORMAL
                            }); 
                        }  
                }
                
            },
            init_view() { 
                select = ROOTPATH + "select/" 
                var img_bg1 = hmUI.createWidget(hmUI.widget.IMG,{
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: ROOTPATH + "bg/bg.png", 
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });  
                let red_WidgetOptionalArray = [
                    { type: hmUI.edit_type.STEP, preview: widget_Small_Preview + "red_icon/step.png" },
                    { type: hmUI.edit_type.CAL, preview: widget_Small_Preview + "red_icon/cal.png" },
                    { type: hmUI.edit_type.PAI, preview: widget_Small_Preview + "red_icon/pai.png" },
                    { type: hmUI.edit_type.BATTERY, preview: widget_Small_Preview + "red_icon/bat.png" },
                    { type: hmUI.edit_type.HUMIDITY, preview: widget_Small_Preview + "red_icon/hum.png" },
                    { type: hmUI.edit_type.HEART, preview: widget_Small_Preview + "red_icon/heart.png" },
                ];  
                groupX = 259;
                groupY = 329;
                //可编辑组件
                innerWidget = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: WIDGET_INNER_ID,
                    x: groupX,
                    y: groupY,
                    w: WIDGET_EDIT_LEFT_SIZE,
                    h: WIDGET_EDIT_LEFT_SIZE,
                    select_image: select + "select_small.png",
                    un_select_image: select + "unselect_small.png",
                    default_type: hmUI.edit_type.PAI,
                    optional_types: red_WidgetOptionalArray,
                    count: red_WidgetOptionalArray.length,
                    tips_BG: WIDGET_TIPS_PATH,
                    tips_x: -106,
                    tips_y: 5,
                    tips_width: WIDGET_TIPS_WIDTH,
                    tips_margin:10,
                });
                var editType = innerWidget.getProperty(hmUI.prop.CURRENT_TYPE);
                this.drawWidget(WIDGET_INNER,editType);


                let green_WidgetOptionalArray = [
                    { type: hmUI.edit_type.STEP, preview: widget_Small_Preview + "green_icon/step.png" },
                    { type: hmUI.edit_type.CAL, preview: widget_Small_Preview + "green_icon/cal.png" },
                    { type: hmUI.edit_type.PAI, preview: widget_Small_Preview + "green_icon/pai.png" },
                    { type: hmUI.edit_type.BATTERY, preview: widget_Small_Preview + "green_icon/bat.png" },
                    { type: hmUI.edit_type.HUMIDITY, preview: widget_Small_Preview + "green_icon/hum.png" },
                    { type: hmUI.edit_type.HEART, preview: widget_Small_Preview + "green_icon/heart.png" },
                ];  
                groupX = 259;
                groupY = 377;
                midWidget = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: WIDGET_MID_ID,
                    x: groupX,
                    y: groupY,
                    w: WIDGET_EDIT_LEFT_SIZE,
                    h: WIDGET_EDIT_LEFT_SIZE,
                    select_image: select + "select_small.png",
                    un_select_image: select + "unselect_small.png",
                    default_type: hmUI.edit_type.STEP,
                    optional_types: green_WidgetOptionalArray,
                    count: green_WidgetOptionalArray.length,
                    tips_BG: WIDGET_TIPS_PATH,
                    tips_x: -106,
                    tips_y: 5,
                    tips_width: WIDGET_TIPS_WIDTH,
                    tips_margin:10,
                });
                editType = midWidget.getProperty(hmUI.prop.CURRENT_TYPE);
                this.drawWidget(WIDGET_MID,editType);
                
                let blue_WidgetOptionalArray = [
                    { type: hmUI.edit_type.STEP, preview: widget_Small_Preview + "blue_icon/step.png" },
                    { type: hmUI.edit_type.CAL, preview: widget_Small_Preview + "blue_icon/cal.png" },
                    { type: hmUI.edit_type.PAI, preview: widget_Small_Preview + "blue_icon/pai.png" },
                    { type: hmUI.edit_type.BATTERY, preview: widget_Small_Preview + "blue_icon/bat.png" },
                    { type: hmUI.edit_type.HUMIDITY, preview: widget_Small_Preview + "blue_icon/hum.png" },
                    { type: hmUI.edit_type.HEART, preview: widget_Small_Preview + "blue_icon/heart.png" },
                ];  
                groupX = 259;
                groupY = 425;
                outWidget = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: WIDGET_OUT_ID,
                    x: groupX,
                    y: groupY,
                    w: WIDGET_EDIT_LEFT_SIZE,
                    h: WIDGET_EDIT_LEFT_SIZE,
                    select_image: select + "select_small.png",
                    un_select_image: select + "unselect_small.png",
                    default_type: hmUI.edit_type.BATTERY,
                    optional_types: blue_WidgetOptionalArray,
                    count: blue_WidgetOptionalArray.length,
                    tips_BG: WIDGET_TIPS_PATH,
                    tips_x: -106,
                    tips_y: 5,
                    tips_width: WIDGET_TIPS_WIDTH,
                    tips_margin:10,
                });
                editType = outWidget.getProperty(hmUI.prop.CURRENT_TYPE);  
                this.drawWidget(WIDGET_OUT,editType);
     // -----------------------------------------------------------------s
                let right_WidgetOptionalArray = [
                    { type: hmUI.edit_type.STEP, preview: widget_Big_Preview + "step.png" }, 
                    { type: hmUI.edit_type.UVI, preview: widget_Big_Preview + "uvi.png" },
                    { type: hmUI.edit_type.WEATHER, preview: widget_Big_Preview + "weather.png" },  
                    { type: hmUI.edit_type.HUMIDITY, preview: widget_Big_Preview + "hum.png" },
                    { type: hmUI.edit_type.HEART, preview: widget_Big_Preview + "heart.png" }, 
                    // { type: hmUI.edit_type.AQI, preview: widget_Big_Preview + "aqi.png" },
                ];  

                groupX = 319;
                groupY = 87;
                rightWidget1 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: WIDGET_UP_ID,
                    x: groupX,
                    y: groupY,
                    w: 102,
                    h: 102,
                    select_image: select + "select_big.png",
                    un_select_image: select + "unselect_big.png",
                    default_type: hmUI.edit_type.WEATHER,
                    optional_types: right_WidgetOptionalArray,
                    count: right_WidgetOptionalArray.length,
                    tips_BG: WIDGET_TIPS_PATH,
                    tips_x: 0,
                    tips_y: 104,
                    tips_width: WIDGET_TIPS_WIDTH,
                    tips_margin:10,
                });
                editType = rightWidget1.getProperty(hmUI.prop.CURRENT_TYPE);
                this.drawWidget(WIDGET_RIGHT_1,editType);

                groupX = 319;
                groupY = 306;
                rightWidget2 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: WIDGET_DOWN_ID,
                    x: groupX,
                    y: groupY,
                    w: 102,
                    h: 102,
                    select_image: select + "select_big.png",
                    un_select_image: select + "unselect_big.png",
                    default_type: hmUI.edit_type.HEART,
                    optional_types: right_WidgetOptionalArray,
                    count: right_WidgetOptionalArray.length,
                    tips_BG: WIDGET_TIPS_PATH,
                    tips_x: 0,
                    tips_y: -38,
                    tips_width: WIDGET_TIPS_WIDTH,
                    tips_margin:10,
                });
                editType = rightWidget2.getProperty(hmUI.prop.CURRENT_TYPE);
                this.drawWidget(WIDGET_RIGHT_2,editType);
 //------------------------------------------------------------------------------- 
                 // 息屏状态
                var  point_prop = {
                        hour_zero:1, //是否补零
                        hour_startX: 160.46,
                        hour_startY: 198.46,
                        hour_array:timeArray,
                        hour_space:0, //每个数组间的间隔
                        //单位
                        hour_unit_sc: ROOTPATH+"fast/time/10.png", 
                        hour_unit_tc: ROOTPATH+"fast/time/10.png",
                        hour_unit_en: ROOTPATH+"fast/time/10.png",
                        hour_align:hmUI.align.LEFT, 
                        
                        minute_zero:1, //是否补零
                        minute_startX:330.31,
                        minute_startY:198.46,
                        minute_array:timeArray,
                        minute_space:0, //每个数组间的间隔
                        //单位 
                        minute_align:hmUI.align.LEFT, 

                        am_x:269.46,
                        am_y:160,
                        am_sc_path: ROOTPATH + "fast/AM/AM.png",
                        am_en_path: ROOTPATH + "fast/AM/AM.png",

                        pm_x:269.46,
                        pm_y:160,
                        pm_sc_path: ROOTPATH + "fast/AM/PM.png",
                        pm_en_path: ROOTPATH + "fast/AM/PM.png",
                        
                    //pm同上 前缀由am改为pm
                    }  
                 
                let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, point_prop);
                let mask70 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: ROOTPATH + "100.png",
                    show_level: hmUI.show_level.ONLY_EDIT,
                });  
                let mask100 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: ROOTPATH + "70.png",
                    show_level: hmUI.show_level.ONLY_EDIT,
                }); 
            },

            onInit() {
                console.log('index page.js on init invoke') 
                this.init_view();
            },

            onReady() {
                console.log('index page.js on ready invoke')
            },

            onShow() {
                console.log('index page.js on show invoke')
            },

            onHide() {
                console.log('index page.js on hide invoke')
            },

            onDestory() {
                console.log('index page.js on destory invoke')
            },
        });
        /*
        * end js
        */
    })()
} catch (e) {
    console.log(e)
}
