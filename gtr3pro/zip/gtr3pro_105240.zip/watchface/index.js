try {
    (() => {
    
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
  
    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');
  
      /*
    * huamiOS bundle tool v1.0.17
    * Copyright © Huami. All Rights Reserved
    *   1000577
    */
    'use strict';
  
    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    const rootPath = "images/";
    const DISPLAY_LEVEL = hmUI.show_level.ALL;
    const weekArray = [
        rootPath + "week/01.png",
        rootPath + "week/02.png",
        rootPath + "week/03.png",
        rootPath + "week/04.png",
        rootPath + "week/05.png",
        rootPath + "week/06.png",
        rootPath + "week/07.png",
    ];
    const monthArray = [
        rootPath + "month/01.png",
        rootPath + "month/02.png",
        rootPath + "month/03.png",
        rootPath + "month/04.png",
        rootPath + "month/05.png",
        rootPath + "month/06.png",
        rootPath + "month/07.png",
        rootPath + "month/08.png",
        rootPath + "month/09.png",
        rootPath + "month/10.png",
        rootPath + "month/11.png",
        rootPath + "month/12.png",
    ];
    const dayArray = [
        rootPath + "day/0.png",
        rootPath + "day/1.png",
        rootPath + "day/2.png",
        rootPath + "day/3.png",
        rootPath + "day/4.png",
        rootPath + "day/5.png",
        rootPath + "day/6.png",
        rootPath + "day/7.png",
        rootPath + "day/8.png",
        rootPath + "day/9.png",
    ];
    
    let timeSensor = null;
    let day1 = null;
    let day2 = null;
    let timePointer = null;
    let bg = null;

    const logger = DeviceRuntimeCore.HmLogger.getLogger("lenshuangqiuhan");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({

        init_view() {
            //bg
            bg = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
            });
          
            //week
            hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                x: 228,
                y: 66,
                week_tc: weekArray,
                week_sc: weekArray,
                week_en: weekArray,
                });
            //date
            hmUI.createWidget(hmUI.widget.IMG_DATE, {
             
                    month_startX: 228,
                    month_startY: 318,
                    month_zero: true,
                    month_en_array: monthArray,
                    month_is_character: true,
                });
            day1 = hmUI.createWidget(hmUI.widget.IMG, {
                x: 228,
                y: 399,
                w: 24,
                h: 18,
            });
            day2 = hmUI.createWidget(hmUI.widget.IMG, {
                x: 228,
                y: 420,
                w: 24,
                h: 18,
            });
            timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            if(timeSensor == null || day1 == null || day2 == null){
                console.log('refreshDay error');
                return;
            }
            const currentDay = timeSensor.day;
            day1.setProperty(hmUI.prop.SRC,dayArray[parseInt(currentDay/10)]);
            day2.setProperty(hmUI.prop.SRC,dayArray[parseInt(currentDay%10)]); 
            // console.log('++++++++++++++++++++++e'+parseInt(currentDay/10));
            // console.log('++++++++++++++++++++++e'+parseInt(currentDay%10));
            timePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER,{
            
            });
            var screenType = hmSetting.getScreenType();
            if(screenType == hmSetting.screen_type.AOD){
                bg.setProperty(hmUI.prop.MORE, {
                    src: rootPath + "img/bg_xp.png",
                });
                timePointer.setProperty(hmUI.prop.MORE, {
                    hour_centerX: 240,
                    hour_centerY: 240,
                    hour_posX: 20,
                    hour_posY: 240,//171,
                    hour_path:  rootPath + "img/hour.png",
                   minute_centerX: 240,
                   minute_centerY: 240,
                   minute_posX: 20,
                   minute_posY: 240,
                   minute_path:  rootPath + "img/min.png",
                    minute_cover_path: rootPath + "img/cover.png", //指针圆心图片
                    minute_cover_y: 229,
                    minute_cover_x: 229,
                });
            }else{
                bg.setProperty(hmUI.prop.MORE, {
                    src: rootPath + "img/bg.png",
                });
                timePointer.setProperty(hmUI.prop.MORE, {
                    hour_centerX: 240,
                    hour_centerY: 240,
                    hour_posX: 20,
                    hour_posY: 240,// 171,
                    hour_path:  rootPath + "img/hour.png",
                    minute_centerX: 240,
                    minute_centerY: 240,
                    minute_posX: 20,
                    minute_posY: 240,
                    minute_path:  rootPath + "img/min.png",
                    second_centerX: 240,
                    second_centerY: 240,
                    second_posX: 20,
                    second_posY: 240,
                    second_path:  rootPath + "img/sec.png",
                    second_cover_path: rootPath + "img/cover.png", //指针圆心图片
                    second_cover_y: 229,
                    second_cover_x: 229,
                });
            }
        },

        onInit() {
            console.log('index page.js on init invoke');

            this.init_view();
          

          
       
        },

        onReady() {
            console.log('index page.js on ready invoke')
        },

        onShow() {
            console.log('index page.js on show invoke')
        },

        onHide() {
            console.log('index page.js on hide invoke')
        },

        onDestory() {
            console.log('index page.js on destory invoke')
            timer.stopTimer(clock_timer);
        },
    });
    /*
    * end js
    */
        })()
    } catch (e) {
        console.log(e)
    }
