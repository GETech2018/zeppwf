try {
  (() => {

    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

    /*
  * huamiOS bundle tool v1.0.17
  * Copyright © Huami. All Rights Reserved
  */
    'use strict';

    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let rootPath = null
    let bgPath = null
    let bg_img = null
    let weather_img = null
    let weather_imgPath = null
    let weather_img_array = null
    let calorie_array = null
    let calorie_img = null
    let calorie_imgPath = null
    let yellowPath = null
    let yellow_num_array = null

    let greenPath = null
    let greenAqiPath = null
    let aqi_array = null
    let aqi_num_array = null
    let aqiText = null

    let bluePath = null
    let bluePaiPath = null
    let pai_array = null
    let pai_num_array = null
    let paiText = null


    let weekText = null
    let week_en_array = null
    let week_sc_array = null
    // let week_tc_array = null

    let weekText1 = null
    let week1_en_array = null
    let week1_sc_array = null

    let humidityText = null
    let numPath = null
    let num_array = null

    let timeText = null
    let timeArray = null
    let timeArray1 = null
    let timePath = null
    let timePath1 = null

    let hourPath = null
    let hour_array = null

    let widgetPreview = null

    let pinkPath = null
    let pink_array = null
    let pink_num_array = null
    let pink_numPath = null

    let mask = null
    let blue = null
    // let array = null
    let yellow = null
    let pink = null
    let green = null
    // let x = null

    let violet = null
    let uviPath = null
    let violetPath = null
    let violet_array = null
    let violet_num_array = null


    let coloriewidget = null

    let pointer = null
    let config = null

    let restPath = null
    let time_array1 = null


    const logger = DeviceRuntimeCore.HmLogger.getLogger("defult");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      drawWidget(editType, id) {




        config = {
          bgx: null,
          bgy: null,
          w: null,
          iconX: null,
          iconY: null,
          numX: null,
          numY: null,
          bgimg1: null,
          array: null,
          type: null,
          src: null,
          num_array: null,
          h: 0,
          invalid: null
          // bg_img1:blue
        }

        switch (id) {
          case 101:
            config.bgx = 154,
              config.bgy = 57,
              config.bgw = 94,
              config.numX = 163,
              config.numY = 89,
              config.iconX = 185,
              config.iconY = 119
            break;
          case 102:
            config.bgx = 54,
              config.bgy = 192,
              config.bgw = 94,
              config.numX = 62,
              config.numY = 223,
              config.iconX = 84,
              config.iconY = 253
            break;
          case 103:
            config.bgx = 150,
              config.bgy = 324,
              config.bgw = 100,
              config.numX = 162,
              config.numY = 360,
              config.iconX = 184,
              config.iconY = 395
            break;
          default:
        }

        switch (editType) {
          case hmUI.edit_type.BATTERY:
            config.bgimg1 = blue;
            config.array = pai_array;
            config.type = hmUI.data_type.BATTERY;
            config.src = bluePath + "battery.png";
            config.num_array = pai_num_array;
            config.numX = config.numX + 14
            // config.invalid = bluePath + "null.png"
            break;
          case hmUI.edit_type.CAL:
            config.bgimg1 = yellow;
            config.array = calorie_array;
            config.type = hmUI.data_type.CAL;
            config.num_array = yellow_num_array;
            config.src = yellowPath + "calorie.png"
            config.numX = config.numX + 8
            // config.invalid = yellowPath + "yellow.png"
            break;
          case hmUI.edit_type.PAI:
            config.bgimg1 = blue;
            config.array = pai_array;
            config.type = hmUI.data_type.PAI_WEEKLY;
            config.src = bluePath + "pai.png";
            config.num_array = pai_num_array;
            config.numX = config.numX + 16;
            // config.invalid = bluePath + "null.png"

            break
          case hmUI.edit_type.STEP:
            config.bgimg1 = blue;
            config.array = pai_array;
            config.type = hmUI.data_type.STEP;
            config.src = bluePath + "step.png";
            config.num_array = pai_num_array;
            // config.numX = config.numX - 5;
            config.h = -3
            // config.invalid = bluePath + "null.png"
            break
          // case hmUI.edit_type.AQI:
          //   config.bgimg1 = green;
          //   config.array = aqi_array;
          //   config.type = hmUI.data_type.AQI;
          //   config.src = greenPath + "icon.png";
          //   config.num_array = aqi_num_array;
          //   config.numX = config.numX + 16;
          //   config.invalid = greenPath + "null.png"
          //   // config.numY = config.numY + 6;
          //   break
          case hmUI.edit_type.UVI:
            config.bgimg1 = violet;
            config.array = violet_array;
            config.type = hmUI.data_type.UVI;
            config.src = violetPath + "icon.png"
            config.num_array = violet_num_array;
            config.numX = config.numX + 25
            config.invalid = violetPath + "null.png"
            console.log("5555555555" + editType)
            break
          case hmUI.edit_type.HEART:
            config.bgimg1 = pink;
            config.array = pink_array;
            config.type = hmUI.data_type.HEART;
            config.src = pinkPath + "heart.png"
            config.num_array = pink_num_array;
            config.numX = config.numX + 16
            config.invalid = pink_numPath + "10.png"
            break

          default:
            return config;

        }

        console.log(editType + "66666666")

        console.log(44444444444 + config.bgimg1)
        // 背景进度条
        item_bgimg = hmUI.createWidget(hmUI.widget.IMG, {
          x: config.bgx,
          y: config.bgy,
          w: config.bgw,
          h: config.bgw,
          src: config.bgimg1,
          show_level: hmUI.show_level.ONLY_NORMAL
        })
        // 组件进度条
        item_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: config.bgx,
          y: config.bgy,

          image_array: config.array,
          image_length: config.array.length,
          type: config.type,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        console.log('11111111111' + config.array[1])
        // 组件文本
        item_Text = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: config.numX,
          y: config.numY,
          type: config.type,
          font_array: config.num_array,
          h_space: config.h,
          show_level: hmUI.show_level.ONLY_NORMAL,
          invalid_image: config.invalid,
          // padding: true,
          align_h: hmUI.align.CENTER_H,
        });
        // 组件图标
        item_icon = hmUI.createWidget(hmUI.widget.IMG, {
          x: config.iconX,
          y: config.iconY,
          src: config.src,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
      },
      init_view() {
        rootPath = "images/";
        bgPath = rootPath + "BG/";
        weather_imgPath = rootPath + "weather/";
        calorie_imgPath = rootPath + "yellow/calorie/"
        yellowPath = rootPath + "yellow/"
        hourPath = rootPath + "time/"
        timePath = rootPath + "date/"
        timePath1 = rootPath + "date1/"
        widgetPreview = rootPath + "preview/"

        week_enPath = rootPath + "week/en/"
        week_scPath = rootPath + "week/sc/"

        week1_enPath = rootPath + "week1/en/"
        week1_scPath = rootPath + "week1/sc/"

        numPath = rootPath + "motion/"

        greenPath = rootPath + "green/"
        greenAqiPath = rootPath + "green/aqi/"

        bluePath = rootPath + "blue/"
        bluePaiPath = rootPath + "blue/pai/"

        pink_numPath = rootPath + "pink/num/"
        pinkPath = rootPath + "pink/"


        blue = bluePath + "bg.png"
        yellow = calorie_imgPath + "11.png"
        pink = pinkPath + "bg.png"
        green = greenAqiPath + "bg.png"

        violetPath = rootPath + "violet/"
        uviPath = violetPath + "uvi/"
        violet = uviPath + "6.png"

        restPath = rootPath + "time1/"

        weather_img_array = [
          weather_imgPath + "00.png",
          weather_imgPath + "01.png",
          weather_imgPath + "02.png",
          weather_imgPath + "03.png",
          weather_imgPath + "04.png",
          weather_imgPath + "05.png",
          weather_imgPath + "06.png",
          weather_imgPath + "07.png",
          weather_imgPath + "08.png",
          weather_imgPath + "09.png",
          weather_imgPath + "10.png",
          weather_imgPath + "11.png",
          weather_imgPath + "12.png",
          weather_imgPath + "13.png",
          weather_imgPath + "14.png",
          weather_imgPath + "15.png",
          weather_imgPath + "16.png",
          weather_imgPath + "17.png",
          weather_imgPath + "18.png",
          weather_imgPath + "19.png",
          weather_imgPath + "20.png",
          weather_imgPath + "21.png",
          weather_imgPath + "22.png",
          weather_imgPath + "23.png",
          weather_imgPath + "24.png",
          weather_imgPath + "25.png",
          weather_imgPath + "26.png",
          weather_imgPath + "27.png",
          weather_imgPath + "28.png",
        ]
        calorie_array = [
          calorie_imgPath + "1.png",
          calorie_imgPath + "2.png",
          calorie_imgPath + "3.png",
          calorie_imgPath + "4.png",
          calorie_imgPath + "5.png",
          calorie_imgPath + "6.png",
          calorie_imgPath + "7.png",
          calorie_imgPath + "8.png",
          calorie_imgPath + "9.png",
          calorie_imgPath + "10.png",
        ]

        yellow_num_array = [
          yellowPath + "0.png",
          yellowPath + "1.png",
          yellowPath + "2.png",
          yellowPath + "3.png",
          yellowPath + "4.png",
          yellowPath + "5.png",
          yellowPath + "6.png",
          yellowPath + "7.png",
          yellowPath + "8.png",
          yellowPath + "9.png",
        ]

        hour_array = [
          hourPath + "h0.png",
          hourPath + "h1.png",
          hourPath + "h2.png",
          hourPath + "h3.png",
          hourPath + "h4.png",
          hourPath + "h5.png",
          hourPath + "h6.png",
          hourPath + "h7.png",
          hourPath + "h8.png",
          hourPath + "h9.png",
        ]
        timeArray = [
          timePath + "0.png",
          timePath + "1.png",
          timePath + "2.png",
          timePath + "3.png",
          timePath + "4.png",
          timePath + "5.png",
          timePath + "6.png",
          timePath + "7.png",
          timePath + "8.png",
          timePath + "9.png",
        ]
        timeArray1 = [
          timePath1 + "0.png",
          timePath1 + "1.png",
          timePath1 + "2.png",
          timePath1 + "3.png",
          timePath1 + "4.png",
          timePath1 + "5.png",
          timePath1 + "6.png",
          timePath1 + "7.png",
          timePath1 + "8.png",
          timePath1 + "9.png",
        ]

        week_en_array = [
          week_enPath + "1.png",
          week_enPath + "2.png",
          week_enPath + "3.png",
          week_enPath + "4.png",
          week_enPath + "5.png",
          week_enPath + "6.png",
          week_enPath + "7.png",
        ]
        week_sc_array = [
          week_scPath + "1.png",
          week_scPath + "2.png",
          week_scPath + "3.png",
          week_scPath + "4.png",
          week_scPath + "5.png",
          week_scPath + "6.png",
          week_scPath + "7.png",
        ]

        num_array = [
          numPath + "0.png",
          numPath + "1.png",
          numPath + "2.png",
          numPath + "3.png",
          numPath + "4.png",
          numPath + "5.png",
          numPath + "6.png",
          numPath + "7.png",
          numPath + "8.png",
          numPath + "9.png",
        ]

        aqi_array = [
          greenAqiPath + "1.png",
          greenAqiPath + "2.png",
          greenAqiPath + "3.png",
          greenAqiPath + "4.png",
          greenAqiPath + "5.png",
          greenAqiPath + "6.png",
        ]

        aqi_num_array = [
          greenPath + "0.png",
          greenPath + "1.png",
          greenPath + "2.png",
          greenPath + "3.png",
          greenPath + "4.png",
          greenPath + "5.png",
          greenPath + "6.png",
          greenPath + "7.png",
          greenPath + "8.png",
          greenPath + "9.png",
        ]

        pai_array = [
          bluePaiPath + "1.png",
          bluePaiPath + "2.png",
          bluePaiPath + "3.png",
          bluePaiPath + "4.png",
          bluePaiPath + "5.png",
          bluePaiPath + "6.png",
          bluePaiPath + "7.png",
          bluePaiPath + "8.png",
          bluePaiPath + "9.png",
          bluePaiPath + "10.png",
        ]

        pai_num_array = [
          bluePath + "0.png",
          bluePath + "1.png",
          bluePath + "2.png",
          bluePath + "3.png",
          bluePath + "4.png",
          bluePath + "5.png",
          bluePath + "6.png",
          bluePath + "7.png",
          bluePath + "8.png",
          bluePath + "9.png",
        ]

        pink_num_array = [
          pink_numPath + "0.png",
          pink_numPath + "1.png",
          pink_numPath + "2.png",
          pink_numPath + "3.png",
          pink_numPath + "4.png",
          pink_numPath + "5.png",
          pink_numPath + "6.png",
          pink_numPath + "7.png",
          pink_numPath + "8.png",
          pink_numPath + "9.png",
        ]
        pink_array = [
          pinkPath + "1.png",
          pinkPath + "2.png",
          pinkPath + "3.png",
          pinkPath + "4.png",
          pinkPath + "5.png",
          pinkPath + "6.png",
        ]

        violet_array = [
          uviPath + "1.png",
          uviPath + "2.png",
          uviPath + "3.png",
          uviPath + "4.png",
          uviPath + "5.png",
        ]

        violet_num_array = [
          violetPath + "0.png",
          violetPath + "1.png",
          violetPath + "2.png",
          violetPath + "3.png",
          violetPath + "4.png",
          violetPath + "5.png",
          violetPath + "6.png",
          violetPath + "7.png",
          violetPath + "8.png",
          violetPath + "9.png",
        ]

        time_array1 = [
          restPath + "h0.png",
          restPath + "h1.png",
          restPath + "h2.png",
          restPath + "h3.png",
          restPath + "h4.png",
          restPath + "h5.png",
          restPath + "h6.png",
          restPath + "h7.png",
          restPath + "h8.png",
          restPath + "h9.png",
        ]

        week1_en_array = [
          week1_enPath + "1.png",
          week1_enPath + "2.png",
          week1_enPath + "3.png",
          week1_enPath + "4.png",
          week1_enPath + "5.png",
          week1_enPath + "6.png",
          week1_enPath + "7.png",
        ]
        week1_sc_array = [
          week1_scPath + "1.png",
          week1_scPath + "2.png",
          week1_scPath + "3.png",
          week1_scPath + "4.png",
          week1_scPath + "5.png",
          week1_scPath + "6.png",
          week1_scPath + "7.png",
        ]
        // 背景
        bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 480,
          h: 480,
          src: bgPath + "bg.png",
          show_level: hmUI.show_level.ONLY_NORMAL
        })
        // 时间文本
        timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          hour_zero: 1, //是否补零
          hour_startX: 237,
          hour_startY: 200,
          hour_array: hour_array,
          hour_space: 8, //每个数组间的间隔
          minute_zero: 1, //是否补零
          minute_startX: 359,
          minute_startY: 200,
          minute_array: hour_array,
          minute_space: 8, //每个数组间的间隔
          second_zero: 1, //是否补零
          second_startX: 305,
          second_startY: 284,
          second_array: timeArray,
          second_space: 0, //每个数组间的间隔
          //单位
          hour_align: hmUI.align.LEFT,


          am_x: 303,
          am_y: 103,
          am_sc_path: rootPath + "am_pm/am.png",
          am_en_path: rootPath + "am_pm/am.png",
          pm_x: 303,
          pm_y: 103,
          pm_sc_path: rootPath + "am_pm/pm.png",
          pm_en_path: rootPath + "am_pm/pm.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        //
        let clockStatus = hmUI.createWidget(hmUI.widget.IMG_STATUS,{
          x: 329,
          y: 50,
          type:hmUI.system_status.CLOCK,
          //参考上方表格
          src:  bgPath + "clock.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
          });
        // 日期
        let status = hmUI.createWidget(hmUI.widget.IMG_DATE, {
          day_startX: 305,
          day_startY: 165,
          day_align: hmUI.align.LEFT,
          day_space: 1,//文字间隔
          day_zero: 1,//是否补零 
          day_en_array: timeArray,
          day_sc_array: timeArray,
          day_tc_array: timeArray,
        });
        // 星期
        weekText = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
          x: 351,
          y: 165,
          week_en: week_en_array,
          week_tc: week_sc_array,
          week_sc: week_sc_array,
        });
        // 空气质量图标
        // const aqiwidget = hmUI.createWidget(hmUI.widget.IMG, {
        //   x: 304,
        //   y: 52,
        //   src: greenPath + "icon.png",
        //   show_level: hmUI.show_level.ONLY_NORMAL,
        // });
        // // 空气质量文本
        // aqiText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
        //   x: 340,
        //   y: 55,
        //   type: hmUI.data_type.AQI,
        //   font_array: num_array,
        //   h_space: 0,
        //   align_h: hmUI.align.LEFT,
        //   invalid_image: numPath + "null.png",
        //   // h_space: -2,
        //   padding: true,
        //   show_level: hmUI.show_level.ONLY_NORMAL,
        // });

        // 步数图标
        const stepwidget = hmUI.createWidget(hmUI.widget.IMG, {
          x: 304,
          y: 338,
          src: bluePath + "step.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        // 步数文本
        stepText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 345,
          y: 341,
          type: hmUI.data_type.STEP,
          font_array: num_array,
          h_space: -1,
          align_h: hmUI.align.LEFT,
          show_level: hmUI.show_level.ONLY_NORMAL,
          // invalid_image: numPath + "null.png",
          // padding: true
        });
        // 湿度图标
        const humidityidget = hmUI.createWidget(hmUI.widget.IMG, {
          x: 304,
          y: 395,
          src: bluePath + "humidity.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        // 湿度文本
        humidityText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 345,
          y: 398,
          type: hmUI.data_type.HUMIDITY,
          font_array: num_array,
          h_space: 0,
          // unit_sc:,
          align_h: hmUI.align.LEFT,
          show_level: hmUI.show_level.ONLY_NORMAL,
          invalid_image: numPath + "null.png",
          // padding: true
        });
        // 息屏背景
        AOD_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 480,
          h: 480,
          src: bgPath + "bg1.png",
          show_level: hmUI.show_level.ONAL_AOD
        })

        AOD_timeText1 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          hour_zero: 1, //是否补零
          hour_startX: 237,
          hour_startY: 200,
          hour_array: time_array1,
          hour_space: 8, //每个数组间的间隔
          minute_zero: 1, //是否补零
          minute_startX: 359,
          minute_startY: 200,
          minute_array: time_array1,
          minute_space: 8, //每个数组间的间隔
          // second_zero: 1, //是否补零
          // second_startX: 305,
          // second_startY: 284,
          // second_array: timeArray1,
          // second_space: 0, //每个数组间的间隔
          //单位
          hour_align: hmUI.align.LEFT,
          show_level: hmUI.show_level.ONAL_AOD
        });

        AOD_weekText1 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
          x: 351,
          y: 165,
          week_en: week1_en_array,
          week_tc: week1_sc_array,
          week_sc: week1_sc_array,
          show_level: hmUI.show_level.ONAL_AOD
        });

        AOD_status1 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
          day_startX: 305,
          day_startY: 165,
          day_align: hmUI.align.LEFT,
          day_space: 1,//文字间隔
          day_zero: 1,//是否补零 
          day_en_array: timeArray1,
          day_sc_array: timeArray1,
          day_tc_array: timeArray1,
          show_level: hmUI.show_level.ONAL_AOD
        });

        // 天气图标
        weather_img = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 69,
          y: 105,
          image_array: weather_img_array,
          image_length: weather_img_array.length,
          type: hmUI.data_type.WEATHER,
          show_level: hmUI.show_level.ONLY_NORMAL
        });
        // 紫外线强度
        pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
          center_x: 86,
          center_y: 356,
          x: 5,
          y: 26,
          src: violetPath + "10.png",
          type: hmUI.data_type.UVI,
          start_angle: -180,
          end_angle: 180,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });


        let widgetOptionalArray = [
          { type: hmUI.edit_type.STEP, preview: widgetPreview + "steps.png" },
          { type: hmUI.edit_type.CAL, preview: widgetPreview + "cal.png" },
          { type: hmUI.edit_type.BATTERY, preview: widgetPreview + "battery.png" },
          { type: hmUI.edit_type.HEART, preview: widgetPreview + "heart.png" },
          { type: hmUI.edit_type.UVI, preview: widgetPreview + "uvi.png" },
          { type: hmUI.edit_type.PAI, preview: widgetPreview + "pai.png" },
          // { type: hmUI.edit_type.AQI, preview: widgetPreview + "aqi.png" },
        ];


        let groupX2 = 46;
        let groupY2 = 185
        let Group2 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 102,
          x: groupX2,
          y: groupY2,
          w: 113,
          h: 113,
          select_image: rootPath + "select/select.png",
          un_select_image: rootPath + "select/un_select.png",
          default_type: hmUI.edit_type.BATTERY,
          optional_types: widgetOptionalArray,
          count: widgetOptionalArray.length,
          tips_BG: rootPath + "select/tips.png",
          tips_x: 0,
          tips_y: -38,
          tips_width: 113,
        });
        var item2 = Group2.getProperty(hmUI.prop.CURRENT_TYPE);
        this.drawWidget(item2, 102);


        // let groupX = 155;
        let groupX = 147;
        // let groupY = 59
        let groupY = 50
        let Group1 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 101,
          x: groupX,
          y: groupY,
          w: 113,
          h: 113,
          select_image: rootPath + "select/select.png",
          un_select_image: rootPath + "select/un_select.png",
          default_type: hmUI.edit_type.CAL,
          optional_types: widgetOptionalArray,
          count: widgetOptionalArray.length,
          tips_BG: rootPath + "select/tips.png",
          tips_x: 0,
          tips_y: -38,
          tips_width: 113,
        });

        var item = Group1.getProperty(hmUI.prop.CURRENT_TYPE);

        console.log(Group1.getProperty(hmUI.prop.CURRENT_TYPE))

        console.log(item + "77777777")
        console.log(hmUI.edit_type.BATTERY)
        console.log(hmUI.edit_type.UVI)
        this.drawWidget(item, 101);

        let groupX3 = 145;
        let groupY3 = 318

        let Group3 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 103,
          x: groupX3,
          y: groupY3,
          w: 113,
          h: 113,
          select_image: rootPath + "select/select.png",
          un_select_image: rootPath + "select/un_select.png",
          default_type: hmUI.edit_type.HEART,
          optional_types: widgetOptionalArray,
          count: widgetOptionalArray.length,
          tips_BG: rootPath + "select/tips.png",
          tips_x: 0,
          tips_y: -38,
          tips_width: 113,
        });
        var item3 = Group3.getProperty(hmUI.prop.CURRENT_TYPE);
        this.drawWidget(item3, 103);



        maskCover = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK, {
          x: 0,
          y: 0,
          w: 480,
          h: 480,
          src: rootPath + "select/mask100.png",
          show_level: hmUI.show_level.ONLY_EDIT,
        });

        mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
          x: 0,
          y: 0,
          w: 480,
          h: 480,
          src: rootPath + "select/mask70.png",
          show_level: hmUI.show_level.ONLY_EDIT,
        });

      },

      onInit() {
        console.log('index page.js on init invoke');

        this.init_view();


      },

      onReady() {
        console.log('index page.js on ready invoke')
      },

      onShow() {
        console.log('index page.js on show invoke')
      },

      onHide() {
        console.log('index page.js on hide invoke')
      },

      onDestory() {
        console.log('index page.js on destory invoke')
      },
    });
    /*
    * end js
    */
  })()
} catch (e) {
  console.log(e)
}