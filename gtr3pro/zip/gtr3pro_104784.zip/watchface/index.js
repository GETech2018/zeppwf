try {
    (() => {
    
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
  
    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');
  
      /*
    * huamiOS bundle tool v1.0.17
    * Copyright © Huami. All Rights Reserved
    */
    'use strict';
  
    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let rootPath = null
    let timeRootPath = null
    let animType = null
    let animDuration = null
    let timeArray = null
    let timeArray_xp = null 
    let dateArray = null
    let bg = null
    let animCreate = null
    let animResident = null
    
    // let batText = null
    // let stepText = null

    let monthArr_en =null 
    let monthArr_sc =null 
   

    const logger = DeviceRuntimeCore.HmLogger.getLogger("default2");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({

     

        init_view() {
           // timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            rootPath = "images/",
           
            timeArray = [
                rootPath +  "time/0.png",
                rootPath +  "time/1.png",
                rootPath +  "time/2.png",
                rootPath +  "time/3.png",
                rootPath +  "time/4.png",
                rootPath +  "time/5.png",
                rootPath +  "time/6.png",
                rootPath +  "time/7.png",
                rootPath +  "time/8.png",
                rootPath +  "time/9.png",
            ]
            timeArray_xp = [
                rootPath +  "time_xp/0.png",
                rootPath +  "time_xp/1.png",
                rootPath +  "time_xp/2.png",
                rootPath +  "time_xp/3.png",
                rootPath +  "time_xp/4.png",
                rootPath +  "time_xp/5.png",
                rootPath +  "time_xp/6.png",
                rootPath +  "time_xp/7.png",
                rootPath +  "time_xp/8.png",
                rootPath +  "time_xp/9.png",
            ]
            dateArray = [
                rootPath + "num/0.png",
                rootPath + "num/1.png",
                rootPath + "num/2.png",
                rootPath + "num/3.png",
                rootPath + "num/4.png",
                rootPath + "num/5.png",
                rootPath + "num/6.png",
                rootPath + "num/7.png",
                rootPath + "num/8.png",
                rootPath + "num/9.png",
            ]
            monthArr_en = [
                rootPath + "month_en/1.png",
                rootPath + "month_en/2.png",
                rootPath + "month_en/3.png",
                rootPath + "month_en/4.png",
                rootPath + "month_en/5.png",
                rootPath + "month_en/6.png",
                rootPath + "month_en/7.png",
                rootPath + "month_en/8.png",
                rootPath + "month_en/9.png",
                rootPath + "month_en/10.png",
                rootPath + "month_en/11.png",
                rootPath + "month_en/12.png",
            ]
            monthArr_sc = [
                rootPath + "month_sc/1.png",
                rootPath + "month_sc/2.png",
                rootPath + "month_sc/3.png",
                rootPath + "month_sc/4.png",
                rootPath + "month_sc/5.png",
                rootPath + "month_sc/6.png",
                rootPath + "month_sc/7.png",
                rootPath + "month_sc/8.png",
                rootPath + "month_sc/9.png",
                rootPath + "month_sc/10.png",
                rootPath + "month_sc/11.png",
                rootPath + "month_sc/12.png",
            ]
           

            var screenType = hmSetting.getScreenType();
                if(screenType == hmSetting.screen_type.AOD){
          
                    bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
                        x: 0,
                        y: 0,
                        w: 480,
                        h: 480,
                        color: 0x000000,
                    });
                    
                    let timeText_xp = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                        hour_zero: 1,
                        hour_startX: 66,
                        hour_startY: 190,
                        hour_array: timeArray_xp,
                        hour_space: 8,
                        hour_unit_sc: rootPath+"img/colon_xp.png", //单位
                        hour_unit_tc: rootPath+"img/colon_xp.png",
                        hour_unit_en: rootPath+"img/colon_xp.png",
                        hour_align: hmUI.align.LEFT,

                        minute_zero: 1, //是否补零 1为补零
                        minute_startX: 274,
                        minute_startY: 190,
                        minute_array: timeArray_xp,
                        minute_space: 8, //两个图片间隔 对应GT2的interval
                        minute_follow: 1, //是否跟随
                        minute_align: hmUI.align.LEFT,
                        
                        show_level: hmUI.show_level.ONAL_AOD,
                    });

                }else{
                    bg = hmUI.createWidget(hmUI.widget.IMG,{
                        x: 0,
                        y: 0,
                        w: 480,
                        h: 480,
                        src:  rootPath + "img/bg.png",
                    });
                    animCreate = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                        x: 0,
                        y: 0,
                        anim_path: rootPath + "bg_animte",
                        anim_prefix: "bgAnimate",
                        anim_ext: "png",
                        anim_fps: 25,
                        anim_size: 85,
                        anim_repeat: false,
                        repeat_count: 0,
                        anim_status: 1,
                        anim_complete_call:this._animNext,
                    });
                }

                let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 66,
                    hour_startY: 190,
                    hour_array: timeArray,
                    hour_space: 8,
                    hour_unit_sc: rootPath+"img/colon.png", //单位
                    hour_unit_tc: rootPath+"img/colon.png",
                    hour_unit_en: rootPath+"img/colon.png",
                    hour_align: hmUI.align.LEFT,

                    minute_zero: 1, //是否补零 1为补零
                    minute_startX: 274,
                    minute_startY: 190,
                    minute_array: timeArray,
                    minute_space: 8, //两个图片间隔 对应GT2的interval
                    minute_follow: 1, //是否跟随
                    minute_align: hmUI.align.LEFT,
                    
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    

                    let month = hmUI.createWidget(hmUI.widget.IMG_DATE,{
                        month_startX: 186,
                        month_startY: 121,
   
                        month_align: hmUI.align.LEFT,
                        month_space: 0,
                        month_zero: 0,
                        month_follow: 0,
                        month_en_array: monthArr_en,
                        month_sc_array: monthArr_sc,
                        month_tc_array: monthArr_sc,
                        month_is_character: true, //年份此字段无效   为true时 传入的图片为月份12张 日31张
                        show_level: hmUI.show_level.ONLY_NORMAL,

                    });
                    let dayImg = hmUI.createWidget(hmUI.widget.IMG_DATE,{
                        day_startX: 260,
                        day_startY: 126,
                        day_align: hmUI.align.LEFT,
                        day_space: 0,
                        day_zero: 1,
                        day_follow: 0,
                        day_en_array: dateArray,
                        day_sc_array: dateArray,
                        day_tc_array: dateArray,
                        ///day_is_character: true, 
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                    let stepTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 182,
                        y: 314,
                        type: hmUI.data_type.STEP,
                        font_array:  dateArray ,
                        h_space: -1, //图片间隔
                        align_h: hmUI.align.LEFT,
                        invalid_image: rootPath+"img/invalid.png",
                        padding:false, //是否补零 true为补零
                        show_level: hmUI.show_level.ONLY_NORMAL,
                         
                        });
            
                        let batTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                            x: 280,
                            y: 314,
                            type: hmUI.data_type.BATTERY,
                            font_array:  dateArray ,
                            h_space: -1, //图片间隔
                            align_h: hmUI.align.LEFT,
                            unit_sc: rootPath+"img/per.png",
                            unit_tc: rootPath+"img/per.png",
                            unit_en: rootPath+"img/per.png",
                            invalid_image: rootPath+"img/invalid.png",
                            padding:false, //是否补零 true为补零
                            show_level: hmUI.show_level.ONLY_NORMAL,
                             
                            });
           
           
           

        },

        onInit() {
            console.log('index page.js on init invoke');

            this.init_view();
       
            


        },

        onReady() {
            console.log('index page.js on ready invoke')
        },

        onShow() {
            console.log('index page.js on show invoke')
        },

        onHide() {
            console.log('index page.js on hide invoke')
        },

        onDestory() {
            console.log('index page.js on destory invoke')
            timer.stopTimer(clock_timer);
        },
    });
    /*
    * end js
    */
        })()
    } catch (e) {
        console.log(e)
    }
