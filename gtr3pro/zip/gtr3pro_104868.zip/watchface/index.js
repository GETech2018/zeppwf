try {
    (() => {
    
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
  
    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');
  
      /*
    * hugray_small_numiOS bundle tool v1.0.17
    * Copyright © Hugray_small_numi. All Rights Reserved
    */
    'use strict';
  
    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let rootPath = null
 
    let animType = null
    let animDuration = null
    let timeArray = null
    let timeArray_xp =null 
    let dateArray = null
    let bg = null
    let animCreate = null
    let animResident = null

    

    let clock_timer = null
    
    let weekArr_en =null 
   
    let weekArr_tc =null 
    let monthImg = null
    let dayImg = null
    let  dice_1 = null
    let  dice_2 = null
    let  dice_3 = null
    const logger = DeviceRuntimeCore.HmLogger.getLogger("default2");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({

     

        init_view() {
           
            rootPath = "images/",
            animType = "easein";
            animDuration = 1200;
            timeArray = [
                rootPath +  "time/0.png",
                rootPath +  "time/1.png",
                rootPath +  "time/2.png",
                rootPath +  "time/3.png",
                rootPath +  "time/4.png",
                rootPath +  "time/5.png",
                rootPath +  "time/6.png",
                rootPath +  "time/7.png",
                rootPath +  "time/8.png",
                rootPath +  "time/9.png",
            ]
            timeArray_xp = [
                rootPath +  "time_xp/0.png",
                rootPath +  "time_xp/1.png",
                rootPath +  "time_xp/2.png",
                rootPath +  "time_xp/3.png",
                rootPath +  "time_xp/4.png",
                rootPath +  "time_xp/5.png",
                rootPath +  "time_xp/6.png",
                rootPath +  "time_xp/7.png",
                rootPath +  "time_xp/8.png",
                rootPath +  "time_xp/9.png",
            ]
            dateArray = [
                rootPath + "date/0.png",
                rootPath + "date/1.png",
                rootPath + "date/2.png",
                rootPath + "date/3.png",
                rootPath + "date/4.png",
                rootPath + "date/5.png",
                rootPath + "date/6.png",
                rootPath + "date/7.png",
                rootPath + "date/8.png",
                rootPath + "date/9.png",
            ]
            weekArr = [
                rootPath + "week/1.png",
                rootPath + "week/2.png",
                rootPath + "week/3.png",
                rootPath + "week/4.png",
                rootPath + "week/5.png",
                rootPath + "week/6.png",
                rootPath + "week/7.png",
            ]
           

            var screenType = hmSetting.getScreenType();
                if(screenType == hmSetting.screen_type.AOD){
        
                    bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
                        x: 0,
                        y: 0,
                        w: 480,
                        h: 480,
                        color: 0x000000,
                    });
                    let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                        hour_zero: 1,
                        hour_startX: 120,
                        hour_startY: 75,
                        hour_array: timeArray_xp,
                        hour_space: 0,
                        hour_unit_sc: rootPath+"img/colon_xp.png", //单位
                        hour_unit_tc: rootPath+"img/colon_xp.png",
                        hour_unit_en: rootPath+"img/colon_xp.png",
                        hour_align: hmUI.align.LEFT,
    
                        minute_zero: 1, //是否补零 1为补零
                        minute_startX: 277,
                        minute_startY: 75,
                        minute_array: timeArray_xp,
                        minute_space: 0, //两个图片间隔 对应GT2的interval
                        minute_follow: 1, //是否跟随
                        minute_align: hmUI.align.LEFT,
                        am_x: 216,
                        am_y: 208,
                        am_sc_path: rootPath + "img/am_xp.png",
                        am_en_path: rootPath + "img/am_xp.png",//pm同上 前缀由am改为pm
                        pm_x: 216,
                        pm_y: 208,
                        pm_sc_path: rootPath + "img/pm_xp.png",
                        pm_en_path: rootPath + "img/pm_xp.png",//p
                        show_level: hmUI.show_level.AOD,
                        });
                
                }else{
                    bg = hmUI.createWidget(hmUI.widget.IMG,{
                        x: 0,
                        y: 0,
                        w: 480,
                        h: 480,
                        src:  rootPath + "img/bg.png",
                    });
                    
                
                function animateShow()
                {
                    var m1 = parseInt(Math.random()*6)+1;
                    var m2 = parseInt(Math.random()*6)+1;
                    var m3 = parseInt(Math.random()*6)+1;
                    dice_1.setProperty(hmUI.prop.MORE,{
                        x: 25,
                        y: 198,
                        w: 120,
                        h: 120,
                        src:  rootPath + "dice/a/"+m1+".png",
                    });
                    dice_2.setProperty(hmUI.prop.MORE,{
                        x: 111,
                        y: 319,
                        w: 120,
                        h: 120,
                        src:  rootPath + "dice/b/"+m2+".png",
                    });
                    dice_3.setProperty(hmUI.prop.MORE,{
                        x: 266,
                        y: 329,
                        w: 131,
                        h: 131,
                        src:  rootPath + "dice/c/"+m3+".png",
                    });
                    dice_3.setProperty(hmUI.prop.VISIBLE,true);
                    dice_2.setProperty(hmUI.prop.VISIBLE,true);
                    dice_1.setProperty(hmUI.prop.VISIBLE,true);
                }
                let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 120,
                    hour_startY: 75,
                    hour_array: timeArray,
                    hour_space: 0,
                    hour_unit_sc: rootPath+"img/colon.png", //单位
                    hour_unit_tc: rootPath+"img/colon.png",
                    hour_unit_en: rootPath+"img/colon.png",
                    hour_align: hmUI.align.LEFT,

                    minute_zero: 1, //是否补零 1为补零
                    minute_startX: 277,
                    minute_startY: 75,
                    minute_array: timeArray,
                    minute_space: 0, //两个图片间隔 对应GT2的interval
                    minute_follow: 1, //是否跟随
                    minute_align: hmUI.align.LEFT,

                    am_x: 216,
                    am_y: 208,
                    am_sc_path: rootPath + "img/am.png",
                    am_en_path: rootPath + "img/am.png",//pm同上 前缀由am改为pm
                    pm_x: 216,
                    pm_y: 208,
                    pm_sc_path: rootPath + "img/pm.png",
                    pm_en_path: rootPath + "img/pm.png",//p
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    let week = hmUI.createWidget(hmUI.widget.IMG_WEEK,{
                        x: 253,
                        y: 180,
                        week_en: weekArr,
                        week_tc: weekArr,
                        week_sc: weekArr,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    monthImg = hmUI.createWidget(hmUI.widget.IMG_DATE,{
                        month_startX: 228,
                        month_startY: 257 ,
                        month_unit_sc: rootPath + "img/dot.png",
                        month_unit_tc: rootPath + "img/dot.png",
                        month_unit_en: rootPath + "img/dot.png",
                        month_align: hmUI.align.LEFT,
                        month_space: 0,
                        month_zero: 1,
                        month_follow: 0,
                        month_en_array: dateArray,
                        month_sc_array: dateArray,
                        month_tc_array: dateArray,

                        day_align: hmUI.align.LEFT,
                        day_space: 0,
                        day_zero: 1,
                        day_follow: 1,
                        day_en_array: dateArray,
                        day_sc_array: dateArray,
                        day_tc_array: dateArray,
                       // day_is_charact er: true , 
                       show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                animCreate = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                    x: 0,
                    y: 0,
                    anim_path: rootPath + "game_animte",
                    anim_prefix: "game",
                    anim_ext: "png",
                    anim_fps: 25,
                    anim_size: 11,
                    anim_repeat: false,
                    repeat_count: 1,
                    anim_status: 1,
                    anim_complete_call:animateShow,
                });
                dice_1  = hmUI.createWidget(hmUI.widget.IMG,{
                    enable:false,
                });
                dice_2  = hmUI.createWidget(hmUI.widget.IMG,{
                    enable:false,
                });
                dice_3  = hmUI.createWidget(hmUI.widget.IMG,{
                    enable:false,
                });
                animCreate.addEventListener(hmUI.event.CLICK_UP, (function (info) {   
                    console.log('click up'); 
                    dice_3.setProperty(hmUI.prop.VISIBLE,false);
                    dice_2.setProperty(hmUI.prop.VISIBLE,false);
                    dice_1.setProperty(hmUI.prop.VISIBLE,false);
                    animCreate.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                }));      
            }

        },

        onInit() {
            console.log('index page.js on init invoke');

            this.init_view();
        },

        onReady() {
            console.log('index page.js on ready invoke')
        },

        onShow() {
            console.log('index page.js on show invoke')
        },

        onHide() {
            console.log('index page.js on hide invoke')
        },

        onDestory() {
            console.log('index page.js on destory invoke')
            timer.stopTimer(clock_timer);
        },
    });
    /*
    * end js
    */
        })()
    } catch (e) {
        console.log(e)
    }
