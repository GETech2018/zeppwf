try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_a44478fe7e484bd48e42bb06164500f8 = '';
        let normal$_$text_094dac8691c147baa774b8d5888d6316 = '';
        let normal$_$text_cb079201272d4967ba2ede3e8790b0af = '';
        let dateFormat = '';
        let dateFormatMap = '';
        let batterySensor = '';
        let timeSensor = '';
        const logger = Logger.getLogger('watchface6');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 240,
                    center_y: 240,
                    radius: 167,
                    start_angle: 255,
                    end_angle: 290,
                    color: 4281545523,
                    line_width: 10,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_a44478fe7e484bd48e42bb06164500f8 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 0,
                    y: 279,
                    w: 68,
                    h: 32,
                    text: '[BATT_PER]%',
                    color: '0xFF333333',
                    text_size: 18,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.RIGHT,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_094dac8691c147baa774b8d5888d6316 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 356,
                    y: 231,
                    w: 100,
                    h: 40,
                    text: '[WEEK_EN_S]',
                    color: '0xFFffffff',
                    text_size: 18,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_cb079201272d4967ba2ede3e8790b0af = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 399,
                    y: 231,
                    w: 100,
                    h: 40,
                    text: '[DAY]',
                    color: '0xFFff6000',
                    text_size: 18,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 240,
                    hour_centerY: 240,
                    hour_posX: 240,
                    hour_posY: 240,
                    hour_path: '3.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 240,
                    minute_centerY: 240,
                    minute_posX: 240,
                    minute_posY: 240,
                    minute_path: '4.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    second_centerX: 240,
                    second_centerY: 240,
                    second_posX: 240,
                    second_posY: 240,
                    second_path: '5.png',
                    second_cover_x: 0,
                    second_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '6.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 240,
                    hour_centerY: 240,
                    hour_posX: 240,
                    hour_posY: 240,
                    hour_path: '3.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 240,
                    minute_centerY: 240,
                    minute_posX: 240,
                    minute_posY: 240,
                    minute_path: '4.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                if (!batterySensor) {
                    batterySensor = hmSensor.createSensor(hmSensor.id.BATTERY);
                }
                if (!timeSensor) {
                    timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                }
                batterySensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_a44478fe7e484bd48e42bb06164500f8.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }%` });
                }), timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
                    const WEEK_EN_S = function (val) {
                        const valueMap = {
                            '1': 'Mon',
                            '2': 'Tue',
                            '3': 'Wed',
                            '4': 'Thu',
                            '5': 'Fri',
                            '6': 'Sat',
                            '7': 'Sun'
                        };
                        return valueMap[val];
                    };
                    normal$_$text_094dac8691c147baa774b8d5888d6316.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_S(timeSensor.week) }` });
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_cb079201272d4967ba2ede3e8790b0af.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                        },
                        () => {
                            normal$_$text_cb079201272d4967ba2ede3e8790b0af.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                        },
                        () => {
                            normal$_$text_cb079201272d4967ba2ede3e8790b0af.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                });
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        normal$_$text_a44478fe7e484bd48e42bb06164500f8.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }%` });
                        const WEEK_EN_S = function (val) {
                            const valueMap = {
                                '1': 'Mon',
                                '2': 'Tue',
                                '3': 'Wed',
                                '4': 'Thu',
                                '5': 'Fri',
                                '6': 'Sat',
                                '7': 'Sun'
                            };
                            return valueMap[val];
                        };
                        normal$_$text_094dac8691c147baa774b8d5888d6316.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_S(timeSensor.week) }` });
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                normal$_$text_cb079201272d4967ba2ede3e8790b0af.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                            },
                            () => {
                                normal$_$text_cb079201272d4967ba2ede3e8790b0af.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                            },
                            () => {
                                normal$_$text_cb079201272d4967ba2ede3e8790b0af.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}