try {
  (() => {
    var e = __$$hmAppManager$$__.currentApp;
    const n = e.current,
      { px: _ } =
        (new DeviceRuntimeCore.WidgetFactory(
          new DeviceRuntimeCore.HmDomApi(e, n)
        ),
        e.app.__globals__),
      o = Logger.getLogger("watchface6");
    n.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
          edit_id: 1,
          x: 0,
          y: 0,
          bg_config: [
            { id: 1, path: "4.png", preview: "4.png" },
            { id: 2, path: "5.png", preview: "5.png" },
            { id: 3, path: "6.png", preview: "6.png" },
          ],
          count: 3,
          default_id: 1,
          fg: "3.png",
          tips_x: 155,
          tips_y: 21,
          tips_bg: "2.png",
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
        }),
          hmUI.createWidget(hmUI.widget.TIME_POINTER, {
            hour_centerX: 240,
            hour_centerY: 240,
            hour_posX: 240,
            hour_posY: 240,
            hour_path: "7.png",
            hour_cover_x: 240,
            hour_cover_y: 240,
            enable: !1,
            show_level: hmUI.show_level.ONLY_NORMAL,
          }),
          hmUI.createWidget(hmUI.widget.TIME_POINTER, {
            second_centerX: 240,
            second_centerY: 240,
            second_posX: 240,
            second_posY: 240,
            second_path: "9.png",
            second_cover_x: 240,
            second_cover_y: 240,
            enable: !1,
            show_level: hmUI.show_level.ONLY_NORMAL,
          }),
          hmUI.createWidget(hmUI.widget.TIME_POINTER, {
            minute_centerX: 240,
            minute_centerY: 240,
            minute_posX: 8,
            minute_posY: 240,
            minute_path: "8.png",
            minute_cover_x: 0,
            minute_cover_y: 0,
            enable: !1,
            show_level: hmUI.show_level.ONLY_NORMAL,
          }),
          hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
            center_x: 240,
            center_y: 240,
            radius: 239,
            start_angle: 180,
            end_angle: -180,
            color: 4286348412,
            line_width: 3,
            type: hmUI.data_type.STEP,
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
      },
      onInit() {
        o.log("index page.js on init invoke");
      },
      build() {
        this.init_view(), o.log("index page.js on ready invoke");
      },
      onDestory() {
        o.log("index page.js on destory invoke");
      },
    });
  })();
} catch (e) {
  console.log(e);
}
