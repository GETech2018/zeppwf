try {
  (() => {

    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

    /*
  * huamiOS bundle tool v1.0.17
  * Copyright © Huami. All Rights Reserved
  */
    'use strict';

    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let rootPath = null
    let bgPath = null
    let dayPath = null
    let distancePath = null
    let heartPath = null
    let hourPath = null
    let humidityPath = null
    let powerPath = null
    let power_disPath = null
    let stepPath = null
    let sunrisePath = null
    let sunsetPath = null
    let temperaturePath = null
    let walkPath = null
    let weatherPath = null
    let weekPath = null


    let day_array = null
    let distance_array = null
    let heart_array = null
    let hour_array = null
    let humidity_array = null
    let power_array = null
    let power_dis_array = null
    let step_array = null
    let sunrise_array = null
    let sunset_array = null
    let temperature_array = null
    let walk_array = null
    let weather_array = null
    let week_array = null
  
    const logger = DeviceRuntimeCore.HmLogger.getLogger("defult");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({


      init_view() {
        rootPath = "images/";
        bgPath = rootPath + "bg/"
        dayPath = rootPath + "day/"
        distancePath = rootPath + "distance/"
        heartPath = rootPath + "heart/"
        hourPath = rootPath + "hour/"
        humidityPath = rootPath + "humidity/"
        powerPath = rootPath + "power/"
        power_disPath = powerPath + "distance/"
        stepPath = rootPath + "step/"
        sunrisePath = rootPath + "sunrise/"
        sunsetPath = rootPath + "sunset/"
        temperaturePath = rootPath + "temperature/"
        walkPath = rootPath + "walk/"
        weatherPath = rootPath + "weather/"
        weekPath = rootPath + "week/"

        day_array = [
          dayPath + "0.png",
          dayPath + "1.png",
          dayPath + "2.png",
          dayPath + "3.png",
          dayPath + "4.png",
          dayPath + "5.png",
          dayPath + "6.png",
          dayPath + "7.png",
          dayPath + "8.png",
          dayPath + "9.png"
        ]

        distance_array = [
          distancePath + "0.png",
          distancePath + "1.png",
          distancePath + "2.png",
          distancePath + "3.png",
          distancePath + "4.png",
          distancePath + "5.png",
          distancePath + "6.png",
          distancePath + "7.png",
          distancePath + "8.png",
          distancePath + "9.png"
        ]

        heart_array = [
          heartPath + "0.png",
          heartPath + "1.png",
          heartPath + "2.png",
          heartPath + "3.png",
          heartPath + "4.png",
          heartPath + "5.png",
          heartPath + "6.png",
          heartPath + "7.png",
          heartPath + "8.png",
          heartPath + "9.png"
        ]

        hour_array = [
          hourPath + "0.png",
          hourPath + "1.png",
          hourPath + "2.png",
          hourPath + "3.png",
          hourPath + "4.png",
          hourPath + "5.png",
          hourPath + "6.png",
          hourPath + "7.png",
          hourPath + "8.png",
          hourPath + "9.png"
        ]

        humidity_array = [
          humidityPath + "0.png",
          humidityPath + "1.png",
          humidityPath + "2.png",
          humidityPath + "3.png",
          humidityPath + "4.png",
          humidityPath + "5.png",
          humidityPath + "6.png",
          humidityPath + "7.png",
          humidityPath + "8.png",
          humidityPath + "9.png"
        ]

        power_array = [
          powerPath + "1.png",
          powerPath + "2.png",
          powerPath + "3.png",
          powerPath + "4.png",
          powerPath + "5.png",
          powerPath + "6.png",
          powerPath + "7.png",
          powerPath + "8.png",
          powerPath + "9.png",
          powerPath + "10.png",
        ]

        power_dis_array = [
          power_disPath + "0.png",
          power_disPath + "1.png",
          power_disPath + "2.png",
          power_disPath + "3.png",
          power_disPath + "4.png",
          power_disPath + "5.png",
          power_disPath + "6.png",
          power_disPath + "7.png",
          power_disPath + "8.png",
          power_disPath + "9.png"
        ]

        step_array = [
          stepPath + "0.png",
          stepPath + "1.png",
          stepPath + "2.png",
          stepPath + "3.png",
          stepPath + "4.png",
          stepPath + "5.png",
          stepPath + "6.png",
          stepPath + "7.png",
          stepPath + "8.png",
          stepPath + "9.png"
        ]

        sunrise_array = [
          sunrisePath + "0.png",
          sunrisePath + "1.png",
          sunrisePath + "2.png",
          sunrisePath + "3.png",
          sunrisePath + "4.png",
          sunrisePath + "5.png",
          sunrisePath + "6.png",
          sunrisePath + "7.png",
          sunrisePath + "8.png",
          sunrisePath + "9.png"
        ]

        sunset_array = [
          sunsetPath + "0.png",
          sunsetPath + "1.png",
          sunsetPath + "2.png",
          sunsetPath + "3.png",
          sunsetPath + "4.png",
          sunsetPath + "5.png",
          sunsetPath + "6.png",
          sunsetPath + "7.png",
          sunsetPath + "8.png",
          sunsetPath + "9.png"
        ]

        temperature_array = [
          temperaturePath + "0.png",
          temperaturePath + "1.png",
          temperaturePath + "2.png",
          temperaturePath + "3.png",
          temperaturePath + "4.png",
          temperaturePath + "5.png",
          temperaturePath + "6.png",
          temperaturePath + "7.png",
          temperaturePath + "8.png",
          temperaturePath + "9.png"
        ]

        walk_array = [
          walkPath + "1.png",
          walkPath + "2.png",
          walkPath + "3.png",
          walkPath + "4.png",
          walkPath + "5.png",
          walkPath + "6.png",
        ]

        weather_array = [
          weatherPath + "0.png",
          weatherPath + "1.png",
          weatherPath + "2.png",
          weatherPath + "3.png",
          weatherPath + "4.png",
          weatherPath + "5.png",
          weatherPath + "6.png",
          weatherPath + "7.png",
          weatherPath + "8.png",
          weatherPath + "9.png",
          weatherPath + "10.png",
          weatherPath + "11.png",
          weatherPath + "12.png",
          weatherPath + "13.png",
          weatherPath + "14.png",
          weatherPath + "15.png",
          weatherPath + "16.png",
          weatherPath + "17.png",
          weatherPath + "18.png",
          weatherPath + "19.png",
          weatherPath + "20.png",
          weatherPath + "21.png",
          weatherPath + "22.png",
          weatherPath + "23.png",
          weatherPath + "24.png",
          weatherPath + "25.png",
          weatherPath + "26.png",
          weatherPath + "27.png",
          weatherPath + "28.png",
        ]

        week_array = [
          weekPath + "1.png",
          weekPath + "2.png",
          weekPath + "3.png",
          weekPath + "4.png",
          weekPath + "5.png",
          weekPath + "6.png",
          weekPath + "7.png",
        ]


        let animA = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
          x: 0,
          y: 0,

          anim_path: rootPath + "bg",

          anim_prefix: "anim",

          anim_ext: "png",
          // anim_0 
          anim_fps: 25,

          anim_size: 6,

          repeat_count: 1, //0位无限重复
          display_on_restart:true,
          anim_repeat: false,//是否重复
          anim_status: hmUI.anim_status.START,

        });
      

        let batteryLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 191.77,
          y: 22.2,
          image_array: power_array,
          image_length: power_array.length,//长度
          type: hmUI.data_type.BATTERY,
          show_level: hmUI.show_level.ONLY_NORMAL
        })

        let batteryText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 237.89,
          y: 16.92,
          type: hmUI.data_type.BATTERY,
          font_array: power_dis_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NORMAL,
          unit_sc: power_disPath + "baifen.png",
          unit_tc: power_disPath + "baifen.png",
          unit_en: power_disPath + "baifen.png",
          // invalid_image: power_disPath + "null.png",
          // padding: true
        });

        let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          hour_zero: 1, //是否补零
          hour_startX: 111.01,
          hour_startY: 74.01,
          hour_array: hour_array,
          hour_space: 0, //每个数组间的间隔
          hour_unit_sc: hourPath + "maohao.png",
          hour_unit_tc: hourPath + "maohao.png",
          hour_unit_en: hourPath + "maohao.png",

          minute_zero: 1, //是否补零
          minute_startX: 203,
          minute_startY: 74.01,
          minute_array: hour_array,
          minute_space: 0, //每个数组间的间隔
          minute_unit_sc: hourPath + "maohao.png",
          minute_unit_tc: hourPath + "maohao.png",
          minute_unit_en: hourPath + "maohao.png",

          second_zero: 1, //是否补零
          second_startX: 294.98,
          second_startY: 74.01,
          second_array: hour_array,
          second_space: 0, //每个数组间的间隔
          show_level: hmUI.show_level.ONLY_NORMAL,
        })

        let dayText = hmUI.createWidget(hmUI.widget.IMG_DATE, {
          month_startX: 170.22,
          month_startY: 143.79,
          // month_align: hmUI.align.LEFT,
          month_space: 0,//文字间隔
          month_zero: 1,//是否补零
          month_unit_sc: dayPath + "hen.png", //单位
          month_unit_tc: dayPath + "hen.png",
          month_unit_en: dayPath + "hen.png",
          month_en_array: day_array,
          month_sc_array: day_array,
          month_tc_array: day_array,
          day_startX: 222.68,
          day_startY: 143.79,
          // day_align: hmUI.align.LEFT,
          day_space: 0,//文字间隔
          day_zero: 1,//是否补零 
          day_en_array: day_array,
          day_sc_array: day_array,
          day_tc_array: day_array,
          show_level: hmUI.show_level.ONLY_NORMAL,
        })

        let weekText = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
          x: 260.74,
          y: 145.79,
          week_en: week_array,
          week_tc: week_array,
          week_sc: week_array,
          show_level: hmUI.show_level.ONLY_NORMAL
        })

        let distanceText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 50,
          y: 228.37,
          w: 120,
          type: hmUI.data_type.DISTANCE,
          font_array: distance_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NOMAL,
          invalid_image: temperaturePath + "null.png",
          dot_image: distancePath + "dot.png",
        });

        let weatherLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 225.2,
          y: 187.14,
          image_array: weather_array,
          image_length: weather_array.length,//长度
          type: hmUI.data_type.WEATHER,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let weatherText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 195.28,
          y: 228.37,
          w: 100,
          type: hmUI.data_type.WEATHER_CURRENT,
          font_array: temperature_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          invalid_image: temperaturePath + "null.png",
          dot_image: temperaturePath + "dot.png",
          unit_sc: temperaturePath + "du.png",
          unit_tc: temperaturePath + "du.png",
          unit_en: temperaturePath + "du.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
          // padding: true
        });

        let humidityText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {//湿度
          x: 318.38,
          y: 228.37,
          w: 100,
          type: hmUI.data_type.HUMIDITY,
          // font_array: distance_array,
          font_array: humidity_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          unit_sc: humidityPath + "baifen.png",
          unit_tc: humidityPath + "baifen.png",
          unit_en: humidityPath + "baifen.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
          invalid_image: temperaturePath + "null.png",
          // dot_image: distancePath + "dot.png",
          // padding: true
        });

        let stepText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 203.04,
          y: 282.64,
          type: hmUI.data_type.STEP,
          font_array: step_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NORMAL,
          // invalid_image: number_sPath + "null.png",
          // padding:true
        });

        let sun_RISEText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 130.04,
          y: 362.64,
          type: hmUI.data_type.SUN_RISE,
          font_array: sunrise_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          dot_image: sunrisePath + "maohao.png",
          isCharater: true,
          padding: true,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let sun_SETText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 287.58,
          y: 362.64,
          type: hmUI.data_type.SUN_SET,
          font_array: sunset_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          dot_image: sunsetPath + "maohao.png",
          isCharater: true,
          padding: true,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let heartText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 212.51,
          y: 411.28,
          type: hmUI.data_type.HEART,
          font_array: heart_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NORMAL,
          invalid_image: heartPath + "null.png",
          // padding:true
        });

        let step_target_img = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 31.72,
          y: 324.58,
          image_array: walk_array,
          image_length: walk_array.length,
          type: hmUI.data_type.STEP_TARGET,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        let AOD_timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          hour_zero: 1, //是否补零
          hour_startX: 111.01,
          hour_startY: 74.01,
          hour_array: hour_array,
          hour_space: 0, //每个数组间的间隔
          hour_unit_sc: hourPath + "maohao.png",
          hour_unit_tc: hourPath + "maohao.png",
          hour_unit_en: hourPath + "maohao.png",

          minute_zero: 1, //是否补零
          minute_startX: 203,
          minute_startY: 74.01,
          minute_array: hour_array,
          minute_space: 0, //每个数组间的间隔
          show_level: hmUI.show_level.ONAL_AOD,
        })

       

      },

      onInit() {
        console.log('index page.js on init invoke');

        this.init_view();


      },

      onReady() {
        console.log('index page.js on ready invoke')
      },

      onShow() {
        console.log('index page.js on show invoke')
      },

      onHide() {
        console.log('index page.js on hide invoke')
      },

      onDestory() {
        console.log('index page.js on destory invoke')
      },
    });
    /*
    * end js
    */
  })()
} catch (e) {
  console.log(e)
}