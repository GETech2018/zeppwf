
try {
  (() => {
  
var __$$app$$__ = __$$hmAppManager$$__.currentApp;

function noTreeShaking() {}

function getApp() {
  return __$$app$$__.app;
}

function getCurrentPage() {
  return __$$app$$__.current && __$$app$$__.current.module;
}

var __$$module$$__ = __$$app$$__.current;
var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
var { px } = getApp().__globals__;

  /*
* ZeppOS bundle tool v2.1.49
* Copyright © Zepp. All Rights Reserved
*/
'use strict';

let min_h = null;
let min_l = null;
let t = new Date();
const logger = Logger.getLogger('watchface6');
const img = function (type) {
    return path => type + '/' + path;
}('images');
__$$module$$__.module = DeviceRuntimeCore.WatchFace({
    init_view() {
        hours = [];
        hours_dim = [];
        for (let i = 0; i < 10; i++) {
            hours.push(img(`hour/time_${ i }.png`));
            hours_dim.push(img(`hour_dim/time_${ i }.png`));
        }
        minutes = [];
        for (let i = 0; i < 10; i++) {
            minutes.push(img(`min/minute_high_${ i }.png`));
        }
        date_imgs = [];
        dates_dim = [];
        for (let i = 0; i < 10; i++) {
            date_imgs.push(img(`day/date_${ i }.png`));
            dates_dim.push(img(`date_dim/date_${ i }.png`));
        }
        hmUI.createWidget(hmUI.widget.IMG, {
            x: px(0),
            y: px(0),
            w: px(480),
            h: px(480),
            src: img('bg_dim.png'),
            show_level: hmUI.show_level.ONLY_AOD
        });
        hmUI.createWidget(hmUI.widget.IMG_ANIM, {
            x: px(0),
            y: px(0),
            anim_path: 'images/anim',
            anim_prefix: 'anim',
            anim_ext: 'png',
            anim_fps: 12,
            anim_size: 24,
            anim_repeat: true,
            repeat_count: 255,
            anim_status: hmUI.anim_status.START
        });
        hmUI.createWidget(hmUI.widget.IMG_TIME, {
            hour_zero: 1,
            hour_startX: px(316),
            hour_startY: px(125),
            hour_array: hours,
            hour_space: px(11),
            hour_align: hmUI.align.LEFT,
            minute_zero: 1,
            minute_startX: px(316),
            minute_startY: px(219),
            minute_array: [],
            minute_space: px(11),
            minute_align: hmUI.align.LEFT,
            minute_follow: 0,
            am_x: px(316),
            am_y: px(86),
            am_sc_path: img('am_cn.png'),
            am_en_path: img('am_en.png'),
            pm_x: px(316),
            pm_y: px(86),
            pm_sc_path: img('pm_cn.png'),
            pm_en_path: img('pm_en.png'),
            show_level: hmUI.show_level.ONLY_NORMAL
        });
        hmUI.createWidget(hmUI.widget.IMG_TIME, {
            hour_zero: 1,
            hour_startX: px(316),
            hour_startY: px(125),
            hour_array: hours_dim,
            hour_space: px(11),
            hour_align: hmUI.align.LEFT,
            minute_zero: 1,
            minute_startX: px(316),
            minute_startY: px(219),
            minute_array: hours_dim,
            minute_space: px(11),
            minute_align: hmUI.align.LEFT,
            minute_follow: 0,
            am_x: px(316),
            am_y: px(86),
            am_sc_path: img('am_cn_dim.png'),
            am_en_path: img('am_en_dim.png'),
            pm_x: px(316),
            pm_y: px(86),
            pm_sc_path: img('pm_cn_dim.png'),
            pm_en_path: img('pm_en_dim.png'),
            show_level: hmUI.show_level.ONLY_AOD
        });
        min_h = hmUI.createWidget(hmUI.widget.IMG, {
            x: px(316),
            y: px(219),
            w: px(47),
            h: px(73),
            src: '',
            show_level: hmUI.show_level.ONLY_NORMAL
        });
        min_l = hmUI.createWidget(hmUI.widget.IMG, {
            x: px(374),
            y: px(219),
            w: px(47),
            h: px(73),
            src: '',
            show_level: hmUI.show_level.ONLY_NORMAL
        });
        hmUI.createWidget(hmUI.widget.IMG_DATE, {
            month_startX: px(316),
            month_startY: px(313),
            month_sc_array: date_imgs,
            month_tc_array: date_imgs,
            month_en_array: date_imgs,
            month_align: hmUI.align.LEFT,
            month_zero: 1,
            month_follow: 0,
            month_space: px(2),
            month_is_character: false,
            day_startX: px(382),
            day_startY: px(313),
            day_sc_array: date_imgs,
            day_tc_array: date_imgs,
            day_en_array: date_imgs,
            day_align: hmUI.align.LEFT,
            day_zero: 1,
            day_follow: 0,
            day_space: px(2),
            day_is_character: false,
            show_level: hmUI.show_level.ONLY_NORMAL
        });
        hmUI.createWidget(hmUI.widget.IMG, {
            x: px(359),
            y: px(313),
            w: px(18),
            h: px(26),
            src: img('day/date_s.png'),
            show_level: hmUI.show_level.ONLY_NORMAL
        });
        hmUI.createWidget(hmUI.widget.IMG_DATE, {
            month_startX: px(316),
            month_startY: px(313),
            month_sc_array: dates_dim,
            month_tc_array: dates_dim,
            month_en_array: dates_dim,
            month_align: hmUI.align.LEFT,
            month_zero: 1,
            month_follow: 0,
            month_space: px(2),
            month_is_character: false,
            day_startX: px(382),
            day_startY: px(313),
            day_sc_array: dates_dim,
            day_tc_array: dates_dim,
            day_en_array: dates_dim,
            day_align: hmUI.align.LEFT,
            day_zero: 1,
            day_follow: 0,
            day_space: px(2),
            day_is_character: false,
            show_level: hmUI.show_level.ONLY_AOD
        });
        hmUI.createWidget(hmUI.widget.IMG, {
            x: px(359),
            y: px(313),
            w: px(18),
            h: px(26),
            src: img('date_dim/date_s.png'),
            show_level: hmUI.show_level.ONLY_AOD
        });
        function setMinute() {
            t.setTime(Date.now());
            min_h.setProperty(hmUI.prop.SRC, minutes[parseInt(t.getMinutes() / 10)]);
            min_l.setProperty(hmUI.prop.SRC, hours[parseInt(t.getMinutes() % 10)]);
        }
        setMinute();
        mintimer = timer.createTimer(10, 1000, setMinute, {});
    },
    onInit() {
        logger.log('index page.js on init invoke');
    },
    build() {
        logger.log('index page.js on build invoke');
        this.init_view();
    },
    onDestory() {
        logger.log('index page.js on destory invoke');
    }
});
/*
* end js
*/

  ;
  })()
} catch(e) {
  console.log(e)
  /* todo */
}