try {
    (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;

        var __$$module$$__ = __$$app$$__.current;
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        /*
      * huamiOS bundle tool v1.0.17
      * Copyright © Huami. All Rights Reserved
      */
        'use strict';

        console.log("----->>>current");
        console.log(__$$hmAppManager$$__.currentApp.pid);
        console.log(__$$hmAppManager$$__.currentApp.current);


        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

            init_view() {
                let rootPath = "images/";
                let weekArray = [
                    rootPath + "week/1.png",
                    rootPath + "week/2.png",
                    rootPath + "week/3.png",
                    rootPath + "week/4.png",
                    rootPath + "week/5.png",
                    rootPath + "week/6.png",
                    rootPath + "week/7.png",
                ]
                let dateArray = [
                    rootPath + "date/0.png",
                    rootPath + "date/1.png",
                    rootPath + "date/2.png",
                    rootPath + "date/3.png",
                    rootPath + "date/4.png",
                    rootPath + "date/5.png",
                    rootPath + "date/6.png",
                    rootPath + "date/7.png",
                    rootPath + "date/8.png",
                    rootPath + "date/9.png",
                ];
                let timeArr = [
                    rootPath + "time/0.png",
                    rootPath + "time/1.png",
                    rootPath + "time/2.png",
                    rootPath + "time/3.png",
                    rootPath + "time/4.png",
                    rootPath + "time/5.png",
                    rootPath + "time/6.png",
                    rootPath + "time/7.png",
                    rootPath + "time/8.png",
                    rootPath + "time/9.png"
                ]
                let restimeArr = [
                    rootPath + "restTime/0.png",
                    rootPath + "restTime/1.png",
                    rootPath + "restTime/2.png",
                    rootPath + "restTime/3.png",
                    rootPath + "restTime/4.png",
                    rootPath + "restTime/5.png",
                    rootPath + "restTime/6.png",
                    rootPath + "restTime/7.png",
                    rootPath + "restTime/8.png",
                    rootPath + "restTime/9.png"
                ]
                let fontArr = [
                    rootPath + "font/0.png",
                    rootPath + "font/1.png",
                    rootPath + "font/2.png",
                    rootPath + "font/3.png",
                    rootPath + "font/4.png",
                    rootPath + "font/5.png",
                    rootPath + "font/6.png",
                    rootPath + "font/7.png",
                    rootPath + "font/8.png",
                    rootPath + "font/9.png"
                ]



                let screenType = hmSetting.getScreenType()
                if (screenType == hmSetting.screen_type.AOD) {
                    let img_bg = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 0,
                        y: 0,
                        w: 480,
                        h: 480,
                        src: rootPath + "img/bg.png",
                    });

                    let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                        hour_startX: 100,
                        hour_startY: 56,
                        hour_zero: 1,
                        hour_array: restimeArr,
                        hour_space: 8,
                        hour_align: hmUI.align.LEFT,

                        minute_startX: 100,
                        minute_startY: 249,
                        minute_zero: 1,
                        minute_array: restimeArr,
                        minute_space: 8,
                        minute_align: hmUI.align.LEFT,
                    });
                } else {
                    let img_bg = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 0,
                        y: 0,
                        w: 480,
                        h: 480,
                        src: rootPath + "img/bg.png",
                    });

                    let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                        hour_startX: 100,
                        hour_startY: 56,
                        hour_zero: 1,
                        hour_array: timeArr,
                        hour_space: 8,
                        hour_align: hmUI.align.LEFT,

                        minute_startX: 100,
                        minute_startY: 249,
                        minute_zero: 1,
                        minute_array: timeArr,
                        minute_space: 8,
                        minute_align: hmUI.align.LEFT,

                        am_x: 384,
                        am_y: 180,
                        am_sc_path:rootPath + "AP/AM.png",
                        am_en_path:rootPath + "AP/AM.png",

                        pm_x: 384,
                        pm_y: 180,
                        pm_sc_path:rootPath + "AP/PM.png",
                        pm_en_path:rootPath + "AP/PM.png"
                    });

                    week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                        x: 42,
                        y: 199,
                        week_en: weekArray,
                        week_tc: weekArray,
                        week_sc: weekArray,
                        show_level: hmUI.show_level.ONAL_NORML,
                    });

                    let stepImg = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 42,
                        y: 281,
                        src: rootPath + "font/steps.png",
                    });
                    let stepText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 116,
                        y: 281,
                        type: hmUI.data_type.STEP,
                        font_array: fontArr,
                        invalid_image: rootPath + "font/none.png",
                        h_space: 0,
                        align_h: hmUI.align.LEFT,
                        padding: false,
                        isCharacter: false,
                    });

                    let powerImg = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 274,
                        y: 281,
                        src: rootPath + "font/power.png",
                    });
                    let powerText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 362,
                        y: 281,
                        type: hmUI.data_type.BATTERY,
                        font_array: fontArr,
                        unit_sc: rootPath + "font/unit.png",
                        unit_tc: rootPath + "font/unit.png",
                        unit_en: rootPath + "font/unit.png",
                        h_space: 0,
                        invalid_image: rootPath + "font/none.png",
                        align_h: hmUI.align.LEFT,
                        padding: false,
                        isCharacter: false,
                    });
                }


            },

            onInit() {
                console.log('index page.js on init invoke')

                this.init_view();
            },

            onReady() {
                console.log('index page.js on ready invoke')
            },

            onShow() {
                console.log('index page.js on show invoke')
            },

            onHide() {
                console.log('index page.js on hide invoke')
            },

            onDestory() {
                console.log('index page.js on destory invoke')
                timer.stopTimer(timerSupport)
            },
        });
        /*
        * end js
        */
    })()
} catch (e) {
    console.log(e)
}