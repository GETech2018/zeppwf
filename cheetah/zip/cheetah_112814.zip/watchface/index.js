try {
    (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;

        var __$$module$$__ = __$$app$$__.current;
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        /*
      * huamiOS bundle tool v1.0.17
      * Copyright © Huami. All Rights Reserved
      */
        'use strict';

        console.log("----->>>current");
        console.log(__$$hmAppManager$$__.currentApp.pid);
        console.log(__$$hmAppManager$$__.currentApp.current);


        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

            init_view() {
                let rootPath = "images/";
                let weekArray = []
                let monthArr = []
                for (let i = 1; i < 8; i++) {
                    weekArray.push(rootPath + `week/${i}.png`)
                }
                for (let i = 1; i < 13; i++) {
                    monthArr.push(rootPath + `month/${i}.png`)
                }

                let dateArray = []
                let timeArr = []
                let restimeArr = []
                let stepArr = []
                let powerArr = []
                let yearArr = []
                let secondsArr = []
                let heartArr = []
                let powerLevel = []
                let tempArr = []
                let moonArr = []
                let sunTime = []
                let stepLevelArray = []
                for (let i = 0; i < 10; i++) {
                    if (i <= 6) {
                        powerLevel.push(rootPath + "powerLevel/" + i + ".png")
                    }
                    if (i <= 5) {
                        stepLevelArray.push(rootPath + "stepLevel/" + i + ".png")
                    }
                    dateArray.push(rootPath + "date/" + i + ".png")
                    timeArr.push(rootPath + "time/" + i + ".png")
                    restimeArr.push(rootPath + "restTime/" + i + ".png")
                    stepArr.push(rootPath + "step/" + i + ".png")
                    powerArr.push(rootPath + "power/" + i + ".png")
                    yearArr.push(rootPath + "year/" + i + ".png")
                    secondsArr.push(rootPath + "seconds/" + i + ".png")
                    heartArr.push(rootPath + "heart/" + i + ".png")
                    tempArr.push(rootPath + "temp/" + i + ".png")
                    sunTime.push(rootPath + "sunTime/" + i + ".png")
                }
                for (let i = 1; i <= 30; i++) {
                    moonArr.push(rootPath + "moon/" + i + ".png")
                }
                let screenType = hmSetting.getScreenType()
                if (screenType == hmSetting.screen_type.AOD) {
                    let img_bg = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 0,
                        y: 0,
                        w: 454,
                        h: 454,
                        src: rootPath + "img/restBg.png",
                    });
                    let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                        hour_startX: 87 * 0.9458,
                        hour_startY: 204 * 0.9458,
                        hour_zero: 1,
                        hour_array: restimeArr,
                        hour_space: 0,
                        hour_align: hmUI.align.LEFT,

                        minute_startX: 256 * 0.9458,
                        minute_startY: 204 * 0.9458,
                        minute_zero: 1,
                        minute_array: restimeArr,
                        minute_space: 0,
                        minute_align: hmUI.align.LEFT,
                    });
                } else {
                    let img_bg = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 0,
                        y: 0,
                        w: 454,
                        h: 454,
                        src: rootPath + "img/bg.png",
                    });
                    //time text
                    let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                        hour_startX: 51.5 * 0.9458,
                        hour_startY: 122 * 0.9458,
                        hour_zero: 1,
                        hour_array: timeArr,
                        hour_space: 0,
                        hour_align: hmUI.align.LEFT,

                        minute_startX: 209.5 * 0.9458,
                        minute_startY: 122 * 0.9458,
                        minute_zero: 1,
                        minute_array: timeArr,
                        minute_space: 0,
                        minute_align: hmUI.align.LEFT,

                        second_startX: 356.5 * 0.9458,
                        second_startY: 122 * 0.9458,
                        second_zero: 1,
                        second_array: secondsArr,
                        second_space: 0,
                        second_align: hmUI.align.LEFT,

                        am_x: 79 * 0.9458,
                        am_y: 62 * 0.9458,
                        am_sc_path: rootPath + "time/AM.png",
                        am_en_path: rootPath + "time/AM.png",

                        pm_x: 79 * 0.9458,
                        pm_y: 62 * 0.9458,
                        pm_sc_path: rootPath + "time/PM.png",
                        pm_en_path: rootPath + "time/PM.png",
                    });
                    //week
                    week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                        x: 166 * 0.9458,
                        y: 322 * 0.9458,
                        week_en: weekArray,
                        week_tc: weekArray,
                        week_sc: weekArray,
                    });
                    //step text
                    let stepText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 40 * 0.9458,
                        y: 225 * 0.9458,
                        type: hmUI.data_type.STEP,
                        font_array: stepArr,
                        // invalid_image: rootPath + "font/none.png",
                        h_space: 0,
                        align_h: hmUI.align.CENTER_H,
                        padding: false,
                        isCharacter: false,
                    });

                    //step level
                    let step_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                        x: 0,
                        y: 0,
                        image_array: stepLevelArray,
                        image_length: stepLevelArray.length,//长度
                        type: hmUI.data_type.STEP,
                    });

                    // power text
                    let powerText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 264.5 * 0.9458,
                        y: 41 * 0.9458,
                        type: hmUI.data_type.BATTERY,
                        font_array: powerArr,
                        unit_sc: rootPath + "power/unit.png",
                        unit_tc: rootPath + "power/unit.png",
                        unit_en: rootPath + "power/unit.png",
                        h_space: 0,
                        // invalid_image: rootPath + "power/none.png",
                        align_h: hmUI.align.LEFT,
                        padding: false,
                        isCharacter: false,
                    });

                    let powerlevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                        x: 129,
                        y: 67,
                        image_array: powerLevel,
                        image_length: powerLevel.length,//长度
                        type: hmUI.data_type.BATTERY,
                    });

                    //month
                    let monthText = hmUI.createWidget(hmUI.widget.IMG_DATE, {
                        year_startX: 169 * 0.9458,
                        year_startY: 287 * 0.9458,
                        year_align: hmUI.align.LEFT,
                        year_space: 0,
                        year_zero: 1,
                        year_follow: 0,
                        year_en_array: yearArr,
                        year_sc_array: yearArr,
                        year_tc_array: yearArr,
                        year_is_character: false,

                        month_startX: 249 * 0.9458,
                        month_startY: 287 * 0.9458,
                        month_align: hmUI.align.LEFT,
                        month_space: 0,
                        month_zero: 0,
                        month_follow: 0,
                        month_en_array: monthArr,
                        month_sc_array: monthArr,
                        month_tc_array: monthArr,
                        month_is_character: true,

                        day_startX: 52 * 0.9458,
                        day_startY: 287 * 0.9458,
                        day_align: hmUI.align.LEFT,
                        day_space: 0,
                        day_zero: 1,
                        day_follow: 0,
                        day_en_array: dateArray,
                        day_sc_array: dateArray,
                        day_tc_array: dateArray,
                        day_is_character: false,
                    });
                    //heart
                    let heartTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 375.5 * 0.9458,
                        y: 204 * 0.9458,
                        type: hmUI.data_type.HEART,
                        font_array: heartArr,
                        h_space: 0,
                        align_h: hmUI.align.LEFT,
                        padding: false,
                        invalid_image: rootPath + "heart/none.png",
                        isCharacter: true,
                    });

                    //cal
                    let calTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 369 * 0.9458,
                        y: 248 * 0.9458,
                        type: hmUI.data_type.CAL,
                        font_array: heartArr,
                        h_space: 0,
                        align_h: hmUI.align.LEFT,
                        padding: false,
                        invalid_image: rootPath + "heart/none.png",
                        isCharacter: false,
                    });

                    //sun rise time
                    let sun_rise_time = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 114 * 0.9458,
                        y: 386.5 * 0.9458,
                        type: hmUI.data_type.SUN_RISE,
                        font_array: sunTime,
                        h_space: 0,
                        align_h: hmUI.align.CENTER_H,
                        dot_image: rootPath + "sunTime/dot.png",
                        padding: true,
                        invalid_image: rootPath + "temp/none.png",
                        isCharacter: false,
                    });
                    //sun set time
                    let sun_set_time = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 292 * 0.9458,
                        y: 386.5 * 0.9458,
                        type: hmUI.data_type.SUN_SET,
                        font_array: sunTime,
                        h_space: 0,
                        align_h: hmUI.align.CENTER_H,
                        dot_image: rootPath + "sunTime/dot.png",
                        padding: true,
                        invalid_image: rootPath + "temp/none.png",
                        isCharacter: false,
                    });
                    //moon
                    let moon_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                        x: 196 * 0.9458,
                        y: 353.5 * 0.9458,
                        image_array: moonArr,
                        image_length: moonArr.length,
                        type: hmUI.data_type.MOON,
                    });

                    //WEATHER_LOW
                    let low_temp = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 276 * 0.9458,
                        y: 423 * 0.9458,
                        type: hmUI.data_type.WEATHER_LOW,
                        font_array: tempArr,
                        h_space: 0,
                        align_h: hmUI.align.RIGHT,
                        padding: false,
                        invalid_image: rootPath + "temp/none.png",
                        negative_image: rootPath + "temp/minus.png",
                        unit_sc: rootPath + "temp/unit.png",
                        unit_tc: rootPath + "temp/unit.png",
                        unit_en: rootPath + "temp/unit.png",
                        isCharacter: false,
                    });
                    //WEATHER_HIGH
                    let high_temp = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 147 * 0.9458,
                        y: 423 * 0.9458,
                        type: hmUI.data_type.WEATHER_HIGH,
                        font_array: tempArr,
                        h_space: 0,
                        align_h: hmUI.align.LEFT,
                        padding: false,
                        invalid_image: rootPath + "temp/none.png",
                        negative_image: rootPath + "temp/minus.png",
                        unit_sc: rootPath + "temp/unit.png",
                        unit_tc: rootPath + "temp/unit.png",
                        unit_en: rootPath + "temp/unit.png",
                        isCharacter: false,
                    });
                    //clock bg
                    let clockBg = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 71 * 0.9458,
                        y: 345.5 * 0.9458,
                        alpha: 100,
                        src: rootPath + "img/clock.png",
                    });
                    //clock
                    let clock = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                        x: 71 * 0.9458,
                        y: 345.5 * 0.9458,
                        type: hmUI.system_status.CLOCK,
                        src: rootPath + "img/clock.png",
                    });
                    //disturb bg
                    let disturbBg = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 360 * 0.9458,
                        y: 345.5 * 0.9458,
                        alpha: 100,
                        src: rootPath + "img/disturb.png",
                    });
                    //disturb
                    let disturb = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                        x: 360 * 0.9458,
                        y: 345.5 * 0.9458,
                        type: hmUI.system_status.DISTURB,
                        src: rootPath + "img/disturb.png",
                    });
                }
                let clickstep = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 17 * 0.9458,
                    y: 208 * 0.9458,
                    w: 296,
                    h: 66,
                    type: hmUI.data_type.STEP, //必写 跳转的action
                });
                let clickheart = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 369.5 * 0.9458,
                    y: 204 * 0.9458,
                    w: 50,
                    h: 50,
                    type: hmUI.data_type.HEART, //必写 跳转的action
                });
                let clickcal = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 340 * 0.9458,
                    y: 242 * 0.9458,
                    w: 118,
                    h: 38,
                    type: hmUI.data_type.CAL, //必写 跳转的action
                });

                let clickAlarm = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 54 * 0.9458,
                    y: 350 * 0.9458,
                    w: 87,
                    h: 54,
                    type: hmUI.data_type.ALARM_CLOCK, //必写 跳转的action
                });

                let clickSunrise = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 139 * 0.9458,
                    y: 350 * 0.9458,
                    w: 51,
                    h: 66,
                    type: hmUI.data_type.SUN_RISE, //必写 跳转的action
                });

                let clickSunset = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 295 * 0.9458,
                    y: 350 * 0.9458,
                    w: 51,
                    h: 66,
                    type: hmUI.data_type.SUN_SET, //必写 跳转的action
                });

                let clickWeatherHigh = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 139 * 0.9458,
                    y: 415 * 0.9458,
                    w: 54,
                    h: 29,
                    type: hmUI.data_type.WEATHER_HIGH, //必写 跳转的action
                });

                let clickWeatherLow = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 293 * 0.9458,
                    y: 415 * 0.9458,
                    w: 54,
                    h: 29,
                    type: hmUI.data_type.WEATHER_LOW, //必写 跳转的action
                });
                let clickmoon = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 195 * 0.9458,
                    y: 353.5 * 0.9458,
                    w: 70,
                    h: 70,
                    type: hmUI.data_type.MOON, //必写 跳转的action
                });
            },

            onInit() {
                console.log('index page.js on init invoke')

                this.init_view();
            },

            onReady() {
                console.log('index page.js on ready invoke')
            },

            onShow() {
                console.log('index page.js on show invoke')
            },

            onHide() {
                console.log('index page.js on hide invoke')
            },

            onDestory() {
                console.log('index page.js on destory invoke')
                timer.stopTimer(timerSupport)
            },
        });
        /*
        * end js
        */
    })()
} catch (e) {
    console.log(e)
}