try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 454,
                    h: 454,
                    src: '3.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 47,
                    y: 44,
                    src: '4.png',
                    type: hmUI.system_status.DISCONNECT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 338,
                    y: 336,
                    src: '5.png',
                    type: hmUI.system_status.DISTURB,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 347,
                    y: 57,
                    src: '6.png',
                    type: hmUI.system_status.LOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 56,
                    y: 343,
                    src: '7.png',
                    type: hmUI.system_status.CLOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 184,
                    y: 110,
                    image_array: [
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png'
                    ],
                    image_length: 29,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 128,
                    y: 9,
                    image_array: [
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png'
                    ],
                    image_length: 6,
                    type: hmUI.data_type.AQI,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 71,
                    y: 175,
                    type: hmUI.data_type.BATTERY,
                    font_array: [
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -3,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '54.png',
                    unit_tc: '54.png',
                    unit_en: '54.png',
                    invalid_image: '53.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: '55.png',
                    center_x: 106,
                    center_y: 227,
                    x: 11,
                    y: 49,
                    type: hmUI.data_type.BATTERY,
                    start_angle: 70,
                    end_angle: 290,
                    cover_x: 0,
                    cover_y: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 318,
                    y: 175,
                    type: hmUI.data_type.CAL,
                    font_array: [
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -3,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '56.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: '57.png',
                    center_x: 350,
                    center_y: 227,
                    x: 11,
                    y: 49,
                    type: hmUI.data_type.CAL,
                    start_angle: 70,
                    end_angle: 290,
                    cover_x: 1,
                    cover_y: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 188,
                    y: 371,
                    type: hmUI.data_type.STEP,
                    font_array: [
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -3,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '58.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: '59.png',
                    center_x: 227,
                    center_y: 339,
                    x: 11,
                    y: 57,
                    type: hmUI.data_type.STEP,
                    start_angle: -135,
                    end_angle: 135,
                    cover_x: 0,
                    cover_y: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 110,
                    y: 126,
                    week_en: [
                        '60.png',
                        '61.png',
                        '62.png',
                        '63.png',
                        '64.png',
                        '65.png',
                        '66.png'
                    ],
                    week_sc: [
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png',
                        '71.png',
                        '72.png',
                        '73.png'
                    ],
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 274,
                    month_startY: 127,
                    month_sc_array: [
                        '74.png',
                        '75.png',
                        '76.png',
                        '77.png',
                        '78.png',
                        '79.png',
                        '80.png',
                        '81.png',
                        '82.png',
                        '83.png'
                    ],
                    month_tc_array: [
                        '74.png',
                        '75.png',
                        '76.png',
                        '77.png',
                        '78.png',
                        '79.png',
                        '80.png',
                        '81.png',
                        '82.png',
                        '83.png'
                    ],
                    month_en_array: [
                        '74.png',
                        '75.png',
                        '76.png',
                        '77.png',
                        '78.png',
                        '79.png',
                        '80.png',
                        '81.png',
                        '82.png',
                        '83.png'
                    ],
                    month_align: hmUI.align.LEFT,
                    month_zero: 1,
                    month_follow: 0,
                    month_space: -4,
                    month_is_character: false,
                    day_startX: 314,
                    day_startY: 127,
                    day_sc_array: [
                        '74.png',
                        '75.png',
                        '76.png',
                        '77.png',
                        '78.png',
                        '79.png',
                        '80.png',
                        '81.png',
                        '82.png',
                        '83.png'
                    ],
                    day_tc_array: [
                        '74.png',
                        '75.png',
                        '76.png',
                        '77.png',
                        '78.png',
                        '79.png',
                        '80.png',
                        '81.png',
                        '82.png',
                        '83.png'
                    ],
                    day_en_array: [
                        '74.png',
                        '75.png',
                        '76.png',
                        '77.png',
                        '78.png',
                        '79.png',
                        '80.png',
                        '81.png',
                        '82.png',
                        '83.png'
                    ],
                    day_align: hmUI.align.LEFT,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: -4,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 154,
                    hour_startY: 66,
                    hour_array: [
                        '84.png',
                        '85.png',
                        '86.png',
                        '87.png',
                        '88.png',
                        '89.png',
                        '90.png',
                        '91.png',
                        '92.png',
                        '93.png'
                    ],
                    hour_space: -1,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 233,
                    minute_startY: 66,
                    minute_array: [
                        '84.png',
                        '85.png',
                        '86.png',
                        '87.png',
                        '88.png',
                        '89.png',
                        '90.png',
                        '91.png',
                        '92.png',
                        '93.png'
                    ],
                    minute_space: -1,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 227,
                    hour_centerY: 227,
                    hour_posX: 36,
                    hour_posY: 227,
                    hour_path: '94.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 227,
                    minute_centerY: 227,
                    minute_posX: 36,
                    minute_posY: 227,
                    minute_path: '95.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    second_centerX: 227,
                    second_centerY: 227,
                    second_posX: 36,
                    second_posY: 227,
                    second_path: '96.png',
                    second_cover_x: 0,
                    second_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 454,
                    h: 454,
                    src: '97.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 184,
                    y: 110,
                    image_array: [
                        '98.png',
                        '99.png',
                        '100.png',
                        '101.png',
                        '102.png',
                        '103.png',
                        '104.png',
                        '105.png',
                        '106.png',
                        '107.png',
                        '108.png',
                        '109.png',
                        '110.png',
                        '111.png',
                        '112.png',
                        '113.png',
                        '114.png',
                        '115.png',
                        '116.png',
                        '117.png',
                        '118.png',
                        '119.png',
                        '120.png',
                        '121.png',
                        '122.png',
                        '123.png',
                        '124.png',
                        '125.png',
                        '126.png'
                    ],
                    image_length: 29,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 188,
                    y: 357,
                    type: hmUI.data_type.STEP,
                    font_array: [
                        '127.png',
                        '128.png',
                        '129.png',
                        '130.png',
                        '131.png',
                        '132.png',
                        '133.png',
                        '134.png',
                        '135.png',
                        '136.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -3,
                    show_level: hmUI.show_level.ONLY_AOD,
                    invalid_image: '137.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: '138.png',
                    center_x: 227,
                    center_y: 339,
                    x: 12,
                    y: 57,
                    type: hmUI.data_type.STEP,
                    start_angle: -135,
                    end_angle: 135,
                    cover_x: 0,
                    cover_y: 0,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 110,
                    y: 126,
                    week_en: [
                        '139.png',
                        '140.png',
                        '141.png',
                        '142.png',
                        '143.png',
                        '144.png',
                        '145.png'
                    ],
                    week_sc: [
                        '146.png',
                        '147.png',
                        '148.png',
                        '149.png',
                        '150.png',
                        '151.png',
                        '152.png'
                    ],
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 274,
                    month_startY: 127,
                    month_sc_array: [
                        '127.png',
                        '128.png',
                        '129.png',
                        '130.png',
                        '131.png',
                        '132.png',
                        '133.png',
                        '134.png',
                        '135.png',
                        '136.png'
                    ],
                    month_tc_array: [
                        '127.png',
                        '128.png',
                        '129.png',
                        '130.png',
                        '131.png',
                        '132.png',
                        '133.png',
                        '134.png',
                        '135.png',
                        '136.png'
                    ],
                    month_en_array: [
                        '127.png',
                        '128.png',
                        '129.png',
                        '130.png',
                        '131.png',
                        '132.png',
                        '133.png',
                        '134.png',
                        '135.png',
                        '136.png'
                    ],
                    month_align: hmUI.align.LEFT,
                    month_zero: 1,
                    month_follow: 0,
                    month_space: -4,
                    month_is_character: false,
                    day_startX: 314,
                    day_startY: 127,
                    day_sc_array: [
                        '127.png',
                        '128.png',
                        '129.png',
                        '130.png',
                        '131.png',
                        '132.png',
                        '133.png',
                        '134.png',
                        '135.png',
                        '136.png'
                    ],
                    day_tc_array: [
                        '127.png',
                        '128.png',
                        '129.png',
                        '130.png',
                        '131.png',
                        '132.png',
                        '133.png',
                        '134.png',
                        '135.png',
                        '136.png'
                    ],
                    day_en_array: [
                        '127.png',
                        '128.png',
                        '129.png',
                        '130.png',
                        '131.png',
                        '132.png',
                        '133.png',
                        '134.png',
                        '135.png',
                        '136.png'
                    ],
                    day_align: hmUI.align.LEFT,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: -4,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 227,
                    hour_centerY: 227,
                    hour_posX: 22,
                    hour_posY: 227,
                    hour_path: '153.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 227,
                    minute_centerY: 227,
                    minute_posX: 22,
                    minute_posY: 227,
                    minute_path: '155.png',
                    minute_cover_path: '154.png',
                    minute_cover_x: 209,
                    minute_cover_y: 209,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}