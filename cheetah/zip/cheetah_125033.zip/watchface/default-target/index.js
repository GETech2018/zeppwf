try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface6');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 454,
                    h: 454,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_val: new Date().getHours(),
                    hour_zero: 1,
                    hour_startX: 30,
                    hour_startY: 145,
                    hour_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    hour_space: 10,
                    hour_align: hmUI.align.CENTER_H,
                    minute_val: new Date().getMinutes(),
                    minute_zero: 1,
                    minute_startX: 215,
                    minute_startY: 145,
                    minute_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    minute_space: 10,
                    minute_align: hmUI.align.CENTER_H,
                    minute_follow: 0,
                    second_val: new Date().getSeconds(),
                    second_zero: 1,
                    second_startX: 368,
                    second_startY: 210,
                    second_array: [
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png'
                    ],
                    second_space: 10,
                    second_align: hmUI.align.CENTER_H,
                    second_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 183,
                    y: 160,
                    w: 15,
                    h: 69,
                    src: '33.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    year_startX: 270,
                    year_startY: 80,
                    year_sc_array: [
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png'
                    ],
                    year_tc_array: [
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png'
                    ],
                    year_en_array: [
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png'
                    ],
                    year_align: hmUI.align.CENTER_H,
                    year_zero: 1,
                    year_space: 10,
                    year_is_character: false,
                    month_startX: 195,
                    month_startY: 80,
                    month_sc_array: [
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png'
                    ],
                    month_tc_array: [
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png'
                    ],
                    month_en_array: [
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png'
                    ],
                    month_align: hmUI.align.CENTER_H,
                    month_zero: 1,
                    month_follow: 0,
                    month_space: 10,
                    month_is_character: false,
                    day_startX: 120,
                    day_startY: 80,
                    day_sc_array: [
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png',
                        '58.png',
                        '59.png',
                        '60.png',
                        '61.png',
                        '62.png',
                        '63.png'
                    ],
                    day_tc_array: [
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png',
                        '58.png',
                        '59.png',
                        '60.png',
                        '61.png',
                        '62.png',
                        '63.png'
                    ],
                    day_en_array: [
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png',
                        '58.png',
                        '59.png',
                        '60.png',
                        '61.png',
                        '62.png',
                        '63.png'
                    ],
                    day_align: hmUI.align.CENTER_H,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 10,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 250,
                    y: 95,
                    w: 15,
                    h: 4,
                    src: '64.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 175,
                    y: 95,
                    w: 15,
                    h: 4,
                    src: '65.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 190,
                    y: 20,
                    type: hmUI.data_type.BATTERY,
                    font_array: [
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png',
                        '71.png',
                        '72.png',
                        '73.png',
                        '74.png',
                        '75.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 10,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '76.png',
                    unit_tc: '76.png',
                    unit_en: '76.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 150,
                    y: 10,
                    src: '77.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 120,
                    y: 340,
                    type: hmUI.data_type.HEART,
                    font_array: [
                        '78.png',
                        '79.png',
                        '80.png',
                        '81.png',
                        '82.png',
                        '83.png',
                        '84.png',
                        '85.png',
                        '86.png',
                        '87.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 10,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '88.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 55,
                    y: 330,
                    src: '89.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 65,
                    y: 72,
                    src: '90.png',
                    type: hmUI.system_status.DISCONNECT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 370,
                    y: 145,
                    src: '91.png',
                    type: hmUI.system_status.CLOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 280,
                    y: 340,
                    type: hmUI.data_type.CAL,
                    font_array: [
                        '92.png',
                        '93.png',
                        '94.png',
                        '95.png',
                        '96.png',
                        '97.png',
                        '98.png',
                        '99.png',
                        '100.png',
                        '101.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 10,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '102.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 225,
                    y: 330,
                    src: '103.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 300,
                    y: 280,
                    type: hmUI.data_type.DISTANCE,
                    font_array: [
                        '104.png',
                        '105.png',
                        '106.png',
                        '107.png',
                        '108.png',
                        '109.png',
                        '110.png',
                        '111.png',
                        '112.png',
                        '113.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 10,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    dot_image: '115.png',
                    invalid_image: '114.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 240,
                    y: 270,
                    src: '116.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 85,
                    y: 280,
                    type: hmUI.data_type.STEP,
                    font_array: [
                        '117.png',
                        '118.png',
                        '119.png',
                        '120.png',
                        '121.png',
                        '122.png',
                        '123.png',
                        '124.png',
                        '125.png',
                        '126.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 10,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '127.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 25,
                    y: 270,
                    src: '128.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 215,
                    y: 400,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: [
                        '129.png',
                        '130.png',
                        '131.png',
                        '132.png',
                        '133.png',
                        '134.png',
                        '135.png',
                        '136.png',
                        '137.png',
                        '138.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 10,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '141.png',
                    unit_tc: '141.png',
                    unit_en: '141.png',
                    negative_image: '140.png',
                    invalid_image: '139.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 160,
                    y: 392,
                    src: '142.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}