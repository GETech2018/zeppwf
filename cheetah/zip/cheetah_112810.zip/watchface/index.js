try {
  (() => {

    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

    /*
  * huamiOS bundle tool v1.0.17
  * Copyright © Huami. All Rights Reserved
  */
    'use strict';

    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    function rem(num) {
      return num * (454 / 466);   //andes
      // return num * (466 / 466);  //berlin
      // return num * (416 / 466);  //vienna
    }
    let SBname = `andes/`;
    // let SBname = `vienna/`;
    // let SBname = `berlin/`;
    /**
   * 
   */

    let strRootPath = "images/" + SBname;
    let strStepPath = strRootPath + "step/";
    let strTimePath = strRootPath + "time/";
    let arrFont = [];
    let arrTime = [];
    let arrWeekEn = [];
    let arrWeekSc = [];
    let arrFish = [];
    for (let i = 0; i < 10; i++) {
      arrFont.push(strStepPath + `font` + i + ".png");
      arrTime.push(strTimePath + `time_` + i + ".png");
      arrFish.push(strRootPath + `fishlength/` + i + ".png");
    }
    for (let i = 1; i < 8; i++) {
      arrWeekEn.push(strRootPath + `week/en/` + i + ".png");
      arrWeekSc.push(strRootPath + `week/tc/` + i + ".png");
    }
    let objBg = {
      x: 0,
      y: 0,
      w: rem(466),
      h: rem(466),
      src: strRootPath + `bg.png`,
      show_level: hmUI.show_level.ONLY_NORMAL
    };
    let objAnim = {
      x: 0,
      y: 0,
      anim_path: strRootPath + "bg/water",
      anim_prefix: "water",
      anim_ext: "png",
      anim_fps: 24,
      anim_size: 48,
      repeat_count: 1, //0位无限重复
      anim_repeat: true,//是否重复
      anim_status: hmUI.anim_status.START,
      // display_on_restart: true,//从息屏到亮屏是否自动重复播放
      // anim_complete_call:animCall,//动画结束回调 无限重复永远不会调用到
      show_level: hmUI.show_level.ONLY_NORMAL
    };
    let objBatteryBg = {
      x: rem(193),
      y: rem(32),
      src: strRootPath + `battery/0.png`,
      show_level: hmUI.show_level.ONLY_NORMAL
    };
    let objBatteryIcon = {
      x: rem(161),
      y: rem(32),
      src: strRootPath + `step/battery.png`,
      show_level: hmUI.show_level.ONLY_NORMAL
    };

    let objTime = {
      hour_zero: 1, //是否补零
      hour_startX: rem(74),
      hour_startY: rem(81),
      hour_array: arrTime,
      hour_space: 10, //每个数组间的间隔
      minute_zero: 1, //是否补零
      minute_startX: rem(250),
      minute_startY: rem(81),
      minute_array: arrTime,
      minute_space: 10, //每个数组间的间隔
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
    };
    let objBatteryText = {
      x: rem(252),
      y: rem(33),
      type: hmUI.data_type.BATTERY,
      font_array: arrFont,
      h_space: 1,
      align_h: hmUI.align.LEFT,
      unit_sc: strRootPath + "unit/baifenhao.png",
      unit_tc: strRootPath + "unit/baifenhao.png",
      unit_en: strRootPath + "unit/baifenhao.png",
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    let objTimeUnit = {
      x: rem(200),
      y: rem(78),
      src: strTimePath + "maohao.png",
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
    };
    let objDate = {
      month_startX: rem(70),
      month_startY: rem(185),
      month_unit_sc: strRootPath + "unit/fenhao.png", //单位
      month_unit_tc: strRootPath + "unit/fenhao.png",
      month_unit_en: strRootPath + "unit/fenhao.png",
      month_align: hmUI.align.LEFT,
      month_space: 0,//文字间隔
      month_zero: true,//是否补零
      month_en_array: arrFont,
      month_sc_array: arrFont,
      month_tc_array: arrFont,
      day_follow: 1,//是否跟随
      day_align: hmUI.align.LEFT,
      day_space: 0,//文字间隔
      day_zero: true,//是否补零
      day_en_array: arrFont,
      day_sc_array: arrFont,
      day_tc_array: arrFont,
      show_level: hmUI.show_level.ONLY_NORMAL
    };
    let objStep = {
      x: rem(210),
      y: rem(185),
      w: rem(150),
      type: hmUI.data_type.STEP,
      font_array: arrFont,
      h_space: 0,
      align_h: hmUI.align.RIGHT,

      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    let objStepIcon = {
      x: rem(370),
      y: rem(184),
      src: strRootPath + `step/step.png`,
      show_level: hmUI.show_level.ONLY_NORMAL
    };
    let objStepJump = {
      x: rem(289),
      y: rem(180),
      w: 110,
      h: 34,
      type: hmUI.data_type.STEP, //必写 跳转的action
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    let objWeek = {
      x: rem(150),
      y: rem(184),
      week_en: arrWeekEn,
      week_tc: arrWeekSc,
      week_sc: arrWeekSc,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    //------------完成界面配置start-------------------
    let objFillBg = {
      x: -2,
      y: -2,
      w: rem(470),
      h: rem(470),
      radius: rem(470 / 2),
      color: 0x000000,
    };
    let objbgLight = {
      x: 0,
      y: 0,
      src: strRootPath + "bg_light.png",
    };

    //------------完成界面配置end---------------------
    let battery = hmSensor.createSensor(hmSensor.id.BATTERY);
    let battery_rect;
    function setBattery(battery) {
      let batteryCurrent = battery.current;
      // batteryCurrent = 100; //调试
      let batw = 30 * (batteryCurrent / 100);
      let color;
      if (batteryCurrent <= 15) {
        color = 0xff0000;
      } else {
        color = 0xffffff;
      }
      battery_rect.setProperty(hmUI.prop.MORE, {
        x: rem(197),
        y: Math.floor(rem(36)),
        w: rem(batw),
        h: rem(14),
        color
      });
    }
    let vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);//震动传感器
    // vibrate.stop();
    let flag = false;
    const logger = DeviceRuntimeCore.HmLogger.getLogger("defult");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        //--------------------非交互区域----------------------
        hmUI.createWidget(hmUI.widget.IMG_ANIM, objAnim);
        hmUI.createWidget(hmUI.widget.IMG, objBg);
        hmUI.createWidget(hmUI.widget.IMG, objBatteryBg);
        hmUI.createWidget(hmUI.widget.IMG, objBatteryIcon);
        battery_rect = hmUI.createWidget(hmUI.widget.FILL_RECT, {
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        setBattery(battery);
        battery.addEventListener(hmSensor.event.CHANGE, function () {
          setBattery(battery);
        });
        hmUI.createWidget(hmUI.widget.TEXT_IMG, objBatteryText);
        hmUI.createWidget(hmUI.widget.IMG_TIME, objTime);
        hmUI.createWidget(hmUI.widget.IMG, objTimeUnit);
        hmUI.createWidget(hmUI.widget.IMG_DATE, objDate);
        hmUI.createWidget(hmUI.widget.IMG_WEEK, objWeek);
        hmUI.createWidget(hmUI.widget.IMG, objStepIcon);
        hmUI.createWidget(hmUI.widget.TEXT_IMG, objStep);
        hmUI.createWidget(hmUI.widget.IMG_CLICK, objStepJump);
        // hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
        //   resume_call: (function () {
        //     setBattery(battery);
        //     console.log('ui resume');
        //   }),
        //   pause_call: (function () {
        //     console.log('ui pause');
        //   }),
        // });
        function randomNum(min, max) { //获取两个数值之间的随机数
          let res = Math.floor(Math.random() * (max - min + 1));
          let res1 = res + min;
          return res1;
        }
        let powerBg = hmUI.createWidget(hmUI.widget.IMG, {
          x: rem(40),
          y: rem(230),
          src: strRootPath + "bg/bite/bite_0.png",
          show_level: hmUI.show_level.ONLY_NORMAL
        });
        let powerBg1 = hmUI.createWidget(hmUI.widget.IMG, { //按钮背景
          x: rem(185),
          y: rem(315),
          src: strRootPath + "btn/button.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        let powerBg2 = hmUI.createWidget(hmUI.widget.IMG, {  //按钮上的三角图
          x: rem(204),
          y: rem(330),
          src: strRootPath + "btn/play.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        //---------------清屏重新创建部分------------------
        let animFishing = null;
        let btn = null;
        let btnPlay = null;
        let animCreate = null;
        let objAnimThrow = null;
        let objAnimBite = null;
        let failBg = null;
        let failAnim = null;
        let objAnimClick = null;
        let fillBg = null;
        let bgLight = null;
        let animRetractor = null;
        let mathNum = null;
        let btnResBg = null;
        let btnRes = null;
        let btnStopBg = null;
        let btnStop = null;
        let clockTimer1 = null;
        let clockTimer = null;
        let clockTimer11 = null;
        //-------------------------------------------------------

        //省电模式下 处理
        let arc = hmUI.createWidget(hmUI.widget.TEXT, {
          x: rem(0),
          y: rem(233),
          w: rem(466),
          h: rem(233),
          text: '',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let prompts = null; //提示语
        let status = null; //记录状态 同一种模式下 不需要多次刷新
        let nextStatus = null;
        let successNum = 0; //解决 在成功界面进入省电模式 会震动问题
        // let arc = hmUI.createWidget(hmUI.widget.FILL_RECT, {
        //   x: rem(106),
        //   y: rem(223),
        //   w: rem(252),
        //   h: rem(194),
        //   color: 0xfc6950,
        //   show_level: hmUI.show_level.ONLY_NORMAL,
        // });

        function getState() {
          const language = hmSetting.getLanguage();
          if (language == 0) {
            prompts = '省电模式下，该功能停用';
          } else if (language == 1) {
            prompts = '省電模式下，該功能停用';
          } else {
            prompts = 'In power saving mode, this function is disabled';
          }
          const { powerSaving } = hmSetting.getSystemMode();
          if (!powerSaving) {
            status = `正常模式`;
            if (status == nextStatus) {
              return;
            }
            nextStatus = status;
            powerBg.setProperty(hmUI.prop.VISIBLE, false);
            powerBg1.setProperty(hmUI.prop.VISIBLE, false);
            powerBg2.setProperty(hmUI.prop.VISIBLE, false);
            vibrate.stop();
            animFishing = hmUI.createWidget(hmUI.widget.IMG_ANIM, { //鱼咬钩动画
              x: rem(40),
              y: rem(230),
              anim_path: strRootPath + "bg/fishing",
              anim_prefix: "fishing",
              anim_ext: "png",
              anim_fps: 24,
              anim_size: 48,
              anim_repeat: true,
              repeat_count: 1,
              anim_status: 1,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn = hmUI.createWidget(hmUI.widget.IMG, { //按钮背景
              x: rem(185),
              y: rem(315),
              src: strRootPath + "btn/button.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btnPlay = hmUI.createWidget(hmUI.widget.IMG, {  //按钮上的三角图
              x: rem(204),
              y: rem(330),
              src: strRootPath + "btn/play.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            animCreate = hmUI.createWidget(hmUI.widget.IMG_ANIM, { //点击按钮后3秒倒计时动画
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            // animCreate.setProperty(hmUI.prop.VISIBLE, false);//隐藏倒计时动画控件
            btnPlay.addEventListener(hmUI.event.CLICK_UP, (function (info) {//按钮事件

              btnPlay.setProperty(hmUI.prop.VISIBLE, false); //按钮三角隐藏
              animCreate.setProperty(hmUI.prop.MORE, {
                x: rem(202),
                y: rem(330),
                anim_path: strRootPath + "play",
                anim_prefix: "game",
                anim_ext: "png",
                anim_fps: 1,
                anim_size: 3,
                anim_repeat: false,
                repeat_count: 1,
                // default_frame_index: 0,
                anim_complete_call: animateShow,  //3秒倒计时动画结束后、隐藏按钮以及背景、开始甩杆动画
              });
              animCreate.setProperty(hmUI.prop.VISIBLE, true); //显示3秒倒计时动画（是否可以移除）
              animCreate.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.START);//播放三秒倒计时开始

              hmSetting.setBrightScreen(200); //开始钓鱼后屏幕常亮200秒
            }));
            objAnimThrow = hmUI.createWidget(hmUI.widget.IMG_ANIM, {//甩杆动画控件
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            objAnimBite = hmUI.createWidget(hmUI.widget.IMG_ANIM, {//上钩动画控件
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            // objAnimThrow.setProperty(hmUI.prop.VISIBLE, false); //隐藏甩杆动画（是否可以移除）
            // objAnimBite.setProperty(hmUI.prop.VISIBLE, false); ////隐藏上钩动画（是否可以移除）
            //--------------------钓鱼失败界面开始--------------------
            failBg = hmUI.createWidget(hmUI.widget.IMG, {//脱钩背景图
              x: 0,
              y: 0,
              src: strRootPath + `mask.png`,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            failAnim = hmUI.createWidget(hmUI.widget.IMG_ANIM, {//脱钩动画控件
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            failBg.setProperty(hmUI.prop.VISIBLE, false);//隐藏脱钩背景
            // failAnim.setProperty(hmUI.prop.VISIBLE, false); //隐藏脱钩动画
            //--------------------钓鱼失败界面结束--------------------
            objAnimClick = hmUI.createWidget(hmUI.widget.IMG_ANIM, {//小手引导点击动画控件
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            fillBg = hmUI.createWidget(hmUI.widget.FILL_RECT, {//成功上钩底色背景控件
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            bgLight = hmUI.createWidget(hmUI.widget.IMG, {//成功上钩背景控件
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            animRetractor = hmUI.createWidget(hmUI.widget.IMG_ANIM, {//成功上钩动画控件
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            mathNum = hmUI.createWidget(hmUI.widget.TEXT_IMG, {//鱼线长度控件
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            //--------------------重新开始按钮--------------------
            btnResBg = hmUI.createWidget(hmUI.widget.IMG, {//重新开始背景图片
              x: rem(253),
              y: rem(315),
              src: strRootPath + "btn/button.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btnRes = hmUI.createWidget(hmUI.widget.IMG, {//重新开始图片
              x: rem(270),
              y: rem(330),
              src: strRootPath + "btn/return.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            btnStopBg = hmUI.createWidget(hmUI.widget.IMG, {//重新开始背景图片
              x: rem(117),
              y: rem(315),
              src: strRootPath + "btn/button.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btnStop = hmUI.createWidget(hmUI.widget.IMG, {//重新开始图片
              x: rem(135),
              y: rem(330),
              src: strRootPath + "btn/stop.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btnResBg.setProperty(hmUI.prop.VISIBLE, false); //隐藏重新开始按钮
            btnRes.setProperty(hmUI.prop.VISIBLE, false);//隐藏重新开始按钮
            btnStopBg.setProperty(hmUI.prop.VISIBLE, false); //隐藏重新开始按钮
            btnStop.setProperty(hmUI.prop.VISIBLE, false);//隐藏重新开始按钮
            //--------------------重新开始按钮--------------------
            fillBg.setProperty(hmUI.prop.VISIBLE, false);//隐藏成功界面控件
            bgLight.setProperty(hmUI.prop.VISIBLE, false);//隐藏成功界面控件
            animRetractor.setProperty(hmUI.prop.VISIBLE, false);//隐藏成功界面控件
            mathNum.setProperty(hmUI.prop.VISIBLE, false);//隐藏成功界面控件
            objAnimClick.setProperty(hmUI.prop.VISIBLE, false); //小手引导点击动画控件

            //-----------------------------方法↓----------------------------
            function animateShow() { //3秒倒计时动画结束后执行的函数、隐藏按钮以及背景、鱼咬钩动画、开始甩杆动画
              btn.setProperty(hmUI.prop.VISIBLE, false);
              animCreate.setProperty(hmUI.prop.VISIBLE, false);
              animFishing.setProperty(hmUI.prop.VISIBLE, false);
              animFishing.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.STOP);//停止咬钩动画
              animThrow(); //开始甩杆动画
            }
            function animThrow() { //甩杆动画  不循环播放
              objAnimThrow.setProperty(hmUI.prop.VISIBLE, true); //显示甩杆动画控件
              objAnimThrow.setProperty(hmUI.prop.MORE, { //更改甩杆动画属性
                x: 0,
                y: rem(120),
                anim_path: strRootPath + "bg/throw",
                anim_prefix: "s",
                anim_ext: "png",
                anim_fps: 24,
                anim_size: 48,
                anim_repeat: false,
                repeat_count: 1,
                anim_status: 1,
                // default_frame_index: 0,
                anim_complete_call: animBite, //回调鱼上钩动画
              });
            };
            function animBite() { //鱼上钩动画
              vibrate.stop();
              if (!clockTimer1) {
                clockTimer1 = timer.createTimer(  //上钩动画
                  3000, 1000, (function (option) {
                    timer.stopTimer(clockTimer1);
                    clockTimer1 = null;

                    vibrate.start();//轻震动
                    // hmUI.showToast({
                    //   text: `上钩界面震动`
                    // });
                    objAnimThrow.setProperty(hmUI.prop.VISIBLE, false);  //隐藏甩杆动画
                    objAnimThrow.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.STOP);//停止甩杆动画
                    objAnimBite.setProperty(hmUI.prop.VISIBLE, true); //显示上钩动画控件
                    objAnimBite.setProperty(hmUI.prop.MORE, { //上钩动画更改属性
                      x: rem(40),
                      y: rem(230),
                      anim_path: strRootPath + "bg/bite",
                      anim_prefix: "bite",
                      anim_ext: "png",
                      anim_fps: 24,
                      anim_size: 48,
                      // anim_repeat: false,
                      anim_repeat: true,
                      repeat_count: 1,
                      anim_status: 1,
                      // default_frame_index: 0,
                    });
                    flag = true;
                    objAnimBite.addEventListener(hmUI.event.CLICK_UP, (function (info) {//动画点击事件
                      flag = false;//控制引导点击动画开关（true展示）
                      vibrate.stop();//停止震动（不停止无法再次开启）
                      // successNum = 0; //重置为0，进入成功界面时确保为0
                      objAnimBite.setProperty(hmUI.prop.VISIBLE, false);//隐藏上钩动画
                      objAnimBite.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.STOP);//停止上钩动画（上钩动画为重复播放）
                      random();
                    }));
                  }),
                  {});
              }

              if (!clockTimer) {
                clockTimer = timer.createTimer(  //延时展示引导点击动画，在鱼咬钩动画执行3秒后未点击屏幕，执行该动画，点击屏幕则不执行
                  6000, 6000, (function (option) {
                    timer.stopTimer(clockTimer);
                    clockTimer = null;
                    if (flag) {
                      animClick();
                    }

                  })
                  , {});
              }

            }
            function animClick() {//引导点击函数
              vibrate.stop();
              // successNum = 0; //重置为0，进入成功界面时确保为0
              objAnimClick.setProperty(hmUI.prop.VISIBLE, true);//显示引导点击动画控件
              objAnimClick.setProperty(hmUI.prop.MORE, { //设置引导点击动画控件属性 重复播放
                x: rem(143),
                y: rem(220),
                anim_path: strRootPath + "bg/click",
                anim_prefix: "anim",
                anim_ext: "png",
                anim_fps: 24,
                anim_size: 49,
                anim_repeat: true,
                repeat_count: 1,
                anim_status: 1,
                // default_frame_index: 10,
              });
              objAnimClick.addEventListener(hmUI.event.CLICK_UP, (function (info) {  //引导动画点击事件

                objAnimBite.setProperty(hmUI.prop.VISIBLE, false); //隐藏上钩动画
                objAnimClick.setProperty(hmUI.prop.VISIBLE, false); //隐藏引导点击动画
                objAnimBite.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.STOP);//停止上钩动画
                objAnimClick.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.STOP);//停止引导点击动画
                random();
              }));
            }
            function random() { //随机函数
              vibrate.stop();
              if (randomNum(0, 9) < 4) {
                failAnim.setProperty(hmUI.prop.VISIBLE, false);
                fnAnimRetractor();
              } else {
                failAnim.setProperty(hmUI.prop.VISIBLE, true);
                failBg.setProperty(hmUI.prop.VISIBLE, true);
                failAnim.setProperty(hmUI.prop.MORE, { //空钩动画
                  x: 0,
                  y: 0,
                  anim_path: strRootPath + "bg/fail",
                  anim_prefix: "anim",
                  anim_ext: "png",
                  anim_fps: 24,
                  anim_size: 30,
                  anim_repeat: false,
                  repeat_count: 1,
                  anim_status: 1,
                  // default_frame_index: 24,
                  anim_complete_call: fnFail, //鱼脱钩动画
                });
              }
            }
            function failHide() { //失败界面需要隐藏的  按钮 背景 动画
              vibrate.stop();
              btnRes.setProperty(hmUI.prop.VISIBLE, false);
              btnResBg.setProperty(hmUI.prop.VISIBLE, false);
              btnStopBg.setProperty(hmUI.prop.VISIBLE, false);
              btnStop.setProperty(hmUI.prop.VISIBLE, false);
              failBg.setProperty(hmUI.prop.VISIBLE, false);
              failAnim.setProperty(hmUI.prop.VISIBLE, false);
            }
            function fnFail() {  // 失败动画
              btnStop.addEventListener(hmUI.event.CLICK_UP, (function (info) { //不玩了
                failHide();
                btn.setProperty(hmUI.prop.VISIBLE, true);
                btnPlay.setProperty(hmUI.prop.VISIBLE, true);
                animFishing.setProperty(hmUI.prop.VISIBLE, true);
                animFishing.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.START);
                hmSetting.setBrightScreenCancel(); //取消屏幕常亮
                // flag = true;

              }));
              btnRes.addEventListener(hmUI.event.CLICK_UP, (function (info) {
                failHide();
                objAnimThrow.setProperty(hmUI.prop.VISIBLE, true);
                objAnimThrow.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.START);

              }));
              btnResBg.setProperty(hmUI.prop.VISIBLE, true);
              btnRes.setProperty(hmUI.prop.VISIBLE, true);
              btnStopBg.setProperty(hmUI.prop.VISIBLE, true);
              btnStop.setProperty(hmUI.prop.VISIBLE, true);
            }
            function fnAnimRetractor() { //最后完成界面-成功钓到鱼界面
              vibrate.stop();
              successNum = 0; //重置为0，进入成功界面时确保为0
              fillBg.setProperty(hmUI.prop.VISIBLE, true);
              bgLight.setProperty(hmUI.prop.VISIBLE, true);
              animRetractor.setProperty(hmUI.prop.VISIBLE, true);
              fillBg.setProperty(hmUI.prop.MORE, objFillBg);
              bgLight.setProperty(hmUI.prop.MORE, objbgLight);
              animRetractor.setProperty(hmUI.prop.MORE, {
                x: 0,
                y: 0,
                anim_path: strRootPath + "bg/retractor",
                anim_prefix: "a",
                anim_ext: "png",
                anim_fps: 24,
                anim_size: 49,
                anim_repeat: false,
                repeat_count: 1,
                anim_status: 1,
                // default_frame_index: 23,
                // anim_complete_call: startVibrate,
                anim_complete_call: fnNum,
              });
            }
            function groupHide() {//成功界面隐藏   停止按钮  重新开始按钮 随机数字 黑背景  光环图 上钩动画
              vibrate.stop();
              btnRes.setProperty(hmUI.prop.VISIBLE, false);
              btnResBg.setProperty(hmUI.prop.VISIBLE, false);
              btnStopBg.setProperty(hmUI.prop.VISIBLE, false);
              btnStop.setProperty(hmUI.prop.VISIBLE, false);
              mathNum.setProperty(hmUI.prop.VISIBLE, false);
              animRetractor.setProperty(hmUI.prop.VISIBLE, false);
              bgLight.setProperty(hmUI.prop.VISIBLE, false);
              fillBg.setProperty(hmUI.prop.VISIBLE, false);
              // objAnimBite.setProperty(hmUI.prop.VISIBLE, false);
            }

            // function startVibrate() {
            //   successNum++
            //   if (successNum == 1) {
            //     // hmUI.showToast({
            //     //   text: `成功界面`
            //     // });
            //     vibrate.start();//震动
            //     fnNum()
            //   }
            // }
            function fnNum() {
              successNum++;
              if (successNum == 1) { //进入说明第一次调用此函数
                // hmUI.showToast({
                //   text: `成功界面`
                // });
                vibrate.start();//震动
              }
              mathNum.setProperty(hmUI.prop.VISIBLE, true);
              mathNum.setProperty(hmUI.prop.MORE, {
                x: 0,
                y: rem(200),
                w: rem(466),
                text: Math.ceil(Math.random() * 1000) * Math.ceil(Math.random() * 10),
                font_array: arrFish,
                h_space: 2,
                align_h: hmUI.align.CENTER_H,
                unit_sc: strRootPath + "fishlength/unit.png",
                unit_tc: strRootPath + "fishlength/unit.png",
                unit_en: strRootPath + "fishlength/unit.png",
              });
              if (!clockTimer11) {
                clockTimer11 = timer.createTimer(
                  1500, 1000, (function (option) {
                    timer.stopTimer(clockTimer11);
                    clockTimer11 = null;
                    vibrate.stop();
                    // hmUI.showToast({
                    //   text: `震动已停止`
                    // });
                    btnStop.addEventListener(hmUI.event.CLICK_UP, (function (info) {
                      groupHide();
                      //----------------------------从头开始-------------------------
                      btn.setProperty(hmUI.prop.VISIBLE, true);
                      btnPlay.setProperty(hmUI.prop.VISIBLE, true);
                      animFishing.setProperty(hmUI.prop.VISIBLE, true);
                      animFishing.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.START);
                      hmSetting.setBrightScreenCancel(); //取消屏幕常亮
                      // flag = true;
                    }));
                    btnRes.addEventListener(hmUI.event.CLICK_UP, (function (info) {
                      groupHide();
                      //----------------------------甩杆开始-------------------------
                      objAnimThrow.setProperty(hmUI.prop.VISIBLE, true);
                      objAnimThrow.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.START);
                      // flag = true;
                    }));
                    btnResBg.setProperty(hmUI.prop.VISIBLE, true);
                    btnRes.setProperty(hmUI.prop.VISIBLE, true);
                    btnStopBg.setProperty(hmUI.prop.VISIBLE, true);
                    btnStop.setProperty(hmUI.prop.VISIBLE, true);
                  })
                  , {});
              }

            }
            arc.setProperty(hmUI.prop.VISIBLE, false);
          } else {
            status = `省电模式`;
            if (status == nextStatus) {
              return;
            }
            nextStatus = status;
            vibrate.stop();
            if (animFishing) {
              hmSetting.setBrightScreenCancel();
              hmUI.deleteWidget(animFishing);
              hmUI.deleteWidget(btn);
              hmUI.deleteWidget(btnPlay);
              hmUI.deleteWidget(animCreate);
              hmUI.deleteWidget(objAnimThrow);
              hmUI.deleteWidget(objAnimBite);
              hmUI.deleteWidget(failBg);
              hmUI.deleteWidget(failAnim);
              hmUI.deleteWidget(objAnimClick);
              hmUI.deleteWidget(fillBg);
              hmUI.deleteWidget(bgLight);
              hmUI.deleteWidget(animRetractor);
              hmUI.deleteWidget(mathNum);
              hmUI.deleteWidget(btnResBg);
              hmUI.deleteWidget(btnRes);
              hmUI.deleteWidget(btnStopBg);
              hmUI.deleteWidget(btnStop);
              animFishing = null;
              btn = null;
              btnPlay = null;
              animCreate = null;
              objAnimThrow = null;
              objAnimBite = null;
              failBg = null;
              failAnim = null;
              objAnimClick = null;
              fillBg = null;
              bgLight = null;
              animRetractor = null;
              mathNum = null;
              btnResBg = null;
              btnRes = null;
              btnStopBg = null;
              btnStop = null;
            }
            if (clockTimer1) {
              timer.stopTimer(clockTimer1);
              clockTimer1 = null;
            }
            if (clockTimer) {
              timer.stopTimer(clockTimer);
              clockTimer = null;
            }
            if (clockTimer11) {
              timer.stopTimer(clockTimer11);
              clockTimer11 = null;
            }
            hmUI.redraw();

            powerBg.setProperty(hmUI.prop.VISIBLE, true);
            powerBg1.setProperty(hmUI.prop.VISIBLE, true);
            powerBg2.setProperty(hmUI.prop.VISIBLE, true);
            arc.setProperty(hmUI.prop.VISIBLE, true);
          }
        }



        getState();

        hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: (function () {
            console.log('ui resume');
            setBattery(battery);
            getState();

          }),
          pause_call: (function () {
            console.log('ui pause');
          }),
        });
        arc.addEventListener(hmUI.event.CLICK_DOWN, (info) => {
          hmUI.showToast({
            text: prompts
          });
        });

      },

      onInit() {
        console.log('index page.js on init invoke');
        this.init_view();
      },
      onReady() {
        console.log('index page.js on ready invoke');
      },
      onShow() {
        console.log('index page.js on show invoke');
      },
      onHide() {
        console.log('index page.js on hide invoke');
      },
      onDestroy() {
        vibrate.stop();
        if (clockTimer1) {
          timer.stopTimer(clockTimer1);
          clockTimer1 = null;
        }
        if (clockTimer) {
          timer.stopTimer(clockTimer);
          clockTimer = null;
        }
        if (clockTimer11) {
          timer.stopTimer(clockTimer11);
          clockTimer11 = null;
        }
        console.log('index page.js on destory invoke');
      },
    });
    /*
    * end js
    */
  })();
} catch (e) {
  console.log(e);
}