try {
  (() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__),
      "drink"
    );

    /*
     * huamiOS bundle tool v1.0.17
     * Copyright © Huami. All Rights Reserved
     * 数字时代 10024
     */
    ("use strict");

    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let rootPath = null;
    let weekArray = null;
    let data_yellow_Arr = null;
    let data_white_Arr = null;
    let hourArr = null;
    let minArr = null;
    let timeXp_arr = null;

    let img_bg = null;

    let timeTxt = null;

    let weekLevel = null;
    let day_img = null;
    let monthArr = null;
    let month_img = null;

    let text1 = null;
    let text2 = null;
    let text3 = null;
    let icon1 = null;
    let icon2 = null;
    let icon3 = null;
    let arc3 = null;

    let editGroup1 = null;
    let editGroup2 = null;
    let editGroup3 = null;
    let battery_rect = null;
    let img24 = null;
    let edit_list_config = {
      title_font_size :34 ,
      title_align_h: hmUI.align.CENTER_H ,
      list_item_vspace: 8 ,
      list_bg_color : 0x0000,
      list_bg_radius: 30,
      list_group_text_font_size: 32,
      list_group_text_align_h: hmUI.align.CENTER_H,
      list_tips_text_font_size: 32,
      list_tips_text_align_h : hmUI.align.LEFT,
    };
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        rootPath = "images/";
        weekArray = [
          rootPath + "week/1.png",
          rootPath + "week/2.png",
          rootPath + "week/3.png",
          rootPath + "week/4.png",
          rootPath + "week/5.png",
          rootPath + "week/6.png",
          rootPath + "week/7.png",
        ];
        monthArr = [
          rootPath + "month/1.png",
          rootPath + "month/2.png",
          rootPath + "month/3.png",
          rootPath + "month/4.png",
          rootPath + "month/5.png",
          rootPath + "month/6.png",
          rootPath + "month/7.png",
          rootPath + "month/8.png",
          rootPath + "month/9.png",
          rootPath + "month/10.png",
          rootPath + "month/11.png",
          rootPath + "month/12.png",
        ];
        data_white_Arr = [
          rootPath + "data_white/0.png",
          rootPath + "data_white/1.png",
          rootPath + "data_white/2.png",
          rootPath + "data_white/3.png",
          rootPath + "data_white/4.png",
          rootPath + "data_white/5.png",
          rootPath + "data_white/6.png",
          rootPath + "data_white/7.png",
          rootPath + "data_white/8.png",
          rootPath + "data_white/9.png",
        ];
        data_yellow_Arr = [
          rootPath + "data_yellow/0.png",
          rootPath + "data_yellow/1.png",
          rootPath + "data_yellow/2.png",
          rootPath + "data_yellow/3.png",
          rootPath + "data_yellow/4.png",
          rootPath + "data_yellow/5.png",
          rootPath + "data_yellow/6.png",
          rootPath + "data_yellow/7.png",
          rootPath + "data_yellow/8.png",
          rootPath + "data_yellow/9.png",
        ];
        hourArr = [
          rootPath + "hour/0.png",
          rootPath + "hour/1.png",
          rootPath + "hour/2.png",
          rootPath + "hour/3.png",
          rootPath + "hour/4.png",
          rootPath + "hour/5.png",
          rootPath + "hour/6.png",
          rootPath + "hour/7.png",
          rootPath + "hour/8.png",
          rootPath + "hour/9.png",
        ];
        minArr = [
          rootPath + "min/0.png",
          rootPath + "min/1.png",
          rootPath + "min/2.png",
          rootPath + "min/3.png",
          rootPath + "min/4.png",
          rootPath + "min/5.png",
          rootPath + "min/6.png",
          rootPath + "min/7.png",
          rootPath + "min/8.png",
          rootPath + "min/9.png",
        ];
        timeXp_arr = [
          rootPath + "time_xp/1.png",
          rootPath + "time_xp/2.png",
          rootPath + "time_xp/3.png",
          rootPath + "time_xp/4.png",
          rootPath + "time_xp/5.png",
          rootPath + "time_xp/6.png",
          rootPath + "time_xp/7.png",
          rootPath + "time_xp/8.png",
          rootPath + "time_xp/9.png",
          rootPath + "time_xp/10.png",
        ];
        img_bg = hmUI.createWidget(hmUI.widget.IMG, {
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD,
        });

        var screenType = hmSetting.getScreenType();

        if (screenType == hmSetting.screen_type.AOD) {
          img_bg.setProperty(hmUI.prop.MORE, {
            x: 0,
            y: 0,
            w: 454,
            h: 454,
            src: rootPath + "img/bg_xp.png",
            show_level: hmUI.show_level.ONAL_AOD,
          });
          timeTxt = hmUI.createWidget(hmUI.widget.IMG_TIME, {
            hour_zero: 1,
            hour_startX: 123,
            hour_startY: 159,
            hour_array: timeXp_arr,
            hour_space: 0,

            hour_align: hmUI.align.LEFT,
            minute_zero: 1, //是否补零 1为补零
            minute_startX: 123,
            minute_startY: 281,
            minute_array: timeXp_arr,
            minute_space: 0, //两个图片间隔 对应GT2的interval
            minute_follow: 0, //是否跟随
            minute_align: hmUI.align.LEFT,

            am_x: 124,
            am_y: 97,
            am_sc_path: rootPath + "img/am.png",
            am_en_path: rootPath + "img/am.png",
            pm_x: 124,
            pm_y: 97,
            pm_sc_path: rootPath + "img/pm.png",
            pm_en_path: rootPath + "img/pm.png",
            show_level: hmUI.show_level.ONAL_AOD,
          });
        } else if (screenType == hmSetting.screen_type.WATCHFACE) {

          img_bg.setProperty(hmUI.prop.MORE, {
            x: 0,
            y: 0,
            w: 454,
            h: 454,
            src: rootPath + "img/bg.png",
            show_level: hmUI.show_level.ONLY_NORMAL,
          });

          weekLevel = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
            x: 255,
            y: 405,
            week_sc: weekArray,
            week_tc: weekArray,
            week_en: weekArray,
            show_level: hmUI.show_level.ONLY_NORMAL,
          });

          day_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
            day_startX: 212,
            day_startY: 405,
            day_en_array: data_white_Arr,
            day_sc_array: data_white_Arr,
            day_tc_array: data_white_Arr,
            day_space: 0,
            day_zero: 1,
            day_align: hmUI.align.LEFT,
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
            month_startX: 142 - 4,
            month_startY: 405,
            month_en_array: monthArr,
            month_sc_array: monthArr,
            month_tc_array: monthArr,
            month_space: 0,
            month_zero: 0,
            month_is_character: true,
            month_align: hmUI.align.LEFT,
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          timeTxt = hmUI.createWidget(hmUI.widget.IMG_TIME, {
            hour_zero: 1,
            hour_startX: 123,
            hour_startY: 154,
            hour_array: hourArr,
            hour_space: 0,
            hour_align: hmUI.align.LEFT,
            minute_zero: 1, //是否补零 1为补零
            minute_startX: 123,
            minute_startY: 276,
            minute_array: minArr,
            minute_space: 0, //两个图片间隔 对应GT2的interval
            minute_follow: 0, //是否跟随
            minute_align: hmUI.align.LEFT,

            am_x: 124,
            am_y: 97,
            am_sc_path: rootPath + "img/am.png",
            am_en_path: rootPath + "img/am.png",
            pm_x: 124,
            pm_y: 97,
            pm_sc_path: rootPath + "img/pm.png",
            pm_en_path: rootPath + "img/pm.png",
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          let clockStatus = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
            x: 140,
            y: 31,
            type: hmUI.system_status.CLOCK,
            src: rootPath + "img/clock.png",
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          let disturbStatus = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
            x: 209,
            y: 31,
            type: hmUI.system_status.DISTURB,
            src: rootPath + "img/disturb.png",
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          //DISCONNECT
          let blueToothStatus = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
            x: 276,
            y: 31,
            type: hmUI.system_status.DISCONNECT,
            src: rootPath + "img/blueTooth.png",
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          let bgGray1 = hmUI.createWidget(hmUI.widget.IMG, {
            x: 288,
            y: 104,
            w: 50,
            h: 50,
            src: rootPath + "mask/unselected1.png",
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          let bgGray2 = hmUI.createWidget(hmUI.widget.IMG, {
            x: 288,
            y: 162,
            w: 50,
            h: 50,
            src: rootPath + "mask/unselected1.png",
            show_level: hmUI.show_level.ONLY_NORMAL,
          });

          batteryTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
            x: 32,
            y: 222,
            type: hmUI.data_type.BATTERY,
            font_array: data_white_Arr,
            h_space: 0, //图片间隔
            align_h: hmUI.align.CENTER_H,
            invalid_image: rootPath + "img/invalid.png",
            padding: false, //是否补零 true为补零
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          let objBatteryBtn = hmUI.createWidget(hmUI.widget.IMG_CLICK,{
            x: 28,
            y: 196,
            w: 60,
            h: 96,
            type:hmUI.data_type.BATTERY, //必写 跳转的action
            });

          //--------------------------------
          // let ceshitest = hmUI.createWidget(hmUI.widget.TEXT)
          //--------------------------------
          //监听传感器事件  电量柱状图绘制
          let battery = hmSensor.createSensor(hmSensor.id.BATTERY);
          battery_rect = hmUI.createWidget(hmUI.widget.FILL_RECT, {
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          function setBattery(battery){
            let batteryCurrent = battery.current;

            let batHeight = 278 * (batteryCurrent / 100);
            let batY = 277 - batHeight + 100;
            battery_rect.setProperty(hmUI.prop.MORE, {
              x: 92,
              y: batY,
              w: 7,
              h: batHeight,
              color: 0xffc022,
              radius: 2,
            });

          }
          setBattery(battery)

          //log传感器属性
          battery.addEventListener(hmSensor.event.CHANGE, function () {
            setBattery(battery)
          });
          hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
            resume_call: (function () {
              setBattery(battery)
                console.log('ui resume');
            }),
            pause_call: (function () {
                console.log('ui pause');
            }),
        });

        }

        text1 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        icon1 = hmUI.createWidget(hmUI.widget.IMG, {
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        text2 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        icon2 = hmUI.createWidget(hmUI.widget.IMG, {
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        text3 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        icon3 = hmUI.createWidget(hmUI.widget.IMG, {
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        arc3 = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        var editGroupX1 = 290;
        var editGroupY1 = 104;
        editGroup1 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 101,
          x: editGroupX1,
          y: editGroupY1,
          w: 48,
          h: 48,
          select_image: rootPath + "mask/selected1.png",
          un_select_image: rootPath + "mask/unselected1.png",
          default_type: hmUI.edit_type.HEART,
          optional_types: [
            {
              type: hmUI.edit_type.BATTERY,
              preview: rootPath + "icon_white/battery.png",
            },
            {
              type: hmUI.edit_type.CAL,
              preview: rootPath + "icon_white/cal.png",
            },
            {
              type: hmUI.edit_type.DISTANCE,
              preview: rootPath + "icon_white/distance.png",
            },
            {
              type: hmUI.edit_type.HEART,
              preview: rootPath + "icon_white/heart.png",
            },
            {
              type: hmUI.edit_type.HUMIDITY,
              preview: rootPath + "icon_white/humi.png",
            },
            {
              type: hmUI.edit_type.PAI_WEEKLY,
              preview: rootPath + "icon_white/pai.png",
            },
            {
              type: hmUI.edit_type.SPO2,
              preview: rootPath + "icon_white/spo2.png",
            },
            {
              type: hmUI.edit_type.STEP,
              preview: rootPath + "icon_white/step.png",
            },
            {
              type: hmUI.edit_type.UVI,
              preview: rootPath + "icon_white/uvi.png",
            },
            {
              type: hmUI.edit_type.WIND,
              preview: rootPath + "icon_white/wind.png",
            },
          ],
          count: 10,
          tips_BG: rootPath + "mask/text_tag.png",
          tips_x: - 122,
          tips_y: 291,
          tips_width: 104,
          tips_margin: 10,
          select_list: edit_list_config,
        });
        //通过这个函数来获取当前的保存的数据项类型来绘制组件
        var type1 = editGroup1.getProperty(hmUI.prop.CURRENT_TYPE);
        let  ObjTop = {}
        switch (type1) {
          case hmUI.edit_type.PAI_WEEKLY:
            ObjTop.type = hmUI.data_type.PAI_WEEKLY,
            icon1.setProperty(hmUI.prop.MORE, {
              x: editGroupX1,
              y: editGroupY1,
              w: 50,
              h: 50,
              src: rootPath + "icon_white/pai.png",
            });
            text1.setProperty(hmUI.prop.MORE, {
              x: 345,
              y: 113,
              type: hmUI.data_type.PAI_WEEKLY,
              font_array: data_white_Arr,
              h_space: 0, //图片间隔
              align_h: hmUI.align.LEFT,
              padding: false, //是否补零 true为补零
              // invalid_image: rootPath + "img/invalid.png",//单位
            });
            break;
          case hmUI.edit_type.CAL:
            ObjTop.type = hmUI.data_type.CAL,
            icon1.setProperty(hmUI.prop.MORE, {
              x: editGroupX1,
              y: editGroupY1,
              w: 50,
              h: 50,
              src: rootPath + "icon_white/cal.png",
            });
            text1.setProperty(hmUI.prop.MORE, {
              x: 345,
              y: 113,
              type: hmUI.data_type.CAL,
              font_array: data_white_Arr,
              h_space: 0, //图片间隔
              align_h: hmUI.align.LEFT,
              padding: false, //是否补零 true为补零
              //invalid_image: rootPath + "img/invalid.png",//单位
            });
            break;
          case hmUI.edit_type.BATTERY:
            ObjTop.type = hmUI.data_type.BATTERY,
            icon1.setProperty(hmUI.prop.MORE, {
              x: editGroupX1,
              y: editGroupY1,
              w: 50,
              h: 50,
              src: rootPath + "icon_white/battery.png",
            });
            text1.setProperty(hmUI.prop.MORE, {
              x: 345,
              y: 113,
              type: hmUI.data_type.BATTERY,
              font_array: data_white_Arr,
              h_space: 0, //图片间隔
              align_h: hmUI.align.LEFT,
              padding: false, //是否补零 true为补零
              invalid_image: rootPath + "img/invalid.png", //单位
              unit_sc: rootPath + "img/per.png", //单位
              unit_tc: rootPath + "img/per.png", //单位
              unit_en: rootPath + "img/per.png", //单位
            });
            break;
          case hmUI.edit_type.HEART:
            ObjTop.type = hmUI.data_type.HEART,
            icon1.setProperty(hmUI.prop.MORE, {
              x: editGroupX1,
              y: editGroupY1,
              w: 50,
              h: 50,
              src: rootPath + "icon_white/heart.png",
            });
            text1.setProperty(hmUI.prop.MORE, {
              x: 345,
              y: 113,
              type: hmUI.data_type.HEART,
              font_array: data_white_Arr,
              h_space: 0, //图片间隔
              align_h: hmUI.align.LEFT,
              padding: false, //是否补零 true为补零
              invalid_image: rootPath + "img/invalid.png", //单位
            });
            break;
          case hmUI.edit_type.STEP:
            ObjTop.type = hmUI.data_type.STEP,
            icon1.setProperty(hmUI.prop.MORE, {
              x: editGroupX1,
              y: editGroupY1,
              w: 50,
              h: 50,
              src: rootPath + "icon_white/step.png",
            });
            text1.setProperty(hmUI.prop.MORE, {
              x: 345,
              y: 113,
              type: hmUI.data_type.STEP,
              font_array: data_white_Arr,
              h_space: 0, //图片间隔
              align_h: hmUI.align.LEFT,
              padding: false, //是否补零 true为补零
              //invalid_image: rootPath + "img/invalid.png",//单位
            });
            break;
          case hmUI.edit_type.DISTANCE:
            ObjTop.type = hmUI.data_type.DISTANCE,
            icon1.setProperty(hmUI.prop.MORE, {
              x: editGroupX1,
              y: editGroupY1,
              w: 50,
              h: 50,
              src: rootPath + "icon_white/distance.png",
            });
            text1.setProperty(hmUI.prop.MORE, {
              x: 345,
              y: 113,
              type: hmUI.data_type.DISTANCE,
              font_array: data_white_Arr,
              h_space: 0, //图片间隔
              align_h: hmUI.align.LEFT,
              padding: false, //是否补零 true为补零
              invalid_image: rootPath + "img/invalid.png", //单位
              dot_image: rootPath + "img/dot.png", //小数点图片
            });
            break;
          case hmUI.edit_type.FAT_BURNING:
            ObjTop.type = hmUI.data_type.FAT_BURNING,
            icon1.setProperty(hmUI.prop.MORE, {
              x: editGroupX1,
              y: editGroupY1,
              w: 50,
              h: 50,
              src: rootPath + "icon_white/fat.png",
            });
            text1.setProperty(hmUI.prop.MORE, {
              x: 345,
              y: 113,
              type: hmUI.data_type.FAT_BURNING,
              font_array: data_white_Arr,
              h_space: 0, //图片间隔
              align_h: hmUI.align.LEFT,
              padding: false, //是否补零 true为补零
              invalid_image: rootPath + "img/invalid.png", //单位
            });
            break;
          case hmUI.edit_type.HUMIDITY:
            ObjTop.type = hmUI.data_type.HUMIDITY,
            icon1.setProperty(hmUI.prop.MORE, {
              x: editGroupX1,
              y: editGroupY1,
              w: 50,
              h: 50,
              src: rootPath + "icon_white/humi.png",
            });
            text1.setProperty(hmUI.prop.MORE, {
              x: 345,
              y: 113,
              type: hmUI.data_type.HUMIDITY,
              font_array: data_white_Arr,
              h_space: 0, //图片间隔
              align_h: hmUI.align.LEFT,
              padding: false, //是否补零 true为补零
              invalid_image: rootPath + "img/invalid.png", //单位
              unit_sc: rootPath + "img/per.png", //单位
              unit_tc: rootPath + "img/per.png", //单位
              unit_en: rootPath + "img/per.png", //单位
            });
            break;
          case hmUI.edit_type.SPO2:
            ObjTop.type = hmUI.data_type.SPO2,
            icon1.setProperty(hmUI.prop.MORE, {
              x: editGroupX1,
              y: editGroupY1,
              w: 50,
              h: 50,
              src: rootPath + "icon_white/spo2.png",
            });
            text1.setProperty(hmUI.prop.MORE, {
              x: 345,
              y: 113,
              type: hmUI.data_type.SPO2,
              font_array: data_white_Arr,
              h_space: 0, //图片间隔
              align_h: hmUI.align.LEFT,
              padding: false, //是否补零 true为补零
              invalid_image: rootPath + "img/invalid.png", //单位
              unit_sc: rootPath + "img/per.png", //单位
              unit_tc: rootPath + "img/per.png", //单位
              unit_en: rootPath + "img/per.png", //单位
            });
            break;
          case hmUI.edit_type.STAND:
            ObjTop.type = hmUI.data_type.STAND,
            icon1.setProperty(hmUI.prop.MORE, {
              x: editGroupX1,
              y: editGroupY1,
              w: 50,
              h: 50,
              src: rootPath + "icon_white/stand.png",
            });
            text1.setProperty(hmUI.prop.MORE, {
              x: 345,
              y: 113,
              type: hmUI.data_type.STAND,
              font_array: data_white_Arr,
              h_space: 0, //图片间隔
              align_h: hmUI.align.LEFT,
              padding: false, //是否补零 true为补零
              //invalid_image: rootPath + "img/invalid.png",//单位
            });
            break;
          case hmUI.edit_type.UVI:
            ObjTop.type = hmUI.data_type.UVI,
            icon1.setProperty(hmUI.prop.MORE, {
              x: editGroupX1,
              y: editGroupY1,
              w: 50,
              h: 50,
              src: rootPath + "icon_white/uvi.png",
            });
            text1.setProperty(hmUI.prop.MORE, {
              x: 345,
              y: 113,
              type: hmUI.data_type.UVI,
              font_array: data_white_Arr,
              h_space: 0, //图片间隔
              align_h: hmUI.align.LEFT,
              padding: false, //是否补零 true为补零
              invalid_image: rootPath + "img/invalid.png", //单位
            });
            break;
          case hmUI.edit_type.WIND:
            ObjTop.type = hmUI.data_type.WIND,
            icon1.setProperty(hmUI.prop.MORE, {
              x: editGroupX1,
              y: editGroupY1,
              w: 50,
              h: 50,
              src: rootPath + "icon_white/wind.png",
            });
            text1.setProperty(hmUI.prop.MORE, {
              x: 345,
              y: 113,
              type: hmUI.data_type.WIND,
              font_array: data_white_Arr,
              h_space: 0, //图片间隔
              align_h: hmUI.align.LEFT,
              padding: false, //是否补零 true为补零
              invalid_image: rootPath + "img/invalid.png", //单位
            });
            break;
        }

        //2222222222-------------------/*  */-------
        var editGroupX2 = 290;
        var editGroupY2 = 163;
        editGroup2 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 102,
          x: editGroupX2,
          y: editGroupY2,
          w: 48,
          h: 48,
          select_image: rootPath + "mask/selected1.png",
          un_select_image: rootPath + "mask/unselected1.png",
          default_type: hmUI.edit_type.STEP,
          optional_types: [
            // { type: hmUI.edit_type.AQI, preview: rootPath + "icon_white/aqi.png" },
            {
              type: hmUI.edit_type.BATTERY,
              preview: rootPath + "icon_white/battery.png",
            },
            {
              type: hmUI.edit_type.CAL,
              preview: rootPath + "icon_white/cal.png",
            },
            {
              type: hmUI.edit_type.DISTANCE,
              preview: rootPath + "icon_white/distance.png",
            },
            {
              type: hmUI.edit_type.HEART,
              preview: rootPath + "icon_white/heart.png",
            },
            {
              type: hmUI.edit_type.HUMIDITY,
              preview: rootPath + "icon_white/humi.png",
            },
            {
              type: hmUI.edit_type.PAI_WEEKLY,
              preview: rootPath + "icon_white/pai.png",
            },
            {
              type: hmUI.edit_type.SPO2,
              preview: rootPath + "icon_white/spo2.png",
            },
            {
              type: hmUI.edit_type.STEP,
              preview: rootPath + "icon_white/step.png",
            },
            {
              type: hmUI.edit_type.UVI,
              preview: rootPath + "icon_white/uvi.png",
            },
            {
              type: hmUI.edit_type.WIND,
              preview: rootPath + "icon_white/wind.png",
            },
          ],
          count: 10,
          tips_BG: rootPath + "mask/text_tag.png",
          tips_x: -122,
          tips_y: 232,
          tips_width: 104,
          tips_margin: 10,
          select_list: edit_list_config,
        });
        //通过这个函数来获取当前的保存的数据项类型来绘制组件
        var type2 = editGroup2.getProperty(hmUI.prop.CURRENT_TYPE);
        let objCenter = {}
        switch (type2) {
          case hmUI.edit_type.PAI_WEEKLY:
            objCenter.type = hmUI.data_type.PAI_WEEKLY
            icon2.setProperty(hmUI.prop.MORE, {
              x: editGroupX2,
              y: editGroupY2,
              w: 50,
              h: 50,
              src: rootPath + "icon_white/pai.png",
            });
            text2.setProperty(hmUI.prop.MORE, {
              x: 345,
              y: 170,
              type: hmUI.data_type.PAI_WEEKLY,
              font_array: data_white_Arr,
              h_space: 0, //图片间隔
              align_h: hmUI.align.LEFT,
              padding: false, //是否补零 true为补零
              // invalid_image: rootPath + "img/invalid.png",//单位
            });
            break;
          case hmUI.edit_type.CAL:
            objCenter.type = hmUI.data_type.CAL
            icon2.setProperty(hmUI.prop.MORE, {
              x: editGroupX2,
              y: editGroupY2,
              w: 50,
              h: 50,
              src: rootPath + "icon_white/cal.png",
            });
            text2.setProperty(hmUI.prop.MORE, {
              x: 345,
              y: 170,
              type: hmUI.data_type.CAL,
              font_array: data_white_Arr,
              h_space: 0, //图片间隔
              align_h: hmUI.align.LEFT,
              padding: false, //是否补零 true为补零
              //invalid_image: rootPath + "img/invalid.png",//单位
            });
            break;
          case hmUI.edit_type.BATTERY:
            objCenter.type = hmUI.data_type.BATTERY
            icon2.setProperty(hmUI.prop.MORE, {
              x: editGroupX2,
              y: editGroupY2,
              w: 50,
              h: 50,
              src: rootPath + "icon_white/battery.png",
            });
            text2.setProperty(hmUI.prop.MORE, {
              x: 365,
              y: 177,
              type: hmUI.data_type.BATTERY,
              font_array: data_white_Arr,
              h_space: 0, //图片间隔
              align_h: hmUI.align.LEFT,
              padding: false, //是否补零 true为补零
              invalid_image: rootPath + "img/invalid.png", //单位
              unit_sc: rootPath + "img/per.png", //单位
              unit_tc: rootPath + "img/per.png", //单位
              unit_en: rootPath + "img/per.png", //单位
            });
            break;
          case hmUI.edit_type.HEART:
            objCenter.type = hmUI.data_type.HEART
            icon2.setProperty(hmUI.prop.MORE, {
              x: editGroupX2,
              y: editGroupY2,
              w: 50,
              h: 50,
              src: rootPath + "icon_white/heart.png",
            });
            text2.setProperty(hmUI.prop.MORE, {
              x: 345,
              y: 170,
              type: hmUI.data_type.HEART,
              font_array: data_white_Arr,
              h_space: 0, //图片间隔
              align_h: hmUI.align.LEFT,
              padding: false, //是否补零 true为补零
              invalid_image: rootPath + "img/invalid.png", //单位
            });
            break;
          case hmUI.edit_type.STEP:
            objCenter.type = hmUI.data_type.STEP
            icon2.setProperty(hmUI.prop.MORE, {
              x: editGroupX2,
              y: editGroupY2,
              w: 50,
              h: 50,
              src: rootPath + "icon_white/step.png",
            });
            text2.setProperty(hmUI.prop.MORE, {
              x: 345,
              y: 170,
              type: hmUI.data_type.STEP,
              font_array: data_white_Arr,
              h_space: 0, //图片间隔
              align_h: hmUI.align.LEFT,
              padding: false, //是否补零 true为补零
              //invalid_image: rootPath + "img/invalid.png",//单位
            });
            break;
          case hmUI.edit_type.DISTANCE:
            objCenter.type = hmUI.data_type.DISTANCE
            icon2.setProperty(hmUI.prop.MORE, {
              x: editGroupX2,
              y: editGroupY2,
              w: 50,
              h: 50,
              src: rootPath + "icon_white/distance.png",
            });
            text2.setProperty(hmUI.prop.MORE, {
              x: 345,
              y: 170,
              type: hmUI.data_type.DISTANCE,
              font_array: data_white_Arr,
              h_space: 0, //图片间隔
              align_h: hmUI.align.LEFT,
              padding: false, //是否补零 true为补零
              invalid_image: rootPath + "img/invalid.png", //单位
              dot_image: rootPath + "img/dot.png", //小数点图片
            });
            break;
          case hmUI.edit_type.FAT_BURNING:
            objCenter.type = hmUI.data_type.FAT_BURNING
            icon2.setProperty(hmUI.prop.MORE, {
              x: editGroupX2,
              y: editGroupY2,
              w: 50,
              h: 50,
              src: rootPath + "icon_white/fat.png",
            });
            text2.setProperty(hmUI.prop.MORE, {
              x: 345,
              y: 170,
              type: hmUI.data_type.FAT_BURNING,
              font_array: data_white_Arr,
              h_space: 0, //图片间隔
              align_h: hmUI.align.LEFT,
              padding: false, //是否补零 true为补零
              invalid_image: rootPath + "img/invalid.png", //单位
            });
            break;
          case hmUI.edit_type.HUMIDITY:
            objCenter.type = hmUI.data_type.HUMIDITY
            icon2.setProperty(hmUI.prop.MORE, {
              x: editGroupX2,
              y: editGroupY2,
              w: 50,
              h: 50,
              src: rootPath + "icon_white/humi.png",
            });
            text2.setProperty(hmUI.prop.MORE, {
              x: 345,
              y: 170,
              type: hmUI.data_type.HUMIDITY,
              font_array: data_white_Arr,
              h_space: 0, //图片间隔
              align_h: hmUI.align.LEFT,
              padding: false, //是否补零 true为补零
              invalid_image: rootPath + "img/invalid.png", //单位
              unit_sc: rootPath + "img/per.png", //单位
              unit_tc: rootPath + "img/per.png", //单位
              unit_en: rootPath + "img/per.png", //单位
            });
            break;
          case hmUI.edit_type.SPO2:
            objCenter.type = hmUI.data_type.SPO2
            icon2.setProperty(hmUI.prop.MORE, {
              x: editGroupX2,
              y: editGroupY2,
              w: 50,
              h: 50,
              src: rootPath + "icon_white/spo2.png",
            });
            text2.setProperty(hmUI.prop.MORE, {
              x: 345,
              y: 170,
              type: hmUI.data_type.SPO2,
              font_array: data_white_Arr,
              h_space: 0, //图片间隔
              align_h: hmUI.align.LEFT,
              padding: false, //是否补零 true为补零
              invalid_image: rootPath + "img/invalid.png", //单位
              unit_sc: rootPath + "img/per.png", //单位
              unit_tc: rootPath + "img/per.png", //单位
              unit_en: rootPath + "img/per.png", //单位
            });
            break;
          case hmUI.edit_type.STAND:
            objCenter.type = hmUI.data_type.STAND
            icon2.setProperty(hmUI.prop.MORE, {
              x: editGroupX2,
              y: editGroupY2,
              w: 50,
              h: 50,
              src: rootPath + "icon_white/stand.png",
            });
            text2.setProperty(hmUI.prop.MORE, {
              x: 345,
              y: 170,
              type: hmUI.data_type.STAND,
              font_array: data_white_Arr,
              h_space: 0, //图片间隔
              align_h: hmUI.align.LEFT,
              padding: false, //是否补零 true为补零
              //invalid_image: rootPath + "img/invalid.png",//单位
            });
            break;
          case hmUI.edit_type.UVI:
            objCenter.type = hmUI.data_type.UVI
            icon2.setProperty(hmUI.prop.MORE, {
              x: editGroupX2,
              y: editGroupY2,
              w: 50,
              h: 50,
              src: rootPath + "icon_white/uvi.png",
            });
            text2.setProperty(hmUI.prop.MORE, {
              x: 345,
              y: 170,
              type: hmUI.data_type.UVI,
              font_array: data_white_Arr,
              h_space: 0, //图片间隔
              align_h: hmUI.align.LEFT,
              padding: false, //是否补零 true为补零
              invalid_image: rootPath + "img/invalid.png", //单位
            });
            break;
          case hmUI.edit_type.WIND:
            objCenter.type = hmUI.data_type.WIND
            icon2.setProperty(hmUI.prop.MORE, {
              x: editGroupX2,
              y: editGroupY2,
              w: 50,
              h: 50,
              src: rootPath + "icon_white/wind.png",
            });
            text2.setProperty(hmUI.prop.MORE, {
              x: 345,
              y: 170,
              type: hmUI.data_type.WIND,
              font_array: data_white_Arr,
              h_space: 0, //图片间隔
              align_h: hmUI.align.LEFT,
              padding: false, //是否补零 true为补零
              invalid_image: rootPath + "img/invalid.png", //单位
            });
            break;
        }

        //3333333333333333-----------------
        var editGroupX3 = 290;
        var editGroupY3 = 221;
        let objGroup3ArcPublic = {
          center_x: 342,
          center_y: 273,
          radius: 34,
          start_angle: 0,
          end_angle: 360,
          color: 0xffc022,
          line_width: 8,
        };
        let objGroup3TextPublic = {
          x: 267,
          y: 318,
          w: 150,
        };
        editGroup3 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 103,
          x: editGroupX3 - 3,
          y: editGroupY3 - 3,
          w: 110,
          h: 164,
          select_image: rootPath + "mask/selected2.png",
          un_select_image: rootPath + "mask/unselected2.png",
          default_type: hmUI.edit_type.CAL,
          optional_types: [
            {
              type: hmUI.edit_type.BATTERY,
              preview: rootPath + "preview_yellow/battery.png",
            },

            {
              type: hmUI.edit_type.CAL,
              preview: rootPath + "preview_yellow/cal.png",
            },

            {
              type: hmUI.edit_type.PAI_WEEKLY,
              preview: rootPath + "preview_yellow/pai.png",
            },

            {
              type: hmUI.edit_type.STEP,
              preview: rootPath + "preview_yellow/step.png",
            },

            {
              type: hmUI.edit_type.STAND,
              preview: rootPath + "preview_yellow/stand.png",
            },
          ],
          count: 5,
          tips_BG: rootPath + "mask/text_tag.png",
          tips_x: -119,
          tips_y: 177,
          tips_width: 104,
          tips_margin: 10,
          select_list: edit_list_config,
        });
        //通过这个函数来获取当前的保存的数据项类型来绘制组件
        var type3 = editGroup3.getProperty(hmUI.prop.CURRENT_TYPE);
       let objBottom = {}
        switch (type3) {
          case hmUI.edit_type.PAI_WEEKLY:
            objBottom.type = hmUI.data_type.PAI_WEEKLY
            arc3.setProperty(hmUI.prop.MORE, {
              ...objGroup3ArcPublic,
              type: hmUI.data_type.PAI_WEEKLY,
            });
            icon3.setProperty(hmUI.prop.MORE, {
              x: editGroupX3,
              y: editGroupY3,
              src: rootPath + "icon_yellow/pai.png",
            });
            text3.setProperty(hmUI.prop.MORE, {
              ...objGroup3TextPublic,
              type: hmUI.data_type.PAI_WEEKLY,
              font_array: data_yellow_Arr,
              h_space: 0, //图片间隔
              align_h: hmUI.align.CENTER_H,
              padding: false, //是否补零 true为补零
              // invalid_image: rootPath + "img/invalid.png",//单位
            });
            break;
          case hmUI.edit_type.CAL:
            objBottom.type = hmUI.data_type.CAL
            arc3.setProperty(hmUI.prop.MORE, {
              ...objGroup3ArcPublic,
              type: hmUI.data_type.CAL,
            });
            icon3.setProperty(hmUI.prop.MORE, {
              x: editGroupX3,
              y: editGroupY3,
              src: rootPath + "icon_yellow/cal.png",
            });
            text3.setProperty(hmUI.prop.MORE, {
              ...objGroup3TextPublic,
              type: hmUI.data_type.CAL,
              font_array: data_yellow_Arr,
              h_space: 0, //图片间隔
              align_h: hmUI.align.CENTER_H,
              padding: false, //是否补零 true为补零
              // invalid_image: rootPath + "img/invalid.png",//单位
            });
            break;
          case hmUI.edit_type.BATTERY:
            objBottom.type = hmUI.data_type.BATTERY
            arc3.setProperty(hmUI.prop.MORE, {
              ...objGroup3ArcPublic,
              type: hmUI.data_type.BATTERY,
            });
            icon3.setProperty(hmUI.prop.MORE, {
              x: editGroupX3,
              y: editGroupY3,
              src: rootPath + "icon_yellow/battery.png",
            });
            text3.setProperty(hmUI.prop.MORE, {
              ...objGroup3TextPublic,
              type: hmUI.data_type.BATTERY,
              font_array: data_yellow_Arr,
              h_space: 0, //图片间隔
              align_h: hmUI.align.CENTER_H,
              padding: false, //是否补零 true为补零
              unit_sc: rootPath + "img/14.png", //单位
              unit_tc: rootPath + "img/14.png", //单位
              unit_en: rootPath + "img/14.png", //单位
            });
            break;
          case hmUI.edit_type.STEP:
            objBottom.type = hmUI.data_type.STEP
            arc3.setProperty(hmUI.prop.MORE, {
              ...objGroup3ArcPublic,
              type: hmUI.data_type.STEP,
            });
            icon3.setProperty(hmUI.prop.MORE, {
              x: editGroupX3,
              y: editGroupY3,
              src: rootPath + "icon_yellow/step.png",
            });
            text3.setProperty(hmUI.prop.MORE, {
              ...objGroup3TextPublic,
              type: hmUI.data_type.STEP,
              font_array: data_yellow_Arr,
              h_space: 0, //图片间隔
              align_h: hmUI.align.CENTER_H,
              padding: false, //是否补零 true为补零
              //invalid_image: rootPath + "img/invalid.png",//单位
            });
            break;
          case hmUI.edit_type.STAND:
            objBottom.type = hmUI.data_type.STAND
            arc3.setProperty(hmUI.prop.MORE, {
              ...objGroup3ArcPublic,
              type: hmUI.data_type.STAND,
            });
            icon3.setProperty(hmUI.prop.MORE, {
              x: editGroupX3,
              y: editGroupY3,
              src: rootPath + "icon_yellow/stand.png",
            });
            text3.setProperty(hmUI.prop.MORE, {
              ...objGroup3TextPublic,
              type: hmUI.data_type.STAND,
              font_array: data_yellow_Arr,
              h_space: 0, //图片间隔
              align_h: hmUI.align.CENTER_H,
              padding: false, //是否补零 true为补零
              //invalid_image: rootPath + "img/invalid.png",//单位
            });
            break;
        }

        //-----------------跳转应用方法----------------
        function jumpApp(x ,y ,w ,h ,type){
          hmUI.createWidget(hmUI.widget.IMG_CLICK,{
            x, y, w, h, type //type必写 跳转的action
            });
        }
        //-----------------跳转应用执行----------------
        if(ObjTop.type){
          jumpApp(290,103,140,50,ObjTop.type)
        }
        if(objCenter.type){
          jumpApp(290,168,140,50,objCenter.type)
        }
        if(objBottom.type){
          jumpApp(290,225,105,150,objBottom.type)
        }
        jumpApp(140,31,35,35,hmUI.data_type.ALARM_CLOCK)
        hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          src: "images/mask/mask100.png",
          show_level: hmUI.show_level.ONLY_EDIT,
        });
        hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          src: "images/mask/mask70.png",
          show_level: hmUI.show_level.ONLY_EDIT,
        });

      },

      onInit() {
        console.log("index page.js on init invoke");

        this.init_view();
      },

      onReady() {
        console.log("index page.js on ready invoke");
      },

      onShow() {
        console.log("index page.js on show invoke");
      },

      onHide() {
        console.log("index page.js on hide invoke");
      },

      onDestory() {
        console.log("index page.js on destory invoke");
      },
    });
    /*
     * end js
     */
  })();
} catch (e) {
  console.log(e);
}
