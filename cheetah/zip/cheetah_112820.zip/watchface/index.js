try {
  ; (() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp

    var __$$module$$__ = __$$app$$__.current
    var h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__),
      'drink'
    )

      /*
       * huamiOS bundle tool v1.0.17
       * Copyright © Huami. All Rights Reserved
       */
      ; ('use strict')

    console.log('----->>>current')
    console.log(__$$hmAppManager$$__.currentApp.pid)
    console.log(__$$hmAppManager$$__.currentApp.current)

    let config = null

    let rootPath = 'images/'
    let dataPath = rootPath + 'data/'
    let timePath = rootPath + 'time/'
    let timeXpPath = rootPath + 'xp_time/'


    let weather_imgPath = dataPath + 'weather/'
    let batPath = dataPath + 'bat/'
    let stepPath = dataPath + 'step/'
    let altPath = dataPath + 'alt/'
    let tempPath = dataPath + 'temp/'
    let textPath = dataPath + 'text/'

    let textScPath = textPath + 'sc/'
    let textEnPath = textPath + 'en/'
    let textTcPath = textPath + 'tc/'

    let hourPath = timePath + 'hour/'
    let datePath = rootPath + 'date/'
    let secondPath = timePath + 'second/'

    let week_enPath = rootPath + 'week/en/'
    let week_scPath = rootPath + 'week/sc/'


    let weather_img_array = [] //天气数组
    let step_array = [] //气压 消耗 步数
    let hour_array = []
    let xp_time_array = []
    let second_array = []
    let week_en_array = []
    let week_sc_array = []

    let temp_array = [] //气温
    let date_array = []
    let alt_array = []
    let bat_array = []
    let bat_level_array = []

    const num_time_h_x = 127 * 0.946
    const num_time_m_x = 254 * 0.946
    const num_time_common_y = 95 * 0.946
    const num_am_pm_y = 114 * 0.946
    const num_am_pm_x = 44 * 0.946
    const num_week_x = 158 * 0.946
    const num_week_y = 32 * 0.946
    const num_date_x = 262 * 0.946
    const num_icon_x = 298 * 0.946
    const num_tips_w = 109 * 0.946

    let textSrcPath = ''

    var languge = hmSetting.getLanguage(); //返回当前语言的序号

    const logger = DeviceRuntimeCore.HmLogger.getLogger('defult')
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        for (let k = 0; k < 29; k++) {
          weather_img_array.push(weather_imgPath + k + '.png')
        }

        for (let i = 0; i < 10; i++) {
          hour_array.push(hourPath + i + '.png')
          step_array.push(stepPath + i + '.png')
          second_array.push(secondPath + i + '.png')
          temp_array.push(tempPath + i + '.png')
          date_array.push(datePath + i + '.png')
          alt_array.push(altPath + i + '.png')
          bat_array.push(batPath + 'num/' + i + '.png')
          xp_time_array.push(timeXpPath + i + '.png')

        }

        for (let k = 1; k < 8; k++) {
          week_en_array.push(week_enPath + k + '.png')
          week_sc_array.push(week_scPath + k + '.png')
        }

        for (let j = 1; j < 11; j++) {
          bat_level_array.push(batPath + 'level/' + j + '.png')

        }
        function getPathByLanguage(languge, type) {
          switch (languge) {
            case 2:
              textSrcPath = textEnPath + type + '.png'
              break;
            case 0:
              textSrcPath = textScPath + type + '.png'
              break;
            case 1:
              textSrcPath = textTcPath + type + '.png'
              break;
            default:
              textSrcPath = textEnPath + type + '.png'

          }
          return textSrcPath
        }

        let obj_text_bat = {
          x: 35 * 0.946,
          y: 250 * 0.946,
          src: textEnPath + 'bat.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        }
        let obj_text_alt = {
          x: 48 * 0.946,
          y: 333 * 0.946,
          src: textEnPath + 'alt.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        }
        let obj_text_kpa = {
          x: 48 * 0.946,
          y: 376 * 0.946,
          src: textEnPath + 'kpa.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        }
        let obj_text_heart = {
          x: 355 * 0.946,
          y: 250 * 0.946,
          src: textEnPath + 'heart.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        }
        let obj_text_cal = {
          x: 325 * 0.946,
          y: 376 * 0.946,
          src: textEnPath + 'cal.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        }
        let obj_text_maxo = {
          x: 325 * 0.946,
          y: 333 * 0.946,
          src: textEnPath + 'maxo.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        }
        let obj_bg = {
          x: 0,
          y: 0,
          // w: 454,
          // h: 454,
          src: rootPath + 'bg.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        }
        let obj_bat_mask = {
          x: 12,
          y: 162,
          // w: 138 * 0.946,
          // h: 138 * 0.946,
          src: batPath + 'level/mask.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        }
        let obj_heart_mask = {
          x: 312 ,
          y: 162 ,
          // w: 138 * 0.946,
          // h: 138 * 0.946,
          src: batPath + 'level/mask2.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        }
        let obj_time = {
          hour_zero: 1,
          hour_startX: num_time_h_x,
          hour_startY: num_time_common_y,
          hour_array: hour_array,
          hour_space: 0,
          hour_unit_sc: hourPath + 'dot.png',
          hour_unit_tc: hourPath + 'dot.png',
          hour_unit_en: hourPath + 'dot.png',
          minute_zero: 1,
          minute_startX: num_time_m_x,
          minute_startY: num_time_common_y,
          minute_array: hour_array,
          minute_space: 0,
          second_zero: 1,
          second_startX: 387 * 0.946,
          second_startY: 124 * 0.946,
          second_array: second_array,
          second_space: 0,
          hour_align: hmUI.align.LEFT,
          am_x: num_am_pm_x,
          am_y: num_am_pm_y,
          am_sc_path: timePath + 'ampm/am_sc.png',
          am_en_path: timePath + 'ampm/am_en.png',
          pm_x: num_am_pm_x,
          pm_y: num_am_pm_y,
          pm_sc_path: timePath + 'ampm/pm_sc.png',
          pm_en_path: timePath + 'ampm/pm_en.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        }
        // 息屏时间
        let obj_xp_time = {
          hour_zero: 1,
          hour_startX: num_time_h_x,
          hour_startY: num_time_common_y,
          hour_array: xp_time_array,
          hour_space: 0,
          hour_unit_sc: timeXpPath + 'dot.png',
          hour_unit_tc: timeXpPath + 'dot.png',
          hour_unit_en: timeXpPath + 'dot.png',
          minute_zero: 1,
          minute_startX: num_time_m_x,
          minute_startY: num_time_common_y,
          minute_array: xp_time_array,
          minute_space: 0,
          show_level: hmUI.show_level.ONLY_AOD,
        }
        // 日期
        let obj_date = {
          month_startX: num_date_x,
          month_startY: num_week_y,
          month_align: hmUI.align.LEFT,
          month_space: -1, //文字间隔
          month_zero: 1, //是否补零
          month_en_array: date_array,
          month_sc_array: date_array,
          month_tc_array: date_array,
          month_unit_sc: datePath + 'dot.png', // 单位
          month_unit_tc: datePath + 'dot.png', // 单位
          month_unit_en: datePath + 'dot.png', // 单位

          day_startX: num_date_x,
          day_startY: num_week_y,
          day_align: hmUI.align.LEFT,
          day_space: -1, //文字间隔
          day_zero: 1, //是否补零
          day_follow: 1, // 是否跟随
          day_en_array: date_array,
          day_sc_array: date_array,
          day_tc_array: date_array,
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD
        }
        // 星期
        let obj_week = {
          x: num_week_x,
          y: num_week_y,
          week_en: week_en_array,
          week_tc: week_sc_array,
          week_sc: week_sc_array,
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD
        }
        //步数
        let obj_step = {
          x: 0,
          y: 428 * 0.946,
          w: 454,
          icon: stepPath + 'icon.png',
          icon_space: 9 * 0.946,//icon到文字的间隔
          type: hmUI.data_type.STEP,
          font_array: step_array,
          h_space: -2,
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NORMAL
        }
        // 电量
        let obj_bat = {
          x: 40 * 0.946,
          y: 207 * 0.946,
          w: 80 * 0.946,
          type: hmUI.data_type.BATTERY,
          font_array: bat_array,
          h_space: 0,
          unit_sc: batPath + 'num/b.png',
          unit_en: batPath + 'num/b.png',
          unit_tc: batPath + 'num/b.png',
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NORMAL
        };
        //最大摄氧量
        let obj_maxo = {
          x: 254 * 0.946,
          y: 328 * 0.946,
          w: 90 * 0.946,
          type: hmUI.data_type.VO2MAX,
          font_array: step_array,
          invalid_image: tempPath + 'null.png',
          h_space: 0,
          align_h: hmUI.align.LEFT,
          show_level: hmUI.show_level.ONLY_NORMAL
        };
        //消耗
        let obj_cal = {
          x: 254 * 0.946,
          y: 370 * 0.946,
          w: 72 * 0.946,
          type: hmUI.data_type.CAL,
          font_array: step_array,
          invalid_image: tempPath + 'null.png',
          h_space: -2,
          align_h: hmUI.align.LEFT,
          show_level: hmUI.show_level.ONLY_NORMAL
        };
        //气压
        let obj_kpa = {
          x: 144 * 0.946,
          y: 370 * 0.946,
          w: 82 * 0.946,
          type: hmUI.data_type.ALTIMETER,
          font_array: step_array,
          invalid_image: tempPath + 'null.png',
          h_space: -1,
          align_h: hmUI.align.RIGHT,
          show_level: hmUI.show_level.ONLY_NORMAL
        };
        //海拔
        let obj_alt = {
          x: 144 * 0.946,
          y: 328 * 0.946,
          w: 82 * 0.946,
          type: hmUI.data_type.ALTITUDE,
          font_array: step_array,
          invalid_image: tempPath + 'null.png',
          negative_image: tempPath + 'dot.png',
          h_space: -1,
          align_h: hmUI.align.RIGHT,
          show_level: hmUI.show_level.ONLY_NORMAL
        };
        let obj_heart = {//心率
          x: 370 * 0.946,
          y: 213 * 0.946,
          w: 60 * 0.946,
          type: hmUI.data_type.HEART,
          font_array: bat_array,
          invalid_image: tempPath + 'null.png',
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NORMAL
        };

        // let obj_bat_level = {
        //   x: 13 * 0.946,
        //   y: 171 * 0.946,
        //   image_array: bat_level_array,
        //   image_length: bat_level_array.length,
        //   type: hmUI.data_type.BATTERY,
        //   show_level: hmUI.show_level.ONLY_NORMAL,
        // }
        let obj_pointer = {
          src: rootPath + 'pointer.png',
          center_x: 81 * 0.946,
          center_y: 241 * 0.946,
          x: 8 * 0.946,
          y: 63 * 0.946,
          type: hmUI.data_type.BATTERY,
          start_angle: 360,
          end_angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL
        }
        let obj_heart_pointer = {
          src: rootPath + 'pointer.png',
          center_x: 400 * 0.946,
          center_y: 244 * 0.946,
          x: 8 * 0.946,
          y: 63 * 0.946,
          type: hmUI.data_type.HEART,
          start_angle: 0,
          end_angle: 360,
          show_level: hmUI.show_level.ONLY_NORMAL
        }
        let obj_weather = {
          x: 183 * 0.946,
          y: 217 * 0.946,
          image_array: weather_img_array,
          image_length: weather_img_array.length,
          type: hmUI.data_type.WEATHER_CURRENT,
          show_level: hmUI.show_level.ONLY_NORMAL,
        }

        let obj_temp = {
          x: 240 * 0.946,
          y: 225 * 0.946,
          w: 68 * 0.946,
          type: hmUI.data_type.WEATHER_CURRENT,
          font_array: temp_array,
          h_space: 0,
          unit_sc: tempPath + 'du.png',
          unit_en: tempPath + 'du.png',
          unit_tc: tempPath + 'du.png',
          invalid_image: tempPath + 'null.png',
          negative_image: tempPath + 'dot.png',
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NORMAL
        }

        let obj_cal_click = {
          x: 253 * 0.946,
          y: 369 * 0.946,
          w: 178 * 0.946,
          h: 30 * 0.946,
          type: hmUI.data_type.CAL,
        }

        let obj_maxo_click = {//最大摄氧量
          x: 253 * 0.946,
          y: 323 * 0.946,
          w: 203 * 0.946,
          h: 31 * 0.946,
          type: hmUI.data_type.VO2MAX,
        }
        // 海拔
        let obj_haiba_click = {
          x: 20 * 0.946,
          y: 325 * 0.946,
          w: 203 * 0.946,
          h: 31 * 0.946,
          type: hmUI.data_type.ALTITUDE,
        }

        let obj_weather_click = {//天气
          x: 178 * 0.946,
          y: 214 * 0.946,
          w: 132 * 0.946,
          h: 50 * 0.946,
          type: hmUI.data_type.WEATHER_CURRENT,
        }
        let obj_heart_click = {//心率
          x: 370 * 0.946,
          y: 210 * 0.946,
          w: 60 * 0.946,
          h: 70 * 0.946,
          type: hmUI.data_type.HEART,
        }
        let obj_step_click = {//步数
          y: 430 * 0.946,
          x: 186 * 0.946,
          w: 122 * 0.946,
          h: 40 * 0.946,
          type: hmUI.data_type.STEP,
        }
        let obj_alt_click = {
          x: 70 * 0.946,
          y: 369 * 0.946,
          w: 160 * 0.946,
          h: 40 * 0.946,
          type: hmUI.data_type.ALTIMETER,
        }

        // 背景
        hmUI.createWidget(hmUI.widget.IMG, obj_bg)
        // 电量
        let batText = hmUI.createWidget(hmUI.widget.IMG, obj_text_bat)
        batText.setProperty(hmUI.prop.SRC, getPathByLanguage(languge, 'bat'))
        //海拔
        let altText = hmUI.createWidget(hmUI.widget.IMG, obj_text_alt)
        altText.setProperty(hmUI.prop.SRC, getPathByLanguage(languge, 'alt'))
        //  气压
        let kpaText = hmUI.createWidget(hmUI.widget.IMG, obj_text_kpa)
        kpaText.setProperty(hmUI.prop.SRC, getPathByLanguage(languge, 'kpa'))
        // 心率
        let heartText = hmUI.createWidget(hmUI.widget.IMG, obj_text_heart)
        heartText.setProperty(hmUI.prop.SRC, getPathByLanguage(languge, 'heart'))
        // 消耗
        let calText = hmUI.createWidget(hmUI.widget.IMG, obj_text_cal)
        calText.setProperty(hmUI.prop.SRC, getPathByLanguage(languge, 'cal'))
        // 最大摄氧
        let maxoText = hmUI.createWidget(hmUI.widget.IMG, obj_text_maxo)
        maxoText.setProperty(hmUI.prop.SRC, getPathByLanguage(languge, 'maxo'))

        hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
          center_x: 77,  // 圆弧中心位置x坐标
          center_y: 227,  // 圆弧中心位置y坐标
          radius: 60 * 0.946,    // 圆弧内半径
          start_angle: 360, // 开始角度
          end_angle: 0,    // 结束角度 (小于'开始角度'时为逆时针)
          color: 0xfb761e,  // 填充色
          line_width: 6,   // 弧形进度条宽度
          corner_flag: 6,   // 可选, 默认0-两端圆角,1-仅起始圆角,2-仅终点圆角,其它值-两端直角
          type: hmUI.data_type.BATTERY, // 设置数据类型来驱动进度,type和level至少要设置一个.
          show_level: hmUI.show_level.ONLY_NORMAL,
        })
        hmUI.createWidget(hmUI.widget.IMG, obj_bat_mask)

        hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
          center_x: 377,  // 圆弧中心位置x坐标
          center_y: 227,  // 圆弧中心位置y坐标
          radius: 60 * 0.946,    // 圆弧内半径
          start_angle: 0, // 开始角度
          end_angle: 360,    // 结束角度 (小于'开始角度'时为逆时针)
          color: 0xfb761e,  // 填充色
          line_width: 6,   // 弧形进度条宽度
          corner_flag: 6,   // 可选, 默认0-两端圆角,1-仅起始圆角,2-仅终点圆角,其它值-两端直角
          type: hmUI.data_type.HEART, // 设置数据类型来驱动进度,type和level至少要设置一个.
          show_level: hmUI.show_level.ONLY_NORMAL,
        })
        hmUI.createWidget(hmUI.widget.IMG, obj_heart_mask)

        // 时间
        hmUI.createWidget(hmUI.widget.IMG_TIME, obj_time)
        // 日期
        hmUI.createWidget(hmUI.widget.IMG_DATE, obj_date)
        // 星期
        hmUI.createWidget(hmUI.widget.IMG_WEEK, obj_week)
        hmUI.createWidget(hmUI.widget.TEXT_IMG, obj_bat)
        hmUI.createWidget(hmUI.widget.TEXT_IMG, obj_maxo)
        hmUI.createWidget(hmUI.widget.TEXT_IMG, obj_cal)
        hmUI.createWidget(hmUI.widget.TEXT_IMG, obj_kpa)
        hmUI.createWidget(hmUI.widget.TEXT_IMG, obj_alt)
        hmUI.createWidget(hmUI.widget.TEXT_IMG, obj_heart)
        // hmUI.createWidget(hmUI.widget.IMG_LEVEL, obj_bat_level)
        // 步数
        hmUI.createWidget(hmUI.widget.TEXT_IMG, obj_step)
        // 天气图标
        hmUI.createWidget(hmUI.widget.IMG_LEVEL, obj_weather)
        hmUI.createWidget(hmUI.widget.TEXT_IMG, obj_temp)
        hmUI.createWidget(hmUI.widget.IMG_TIME, obj_xp_time)
        hmUI.createWidget(hmUI.widget.IMG_POINTER, obj_pointer)
        hmUI.createWidget(hmUI.widget.IMG_POINTER, obj_heart_pointer)

        // 热区跳转
        hmUI.createWidget(hmUI.widget.IMG_CLICK, obj_heart_click)
        hmUI.createWidget(hmUI.widget.IMG_CLICK, obj_weather_click)

        hmUI.createWidget(hmUI.widget.IMG_CLICK, obj_cal_click)
        hmUI.createWidget(hmUI.widget.IMG_CLICK, obj_alt_click)
        hmUI.createWidget(hmUI.widget.IMG_CLICK, obj_maxo_click)
        hmUI.createWidget(hmUI.widget.IMG_CLICK, obj_step_click)
        hmUI.createWidget(hmUI.widget.IMG_CLICK, obj_haiba_click)



        hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: (function () {
            let languge = hmSetting.getLanguage()
            let path = null
            switch (languge) {
              case 2:
                path = textEnPath
                break;
              case 0:
                path = textScPath
                break;
              case 1:
                path = textTcPath
                break
              default:
                path = textEnPath
            }
            heartText.setProperty(hmUI.prop.SRC, path + 'heart.png')
            batText.setProperty(hmUI.prop.SRC, path + 'bat.png')
            altText.setProperty(hmUI.prop.SRC, path + 'alt.png')
            kpaText.setProperty(hmUI.prop.SRC, path + 'kpa.png')
            calText.setProperty(hmUI.prop.SRC, path + 'cal.png')
            maxoText.setProperty(hmUI.prop.SRC, path + 'maxo.png')

          }),
          pause_call: (function () {
            console.log('ui pause');
          }),
        });

      },

      onInit() {
        console.log('index page.js on init invoke')

        this.init_view()
      },

      onReady() {
        console.log('index page.js on ready invoke')
      },

      onShow() {
        console.log('index page.js on show invoke')
      },

      onHide() {
        console.log('index page.js on hide invoke')
      },

      onDestory() {
        console.log('index page.js on destory invoke')
      },
    })
    /*
     * end js
     */
  })()
} catch (e) {
  console.log(e)
}
