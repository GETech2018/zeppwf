try {
  (() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__),
      "drink"
    );

    /*
     * huamiOS bundle tool v1.0.17
     * Copyright © Huami. All Rights Reserved
     */
    ("use strict");

    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);
    //===================变量声明=====================
    const rootPath = "images/";

    const weekRootPath = rootPath + "week/";
    const dayRootPath = rootPath + "date/";
    const kapRootPath = rootPath + "kpa_num/";
    const moonRootPath = rootPath + "moon/";

    const weekArray = [];
    const dayArray = [];
    const kpaArray = [];
    const sunimgArray = [];
    const moonArray = [];
    let num = 0.945;
    //=================循环添加路径==================
    for (i = 1; i < 8; i++) {
      weekArray.push(`${weekRootPath}week_0${i}.png`);
      moonArray.push(`${moonRootPath}moon_0${i}.png`);
      sunimgArray.push(`${rootPath}sunset/sunset_${i}.png`);
    }
    for (i = 0; i < 10; i++) {
      dayArray.push(`${dayRootPath}day_0${i}.png`);
      kpaArray.push(`${kapRootPath}kpa_0${i}.png`);
    }
    //================参数对象======================
    let objImgBg = {
      x: 0,
      y: 0,
      w: 454,
      h: 454,
      src: rootPath + "bg.png",
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    let coverImg = {
      x: 220 * num,
      y: 220 * num,
      w: 454,
      h: 454,
      src: "images/img/cover.png",
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    let objWeekLevel = {
      x: 219 * num,
      y: 340 * num,
      week_sc: weekArray,
      week_tc: weekArray,
      week_en: weekArray,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    let objDayImg = {
      day_startX: 227 * num,
      day_startY: 383 * num,
      day_en_array: dayArray,
      day_space: 0,
      day_zero: 1,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    let objMonthPointer = {
      src: rootPath + "img/data_1.png",
      center_x: 240 * num,
      center_y: 368 * num,
      posX: 23 * num,
      posY: 55 * num,
      type: hmUI.date.MONTH,
      start_angle: 0,
      end_angle: 360,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    let objKpa = {
      x: 96 * num,
      y: 233 * num,
      font_array: kpaArray,
      h_space: 0,
      align_h: hmUI.align.CENTER_H,
      type: hmUI.data_type.ALTIMETER,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    let objMinPointer = {
      minute_centerX: 120 * num,
      minute_centerY: 242 * num,
      minute_posX: 60,
      minute_posY: 60,
      minute_path: rootPath + "img/kpaPointer.png",

      // src: rootPath + "img/kpaPointer.png",
      // center_x: 120 * num,
      // center_y: 242 * num,
      // x: 60,
      // y: 60,
      // type: hmUI.data_type.ALTIMETER,
      // start_angle: 0,
      // end_angle: 360,

      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    let objSunIcon = {
      src: rootPath + "sun/0.png",
      center_x: 362 * num,
      center_y: 242 * num,
      x: 16 * num,
      y: 39 * num,
      type: hmUI.data_type.SUN_CURRENT,
      start_angle: -90,
      end_angle: 80,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    let objMoonIcon = {
      src: rootPath + "sun/1.png",
      center_x: 362 * num,
      center_y: 242 * num,
      x: 16 * num,
      y: 39 * num,
      type: hmUI.data_type.MOON_CURRENT,
      start_angle: -90,
      end_angle: 80,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    let objSunbg = {
      show_level: hmUI.show_level.ONLY_NORMAL,
      x: 312 * num,
      y: 191 * num,
      w: 104,
      h: 104,
      src: rootPath + "sun/sun_bg.png",
    };
    // let objSunLevel = {

    //     x: 330 * 0.9708,
    //     y: 258 * 0.9708,
    //     w: 65,
    //     h: 15,
    //     image_array: [rootPath + "sun/sunrise.png", rootPath + "sun/sunset.png"],
    //     image_length: 2,
    //     type: hmUI.data_type.SUN_TIME,
    //     show_level: hmUI.show_level.ONLY_NORMAL,
    // }
    let objSunTimeImg = {
      x: 332 * num,
      y: 258 * num,
      w: 65,
      h: 15,
      src: rootPath + "sun/sunrise.png",
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    let objSunPointer = {
      src: rootPath + "img/data_1.png",
      center_x: 362 * num,
      center_y: 242 * num,
      x: 21,
      y: 51,
      type: hmUI.data_type.SUN_TIME,
      start_angle: 0,
      end_angle: 360,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    let objMoonLevel = {
      x: 157 * num,
      y: 29 * num,
      w: 156, //宽高可省略
      h: 156,
      image_array: moonArray,
      image_length: 7,
      type: hmUI.data_type.MOON,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };

    let sunRise = null; //日出
    let sunRiseMinute = null;
    let sunRiseTime = null;
    let sunSet = null; //日落
    let sunSetMinute = null;
    let sunSetTime = null;
    let hourNow = null; //当前小时
    let minuteNow = null; //当前分钟
    let timeNow = null; //当前分钟

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        hmUI.createWidget(hmUI.widget.IMG, objImgBg);
        hmUI.createWidget(hmUI.widget.IMG_WEEK, objWeekLevel);
        hmUI.createWidget(hmUI.widget.IMG_DATE, objDayImg);
        hmUI.createWidget(hmUI.widget.DATE_POINTER, objMonthPointer);
        hmUI.createWidget(hmUI.widget.TEXT_IMG, objKpa);
        hmUI.createWidget(hmUI.widget.TIME_POINTER, objMinPointer);
        hmUI.createWidget(hmUI.widget.IMG_POINTER, objSunIcon);
        // hmUI.createWidget(hmUI.widget.IMG_POINTER, objMoonIcon);
        var sunbg = hmUI.createWidget(hmUI.widget.IMG, objSunbg);
        // var sunLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, objSunLevel);
        let sunImgset = hmUI.createWidget(hmUI.widget.IMG, objSunTimeImg); //日出日落图片
        let sun_pointer = hmUI.createWidget(
          hmUI.widget.IMG_POINTER,
          objSunPointer
        );
        let moonLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, objMoonLevel);

        hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 166,
          y: 42,
          w: 122,
          h: 122,
          type: hmUI.data_type.MOON,
        });

        hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 282,
          y: 168,
          w: 122,
          h: 122,
          type: hmUI.data_type.SUN_SET,
        });
        hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 52,
          y: 168,
          w: 122,
          h: 122,
          type: hmUI.data_type.ALTIMETER,
        });

        var screenType = hmSetting.getScreenType();
        var aodModel = screenType == hmSetting.screen_type.AOD;
        var pointerProp = {
          hour_centerX: 227,
          hour_centerY: 227,
          hour_posX: 11,
          hour_posY: 156,
          hour_path: rootPath + "img/hour.png",
          minute_centerX: 227,
          minute_centerY: 227,
          minute_posX: 14,
          minute_posY: 222,
          minute_path: rootPath + "img/min_xp.png",
          show_level: hmUI.show_level.ONAL_AOD,
        };
        var timeNor1 = {
          hour_centerX: 227,
          hour_centerY: 227,
          hour_posX: 11,
          hour_posY: 156,
          hour_path: rootPath + "img/hour.png",
          minute_centerX: 227,
          minute_centerY: 227,
          minute_posX: 14,
          minute_posY: 222,
          minute_path: rootPath + "img/min_xp.png",
          second_centerX: 227,
          second_centerY: 227,
          second_posX: 15,
          second_posY: 225,
          second_path: rootPath + "img/sec.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        };
        timeNor = hmUI.createWidget(hmUI.widget.TIME_POINTER, timeNor1);
        timePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp);
        // hmUI.createWidget(hmUI.widget.IMG, coverImg); //针帽
        // console.log("cccccccccccccccccccccccc");
        setSunTime();
        // console.log("dddddddddddddddddddddddddd");
        function setSunTime() {
          // console.log("ffffffffffffffffffffffff");
          // 创建传感器
          const weather = hmSensor.createSensor(hmSensor.id.WEATHER);
          const weatherData = weather.getForecastWeather();
          const tideData = weatherData.tideData;
          var jstime = hmSensor.createSensor(hmSensor.id.TIME);
          hourNow = jstime.hour;
          minuteNow = jstime.minute;

          const element = tideData.data[0]; // i:0是当日
          sunRise = parseInt(element.sunrise.hour); //当天日出时间
          sunRiseMinute = parseInt(element.sunrise.minute); //当天日出时间/分

          sunSet = parseInt(element.sunset.hour); //当天日落时间
          sunSetMinute == parseInt(element.sunset.minute); //当天日落时间/分

          sunRiseTime = sunRise * 60 + sunRiseMinute; //算小时+分钟日出时间
          sunSetTime = sunSet * 60 + sunSetMinute; //算小时+分钟日出时间
          timeNow = hourNow * 60 + minuteNow; //算小时+分钟日出时间

          if (timeNow >= sunRiseTime && timeNow < sunSetTime) {
            sunImgset.setProperty(hmUI.prop.SRC, "images/sun/sunset.png");
          } else {
            sunImgset.setProperty(hmUI.prop.SRC, "images/sun/sunrise.png");
          }
          // console.log("日出时" + sunRise + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
          console
            .log
            // "日出分" + sunRiseMinute + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
            ();
          // console.log("bbbbbbbbbbbbbbbbbbbbbbbbbbbb");
        }

        hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: function () {
            setSunTime();
          },
          pause_call: function () {
            setSunTime();
          },
        });
      },

      onInit() {
        console.log("index page.js on init invoke");

        this.init_view();
      },

      onReady() {
        console.log("index page.js on ready invoke");
      },

      onShow() {
        console.log("index page.js on show invoke");
      },

      onHide() {
        console.log("index page.js on hide invoke");
      },

      onDestory() {
        console.log("index page.js on destory invoke");
      },
    });
    /*
     * end js
     */
  })();
} catch (e) {
  console.log(e);
}
