try {
  (() => {

    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

/*
* huamiOS bundle tool v1.0.17
* Copyright © Huami. All Rights Reserved
*/
    'use strict';

    console.log("----->>>current")
    console.log(__$$hmAppManager$$__.currentApp.pid)
    console.log(__$$hmAppManager$$__.currentApp.current)

    /*params声明*/

    let strPath = '';
    let strDataPath = '';
    let strRootPath = "images/";
    let nX = 0;
    let nY = 0;
    let pageX = 227;
    let pageY = 227;
    let arrEnWeek = [];
    let arrTcWeek = [];
    let arrScWeek = [];
    let arrDate = [];
    let arrData = [];
    let arrYear = [];
    let arrEnMonth = [];
    let arrScMonth = [];
    let arrTcMonth = [];
    let arrHeart = [];
    let topIcon = null;
    let botIcon = null;
    let leftIcon = null;
    let editTop  = null;
    let editBot = null;
    let heart = null;


    let languge = hmSetting.getLanguage();
    switch (languge) {
      case 2:
        strPath = strRootPath + "edit/data/en/";
        strDataPath = strRootPath + "edit_data/en/";
        break;
      case 0:
        strPath = strRootPath + "edit/data/sc/";
        strDataPath = strRootPath + "edit_data/sc/";
        break;
      case 1:
        strPath = strRootPath + "edit/data/tc/";
        strDataPath = strRootPath + "edit_data/tc/";
        break;
      default:
        strPath = strRootPath + "edit/data/en/";
        strDataPath = strRootPath + "edit_data/en/";
        break;
    };
    function px(num) {
      return num * (454 / 454);   //teide
      // return num * (466 / 454);  //berlin
      // return num * (416 / 454);  //vienna
    }
    let objBg = {
      x: nX,
      y: nY,
      src: strRootPath + "background/bg.png",
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
    };
    let objAodBg = {
      x: nX,
      y: nY,
      src: strRootPath + "aod_bg.png",
      show_level: hmUI.show_level.ONLY_AOD,
    };
    let edit_list_top = {
      title_font_size :34 ,
      title_align_h: hmUI.align.CENTER_H ,
      list_item_vspace: 8 ,
      list_tips_text_font_size: 32,
      list_tips_text_align_h : hmUI.align.LEFT,
    };
    let edit_list_bot = {
      title_font_size :34 ,
      title_align_h: hmUI.align.CENTER_H ,
      list_item_vspace: 8 ,
      list_tips_text_font_size: 32,
      list_tips_text_align_h : hmUI.align.LEFT,
    };
    let objPointer = {
      hour_centerX: pageX,
      hour_centerY: pageY,
      hour_posX: 21,
      hour_posY: 227,
      hour_path: strRootPath + "time/hour.png",
      minute_centerX: pageX,
      minute_centerY: pageY,
      minute_posX: 21,
      minute_posY: 227,
      minute_path: strRootPath + "time/min.png",
      second_centerX: pageX,
      second_centerY: pageY,
      second_posX: 21,
      second_posY: 227,
      second_path: strRootPath + "time/sec.png",
      show_level: hmUI.show_level.ONLY_NORMAL
    };
    let objEditPointer = {
      hour_centerX: pageX,
      hour_centerY: pageY,
      hour_posX: 21,
      hour_posY: 227,
      hour_path: strRootPath + "time/hour.png",
      minute_centerX: pageX,
      minute_centerY: pageY,
      minute_posX: 21,
      minute_posY: 227,
      minute_path: strRootPath + "time/min.png",
      second_centerX: pageX,
      second_centerY: pageY,
      second_posX: 21,
      second_posY: 227,
      second_path: strRootPath + "time/sec.png",
      show_level: hmUI.show_level.ONLY_EDIT
    };
    let objAodPointer = {
      hour_centerX: pageX,
      hour_centerY: pageY,
      hour_posX: 21,
      hour_posY: 227,
      hour_path: strRootPath + "time/hour.png",
      minute_centerX: pageX,
      minute_centerY: pageY,
      minute_posX: 21,
      minute_posY: 227,
      minute_path: strRootPath + "time/min.png",
      show_level: hmUI.show_level.ONAL_AOD
    };
    let objWeek = {
      x: 310,
      y: 177,
      week_en: arrEnWeek,
      week_sc: arrScWeek,
      week_tc: arrTcWeek,
      show_level: hmUI.show_level.ONLY_ALL    //ONAL_AOD  or  ONLY_AOD
    };
    let objDate = {
      year_startX: 323,
      year_startY: 255,
      year_align: hmUI.align.RIGHT,
      year_space: 1,
      year_zero: 1,
      year_en_array: arrYear,
      year_sc_array: arrYear,
      year_tc_array: arrYear,
      year_is_character:false,
      year_follow: 0,
      month_startX: 295,
      month_startY: 217,
      month_align: hmUI.align.LEFT,
      month_space: 0,
      month_zero: 1,
      month_follow: 0,
      month_en_array: arrEnMonth,
      month_sc_array: arrScMonth,
      month_tc_array: arrTcMonth,
      month_is_character:true,
      day_startX: 355,
      day_startY: 218,
      day_align: hmUI.align.LEFT,
      day_space: 0,
      day_zero: 1,
      day_follow: 0,
      day_en_array: arrDate,
      day_sc_array: arrDate,
      day_tc_array: arrDate,
      show_level: hmUI.show_level.ONLY_ALL
    };
    let objEditTop = {
      edit_id: 101,
      x: px(152),
      y: px(39),
      w: px(162),
      h: px(162),
      select_image:strRootPath + "edit/select/select.png",
      un_select_image:strRootPath + "edit/select/select_null.png",
      default_type:hmUI.edit_type.CAL,
      optional_types: [
        { type: hmUI.edit_type.CAL, preview: strPath + "cal.png" },
        { type: hmUI.edit_type.BATTERY, preview: strPath + "bat.png" },
        { type: hmUI.edit_type.DISTANCE, preview: strPath + "distance.png",},
        { type: hmUI.edit_type.PAI_WEEKLY, preview: strPath + "pai.png" },
        { type: hmUI.edit_type.STAND, preview: strPath + "stand.png" },
        { type: hmUI.edit_type.UVI, preview: strPath + "uvi.png" },
        { type: hmUI.edit_type.STEP, preview: strPath + "step.png" }
      ],
      count:7,
      tips_BG:strRootPath+"edit/tips.png",
      tips_x:-5,
      tips_y:175,
      tips_width:170,
      tips_margin:0,
      select_list: edit_list_top,
    };
    let objEditBot = {
      edit_id: 102,
      x: px(152),
      y: px(264),
      w: px(162),
      h: px(162),
      select_image:strRootPath + "edit/select/select.png",
      un_select_image:strRootPath + "edit/select/select_null.png",
      default_type:hmUI.edit_type.STEP,
      optional_types: [
        { type: hmUI.edit_type.CAL, preview: strPath + "cal.png" },
        { type: hmUI.edit_type.BATTERY, preview: strPath + "bat.png" },
        { type: hmUI.edit_type.DISTANCE, preview: strPath + "distance.png",},
        { type: hmUI.edit_type.PAI_WEEKLY, preview: strPath + "pai.png" },
        { type: hmUI.edit_type.STAND, preview: strPath + "stand.png" },
        { type: hmUI.edit_type.UVI, preview: strPath + "uvi.png" },
        { type: hmUI.edit_type.STEP, preview: strPath + "step.png" }
      ],
      count:7,
      tips_BG:strRootPath+"edit/tips.png",
      tips_x:-5,
      tips_y: -50,
      tips_width:170,
      tips_margin:0,
      select_list: edit_list_bot,
    };
    let objMask = {
      x: nX,
      y: nY,
      w: 454,
      h: 454,
      src: strRootPath+"edit/bg_mask/mask.png",
      show_level:hmUI.show_level.ONLY_EDIT,
    };
    /*遍历数组*/
    for(i = 0; i < 29; i++){
      if( i < 8 && i > 0 ){
        arrEnWeek.push(strRootPath+"week/en/"+i+".png")
        arrScWeek.push(strRootPath+"week/sc/"+i+".png")
        arrTcWeek.push(strRootPath+"week/tc/"+i+".png")
      }
      if(i < 10){
        arrDate.push(strRootPath+"date/"+i+".png")
        arrData.push(strRootPath+"data/"+i+".png")
        arrYear.push(strRootPath+"year/"+i+".png")
      }
      if(i < 11 && i > 0 ){
        arrHeart.push(strRootPath+"pointer/level/"+i+".png")
      }
      if(i < 13 && i > 0){
        arrEnMonth.push(strRootPath+"month/en/"+i+".png")
        arrScMonth.push(strRootPath+"month/sc/"+i+".png")
        arrTcMonth.push(strRootPath+"month/tc/"+i+".png")
      }
    };

    const logger = DeviceRuntimeCore.HmLogger.getLogger("xiping");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({

      /* 获取数值--电量/湿度/步数/卡路里/天气温度/PAI/心率 */
      getFont(options) {
        let objConfig = {
          x: 0,
          y: 0,
          w: 0,
          type: "",
          font_array: arrData,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          unit_sc: "",
          unit_tc: "",
          unit_en: "",
          invalid_image: "",
          dot_image:"",
          padding: !1,
          negative_image: "",
          show_level: hmUI.show_level.ONLY_NORMAL
        }
        for (let key in options) {
          if (key in objConfig) {
            objConfig[key] = options[key]
          }
        }
        for (let key in objConfig) {
          if (!objConfig[key]) {
            delete objConfig[key]
          }
        }
        let text = hmUI.createWidget(hmUI.widget.TEXT_IMG, objConfig)
      },
      /* 获取进度--电量/湿度/步数/卡路里 */
      getLevel(options) {
        let { x, y, arr, type } = options
        let progress = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: x,
          y: y,
          image_array: arr,
          image_length: arr.length, //长度
          type: type,
          show_level: hmUI.show_level.ONLY_NORMAL|hmUI.show_level.ONLY_EDIT
        })
      },
      /* 获取图标 */
      getIcon(options){
        let { x, y, src  } = options
        let icon = hmUI.createWidget(hmUI.widget.IMG, {
          x: x,
          y: y,
          src: src,
          show_level: hmUI.show_level.ONLY_NORMAL|hmUI.show_level.ONLY_EDIT,
        })
        return icon;
      },
      /* 获取当前语言的路径 */
      getLangPath(options){
          let strDataPath = ''
          let path = ''
          let languge = hmSetting.getLanguage();
          switch (languge) {
            case 2:
              strDataPath = strRootPath + "edit_data/en/";
              break;
            case 0:
              strDataPath = strRootPath + "edit_data/sc/";
              break;
            case 1:
              strDataPath = strRootPath + "edit_data/tc/";
              break;
            default:
              strDataPath = strRootPath + "edit_data/en/";
              break;
          }
          switch (options) {
            case hmUI.edit_type.BATTERY:
              path = strDataPath + "bat.png"
              break;
            case hmUI.edit_type.CAL:
              path = strDataPath + "cal.png"
              break;
            case hmUI.edit_type.DISTANCE:
              path = strDataPath + "distance.png"
              break;
            case hmUI.edit_type.PAI_WEEKLY:
              path = strDataPath + "pai.png"
              break;
            case hmUI.edit_type.STAND:
              path = strDataPath + "stand.png"
              break;
            case hmUI.edit_type.UVI:
              path = strDataPath + "uvi.png"
              break;
            case hmUI.edit_type.STEP:
              path = strDataPath + "step.png"
              break;
            default:
              path = strDataPath + "heart.png"
              break;
          }
          return path;
      },
      /* 根据编辑的状态选择数据Top */
      getTopData(options) {
        let { x, y, txty, piy, type } = options
        switch (type) {
          case hmUI.edit_type.BATTERY:
            this.getFont({ x: 191, y:y, w:80, type: hmUI.data_type.BATTERY,})
            this.getDataPointet({ x: x, y: piy,type: hmUI.data_type.BATTERY})
            topIcon = this.getIcon({ x: 188, y: txty, src: strDataPath + "bat.png" })
            this.changeClick({ x: 178, y: 65, w: 110, h: 110, type: hmUI.data_type.BATTERY})
            break;
          case hmUI.edit_type.CAL:
            this.getFont({ x: 192, y: y, w:80, type: hmUI.data_type.CAL})
            this.getDataPointet({ x: x, y: piy,type: hmUI.data_type.CAL})
            topIcon=this.getIcon({ x: 188, y: txty, src: strDataPath + "cal.png" })
            this.changeClick({ x: 178, y: 65, w: 110, h: 110, type: hmUI.data_type.CAL})
            break;
          case hmUI.edit_type.DISTANCE:
            this.getFont({ x: 191, y: y, w:80, type: hmUI.data_type.DISTANCE,dot_image:strRootPath +"data/dot.png",invalid_image:strRootPath +"data/null.png"})
            this.getDataPointet({ x: x, y: piy,type: hmUI.data_type.DISTANCE})
            topIcon=this.getIcon({ x: 188, y: txty, src: strDataPath + "distance.png" })
            this.changeClick({ x: 178, y: 65, w: 110, h: 110, type: hmUI.data_type.DISTANCE})
            break;
          case hmUI.edit_type.PAI_WEEKLY:
            this.getFont({ x: 191, y: y, w:80, type: hmUI.data_type.PAI_WEEKLY})
            this.getDataPointet({ x: x, y: piy,type: hmUI.data_type.PAI_WEEKLY})
            topIcon=this.getIcon({ x: 186, y: txty, src: strDataPath + "pai.png" })
            this.changeClick({ x: 178, y: 65, w: 110, h: 110, type: hmUI.data_type.PAI_WEEKLY})
            break;
          case hmUI.edit_type.STAND:
            this.getFont({ x: 191, y: y, w:80, type: hmUI.data_type.STAND})
            this.getDataPointet({ x: x, y: piy,type: hmUI.data_type.STAND})
            topIcon=this.getIcon({ x: 188, y: txty, src: strDataPath + "stand.png" })
            this.changeClick({ x: 178, y: 65, w: 110, h: 110, type: hmUI.data_type.STAND})
            break;
          case hmUI.edit_type.UVI:
            this.getFont({ x: 191, y: y, w:80, type: hmUI.data_type.UVI,invalid_image:strRootPath +"data/null.png"})
            this.getDataPointet({ x: x, y: piy,type: hmUI.data_type.UVI})
            topIcon=this.getIcon({ x: 188, y: txty, src: strDataPath + "uvi.png" })
            this.changeClick({ x: 178, y: 65, w: 110, h: 110, type: hmUI.data_type.UVI})
            break;
          case hmUI.edit_type.STEP:
            this.getFont({ x: 191, y:y, w:80, type: hmUI.data_type.STEP})
            this.getDataPointet({ x: x, y: piy,type: hmUI.data_type.STEP})
            topIcon=this.getIcon({ x: 188, y: txty, src: strDataPath + "step.png" })
            this.changeClick({ x: 178, y: 65, w: 110, h: 110, type: hmUI.data_type.STEP})
            break;
          default:
            break;
        }

      },
      /* 根据编辑的状态选择数据Bot */
      getBotData(options) {
        let { x, y, txty, piy, type } = options
        switch (type) {
          case hmUI.edit_type.BATTERY:
            this.getFont({ x: 191, y:y, w:80, type: hmUI.data_type.BATTERY,})
            this.getDataPointet({ x: x, y: piy, type: hmUI.data_type.BATTERY})
            botIcon = this.getIcon({ x: 188, y: txty, src: strDataPath + "bat.png" })
            this.changeClick({ x: 178, y: 288, w: 110, h: 110, type: hmUI.data_type.BATTERY})
            break;
          case hmUI.edit_type.CAL:
            this.getFont({ x: 192, y: y, w:80, type: hmUI.data_type.CAL})
            this.getDataPointet({ x: x, y: piy, type: hmUI.data_type.CAL})
            botIcon=this.getIcon({ x: 188, y: txty, src: strDataPath + "cal.png" })
            this.changeClick({ x: 178, y: 288, w: 110, h: 110, type: hmUI.data_type.CAL})
            break;
          case hmUI.edit_type.DISTANCE:
            this.getFont({ x: 191, y: y, w:80, type: hmUI.data_type.DISTANCE,dot_image:strRootPath +"data/dot.png",invalid_image:strRootPath +"data/null.png"})
            this.getDataPointet({ x: x, y: piy,type: hmUI.data_type.DISTANCE})
            botIcon=this.getIcon({ x: 188, y: txty, src: strDataPath + "distance.png" })
            this.changeClick({ x: 178, y: 288, w: 110, h: 110, type: hmUI.data_type.DISTANCE})
            break;
          case hmUI.edit_type.PAI_WEEKLY:
            this.getFont({ x: 191, y: y, w:80, type: hmUI.data_type.PAI_WEEKLY})
            this.getDataPointet({ x: x, y: piy,type: hmUI.data_type.PAI_WEEKLY})
            botIcon=this.getIcon({ x: 188, y: txty, src: strDataPath + "pai.png" })
            this.changeClick({ x: 178, y: 288, w: 110, h: 110, type: hmUI.data_type.PAI_WEEKLY})
            break;
          case hmUI.edit_type.STAND:
            this.getFont({ x: 191, y: y, w:80, type: hmUI.data_type.STAND})
            this.getDataPointet({ x: x, y: piy,type: hmUI.data_type.STAND})
            botIcon=this.getIcon({ x: 188, y: txty, src: strDataPath + "stand.png" })
            this.changeClick({ x: 178, y: 288, w: 110, h: 110, type: hmUI.data_type.STAND})
            break;
          case hmUI.edit_type.UVI:
            this.getFont({ x: 191, y: y, w:80, type: hmUI.data_type.UVI,invalid_image:strRootPath +"data/null.png"})
            this.getDataPointet({ x: x, y: piy, type: hmUI.data_type.UVI})
            botIcon=this.getIcon({ x: 188, y: txty, src: strDataPath + "uvi.png" })
            this.changeClick({ x: 178, y: 288, w: 110, h: 110, type: hmUI.data_type.UVI})
            break;
          case hmUI.edit_type.STEP:
            this.getFont({ x: 191, y:y, w:80, type: hmUI.data_type.STEP})
            this.getDataPointet({ x: x, y: piy,type: hmUI.data_type.STEP})
            botIcon=this.getIcon({ x: 188, y: txty, src: strDataPath + "step.png" })
            this.changeClick({ x: 178, y: 288, w: 110, h: 110, type: hmUI.data_type.STEP})
            break;
          default:
            break;
        }
      },
      /* 获取数据指针 */
      getDataPointet(options){
        let { x, y, type } = options
        let pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
          src: strRootPath + "pointer/data_pointer.png",
          center_x: x,
          center_y: y,
          x: 9,
          y: 74,
          type:type,
          invalid_visible:true,
          start_angle:0,
          end_angle:360,
          show_level: hmUI.show_level.ONLY_NORMAL|hmUI.show_level.ONLY_EDIT
        })
      },
      /* 点击事件 */
      changeClick(options){
        let { x, y, w, h, type} = options
        let click = hmUI.createWidget(hmUI.widget.IMG_CLICK,{
          x: x,
          y: y,
          w: w,
          h: h,
          type: type,
        })
      },
      init_view() {
        let that = this;

        /* 正常背景 */
        let bg = hmUI.createWidget(hmUI.widget.IMG, objBg);

        /* 息屏背景 */
        let aodBg = hmUI.createWidget(hmUI.widget.IMG, objAodBg);

        /* top_圈圈 */
        this.getIcon({ x:152,y:39,src:strRootPath + "edit/bg/edit_bg.png" });

        /* bottom_圈圈 */
        this.getIcon({ x:152,y:262,src:strRootPath + "edit/bg/edit_bg.png" });

        /* 日期 */
        let timeDate = hmUI.createWidget(hmUI.widget.IMG_DATE, objDate);

        /* 星期 */
        let timeWeek = hmUI.createWidget(hmUI.widget.IMG_WEEK, objWeek);

        /* HEART */
        this.getFont({ x: 96, y: 194, w:50, type: hmUI.data_type.HEART,
          show_level:hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
          invalid_image:strRootPath +"data/null.png"})
        leftIcon = this.getIcon({ x: 78, y: 242, src: strDataPath + "heart.png" });

        /* HEART_进度 */
        let arc = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
          center_x: 120,
          center_y: 228,
          radius: 59,
          start_angle: 0,
          end_angle: 360,
          color: 0xE7ECEF,
          line_width: 7,
          corner_flag: 3,
          // level:80,
          type: hmUI.data_type.HEART,
          show_level: hmUI.show_level.ONLY_NORMAL|hmUI.show_level.ONLY_EDIT
        });
        this.getIcon({ x: 55, y: 162, src: strRootPath + "mask.png" });

        /* HEART_指针 */
        this.getDataPointet({ x: 120, y: 230, type: hmUI.data_type.HEART});

        /* 亮屏时间指针 */
        let timeEdit = hmUI.createWidget(hmUI.widget.TIME_POINTER, objEditPointer);

        /*heart跳转*/
        this.changeClick({ x: 68, y: 178, w: 110, h: 110, type: hmUI.data_type.HEART});

        /* 100%mask 编辑背景 */
        let maskCover = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK,objMask);

        /* 可编辑组件 */
        editTop  = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP,objEditTop);
        editBot = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, objEditBot);

        /* 获取当前编辑选择的id */
        let topType = editTop.getProperty(hmUI.prop.CURRENT_TYPE);
        let botType = editBot.getProperty(hmUI.prop.CURRENT_TYPE);
        this.getTopData({ x: 231, y: 83, txty: 132, piy: 117, type: topType });
        this.getBotData({ x: 231, y: 306, txty: 355, piy: 343, type: botType });

        /* 亮屏时间指针 */
        let timePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, objPointer);

        /* 息屏时间指针 */
        let timeAodPointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, objAodPointer);

        /* 滑屏幕事件 */
        let widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: (function(){
            let topType = editTop.getProperty(hmUI.prop.CURRENT_TYPE);
            let botType = editBot.getProperty(hmUI.prop.CURRENT_TYPE);
            let leftType = true
            let topPath = that.getLangPath(topType)
            let botPath = that.getLangPath(botType)
            let leftPath = that.getLangPath(leftType)
            topIcon.setProperty(hmUI.prop.SRC,topPath)
            botIcon.setProperty(hmUI.prop.SRC,botPath)
            leftIcon.setProperty(hmUI.prop.SRC,leftPath)
          }),
          pause_call: (function () {
              console.log('ui pause');
          }),
        });

      },

      onInit() {
        console.log('index page.js on init invoke')
        this.init_view();
      },

      onReady() {
        console.log('index page.js on ready invoke')
      },

      onShow() {
        console.log('index page.js on show invoke')
      },

      onHide() {
        console.log('index page.js on hide invoke')
      },

      onDestory() {
        console.log('index page.js on destory invoke')
      },
    });
    /*
    * end js
    */
  })()
} catch (e) {
  console.log(e)
}
