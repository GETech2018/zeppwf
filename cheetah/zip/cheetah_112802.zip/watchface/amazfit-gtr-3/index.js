try {
    (() => {
        var e = __$$hmAppManager$$__.currentApp;
        const _ = e.current,
            {
                px: n
            } = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e, _)), e.app.__globals__),
            t = Logger.getLogger("watchface6");
        _.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 454,
                    h: 454,
                    src: "4.png",
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 83,
                    y: 253,
                    type: hmUI.data_type.BATTERY,
                    font_array: ["5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png", "14.png"],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -4,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: "16.png",
                    unit_tc: "16.png",
                    unit_en: "16.png",
                    invalid_image: "15.png",
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: "17.png",
                    center_x: 118,
                    center_y: 226,
                    x: 12,
                    y: 57,
                    type: hmUI.data_type.BATTERY,
                    start_angle: -133,
                    end_angle: 133,
                    cover_x: 0,
                    cover_y: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 190,
                    y: 361,
                    type: hmUI.data_type.STEP,
                    font_array: ["18.png", "19.png", "20.png", "21.png", "22.png", "23.png", "24.png", "25.png", "26.png", "27.png"],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -2,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: "28.png",
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: "30.png",
                    center_x: 227,
                    center_y: 333,
                    x: 13,
                    y: 57,
                    type: hmUI.data_type.STEP,
                    start_angle: -120,
                    end_angle: 120,
                    cover_path: "29.png",
                    cover_x: 203,
                    cover_y: 309,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    day_startX: 319,
                    day_startY: 213,
                    day_sc_array: ["31.png", "32.png", "33.png", "34.png", "35.png", "36.png", "37.png", "38.png", "39.png", "40.png"],
                    day_tc_array: ["31.png", "32.png", "33.png", "34.png", "35.png", "36.png", "37.png", "38.png", "39.png", "40.png"],
                    day_en_array: ["31.png", "32.png", "33.png", "34.png", "35.png", "36.png", "37.png", "38.png", "39.png", "40.png"],
                    day_align: hmUI.align.CENTER_H,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: -2,
                    day_is_character: !1,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 203,
                    y: 144,
                    type: hmUI.data_type.HEART,
                    font_array: ["41.png", "42.png", "43.png", "44.png", "45.png", "46.png", "47.png", "48.png", "49.png", "50.png"],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: "51.png",
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: "53.png",
                    center_x: 227,
                    center_y: 118,
                    x: 13,
                    y: 57,
                    type: hmUI.data_type.HEART,
                    start_angle: -120,
                    end_angle: 120,
                    cover_path: "52.png",
                    cover_x: 203,
                    cover_y: 93,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 227,
                    hour_centerY: 227,
                    hour_posX: 25,
                    hour_posY: 146,
                    hour_path: "54.png",
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 227,
                    minute_centerY: 227,
                    minute_posX: 22,
                    minute_posY: 186,
                    minute_path: "55.png",
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    second_centerX: 227,
                    second_centerY: 227,
                    second_posX: 13,
                    second_posY: 218,
                    second_path: "57.png",
                    second_cover_path: "56.png",
                    second_cover_x: 219,
                    second_cover_y: 219,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 57,
                    y: 54,
                    src: "58.png",
                    type: hmUI.system_status.DISCONNECT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 330,
                    y: 325,
                    src: "59.png",
                    type: hmUI.system_status.DISTURB,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 332,
                    y: 58,
                    src: "60.png",
                    type: hmUI.system_status.LOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 57,
                    y: 330,
                    src: "61.png",
                    type: hmUI.system_status.CLOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 227,
                    hour_centerY: 227,
                    hour_posX: 16,
                    hour_posY: 135,
                    hour_path: "62.png",
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 227,
                    minute_centerY: 227,
                    minute_posX: 18,
                    minute_posY: 177,
                    minute_path: "63.png",
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_AOD
                }), hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 180,
                    y: 288,
                    w: 93,
                    h: 93,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 180,
                    y: 71,
                    w: 93,
                    h: 93,
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 57,
                    y: 330,
                    w: 70,
                    h: 70,
                    type: hmUI.data_type.ALARM_CLOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                })
            },
            onInit() {
                t.log("index page.js on init invoke")
            },
            build() {
                this.init_view(), t.log("index page.js on ready invoke")
            },
            onDestroy() {
                t.log("index page.js on destroy invoke")
            }
        })
    })()
} catch (e) {
    console.log(e)
}