try {
  (() => {

    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

    /*
     * huamiOS bundle tool v1.0.17
     * Copyright © Huami. All Rights Reserved
     */
    'use strict';
    /* params声明 */

    let strRootPath = "images/";
    let nX = 0;
    let nY = 0;
    let nWidth = 454;
    let nHeight = 454;
    let nPageX = nWidth / 2;
    let nPageY = nHeight / 2 - 1;
    let nCalX = 174;
    let nCalY = 32;
    let nIconX = 258;
    let nIconY = 258;
    let arrAodDay = [];
    let arrNorDay = [];
    let arrWeek = [];
    let arrMonth = [];
    let arrBatLine = [];
    let arrWeather = [];
    let arrMoon = [];
    /* 遍历数组 */
    for (let i = 0; i < 29; i++) {
      if (i < 8) {
        arrWeek.push(strRootPath + "week/" + i + ".png");
      }
      if (i < 10) {
        arrNorDay.push(strRootPath + "data_font/" + i + ".png");
        arrAodDay.push(strRootPath + "day_font/" + i + ".png");
        arrBatLine.push(strRootPath + "bat/" + i + ".png");
      }
      if (i < 12) {
        arrMonth.push(strRootPath + "month/" + i + ".png");
      }
      arrWeather.push(strRootPath + "weather/" + i + ".png");
    }
    for (let i = 1; i < 31; i++) {
      arrMoon.push(strRootPath + "moon/" + i + ".png");
    }
    let objSecondStyle = {
      centerX: nPageX,
      centerY: nPageY,
      posX: 15,
      posY: nPageY,
    };
    let arrPointerConfig = [
      {
        id: 1,
        second: {
          ...objSecondStyle,
          path: strRootPath + "pointer/sec.png",
        },
        preview: strRootPath + "pointer/red1.png",
      },
      {
        id: 2,
        second: {
          ...objSecondStyle,
          path: strRootPath + "pointer/sec_green.png",
        },
        preview: strRootPath + "pointer/green1.png",
      },
      {
        id: 3,
        second: {
          ...objSecondStyle,
          path: strRootPath + "pointer/sec_yellow.png",
        },
        preview: strRootPath + "pointer/yellow1.png",
      },
      {
        id: 4,
        second: {
          ...objSecondStyle,
          path: strRootPath + "pointer/sec_blue.png",
        },
        preview: strRootPath + "pointer/blue1.png",
      },
    ];
    let objEditBg = {
      edit_id: 103,
      x: nX,
      y: nY,
      bg_config: [
        { id: 1, preview: strRootPath + "preview/preview_1.png", path: strRootPath + "mask/bg_1.png" },
        { id: 2, preview: strRootPath + "preview/preview_blue.png", path: strRootPath + "mask/bg_blue.png" },
        { id: 3, preview: strRootPath + "preview/preview_yellow.png", path: strRootPath + "mask/bg_yellow.png" },
        { id: 4, preview: strRootPath + "preview/preview_green.png", path: strRootPath + "mask/bg_green.png" },
        { id: 5, preview: strRootPath + "preview/preview_red.png", path: strRootPath + "mask/bg_red.png" },
      ],
      count: 5,
      default_id: 1,
      fg: strRootPath + "mask/mask-70-1green.png",
      tips_x: 175,
      tips_y: 368,
      tips_margin: 10,
      tips_bg: strRootPath + "mask/tips.png",
    };
    let objAodBG = {
      x: nX,
      y: nY,
      w: nWidth,
      h: nHeight,
      src: strRootPath + "aod/BG.png",
      show_level: hmUI.show_level.ONAL_AOD,
    };
    let nMonthX = 110;
    let nMonthY = 233;
    let nDatX = 57;
    let nDatY = 217;
    let objDate = {
      month_startX: nMonthX,
      month_startY: nMonthY,
      month_zero: 1,//是否补零
      month_follow: 0,//是否跟随
      month_en_array: arrMonth,
      month_sc_array: arrMonth,
      month_tc_array: arrMonth,
      month_is_character: true,
      day_startX: nDatX,
      day_startY: nDatY,
      day_align: hmUI.align.LEFT,
      day_space: 0,//文字间隔
      day_zero: 1,//是否补零
      day_follow: 0,//是否跟随
      day_en_array: arrAodDay,
      day_sc_array: arrAodDay,
      day_tc_array: arrAodDay,
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD,
    };
    let nWeekX = 110;
    let nWeekY = 207;
    let objWeek = {
      x: nWeekX,
      y: nWeekY,
      week_en: arrWeek,
      week_tc: arrWeek,
      week_sc: arrWeek,
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD,
    };
    let nHourX = 34;
    let nHourY = 166;
    let nMinX = 23;
    let nMinY = 227;
    let objPointerStyle = {
      hour_centerX: nPageX,
      hour_centerY: nPageY,
      hour_posX: nHourX,
      hour_posY: nHourY,
      minute_centerX: nPageX,
      minute_centerY: nPageY,
      minute_posX: nMinX,
      minute_posY: nMinY,
    };
    let objPointer = {
      ...objPointerStyle,
      hour_path: strRootPath + "pointer/hour.png",
      minute_path: strRootPath + "pointer/min.png",
      show_level: hmUI.show_level.ONLY_NORMAL
    };
    let objPointerAod = {
      ...objPointerStyle,
      hour_path: strRootPath + "aod/hour.png",
      minute_path: strRootPath + "aod/min.png",
      show_level: hmUI.show_level.ONAL_AOD
    };
    let objEditSecondPointer = {
      edit_id: 105,
      x: nX,
      y: nY,
      config: arrPointerConfig,
      count: arrPointerConfig.length,
      default_id: 1,
      fg: strRootPath + "mask/mask-70-1.png",
      tips_x: 174,
      // tips_x: 178,
      tips_y: 120,
      tips_margin: 10,
      tips_bg: strRootPath + "mask/tips.png",
    };
    let objMask = {
      x: nX,
      y: nY,
      w: nWidth,
      h: nHeight,
      src: strRootPath + "mask/mask-70-1.png",
      show_level: hmUI.show_level.ONLY_EDIT,
    };
    let objCompass = {
      x: nIconX,
      y: nIconY,
      w: 60,
      h: 60,
      src: "images/compass.png",
      enable: true, //false不接收点击事件
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    let objMoon = {
      x: 258,
      y: 136,
      image_array: arrMoon,
      image_length: arrMoon.length, //长度
      type: hmUI.data_type.MOON,
      shortcut: true,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    let objCal = {
      x: nCalX,
      y: nCalY,
      src: strRootPath + "cal/0.png",
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    let objClickStyle = {
      w: 134,
      h: 134,
      enable: true,
      show_level: hmUI.show_level.ONLY_NORMAL
    };
    let objBlke = {
      x: 0,
      y: 0,
      ...objClickStyle,
      type: hmUI.data_type.OUTDOOR_CYCLING,
    };
    let objRun = {
      x: 320,
      y: 0,
      ...objClickStyle,
      type: hmUI.data_type.OUTDOOR_RUNNING,
    };
    let objSwimming = {
      x: 0,
      y: 320,
      ...objClickStyle,
      type: hmUI.data_type.POOL_SWIMMING,
    };
    let objWalk = {
      x: 320,
      y: 320,
      ...objClickStyle,
      type: hmUI.data_type.WALKING,
    };
    let objCalText = {
      x: 178,
      y: 90,
      w: 100,
      type: hmUI.data_type.CAL,
      font_array: arrNorDay,
      align_h: hmUI.align.CENTER_H,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    let objbatteryText = {
      x: 323,
      y: 231,
      w: 95,
      type: hmUI.data_type.BATTERY,
      font_array: arrNorDay,
      align_h: hmUI.align.CENTER_H,
      unit_sc: "images/data_font/per.png",
      unit_tc: "images/data_font/per.png",
      unit_en: "images/data_font/per.png",
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    let objWeatherText = {
      x: 180,
      y: 375,
      w: 95,
      type: hmUI.data_type.WEATHER_CURRENT,
      unit_sc: "images/data_font/du.png",
      unit_tc: "images/data_font/du.png",
      unit_en: "images/data_font/du.png",
      negative_image: "images/data_font/fuhao.png",
      invalid_image: "images/data_font/null.png",
      font_array: arrNorDay,
      align_h: hmUI.align.CENTER_H,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    // let objBatteryLevel = {
    //   x: 318,
    //   y: 175,
    //   image_array: arrBatLine,
    //   image_length: arrBatLine.length,
    //   type: hmUI.data_type.BATTERY,
    //   show_level: hmUI.show_level.ONLY_NORMAL,
    // };
    let objWeatherLevel = {
      x: 207,
      y: 333,
      image_array: arrWeather,
      image_length: arrWeather.length,
      type: hmUI.data_type.WEATHER,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    let color; //卡路里需要绘制的颜色
    let objCalArc = {
      center_x: 228,  // 圆弧中心位置x坐标
      center_y: 85,  // 圆弧中心位置y坐标
      radius: 48,    // 圆弧内半径
      start_angle: 0, // 开始角度
      end_angle: 360,    // 结束角度 (小于'开始角度'时为逆时针)
      line_width: 6,   // 弧形进度条宽度
      corner_flag: 3,   // 可选, 默认0-两端圆角,1-仅起始圆角,2-仅终点圆角,其它值-两端直角
      type: hmUI.data_type.CAL, // 设置数据类型来驱动进度,type和level至少要设置一个.
      // type: hmUI.data_type.BATTERY, // 设置数据类型来驱动进度,type和level至少要设置一个.
    };
    let objBat = {
      center_x: 371,  // 圆弧中心位置x坐标
      center_y: 227,  // 圆弧中心位置y坐标
      radius: 48,    // 圆弧内半径
      start_angle: 0, // 开始角度
      end_angle: -360,    // 结束角度 (小于'开始角度'时为逆时针)
      color: 0x000000,  // 填充色
      line_width: 8,   // 弧形进度条宽度
      corner_flag: 3,   // 可选, 默认0-两端圆角,1-仅起始圆角,2-仅终点圆角,其它值-两端直角
      show_level: hmUI.show_level.ONLY_NORMAL,
    }
    function jumpApp(x, y, type, w = 104, h = 102) {
      hmUI.createWidget(hmUI.widget.IMG_CLICK, {
        x, y, type, w, h,//type必写 跳转的action
        show_level: hmUI.show_level.ONLY_NORMAL,
      });
    }

    function getPointerControl() {
      let pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER, objEditSecondPointer);
      let screenType = hmSetting.getScreenType();
      let aodModel = screenType == hmSetting.screen_type.AOD;
      let pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG, !aodModel);
      hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp);
    }
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        let typeId = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, objEditBg);
        let type = typeId.getProperty(hmUI.prop.CURRENT_TYPE);
        if (type == 1 || type == 5) {
          color = 0xb80000;
        }
        if (type == 2) {
          color = 0x557cc1;
        }
        if (type == 3) {
          color = 0xa77b5a;
        }
        if (type == 4) {
          color = 0x528e5c;
        }
        hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
          ...objCalArc,
          color,  // 填充色
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        hmUI.createWidget(hmUI.widget.IMG, objAodBG);
        hmUI.createWidget(hmUI.widget.IMG_DATE, objDate);
        hmUI.createWidget(hmUI.widget.IMG_WEEK, objWeek);
        hmUI.createWidget(hmUI.widget.TEXT_IMG, objCalText);
        hmUI.createWidget(hmUI.widget.TEXT_IMG, objbatteryText);
        hmUI.createWidget(hmUI.widget.TEXT_IMG, objWeatherText);
      
        let batArc = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, objBat);
        let batterySensor = hmSensor.createSensor(hmSensor.id.BATTERY);

        function setBattery(batterySensor) {
          let batteryCurrent = batterySensor.current;
          // batteryCurrent = 10; //调试
          batArc.setProperty(hmUI.prop.MORE, {
            ...objBat,
            level: 100 - batteryCurrent
          })
        }
        batterySensor.addEventListener(hmSensor.event.CHANGE, function () {
          setBattery(batterySensor)
        })
        hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: (function () {
            setBattery(batterySensor)
              console.log('ui resume');
          }),
          pause_call: (function () {
              console.log('ui pause');
          }),
      });



     
        // hmUI.createWidget(hmUI.widget.IMG_LEVEL, objBatteryLevel);
        hmUI.createWidget(hmUI.widget.IMG_LEVEL, objWeatherLevel);

        let cpIcon = hmUI.createWidget(hmUI.widget.IMG, objCompass);
        hmUI.createWidget(hmUI.widget.IMG_LEVEL, objMoon);
        hmUI.createWidget(hmUI.widget.TIME_POINTER, objPointer);
        hmUI.createWidget(hmUI.widget.TIME_POINTER, objPointerAod);
        getPointerControl();
        cpIcon.addEventListener(hmUI.event.CLICK_UP, function (info) {
          hmApp.startApp({ url: "CompassScreen", native: true });
        });
        hmUI.createWidget(hmUI.widget.IMG_CLICK, objBlke);
        hmUI.createWidget(hmUI.widget.IMG_CLICK, objRun);
        hmUI.createWidget(hmUI.widget.IMG_CLICK, objSwimming);
        hmUI.createWidget(hmUI.widget.IMG_CLICK, objWalk);
        // hmUI.createWidget(hmUI.widget.IMG, objMask);
        hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, objMask);

        //-----------------跳转应用执行----------------
        jumpApp(176, 34, hmUI.data_type.CAL);
        jumpApp(176, 320, hmUI.data_type.WEATHER_CURRENT);
        jumpApp(321, 176, hmUI.data_type.BATTERY);

      },
      onInit() {
        console.log('index page.js on init invoke');
        this.init_view();
      },
      onReady() {
        console.log('index page.js on ready invoke');
      },
      onShow() {
        console.log('index page.js on show invoke');
      },
      onHide() {
        console.log('index page.js on hide invoke');
      },
      onDestory() {
        console.log('index page.js on destory invoke');
      },
    });
  })();
} catch (e) {
  console.log(e);
}
