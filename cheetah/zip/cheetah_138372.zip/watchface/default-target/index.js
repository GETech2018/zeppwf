﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

// Select background (SETTINGS)

    let total_backgrounds = 6
    let background_prefix = "01_bg_"

// Select foreground (SETTINGS)

    let total_foregrounds = 6
    let foreground_prefix = "00_fg_"     
    
// Select color (SETTINGS)

    let total_colors = 6
    let hhss_color_prefix = "02_col_hh_" 

// Select compass (SETTINGS)
    
    let total_compass = 6
    let compass_prefix = "00_compass_ENG_"
    
// Alternate Elements (SETTINGS)

    let top_left_items_count = 3
    let top_right_items_count = 3
    let middle_left_items_count = 4
    let middle_right_items_count = 4    
    let bottom_left_items_count = 3
    let bottom_right_items_count = 3
    
///////////////////////////// NOT EDIT BELOW ///////////////////////////
 
//////////////  Select background (SCRIPTS) ////////////// 

    let background_number = 1

  function up_background() {
  
    if(background_number >= total_backgrounds) {
        background_number = 1;
    }
    else {
        background_number = background_number + 1;
    }

    change_style_bg();
    
  };
  
  function change_style_bg() {
     
    style_color_bg = parseInt(background_number);
   
    normal_background_bg_img.setProperty(hmUI.prop.SRC, background_prefix + style_color_bg + ".png");
    
  };

//////////////  Select foreground (SCRIPT) ////////////// 

    let foreground_number = 1

  function up_foreground() {
  
    if(foreground_number >= total_foregrounds) {
        foreground_number = 1;
    }
    else {
        foreground_number = foreground_number + 1;
    }

    change_style_fg();
    
  };
  
  function change_style_fg() {
     
    style_color_fg = parseInt(foreground_number);
   
    normal_image_img.setProperty(hmUI.prop.SRC, foreground_prefix + style_color_fg + ".png");

  };

//////////////  Select color (SCRIPT) ////////////// 

    let color_number = 1

  function up_color() {
  
    if(color_number >= total_colors) {
        color_number = 1;
    }
    else {
        color_number = color_number + 1;
    }

    change_color();
    
  };
  
  function change_color() {
     
    style_color = parseInt(color_number);
   
    normal_stress_icon_img.setProperty(hmUI.prop.SRC, hhss_color_prefix + style_color + ".png");
    
  };

//////////////  Select compass (SCRIPT) //////////////     

    let compass_number = 1
		
  function up_compass() {
      
    if(compass_number >= total_compass) {
        compass_number = 1;
    }
    else {
        compass_number = compass_number + 1;
    }

    normal_compass_direction_pointer_img.setProperty(hmUI.prop.SRC, compass_prefix + parseInt(compass_number) + ".png");
  
  };
  
/////////////  Compass ON / OFF (SCRIPT) //////////////
  
    let switch_pos_compass = 1
    let total_pos_compass = 2

  function switch_compass() {
        
    if(switch_pos_compass == total_pos_compass) {
       switch_pos_compass = 1; // Compass OFF

       if (compass) {
          normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, true);
          normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, true);
          normal_date_month_separator_img.setProperty(hmUI.prop.VISIBLE, true);
          normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, true);
          
          normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
          
          normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);
          compass.stop();
       }        

    }
    else {
       switch_pos_compass = switch_pos_compass + 1; // Compass ON

       if(switch_pos_compass == 2) {
           if (compass)  {
                normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
                normal_date_month_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, false);                
                 
                normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, true);
                
                compass.start();
           }        
                
       }
    }
        
  }; 
   
//////////////  Alternate Elements (SCRIPTS) //////////////

    let top_left_items_index = 1

  function click_top_left_dial() {
  
    top_left_items_index++;
    if(top_left_items_index > top_left_items_count) top_left_items_index = 1;
    
    normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, top_left_items_index == 1);
    normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, top_left_items_index == 1);
    
    normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, top_left_items_index == 2);
    normal_sun_high_separator_img.setProperty(hmUI.prop.VISIBLE, top_left_items_index == 2);
    
    normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, top_left_items_index == 3);
    normal_sun_low_separator_img.setProperty(hmUI.prop.VISIBLE, top_left_items_index == 3);
    
  };
  
    let top_right_items_index = 1

  function click_top_right_dial() {
  
    top_right_items_index++;
    if(top_right_items_index > top_right_items_count) top_right_items_index = 1;
    
    normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, top_right_items_index == 1);
    normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, top_right_items_index == 1);

    normal_moon_high_text_img.setProperty(hmUI.prop.VISIBLE, top_right_items_index == 2);
    normal_moon_high_separator_img.setProperty(hmUI.prop.VISIBLE, top_right_items_index == 2);

    normal_moon_low_text_img.setProperty(hmUI.prop.VISIBLE, top_right_items_index == 3);
    normal_moon_low_separator_img.setProperty(hmUI.prop.VISIBLE, top_right_items_index == 3);

  }; 
   
    let middle_left_items_index = 1

  function click_middle_left_dial() {
  
    middle_left_items_index++;
    if(middle_left_items_index > middle_left_items_count) middle_left_items_index = 1;
        
    normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, middle_left_items_index == 1);
    normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, middle_left_items_index == 1);    
        
    normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, middle_left_items_index == 2);
    normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, middle_left_items_index == 2);
    
    normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, middle_left_items_index == 3);
    normal_fat_burning_icon_img.setProperty(hmUI.prop.VISIBLE, middle_left_items_index == 3);
    
    normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, middle_left_items_index == 4);
    normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, middle_left_items_index == 4);

  };

    let middle_right_items_index = 1

  function click_middle_right_dial() {
  
    middle_right_items_index++;
    if(middle_right_items_index > middle_right_items_count) middle_right_items_index = 1;
    
    normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, middle_right_items_index == 1);
    normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, middle_right_items_index == 1);
    
    normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, middle_right_items_index == 2);
    normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, middle_right_items_index == 2);
    
    normal_altitude_target_text_img.setProperty(hmUI.prop.VISIBLE, middle_right_items_index == 3);
    normal_altitude_target_separator_img.setProperty(hmUI.prop.VISIBLE, middle_right_items_index == 3);
    
    normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, middle_right_items_index == 4);
    normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, middle_right_items_index == 4);
           
  }; 
  
    let bottom_left_items_index = 1

  function click_bottom_left_dial() {
  
    bottom_left_items_index++;
    if(bottom_left_items_index > bottom_left_items_count) bottom_left_items_index = 1;
    
    normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, bottom_left_items_index == 1);
    normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, bottom_left_items_index == 1);
    
    normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, bottom_left_items_index == 2);
    normal_temperature_low_separator_img.setProperty(hmUI.prop.VISIBLE, bottom_left_items_index == 2);
    
    normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, bottom_left_items_index == 3);
    normal_temperature_high_separator_img.setProperty(hmUI.prop.VISIBLE, bottom_left_items_index == 3);

  };
  
    let bottom_right_items_index = 1

  function click_bottom_right_dial() {
  
    bottom_right_items_index++;
    if(bottom_right_items_index > bottom_right_items_count) bottom_right_items_index = 1;

    normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, bottom_right_items_index == 1);    
    normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, bottom_right_items_index == 1);
    normal_uvi_text_separator_img.setProperty(hmUI.prop.VISIBLE, bottom_right_items_index == 1);
   
    normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, bottom_right_items_index == 2);
    normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, bottom_right_items_index == 2);
    normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, bottom_right_items_index == 2);   
    
    normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, bottom_right_items_index == 3);
    normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, bottom_right_items_index == 3);
    normal_humidity_text_separator_img.setProperty(hmUI.prop.VISIBLE, bottom_right_items_index == 3);

  }; 
        
////////////////////////////////////////////////////////////////////////////////  

        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_pai_icon_img = ''
        let normal_stress_icon_img = ''
        let normal_compass_direction_pointer_img = ''
        let normal_compass_text_img = ''
        let normal_date_img_date_month = ''
        let normal_date_month_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_altitude_target_text_img = ''
        let normal_altitude_target_separator_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_altimeter_text_separator_img = ''
        let normal_distance_icon_img = ''
        let normal_distance_text_text_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_high_separator_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_low_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_current_separator_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_stand_icon_img = ''
        let normal_stand_current_text_img = ''
        let normal_fat_burning_icon_img = ''
        let normal_fat_burning_current_text_img = ''
        let normal_spo2_icon_img = ''
        let normal_spo2_text_text_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_humidity_icon_img = ''
        let normal_humidity_text_text_img = ''
        let normal_humidity_text_separator_img = ''
        let normal_wind_icon_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_text_text_img = ''
        let normal_uvi_icon_img = ''
        let normal_uvi_text_text_img = ''
        let normal_uvi_text_separator_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_high_separator_img = ''
        let normal_sun_low_text_img = ''
        let normal_sun_low_separator_img = ''
        let normal_moon_high_text_img = ''
        let normal_moon_high_separator_img = ''
        let normal_moon_low_text_img = ''
        let normal_moon_low_separator_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let idle_background_bg_img = ''
        let idle_pai_icon_img = ''
        let idle_stress_icon_img = ''
        let idle_date_img_date_month = ''
        let idle_date_month_separator_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_temperature_current_text_img = ''
        let idle_temperature_current_separator_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_step_icon_img = ''
        let idle_step_current_text_img = ''
        let idle_calorie_icon_img = ''
        let idle_calorie_current_text_img = ''
        let idle_uvi_icon_img = ''
        let idle_uvi_text_text_img = ''
        let idle_uvi_text_separator_img = ''
        let idle_heart_rate_icon_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_battery_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_digital_clock_img_time = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_image_img = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '01_bg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '00_fg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '00_fg_normal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '02_col_hh_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            
            // normal_compass_custom_pointer_img = hmUI.createWidget(hmUI.widget.CUSTOM_POINTER, {
              // src: '00_compass_ENG_1.png',
              // center_x: 227,
              // center_y: 227,
              // x: 227,
              // y: 227,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.COMPASS,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            //start of ignored block
            normal_compass_direction_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 227,
              pos_y: 227 - 227,
              center_x: 227,
              center_y: 227,
              src: '00_compass_ENG_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            //end of ignored block

            normal_compass_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 184,
              y: 48,
              font_array: ["03_M_0.png","03_M_1.png","03_M_2.png","03_M_3.png","03_M_4.png","03_M_5.png","03_M_6.png","03_M_7.png","03_M_8.png","03_M_9.png"],
              padding: true,
              h_space: -1,
              unit_sc: '10_degree.png',
              unit_tc: '10_degree.png',
              unit_en: '10_degree.png',
              negative_image: '10_null.png',
              align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.COMPASS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 217,
              month_startY: 48,
              month_sc_array: ["03_M_0.png","03_M_1.png","03_M_2.png","03_M_3.png","03_M_4.png","03_M_5.png","03_M_6.png","03_M_7.png","03_M_8.png","03_M_9.png"],
              month_tc_array: ["03_M_0.png","03_M_1.png","03_M_2.png","03_M_3.png","03_M_4.png","03_M_5.png","03_M_6.png","03_M_7.png","03_M_8.png","03_M_9.png"],
              month_en_array: ["03_M_0.png","03_M_1.png","03_M_2.png","03_M_3.png","03_M_4.png","03_M_5.png","03_M_6.png","03_M_7.png","03_M_8.png","03_M_9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 255,
              y: 48,
              src: '10_slash_M.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 278,
              day_startY: 48,
              day_sc_array: ["03_M_0.png","03_M_1.png","03_M_2.png","03_M_3.png","03_M_4.png","03_M_5.png","03_M_6.png","03_M_7.png","03_M_8.png","03_M_9.png"],
              day_tc_array: ["03_M_0.png","03_M_1.png","03_M_2.png","03_M_3.png","03_M_4.png","03_M_5.png","03_M_6.png","03_M_7.png","03_M_8.png","03_M_9.png"],
              day_en_array: ["03_M_0.png","03_M_1.png","03_M_2.png","03_M_3.png","03_M_4.png","03_M_5.png","03_M_6.png","03_M_7.png","03_M_8.png","03_M_9.png"],
              day_zero: 1,
              day_space: -1,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 144,
              y: 48,
              week_en: ["08_wd_ENG_1.png","08_wd_ENG_2.png","08_wd_ENG_3.png","08_wd_ENG_4.png","08_wd_ENG_5.png","08_wd_ENG_6.png","08_wd_ENG_7.png"],
              week_tc: ["08_wd_ENG_1.png","08_wd_ENG_2.png","08_wd_ENG_3.png","08_wd_ENG_4.png","08_wd_ENG_5.png","08_wd_ENG_6.png","08_wd_ENG_7.png"],
              week_sc: ["08_wd_ENG_1.png","08_wd_ENG_2.png","08_wd_ENG_3.png","08_wd_ENG_4.png","08_wd_ENG_5.png","08_wd_ENG_6.png","08_wd_ENG_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 340,
              y: 207,
              font_array: ["03_M_0.png","03_M_1.png","03_M_2.png","03_M_3.png","03_M_4.png","03_M_5.png","03_M_6.png","03_M_7.png","03_M_8.png","03_M_9.png"],
              padding: false,
              h_space: -2,
              negative_image: '10_dash.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 297,
              y: 206,
              src: '10_alt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 340,
              y: 207,
              font_array: ["03_M_0.png","03_M_1.png","03_M_2.png","03_M_3.png","03_M_4.png","03_M_5.png","03_M_6.png","03_M_7.png","03_M_8.png","03_M_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 297,
              y: 206,
              src: '10_baro.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 297,
              y: 206,
              src: '10_dist.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 340,
              y: 207,
              font_array: ["03_M_0.png","03_M_1.png","03_M_2.png","03_M_3.png","03_M_4.png","03_M_5.png","03_M_6.png","03_M_7.png","03_M_8.png","03_M_9.png"],
              padding: false,
              h_space: -2,
              dot_image: '10_dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 54,
              y: 279,
              font_array: ["03_M_0.png","03_M_1.png","03_M_2.png","03_M_3.png","03_M_4.png","03_M_5.png","03_M_6.png","03_M_7.png","03_M_8.png","03_M_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: '10_degree.png',
              unit_tc: '10_degree.png',
              unit_en: '10_degree.png',
              negative_image: '10_dash.png',
              invalid_image: '10_null.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 115,
              y: 278,
              src: '10_temp_MAX.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 54,
              y: 279,
              font_array: ["03_M_0.png","03_M_1.png","03_M_2.png","03_M_3.png","03_M_4.png","03_M_5.png","03_M_6.png","03_M_7.png","03_M_8.png","03_M_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: '10_degree.png',
              unit_tc: '10_degree.png',
              unit_en: '10_degree.png',
              negative_image: '10_dash.png',
              invalid_image: '10_null.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 115,
              y: 278,
              src: '10_temp_MIN.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 54,
              y: 279,
              font_array: ["03_M_0.png","03_M_1.png","03_M_2.png","03_M_3.png","03_M_4.png","03_M_5.png","03_M_6.png","03_M_7.png","03_M_8.png","03_M_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: '10_degree.png',
              unit_tc: '10_degree.png',
              unit_en: '10_degree.png',
              negative_image: '10_dash.png',
              invalid_image: '10_null.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 115,
              y: 278,
              src: '10_temp.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 114,
              y: 340,
              image_array: ["09_weather_01.png","09_weather_02.png","09_weather_03.png","09_weather_04.png","09_weather_05.png","09_weather_06.png","09_weather_07.png","09_weather_08.png","09_weather_09.png","09_weather_10.png","09_weather_11.png","09_weather_12.png","09_weather_13.png","09_weather_14.png","09_weather_15.png","09_weather_16.png","09_weather_17.png","09_weather_18.png","09_weather_19.png","09_weather_20.png","09_weather_21.png","09_weather_22.png","09_weather_23.png","09_weather_24.png","09_weather_25.png","09_weather_26.png","09_weather_27.png","09_weather_28.png","09_weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 297,
              y: 206,
              src: '10_steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 340,
              y: 207,
              font_array: ["03_M_0.png","03_M_1.png","03_M_2.png","03_M_3.png","03_M_4.png","03_M_5.png","03_M_6.png","03_M_7.png","03_M_8.png","03_M_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 115,
              y: 206,
              src: '10_stand.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 49,
              y: 207,
              font_array: ["03_M_0.png","03_M_1.png","03_M_2.png","03_M_3.png","03_M_4.png","03_M_5.png","03_M_6.png","03_M_7.png","03_M_8.png","03_M_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 115,
              y: 206,
              src: '10_fat_burn.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 62,
              y: 207,
              font_array: ["03_M_0.png","03_M_1.png","03_M_2.png","03_M_3.png","03_M_4.png","03_M_5.png","03_M_6.png","03_M_7.png","03_M_8.png","03_M_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 115,
              y: 206,
              src: '10_SPO2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 33,
              y: 207,
              font_array: ["03_M_0.png","03_M_1.png","03_M_2.png","03_M_3.png","03_M_4.png","03_M_5.png","03_M_6.png","03_M_7.png","03_M_8.png","03_M_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: '10_percent.png',
              unit_tc: '10_percent.png',
              unit_en: '10_percent.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 115,
              y: 206,
              src: '10_cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 47,
              y: 207,
              font_array: ["03_M_0.png","03_M_1.png","03_M_2.png","03_M_3.png","03_M_4.png","03_M_5.png","03_M_6.png","03_M_7.png","03_M_8.png","03_M_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 297,
              y: 278,
              src: '10_hum.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 340,
              y: 279,
              font_array: ["03_M_0.png","03_M_1.png","03_M_2.png","03_M_3.png","03_M_4.png","03_M_5.png","03_M_6.png","03_M_7.png","03_M_8.png","03_M_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: '10_percent.png',
              unit_tc: '10_percent.png',
              unit_en: '10_percent.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '10_empty.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 297,
              y: 278,
              src: '10_wind.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 375,
              y: 281,
              image_array: ["11_wind_1.png","11_wind_2.png","11_wind_3.png","11_wind_4.png","11_wind_5.png","11_wind_6.png","11_wind_7.png","11_wind_8.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 336,
              y: 279,
              font_array: ["03_M_0.png","03_M_1.png","03_M_2.png","03_M_3.png","03_M_4.png","03_M_5.png","03_M_6.png","03_M_7.png","03_M_8.png","03_M_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 297,
              y: 278,
              src: '10_uv.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 340,
              y: 279,
              font_array: ["03_M_0.png","03_M_1.png","03_M_2.png","03_M_3.png","03_M_4.png","03_M_5.png","03_M_6.png","03_M_7.png","03_M_8.png","03_M_9.png"],
              padding: false,
              h_space: -2,
              invalid_image: '10_null.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '10_empty.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 115,
              y: 134,
              src: '10_bpm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 64,
              y: 135,
              font_array: ["03_M_0.png","03_M_1.png","03_M_2.png","03_M_3.png","03_M_4.png","03_M_5.png","03_M_6.png","03_M_7.png","03_M_8.png","03_M_9.png"],
              padding: false,
              h_space: -2,
              invalid_image: '10_null.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 25,
              y: 135,
              font_array: ["03_M_0.png","03_M_1.png","03_M_2.png","03_M_3.png","03_M_4.png","03_M_5.png","03_M_6.png","03_M_7.png","03_M_8.png","03_M_9.png"],
              padding: false,
              h_space: -2,
              invalid_image: '10_null.png',
              dot_image: '10_separator_M.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 115,
              y: 134,
              src: '10_sunrise.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 25,
              y: 135,
              font_array: ["03_M_0.png","03_M_1.png","03_M_2.png","03_M_3.png","03_M_4.png","03_M_5.png","03_M_6.png","03_M_7.png","03_M_8.png","03_M_9.png"],
              padding: false,
              h_space: -2,
              invalid_image: '10_null.png',
              dot_image: '10_separator_M.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 115,
              y: 134,
              src: '10_sunset.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 340,
              y: 135,
              font_array: ["03_M_0.png","03_M_1.png","03_M_2.png","03_M_3.png","03_M_4.png","03_M_5.png","03_M_6.png","03_M_7.png","03_M_8.png","03_M_9.png"],
              padding: false,
              h_space: -2,
              invalid_image: '10_null.png',
              dot_image: '10_separator_M.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.MOON_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 297,
              y: 134,
              src: '10_moonrise.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 340,
              y: 135,
              font_array: ["03_M_0.png","03_M_1.png","03_M_2.png","03_M_3.png","03_M_4.png","03_M_5.png","03_M_6.png","03_M_7.png","03_M_8.png","03_M_9.png"],
              padding: false,
              h_space: -2,
              invalid_image: '10_null.png',
              dot_image: '10_separator_M.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.MOON_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 297,
              y: 134,
              src: '10_moonset.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 297,
              y: 346,
              image_array: ["12_moon_01.png","12_moon_02.png","12_moon_03.png","12_moon_04.png","12_moon_05.png","12_moon_06.png","12_moon_07.png","12_moon_08.png","12_moon_09.png","12_moon_10.png","12_moon_11.png","12_moon_12.png","12_moon_13.png","12_moon_14.png","12_moon_15.png","12_moon_16.png","12_moon_17.png","12_moon_18.png","12_moon_19.png","12_moon_20.png","12_moon_21.png","12_moon_22.png","12_moon_23.png","12_moon_24.png","12_moon_25.png","12_moon_26.png","12_moon_27.png","12_moon_28.png","12_moon_29.png","12_moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 297,
              y: 134,
              src: '10_batt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 340,
              y: 135,
              font_array: ["03_M_0.png","03_M_1.png","03_M_2.png","03_M_3.png","03_M_4.png","03_M_5.png","03_M_6.png","03_M_7.png","03_M_8.png","03_M_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: '10_percent.png',
              unit_tc: '10_percent.png',
              unit_en: '10_percent.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 177,
              hour_startY: 125,
              hour_array: ["02_hhmm_0.png","02_hhmm_1.png","02_hhmm_2.png","02_hhmm_3.png","02_hhmm_4.png","02_hhmm_5.png","02_hhmm_6.png","02_hhmm_7.png","02_hhmm_8.png","02_hhmm_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 177,
              minute_startY: 239,
              minute_array: ["02_hhmm_0.png","02_hhmm_1.png","02_hhmm_2.png","02_hhmm_3.png","02_hhmm_4.png","02_hhmm_5.png","02_hhmm_6.png","02_hhmm_7.png","02_hhmm_8.png","02_hhmm_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 197,
              second_startY: 357,
              second_array: ["02_ss_0.png","02_ss_1.png","02_ss_2.png","02_ss_3.png","02_ss_4.png","02_ss_5.png","02_ss_6.png","02_ss_7.png","02_ss_8.png","02_ss_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 332,
              y: 89,
              src: '10_BT_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 97,
              y: 89,
              src: '10_AL_on.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '01_bg_6.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '00_fg_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '02_col_hh_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 217,
              month_startY: 48,
              month_sc_array: ["03_M_0.png","03_M_1.png","03_M_2.png","03_M_3.png","03_M_4.png","03_M_5.png","03_M_6.png","03_M_7.png","03_M_8.png","03_M_9.png"],
              month_tc_array: ["03_M_0.png","03_M_1.png","03_M_2.png","03_M_3.png","03_M_4.png","03_M_5.png","03_M_6.png","03_M_7.png","03_M_8.png","03_M_9.png"],
              month_en_array: ["03_M_0.png","03_M_1.png","03_M_2.png","03_M_3.png","03_M_4.png","03_M_5.png","03_M_6.png","03_M_7.png","03_M_8.png","03_M_9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 255,
              y: 48,
              src: '10_slash_M.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 278,
              day_startY: 48,
              day_sc_array: ["03_M_0.png","03_M_1.png","03_M_2.png","03_M_3.png","03_M_4.png","03_M_5.png","03_M_6.png","03_M_7.png","03_M_8.png","03_M_9.png"],
              day_tc_array: ["03_M_0.png","03_M_1.png","03_M_2.png","03_M_3.png","03_M_4.png","03_M_5.png","03_M_6.png","03_M_7.png","03_M_8.png","03_M_9.png"],
              day_en_array: ["03_M_0.png","03_M_1.png","03_M_2.png","03_M_3.png","03_M_4.png","03_M_5.png","03_M_6.png","03_M_7.png","03_M_8.png","03_M_9.png"],
              day_zero: 1,
              day_space: -1,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 144,
              y: 48,
              week_en: ["08_wd_ENG_1.png","08_wd_ENG_2.png","08_wd_ENG_3.png","08_wd_ENG_4.png","08_wd_ENG_5.png","08_wd_ENG_6.png","08_wd_ENG_7.png"],
              week_tc: ["08_wd_ENG_1.png","08_wd_ENG_2.png","08_wd_ENG_3.png","08_wd_ENG_4.png","08_wd_ENG_5.png","08_wd_ENG_6.png","08_wd_ENG_7.png"],
              week_sc: ["08_wd_ENG_1.png","08_wd_ENG_2.png","08_wd_ENG_3.png","08_wd_ENG_4.png","08_wd_ENG_5.png","08_wd_ENG_6.png","08_wd_ENG_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 54,
              y: 279,
              font_array: ["03_M_0.png","03_M_1.png","03_M_2.png","03_M_3.png","03_M_4.png","03_M_5.png","03_M_6.png","03_M_7.png","03_M_8.png","03_M_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: '10_degree.png',
              unit_tc: '10_degree.png',
              unit_en: '10_degree.png',
              negative_image: '10_dash.png',
              invalid_image: '10_null.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 115,
              y: 278,
              src: '10_temp.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 114,
              y: 340,
              image_array: ["09_weather_01.png","09_weather_02.png","09_weather_03.png","09_weather_04.png","09_weather_05.png","09_weather_06.png","09_weather_07.png","09_weather_08.png","09_weather_09.png","09_weather_10.png","09_weather_11.png","09_weather_12.png","09_weather_13.png","09_weather_14.png","09_weather_15.png","09_weather_16.png","09_weather_17.png","09_weather_18.png","09_weather_19.png","09_weather_20.png","09_weather_21.png","09_weather_22.png","09_weather_23.png","09_weather_24.png","09_weather_25.png","09_weather_26.png","09_weather_27.png","09_weather_28.png","09_weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 297,
              y: 206,
              src: '10_steps.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 340,
              y: 207,
              font_array: ["03_M_0.png","03_M_1.png","03_M_2.png","03_M_3.png","03_M_4.png","03_M_5.png","03_M_6.png","03_M_7.png","03_M_8.png","03_M_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 115,
              y: 206,
              src: '10_cal.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 47,
              y: 207,
              font_array: ["03_M_0.png","03_M_1.png","03_M_2.png","03_M_3.png","03_M_4.png","03_M_5.png","03_M_6.png","03_M_7.png","03_M_8.png","03_M_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_uvi_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 297,
              y: 278,
              src: '10_uv.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 340,
              y: 279,
              font_array: ["03_M_0.png","03_M_1.png","03_M_2.png","03_M_3.png","03_M_4.png","03_M_5.png","03_M_6.png","03_M_7.png","03_M_8.png","03_M_9.png"],
              padding: false,
              h_space: -2,
              invalid_image: '10_null.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_uvi_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '10_empty.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 115,
              y: 134,
              src: '10_bpm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 64,
              y: 135,
              font_array: ["03_M_0.png","03_M_1.png","03_M_2.png","03_M_3.png","03_M_4.png","03_M_5.png","03_M_6.png","03_M_7.png","03_M_8.png","03_M_9.png"],
              padding: false,
              h_space: -2,
              invalid_image: '10_null.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 297,
              y: 346,
              image_array: ["12_moon_01.png","12_moon_02.png","12_moon_03.png","12_moon_04.png","12_moon_05.png","12_moon_06.png","12_moon_07.png","12_moon_08.png","12_moon_09.png","12_moon_10.png","12_moon_11.png","12_moon_12.png","12_moon_13.png","12_moon_14.png","12_moon_15.png","12_moon_16.png","12_moon_17.png","12_moon_18.png","12_moon_19.png","12_moon_20.png","12_moon_21.png","12_moon_22.png","12_moon_23.png","12_moon_24.png","12_moon_25.png","12_moon_26.png","12_moon_27.png","12_moon_28.png","12_moon_29.png","12_moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 297,
              y: 134,
              src: '10_batt.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 340,
              y: 135,
              font_array: ["03_M_0.png","03_M_1.png","03_M_2.png","03_M_3.png","03_M_4.png","03_M_5.png","03_M_6.png","03_M_7.png","03_M_8.png","03_M_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: '10_percent.png',
              unit_tc: '10_percent.png',
              unit_en: '10_percent.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 177,
              hour_startY: 125,
              hour_array: ["02_hhmm_0.png","02_hhmm_1.png","02_hhmm_2.png","02_hhmm_3.png","02_hhmm_4.png","02_hhmm_5.png","02_hhmm_6.png","02_hhmm_7.png","02_hhmm_8.png","02_hhmm_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 177,
              minute_startY: 239,
              minute_array: ["02_hhmm_0.png","02_hhmm_1.png","02_hhmm_2.png","02_hhmm_3.png","02_hhmm_4.png","02_hhmm_5.png","02_hhmm_6.png","02_hhmm_7.png","02_hhmm_8.png","02_hhmm_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 197,
              second_startY: 357,
              second_array: ["02_ss_0.png","02_ss_1.png","02_ss_2.png","02_ss_3.png","02_ss_4.png","02_ss_5.png","02_ss_6.png","02_ss_7.png","02_ss_8.png","02_ss_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 332,
              y: 89,
              src: '10_BT_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 97,
              y: 89,
              src: '10_AL_on.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '00_fg_6.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 55,
              y: 270,
              w: 105,
              h: 60,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                click_bottom_left_dial()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 295,
              y: 270,
              w: 105,
              h: 60,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                click_bottom_right_dial()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 55,
              y: 124,
              w: 105,
              h: 60,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                click_top_left_dial()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 40,
              y: 197,
              w: 120,
              h: 60,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                click_middle_left_dial()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 295,
              y: 124,
              w: 105,
              h: 60,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                click_top_right_dial()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 295,
              y: 197,
              w: 120,
              h: 60,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                click_middle_right_dial()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 153,
              y: 35,
              w: 150,
              h: 65,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                switch_compass()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 182,
              y: 172,
              w: 90,
              h: 110,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                up_color()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 187,
              y: 347,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                up_background()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 287,
              y: 337,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                up_foreground()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 108,
              y: 337,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                up_compass()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

////////////  Initial visibility of elements //////////// 

    let cc = 0

    if (cc == 0 ){
    
 // TOP CENTER
     
    normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, true);
    normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, true);
    normal_date_month_separator_img.setProperty(hmUI.prop.VISIBLE, true);
    normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, true);
 
    normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
 
 // TOP LEFT

    normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
    normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, true);
    
    normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_sun_high_separator_img.setProperty(hmUI.prop.VISIBLE, false);
    
    normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_sun_low_separator_img.setProperty(hmUI.prop.VISIBLE, false);

 // TOP RIGHT
 
    normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
    normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, true);

    normal_moon_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_moon_high_separator_img.setProperty(hmUI.prop.VISIBLE, false);

    normal_moon_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_moon_low_separator_img.setProperty(hmUI.prop.VISIBLE, false);
 
    
 // MIDDLE LEFT

    normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
    normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, true);

    normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, false);
    
    normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_fat_burning_icon_img.setProperty(hmUI.prop.VISIBLE, false);
    
    normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, false);

 // MIDDLE RIGHT

    normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
    normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);
    
    normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
    
    normal_altitude_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_altitude_target_separator_img.setProperty(hmUI.prop.VISIBLE, false);
    
    normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
    
 // BOTTOM LEFT

    normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
    normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
    
    normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_temperature_low_separator_img.setProperty(hmUI.prop.VISIBLE, false);
    
    normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_temperature_high_separator_img.setProperty(hmUI.prop.VISIBLE, false);

 // BOTTOM RIGHT

    normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE,true);    
    normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, true);
    normal_uvi_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
   
    normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);   
    
    normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_humidity_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);    
   
    cc = 1;

    };

/////////////////////////////////////////////////////////////////////////////////////////////////

            // end user_script_end.js

            let screenType = hmSetting.getScreenType();
            //start of ignored block
            console.log('compass_update()');
            if (screenType == hmSetting.screen_type.WATCHFACE){
              compass = hmSensor.createSensor(hmSensor.id.COMPASS);
              compass.start();

              if (compass.direction_angle && compass.direction  && compass.direction_angle != 'INVALID') { // initial data
                // Compass Pointer
                let compass_direction_angle = parseInt(compass.direction_angle);
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);
                // Compass Number
                let normal_compass_direction_angle_text = compass_direction_angle.toString().padStart(3, '0');
                normal_compass_text_img.setProperty(hmUI.prop.TEXT, normal_compass_direction_angle_text);

              } else { // error data
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);
                normal_compass_text_img.setProperty(hmUI.prop.TEXT, '-');

              }

              compass.addEventListener(hmSensor.event.CHANGE, function (compass_res) { // change values when changing direction

                if (compass_res.calibration_status) {
                  // Compass Pointer
                  let compass_direction_angle = parseInt(compass_res.direction_angle);
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);
                  // Compass Number
                  let normal_compass_direction_angle_text = compass_direction_angle.toString().padStart(3, '0');
                  normal_compass_text_img.setProperty(hmUI.prop.TEXT, normal_compass_direction_angle_text);

                } else { // error data
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);
                  normal_compass_text_img.setProperty(hmUI.prop.TEXT, '-');

                }

              }); // Listener end              normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);              //normal_compass_text_img.setProperty(hmUI.prop.TEXT, '000');              compass.stop();

            };
            //end of ignored block

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                if(switch_pos_compass == 2) {if (compass && screenType == hmSetting.screen_type.WATCHFACE) compass.start()};

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if(switch_pos_compass == 2) {if (compass && screenType == hmSetting.screen_type.WATCHFACE) compass.start()};

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}