try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 390,
                    h: 450,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                    x: 187,
                    y: 169,
                    anim_path: '',
                    anim_prefix: 'first_anim_sjcwa',
                    anim_ext: 'png',
                    anim_fps: 1,
                    anim_size: 2,
                    display_on_restart: false,
                    repeat_count: 0,
                    anim_status: hmUI.anim_status.START,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                    x: 142,
                    y: 343,
                    anim_path: '',
                    anim_prefix: 'second_anim_sxmlm',
                    anim_ext: 'png',
                    anim_fps: 1,
                    anim_size: 60,
                    display_on_restart: false,
                    repeat_count: 0,
                    anim_status: hmUI.anim_status.START,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_val: new Date().getHours(),
                    hour_zero: 1,
                    hour_startX: 28,
                    hour_startY: 148,
                    hour_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    hour_space: 0,
                    hour_align: hmUI.align.CENTER_H,
                    minute_zero: 1,
                    minute_startX: 222,
                    minute_startY: 148,
                    minute_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    minute_space: 0,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    second_val: new Date().getSeconds(),
                    second_zero: 0,
                    second_startX: 182,
                    second_startY: 386,
                    second_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    second_space: 0,
                    second_align: hmUI.align.CENTER_H,
                    second_follow: 0,
                    am_x: 186,
                    am_y: 185,
                    am_sc_path: '23.png',
                    am_en_path: '24.png',
                    pm_x: 186,
                    pm_y: 185,
                    pm_sc_path: '25.png',
                    pm_en_path: '26.png',
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    year_startX: 168,
                    year_startY: 106,
                    year_sc_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    year_tc_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    year_en_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    year_align: hmUI.align.CENTER_H,
                    year_zero: 1,
                    year_space: 0,
                    year_is_character: false,
                    month_startX: 275,
                    month_startY: 15,
                    month_en_array: [
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png'
                    ],
                    month_align: hmUI.align.LEFT,
                    month_zero: 0,
                    month_follow: 0,
                    month_space: 0,
                    month_is_character: true,
                    day_startX: 66,
                    day_startY: 15,
                    day_sc_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    day_tc_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    day_en_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    day_align: hmUI.align.CENTER_H,
                    day_zero: 0,
                    day_follow: 0,
                    day_space: 0,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 104,
                    y: 58,
                    week_en: [
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png'
                    ],
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 18,
                    y: 302,
                    image_array: [
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png'
                    ],
                    image_length: 6,
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 45,
                    y: 340,
                    type: hmUI.data_type.HEART,
                    font_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '52.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 64,
                    y: 389,
                    src: '53.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 265,
                    y: 299,
                    image_array: [
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png',
                        '58.png',
                        '59.png',
                        '60.png',
                        '61.png',
                        '62.png',
                        '63.png',
                        '64.png'
                    ],
                    image_length: 11,
                    type: hmUI.data_type.CAL,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 289,
                    y: 340,
                    type: hmUI.data_type.CAL,
                    font_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '65.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 303,
                    y: 389,
                    src: '66.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 207,
                    y: 292,
                    type: hmUI.data_type.STEP_TARGET,
                    font_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: -2,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '67.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 132,
                    y: 292,
                    type: hmUI.data_type.STEP,
                    font_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: -2,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '69.png',
                    unit_tc: '69.png',
                    unit_en: '69.png',
                    invalid_image: '68.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 120,
                    y: 292,
                    src: '70.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 335,
                    y: 54,
                    src: '71.png',
                    type: hmUI.system_status.DISCONNECT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 54,
                    y: 53,
                    src: '72.png',
                    type: hmUI.system_status.DISTURB,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 318,
                    y: 52,
                    src: '73.png',
                    type: hmUI.system_status.LOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 34,
                    y: 53,
                    src: '74.png',
                    type: hmUI.system_status.CLOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 155,
                    y: 313,
                    type: hmUI.data_type.DISTANCE,
                    font_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '77.png',
                    unit_tc: '77.png',
                    unit_en: '77.png',
                    imperial_unit_sc: '78.png',
                    imperial_unit_tc: '78.png',
                    imperial_unit_en: '78.png',
                    dot_image: '76.png',
                    invalid_image: '75.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 120,
                    y: 313,
                    src: '79.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 218,
                    y: 6,
                    image_array: [
                        '80.png',
                        '81.png',
                        '82.png',
                        '83.png',
                        '84.png',
                        '85.png',
                        '86.png',
                        '87.png',
                        '88.png',
                        '89.png',
                        '90.png',
                        '91.png',
                        '92.png',
                        '93.png',
                        '94.png',
                        '95.png',
                        '96.png',
                        '97.png',
                        '98.png',
                        '99.png',
                        '100.png',
                        '101.png',
                        '102.png',
                        '103.png',
                        '104.png',
                        '105.png',
                        '106.png',
                        '107.png',
                        '108.png'
                    ],
                    image_length: 29,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 199,
                    y: 27,
                    type: hmUI.data_type.HUMIDITY,
                    font_array: [
                        '109.png',
                        '110.png',
                        '111.png',
                        '112.png',
                        '113.png',
                        '114.png',
                        '115.png',
                        '116.png',
                        '117.png',
                        '118.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: -4,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '120.png',
                    unit_tc: '120.png',
                    unit_en: '120.png',
                    invalid_image: '119.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 45,
                    y: 96,
                    type: hmUI.data_type.SUN_RISE,
                    font_array: [
                        '109.png',
                        '110.png',
                        '111.png',
                        '112.png',
                        '113.png',
                        '114.png',
                        '115.png',
                        '116.png',
                        '117.png',
                        '118.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -3,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    dot_image: '122.png',
                    invalid_image: '121.png',
                    padding: true,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 105,
                    y: 95,
                    w: 29,
                    h: 22,
                    src: '123.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 45,
                    y: 124,
                    type: hmUI.data_type.SUN_SET,
                    font_array: [
                        '109.png',
                        '110.png',
                        '111.png',
                        '112.png',
                        '113.png',
                        '114.png',
                        '115.png',
                        '116.png',
                        '117.png',
                        '118.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -3,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    dot_image: '125.png',
                    invalid_image: '124.png',
                    padding: true,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 105,
                    y: 122,
                    w: 29,
                    h: 22,
                    src: '126.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 0,
                    y: 165,
                    image_array: [
                        '127.png',
                        '128.png',
                        '129.png',
                        '130.png',
                        '131.png',
                        '132.png',
                        '133.png',
                        '134.png',
                        '135.png',
                        '136.png'
                    ],
                    image_length: 10,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 169,
                    y: 230,
                    type: hmUI.data_type.BATTERY,
                    font_array: [
                        '109.png',
                        '110.png',
                        '111.png',
                        '112.png',
                        '113.png',
                        '114.png',
                        '115.png',
                        '116.png',
                        '117.png',
                        '118.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: -3,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '137.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 206,
                    y: 230,
                    w: 15,
                    h: 20,
                    src: '138.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 173,
                    y: 15,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: -2,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '141.png',
                    unit_tc: '141.png',
                    unit_en: '141.png',
                    negative_image: '140.png',
                    invalid_image: '139.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 140,
                    y: 5,
                    type: hmUI.data_type.WEATHER_HIGH,
                    font_array: [
                        '109.png',
                        '110.png',
                        '111.png',
                        '112.png',
                        '113.png',
                        '114.png',
                        '115.png',
                        '116.png',
                        '117.png',
                        '118.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: -5,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '144.png',
                    unit_tc: '144.png',
                    unit_en: '144.png',
                    negative_image: '143.png',
                    invalid_image: '142.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 175,
                    y: 8,
                    w: 11,
                    h: 11,
                    src: '145.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 140,
                    y: 28,
                    type: hmUI.data_type.WEATHER_LOW,
                    font_array: [
                        '109.png',
                        '110.png',
                        '111.png',
                        '112.png',
                        '113.png',
                        '114.png',
                        '115.png',
                        '116.png',
                        '117.png',
                        '118.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: -5,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '148.png',
                    unit_tc: '148.png',
                    unit_en: '148.png',
                    negative_image: '147.png',
                    invalid_image: '146.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 175,
                    y: 34,
                    w: 11,
                    h: 11,
                    src: '149.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 277,
                    y: 117,
                    type: hmUI.data_type.ALTIMETER,
                    font_array: [
                        '109.png',
                        '110.png',
                        '111.png',
                        '112.png',
                        '113.png',
                        '114.png',
                        '115.png',
                        '116.png',
                        '117.png',
                        '118.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: -3,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '151.png',
                    unit_tc: '151.png',
                    unit_en: '151.png',
                    invalid_image: '150.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 259,
                    y: 116,
                    w: 21,
                    h: 18,
                    src: '152.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 300,
                    y: 93,
                    type: hmUI.data_type.WIND,
                    font_array: [
                        '109.png',
                        '110.png',
                        '111.png',
                        '112.png',
                        '113.png',
                        '114.png',
                        '115.png',
                        '116.png',
                        '117.png',
                        '118.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: -3,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '154.png',
                    unit_tc: '154.png',
                    unit_en: '154.png',
                    invalid_image: '153.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 255,
                    y: 93,
                    w: 30,
                    h: 18,
                    src: '155.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 390,
                    h: 450,
                    src: '156.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_val: new Date().getHours(),
                    hour_zero: 1,
                    hour_startX: 28,
                    hour_startY: 148,
                    hour_array: [
                        '157.png',
                        '158.png',
                        '159.png',
                        '160.png',
                        '161.png',
                        '162.png',
                        '163.png',
                        '164.png',
                        '165.png',
                        '166.png'
                    ],
                    hour_space: 0,
                    hour_align: hmUI.align.CENTER_H,
                    minute_zero: 1,
                    minute_startX: 222,
                    minute_startY: 148,
                    minute_array: [
                        '157.png',
                        '158.png',
                        '159.png',
                        '160.png',
                        '161.png',
                        '162.png',
                        '163.png',
                        '164.png',
                        '165.png',
                        '166.png'
                    ],
                    minute_space: 0,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 43,
                    y: 326,
                    w: 50,
                    h: 50,
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 292,
                    y: 326,
                    w: 50,
                    h: 50,
                    type: hmUI.data_type.CAL,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 118,
                    y: 291,
                    w: 152,
                    h: 21,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 118,
                    y: 313,
                    w: 152,
                    h: 21,
                    type: hmUI.data_type.DISTANCE,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 32,
                    y: 96,
                    w: 100,
                    h: 47,
                    type: hmUI.data_type.SUN_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 55,
                    y: 245,
                    w: 270,
                    h: 30,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 147,
                    y: 6,
                    w: 100,
                    h: 40,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 258,
                    y: 118,
                    w: 106,
                    h: 23,
                    type: hmUI.data_type.ALTIMETER,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 258,
                    y: 94,
                    w: 100,
                    h: 18,
                    type: hmUI.data_type.WIND,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}