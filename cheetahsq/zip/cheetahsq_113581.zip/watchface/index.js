try {
  (() => {

    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

    /*
  * huamiOS bundle tool v1.0.17
  * Copyright © Huami. All Rights Reserved
  */
    'use strict';

    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let strRootPath = "images/";
    let strStepPath = strRootPath + "step/";
    let strTimePath = strRootPath + "time/";
    let arrFont = [];
    let arrTime = [];
    for (let i = 0; i < 10; i++) {
      arrFont.push(strStepPath + i + ".png");
      arrTime.push(strTimePath + i + ".png");
    }
    let objBg = {
      x: 0,
      y: 0,
      src: "images/bg.png",
      show_level: hmUI.show_level.ONLY_NORMAL
    };
    let objAnim = {
      x: 0,
      y: 0,
      anim_path: strRootPath + "bg",
      anim_prefix: "a",
      anim_ext: "png",
      anim_fps: 16,
      anim_size: 44,
      repeat_count: 1, //0位无限重复
      anim_repeat: true,//是否重复
      anim_status: hmUI.anim_status.START,
      // display_on_restart: true,//从息屏到亮屏是否自动重复播放
      // anim_complete_call:animCall,//动画结束回调 无限重复永远不会调用到
      default_frame_index: 0,
      show_level: hmUI.show_level.ONLY_NORMAL
    };
    let objBatteryBg = {
      x: 116,
      y: 18,
      src: `images/battery/0.png`,
      show_level: hmUI.show_level.ONLY_NORMAL
    };
    let objBatteryIcon = {
      x: 92,
      y: 21,
      src: `images/battery/bat.png`,
      show_level: hmUI.show_level.ONLY_NORMAL
    };

    let objTime = {
      hour_zero: 1, //是否补零
      hour_startX: 28,
      hour_startY: 60,
      hour_array: arrTime,
      hour_space: 10, //每个数组间的间隔         
      minute_zero: 1, //是否补零
      minute_startX: 203,
      minute_startY: 60,
      minute_array: arrTime,
      minute_space: 10, //每个数组间的间隔
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
    };
    let objBatteryText = {
      x: 233,
      y: 20,
      type: hmUI.data_type.BATTERY,
      font_array: arrFont,
      h_space: -6,
      align_h: hmUI.align.LEFT,
      unit_sc: "images/unit/baifenhao.png",
      unit_tc: "images/unit/baifenhao.png",
      unit_en: "images/unit/baifenhao.png",
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    let objTimeUnit = {
      x: 184,
      y: 56,
      src: strTimePath + "maohao.png",
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
    };
    let objDate = {
      month_startX: 38,
      month_startY: 168,
      month_unit_sc: "images/unit/fenhao.png", //单位
      month_unit_tc: "images/unit/fenhao.png",
      month_unit_en: "images/unit/fenhao.png",
      month_align: hmUI.align.LEFT,
      month_space: -4,//文字间隔
      month_zero: true,//是否补零           
      month_en_array: arrFont,
      month_sc_array: arrFont,
      month_tc_array: arrFont,
      day_follow: 1,//是否跟随               
      day_align: hmUI.align.LEFT,
      day_space: -4,//文字间隔
      day_zero: true,//是否补零           
      day_en_array: arrFont,
      day_sc_array: arrFont,
      day_tc_array: arrFont,
      show_level: hmUI.show_level.ONLY_NORMAL
    };
    let objStep = {
      x: 234,
      y: 168,
      w: 200,
      icon: `images/step/icon.png`,
      icon_space: 22,
      type: hmUI.data_type.STEP,
      font_array: arrFont,
      h_space: -4,
      align_h: hmUI.align.LEFT,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    let objStepJump = {
      x: 227,
      y: 160,
      w: 144,
      h: 36,
      type: hmUI.data_type.STEP, //必写 跳转的action
      show_level: hmUI.show_level.ONLY_NORMAL,
    };

    let battery = hmSensor.createSensor(hmSensor.id.BATTERY);
    let battery_rect = null;
    function setBattery(battery) {
      let batteryCurrent = battery.current;
      let batw = 94 * (batteryCurrent / 100);
      let color;
      // batteryCurrent = 10; //调试
      if (batw <= 5) {
        batw = 5;
      }
      if (batteryCurrent <= 15) {
        color = 0xff0000;
      } else {
        color = 0xffffff;
      }
      battery_rect.setProperty(hmUI.prop.MORE, {
        x: 120,
        y: 23,
        w: batw,
        h: 14,
        radius: 7,
        color
      });
    }

    const logger = DeviceRuntimeCore.HmLogger.getLogger("defult");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        hmUI.createWidget(hmUI.widget.IMG, objBg);
        hmUI.createWidget(hmUI.widget.IMG_ANIM, objAnim);
        hmUI.createWidget(hmUI.widget.IMG, objBatteryBg);
        hmUI.createWidget(hmUI.widget.IMG, objBatteryIcon);
        battery_rect = hmUI.createWidget(hmUI.widget.FILL_RECT, {
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        setBattery(battery);
        battery.addEventListener(hmSensor.event.CHANGE, function () {
          setBattery(battery);
        });
        hmUI.createWidget(hmUI.widget.TEXT_IMG, objBatteryText);
        hmUI.createWidget(hmUI.widget.IMG_TIME, objTime);
        hmUI.createWidget(hmUI.widget.IMG, objTimeUnit);
        hmUI.createWidget(hmUI.widget.IMG_DATE, objDate);
        hmUI.createWidget(hmUI.widget.TEXT_IMG, objStep);
        hmUI.createWidget(hmUI.widget.IMG_CLICK, objStepJump);
        hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: (function () {
            setBattery(battery);
            console.log('ui resume');
          }),
          pause_call: (function () {
            console.log('ui pause');
          }),
        });
        hmUI.createWidget(hmUI.widget.IMG_CLICK,{
          x:224,
          y:162,
          w:145,
          h:35,               
          type:hmUI.data_type.STEP, //必写 跳转的action
          });
      },

      onInit() {
        console.log('index page.js on init invoke');

        this.init_view();


      },

      onReady() {
        console.log('index page.js on ready invoke');
      },

      onShow() {
        console.log('index page.js on show invoke');
      },

      onHide() {
        console.log('index page.js on hide invoke');
      },

      onDestory() {
        console.log('index page.js on destory invoke');
      },
    });
    /*
    * end js
    */
  })();
} catch (e) {
  console.log(e);
}