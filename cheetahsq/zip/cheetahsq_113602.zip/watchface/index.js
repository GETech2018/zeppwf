try {
  (() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__),
      "drink"
    );

    /*
     * huamiOS bundle tool v1.0.17
     * Copyright © Huami. All Rights Reserved
     */
    ("use strict");

    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let rootPath = "images/";
    let dontPath = rootPath + "icon/sp.png";
    let weekStr = null;
    let weekScArray = [];
    let weekEnArray = [];
    let num_array = [];
    let timeArray = [];
    let bg = null;
    let item_Text = null;
    let btIcon = null;
    let weekNor = null;
    let month = null;
    let animCreate = null;
    let time = null;

    for (let i = 1; i < 8; i++) {
      weekScArray.push(rootPath + 'week_cn/0' + i + '.png')
      weekEnArray.push(rootPath + 'week_en/0' + i + '.png')
    }
    for (let i = 0; i < 10; i++) {
      num_array.push(rootPath + 'font/0' + i + '.png')
      timeArray.push(rootPath + 'time/0' + i + '.png')
    }

    const logger = DeviceRuntimeCore.HmLogger.getLogger("defult");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      drawWidget(editType, id) {
        config = {
          bgx: null,
          bgy: null,
          w: null,
          iconX: null,
          iconY: null,
          numX: null,
          numY: null,
          bgimg1: null,
          array: null,
          type: null,
          src: null,
          num_array: num_array,
          h: 0,
          invalid_image: null,
          unit_en: null,
          unit_sc: null,
          unit_tc: null,
          spPath: null,
          // bg_img1:blue
        };

        switch (id) {
          case 101:
            // config.bgx = 154,
            // config.bgy = 44,
            //   config.bgw = 94,
            (config.iconX = 132);
            (config.iconY = 195);
            (config.numX = 150);
            (config.numY = 180);
            break;

          default:
        }

        switch (editType) {
          case hmUI.edit_type.BATTERY:
            config.type = hmUI.data_type.BATTERY;
            config.src = "images/icon/bat.png";
            config.numX = config.numX;
            config.iconX = config.iconX;
            config.unit_en = "images/num/baifenhao.png";
            config.unit_sc = "images/num/baifenhao.png";
            config.unit_tc = "images/num/baifenhao.png";
            break;
          case hmUI.edit_type.CAL:
            config.type = hmUI.data_type.CAL;
            config.src = "images/icon/kcal.png";
            config.numX = config.numX;
            config.iconX = config.iconX;
            break;

          case hmUI.edit_type.STEP:
            config.type = hmUI.data_type.STEP;
            config.src = "images/icon/step.png";
            config.numX = config.numX;
            config.iconX = config.iconX;
            // config.h = -3
            // config.invalid = bluePath + "null.png"
            break;

          case hmUI.edit_type.HEART:
            config.type = hmUI.data_type.HEART;
            config.src = "images/icon/heart.png";
            config.numX = config.numX;
            config.iconX = config.iconX;
            config.invalid = "images/num/none.png";
            break;
          case hmUI.edit_type.HUMIDITY:
            config.src = "images/icon/hum.png";
            config.type = hmUI.data_type.HUMIDITY;
            config.unit_en = "images/num/baifenhao.png";
            config.unit_sc = "images/num/baifenhao.png";
            config.unit_tc = "images/num/baifenhao.png";
            config.invalid = "images/num/none.png";

            break;

          default:
            return config;
        }

        item_Text = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          //文字和图标一起渲染（可做到图标和数据在不同位数时都是居中的状态）
          // x: config.numX - 55, //配合w：150时
          x: config.numX - 51, //配合w：180时
          y: config.numY,
          // w: 150,//图标加数据的最大尺寸
          w: 180, //图标加数据的最大尺寸
          h: 38,
          type: config.type,
          font_array: config.num_array,
          h_space: config.h,
          icon: config.src, //icon图标的路径
          icon_space: 0, //数据和icon图标的间距
          // align_h: hmUI.align.RIGHT,
          align_h: hmUI.align.CENTER_H,

          //   align_h: hmUI.align.LEFT,
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD,
          unit_sc: config.unit_sc,
          unit_en: config.unit_en,
          unit_tc: config.unit_tc,
          invalid_image: config.invalid, //无图数据显示 invalid_image
          dot_image: config.spPath,
          // padding:true //补零
        });
        hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 114,
          y: 168,
          w: 166,
          h: 57,
          type: config.type, //必写 跳转的action
          show_level: hmUI.show_level.ONLY_NORMAL
        })
      },

      init_view() {
        bg = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 390,
          h: 450,
          src: rootPath + "bg.png",
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
        });

        //编辑模式下显示10：09 👇
        let num = 35
        let text = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 21 + num,
          y: 81,
          text: `10`,
          font_array: timeArray,
          h_space: 0,
          show_level: hmUI.show_level.ONLY_EDIT,
        });

        let text1 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 169 + num,
          y: 81,
          text: `09`,
          font_array: timeArray,
          h_space: 0,
          show_level: hmUI.show_level.ONLY_EDIT,
        });

        hmUI.createWidget(hmUI.widget.IMG, {
          x: 144 + num,
          y: 81,
          src: rootPath + "icon/time_sp.png",
          show_level: hmUI.show_level.ONLY_EDIT,
        });
        //编辑模式下显示10：09 👆

        weekNor = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
          x: 196,
          y: 28,
          week_tc: weekScArray,
          week_sc: weekScArray,
          week_en: weekEnArray,
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD,
        });
        const weekEdit = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
          x: 196,
          y: 28,
          week_tc: weekScArray,
          week_sc: weekScArray,
          week_en: weekEnArray,
          show_level: hmUI.show_level.ONLY_EDIT,
        });
        month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
          show_level: hmUI.show_level.ALL,
          month_startX: 96,
          month_startY: 33,
          month_zero: true,
          month_en_array: num_array,
          month_align: hmUI.align.RIGHT,
          month_unit_sc: dontPath,
          month_unit_tc: dontPath,
          month_unit_en: dontPath,
          day_follow: true,
          day_zero: true,
          day_en_array: num_array,
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD,
        });
        const monthEdit = hmUI.createWidget(hmUI.widget.IMG_DATE, {
          show_level: hmUI.show_level.ALL,
          month_startX: 96,
          month_startY: 33,
          month_zero: true,
          month_en_array: num_array,
          month_align: hmUI.align.RIGHT,
          month_unit_sc: dontPath,
          month_unit_tc: dontPath,
          month_unit_en: dontPath,
          day_follow: true,
          day_zero: true,
          day_en_array: num_array,
          show_level: hmUI.show_level.ONLY_EDIT,
        });

        time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          hour_zero: true,
          hour_startX: 58,
          hour_startY: 81,
          hour_array: timeArray,
          hour_space: 0,
          hour_unit_sc: rootPath + "icon/time_sp.png", //单位
          hour_unit_tc: rootPath + "icon/time_sp.png",
          hour_unit_en: rootPath + "icon/time_sp.png",
          hour_align: hmUI.align.LEFT,
          minute_zero: 1, //是否补零 1为补零
          minute_follow: true, //是否跟随
          minute_array: timeArray,
        });

        //=========================================================
        let widgetOptionalArray = [
          { type: hmUI.edit_type.STEP, preview: "images/yulantu/step.png" },
          { type: hmUI.edit_type.CAL, preview: "images/yulantu/kcal.png" },
          { type: hmUI.edit_type.BATTERY, preview: "images/yulantu/bat.png" },
          { type: hmUI.edit_type.HEART, preview: "images/yulantu/heart.png" },
          { type: hmUI.edit_type.HUMIDITY, preview: "images/yulantu/hum.png" },
        ];


        let groupX = 113.999;
        let groupY = 168;
        let Group = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 101,
          x: groupX,
          y: groupY,
          w: 166,
          h: 57,
          select_image: "images/edit/select.png",
          un_select_image: "images/edit/select.png",
          default_type: hmUI.edit_type.STEP,
          optional_types: widgetOptionalArray,
          count: widgetOptionalArray.length,
          tips_BG: "images/edit/tips.png",
          tips_x: 34,
          tips_y: -40,
          tips_width: 98,
          tips_margin: 10, //加margin
          select_list: {
            title_font_size: 34,
            title_align_h: hmUI.align.CENTER_H,
            list_item_vspace: 8,
            list_bg_color: 0x0000,
            list_bg_radius: 30,
            list_group_text_font_size: 32,
            list_group_text_align_h: hmUI.align.CENTER_H,
            list_tips_text_font_size: 32,
            list_tips_text_align_h: hmUI.align.LEFT,
          }, // 新增配置选项
        });
        var item = Group.getProperty(hmUI.prop.CURRENT_TYPE);
        this.drawWidget(item, 101);

        mask = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 390,
          h: 450,
          src: "images/edit/mask.png",
          show_level: hmUI.show_level.ONLY_EDIT,
        });

        // 获取颜色方法----------------------------------------------------
        let getColor = readColor();
        try {
          weekNor.setColor(getColor);
          month.setColor(getColor);
          time.setColor(getColor);
          item_Text.setColor(getColor);
        } catch (error) {
          console.log(error)
        }

        function readColor() {
          //资源文件路径: assets/config.json
          const file_name = 'config.json';
          // 获取文件信息
          // stat_asset 获取应用 assets 目录下的文件信息
          const [file_stat, err] = hmFS.stat_asset(file_name);
          if (err == 0) {
            console.log('file size:', file_stat.size);
          } else {
            console.log('err:', err);
          }
          // 根据文件大小申请 buffer
          var test_buf = new Uint8Array(file_stat.size);
          //打开文件(hmFS.O_RDONLY ：打开方式为只读只读)
          var fd = hmFS.open_asset(file_name, hmFS.O_RDONLY);
          //定位到文件开始位置
          // seek 移动文件指针
          // hmFS.SEEK_SET 我的理解是通过 hmFS.SEEK_SET 设置指针跳转到 fd文件的 0 位置（开头）
          hmFS.seek(fd, 0, hmFS.SEEK_SET);
          // 读取 buffer
          hmFS.read(fd, test_buf.buffer, 0, test_buf.length);
          // 关闭文件
          hmFS.close(fd);
          //打印读取内容 (config.json内容)
          // fromCharCode 是 string 对象的静态方法，用于将二进制编码转为字符串
          // apply 修改 this 指向，返回一个新的方法，test_buf 参数数组
          // 所以 val 最终得到的是 JSON 格式字符串
          const val = String.fromCharCode.apply(null, test_buf);
          contentObj = val ? JSON.parse(val) : {};
          const colors = parseInt('0x' + contentObj.foreground.color);
          return colors;
        }
      },

      onInit() {
        console.log("index page.js on init invoke");

        this.init_view();
      },

      onReady() {
        console.log("index page.js on ready invoke");
      },

      onShow() {
        console.log("index page.js on show invoke");
      },

      onHide() {
        console.log("index page.js on hide invoke");
      },

      onDestory() {
        console.log("index page.js on destory invoke");
      },
    });
    /*
     * end js
     */
  })();
} catch (e) {
  console.log(e);
}
