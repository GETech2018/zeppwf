try {
  ;(() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp

    var __$$module$$__ = __$$app$$__.current
    var h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__),
      'drink'
    )

    /*
     * huamiOS bundle tool v1.0.17
     * Copyright © Huami. All Rights Reserved
     */
    ;('use strict')

    console.log('----->>>current')
    console.log(__$$hmAppManager$$__.currentApp.pid)
    console.log(__$$hmAppManager$$__.currentApp.current)
    const WIDGET_LEFT_ID = 101
    const WIDGET_TOP_ID = 102
    const WIDGET_BOTTOM_ID = 103
    const WIDGET_BG_ID = 105
    const WIDGET_TOP = 1
    const WIDGET_LEFT = 2
    const WIDGET_BOTTOM = 3
    const WIDGET_EDIT_SIZE = 122
    const WIDGET_TIPS_WIDTH = 104
    const ROOTPATH = 'images/'
    const WIDGET_BG_PATH = ROOTPATH + 'widget/bg/'
    const INNER_PROGRESS_PATH = ROOTPATH + 'progress_inner_img/'
    // const WIDGET_ICON_PATH = ROOTPATH + "widget/icon/";
    const WIDGET_POINTER_PATH = ROOTPATH + 'widget/point.png'
    const WIDGET_FONT_ARRAY = [
      ROOTPATH + 'number_img/0.png',
      ROOTPATH + 'number_img/1.png',
      ROOTPATH + 'number_img/2.png',
      ROOTPATH + 'number_img/3.png',
      ROOTPATH + 'number_img/4.png',
      ROOTPATH + 'number_img/5.png',
      ROOTPATH + 'number_img/6.png',
      ROOTPATH + 'number_img/7.png',
      ROOTPATH + 'number_img/8.png',
      ROOTPATH + 'number_img/9.png',
    ]
    const pointPath = ROOTPATH + 'pointer/'
    const widgetPreview = ROOTPATH + 'widget_preview/'
    const TIPS_ROOT = ROOTPATH + 'tips/'
    const WIDGET_TIPS_PATH = TIPS_ROOT + 'widget_tips.png'
    const BGROOT = ROOTPATH + 'bg_edit/'
    let select = ROOTPATH + 'select/'
    let left_eidt = null
    let center_edit = null
    let right_edit = null
    let pointer

    let config = {}
    let battery_imgArr = []
    let number_text_img = []
    let pai_imgArr = []
    let uvi_imgArr = []
    let weather_imgArr = []
    let fontArray = []
    let weather_icon_img = []
    let weekArray = []
    let weekCnArray = []
    let kcal_progress_imgArr = []
    let sleep_progress_imgArr = []
    let step_progress_imgArr = []
    let diststand_progress_imgArr = []

    function get_widget_type(edit_widget) {
      console.log('edit_widget value', edit_widget)
      let edit_type = null
      switch (edit_widget) {
        case hmUI.edit_type.HUMIDITY:
          edit_type = hmUI.data_type.HUMIDITY
          break
        case hmUI.edit_type.ALTIMETER:
          edit_type = hmUI.data_type.ALTIMETER
          break
        case hmUI.edit_type.STEP:
          edit_type = hmUI.data_type.STEP
          break
        case hmUI.edit_type.CAL:
          edit_type = hmUI.data_type.CAL
          break
        case hmUI.edit_type.DISTANCE:
          edit_type = hmUI.data_type.DISTANCE
          break
        case hmUI.edit_type.HEART:
          edit_type = hmUI.data_type.HEART
          break

        case hmUI.edit_type.STAND:
          edit_type = hmUI.data_type.STAND
          break
        case hmUI.edit_type.SPO2:
          edit_type = hmUI.data_type.SPO2
          break
        case hmUI.edit_type.SLEEP:
          edit_type = hmUI.data_type.SLEEP
          break
        case hmUI.edit_type.UVI:
          edit_type = hmUI.data_type.UVI
          break
        case hmUI.edit_type.WIND:
          edit_type = hmUI.data_type.WIND
          break

        default:
      }
      return edit_type
    }

    const logger = DeviceRuntimeCore.HmLogger.getLogger('sanjiao')
    __$$module$$__.module = DeviceRuntimeCore.Page({
      parseWidgetConfig(editType) {
        let config = {
          bgPath: null, //背景图
          iconPath: null, //图标
          dataType: null, //数据类型
          nonePath: null, //无数据的图片
          negativeImage: null,
          unitEnPath: null, //单位
          unitScPath: null,
          unitTcPath: null,
          spPath: null,
          pointerType: null,
          startAngle: 225, //指针开始角度
          endAngle: 495, //指针结束角度
          progressType: null,
          angleType: null,
        }

        switch (editType) {
          case hmUI.edit_type.HUMIDITY: //
            config.bgPath = 'rh.png'
            config.dataType = hmUI.data_type.HUMIDITY
            config.spPath = ROOTPATH + 'widget/font1/number_p.png'
            config.nonePath = ROOTPATH + 'widget/font1/none.png'
            config.angleType = ROOTPATH + 'widget/font1/none.png'
            config.unitEnPath = ROOTPATH + 'widget/font1/u.png'
            config.unitScPath = ROOTPATH + 'widget/font1/u.png'
            config.unitTcPath = ROOTPATH + 'widget/font1/u.png'
            break
          case hmUI.edit_type.ALTIMETER:
            config.bgPath = 'kpa.png'
            config.angleType = ROOTPATH + 'widget/font1/none.png'
            config.dataType = hmUI.data_type.ALTIMETER
            break
          case hmUI.edit_type.STEP:
            config.bgPath = 'step.png'
            // config.iconPath = "step.png";
            config.dataType = hmUI.data_type.STEP
            config.progressType = 'diststand'
            break
          case hmUI.edit_type.CAL:
            //
            config.bgPath = 'kcal.png'
            // config.iconPath = "kcal.png";
            config.dataType = hmUI.data_type.CAL
            config.progressType = 'kcal'
            break

          // case hmUI.edit_type.FAT_BURN:
          // //
          //     config.bgPath = "burn.png";
          //     config.dataType = hmUI.data_type.FAT_BURNING;
          //     config.nonePath = ROOTPATH + "widget/font1/none.png";
          //     config.unitEnPath = ROOTPATH + "number_img/m.png";
          //     config.unitEnPath = ROOTPATH + "number_img/m.png";
          //     config.unitEnPath = ROOTPATH + "number_img/m.png";
          //     config.progressType = 'kcal'
          //     break;

          case hmUI.edit_type.DISTANCE:
            config.bgPath = 'dist.png'
            // config.iconPath = "distance.png";
            config.dataType = hmUI.data_type.DISTANCE
            config.spPath = ROOTPATH + 'widget/font1/dian.png'
            config.pointerType = hmUI.data_type.STEP
            config.nonePath = ROOTPATH + 'widget/font1/none.png'
            config.progressType = 'diststand'
            break
          case hmUI.edit_type.HEART:
            config.bgPath = 'heart.png'
            // config.iconPath = "heart.png";
            config.dataType = hmUI.data_type.HEART
            config.pointerType = hmUI.data_type.HEART
            config.nonePath = ROOTPATH + 'widget/font1/none.png'
            break

          case hmUI.edit_type.STAND:
            config.bgPath = 'stand.png'
            // config.iconPath = "stand.png";
            config.dataType = hmUI.data_type.STAND
            config.spPath = ROOTPATH + 'widget/font1/sp.png'
            config.progressType = 'step'
            break
          case hmUI.edit_type.SPO2:
            config.bgPath = 'spo2.png'
            // config.iconPath = "spo2.png";
            config.dataType = hmUI.data_type.SPO2
            config.unitEnPath = ROOTPATH + 'widget/font1/u.png'
            config.unitScPath = ROOTPATH + 'widget/font1/u.png'
            config.unitTcPath = ROOTPATH + 'widget/font1/u.png'
            config.nonePath = ROOTPATH + 'widget/font1/none.png'
            break

          case hmUI.edit_type.SLEEP:
            config.bgPath = 'sleep.png'
            config.dataType = hmUI.data_type.SLEEP
            config.spPath = ROOTPATH + 'widget/font1/dian.png'
            // config.unitEnPath = ROOTPATH + "widget/font1/h.png";
            // config.unitScPath = ROOTPATH + "widget/font1/h.png";
            // config.unitTcPath = ROOTPATH + "widget/font1/h.png";
            config.nonePath = ROOTPATH + 'widget/font1/none.png'
            config.progressType = 'sleep'
            break

          case hmUI.edit_type.UVI:
            config.bgPath = 'uvi.png'
            // config.iconPath = "uvi.png";
            config.dataType = hmUI.data_type.UVI
            config.nonePath = ROOTPATH + 'widget/font1/none.png'
            break
          case hmUI.edit_type.WIND:
            config.bgPath = 'wind.png'
            // config.iconPath = "wind.png";
            config.dataType = hmUI.data_type.WIND
            config.nonePath = ROOTPATH + 'widget/font1/none.png'
            break

          default:
            return config
        }
        if (config.bgPath != null) {
          config.bgPath = WIDGET_BG_PATH + config.bgPath
        }

        if (config.pointerType == null) {
          config.pointerType = config.dataType
        }
        return config
      },
      drawWidget(widgetType, editType) {
        let bgX = 0
        let bgY = 0
        switch (widgetType) {
          case WIDGET_TOP:
            bgX = 40
            bgY = 166
            break
          case WIDGET_LEFT:
            bgX = 136
            bgY = 258
            break
          case WIDGET_BOTTOM:
            bgX = 232
            bgY = 166
            break
          default:
            return
        }
        const bgSize = 118
        const iconX = bgX + 51
        const iconY = bgY + 17
        const textX = bgX
        const textY = bgY + 68
        const textWidth = 118
        const textHeight = 34
        const iconSize = 32

        config = this.parseWidgetConfig(editType)
        // const config = this.parseWidgetConfig(editType)
        if (config.dataType == null) {
          console.log('invalid arg dataType is null')
          return
        }
        if (config.bgPath == null) {
          console.log('invalid arg bgpath is null')
          return
        }
        //widgetbg

        hmUI.createWidget(hmUI.widget.IMG, {
          x: bgX,
          y: bgY,
          w: bgSize,
          h: bgSize,
          src: config.bgPath,
          show_level: hmUI.show_level.ONLY_NORMAL,
        })

        if (config.progressType) {
          var inner_progress_imgs = null
          switch (config.progressType) {
            case 'step':
              inner_progress_imgs = step_progress_imgArr
              break
            case 'sleep':
              inner_progress_imgs = sleep_progress_imgArr
              break
            case 'kcal':
              inner_progress_imgs = kcal_progress_imgArr
              break
            case 'diststand':
              inner_progress_imgs = diststand_progress_imgArr
              break
          }
          let nowType = null
          if (config.dataType == hmUI.data_type.DISTANCE) {
            nowType = hmUI.data_type.STEP
          } else {
            nowType = config.dataType
          }
          hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
            x: bgX,
            y: bgY,
            image_array: inner_progress_imgs,
            image_length: inner_progress_imgs.length,
            type: nowType,
            show_level: hmUI.show_level.ONLY_NORMAL,
          })
        } else {
          hmUI.createWidget(hmUI.widget.IMG_POINTER, {
            center_x: bgX + bgSize / 2,
            center_y: bgY + bgSize / 2,
            // x:6,
            x: 12,
            y: 58,
            src: WIDGET_POINTER_PATH,
            type: config.pointerType,
            start_angle: config.startAngle,
            end_angle: config.endAngle - 7,
            show_level: hmUI.show_level.ONLY_NORMAL,
          })
        }

        let dataProp = {
          x: textX,
          y: textY,
          w: textWidth,
          h: textHeight,
          align_h: hmUI.align.CENTER_H,
          type: config.dataType,
          h_space: 1,
          font_array: WIDGET_FONT_ARRAY,
          show_level: hmUI.show_level.ONLY_NORMAL,
        }
        if (config.unitEnPath != null) {
          dataProp.unit_en = config.unitEnPath
        }
        if (config.unitScPath != null) {
          dataProp.unit_sc = config.unitScPath
        }
        if (config.unitTcPath != null) {
          dataProp.unit_tc = config.unitTcPath
        }
        if (config.nonePath != null) {
          dataProp.invalid_image = config.nonePath
        }
        if (config.spPath != null) {
          dataProp.dot_image = config.spPath
        }
        if (config.negativeImage != null) {
          dataProp.negative_image = config.negativeImage
        }

        //数据
        hmUI.createWidget(hmUI.widget.TEXT_IMG, dataProp)

        // 指针
        // hmUI.createWidget(hmUI.widget.IMG_POINTER,{
        //     center_x:bgX + bgSize/2,
        //     center_y:bgY + bgSize/2,
        //     x:6,
        //     y:52,
        //     src:WIDGET_POINTER_PATH,
        //     type:config.pointerType,
        //     start_angle:config.startAngle,
        //     end_angle:config.endAngle,
        // });
      },
      init_view() {
        for (let i = 0; i < 13; i++) {
          battery_imgArr.push(ROOTPATH + `progress_img/power_${i}.png`)
        }
        for (let x = 0; x < 12; x++) {
          kcal_progress_imgArr.push(ROOTPATH + `progress_inner_img/kcal/${x}.png`)
          sleep_progress_imgArr.push(ROOTPATH + `progress_inner_img/sleep/${x}.png`)
          step_progress_imgArr.push(ROOTPATH + `progress_inner_img/step/${x}.png`)
          diststand_progress_imgArr.push(ROOTPATH + `progress_inner_img/diststand/${x}.png`)
        }

        for (let j = 1; j < 14; j++) {
          pai_imgArr.push(ROOTPATH + `progress_img/pai_${j}.png`)
          weather_imgArr.push(ROOTPATH + `progress_img/w_${j}.png`)
        }

        for (let k = 0; k < 10; k++) {
          number_text_img.push(ROOTPATH + `number_img/${k}.png`)
          fontArray.push(ROOTPATH + `date/date_${k}.png`)
        }

        for (let m = 1; m < 6; m++) {
          uvi_imgArr.push(ROOTPATH + `progress_img/uvi_${m}.png`)
        }

        for (let p = 0; p < 29; p++) {
          weather_icon_img.push(ROOTPATH + `weather/${p}.png`)
        }

        for (let w = 1; w < 7; w++) {
          weekArray.push(ROOTPATH + `week/week_${w}.png`)
          weekCnArray.push(ROOTPATH + `week_cn/week_${w}.png`)
        }

        // 可编辑背景信息
        const obj_bg = {
          edit_id: WIDGET_BG_ID,
          x: 0,
          y: 0,
          bg_config: [
            { id: 1, preview: BGROOT + 'edit_bg1.png', path: BGROOT + 'bg1.png' },
            { id: 2, preview: BGROOT + 'edit_bg2.png', path: BGROOT + 'bg2.png' },
            { id: 3, preview: BGROOT + 'edit_bg3.png', path: BGROOT + 'bg3.png' },
          ],
          count: 3,
          default_id: 1,
          fg: BGROOT + 'fg.png',
          tips_x: 133,
          tips_y: 400,
          tips_bg: TIPS_ROOT + 'bg_tips.png',
          tips_width: 124,
          tips_margin: 10,          
        }

        // 无数据电量进度条信息
        const obj_battery_default_progress = {
          x: 0,
          y: 0,
          w: 195,
          h: 225,
          src: ROOTPATH + 'progress_img/power_0.png',
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
        }

        // 无数据温度进度条信息
        const obj_weather_default_progress = {
          x: 0,
          y: 225,
          w: 195,
          h: 225,
          src: ROOTPATH + 'progress_img/w_0.png',
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
        }

        //  无数据UVI进度条信息
        const obj_uvi_default_progress = {
          x: 195,
          y: 0,
          w: 195,
          h: 225,
          src: ROOTPATH + 'progress_img/uvi_0.png',
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
        }

        // 无数据PAI进度条信息
        const obj_pai_default_progress = {
          x: 195,
          y: 225,
          w: 195,
          h: 225,
          src: ROOTPATH + 'progress_img/pai_0.png',
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
        }

        // 电量进度条信息
        const obj_battery_progress = {
          x: 0,
          y: 0,
          image_array: battery_imgArr,
          image_length: battery_imgArr.length,
          type: hmUI.data_type.BATTERY,
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
        }

        // UVI进度条
        const obj_UVI_progress = {
          x: 195,
          y: 0,
          image_array: uvi_imgArr,
          image_length: uvi_imgArr.length,
          type: hmUI.data_type.UVI,
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
        }

        // PAI进度条
        const obj_PAI_progress = {
          x: 195,
          y: 225,
          image_array: pai_imgArr,
          image_length: pai_imgArr.length,
          type: hmUI.data_type.PAI_WEEKLY,
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
        }

        // 温度进度条
        const obj_weather_progress = {
          x: 0,
          y: 225,
          image_array: weather_imgArr,
          image_length: weather_imgArr.length,
          type: hmUI.data_type.WEATHER,
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
        }

        // 电量数值文本
        const obj_battery_text = {
          x: 26,
          y: 21,
          w: 60,
          // text:100,
          type: hmUI.data_type.BATTERY,
          font_array: number_text_img,
          h_space: -1,
          align_h: hmUI.align.CENTER_H,
          padding: false,
          // unit_sc: ROOTPATH + 'number_img/number_p.png',
          // unit_tc: ROOTPATH + 'number_img/number_p.png',
          // unit_en: ROOTPATH + 'number_img/number_p.png',
          show_level: hmUI.show_level.ALL,
        }

        // 紫外线数值文本
        const obj_UVI_text = {
          x: 320,
          y: 21,
          type: hmUI.data_type.UVI,
          font_array: number_text_img,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          padding: false,
          invalid_image: ROOTPATH + 'number_img/none.png',
          show_level: hmUI.show_level.ALL,
        }

        // 天气数值文本
        const obj_weather_text = {
          x: 24,
          y: 407,
          type: hmUI.data_type.WEATHER_CURRENT,
          font_array: number_text_img,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          padding: false,
          unit_sc: ROOTPATH + 'number_img/number_du.png',
          unit_tc: ROOTPATH + 'number_img/number_du.png',
          unit_en: ROOTPATH + 'number_img/number_du.png',
          negative_image: ROOTPATH + 'number_img/fuhao.png',
          invalid_image: ROOTPATH + 'number_img/none.png',
          show_level: hmUI.show_level.ALL,
        }

        // pai数值文本
        const obj_pai_text = {
          x: 312,
          y: 407,
          type: hmUI.data_type.PAI_WEEKLY,
          font_array: number_text_img,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          padding: false,
          show_level: hmUI.show_level.ALL,
        }

        // 步数数值文本
        const obj_step_text_xp = {
          x: 160,
          y: 320,
          type: hmUI.data_type.STEP,
          font_array: number_text_img,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          padding: false,
          show_level: hmUI.show_level.ONLY_AOD,
        }

        // 天气图标
        const obj_weather_icon_progress = {
          x: 30,
          y: 374,
          image_array: weather_icon_img,
          image_length: weather_icon_img.length,
          type: hmUI.data_type.WEATHER,
          show_level: hmUI.show_level.ALL,
        }

        let widgetOptionalArray = [
          { type: hmUI.edit_type.STEP, preview: widgetPreview + 'step.png' },
          { type: hmUI.edit_type.CAL, preview: widgetPreview + 'kcal.png' },
          { type: hmUI.edit_type.DISTANCE, preview: widgetPreview + 'dist.png' },
          { type: hmUI.edit_type.HEART, preview: widgetPreview + 'heart.png' },
          { type: hmUI.edit_type.STAND, preview: widgetPreview + 'stand.png' },
          { type: hmUI.edit_type.SPO2, preview: widgetPreview + 'spo2.png' },
          { type: hmUI.edit_type.SLEEP, preview: widgetPreview + 'sleep.png' },
          { type: hmUI.edit_type.UVI, preview: widgetPreview + 'uvi.png' },
          { type: hmUI.edit_type.WIND, preview: widgetPreview + 'ws.png' },
          { type: hmUI.edit_type.HUMIDITY, preview: widgetPreview + 'rh.png' },
          { type: hmUI.edit_type.ALTIMETER, preview: widgetPreview + 'kpa.png' },
          // { type: hmUI.edit_type.FAT_BURN, preview: widgetPreview + "burn.png" },
        ]

        // 可编辑列表
        const edit_list_config = {
          title_font_size: 34,
          title_align_h: hmUI.align.CENTER_H,
          list_item_vspace: 8,
          list_tips_text_font_size: 32,
          list_tips_text_align_h: hmUI.align.LEFT,
        }

        let left_eidt_x = 40
        let left_eidt_y = 165
        const obj_left_edit = {
          edit_id: WIDGET_TOP_ID,
          x: left_eidt_x,
          y: left_eidt_y,
          w: WIDGET_EDIT_SIZE,
          h: WIDGET_EDIT_SIZE,
          select_image: select + 'select.png',
          un_select_image: select + 'unselect.png',
          default_type: hmUI.edit_type.CAL,
          optional_types: widgetOptionalArray,
          count: widgetOptionalArray.length,
          tips_BG: WIDGET_TIPS_PATH,
          tips_x: 10,
          tips_y: -40,
          tips_width: WIDGET_TIPS_WIDTH,
          tips_margin: 10,
          select_list: edit_list_config,
        }

        let cneter_eidt_x = 136
        let cneter_eidt_y = 258
        const obj_center_eidt = {
          edit_id: WIDGET_LEFT_ID,
          x: cneter_eidt_x,
          y: cneter_eidt_y,
          w: WIDGET_EDIT_SIZE,
          h: WIDGET_EDIT_SIZE,
          select_image: select + 'select.png',
          un_select_image: select + 'unselect.png',
          default_type: hmUI.edit_type.SPO2,
          optional_types: widgetOptionalArray,
          count: widgetOptionalArray.length,
          tips_BG: WIDGET_TIPS_PATH,
          tips_x: 10,
          tips_y: -40,
          tips_width: WIDGET_TIPS_WIDTH,
          tips_margin: 10,
          select_list: edit_list_config,
        }

        let right_eidt_x = 229
        let right_eidt_y = 164
        const obj_right_edit = {
          edit_id: WIDGET_BOTTOM_ID,
          x: right_eidt_x,
          y: right_eidt_y,
          w: WIDGET_EDIT_SIZE,
          h: WIDGET_EDIT_SIZE,
          select_image: select + 'select.png',
          un_select_image: select + 'unselect.png',
          default_type: hmUI.edit_type.STAND,
          optional_types: widgetOptionalArray,
          count: widgetOptionalArray.length,
          tips_BG: WIDGET_TIPS_PATH,
          tips_x: 10,
          tips_y: -40,
          tips_width: WIDGET_TIPS_WIDTH,
          tips_margin: 10,
          select_list: edit_list_config,
        }

        const centerXValue = 195
        const centerYValue = 225
        const secondProp = {
          centerX: centerXValue,
          centerY: centerYValue,
          posX: 6,
          posY: 191,
          path: pointPath + 's.png',
        }

        const pointerConfig = [
          {
            id: 1,
            hour: {
              centerX: centerXValue,
              centerY: centerYValue,
              posX: 18,
              posY: 142,
              path: pointPath + 'h1.png',
            },
            minute: {
              centerX: centerXValue,
              centerY: centerYValue,
              posX: 19,
              posY: 200,
              path: pointPath + 'm1.png',
            },
            second: secondProp,
            preview: pointPath + 'preview1.png',
          },
          {
            id: 2,
            hour: {
              centerX: centerXValue,
              centerY: centerYValue,
              posX: 17,
              posY: 119,
              path: pointPath + 'h2.png',
            },
            minute: {
              centerX: centerXValue,
              centerY: centerYValue,
              posX: 13,
              posY: 168,
              path: pointPath + 'm2.png',
            },
            preview: pointPath + 'preview2.png',
          },
          {
            id: 3,
            hour: {
              centerX: centerXValue,
              centerY: centerYValue,
              posX: 12,
              posY: 117,
              path: pointPath + 'h3.png',
            },
            minute: {
              centerX: centerXValue,
              centerY: centerYValue,
              posX: 13,
              posY: 167,
              path: pointPath + 'm3.png',
            },
            preview: pointPath + 'preview3.png',
          },
        ]

        // 可编辑指针
        const obj_edit_pointer = {
          edit_id: 120,
          x: 0,
          y: 0,
          config: pointerConfig,
          count: pointerConfig.length,
          default_id: 1,
          fg: BGROOT + 'point_fg.png',
          tips_x: 133,
          tips_y: 400,
          tips_bg: TIPS_ROOT + 'bg_tips.png',
        }

        // 周
        const obj_week = {
          show_level: hmUI.show_level.ALL,
          x: 165,
          y: 140,
          week_tc: weekCnArray,
          week_sc: weekCnArray,
          week_en: weekArray,
        }

        // 日
        const obj_date = {
          day_startX: 172,
          day_startY: 100,
          day_zero: true,
          day_en_array: fontArray,
          show_level: hmUI.show_level.ALL,
        }

        // 电量图标息屏
        const obj_battery_icon_xp = {
          x: 40,       
          y: 47,      
          src: ROOTPATH + 'progress_img/bett.png',
          show_level: hmUI.show_level.ONLY_AOD,
        }

        // 紫外线图标息屏
        const obj_uvi_icon_xp = {
          x: 319,
          y: 45,        
          src: ROOTPATH + 'progress_img/uvi.png',
          show_level: hmUI.show_level.ONLY_AOD,
        }

        // pai图标息屏
        const obj_pai_icon_xp = {
          x: 317,
          y: 372,        
          src: ROOTPATH + 'progress_img/pai.png',
          show_level: hmUI.show_level.ONLY_AOD,
        }

        // 步数图标息屏
        const obj_step_icon_xp = {
          x: 180,
          y: 285,
          w: 30,
          h: 26,
          src: ROOTPATH + 'progress_img/step.png',
          show_level: hmUI.show_level.ONLY_AOD,
        }

        const obj_left_edit_click = {
          x: 45,
          y: 170,
          w: 110,
          h: 110,
          show_level: hmUI.show_level.ONLY_NORMAL,
        }

        const obj_cneter_edit_click = {
          x: 140,
          y: 260,
          w: 110,
          h: 110,
          show_level: hmUI.show_level.ONLY_NORMAL,
        }

        const obj_right_edit_click = {
          x: 235,
          y: 170,
          w: 110,
          h: 110,
          show_level: hmUI.show_level.ONLY_NORMAL,
        }

        const obj_battery_click = {
          x: 30,
          y: 20,
          w: 50,
          h: 55,
          type: hmUI.data_type.BATTERY,
        }

        const obj_uvi_click = {
          x: 320,
          y: 20,
          w: 50,
          h: 55,
          type: hmUI.data_type.UVI,
        }

        const obj_weather_click = {
          x: 30,
          y: 375,
          w: 50,
          h: 55,
          type: hmUI.data_type.WEATHER_CURRENT,
        }

        const obj_pai_click = {
          x: 320,
          y: 375,
          w: 50,
          h: 55,
          type: hmUI.data_type.PAI_WEEKLY,
        }

        // 可编辑背景
        const editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, obj_bg)
        let type = editBg.getProperty(hmUI.prop.CURRENT_TYPE);
        let bg_img = hmUI.createWidget(hmUI.widget.IMG, {
            x: 0,
            y: 0,
            show_level: hmUI.show_level.ONAL_AOD,
        });
        if (type == 1) {
            bg_img.setProperty(hmUI.prop.MORE, {
                src: `images/bg_edit/xpbg1.png`
            });
        }

        if (type == 2) {
            bg_img.setProperty(hmUI.prop.MORE, {
                src: `images/bg_edit/bg2.png`
            });
        }
        if (type == 3) {
            bg_img.setProperty(hmUI.prop.MORE, {
                src: `images/bg_edit/xpbg3.png`
            });
        }
        // 无数据电量进度条
        const battery_default_progress = hmUI.createWidget(
          hmUI.widget.IMG,
          obj_battery_default_progress
        )

        // 无数据温度进度条
        const weather_default_progress = hmUI.createWidget(
          hmUI.widget.IMG,
          obj_weather_default_progress
        )

        // 无数据UVI进度条
        const uvi_default_progress = hmUI.createWidget(hmUI.widget.IMG, obj_uvi_default_progress)

        // 无数据PAI进度条
        const pai_default_progress = hmUI.createWidget(hmUI.widget.IMG, obj_pai_default_progress)

        // 电量进度条
        const battery_progress = hmUI.createWidget(hmUI.widget.IMG_LEVEL, obj_battery_progress)

        // 温度进度条
        const weather_progress = hmUI.createWidget(hmUI.widget.IMG_LEVEL, obj_weather_progress)

        // UVI进度条
        const UVI_progress = hmUI.createWidget(hmUI.widget.IMG_LEVEL, obj_UVI_progress)

        // PAI进度条
        const PAI_progress = hmUI.createWidget(hmUI.widget.IMG_LEVEL, obj_PAI_progress)

        // 电量数值文本
        let BATTERY_TEXT = hmUI.createWidget(hmUI.widget.TEXT_IMG, obj_battery_text)

        // 紫外线数值文本
        let UVI_TEXT = hmUI.createWidget(hmUI.widget.TEXT_IMG, obj_UVI_text)

        // 天气数值文本
        let WEATHER_TEXT = hmUI.createWidget(hmUI.widget.TEXT_IMG, obj_weather_text)

        // pai数值文本
        let PAI_TEXT = hmUI.createWidget(hmUI.widget.TEXT_IMG, obj_pai_text)

        // 步数数值文本
        let step_TEXT_xp = hmUI.createWidget(hmUI.widget.TEXT_IMG, obj_step_text_xp)

        // 天气图标
        let WEATHER_ICON = hmUI.createWidget(hmUI.widget.IMG_LEVEL, obj_weather_icon_progress)

        // 周
        const week = hmUI.createWidget(hmUI.widget.IMG_WEEK, obj_week)

        // 日
        const day = hmUI.createWidget(hmUI.widget.IMG_DATE, obj_date)

        //可编辑组件
        left_eidt = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, obj_left_edit)
        let left_edit_type = left_eidt.getProperty(hmUI.prop.CURRENT_TYPE)
        this.drawWidget(WIDGET_TOP, left_edit_type)

        center_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, obj_center_eidt)
        let center_edit_type = center_edit.getProperty(hmUI.prop.CURRENT_TYPE)
        this.drawWidget(WIDGET_LEFT, center_edit_type)

        right_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, obj_right_edit)
        let right_edit_type = right_edit.getProperty(hmUI.prop.CURRENT_TYPE)
        this.drawWidget(WIDGET_BOTTOM, right_edit_type)


        // 可编辑指针
        const screenType = hmSetting.getScreenType();
        const aodModel = screenType == hmSetting.screen_type.AOD;

        // const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG, !aodModel);
        let pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER, obj_edit_pointer)
        const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG,!aodModel)
        pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp)


        // 电量图标息屏
        let BATTERY = hmUI.createWidget(hmUI.widget.IMG, obj_battery_icon_xp)

        // 紫外线图标息屏
        let UVI = hmUI.createWidget(hmUI.widget.IMG, obj_uvi_icon_xp)

        // pai图标息屏
        let PAI = hmUI.createWidget(hmUI.widget.IMG, obj_pai_icon_xp)

        // 步数图标息屏
        let step = hmUI.createWidget(hmUI.widget.IMG, obj_step_icon_xp)

        // 遮罩
        let mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
          x: 0,
          y: 0,
          w: 390,
          h: 450,
          src: ROOTPATH + 'masks.png',
          show_level: hmUI.show_level.ONLY_EDIT,
        })

        // 左边控件热区跳转
        let left_data_type = get_widget_type(left_edit_type)
        const left_edit_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          ...obj_left_edit_click,
          type: left_data_type,
        })

        // 中间控件热区跳转
        let cneter_data_type = get_widget_type(center_edit_type)
        const center_edit_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          ...obj_cneter_edit_click,
          type: cneter_data_type,
        })

        // 右边控件热区跳转
        let right_data_type = get_widget_type(right_edit_type)
        const right_edit_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          ...obj_right_edit_click,
          type: right_data_type,
        })

        // 电量热区跳转
        const battery_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, obj_battery_click)

        // 紫外线热区跳转
        const uvi_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, obj_uvi_click)

        // 天气热区跳转
        const weather_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, obj_weather_click)

        // PAI热区跳转
        const pai_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, obj_pai_click)
      },

      onInit() {
        console.log('index page.js on init invoke')

        this.init_view()
      },

      onReady() {
        console.log('index page.js on ready invoke')
      },

      onShow() {
        console.log('index page.js on show invoke')
      },

      onHide() {
        console.log('index page.js on hide invoke')
      },

      onDestory() {
        console.log('index page.js on destory invoke')
      },
    })
    /*
     * end js
     */
  })()
} catch (e) {
  console.log(e)
}
