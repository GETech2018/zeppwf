try {
  (() => {

    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

    /*
     * huamiOS bundle tool v1.0.17
     * Copyright © Huami. All Rights Reserved
     */
    'use strict';

    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let rootPath = null
    let bgPath = null
    let calPath = null
    let dayPath = null
    let heartPath = null
    let hourPath = null
    let loop_bluePath = null
    let loop_greenPath = null
    let loop_redPath = null
    let loop_yellowPath = null
    let selectPath = null
    let weatherPath = null
    let weekPath = null
    let iconPath = null

    let cal_array = null
    let day_array = null
    let heart_array = null
    let hour_arrray = null
    let loop_blue_array = null
    let loop_green_array = null
    let loop_red_array = null
    let loop_yellow_array = null
    let weather_array = null
    let week_array = null

    let cal_text1 = null
    let cal_text2 = null
    let cal_text3 = null

    let clockTimer = null


    const logger = DeviceRuntimeCore.HmLogger.getLogger("defult");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      drawWidget(item) {
        let config = {
          iconX: 285,
          iconY: 31,
          icon_img: null,
          type: null,
          numX: 323,
          numY: 28
        }
        config.invalid_img = heartPath + "null.png"
        config.array = heart_array
        //  let widgetOptionalArray = [
        //   { type: hmUI.edit_type.HEART, preview: iconPath + "heart.png" },
        //   { type: hmUI.edit_type.UVI, preview: iconPath + "uvi.png" },
        //   { type: hmUI.edit_type.PAI, preview: iconPath + "pai.png" },
        //   { type: hmUI.edit_type.AQI, preview: iconPath + "aqi.png" },
        //   { type: hmUI.edit_type.HUMIDITY, preview: iconPath + "hum.png" }
        // ]

        switch (item) {
          case hmUI.edit_type.HEART:
            config.icon_img = iconPath + "heart.png"
            config.type = hmUI.data_type.HEART

            break;
          case hmUI.edit_type.UVI:
            config.icon_img = iconPath + "uvi.png"
            config.type = hmUI.data_type.UVI
            config.numX = config.numX + 6

            break;
          case hmUI.edit_type.PAI:
            config.icon_img = iconPath + "pai.png"
            config.type = hmUI.data_type.PAI_DAILY

            break;
          // case hmUI.edit_type.AQI:
          //   config.icon_img = iconPath + "aqi.png"
          //   config.type = hmUI.data_type.AQI

          //   break;
          case hmUI.edit_type.HUMIDITY:
            config.icon_img = iconPath + "hum.png"
            config.type = hmUI.data_type.HUMIDITY

            break;

          default:
            break;
        }

        // 组件图标
        let item_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: config.iconX,
          y: config.iconY,
          src: config.icon_img,
          show_level: hmUI.show_level.ONLY_NORMAL
        })

        // 组件数值
        let item_Text = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: config.numX,
          y: config.numY,
          type: config.type,
          font_array: config.array,
          h_space: 0,
          align_h: hmUI.align.LEFT,
          invalid_image: config.invalid_img,
          padding: false,
          show_level: hmUI.show_level.ONLY_NORMAL,
        })
      },
      calText(current, target) {
        let maxTemp = (current / target)
        let temp = null


        if (maxTemp >= 1) {
          cal_text1.setProperty(hmUI.prop.SRC, cal_array[0]);
          cal_text2.setProperty(hmUI.prop.SRC, cal_array[0]);
          cal_text3.setProperty(hmUI.prop.SRC, cal_array[1])
        } else if (maxTemp == 0) {
          // 当数值为0时，就显示0
          cal_text1.setProperty(hmUI.prop.SRC, cal_array[0]);
          cal_text2.setProperty(hmUI.prop.VISIBLE, false);
          cal_text3.setProperty(hmUI.prop.VISIBLE, false)
        } else if (maxTemp >= 0.1) {
          temp = Math.floor(maxTemp * 10)
        } else {
          temp = Math.floor(maxTemp * 100)
        }

        let s = Math.floor(temp / 10)
        let i = parseInt(temp % 10)


        console.log(s + "55555555")
        console.log(i + "55555555")

        if (s > 0) {
          cal_text1.setProperty(hmUI.prop.SRC, cal_array[s]);
          cal_text2.setProperty(hmUI.prop.SRC, cal_array[i]);
          cal_text3.setProperty(hmUI.prop.VISIBLE, false)

        } else {
          console.log(2222222222 + temp)
          cal_text1.setProperty(hmUI.prop.SRC, cal_array[i]);
          cal_text2.setProperty(hmUI.prop.VISIBLE, false);
          cal_text3.setProperty(hmUI.prop.VISIBLE, false)

          console.log(3333333333 + s)
        }

      },
      init_view() {
        rootPath = "images/";
        bgPath = rootPath + "bg/"
        calPath = rootPath + "cal/"
        dayPath = rootPath + "day/"
        heartPath = rootPath + "heart/"
        hourPath = rootPath + "hour/"
        loop_bluePath = rootPath + "loop/blue/"
        loop_greenPath = rootPath + "loop/green/"
        loop_redPath = rootPath + "loop/red/"
        loop_yellowPath = rootPath + "loop/yellow/"
        selectPath = rootPath + "select/"
        weatherPath = rootPath + "weather/"
        weekPath = rootPath + "week/"
        x: 300,
          iconPath = rootPath + "icon/"
        // 20  23
        cal_array = [
          calPath + "0.png",
          calPath + "1.png",
          calPath + "2.png",
          calPath + "3.png",
          calPath + "4.png",
          calPath + "5.png",
          calPath + "6.png",
          calPath + "7.png",
          calPath + "8.png",
          calPath + "9.png"
        ]

        // 20  25      
        day_array = [
          dayPath + "0.png",
          dayPath + "1.png",
          dayPath + "2.png",
          dayPath + "3.png",
          dayPath + "4.png",
          dayPath + "5.png",
          dayPath + "6.png",
          dayPath + "7.png",
          dayPath + "8.png",
          dayPath + "9.png",
        ]

        // 20   40
        heart_array = [
          heartPath + "0.png",
          heartPath + "1.png",
          heartPath + "2.png",
          heartPath + "3.png",
          heartPath + "4.png",
          heartPath + "5.png",
          heartPath + "6.png",
          heartPath + "7.png",
          heartPath + "8.png",
          heartPath + "9.png",
        ]

        // 54  64
        hour_arrray = [
          hourPath + "0.png",
          hourPath + "1.png",
          hourPath + "2.png",
          hourPath + "3.png",
          hourPath + "4.png",
          hourPath + "5.png",
          hourPath + "6.png",
          hourPath + "7.png",
          hourPath + "8.png",
          hourPath + "9.png",
        ]

        loop_blue_array = [
          loop_bluePath + "1.png",
          loop_bluePath + "2.png",
          loop_bluePath + "3.png",
          loop_bluePath + "4.png",
          loop_bluePath + "5.png",
          loop_bluePath + "6.png",
          loop_bluePath + "7.png",
          loop_bluePath + "8.png",
          loop_bluePath + "9.png",
          loop_bluePath + "10.png",
        ]

        loop_green_array = [
          loop_greenPath + "1.png",
          loop_greenPath + "2.png",
          loop_greenPath + "3.png",
          loop_greenPath + "4.png",
          loop_greenPath + "5.png",
          loop_greenPath + "6.png",
          loop_greenPath + "7.png",
          loop_greenPath + "8.png",
          loop_greenPath + "9.png",
          loop_greenPath + "10.png",
        ]

        loop_red_array = [
          loop_redPath + "1.png",
          loop_redPath + "2.png",
          loop_redPath + "3.png",
          loop_redPath + "4.png",
          loop_redPath + "5.png",
          loop_redPath + "6.png",
          loop_redPath + "7.png",
          loop_redPath + "8.png",
          loop_redPath + "9.png",
          loop_redPath + "10.png",
        ]

        loop_yellow_array = [
          loop_yellowPath + "1.png",
          loop_yellowPath + "2.png",
          loop_yellowPath + "3.png",
          loop_yellowPath + "4.png",
          loop_yellowPath + "5.png",
          loop_yellowPath + "6.png",
          loop_yellowPath + "7.png",
          loop_yellowPath + "8.png",
          loop_yellowPath + "9.png",
          loop_yellowPath + "10.png",
        ]
        // 天气图标
        weather_array = [
          weatherPath + "0.png",
          weatherPath + "1.png",
          weatherPath + "2.png",
          weatherPath + "3.png",
          weatherPath + "4.png",
          weatherPath + "5.png",
          weatherPath + "6.png",
          weatherPath + "7.png",
          weatherPath + "8.png",
          weatherPath + "9.png",
          weatherPath + "10.png",
          weatherPath + "11.png",
          weatherPath + "12.png",
          weatherPath + "13.png",
          weatherPath + "14.png",
          weatherPath + "15.png",
          weatherPath + "16.png",
          weatherPath + "17.png",
          weatherPath + "18.png",
          weatherPath + "19.png",
          weatherPath + "20.png",
          weatherPath + "21.png",
          weatherPath + "22.png",
          weatherPath + "23.png",
          weatherPath + "24.png",
          weatherPath + "25.png",
          weatherPath + "26.png",
          weatherPath + "27.png",
          weatherPath + "28.png",
        ]

        // 星期
        week_array = [
          weekPath + "1.png",
          weekPath + "2.png",
          weekPath + "3.png",
          weekPath + "4.png",
          weekPath + "5.png",
          weekPath + "6.png",
          weekPath + "7.png",
        ]

        // 背景
        let bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 390,
          h: 450,
          src: bgPath + "bg.png",
          show_level: hmUI.show_level.ONLY_NORMAL
        })

        // 步数进度条
        let stepsLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 161,
          y: 30,
          image_array: loop_red_array,
          image_length: loop_red_array.length, //长度
          type: hmUI.data_type.STEP,
          show_level: hmUI.show_level.ONLY_NORMAL
        })

        // 站立进度
        let standLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 45,
          y: 264,
          image_array: loop_blue_array,
          image_length: loop_blue_array.length, //长度
          type: hmUI.data_type.STAND,
          show_level: hmUI.show_level.ONLY_NORMAL
        })

        // 脂肪燃烧进度
        let fatLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 0,
          y: 45,
          image_array: loop_green_array,
          image_length: loop_green_array.length, //长度
          type: hmUI.data_type.FAT_BURNING,
          show_level: hmUI.show_level.ONLY_NORMAL
        })

        // CAL进度
        let caiLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 39,
          y: 342,
          image_array: loop_yellow_array,
          image_length: loop_yellow_array.length, //长度
          type: hmUI.data_type.CAL,
          show_level: hmUI.show_level.ONLY_NORMAL
        })

        // 星期
        let weekText = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
          x: 216,
          y: 293,
          week_en: week_array,
          week_tc: week_array,
          week_sc: week_array,
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD,
        });

        // 时间

        let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          hour_zero: 1, //是否补零
          hour_startX: 68,
          hour_startY: 191,
          hour_array: hour_arrray,
          hour_space: -2, //每个数组间的间隔
          hour_unit_sc: hourPath + "maohao.png",
          hour_unit_tc: hourPath + "maohao.png",
          hour_unit_en: hourPath + "maohao.png",
          minute_zero: 1, //是否补零
          minute_startX: 222,
          minute_startY: 191,
          minute_array: hour_arrray,
          minute_space: -2, //每个数组间的间隔

          am_x: 166,
          am_y: 133,
          am_sc_path: hourPath + "am.png",
          am_en_path: hourPath + "am.png",
          pm_x: 166,
          pm_y: 133,
          pm_sc_path: hourPath + "pm.png",
          pm_en_path: hourPath + "pm.png",
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD,
        });

        // 月份
        let dayText = hmUI.createWidget(hmUI.widget.IMG_DATE, {
          month_startX: 110,
          month_startY: 293,
          month_space: 0, //文字间隔
          month_zero: 1, //是否补零 
          month_en_array: day_array,
          month_sc_array: day_array,
          month_tc_array: day_array,
          month_unit_sc: dayPath + "xie.png", //单位
          month_unit_tc: dayPath + "xie.png",
          month_unit_en: dayPath + "xie.png",
          day_startX: 168,
          day_startY: 293,
          day_space: 0, //文字间隔
          day_zero: 1, //是否补零 
          day_en_array: day_array,
          day_sc_array: day_array,
          day_tc_array: day_array,
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD,
        });

        // 天气图标
        let weatherLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 33,
          y: 31,
          image_array: weather_array,
          image_length: weather_array.length, //长度
          type: hmUI.data_type.WEATHER,
          show_level: hmUI.show_level.ONLY_NORMAL
        });


        // 创建传感器
        var calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
        // 首次渲染
        cal_text1 = hmUI.createWidget(hmUI.widget.IMG, {
          x: 320,
          y: 406,
          show_level: hmUI.show_level.ONLY_NORMAL
        })
        cal_text2 = hmUI.createWidget(hmUI.widget.IMG, {
          x: 300,
          y: 406,
          show_level: hmUI.show_level.ONLY_NORMAL
        })
        cal_text3 = hmUI.createWidget(hmUI.widget.IMG, {
          x: 280,
          y: 406,
          show_level: hmUI.show_level.ONLY_NORMAL
        })
        // log传感器属性
        console.log(calorie.current + "111111111111")
        console.log(calorie.target)

        // 百分号图标
        let baifen_text = hmUI.createWidget(hmUI.widget.IMG, {
          x: 340,
          y: 406,
          src: calPath + "baifen.png",
          show_level: hmUI.show_level.ONLY_NORMAL
        })




        // let qian = Math.floor(calorie.target / calorie.current)
        // 监听传感器事件
        // calorie.addEventListener(hmSensor.event.CHANGE, function () {
        //   console.log(calorie.current + "2222222222");
        //   console.log(calorie.target);
        // });

        let widgetOptionalArray = [{
          type: hmUI.edit_type.HEART,
          preview: iconPath + "heart.png"
        },
        {
          type: hmUI.edit_type.UVI,
          preview: iconPath + "uvi.png"
        },
        {
          type: hmUI.edit_type.PAI,
          preview: iconPath + "pai.png"
        },
        // {
        //   type: hmUI.edit_type.AQI,
        //   preview: iconPath + "aqi.png"
        // },
        {
          type: hmUI.edit_type.HUMIDITY,
          preview: iconPath + "hum.png"
        }
        ]
        // 可编辑组件
        let groupX = 285;
        let groupY = 31
        let Group1 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 101,
          x: groupX,
          y: groupY,
          w: 48,
          h: 48,
          select_image: selectPath + "select.png",
          un_select_image: selectPath + "unselect.png",
          default_type: hmUI.edit_type.HEART,
          optional_types: widgetOptionalArray,
          count: widgetOptionalArray.length,
          tips_BG: selectPath + "tips.png",
          tips_x: -70,
          tips_y: 50,
          tips_width: 114,
        });

        var item = Group1.getProperty(hmUI.prop.CURRENT_TYPE);
        this.drawWidget(item);


        let maskCover = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK, {
          x: 0,
          y: 0,
          w: 390,
          h: 450,
          src: selectPath + "mask70.png",
          show_level: hmUI.show_level.ONLY_EDIT,
        });

        let mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
          x: 0,
          y: 0,
          w: 390,
          h: 450,
          src: selectPath + "mask100.png",
          show_level: hmUI.show_level.ONLY_EDIT,
        });

        const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: () => {
            clockTimer = timer.createTimer(
              0, 30000,
              () => {
                calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
                this.calText(calorie.current, calorie.target)
              }
            )
          },
          pause_call: (function () {
            timer.stopTimer(clockTimer)
          }),

        });

      },

      onInit() {
        console.log('index page.js on init invoke');

        this.init_view();


      },

      onReady() {
        console.log('index page.js on ready invoke')
      },

      onShow() {
        console.log('index page.js on show invoke')
      },

      onHide() {
        console.log('index page.js on hide invoke')
      },

      onDestory() {
        console.log('index page.js on destory invoke')
      },
    });
    /*
     * end js
     */
  })()
} catch (e) {
  console.log(e)
}