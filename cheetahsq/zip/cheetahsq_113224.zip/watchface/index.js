/*
 * huamiOS bundle tool v1.0.17
 * Copyright © Huami. All Rights Reserved
 */
try {
  (() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__),
      'drink'
    );
    ('use strict');

    const logger = DeviceRuntimeCore.HmLogger.getLogger('ageset');

    /*params声明*/
    let strPath = 'images/';
    let arrBat = [];
    let arrTime = [];
    let arrLevel = [];
    let arrHour = [];
    let arrMin = [];
    let arrAodTime = [];
    let arrWeek = [];
    let arrDate = [];
    let arrStep = [];
    let arrHeart = [];
    let bat_rect = null;
    let step_rect = null;
    let stand_rect = null;

    for (let i = 1; i < 8; i++) {
      arrWeek.push(strPath + 'week/0' + i + '.png');
    }
    for (let i = 0; i < 10; i++) {
      arrDate.push('images/date/0' + i + '.png');
      arrTime.push(strPath + 'time/0' + i + '.png');
      arrAodTime.push(strPath + 'aod/0' + i + '.png');
      arrStep.push(strPath + 'steps/0' + i + '.png');
      arrHeart.push(strPath + 'heart/0' + i + '.png');
    }
    for (let i = 1; i < 11; i++) {
      arrLevel.push('images/level/' + i + '.png');
    }
    let objTime = {
      hour_zero: 1,
      hour_startX: 168,
      hour_startY: 65,
      hour_array: arrTime,
      hour_space: 0,
      hour_align: hmUI.align.LEFT,
      minute_zero: 1,
      minute_startX: 168,
      minute_startY: 199,
      minute_array: arrTime,
      minute_space: 0,
      minute_align: hmUI.align.LEFT,
      am_x: 191,
      am_y: 17,
      am_sc_path: strPath + 'date/am.png',
      am_en_path: strPath + 'date/am.png',
      pm_x: 191,
      pm_y: 17,
      pm_sc_path: strPath + 'date/pm.png',
      pm_en_path: strPath + 'date/pm.png',
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    let objAodTime = {
      hour_zero: 1,
      hour_startX: 168,
      hour_startY: 65,
      hour_array: arrAodTime,
      hour_space: 0,
      hour_align: hmUI.align.LEFT,
      minute_zero: 1,
      minute_startX: 168,
      minute_startY: 199,
      minute_array: arrAodTime,
      minute_space: 0,
      minute_align: hmUI.align.LEFT,
      am_x: 191,
      am_y: 17,
      am_sc_path: strPath + 'date/am.png',
      am_en_path: strPath + 'date/am.png',
      pm_x: 191,
      pm_y: 17,
      pm_sc_path: strPath + 'date/pm.png',
      pm_en_path: strPath + 'date/pm.png',
      show_level: hmUI.show_level.ONLY_AOD,
    };
    let objWeek = {
      x: 245,
      y: 17,
      week_en: arrWeek,
      week_tc: arrWeek,
      week_sc: arrWeek,
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
    };
    let objDate = {
      day_startX: 315,
      day_startY: 17,
      day_align: hmUI.align.LEFT,
      day_space: 0,
      day_zero: 1,
      day_en_array: arrDate,
      day_sc_array: arrDate,
      day_tc_array: arrDate,
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
    };
    let objHeartP = {
      scale_x: 0,
      scale_y: 0,
      src: strPath + 'hr_pt.png',
      center_x: 85,
      center_y: 259,
      x: 12,
      y: 63,
      type: hmUI.data_type.HEART,
      invalid_visible: true,
      start_angle: -155,
      end_angle: 155,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      /*get data */
      getFont(options) {
        let objConfig = {
          x: 0,
          y: 0,
          w: 0,
          type: '',
          font_array: arrDate,
          h_space: 0,
          align_h: hmUI.align.LEFT,
          unit_sc: '',
          unit_tc: '',
          unit_en: '',
          invalid_image: '',
          dot_image: '',
          padding: !1,
          negative_image: '',
          show_level: hmUI.show_level.ONLY_NORMAL,
        };
        for (let key in options) {
          if (key in objConfig) {
            objConfig[key] = options[key];
          }
        }
        for (let key in objConfig) {
          if (!objConfig[key]) {
            delete objConfig[key];
          }
        }
        let text = hmUI.createWidget(hmUI.widget.TEXT_IMG, objConfig);
      },
      /* get img */
      getIcon(options) {
        let { x, y, src } = options;
        let icon = hmUI.createWidget(hmUI.widget.IMG, {
          x: x,
          y: y,
          src: src,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        return icon;
      },
      /* click jump */
      changeClick(options) {
        let { x, y, w, h, type } = options;
        let click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: x,
          y: y,
          w: w,
          h: h,
          type: type,
        });
      },

      init_view() {
        var that = this;
        /* get power */
        var battery = hmSensor.createSensor(hmSensor.id.BATTERY);
        var stand = hmSensor.createSensor(hmSensor.id.STAND);
        var step = hmSensor.createSensor(hmSensor.id.STEP);

        /* bg runbg heartbg */
        this.getIcon({ x: 0, y: 0, src: strPath + 'bg.png' });
        this.getIcon({ x: 26, y: 66, src: strPath + 'run_btn.png' });
        this.getIcon({ x: 26, y: 200, src: strPath + 'hr_bg.png' });
        bat_rect = hmUI.createWidget(hmUI.widget.FILL_RECT, {
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        battery.addEventListener(hmSensor.event.CHANGE, function () {
          setPower();
        });
        step_rect = hmUI.createWidget(hmUI.widget.FILL_RECT, {
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        step.addEventListener(hmSensor.event.CHANGE, function () {
          setPower();
        });
        stand_rect = hmUI.createWidget(hmUI.widget.FILL_RECT, {
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        stand.addEventListener(hmSensor.event.CHANGE, function () {
          setPower();
        });

        /* heart data */
        this.getFont({
          x: 49,
          y: 236,
          w: 70,
          type: hmUI.data_type.HEART,
          font_array: arrHeart,
          align_h: hmUI.align.CENTER_H,
          invalid_image: strPath + 'heart/null.png',
        });

        /* heart pointer */
        let Heart_Pt = hmUI.createWidget(hmUI.widget.IMG_POINTER, objHeartP);

        /* step data */
        this.getFont({
          x: 186,
          y: 353,
          w: 100,
          type: hmUI.data_type.STEP,
          font_array: arrStep,
        });

        /* step mask */
        this.getIcon({ x: 168, y: 347, src: strPath + 'mask_p.png' });
        this.getIcon({ x: 168, y: 393, src: strPath + 'mask_p.png' });

        /* bat data */
        this.getFont({
          x: 59,
          y: 17,
          type: hmUI.data_type.BATTERY,
          unit_sc: strPath + 'date/10.png',
          unit_tc: strPath + 'date/10.png',
          unit_en: strPath + 'date/10.png',
        });

        /* bat level */
        this.getIcon({ x: 39, y: 21, src: strPath + 'power_bg.png' });

        /* time */
        let times = hmUI.createWidget(hmUI.widget.IMG_TIME, objTime);
        let timeAod = hmUI.createWidget(hmUI.widget.IMG_TIME, objAodTime);

        /* week */
        hmUI.createWidget(hmUI.widget.IMG_WEEK, objWeek);

        /* data */
        let timeDate = hmUI.createWidget(hmUI.widget.IMG_DATE, objDate);
        setPower();

        /* hot jump */
        this.changeClick({
          x: 26,
          y: 66,
          w: 118,
          h: 118,
          type: hmUI.data_type.OUTDOOR_RUNNING,
        });
        this.changeClick({
          x: 26,
          y: 200,
          w: 118,
          h: 118,
          type: hmUI.data_type.HEART,
        });
        this.changeClick({
          x: 29,
          y: 337,
          w: 102,
          h: 51,
          type: hmUI.data_type.STEP,
        });
        this.changeClick({
          x: 175,
          y: 347,
          w: 180,
          h: 32,
          type: hmUI.data_type.STEP,
        });
        this.changeClick({
          x: 29,
          y: 388,
          w: 108,
          h: 51,
          type: hmUI.data_type.STAND,
        });
        this.changeClick({
          x: 175,
          y: 393,
          w: 180,
          h: 42,
          type: hmUI.data_type.STAND,
        });

        /* slide event */
        let widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: function () {
            setPower();
          },
          pause_call: function () {
            console.log('ui pause');
          },
        });
        /* bat level */
        function setPower() {
          /* bat */
          let batCount = battery.current;
          let bath = 13 * (batCount / 100);
          let bathY = 13 - bath + 29;
          /* step */
          let stepN = step.current;
          //   let stepN = 4000;
          let stepT = step.target;
          let stepsRadio = stepN / stepT > 1 ? 1 : stepN / stepT;
          let stepW = 180 * stepsRadio;
          /* stand 36 72 108 144  */
          let standN = stand.current;
          //   let standN = 13;
          let standT = stand.target;
          let standRadio = standN / standT > 1 ? 1 : standN / standT;
          let standW = 180 * standRadio;
          let color;
          if (batCount <= 15) {
            color = 0xff0000;
          } else {
            color = 0x999999;
          }
          bat_rect.setProperty(hmUI.prop.MORE, {
            x: 45,
            y: bathY,
            w: 7,
            h: bath,
            color: color,
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          step_rect.setProperty(hmUI.prop.MORE, {
            x: 176,
            y: 347,
            w: stepW,
            h: 32,
            radius: 15,
            color: 0x94ce4b,
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          stand_rect.setProperty(hmUI.prop.MORE, {
            x: 175,
            y: 393,
            w: standW,
            h: 32,
            radius: 15,
            color: 0x94ce4b,
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
        }
      },
      onInit() {
        console.log('index page.js on init invoke');
        this.init_view();
      },
      onReady() {
        console.log('index page.js on ready invoke');
      },
      onShow() {
        console.log('index page.js on show invoke');
      },
      onHide() {
        console.log('index page.js on hide invoke');
      },
      onDestory() {
        console.log('index page.js on destory invoke');
      },
    });
    /*
     * end js
     */
  })();
} catch (e) {
  console.log(e);
}
