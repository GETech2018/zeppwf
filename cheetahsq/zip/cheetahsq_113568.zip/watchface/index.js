/*
 ** huamiOS bundle tool v1.0.17
 * *huamiOS watchface js version v1.0.1
 * *Copyright © Huami. All Rights Reserved
 */

try {
  (() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
    var __$$module$$__ = __$$app$$__.current;
    //drink is a name,can modify
    var h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__),
      'drink'
    );

    ('use strict');
    let rootPath = 'images/';

    let fontArray = [];
    let weekArr_en = [];
    let weekArr_sc = [];
    let monthArr_en = [];
    let monthArr_sc = [];
    for (let i = 0; i < 10; i++) {
      fontArray.push(rootPath + `data/${i}.png`);
    }

    for (let j = 1; j < 8; j++) {
      weekArr_en.push(rootPath + `week/en/${j}.png`);
      weekArr_sc.push(rootPath + `week/cn/${j}.png`);
    }
    for (let k = 1; k < 13; k++) {
      monthArr_en.push(rootPath + `month/en/${k}.png`);
      monthArr_sc.push(rootPath + `month/cn/${k}.png`);
    }

    const logger = DeviceRuntimeCore.HmLogger.getLogger('yeguang');

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        const bg = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
          x: 0,
          y: 30,
          w: 390,
          h: 390,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          anim_path: rootPath + 'breath_animate',
          anim_prefix: 'breath',
          anim_ext: 'png',
          anim_fps: 20,
          anim_size: 200,
          anim_repeat: true,
          repeat_count: 0,
          anim_status: 1,
          //   display_on_restart: true,
        });
        showHeart();
        showStep();
        const weekLevel = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
          x: 220,
          y: 402,
          week_sc: weekArr_sc,
          week_tc: weekArr_sc,
          week_en: weekArr_en,
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
        });

        const day_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
          month_startX: 73,
          month_startY: 402,
          month_en_array: monthArr_en,
          month_sc_array: monthArr_sc,
          month_tc_array: monthArr_sc,
          month_space: 0,
          month_zero: 1,
          month_is_character: true,
          day_startX: 166,
          day_startY: 402,
          day_en_array: fontArray,
          day_space: 0,
          day_zero: 1,
          // day_follow: 1,
          day_unit_sc: rootPath + 'img/comma.png',
          day_unit_tc: rootPath + 'img/comma.png',
          day_unit_en: rootPath + 'img/comma.png',
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
        });
        showAodTime();
        showNomalTime();

        let click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 272,
          y: 18,
          w: 100,
          h: 32,
          type: hmUI.data_type.HEART,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let step_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 24,
          y: 18,
          w: 100,
          h: 32,
          type: hmUI.data_type.STEP,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        function showNomalTime() {
          const timePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
            hour_centerX: 195,
            hour_centerY: 225,
            hour_posX: 17,
            hour_posY: 225,
            hour_path: rootPath + 'img/hour.png',

            minute_centerX: 195,
            minute_centerY: 225,
            minute_posX: 17,
            minute_posY: 225,
            minute_path: rootPath + 'img/min.png',

            second_centerX: 195,
            second_centerY: 225,
            second_posX: 10,
            second_posY: 225,
            second_path: rootPath + 'img/sec.png',
            enable: false,
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
        }
        function showAodTime() {
          const aod_timePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
            hour_centerX: 195,
            hour_centerY: 225,
            hour_posX: 17,
            hour_posY: 225,
            hour_path: rootPath + 'img/hour_xp.png',

            minute_centerX: 195,
            minute_centerY: 225,
            minute_posX: 17,
            minute_posY: 225,
            minute_path: rootPath + 'img/min_xp.png',
            show_level: hmUI.show_level.ONLY_AOD,
          });
        }

        function showHeart() {
          let heartTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
            x: 272,
            y: 18,
            type: hmUI.data_type.HEART,
            font_array: fontArray,
            h_space: 0,
            align_h: hmUI.align.RIGHT,
            padding: false,
            invalid_image: rootPath + 'img/invalid.png',
            show_level: hmUI.show_level.ONLY_NORMAL,
          });

          let heartImg = hmUI.createWidget(hmUI.widget.IMG, {
            x: 334,
            y: 18,
            w: 32,
            h: 32,
            src: rootPath + 'img/heart.png',
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
        }
        function showStep() {
          let stepTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
            x: 64,
            y: 18,
            type: hmUI.data_type.STEP,
            font_array: fontArray,
            h_space: 0,
            align_h: hmUI.align.LEFT,
            padding: false,
            show_level: hmUI.show_level.ONLY_NORMAL,
          });

          var stepImg = hmUI.createWidget(hmUI.widget.IMG, {
            x: 24,
            y: 18,
            w: 32,
            h: 32,
            src: rootPath + 'img/step.png',
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
        }
      },

      onInit() {
        console.log('index page.js on init invoke');

        this.init_view();
      },

      onReady() {
        console.log('index page.js on ready invoke');
      },

      onShow() {
        console.log('index page.js on show invoke');
      },

      onHide() {
        console.log('index page.js on hide invoke');
      },

      onDestory() {
        console.log('index page.js on destory invoke');
      },
    });
  })();
} catch (e) {
  console.log(e);
}
