try {
    (() => {
    
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
  
    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');
  
      /*
    * hugray_small_numiOS bundle tool v1.0.17
    * Copyright © Hugray_small_numi. All Rights Reserved
    */
    'use strict';
  
    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let rootPath = null
 
    let timeArray = null
    let monthArray =null 
    let dateArray = null
    let bg = null
    let animArray = new Array()
    let weekArr = null

    

    let clock_timer = null
    let monthImg = null
    let dayImg = null
    let  batArray = null
    let  stepArray = null
    let  calArray = null
    let  heartArray = null
    let index = 0
    let smilingFace = null
    const logger = DeviceRuntimeCore.HmLogger.getLogger("default2");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({

     

        init_view() {
           
            rootPath = "images/",
            timeArray = [
                rootPath +  "time/di_0.png",
                rootPath +  "time/di_1.png",
                rootPath +  "time/di_2.png",
                rootPath +  "time/di_3.png",
                rootPath +  "time/di_4.png",
                rootPath +  "time/di_5.png",
                rootPath +  "time/di_6.png",
                rootPath +  "time/di_7.png",
                rootPath +  "time/di_8.png",
                rootPath +  "time/di_9.png",
            ]
            dateArray = [
                rootPath + "date/0.png",
                rootPath + "date/1.png",
                rootPath + "date/2.png",
                rootPath + "date/3.png",
                rootPath + "date/4.png",
                rootPath + "date/5.png",
                rootPath + "date/6.png",
                rootPath + "date/7.png",
                rootPath + "date/8.png",
                rootPath + "date/9.png",
            ]
            weekArr = [
                
                rootPath + "week/1.png",
                rootPath + "week/2.png",
                rootPath + "week/3.png",
                rootPath + "week/4.png",
                rootPath + "week/5.png",
                rootPath + "week/6.png",
                rootPath + "week/7.png",
               
            ]
           
            batArray = [
                rootPath + "batNum/g_0.png",
                rootPath + "batNum/g_1.png",
                rootPath + "batNum/g_2.png",
                rootPath + "batNum/g_3.png",
                rootPath + "batNum/g_4.png",
                rootPath + "batNum/g_5.png",
                rootPath + "batNum/g_6.png",
                rootPath + "batNum/g_7.png",
                rootPath + "batNum/g_8.png",
                rootPath + "batNum/g_9.png",
            ]
            stepArray = [
                rootPath + "stepNum/0.png",
                rootPath + "stepNum/1.png",
                rootPath + "stepNum/2.png",
                rootPath + "stepNum/3.png",
                rootPath + "stepNum/4.png",
                rootPath + "stepNum/5.png",
                rootPath + "stepNum/6.png",
                rootPath + "stepNum/7.png",
                rootPath + "stepNum/8.png",
                rootPath + "stepNum/9.png",
            ]
            calArray = [
                rootPath + "calNum/0.png",
                rootPath + "calNum/1.png",
                rootPath + "calNum/2.png",
                rootPath + "calNum/3.png",
                rootPath + "calNum/4.png",
                rootPath + "calNum/5.png",
                rootPath + "calNum/6.png",
                rootPath + "calNum/7.png",
                rootPath + "calNum/8.png",
                rootPath + "calNum/9.png",
            ]
            heartArray = [
                rootPath + "heartNum/0.png",
                rootPath + "heartNum/1.png",
                rootPath + "heartNum/2.png",
                rootPath + "heartNum/3.png",
                rootPath + "heartNum/4.png",
                rootPath + "heartNum/5.png",
                rootPath + "heartNum/6.png",
                rootPath + "heartNum/7.png",
                rootPath + "heartNum/8.png",
                rootPath + "heartNum/9.png",
            ]
            var screenType = hmSetting.getScreenType();
                if(screenType == hmSetting.screen_type.AOD){
                    bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
                        x: 0,
                        y: 0,
                        w: 390,
                        h: 450,
                        color: 0x000000,
                    });
                    showTime();
                }else{
                    bg = hmUI.createWidget(hmUI.widget.IMG,{
                        x: 0,
                        y: 0,
                        w: 390,
                        h: 450,
                        src:  rootPath + "img/bg.png",
                    });

                    smilingFace  = hmUI.createWidget(hmUI.widget.IMG,{
                        x: 269,
                        y: 94,
                        w: 56,
                        h: 60,
                        src: rootPath + "img/face.png",
                    });
                    showTime();
                    let week = hmUI.createWidget(hmUI.widget.IMG_WEEK,{
                        x: 255,
                        y: 178,
                        week_en: weekArr,
                        week_tc: weekArr,
                        week_sc: weekArr,
                        show_level: hmUI.show_level.ONAL_NORMAL,
                    });
                    monthImg = hmUI.createWidget(hmUI.widget.IMG_DATE,{
                        year_startX: 51,
                        year_startY: 178 ,
                        year_align: hmUI.align.LEFT,
                        year_space: 0,
                        year_zero: 1,
                        year_follow: 1,
                        year_unit_sc: rootPath+"img/splite.png",
                        year_unit_tc: rootPath+"img/splite.png",
                        year_unit_en: rootPath+"img/splite.png",
                        year_en_array: dateArray,
                        year_sc_array: dateArray,
                        year_tc_array: dateArray,

                        month_startX: 130,
                        month_startY: 178 ,
                        month_align: hmUI.align.LEFT,
                        month_space: 0,
                        month_zero: 1,
                        month_follow: 1,
                        month_is_character: false, 
                        month_unit_sc: rootPath+"img/splite.png",
                        month_unit_tc: rootPath+"img/splite.png",
                        month_unit_en: rootPath+"img/splite.png",
                        month_en_array: dateArray,
                        month_sc_array: dateArray,
                        month_tc_array: dateArray,

                        day_startX: 174,
                        day_startY: 178 ,
                        day_align: hmUI.align.LEFT,
                        day_space: 0,
                        day_zero: 1,
                        day_follow: 0,
                        day_en_array: dateArray,
                        day_sc_array: dateArray,
                        day_tc_array: dateArray,
                       // day_is_character: true, 
                       show_level: hmUI.show_level.ONAL_NORMAL,
                    });
                    let heartTxt =  hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 107,
                        y: 373,
                        type: hmUI.data_type.HEART, 
                        font_array: heartArray,   
                        h_space: 0,  
                        align_h: hmUI.align.LEFT,
                        padding: false, //是否补零 true为补零 
                        isCharacter: true, //true为文字图片
                       
                        invalid_image:    rootPath + "img/invalid.png",
                        show_level: hmUI.show_level.ONAL_NORMAL,   
                      });
                    let batTxt =  hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 107,
                        y: 239,
                        type: hmUI.data_type.BATTERY, 
                        font_array: batArray,   
                        h_space: 0,  
                        align_h: hmUI.align.LEFT,
                        padding: false, //是否补零 true为补零
                        unit_sc:   rootPath + "img/per.png",
                        unit_tc:   rootPath + "img/per.png",
                        unit_en:   rootPath + "img/per.png", 
                        show_level: hmUI.show_level.ONAL_NORMAL,   
                      });
                    let stepTxt =  hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 107,
                        y: 283,
                        type: hmUI.data_type.STEP, 
                        font_array: stepArray,   
                        h_space: 0,  
                        align_h: hmUI.align.LEFT,
                        padding: false, //是否补零 true为补零
                        show_level: hmUI.show_level.ONAL_NORMAL,   
                      });
                      let calTxt =  hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 107,
                        y: 329,
                        font_array: calArray,   
                        h_space: 0,  
                        align_h: hmUI.align.LEFT,
                        padding: false, //是否补零 true为补零
                        type: hmUI.data_type.CAL,   
                        show_level: hmUI.show_level.ONAL_NORMAL,   
                      });
                    playMotion();
                }
                
                function showTime() {
                    let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                        hour_zero: 1,
                        hour_startX: 112,
                        hour_startY: 99,
                        hour_array: timeArray,
                        hour_space: 0,
                        hour_unit_sc: rootPath+"img/colon.png", //单位
                        hour_unit_tc: rootPath+"img/colon.png",
                        hour_unit_en: rootPath+"img/colon.png",
                        hour_align: hmUI.align.LEFT,

                        minute_zero: 1, //是否补零 1为补零
                        minute_startX: 189,
                        minute_startY: 99,
                        minute_array: timeArray,
                        minute_space: 0, //两个图片间隔 对应GT2的interval
                        minute_follow: 1, //是否跟随
                        minute_align: hmUI.align.LEFT,
                        show_level: hmUI.show_level.ALL,

                        am_x: 67,
                        am_y: 96,
                        am_sc_path:  rootPath+"img/am.png",
                        am_en_path:  rootPath+"img/am.png",

                        pm_x: 67,
                        pm_y: 96,
                        pm_sc_path:  rootPath+"img/pm.png",
                        pm_en_path:  rootPath+"img/pm.png",
                    });
                   
                }
                    
                function playMotion()
                {///*
                    let anim_path = rootPath + "animate/";
                    showClearanceImg(64,239,44,44,   anim_path+"1.png");//1
                    showClearanceImg(64,239,88,89,   anim_path+"2.png");//2
                    showClearanceImg(64,239,132,133, anim_path+"3.png");//
                    showClearanceImg(64,239,176,176, anim_path+"4.png");//4
                    showClearanceImg(110,239,176,176,anim_path+"5.png");//5
                    showClearanceImg(155,239,176,176,anim_path+"6.png");
                    showClearanceImg(197,284,132,131,anim_path+"7.png");
                    showClearanceImg(241,329,88,87,  anim_path+"8.png");
                    showClearanceImg(285,372,44,44,  anim_path+"1.png");//1

                   //创建timer，延时500ms触发，之后每1000ms执行一次
                    timer1 = timer.createTimer(2000, 100, (function (option) {
                        //回调
                       // console.log("timer callback++++++++++++++++++index:"+index);
                        if(index == 9)
                        {
                            smilingFace.setProperty(hmUI.prop.VISIBLE, false);
                            timer.stopTimer(timer1);
                            return;
                        }else{
                            animArray[index].setProperty(hmUI.prop.VISIBLE, false);
                            index++;
                        }
                        
                    }))
                //*/
                } 
                function showClearanceImg(xpos,ypos,w,h,path)
                {
                    let img  = hmUI.createWidget(hmUI.widget.IMG,{
                        x: xpos,
                        y: ypos,
                        w: w,
                        h: h,
                        src:  path,
                    });
                    animArray.push(img);
                }

        },

        onInit() {
            console.log('index page.js on init invoke');

            this.init_view();
       
            


        },

        onReady() {
            console.log('index page.js on ready invoke')
        },

        onShow() {
            console.log('index page.js on show invoke')
        },

        onHide() {
            console.log('index page.js on hide invoke')
        },

        onDestory() {
            console.log('index page.js on destory invoke')
            timer.stopTimer(clock_timer);
        },
    });
    /*
    * end js
    */
        })()
    } catch (e) {
        console.log(e)
    }
