try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$component_0$_$component = '';
        const logger = Logger.getLogger('watchface6');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
                    edit_id: 1,
                    x: 0,
                    y: 0,
                    bg_config: [
                        {
                            'id': 1,
                            'path': '4.png',
                            'preview': '5.png'
                        },
                        {
                            'id': 2,
                            'path': '6.png',
                            'preview': '7.png'
                        },
                        {
                            'id': 3,
                            'path': '8.png',
                            'preview': '9.png'
                        },
                        {
                            'id': 4,
                            'path': '10.png',
                            'preview': '11.png'
                        }
                    ],
                    count: 4,
                    default_id: 1,
                    fg: '3.png',
                    tips_x: 110,
                    tips_y: 380,
                    tips_bg: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 97,
                    y: 380,
                    type: hmUI.data_type.BATTERY,
                    font_array: [
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 3,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '23.png',
                    unit_tc: '23.png',
                    unit_en: '23.png',
                    invalid_image: '22.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 57,
                    y: 384,
                    src: '24.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 315,
                    y: 380,
                    src: '25.png',
                    type: hmUI.system_status.DISCONNECT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 275,
                    y: 380,
                    src: '26.png',
                    type: hmUI.system_status.CLOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 175,
                    y: 304,
                    type: hmUI.data_type.HUMIDITY,
                    font_array: [
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '28.png',
                    unit_tc: '28.png',
                    unit_en: '28.png',
                    invalid_image: '27.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 73,
                    y: 304,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: [
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '31.png',
                    unit_tc: '31.png',
                    unit_en: '31.png',
                    negative_image: '30.png',
                    invalid_image: '29.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 24,
                    y: 301,
                    image_array: [
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png',
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png',
                        '58.png',
                        '59.png',
                        '60.png'
                    ],
                    image_length: 29,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 65,
                    y: 232,
                    type: hmUI.data_type.STEP,
                    font_array: [
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 2,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '61.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 24,
                    y: 238,
                    src: '62.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 232,
                    y: 167,
                    type: hmUI.data_type.SPO2,
                    font_array: [
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 2,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '64.png',
                    unit_tc: '64.png',
                    unit_en: '64.png',
                    invalid_image: '63.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 195,
                    y: 171,
                    src: '65.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 65,
                    y: 169,
                    type: hmUI.data_type.HEART,
                    font_array: [
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 3,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '66.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 23,
                    y: 171,
                    src: '67.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    day_startX: 286,
                    day_startY: 48,
                    day_sc_array: [
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png'
                    ],
                    day_tc_array: [
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png'
                    ],
                    day_en_array: [
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png'
                    ],
                    day_align: hmUI.align.CENTER_H,
                    day_zero: 0,
                    day_follow: 0,
                    day_space: 4,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 284,
                    y: 95,
                    week_en: [
                        '68.png',
                        '69.png',
                        '70.png',
                        '71.png',
                        '72.png',
                        '73.png',
                        '74.png'
                    ],
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 0,
                    hour_startX: 36,
                    hour_startY: 38,
                    hour_array: [
                        '75.png',
                        '76.png',
                        '77.png',
                        '78.png',
                        '79.png',
                        '80.png',
                        '81.png',
                        '82.png',
                        '83.png',
                        '84.png'
                    ],
                    hour_space: 7,
                    hour_unit_sc: '85.png',
                    hour_unit_tc: '85.png',
                    hour_unit_en: '85.png',
                    hour_align: hmUI.align.RIGHT,
                    minute_zero: 1,
                    minute_startX: 135,
                    minute_startY: 38,
                    minute_array: [
                        '75.png',
                        '76.png',
                        '77.png',
                        '78.png',
                        '79.png',
                        '80.png',
                        '81.png',
                        '82.png',
                        '83.png',
                        '84.png'
                    ],
                    minute_space: 7,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    second_zero: 1,
                    second_startX: 223,
                    second_startY: 87,
                    second_array: [
                        '86.png',
                        '87.png',
                        '88.png',
                        '89.png',
                        '90.png',
                        '91.png',
                        '92.png',
                        '93.png',
                        '94.png',
                        '95.png'
                    ],
                    second_space: 3,
                    second_align: hmUI.align.LEFT,
                    second_follow: 0,
                    am_x: 216,
                    am_y: 38,
                    am_en_path: '96.png',
                    pm_x: 216,
                    pm_y: 38,
                    pm_en_path: '97.png',
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 257,
                    y: 304,
                    type: hmUI.data_type.ALTIMETER,
                    font_array: [
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '99.png',
                    unit_tc: '99.png',
                    unit_en: '99.png',
                    invalid_image: '98.png',
                    padding: false,
                    isCharacter: false
                });
                normal$_$component_0$_$component = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: 2,
                    x: 197,
                    y: 227,
                    w: 167,
                    h: 51,
                    select_image: '100.png',
                    un_select_image: '101.png',
                    default_type: hmUI.edit_type.CAL,
                    optional_types: [
                        {
                            'type': hmUI.edit_type.CAL,
                            'preview': '103.png'
                        },
                        {
                            'type': hmUI.edit_type.DISTANCE,
                            'preview': '104.png'
                        },
                        {
                            'type': hmUI.edit_type.PAI_DAILY,
                            'preview': '105.png'
                        }
                    ],
                    count: 3,
                    tips_BG: '102.png',
                    tips_x: -1,
                    tips_y: -69,
                    tips_width: 167,
                    tips_margin: 10
                });
                editType = normal$_$component_0$_$component.getProperty(hmUI.prop.CURRENT_TYPE);
                switch (editType) {
                case hmUI.edit_type.STEP:
                    break;
                case hmUI.edit_type.BATTERY:
                    break;
                case hmUI.edit_type.HEART:
                    break;
                case hmUI.edit_type.CAL:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 235,
                        y: 232,
                        type: hmUI.data_type.CAL,
                        font_array: [
                            '12.png',
                            '13.png',
                            '14.png',
                            '15.png',
                            '16.png',
                            '17.png',
                            '18.png',
                            '19.png',
                            '20.png',
                            '21.png'
                        ],
                        align_h: hmUI.align.LEFT,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        unit_sc: '107.png',
                        unit_tc: '107.png',
                        unit_en: '107.png',
                        invalid_image: '106.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 195,
                        y: 238,
                        src: '108.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.PAI_DAILY:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 235,
                        y: 232,
                        type: hmUI.data_type.PAI_DAILY,
                        font_array: [
                            '12.png',
                            '13.png',
                            '14.png',
                            '15.png',
                            '16.png',
                            '17.png',
                            '18.png',
                            '19.png',
                            '20.png',
                            '21.png'
                        ],
                        align_h: hmUI.align.LEFT,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '109.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 195,
                        y: 238,
                        src: '110.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.DISTANCE:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 235,
                        y: 232,
                        type: hmUI.data_type.DISTANCE,
                        font_array: [
                            '12.png',
                            '13.png',
                            '14.png',
                            '15.png',
                            '16.png',
                            '17.png',
                            '18.png',
                            '19.png',
                            '20.png',
                            '21.png'
                        ],
                        align_h: hmUI.align.LEFT,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        unit_sc: '113.png',
                        unit_tc: '113.png',
                        unit_en: '113.png',
                        imperial_unit_sc: '114.png',
                        imperial_unit_tc: '114.png',
                        imperial_unit_en: '114.png',
                        dot_image: '112.png',
                        invalid_image: '111.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 195,
                        y: 238,
                        src: '115.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.AQI:
                    break;
                case hmUI.edit_type.HUMIDITY:
                    break;
                case hmUI.edit_type.ALTIMETER:
                    break;
                case hmUI.edit_type.STRESS:
                    break;
                case hmUI.edit_type.WIND:
                    break;
                case hmUI.edit_type.SPO2:
                    break;
                case hmUI.edit_type.TRAINING_LOAD:
                    break;
                case hmUI.edit_type.VO2MAX:
                    break;
                case hmUI.edit_type.UVI:
                    break;
                case hmUI.edit_type.DATE:
                    break;
                case hmUI.edit_type.WEEK:
                    break;
                case hmUI.edit_type.WEATHER:
                    break;
                case hmUI.edit_type.TEMPERATURE:
                    break;
                case hmUI.edit_type.SUN:
                    break;
                }
                hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
                    x: 0,
                    y: 0,
                    w: 390,
                    h: 450,
                    src: '116.png',
                    show_level: hmUI.show_level.ONLY_EDIT
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 0,
                    hour_startX: 36,
                    hour_startY: 38,
                    hour_array: [
                        '75.png',
                        '76.png',
                        '77.png',
                        '78.png',
                        '79.png',
                        '80.png',
                        '81.png',
                        '82.png',
                        '83.png',
                        '84.png'
                    ],
                    hour_space: 7,
                    hour_unit_sc: '117.png',
                    hour_unit_tc: '117.png',
                    hour_unit_en: '117.png',
                    hour_align: hmUI.align.RIGHT,
                    minute_zero: 1,
                    minute_startX: 135,
                    minute_startY: 38,
                    minute_array: [
                        '75.png',
                        '76.png',
                        '77.png',
                        '78.png',
                        '79.png',
                        '80.png',
                        '81.png',
                        '82.png',
                        '83.png',
                        '84.png'
                    ],
                    minute_space: 7,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    am_x: 216,
                    am_y: 38,
                    am_en_path: '118.png',
                    pm_x: 216,
                    pm_y: 38,
                    pm_en_path: '119.png',
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    day_startX: 286,
                    day_startY: 48,
                    day_sc_array: [
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png'
                    ],
                    day_tc_array: [
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png'
                    ],
                    day_en_array: [
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png'
                    ],
                    day_align: hmUI.align.CENTER_H,
                    day_zero: 0,
                    day_follow: 0,
                    day_space: 4,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 284,
                    y: 95,
                    week_en: [
                        '120.png',
                        '121.png',
                        '122.png',
                        '123.png',
                        '124.png',
                        '125.png',
                        '126.png'
                    ],
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 50,
                    y: 375,
                    w: 150,
                    h: 50,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 20,
                    y: 295,
                    w: 234,
                    h: 50,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 20,
                    y: 225,
                    w: 166,
                    h: 55,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 195,
                    y: 155,
                    w: 165,
                    h: 60,
                    type: hmUI.data_type.SPO2,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 20,
                    y: 155,
                    w: 160,
                    h: 60,
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 253,
                    y: 295,
                    w: 112,
                    h: 50,
                    type: hmUI.data_type.ALTIMETER,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}