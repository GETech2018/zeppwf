try {
    (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;

        var __$$module$$__ = __$$app$$__.current;
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        /*
    * huamiOS bundle tool v1.0.17
    * Copyright © Huami. All Rights Reserved
    */
        'use strict';

        console.log("----->>>current")
        console.log(__$$hmAppManager$$__.currentApp.pid)
        console.log(__$$hmAppManager$$__.currentApp.current)
        const WIDGET_LEFT_ID = 101;
        const WIDGET_TOP_ID = 102;
        const WIDGET_BOTTOM_ID = 103;
        const WIDGET_BG_ID = 105;
        const WIDGET_TOP = 1;
        const WIDGET_LEFT = 2;
        const WIDGET_BOTTOM = 3;
        const WIDGET_EDIT_SIZE = 122;
        const WIDGET_TIPS_WIDTH = 104;
        const ROOTPATH = "images/";
        const WIDGET_BG_PATH = ROOTPATH + "widget/bg/";
        const INNER_PROGRESS_PATH = ROOTPATH + "progress_inner_img/";
        // const WIDGET_ICON_PATH = ROOTPATH + "widget/icon/";
        const WIDGET_POINTER_PATH = ROOTPATH + "widget/point.png";
        const WIDGET_FONT_ARRAY = [
            ROOTPATH + "number_img/0.png",
            ROOTPATH + "number_img/1.png",
            ROOTPATH + "number_img/2.png",
            ROOTPATH + "number_img/3.png",
            ROOTPATH + "number_img/4.png",
            ROOTPATH + "number_img/5.png",
            ROOTPATH + "number_img/6.png",
            ROOTPATH + "number_img/7.png",
            ROOTPATH + "number_img/8.png",
            ROOTPATH + "number_img/9.png", 
        ]; 
        const pointPath = ROOTPATH + "pointer/";
        const widgetPreview = ROOTPATH + "widget_preview/"
        const TIPS_ROOT = ROOTPATH + "tips/"
        const WIDGET_TIPS_PATH = TIPS_ROOT + "widget_tips.png";
        const BGROOT = ROOTPATH + "bg_edit/"
        let select = null 
        let editBg = null
        let topWidget = null
        let leftWidget = null
        let bottomWidget = null
        let mask = null 
        let pointer;
        let week = null;
        let day = null;  
        const logger = DeviceRuntimeCore.HmLogger.getLogger("sanjiao");
        __$$module$$__.module = DeviceRuntimeCore.Page({
            parseWidgetConfig(editType) {
                let config = {
                    bgPath: null, //背景图
                    iconPath: null, //图标
                    dataType: null,//数据类型
                    nonePath: null,//无数据的图片
                    negativeImage:null,
                    unitEnPath: null,//单位
                    unitScPath: null,
                    unitTcPath: null,
                    spPath: null,
                    pointerType:null,
                    startAngle: 225, //指针开始角度
                    endAngle: 495, //指针结束角度
                    progressType: null,
                    angleType: null
                };
             
                switch (editType) {
                    
                    case hmUI.edit_type.HUMIDITY: //
                        config.bgPath = "rh.png"; 
                        config.dataType = hmUI.data_type.HUMIDITY;
                        config.spPath = ROOTPATH + "widget/font1/number_p.png";
                        config.nonePath = ROOTPATH + "widget/font1/none.png";
                        config.angleType = ROOTPATH + "widget/font1/none.png";
                        config.unitEnPath = ROOTPATH + "widget/font1/u.png";
                        config.unitScPath = ROOTPATH + "widget/font1/u.png";
                        config.unitTcPath = ROOTPATH + "widget/font1/u.png";
                        break; 
                    case hmUI.edit_type.ALTIMETER:
                        config.bgPath = "kpa.png";
                        config.angleType = ROOTPATH + "widget/font1/none.png";
                        config.dataType = hmUI.data_type.ALTIMETER; 
                        break;
                    case hmUI.edit_type.STEP:
                        config.bgPath = "step.png";
                        // config.iconPath = "step.png";
                        config.dataType = hmUI.data_type.STEP;
                        config.progressType = 'diststand'
                        break;
                    case hmUI.edit_type.CAL:
                    // 
                        config.bgPath = "kcal.png";
                        // config.iconPath = "kcal.png";
                        config.dataType = hmUI.data_type.CAL;
                        config.progressType = 'kcal'
                        break; 

                    // case hmUI.edit_type.FAT_BURN:
                    // // 
                    //     config.bgPath = "burn.png"; 
                    //     config.dataType = hmUI.data_type.FAT_BURNING;
                    //     config.nonePath = ROOTPATH + "widget/font1/none.png";  
                    //     config.unitEnPath = ROOTPATH + "number_img/m.png";
                    //     config.unitEnPath = ROOTPATH + "number_img/m.png";
                    //     config.unitEnPath = ROOTPATH + "number_img/m.png";
                    //     config.progressType = 'kcal'
                    //     break; 

                        
                    case hmUI.edit_type.DISTANCE:
                        config.bgPath = "dist.png";
                        // config.iconPath = "distance.png";
                        config.dataType = hmUI.data_type.DISTANCE;
                        config.spPath = ROOTPATH + "widget/font1/dian.png";
                        config.pointerType = hmUI.data_type.STEP;
                        config.nonePath = ROOTPATH + "widget/font1/none.png"; 
                        config.progressType = 'diststand'
                        break;
                    case hmUI.edit_type.HEART:
                        config.bgPath = "heart.png";
                        // config.iconPath = "heart.png";
                        config.dataType = hmUI.data_type.HEART;
                        config.pointerType = hmUI.data_type.HEART;
                        config.nonePath = ROOTPATH + "widget/font1/none.png"; 
                        break;
                    
                    case hmUI.edit_type.STAND: 
                        config.bgPath = "stand.png";
                        // config.iconPath = "stand.png";
                        config.dataType = hmUI.data_type.STAND;
                        config.spPath = ROOTPATH + "widget/font1/sp.png";
                        config.progressType = 'step'
                        break;
                    case hmUI.edit_type.SPO2:
                        config.bgPath = "spo2.png";
                        // config.iconPath = "spo2.png";
                        config.dataType = hmUI.data_type.SPO2;
                        config.unitEnPath = ROOTPATH + "widget/font1/u.png";
                        config.unitScPath = ROOTPATH + "widget/font1/u.png";
                        config.unitTcPath = ROOTPATH + "widget/font1/u.png";
                        config.nonePath = ROOTPATH + "widget/font1/none.png";
                        break;
                 
                    case hmUI.edit_type.SLEEP:
                        config.bgPath = "sleep.png"; 
                        config.dataType = hmUI.data_type.SLEEP;
                        config.spPath = ROOTPATH + "widget/font1/dian.png";
                        // config.unitEnPath = ROOTPATH + "widget/font1/h.png";
                        // config.unitScPath = ROOTPATH + "widget/font1/h.png";
                        // config.unitTcPath = ROOTPATH + "widget/font1/h.png";
                        config.nonePath = ROOTPATH + "widget/font1/none.png";
                        config.progressType = 'sleep'
                        break;
                  
                    case hmUI.edit_type.UVI:
                        config.bgPath = "uvi.png";
                        // config.iconPath = "uvi.png";
                        config.dataType = hmUI.data_type.UVI;
                        config.nonePath = ROOTPATH + "widget/font1/none.png";
                        break;
                    case hmUI.edit_type.WIND:
                        config.bgPath = "wind.png";
                        // config.iconPath = "wind.png";
                        config.dataType = hmUI.data_type.WIND;
                        config.nonePath = ROOTPATH + "widget/font1/none.png";
                        break; 
                  
                    default:
                        console.log("invalid editType type=" + editType);
                        return config;
                } 
                if (config.bgPath != null) {
                    config.bgPath = WIDGET_BG_PATH + config.bgPath;
                }

             
                if (config.pointerType == null) {
                    config.pointerType = config.dataType;
                }
                return config;
            },
            drawWidget(widgetType, editType) {  
                let bgX = 0;
                let bgY = 0;
                switch (widgetType) {
                    case WIDGET_TOP:
                        bgX = 40;
                        bgY = 166;
                        break;
                    case WIDGET_LEFT:
                        bgX = 136;
                        bgY = 258;
                        break;
                    case WIDGET_BOTTOM:
                        bgX = 232;
                        bgY = 166;
                        break;
                    default:
                        console.log("invalid widgetType type=" + widgetType);
                        return;
                }
                const bgSize = 118;
                const iconX = bgX + 51;
                const iconY = bgY + 17;
                const textX = bgX;
                const textY = bgY + 68;
                const textWidth = 118;
                const textHeight = 34;
                const iconSize = 32;
                 
                const config = this.parseWidgetConfig(editType);
                 console.log(config.dataType + 'XXXXXXXXS')
                if (config.dataType == null) {
                    console.log("invalid arg dataType is null");
                    return;
                }
                if (config.bgPath == null) {
                    console.log("invalid arg bgpath is null");
                    return;
                } 
                //widgetbg
          
                hmUI.createWidget(hmUI.widget.IMG,{
                    x:bgX,
                    y:bgY,
                    w:bgSize,
                    h:bgSize,
                    src:config.bgPath,
                    show_level:hmUI.show_level.ONLY_NORMAL
                });

                let kcal_progress_imgArr = [
                    INNER_PROGRESS_PATH + 'kcal/0.png',
                    INNER_PROGRESS_PATH + 'kcal/1.png',
                    INNER_PROGRESS_PATH + 'kcal/2.png',
                    INNER_PROGRESS_PATH + 'kcal/3.png',
                    INNER_PROGRESS_PATH + 'kcal/4.png',
                    INNER_PROGRESS_PATH + 'kcal/5.png',
                    INNER_PROGRESS_PATH + 'kcal/6.png',
                    INNER_PROGRESS_PATH + 'kcal/7.png',
                    INNER_PROGRESS_PATH + 'kcal/8.png',
                    INNER_PROGRESS_PATH + 'kcal/9.png',
                    INNER_PROGRESS_PATH + 'kcal/10.png',
                    INNER_PROGRESS_PATH + 'kcal/11.png', 
                ]
                 let sleep_progress_imgArr = [
                    INNER_PROGRESS_PATH + 'sleep/0.png',
                    INNER_PROGRESS_PATH + 'sleep/1.png',
                    INNER_PROGRESS_PATH + 'sleep/2.png',
                    INNER_PROGRESS_PATH + 'sleep/3.png',
                    INNER_PROGRESS_PATH + 'sleep/4.png',
                    INNER_PROGRESS_PATH + 'sleep/5.png',
                    INNER_PROGRESS_PATH + 'sleep/6.png',
                    INNER_PROGRESS_PATH + 'sleep/7.png',
                    INNER_PROGRESS_PATH + 'sleep/8.png',
                    INNER_PROGRESS_PATH + 'sleep/9.png',
                    INNER_PROGRESS_PATH + 'sleep/10.png',
                    INNER_PROGRESS_PATH + 'sleep/11.png', 
                ]
                 let step_progress_imgArr = [
                    INNER_PROGRESS_PATH + 'step/0.png',
                    INNER_PROGRESS_PATH + 'step/1.png',
                    INNER_PROGRESS_PATH + 'step/2.png',
                    INNER_PROGRESS_PATH + 'step/3.png',
                    INNER_PROGRESS_PATH + 'step/4.png',
                    INNER_PROGRESS_PATH + 'step/5.png',
                    INNER_PROGRESS_PATH + 'step/6.png',
                    INNER_PROGRESS_PATH + 'step/7.png',
                    INNER_PROGRESS_PATH + 'step/8.png',
                    INNER_PROGRESS_PATH + 'step/9.png',
                    INNER_PROGRESS_PATH + 'step/10.png',
                    INNER_PROGRESS_PATH + 'step/11.png', 
                ]
                 let diststand_progress_imgArr = [
                    INNER_PROGRESS_PATH + 'diststand/0.png',
                    INNER_PROGRESS_PATH + 'diststand/1.png',
                    INNER_PROGRESS_PATH + 'diststand/2.png',
                    INNER_PROGRESS_PATH + 'diststand/3.png',
                    INNER_PROGRESS_PATH + 'diststand/4.png',
                    INNER_PROGRESS_PATH + 'diststand/5.png',
                    INNER_PROGRESS_PATH + 'diststand/6.png',
                    INNER_PROGRESS_PATH + 'diststand/7.png',
                    INNER_PROGRESS_PATH + 'diststand/8.png',
                    INNER_PROGRESS_PATH + 'diststand/9.png',
                    INNER_PROGRESS_PATH + 'diststand/10.png',
                    INNER_PROGRESS_PATH + 'diststand/11.png', 
                ]
                
                console.log(config.dataType+'ppppp')
               
                if(config.progressType){
                    var inner_progress_imgs = null
                    console.log(config.dataType+'rrrrrrrrrrrrrr')
                     console.log(config.progressType+'progressTypeprogressType')
                    switch (config.progressType){ 
                        
                        case 'step':
                        inner_progress_imgs = step_progress_imgArr
                            break
                        case 'sleep':
                        inner_progress_imgs = sleep_progress_imgArr
                            break    
                        case 'kcal':
                        inner_progress_imgs = kcal_progress_imgArr
                            break
                        case 'diststand': 
                        inner_progress_imgs = diststand_progress_imgArr
                            break   
                    } 
                    console.log(config.dataType+'GQF') 
                    let nowType = null
                    if(config.dataType ==  hmUI.data_type.DISTANCE ){
                        nowType = hmUI.data_type.STEP
                    } else {
                        nowType = config.dataType
                    }
                    hmUI.createWidget(hmUI.widget.IMG_LEVEL,{
                        x: bgX,
                        y: bgY,
                        image_array: inner_progress_imgs,
                        image_length: inner_progress_imgs.length,
                        type: nowType,
                        show_level:hmUI.show_level.ONLY_NORMAL
                    });  
                } else {
                   
                    hmUI.createWidget(hmUI.widget.IMG_POINTER,{
                        center_x:bgX + bgSize/2,
                        center_y:bgY + bgSize/2,
                        // x:6,
                        x:12,
                        y:58,
                        src:WIDGET_POINTER_PATH,
                        type:config.pointerType,
                        start_angle:config.startAngle,
                        end_angle:config.endAngle,
                        show_level:hmUI.show_level.ONLY_NORMAL
                    });
                }
                  
 
                let dataProp = {
                    x:textX,
                    y:textY,
                    w:textWidth,
                    h:textHeight,
                    align_h: hmUI.align.CENTER_H,
                    type:config.dataType,
                    h_space:1,
                    font_array:WIDGET_FONT_ARRAY,
                    show_level:hmUI.show_level.ONLY_NORMAL
                };
                if(config.unitEnPath != null){
                    dataProp.unit_en = config.unitEnPath;
                }
                if(config.unitScPath != null){
                    dataProp.unit_sc = config.unitScPath;
                }
                if(config.unitTcPath != null){
                    dataProp.unit_tc = config.unitTcPath;
                }
                if(config.nonePath != null){
                    dataProp.invalid_image = config.nonePath;
                }
                if(config.spPath != null){
                    dataProp.dot_image = config.spPath;
                }
                if(config.negativeImage != null){
                    dataProp.negative_image = config.negativeImage;
                }

                //数据
                hmUI.createWidget(hmUI.widget.TEXT_IMG,dataProp);
               
               // 指针
                // hmUI.createWidget(hmUI.widget.IMG_POINTER,{
                //     center_x:bgX + bgSize/2,
                //     center_y:bgY + bgSize/2,
                //     x:6,
                //     y:52,
                //     src:WIDGET_POINTER_PATH,
                //     type:config.pointerType,
                //     start_angle:config.startAngle,
                //     end_angle:config.endAngle,
                // });
            },
            init_out_Progress(){ //x
                let battery_imgArr = [
                    // ROOTPATH + "progress_img/power_0.png",
                    ROOTPATH + "progress_img/power_1.png",
                    ROOTPATH + "progress_img/power_2.png",
                    ROOTPATH + "progress_img/power_3.png",
                    // ROOTPATH + "progress_img/power_4.png",
                    ROOTPATH + "progress_img/power_5.png",
                    ROOTPATH + "progress_img/power_6.png",
                    ROOTPATH + "progress_img/power_7.png",
                    ROOTPATH + "progress_img/power_8.png",
                    ROOTPATH + "progress_img/power_9.png",
                    ROOTPATH + "progress_img/power_10.png",
                    ROOTPATH + "progress_img/power_11.png",
                    ROOTPATH + "progress_img/power_12.png",
                    ROOTPATH + "progress_img/power_13.png",
                ]
                let number_text_img = [
                    ROOTPATH + "number_img/0.png",
                    ROOTPATH + "number_img/1.png",
                    ROOTPATH + "number_img/2.png",
                    ROOTPATH + "number_img/3.png",
                    ROOTPATH + "number_img/4.png",
                    ROOTPATH + "number_img/5.png",
                    ROOTPATH + "number_img/6.png",
                    ROOTPATH + "number_img/7.png",
                    ROOTPATH + "number_img/8.png",
                    ROOTPATH + "number_img/9.png", 
                ]
                let pai_imgArr = [
                    // ROOTPATH + "progress_img/pai_0.png",
                    ROOTPATH + "progress_img/pai_1.png",
                    ROOTPATH + "progress_img/pai_2.png",
                    ROOTPATH + "progress_img/pai_3.png",
                    ROOTPATH + "progress_img/pai_4.png",
                    ROOTPATH + "progress_img/pai_5.png",
                    ROOTPATH + "progress_img/pai_6.png",
                    ROOTPATH + "progress_img/pai_7.png",
                    ROOTPATH + "progress_img/pai_8.png",
                    ROOTPATH + "progress_img/pai_9.png",
                    ROOTPATH + "progress_img/pai_10.png",
                    ROOTPATH + "progress_img/pai_11.png",
                    ROOTPATH + "progress_img/pai_12.png",
                    ROOTPATH + "progress_img/pai_13.png",
                ]
                let uvi_imgArr = [
                    // ROOTPATH + "progress_img/uvi_0.png",
                    ROOTPATH + "progress_img/uvi_1.png",
                    ROOTPATH + "progress_img/uvi_2.png",
                    ROOTPATH + "progress_img/uvi_3.png",
                    ROOTPATH + "progress_img/uvi_4.png",
                    ROOTPATH + "progress_img/uvi_5.png", 
                ]
                let weather_imgArr = [
                    // ROOTPATH + "progress_img/w_0.png",
                    ROOTPATH + "progress_img/w_1.png",
                    ROOTPATH + "progress_img/w_2.png",
                    ROOTPATH + "progress_img/w_3.png",
                    ROOTPATH + "progress_img/w_4.png",
                    ROOTPATH + "progress_img/w_5.png",
                    ROOTPATH + "progress_img/w_6.png",
                    ROOTPATH + "progress_img/w_7.png",
                    ROOTPATH + "progress_img/w_8.png",
                    ROOTPATH + "progress_img/w_9.png",
                    ROOTPATH + "progress_img/w_10.png",
                    ROOTPATH + "progress_img/w_11.png",
                    ROOTPATH + "progress_img/w_12.png",
                    ROOTPATH + "progress_img/w_13.png",
                ] 
 
                let weather_icon_img = [
                    ROOTPATH + "weather/0.png",
                    ROOTPATH + "weather/1.png",
                    ROOTPATH + "weather/2.png",
                    ROOTPATH + "weather/3.png",
                    ROOTPATH + "weather/4.png",
                    ROOTPATH + "weather/5.png",
                    ROOTPATH + "weather/6.png",
                    ROOTPATH + "weather/7.png",
                    ROOTPATH + "weather/8.png",
                    ROOTPATH + "weather/9.png",
                    ROOTPATH + "weather/10.png",
                    ROOTPATH + "weather/11.png",
                    ROOTPATH + "weather/12.png",
                    ROOTPATH + "weather/13.png", 
                    ROOTPATH + "weather/14.png", 
                    ROOTPATH + "weather/15.png",
                    ROOTPATH + "weather/16.png",
                    ROOTPATH + "weather/17.png",
                    ROOTPATH + "weather/18.png", 
                    ROOTPATH + "weather/19.png", 
                    ROOTPATH + "weather/20.png",
                    ROOTPATH + "weather/21.png",
                    ROOTPATH + "weather/22.png",
                    ROOTPATH + "weather/23.png", 
                    ROOTPATH + "weather/24.png", 
                    ROOTPATH + "weather/25.png",
                    ROOTPATH + "weather/26.png",
                    ROOTPATH + "weather/27.png", 
                    ROOTPATH + "weather/28.png", 
                ] 
                  hmUI.createWidget(hmUI.widget.IMG,{
                       x: 0,
                       y: 0,
                       w:195,//
                       h:225,
                       src: ROOTPATH + "progress_img/power_0.png",
                       show_level:hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                 }); 
                   hmUI.createWidget(hmUI.widget.IMG,{
                       x: 0,
                       y: 225,
                       w:195,
                       h:225,
                       src: ROOTPATH + "progress_img/w_0.png",
                       show_level:hmUI.show_level.ONLY_NORMAL
                 }); 
                hmUI.createWidget(hmUI.widget.IMG,{
                       x: 195,
                       y: 0,
                       w:195,//
                       h:225,
                       src:  ROOTPATH + "progress_img/uvi_0.png",
                       show_level:hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                 }); 
                 hmUI.createWidget(hmUI.widget.IMG,{
                       x: 195,
                       y: 225,
                       w:195,//
                       h:225,
                       src:ROOTPATH + "progress_img/pai_0.png",
                       show_level:hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                 }); 
                  
                 hmUI.createWidget(hmUI.widget.IMG_LEVEL,{
                        x: 0,
                        y: 0,
                        image_array: battery_imgArr,
                        image_length: battery_imgArr.length,
                        type: hmUI.data_type.BATTERY,
                        show_level:hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                 });
                  
                 hmUI.createWidget(hmUI.widget.IMG_LEVEL,{
                        x: 0,
                        y: 225,
                        image_array:  weather_imgArr,
                        image_length:  weather_imgArr.length,
                        type: hmUI.data_type.WEATHER,
                        show_level:hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                 });
                  
                 hmUI.createWidget(hmUI.widget.IMG_LEVEL,{
                        x: 195,
                        y: 0,
                        image_array:  uvi_imgArr,
                        image_length:  uvi_imgArr.length,
                        type: hmUI.data_type.UVI,
                        show_level:hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                 });
                  hmUI.createWidget(hmUI.widget.IMG_LEVEL,{
                        x: 195,
                        y: 225,
                        image_array: pai_imgArr,
                        image_length: pai_imgArr.length,
                        type: hmUI.data_type.PAI_WEEKLY,
                        show_level:hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                 }); 

                let BATTERY_TEXT  = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 26,
                    y: 21,
                   
                    type: hmUI.data_type.BATTERY,   // 获取心率数字，自动获取
                    font_array: number_text_img,   //心率数字图片
                    unit_type:1,
                    h_space: 0,  //数字之间的间隔
                    align_h: hmUI.align.CENTER_H,   //数字的对齐方式
                    padding:false, //是否补零 true为补零
                    isCharacter:true, //true为文字图片
                    unit_sc:  ROOTPATH + "number_img/number_p.png",//单位
                    unit_tc:  ROOTPATH + "number_img/number_p.png",//单位
                    unit_en:  ROOTPATH + "number_img/number_p.png",//单位
                    // show_level:hmUI.show_level.ALL
                    show_level:hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                    // show_level:hmUI.show_level.ONAL_NORMAL,   //心率是否在息屏
                });
              
                let UVI_TEXT  = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 320,
                    y: 21,                   
                    type: hmUI.data_type.UVI,    
                    font_array: number_text_img,   
                    unit_type:1,
                    h_space: 0,   
                    align_h: hmUI.align.CENTER_H,    
                    padding:false, //是否补零 true为补零
                    isCharacter:true, //true为文字图片 
                    invalid_image: ROOTPATH + "number_img/none.png",
                    // show_level:hmUI.show_level.ALL
                    show_level:hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                });
                let BATTERY_TEXT_AOD  = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 29,
                    y: 29,
                   
                    type: hmUI.data_type.BATTERY,   // 获取心率数字，自动获取
                    font_array: number_text_img,   //心率数字图片
                    unit_type:1,
                    h_space: 0,  //数字之间的间隔
                    align_h: hmUI.align.CENTER_H,   //数字的对齐方式
                    padding:false, //是否补零 true为补零
                    isCharacter:true, //true为文字图片
                    unit_sc:  ROOTPATH + "number_img/number_p.png",//单位
                    unit_tc:  ROOTPATH + "number_img/number_p.png",//单位
                    unit_en:  ROOTPATH + "number_img/number_p.png",//单位
                    show_level:hmUI.show_level.ONAL_AOD
                    // show_level:hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                    // show_level:hmUI.show_level.ONAL_NORMAL,   //心率是否在息屏
                });
                let UVI_TEXT_AOD  = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 320,
                    y: 29,                   
                    type: hmUI.data_type.UVI,    
                    font_array: number_text_img,   
                    unit_type:1,
                    h_space: 0,   
                    align_h: hmUI.align.CENTER_H,    
                    padding:false, //是否补零 true为补零
                    isCharacter:true, //true为文字图片 
                    invalid_image: ROOTPATH + "number_img/none.png",
                    show_level:hmUI.show_level.ONAL_AOD
                    // show_level:hmUI.show_level.ALL
                    // show_level:hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                });
                let WEATHER_TEXT = hmUI.createWidget(hmUI.widget.TEXT_IMG,{
                        x: 30,
                        y: 407, 
                        type: hmUI.data_type.WEATHER_CURRENT, 
                        font_array: number_text_img,   //心率数字图片
                        unit_type:1,
                        h_space: 0,  //数字之间的间隔
                        align_h: hmUI.align.CENTER_H,   //数字的对齐方式
                        padding:false, //是否补零 true为补零
                        isCharacter:true, //true为文字图片 
                        unit_sc:  ROOTPATH + "number_img/number_du.png",//单位
                        unit_tc:  ROOTPATH + "number_img/number_du.png",//单位
                        unit_en:  ROOTPATH + "number_img/number_du.png",//单位
                        negative_image: ROOTPATH + "number_img/fuhao.png", 
                        invalid_image: ROOTPATH + "number_img/none.png",
                        show_level:hmUI.show_level.ALL
                         
                 }); 
                let PAI_TEXT = hmUI.createWidget(hmUI.widget.TEXT_IMG,{
                        x: 312,
                        y: 407, 
                        type: hmUI.data_type.PAI_WEEKLY, 
                        font_array: number_text_img,   //心率数字图片
                        unit_type:1,
                        h_space: 0,  //数字之间的间隔
                        align_h: hmUI.align.CENTER_H,   //数字的对齐方式
                        padding:false, //是否补零 true为补零
                        isCharacter:true, //true为文字图片 
                         show_level:hmUI.show_level.ALL
                 }); 
                let step_TEXT = hmUI.createWidget(hmUI.widget.TEXT_IMG,{
                        x: 160,
                        y: 320, 
                        type: hmUI.data_type.STEP, 
                        font_array: number_text_img,   //心率数字图片
                        unit_type:1,
                        h_space: 0,  //数字之间的间隔
                        align_h: hmUI.align.CENTER_H,   //数字的对齐方式
                        padding:false, //是否补零 true为补零
                        isCharacter:true, //true为文字图片 
                        show_level:hmUI.show_level.ONAL_AOD,
                 }); 


                 let WEATHER_ICON = hmUI.createWidget(hmUI.widget.IMG_LEVEL,{
                        x: 30,
                        y: 374,
                        image_array: weather_icon_img,
                        image_length: weather_icon_img.length,
                        type: hmUI.data_type.WEATHER,
                        show_level:hmUI.show_level.ALL
                 }); 
               

            },
            init_view() { 
                let fontArray = [
                    ROOTPATH + "date/date_0.png",
                    ROOTPATH + "date/date_1.png",
                    ROOTPATH + "date/date_2.png",
                    ROOTPATH + "date/date_3.png",
                    ROOTPATH + "date/date_4.png",
                    ROOTPATH + "date/date_5.png",
                    ROOTPATH + "date/date_6.png",
                    ROOTPATH + "date/date_7.png",
                    ROOTPATH + "date/date_8.png",
                    ROOTPATH + "date/date_9.png",
                ];
                
                select = ROOTPATH + "select/"
                // hmUI.createWidget(hmUI.widget.FILL_RECT,{
                //     x:0,
                //     y:0,
                //     w:390,
                //     h:450,
                //     color:0xffffff,
                // });
                editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
                    edit_id: WIDGET_BG_ID,
                    x: 0,
                    y: 0,
                    bg_config: [
                        { id: 1, preview: BGROOT + "edit_bg1.png", path: BGROOT + "bg1.png" },
                        { id: 2, preview: BGROOT + "edit_bg2.png", path: BGROOT + "bg2.png" },
                        { id: 3, preview: BGROOT + "edit_bg3.png", path: BGROOT + "bg3.png" },
                        
                    ],
                    count: 3,
                    default_id: 1,
                    fg: BGROOT + "fg.png",
                    tips_x: 133,
                    tips_y: 400,
                    tips_bg: TIPS_ROOT + "bg_tips.png",
                });


                let widgetOptionalArray = [
                    { type: hmUI.edit_type.STEP, preview: widgetPreview + "step.png" },
                    { type: hmUI.edit_type.CAL, preview: widgetPreview + "kcal.png" }, 
                    { type: hmUI.edit_type.DISTANCE, preview: widgetPreview + "dist.png" }, 
                    { type: hmUI.edit_type.HEART, preview: widgetPreview + "heart.png" },  
                    { type: hmUI.edit_type.STAND, preview: widgetPreview + "stand.png" }, 
                    { type: hmUI.edit_type.SPO2, preview: widgetPreview + "spo2.png" }, 
                    { type: hmUI.edit_type.SLEEP, preview: widgetPreview + "sleep.png" },
                    { type: hmUI.edit_type.UVI, preview: widgetPreview + "uvi.png" },
                    { type: hmUI.edit_type.WIND, preview: widgetPreview + "ws.png" },  
                    { type: hmUI.edit_type.HUMIDITY, preview: widgetPreview + "rh.png" },  
                    { type: hmUI.edit_type.ALTIMETER, preview: widgetPreview + "kpa.png" }, 
                    // { type: hmUI.edit_type.FAT_BURN, preview: widgetPreview + "burn.png" },  
                ];
                let groupX = 40;
                let groupY = 165;
                //可编辑组件
                topWidget = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: WIDGET_TOP_ID,
                    x: groupX,
                    y: groupY,
                    w: WIDGET_EDIT_SIZE,
                    h: WIDGET_EDIT_SIZE,
                    select_image: select + "select.png",
                    un_select_image: select + "unselect.png",
                    default_type: hmUI.edit_type.CAL,
                    optional_types: widgetOptionalArray,
                    count: widgetOptionalArray.length,
                    tips_BG: WIDGET_TIPS_PATH,
                    tips_x: 10,
                    tips_y: -40,
                    tips_width: WIDGET_TIPS_WIDTH,
                });
                var editType = topWidget.getProperty(hmUI.prop.CURRENT_TYPE);
                this.drawWidget(WIDGET_TOP,editType);




                groupX = 136;
                groupY = 258;
                leftWidget = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: WIDGET_LEFT_ID,
                    x: groupX,
                    y: groupY,
                    w: WIDGET_EDIT_SIZE,
                    h: WIDGET_EDIT_SIZE,
                    select_image: select + "select.png",
                    un_select_image: select + "unselect.png",
                    default_type: hmUI.edit_type.SPO2,
                    optional_types: widgetOptionalArray,
                    count: widgetOptionalArray.length,
                    tips_BG: WIDGET_TIPS_PATH,
                    tips_x: 10,
                    tips_y: -40,
                    tips_width: WIDGET_TIPS_WIDTH,
                });
                editType = leftWidget.getProperty(hmUI.prop.CURRENT_TYPE);
                this.drawWidget(WIDGET_LEFT,editType);
                
                groupX = 229;
                groupY = 164;
                bottomWidget = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: WIDGET_BOTTOM_ID,
                    x: groupX,
                    y: groupY,
                    w: WIDGET_EDIT_SIZE,
                    h: WIDGET_EDIT_SIZE,
                    select_image: select + "select.png",
                    un_select_image: select + "unselect.png",
                    default_type: hmUI.edit_type.STAND,
                    optional_types: widgetOptionalArray,
                    count: widgetOptionalArray.length,
                    tips_BG: WIDGET_TIPS_PATH,
                    tips_x: 10,
                    tips_y: -40,
                    tips_width: WIDGET_TIPS_WIDTH,
                });
                editType = bottomWidget.getProperty(hmUI.prop.CURRENT_TYPE);
                this.drawWidget(WIDGET_BOTTOM,editType);



                
                let weekArray = [
                    ROOTPATH + "week/week_1.png",
                    ROOTPATH + "week/week_2.png",
                    ROOTPATH + "week/week_3.png",
                    ROOTPATH + "week/week_4.png",
                    ROOTPATH + "week/week_5.png",
                    ROOTPATH + "week/week_6.png",
                    ROOTPATH + "week/week_7.png",
                ];
                let weekCnArray = [
                    ROOTPATH + "week_cn/week_1.png",
                    ROOTPATH + "week_cn/week_2.png",
                    ROOTPATH + "week_cn/week_3.png",
                    ROOTPATH + "week_cn/week_4.png",
                    ROOTPATH + "week_cn/week_5.png",
                    ROOTPATH + "week_cn/week_6.png",
                    ROOTPATH + "week_cn/week_7.png",
                ];
                week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD | hmUI.show_level.ONLY_EDIT,
                    x: 165,
                    y: 140,
                    week_tc: weekCnArray,
                    week_sc: weekCnArray,
                    week_en: weekArray,
                });
                day = hmUI.createWidget(hmUI.widget.IMG_DATE, { 
                    day_startX: 172,
                    day_startY: 100,
                    day_zero: true,
                    day_en_array: fontArray,
                    show_level: hmUI.show_level.ALL,
                });
                
              
                const centerXValue = 195;
                const centerYValue = 225;
                const secondProp = {
                        centerX: centerXValue,
                        centerY: centerYValue,
                        posX: 6,
                        posY: 191,
                        path: pointPath + "s.png",
                };
                const pointerConfig = [
                    {
                        id: 1,
                        hour: {
                            centerX: centerXValue,
                            centerY: centerYValue,
                            posX: 18,
                            posY: 142,
                            path: pointPath + "h1.png",
                        },
                        minute: {
                            centerX: centerXValue,
                            centerY: centerYValue,
                            posX: 19,
                            posY: 200,
                            path: pointPath + "m1.png",
                        },
                        second:secondProp,
                        preview:  pointPath + "preview1.png",
                    },
                    {
                        id: 2,
                        hour: {
                            centerX: centerXValue,
                            centerY: centerYValue,
                            posX: 17,
                            posY: 119,
                            path: pointPath + "h2.png",
                        },
                        minute: {
                            centerX: centerXValue,
                            centerY: centerYValue,
                            posX: 13,
                            posY: 168,
                            path: pointPath + "m2.png",
                        },
                        preview: pointPath + "preview2.png",
                    },
                    {
                        id: 3,
                        hour: {
                            centerX: centerXValue,
                            centerY: centerYValue,
                            posX: 12,
                            posY: 117,
                            path: pointPath + "h3.png",
                        },
                        minute: {
                            centerX: centerXValue,
                            centerY: centerYValue,
                            posX: 13,
                            posY: 167,
                            path: pointPath + "m3.png",
                        }, 
                        preview: pointPath + "preview3.png",
                    }, 
                ];
                this.init_out_Progress() 
                let pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER,{
                    edit_id:120,
                    x: 0,
                    y: 0,
                    config:pointerConfig,
                    count: pointerConfig.length,
                    default_id: 1,
                    fg: BGROOT + "fg.png",
                    tips_x: 133,
                    tips_y: 413,
                    tips_bg: TIPS_ROOT + "bg_tips.png", 
                });
                const screenType = hmSetting.getScreenType();
                const aodModel = screenType == hmSetting.screen_type.AOD;
                if(aodModel){
                    var BATTERY = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 44,
                        y: 56,
                        // y: 50,
                        w: 25,
                        h: 26,
                        src:  ROOTPATH + "progress_img/bett.png",
                        show_level: hmUI.show_level.ONAL_AOD,
                    });
                    var UVI = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 319,
                        y: 55,
                        // y: 49,
                        w: 30,
                        h: 26,
                        src:  ROOTPATH + "progress_img/uvi.png",
                        show_level: hmUI.show_level.ONAL_AOD
                    });
               
                    var PAI = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 317,
                        y: 375,
                        w: 29,
                        h: 26,
                        src:  ROOTPATH + "progress_img/pai.png",
                        show_level: hmUI.show_level.ONAL_AOD,
                    }); 
                    var step = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 180,
                        y: 285,
                        w: 30,
                        h: 26,
                        src: ROOTPATH + "progress_img/step.png",
                        show_level: hmUI.show_level.ONAL_AOD,
                    });
                }
                const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG,!aodModel);
                pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp); 

                mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
                    x: 0,
                    y: 0,
                    w: 390,
                    h: 450,
                    src: ROOTPATH + "masks.png",
                    show_level: hmUI.show_level.ONLY_EDIT,
                });

            },

            onInit() {
                console.log('index page.js on init invoke')

                this.init_view();
            },

            onReady() {
                console.log('index page.js on ready invoke')
            },

            onShow() {
                console.log('index page.js on show invoke')
            },

            onHide() {
                console.log('index page.js on hide invoke')
            },

            onDestory() {
                console.log('index page.js on destory invoke')
            },
        });
        /*
        * end js
        */
    })()
} catch (e) {
    console.log(e)
}
