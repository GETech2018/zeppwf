try {
    (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;

        var __$$module$$__ = __$$app$$__.current;
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        /*
         * huamiOS bundle tool v1.0.17
         * Copyright © Huami. All Rights Reserved
         * 10020 多数据
         */
        'use strict';

        console.log("----->>>current")
        console.log(__$$hmAppManager$$__.currentApp.pid)
        console.log(__$$hmAppManager$$__.currentApp.current)

        let rootPath = null
        let heartLevel = null
        let batLevel = null
        let img_bg = null
        let timeText = null
        let timeArray = null
        let dataArray = null
        let sleepWidgetArray = new Array(3);
        let sleepArray = null
        let sleep = null
        let swsArr = new Array(4);
        let clockTimer = null
        let nullTip = null
        let isDraw = false
        let sleepCurrentStart = 0
        let sleepCurrentStop = 0
        let heartLine = null 
        let sleepRectArr = new Array(); 
        let sleepTxt1 = null
        let sleepTxt2 = null
        let sleepTxt3 = null
        let sleepTxt4 = null
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

            init_view() {
                rootPath = "images/"
                timeArray = [
                    rootPath + "time/00.png",
                    rootPath + "time/01.png",
                    rootPath + "time/02.png",
                    rootPath + "time/03.png",
                    rootPath + "time/04.png",
                    rootPath + "time/05.png",
                    rootPath + "time/06.png",
                    rootPath + "time/07.png",
                    rootPath + "time/08.png",
                    rootPath + "time/09.png",
                ]
                dataArray = [
                    rootPath + "data/00.png",
                    rootPath + "data/01.png",
                    rootPath + "data/02.png",
                    rootPath + "data/03.png",
                    rootPath + "data/04.png",
                    rootPath + "data/05.png",
                    rootPath + "data/06.png",
                    rootPath + "data/07.png",
                    rootPath + "data/08.png",
                    rootPath + "data/09.png",
                ]

                let fontArr = [
                    rootPath + '/font/0.png',
                    rootPath + '/font/1.png',
                    rootPath + '/font/2.png',
                    rootPath + '/font/3.png',
                    rootPath + '/font/4.png',
                    rootPath + '/font/5.png',
                    rootPath + '/font/6.png',
                    rootPath + '/font/7.png',
                    rootPath + '/font/8.png',
                    rootPath + '/font/9.png',
                ];

                heartLevel = [
                    rootPath + "heartLevel/01.png",
                    rootPath + "heartLevel/02.png",
                    rootPath + "heartLevel/03.png",
                    rootPath + "heartLevel/04.png",
                    rootPath + "heartLevel/05.png",
                    rootPath + "heartLevel/06.png",
                ]
                batLevel = [
                    rootPath + "batLevel/1.png",
                    rootPath + "batLevel/2.png",
                    rootPath + "batLevel/3.png",
                    rootPath + "batLevel/4.png",
                    rootPath + "batLevel/5.png",
                    rootPath + "batLevel/6.png",
                    rootPath + "batLevel/7.png",
                    rootPath + "batLevel/8.png",
                    rootPath + "batLevel/9.png",
                    rootPath + "batLevel/10.png",
                ]

                var screenType = hmSetting.getScreenType();
                if (screenType == hmSetting.screen_type.AOD) {
                    img_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
                        x: 0,
                        y: 0,
                        w: 390,
                        h: 450,
                        color: 0x000000,
                    });
                    showTime();
                } else {
                    img_bg = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 0,
                        y: 0,
                        w: 390,
                        h: 450,
                        src: rootPath + "img/bg.png",
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                    nullTip = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 121,
                        y: 202,
                        w: 121,
                        h: 28,
                        src: rootPath + "img/no_data.png",
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    // system
                    let clockStatus = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                        x: 76,
                        y: 406,
                        type: hmUI.system_status.CLOCK,
                        src: rootPath + "img/clock.png",
                    });
                    let disStatus = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                        x: 212,
                        y: 406,
                        type: hmUI.system_status.DISTURB,
                        src: rootPath + "img/dis.png",
                    });
                    let blueStatus = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                        x: 282,
                        y: 406,
                        type: hmUI.system_status.DISCONNECT,
                        src: rootPath + "img/blue.png",
                    });
                    showTime();
                    showSec();
                    let heart = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                        x: 130,
                        y: 10,
                        w: 130, //宽高可省略
                        h: 130,
                        image_array: heartLevel,
                        image_length: 6,
                        type: hmUI.data_type.HEART,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                    let bpmonIc = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 161,
                        y: 79,
                        w: 70,
                        h: 25,
                        src: rootPath + "img/bpm.png",
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                    let hearTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 162,
                        y: 40, //236
                        type: hmUI.data_type.HEART,
                        font_array: dataArray,
                        h_space: -2, //图片间隔
                        align_h: hmUI.align.CENTER_H,
                        invalid_image: rootPath + "img/invalid.png",
                        padding: false, //是否补零 true为补零
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                    let baterryLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                        x: 144,
                        y: 406,
                        w: 34, //宽高可省略
                        h: 34,
                        image_array: batLevel,
                        image_length: batLevel.length,
                        type: hmUI.data_type.BATTERY,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                    //睡眠得分
                    for (var i = 0; i < 3; i++) {
                        sleepWidgetArray[i] = hmUI.createWidget(hmUI.widget.IMG, {
                            x: 63 + i * 21,
                            y: 40,
                            w: 22,
                            h: 30,
                        });
                    }
                    //深睡时长
                    for (var i = 0; i < 4; i++) {
                        swsArr[i] = hmUI.createWidget(hmUI.widget.IMG);
                    }
                    //睡眠起始时间
                    sleepTxt1 = hmUI.createWidget(hmUI.widget.TEXT_IMG,{
                    });
                    sleepTxt2 = hmUI.createWidget(hmUI.widget.TEXT_IMG,{
                    })
                    sleepTxt3 = hmUI.createWidget(hmUI.widget.TEXT_IMG,{
                    });
                    sleepTxt4 = hmUI.createWidget(hmUI.widget.TEXT_IMG,{
                    }); 
                    //睡眠柱状图
                    for(var j=0;j<200;j++)
                    {
                        sleepRectArr[j]= hmUI.createWidget(hmUI.widget.FILL_RECT);
                        sleepRectArr[j].setProperty(hmUI.prop.VISIBLE,false);
                    }
                   // 睡眠心率
                   // heartLine = hmUI.createWidget(hmUI.widget.GRADKIENT_POLYLINE);
                    drawHeartLine();
                    sleep = hmSensor.createSensor(hmSensor.id.SLEEP);
                    getSleepScroe();
                    getSleepData();
                }

                function setImgPath(widget, path) {
                    widget.setProperty(hmUI.prop.SRC, path);
                    widget.setProperty(hmUI.prop.VISIBLE, true);
                }

                function showTime() {
                    timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                        hour_zero: 1,
                        hour_startX: 79,
                        hour_startY: 326,
                        hour_array: timeArray,
                        hour_space: 2,
                        hour_unit_sc: rootPath + "img/colon.png", //单位
                        hour_unit_tc: rootPath + "img/colon.png",
                        hour_unit_en: rootPath + "img/colon.png",
                        hour_align: hmUI.align.LEFT,

                        minute_zero: 1, //是否补零 1为补零
                        minute_startX: 195,
                        minute_startY: 326,
                        minute_array: timeArray,
                        minute_space: 2, //两个图片间隔 对应GT2的interval
                        minute_follow: 0, //是否跟随
                        minute_align: hmUI.align.LEFT,
                        am_x: 29,
                        am_y: 364,
                        am_sc_path: rootPath + "img/am.png",
                        am_en_path: rootPath + "img/am.png", //pm同上 前缀由am改为pm
                        pm_x: 29,
                        pm_y: 364,
                        pm_sc_path: rootPath + "img/pm.png",
                        pm_en_path: rootPath + "img/pm.png", //pm同上 前缀由am改为pm
                        show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD,
                    });

                }

                function showSec() {
                    let secText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                        second_zero: 1, //是否补零 1为补零
                        second_startX: 304,
                        second_startY: 361,
                        second_array: dataArray,
                        second_space: 0, //两个图片间隔 对应GT2的interval
                        second_follow: 0, //是否跟随
                        second_align: hmUI.align.LEFT,
                    });
                }


                function getSleepScroe() {
                    //sleep 睡眠得分 分数
                    const sleepScroe = sleep.getBasicInfo().score;
                    // sleepScroe =Math.floor( Math.random()*100);
                    let index = 0;
                    let v1 = parseInt(sleepScroe / 100);
                    let hasFirst = false;
                    //--------排列睡眠分数
                    if (v1 > 0 || hasFirst) {
                        hasFirst = true;
                        setImgPath(sleepWidgetArray[index++], dataArray[v1]);
                    }
                    v1 = parseInt(sleepScroe / 10 % 10);
                    if (v1 > 0 || hasFirst) {
                        hasFirst = true;
                        setImgPath(sleepWidgetArray[index++], dataArray[v1]);
                    }
                    setImgPath(sleepWidgetArray[index++], dataArray[parseInt(sleepScroe % 10)]);
                    for (var i = index; i < 3; i++) {
                        sleepWidgetArray[i].setProperty(hmUI.prop.VISIBLE, false);
                    }
                    // deepth min to hour 

                    const deepth = sleep.getBasicInfo().deepMin;
                    // deepth =Math.floor( Math.random()*150);
                    let swsHour = parseInt(deepth / 60);
                    let swsMin = Math.floor(((deepth % 60) / 60) * 10);
                    drawTextImg2(swsArr[0], 270, 40, 22, 30, dataArray[swsHour]);
                    drawTextImg2(swsArr[1], 295, 40, 22, 30, rootPath + "img/dot.png");
                    drawTextImg2(swsArr[2], 300, 40, 22, 30, dataArray[swsMin]);
                    drawTextImg2(swsArr[3], 325, 40, 22, 30, rootPath + "img/h.png");
                }

                function drawTextImg2(swsIcon, xpos, ypos, w, h, path) {
                    swsIcon.setProperty(hmUI.prop.MORE, {
                        x: xpos,
                        y: ypos,
                        w: w,
                        h: h,
                        src: path,
                    });
                }

                function Rect(fillrect,xpos, ypos, w, h, color) {
                    fillrect.setProperty(hmUI.prop.MORE, {
                        x: xpos,
                        y: ypos,
                        w: w,
                        h: h,
                        color: color,
                    });
                    fillrect.setProperty(hmUI.prop.VISIBLE, true);
                }
                function drawRect(xpos, ypos, w, h, color) 
                {
                    var fillrect= hmUI.createWidget(hmUI.widget.FILL_RECT, {
                        x: xpos,
                        y: ypos,
                        w: w,
                        h: h,
                        color: color,
                    });
                    sleepRectArr.push(fillrect);
                }

                function getSleepData() {
                    clockTimer = timer.createTimer(
                        100, 100, (function (option) {
                            drawSleepRect();
                        }), {})
                }

                function drawSleepRect() {
                    let sleepStageArray = sleep.getSleepStageData();
                   // console.log("sleep:0000000000000000000000------------------data.sleepCurrentStart:"+sleepStageArray[0].start);
                    if (sleepStageArray && sleepStageArray.length != 0) {
                        // 表盘显示柱状图的宽度 334
                        if(sleepCurrentStop==sleepStageArray[sleepStageArray.length-1].stop || sleepCurrentStart==sleepStageArray[sleepStageArray.length-1].start)
                        {
                            timer.stopTimer(clockTimer);
                            return;
                        } 
                        sleepCurrentStop =sleepStageArray[sleepStageArray.length-1].stop;
                        sleepCurrentStart=sleepStageArray[sleepStageArray.length-1].start;
                        var per = 334 / (sleepStageArray[(sleepStageArray.length - 1)].stop - sleepStageArray[0].start);
                        for (var i = 0; i < sleepStageArray.length; i++) {
                            const data = sleepStageArray[i];
                            // console.log("sleep:_______________________data.model:"+data.model);
                            // console.log("sleep:_______________________data.start:"+data.start);
                            // console.log("sleep:_______________________data.stop:"+data.stop);
                            var xpos = 20 + (data.start - sleepStageArray[0].start) * per; //柱状图 x 
                            var ypos = 270; //柱状图 y 
                            var w = (data.stop - data.start) * per;
                            var space = 8; //柱状图间隔
                            switch (data.model) {
                                case 4: // .LIGHT_STAGE 浅睡 blue
                                   Rect(sleepRectArr[i],xpos + space, ypos - 24, w, 24, 0x259FBE);
                                    // drawRect(xpos + space, ypos - 24, w, 24, 0x259FBE);
                                    break;
                                case 5: // DEEP_STAGE:5  深睡 purple
                                    Rect(sleepRectArr[i],xpos + space, ypos - 55, w, 55, 0x864BE1);
                                    // drawRect(xpos + space, ypos - 55, w, 55, 0x864BE1);
                                    break;
                                case 7: // WAKE_STAGE:7 清醒 yellow(red)
                                    Rect(sleepRectArr[i],xpos + space, ypos - 111, w, 111, 0xD05D20);
                                   // drawRect(xpos + space, ypos - 111, w, 111, 0xD05D20);
                                    break;
                                case 8: // .REM_STAGE REM green
                                    Rect(sleepRectArr[i],xpos + space, ypos - 83, w, 83, 0x0CB462);
                                    // drawRect(xpos + space, ypos - 83, w, 83, 0x0CB462);
                                    break;
                                default:
                            }
                        }
                       
                        for (var j = i; j < 200; j++) {
                            sleepRectArr[j].setProperty(hmUI.prop.VISIBLE, false);
                        }
                        nullTip.setProperty(hmUI.prop.VISIBLE, false);
                        isDraw = true;
                        timer.stopTimer(clockTimer);
                        //hmUI.deleteWidget(heartLine);
                        heartLine.setProperty(hmUI.prop.MORE, {
                            x: 30, // 心率折现起点 x
                            y: 154, // 心率折现起点 y
                            w: 334, // 心率框 w
                            h: 118, // 心率框 h
                            type: hmUI.data_type.SLEEP,
                            show_level: hmUI.show_level.ONLY_NORMAL,
                        }); 
                    }

                    
                    const sleeptime = sleep.getTotalTime()
                    const num = sleep.getBasicInfo()
                    const startTime = num.startTime
                    const endTime = num.endTime+1
                    
                    // const endTime =1501
                    if (startTime) {

                        // var startTime1 =JSON.stringify(num1[0].stop)

                        var startTime1 = JSON.stringify(startTime)

                       
                        var endTime1 = JSON.stringify(endTime)

                        var H1 = parseInt(endTime1 / 60)
                        var M1 = parseInt(endTime1 % 60)
                        // console.log("222222222222222endTime====" + endTime);

                        let SLEEP_REFERENCE_ZERO = 24 * 60

                        if (startTime1 >= SLEEP_REFERENCE_ZERO) {
                            H = parseInt((startTime1 - SLEEP_REFERENCE_ZERO) / 60)
                            M = parseInt((startTime1 - SLEEP_REFERENCE_ZERO) % 60)
                        } else {
                            H = parseInt(startTime1 / 60)
                            M = parseInt(startTime1 % 60)
                        }
                        if (endTime1 >= SLEEP_REFERENCE_ZERO) {
                            H1 = parseInt((endTime1 - SLEEP_REFERENCE_ZERO) / 60)
                            M1 = parseInt((endTime1 - SLEEP_REFERENCE_ZERO) % 60)
                        } else {
                            H1 = parseInt(endTime1 / 60)
                            M1 = parseInt(endTime1 % 60)
                        }
                        H = H >= 10 ? H : '0' + H
                        M = M >= 10 ? M : '0' + M
                        M1 = M1 >= 10 ? M1 : '0' + M1
                        H1 = H1 >= 10 ? H1 : '0' + H1
                        
                        // sleepTxt1.setProperty(hmUI.prop.TEXT, H);
                        // sleepTxt2.setProperty(hmUI.prop.TEXT, M);
                        // sleepTxt3.setProperty(hmUI.prop.TEXT, H1);
                        // sleepTxt4.setProperty(hmUI.prop.TEXT, M1);
                        sleepTxt1.setProperty(hmUI.prop.VISIBLE, true);
                        sleepTxt2.setProperty(hmUI.prop.VISIBLE, true);
                        sleepTxt3.setProperty(hmUI.prop.VISIBLE, true);
                        sleepTxt4.setProperty(hmUI.prop.VISIBLE, true);
                        sleepTxt1.setProperty(hmUI.prop.MORE, {
                            x: 6,
                            y: 283,
                            text: H,
                            font_array: fontArr,
                            h_space: 0,
                            align_h: hmUI.align.CENTER_H,
                            unit_sc: "images/font/maohao.png",
                            unit_tc: "images/font/maohao.png",
                            unit_en: "images/font/maohao.png",
                        });
                        sleepTxt2.setProperty(hmUI.prop.MORE, {
                            x: 36,
                            y: 283,
                            text: M,
                            font_array: fontArr,
                            h_space: 0,
                            align_h: hmUI.align.CENTER_H,
                        })
                        sleepTxt3.setProperty(hmUI.prop.MORE, {
                            x: 292,
                            y: 283,
                            text: H1,
                            font_array: fontArr,
                            h_space: 0,
                            align_h: hmUI.align.CENTER_H,
                            unit_sc: "images/font/maohao.png",
                            unit_tc: "images/font/maohao.png",
                            unit_en: "images/font/maohao.png",
                        });
                        sleepTxt4 .setProperty(hmUI.prop.MORE, {
                            x: 322,
                            y: 283,
                            text: M1,
                            font_array: fontArr,
                            h_space: 0,
                            align_h: hmUI.align.CENTER_H,
                        }); 
                    }else{
                        sleepTxt1.setProperty(hmUI.prop.VISIBLE, false);
                        sleepTxt2.setProperty(hmUI.prop.VISIBLE, false);
                        sleepTxt3.setProperty(hmUI.prop.VISIBLE, false);
                        sleepTxt4.setProperty(hmUI.prop.VISIBLE, false);
                    }
                }

                function drawHeartLine() {
                    // 睡眠心率折线图
                    heartLine = hmUI.createWidget(hmUI.widget.GRADKIENT_POLYLINE, {
                        x: 30, // 心率折现起点 x
                        y: 154, // 心率折现起点 y
                        w: 334, // 心率框 w
                        h: 118, // 心率框 h
                        type: hmUI.data_type.SLEEP,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    }); 
                }
                function clearnWidet()
                {
                    hmUI.deleteWidet(heartLine);
                    for(var i=0; i<sleepRectArr.length;i++)
                    {
                        hmUI.deleteWidet(sleepRectArr[i]);
                    }
                    sleepRectArr.length=0;
                }
                // 睡眠数据更新
                const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: (function () {
                        getSleepScroe();
                        drawSleepRect();
                    }),
                    pause_call: (function () {
                        // console.log('ui pause');

                    }),

                });
            },

            onInit() {
                console.log('index page.js on init invoke')

                this.init_view();

            },

            onReady() {
                console.log('index page.js on ready invoke')
            },

            onShow() {
                console.log('index page.js on show invoke')
            },

            onHide() {
                console.log('index page.js on hide invoke')
            },

            onDestory() {
                console.log('index page.js on destory invoke')
            },
        });
        /*
         * end js
         */
    })()
} catch (e) {
    console.log(e)
}