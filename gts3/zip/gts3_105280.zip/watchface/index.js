try {
  (() => {

    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

    /*
     * huamiOS bundle tool v1.0.17
     * Copyright © Huami. All Rights Reserved
     */
    'use strict';

    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let rootPath = null
    let heartPath = null
    let bgPath = null
    let dayPath = null
    let item_numPath = null
    let numPath = null
    let pointerPath = null
    let previewPath = null
    let powerPath = null
    let selectPath = null
    let tempPath = null
    let weatherPath = null
    let weekPath = null
    let xpPath = null
    let xp_bgPath = null
    let xp_numPath = null
    let xp_weekPath = null
    let xp_pointerPath = null

    let heart_array = null
    let day_array = null
    let item_num_array = null
    let num_array = null
    let pai_array = null
    let power_array = null
    let temp_array = null
    let weather_array = null
    let week_array = null
    let xp_num_array = null
    let xp_week_array = null
    const logger = DeviceRuntimeCore.HmLogger.getLogger("defult");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      drawHeartWidget(item) {
        let config = {
          bgX: 140,
          bgY: 224,
          numX: 177,
          numY: 256,
          bg_img: null,
          type: null,
          invalid: null,
          h: 0,
          dot: null,
          xp_dot: null
        }
        switch (item) {
          case hmUI.edit_type.HEART:
            config.bg_img = bgPath + "bpm_bg.png",
              config.type = hmUI.data_type.HEART,
              config.invalid = item_numPath + "null.png"
            break;
          case hmUI.edit_type.CAL:
            config.bg_img = bgPath + "kcal_bg.png",
              config.type = hmUI.data_type.CAL
            config.numX = config.numX - 6
            // config.invalid = numPath + "null.png"
            break;
          case hmUI.edit_type.ALTIMETER:
            config.bg_img = bgPath + "kpa_bg.png",
              config.type = hmUI.data_type.ALTIMETER
            config.numX = config.numX - 6
            config.invalid = item_numPath + "null.png"

            break;
          case hmUI.edit_type.HUMIDITY:
            config.bg_img = bgPath + "rh_bg.png",
              config.type = hmUI.data_type.HUMIDITY
            config.invalid = item_numPath + "null.png"

            break;
          case hmUI.edit_type.SPO2:
            config.bg_img = bgPath + "spo.png",
              config.type = hmUI.data_type.SPO2;
            config.invalid = item_numPath + "null.png"

            break;
          case hmUI.edit_type.STAND:
            config.bg_img = bgPath + "stand_bg.png",
              config.type = hmUI.data_type.STAND
            config.numX = config.numX - 6
            config.h = -2
            config.invalid = item_numPath + "null.png"
            config.dot = item_numPath + "xie.png"
            config.xp_dot = xp_numPath + "xie.png"

            break;
          case hmUI.edit_type.STEP:
            config.bg_img = bgPath + "step_bg.png",
              config.type = hmUI.data_type.STEP
            config.numX = config.numX - 12
            // config.invalid = numPath + "null.png"

            break;
          case hmUI.edit_type.UVI:
            config.bg_img = bgPath + "uvi_bg.png",
              config.type = hmUI.data_type.UVI
            config.numX = config.numX + 6
            config.invalid = item_numPath + "null.png"

            break;
          default:
            break;
        }
        let item_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: config.bgX,
          y: config.bgY,
          src: config.bg_img,
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD
        })


        let item_Text = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: config.numX,
          y: config.numY,
          type: config.type,
          font_array: item_num_array,
          h_space: config.h,
          align_h: hmUI.align.CENTER_H,
          invalid_image: config.invalid,
          // padding: true,
          dot_image: config.dot,
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD,
        });


        let AOD_item_Text = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: config.numX,
          y: config.numY,
          type: config.type,
          font_array: xp_num_array,
          h_space: config.h,
          align_h: hmUI.align.CENTER_H,
          invalid_image: xp_numPath + "null.png",
          // padding: true,
          dot_image: config.xp_dot,
          show_level: hmUI.show_level.ONAL_AOD,
        });

        let item_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
          src: pointerPath + "p.png",
          center_x: 195,
          center_y: 283,
          x: 7,
          y: 46,
          type: config.type,
          start_angle: 0,
          end_angle: 360,
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD,
        });




      },
      init_view() {
        rootPath = "images/";
        heartPath = rootPath + "heart/"
        bgPath = rootPath + "bg/"
        dayPath = rootPath + "day/"
        item_numPath = rootPath + "item_num/"
        numPath = rootPath + "num/"
        paiPath = rootPath + "pai/"
        pointerPath = rootPath + "pointer/"
        powerPath = rootPath + "power/"
        previewPath = rootPath + "preview/"
        selectPath = rootPath + "select/"
        tempPath = rootPath + "temp/"
        weatherPath = rootPath + "weather/"
        weekPath = rootPath + "week/"
        xpPath = rootPath + "xp/"
        xp_bgPath = xpPath + "bg/"
        xp_weekPath = xpPath + "week/"
        xp_pointerPath = xpPath + "pointer/"
        xp_numPath = xpPath + "number/"

        heart_array = [
          heartPath + "1.png",
          heartPath + "2.png",
          heartPath + "3.png",
          heartPath + "4.png",
          heartPath + "5.png",
          heartPath + "6.png",

        ]

        day_array = [
          dayPath + "0.png",
          dayPath + "1.png",
          dayPath + "2.png",
          dayPath + "3.png",
          dayPath + "4.png",
          dayPath + "5.png",
          dayPath + "6.png",
          dayPath + "7.png",
          dayPath + "8.png",
          dayPath + "9.png",
        ]

        item_num_array = [
          item_numPath + "0.png",
          item_numPath + "1.png",
          item_numPath + "2.png",
          item_numPath + "3.png",
          item_numPath + "4.png",
          item_numPath + "5.png",
          item_numPath + "6.png",
          item_numPath + "7.png",
          item_numPath + "8.png",
          item_numPath + "9.png",
        ]

        num_array = [
          numPath + "0.png",
          numPath + "1.png",
          numPath + "2.png",
          numPath + "3.png",
          numPath + "4.png",
          numPath + "5.png",
          numPath + "6.png",
          numPath + "7.png",
          numPath + "8.png",
          numPath + "9.png",
        ]

        pai_array = [
          // paiPath + "0.png",
          paiPath + "1.png",
          paiPath + "2.png",
          paiPath + "3.png",
          paiPath + "4.png",
          paiPath + "5.png",
          paiPath + "6.png",
          paiPath + "7.png",
          paiPath + "8.png",
          paiPath + "9.png",
          paiPath + "10.png",
        ]

        power_array = [
          // powerPath + "10.png",
          powerPath + "9.png",
          powerPath + "8.png",
          powerPath + "7.png",
          powerPath + "6.png",
          powerPath + "5.png",
          powerPath + "4.png",
          powerPath + "3.png",
          powerPath + "2.png",
          powerPath + "1.png",
          powerPath + "0.png",
        ]

        temp_array = [
          // tempPath + "0.png",
          tempPath + "1.png",
          tempPath + "2.png",
          tempPath + "3.png",
          tempPath + "4.png",
          tempPath + "5.png",
          tempPath + "6.png",
          tempPath + "7.png",
          tempPath + "8.png",
          tempPath + "9.png",
          tempPath + "10.png",
        ]

        weather_array = [
          weatherPath + "00.png",
          weatherPath + "01.png",
          weatherPath + "02.png",
          weatherPath + "03.png",
          weatherPath + "04.png",
          weatherPath + "05.png",
          weatherPath + "06.png",
          weatherPath + "07.png",
          weatherPath + "08.png",
          weatherPath + "09.png",
          weatherPath + "10.png",
          weatherPath + "11.png",
          weatherPath + "12.png",
          weatherPath + "13.png",
          weatherPath + "14.png",
          weatherPath + "15.png",
          weatherPath + "16.png",
          weatherPath + "17.png",
          weatherPath + "18.png",
          weatherPath + "19.png",
          weatherPath + "20.png",
          weatherPath + "21.png",
          weatherPath + "22.png",
          weatherPath + "23.png",
          weatherPath + "24.png",
          weatherPath + "25.png",
          weatherPath + "26.png",
          weatherPath + "27.png",
          weatherPath + "28.png",
        ]

        week_array = [
          weekPath + "1.png",
          weekPath + "2.png",
          weekPath + "3.png",
          weekPath + "4.png",
          weekPath + "5.png",
          weekPath + "6.png",
          weekPath + "7.png",
        ]
        xp_num_array = [
          xp_numPath + "0.png",
          xp_numPath + "1.png",
          xp_numPath + "2.png",
          xp_numPath + "3.png",
          xp_numPath + "4.png",
          xp_numPath + "5.png",
          xp_numPath + "6.png",
          xp_numPath + "7.png",
          xp_numPath + "8.png",
          xp_numPath + "9.png",
          xp_numPath + "10.png",
        ]

        xp_week_array = [
          xp_weekPath + "1.png",
          xp_weekPath + "2.png",
          xp_weekPath + "3.png",
          xp_weekPath + "4.png",
          xp_weekPath + "5.png",
          xp_weekPath + "6.png",
          xp_weekPath + "7.png",
        ]

        let bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 390,
          h: 450,
          src: bgPath + "bg.png",
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
        })

        let AOD_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 390,
          h: 450,
          src: xp_bgPath + "bg.png",
          show_level: hmUI.show_level.ONAL_AOD
        })

        let pai_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 195,
          y: 225,
          src: bgPath + "pai.png",
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD | hmUI.show_level.ONLY_EDIT
        })

        let heart_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 195,
          y: 0,
          src: bgPath + "heart.png",
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD | hmUI.show_level.ONLY_EDIT
        })

        let batteryLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 0,
          y: 0,
          image_array: power_array,
          image_length: power_array.length, //长度
          type: hmUI.data_type.BATTERY,
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD | hmUI.show_level.ONLY_EDIT
        });

        let heartLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 195,
          y: 0,
          image_array: heart_array,
          image_length: heart_array.length, //长度
          type: hmUI.data_type.HEART,
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD | hmUI.show_level.ONLY_EDIT
        });
        // 温度
        let tempLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 0,
          y: 225,
          image_array: temp_array,
          image_length: temp_array.length, //长度
          type: hmUI.data_type.WEATHER_CURRENT,
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD | hmUI.show_level.ONLY_EDIT
        });

        let paiLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 195,
          y: 225,
          image_array: pai_array,
          image_length: pai_array.length, //长度
          type: hmUI.data_type.PAI_DAILY,
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD | hmUI.show_level.ONLY_EDIT
        });

        let weatherLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 40,
          y: 373,
          image_array: weather_array,
          image_length: weather_array.length, //长度
          type: hmUI.data_type.WEATHER,
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD | hmUI.show_level.ONLY_EDIT
        });

        let batteryText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 27,
          y: 22,
          type: hmUI.data_type.BATTERY,
          font_array: num_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          unit_sc: numPath + "baifen.png",
          unit_tc: numPath + "baifen.png",
          unit_en: numPath + "baifen.png",
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD | hmUI.show_level.ONLY_EDIT,
        });

        let weatherText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 34,
          y: 409,
          type: hmUI.data_type.WEATHER_CURRENT,
          font_array: num_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          unit_sc: numPath + "du.png",
          unit_tc: numPath + "du.png",
          unit_en: numPath + "du.png",
          negative_image: numPath + "fu.png",
          invalid_image: numPath + "null.png",
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD | hmUI.show_level.ONLY_EDIT,
        });

        let heartText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 312,
          y: 22,
          type: hmUI.data_type.HEART,
          font_array: num_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          invalid_image: numPath + "null.png",
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD | hmUI.show_level.ONLY_EDIT,
        });

        let paiText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 312,
          y: 409,
          type: hmUI.data_type.PAI_DAILY,
          font_array: num_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          // invalid_image: numPath + "null.png",
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD | hmUI.show_level.ONLY_EDIT,
        });

        let dayText = hmUI.createWidget(hmUI.widget.IMG_DATE, {
          day_startX: 178,
          day_startY: 119,
          day_align: hmUI.align.LEFT,
          day_space: -0, //文字间隔
          day_zero: 1, //是否补零 
          day_en_array: day_array,
          day_sc_array: day_array,
          day_tc_array: day_array,
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD | hmUI.show_level.ONLY_EDIT,
        });

        let weekText = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
          x: 133,
          y: 154,
          week_en: week_array,
          week_tc: week_array,
          week_sc: week_array,
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
        });

        


        let optionwidget = [{
            type: hmUI.edit_type.HEART,
            preview: previewPath + "bpm.png"
          },
          {
            type: hmUI.edit_type.CAL,
            preview: previewPath + "kcal.png"
          },
          {
            type: hmUI.edit_type.ALTIMETER,
            preview: previewPath + "kpa.png"
          },
          {
            type: hmUI.edit_type.HUMIDITY,
            preview: previewPath + "rh.png"
          },
          {
            type: hmUI.edit_type.SPO2,
            preview: previewPath + "spo.png"
          },
          {
            type: hmUI.edit_type.STAND,
            preview: previewPath + "stand.png"
          },
          {
            type: hmUI.edit_type.STEP,
            preview: previewPath + "step.png"
          },
          {
            type: hmUI.edit_type.UVI,
            preview: previewPath + "uvi.png"
          },
        ]
        var groupX = 138;
        var groupY = 244;

        Group = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 101,
          x: groupX,
          y: groupY,
          w: 114,
          h: 114,
          select_image: selectPath + "select.png",
          un_select_image: selectPath + "unchecked.png",
          default_type: hmUI.edit_type.STEP,
          optional_types: optionwidget,
          count: optionwidget.length,
          tips_BG: selectPath + "tips.png",
          tips_x: 5,
          tips_y: 119,
          tips_width: 104,
        });

        var item = Group.getProperty(hmUI.prop.CURRENT_TYPE);
        this.drawHeartWidget(item)


        let timePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_centerX: 195, //指针旋转中心 对应centerX
          hour_centerY: 225, //指针旋转中心 对应centerY
          hour_posX: 15, //指针自身旋转中心 对应positioin中的x
          hour_posY: 122, //指针自身旋转中心 对应positioin中的y
          hour_path: pointerPath + "H.png",
          minute_centerX: 195, //指针旋转中心 对应centerX
          minute_centerY: 225, //指针旋转中心 对应centerY
          minute_posX: 15, //指针自身旋转中心 对应positioin中的x
          minute_posY: 182, //指针自身旋转中心 对应positioin中的y
          minute_path: pointerPath + "M.png",
          second_centerX: 195, //指针旋转中心 对应centerX
          second_centerY: 225, //指针旋转中心 对应centerY
          second_posX: 12, //指针自身旋转中心 对应positioin中的x
          second_posY: 184, //指针自身旋转中心 对应positioin中的y
          second_path: pointerPath + "S.png",
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
        });

        let AOD_timePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_centerX: 195, //指针旋转中心 对应centerX
          hour_centerY: 225, //指针旋转中心 对应centerY
          hour_posX: 15, //指针自身旋转中心 对应positioin中的x
          hour_posY: 122, //指针自身旋转中心 对应positioin中的y
          hour_path: xp_pointerPath + "H.png",
          minute_centerX: 195, //指针旋转中心 对应centerX
          minute_centerY: 225, //指针旋转中心 对应centerY
          minute_posX: 15, //指针自身旋转中心 对应positioin中的x
          minute_posY: 182, //指针自身旋转中心 对应positioin中的y
          minute_path: xp_pointerPath + "M.png",
          show_level: hmUI.show_level.ONAL_AOD
        });

        let AOD_weekText = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
          x: 133,
          y: 154,
          week_en: xp_week_array,
          week_tc: xp_week_array,
          week_sc: xp_week_array,
          show_level: hmUI.show_level.ONAL_AOD
        });

        // let maskCover = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK, {
        //   x: 0,
        //   y: 0,
        //   w: 390,
        //   h: 450,
        //   src: selectPath + "2.png",
        //   show_level: hmUI.show_level.ONLY_EDIT,
        // });


        //70%msk

        let mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
          x: 0,
          y: 0,
          w: 390,
          h: 450,
          src: selectPath + "1.png",
          show_level: hmUI.show_level.ONLY_EDIT,
        });
      },

      onInit() {
        console.log('index page.js on init invoke');

        this.init_view();


      },

      onReady() {
        console.log('index page.js on ready invoke')
      },

      onShow() {
        console.log('index page.js on show invoke')
      },

      onHide() {
        console.log('index page.js on hide invoke')
      },

      onDestory() {
        console.log('index page.js on destory invoke')
      },
    });
    /*
     * end js
     */
  })()
} catch (e) {
  console.log(e)
}