try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_3aa523d06b65444ba6f1c8f6abe5e88d = '';
        let dateFormat = '';
        let dateFormatMap = '';
        let normal$_$text_c9a56bb55bea4cccace2f1e55700eff2 = '';
        let normal$_$text_1bc1eabb235847128f9a07a9d2af5c33 = '';
        let idle$_$text_2544fb633c9441fa8144866ade4e8ff8 = '';
        let idle$_$text_46e9ea9f6adf46818a4802dcd863c967 = '';
        let idle$_$text_c52d552767b54eeebcfc8f978b7467a9 = '';
        let timeSensor = '';
        let batterySensor = '';
        const logger = Logger.getLogger('watchface6');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 390,
                    h: 450,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_3aa523d06b65444ba6f1c8f6abe5e88d = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 164,
                    y: 188,
                    w: 100,
                    h: 40,
                    text: '[DAY_Z]-[MON_Z]-[YEAR]',
                    color: '0xFFffffff',
                    text_size: 18,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_c9a56bb55bea4cccace2f1e55700eff2 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 110,
                    y: 150,
                    w: 100,
                    h: 40,
                    text: '[HOUR_24_Z]:[MIN_Z]:[SEC_Z]',
                    color: '0xFFffffff',
                    text_size: 18,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_1bc1eabb235847128f9a07a9d2af5c33 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 248,
                    y: 300,
                    w: 100,
                    h: 40,
                    text: '[BATT_PER]%',
                    color: '0xFFffffff',
                    text_size: 18,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 390,
                    h: 450,
                    src: '3.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                idle$_$text_2544fb633c9441fa8144866ade4e8ff8 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 248,
                    y: 300,
                    w: 100,
                    h: 40,
                    text: '[BATT_PER]%',
                    color: '0xFFffffff',
                    text_size: 18,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                idle$_$text_46e9ea9f6adf46818a4802dcd863c967 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 110,
                    y: 150,
                    w: 100,
                    h: 40,
                    text: '[HOUR_24_Z]:[MIN_Z]:[SEC_Z]',
                    color: '0xFFffffff',
                    text_size: 18,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                idle$_$text_c52d552767b54eeebcfc8f978b7467a9 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 164,
                    y: 188,
                    w: 100,
                    h: 40,
                    text: '[DAY_Z]-[MON_Z]-[YEAR]',
                    color: '0xFFffffff',
                    text_size: 17,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                if (!timeSensor) {
                    timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                }
                if (!batterySensor) {
                    batterySensor = hmSensor.createSensor(hmSensor.id.BATTERY);
                }
                timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_3aa523d06b65444ba6f1c8f6abe5e88d.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }-${ String(timeSensor.month).padStart(2, '0') }-${ String(timeSensor.day).padStart(2, '0') }` });
                        },
                        () => {
                            normal$_$text_3aa523d06b65444ba6f1c8f6abe5e88d.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }-${ String(timeSensor.month).padStart(2, '0') }-${ timeSensor.year }` });
                        },
                        () => {
                            normal$_$text_3aa523d06b65444ba6f1c8f6abe5e88d.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }-${ String(timeSensor.day).padStart(2, '0') }-${ timeSensor.year }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            idle$_$text_c52d552767b54eeebcfc8f978b7467a9.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }-${ String(timeSensor.month).padStart(2, '0') }-${ String(timeSensor.day).padStart(2, '0') }` });
                        },
                        () => {
                            idle$_$text_c52d552767b54eeebcfc8f978b7467a9.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }-${ String(timeSensor.month).padStart(2, '0') }-${ timeSensor.year }` });
                        },
                        () => {
                            idle$_$text_c52d552767b54eeebcfc8f978b7467a9.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }-${ String(timeSensor.day).padStart(2, '0') }-${ timeSensor.year }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                }), timeSensor.addEventListener(timeSensor.event.MINUTEEND, function () {
                    normal$_$text_c9a56bb55bea4cccace2f1e55700eff2.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }:${ String(timeSensor.minute).padStart(2, '0') }:${ String(timeSensor.second).padStart(2, '0') }` });
                    idle$_$text_46e9ea9f6adf46818a4802dcd863c967.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }:${ String(timeSensor.minute).padStart(2, '0') }:${ String(timeSensor.second).padStart(2, '0') }` });
                }), batterySensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_1bc1eabb235847128f9a07a9d2af5c33.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }%` });
                    idle$_$text_2544fb633c9441fa8144866ade4e8ff8.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }%` });
                });
                normal$_$text_c9a56bb55bea4cccace2f1e55700eff2.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }:${ String(timeSensor.minute).padStart(2, '0') }:${ String(timeSensor.second).padStart(2, '0') }` });
                idle$_$text_46e9ea9f6adf46818a4802dcd863c967.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }:${ String(timeSensor.minute).padStart(2, '0') }:${ String(timeSensor.second).padStart(2, '0') }` });
                timer.createTimer(0, 1000, function (timeSensor2) {
                    normal$_$text_c9a56bb55bea4cccace2f1e55700eff2.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor2.hour).padStart(2, '0') }:${ String(timeSensor2.minute).padStart(2, '0') }:${ String(timeSensor2.second).padStart(2, '0') }` });
                    idle$_$text_46e9ea9f6adf46818a4802dcd863c967.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor2.hour).padStart(2, '0') }:${ String(timeSensor2.minute).padStart(2, '0') }:${ String(timeSensor2.second).padStart(2, '0') }` });
                }, timeSensor);
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                normal$_$text_3aa523d06b65444ba6f1c8f6abe5e88d.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }-${ String(timeSensor.month).padStart(2, '0') }-${ String(timeSensor.day).padStart(2, '0') }` });
                            },
                            () => {
                                normal$_$text_3aa523d06b65444ba6f1c8f6abe5e88d.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }-${ String(timeSensor.month).padStart(2, '0') }-${ timeSensor.year }` });
                            },
                            () => {
                                normal$_$text_3aa523d06b65444ba6f1c8f6abe5e88d.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }-${ String(timeSensor.day).padStart(2, '0') }-${ timeSensor.year }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                        normal$_$text_c9a56bb55bea4cccace2f1e55700eff2.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }:${ String(timeSensor.minute).padStart(2, '0') }:${ String(timeSensor.second).padStart(2, '0') }` });
                        normal$_$text_1bc1eabb235847128f9a07a9d2af5c33.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }%` });
                        idle$_$text_2544fb633c9441fa8144866ade4e8ff8.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }%` });
                        idle$_$text_46e9ea9f6adf46818a4802dcd863c967.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }:${ String(timeSensor.minute).padStart(2, '0') }:${ String(timeSensor.second).padStart(2, '0') }` });
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                idle$_$text_c52d552767b54eeebcfc8f978b7467a9.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }-${ String(timeSensor.month).padStart(2, '0') }-${ String(timeSensor.day).padStart(2, '0') }` });
                            },
                            () => {
                                idle$_$text_c52d552767b54eeebcfc8f978b7467a9.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }-${ String(timeSensor.month).padStart(2, '0') }-${ timeSensor.year }` });
                            },
                            () => {
                                idle$_$text_c52d552767b54eeebcfc8f978b7467a9.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }-${ String(timeSensor.day).padStart(2, '0') }-${ timeSensor.year }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}