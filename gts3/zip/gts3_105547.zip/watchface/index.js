try {
    (() => {

    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

      /*
    * huamiOS bundle tool v1.0.17
    * Copyright © Huami. All Rights Reserved
    */
    'use strict';

    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    const ROOTPATH = "images/"
    let weekScArray = []
    let weekEnArray = []
    let weekTcArray = []
    let dateArray = []
    let timeArray = []


    const logger = DeviceRuntimeCore.HmLogger.getLogger("defult");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({

        init_view() {

            for(let i=0;i<10;i++)
            {
                if(i<8 && i>0)
                {
                    weekEnArray.push(ROOTPATH +  "week_en/"+i+".png");
                    weekScArray.push(ROOTPATH +  "week_cn/"+i+".png");
                    weekTcArray.push(ROOTPATH +  "week_tc/"+i+".png");
                }
                dateArray.push(ROOTPATH +  "date/date_"+i+".png");
                timeArray.push(ROOTPATH +  "time/time_"+i+".png");
            }
            var screenType = hmSetting.getScreenType();
            var aodModel = screenType == hmSetting.screen_type.AOD;
            if(aodModel){
               let bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
                    x: 0,
                    y: 0,
                    w: 390,
                    h: 450,
                    color: 0x000000,
                });
            }else {
               let bg = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 390,
                    h: 450,
                    src: ROOTPATH+"img/bg.png",
                    show_level:hmUI.show_level.ONLY_NOMAL,
                });
            }
           let week = hmUI.createWidget(hmUI.widget.IMG_WEEK,{
                x: 297,
                y: 210,
                week_tc:weekTcArray,
                week_sc:weekScArray,
                week_en:weekEnArray,
                //show_level:hmUI.show_level.ALL,
            });
            let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                hour_zero: 1,
                hour_startX: 114,
                hour_startY: 90,
                hour_array: timeArray,
                hour_space: 0,

                hour_align: hmUI.align.LEFT,

                minute_zero: 1, //是否补零 1为补零
                minute_startX: 202,
                minute_startY: 90,
                minute_array: timeArray,
                minute_space: 0, //两个图片间隔 对应GT2的interval
                minute_follow: 0, //是否跟随
                minute_align: hmUI.align.LEFT,


                am_x: 50,
                am_y: 210,
                am_sc_path:  ROOTPATH+"img/am_cn.png",
                am_en_path:  ROOTPATH+"img/am_en.png",

                pm_x: 50,
                pm_y: 210,
                pm_sc_path:  ROOTPATH+"img/pm_cn.png",
                pm_en_path:  ROOTPATH+"img/pm_en.png",
            });
            let colonImg = hmUI.createWidget(hmUI.widget.IMG, {
                x: 190,
                y: 98,
                w: 11,
                h: 28,
                src: ROOTPATH + "img/colon.png",
                show_level:hmUI.show_level.ONLY_AOD,
            });
          let  dateImg = hmUI.createWidget(hmUI.widget.IMG_DATE,{
                month_startX:160,
                month_startY:140,

                month_align: hmUI.align.LEFT,
                month_space: -2,
                month_zero: 1,
                month_follow: 0,
                month_is_character: false,

                month_en_array: dateArray,
                month_sc_array: dateArray,
                month_tc_array: dateArray,
                month_unit_sc: ROOTPATH+"img/line.png",
                month_unit_tc: ROOTPATH+"img/line.png",
                month_unit_en: ROOTPATH+"img/line.png",

                // day_startX: 200,
                // day_startY: 140 ,
                day_align: hmUI.align.LEFT,
                day_space: -2,
                day_zero: 1,
                day_follow: 1,
                day_en_array: dateArray,
                day_sc_array: dateArray,
                day_tc_array: dateArray,
            });
            // let dateLineImg = hmUI.createWidget(hmUI.widget.IMG, {
            //     x: 187,
            //     y: 138,
            //     w: 16,
            //     h: 17,
            //     src: ROOTPATH+"img/line.png",
            //     show_level:hmUI.show_level.ONLY_AOD,
            // });








        },

        onInit() {
            console.log('index page.js on init invoke');

            this.init_view();


        },

        onReady() {
            console.log('index page.js on ready invoke')
        },

        onShow() {
            console.log('index page.js on show invoke')
        },

        onHide() {
            console.log('index page.js on hide invoke')
        },

        onDestory() {
            console.log('index page.js on destory invoke')
        },
    });
    /*
    * end js
    */
        })()
    } catch (e) {
        console.log(e+"");
    }