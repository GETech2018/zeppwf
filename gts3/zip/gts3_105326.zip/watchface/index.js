try {
    (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;

        var __$$module$$__ = __$$app$$__.current;
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        /*
    * huamiOS bundle tool v1.0.17
    * Copyright © Huami. All Rights Reserved
    * 天气 271F
    */
        'use strict';

        console.log("----->>>current")
        console.log(__$$hmAppManager$$__.currentApp.pid)
        console.log(__$$hmAppManager$$__.currentApp.current)

        let rootPath = null
        let weekArray = null
        let heartArr = null
        let dateWhiteArr = null
        let dateGreyArr = null
        let timeArray = null
        let monthArray = null
        let paiArr = null

        let img_bg = null
        let timeText = null
        let timeSensor = null;
        let todyText = null


        let bgImg = null
        let dateObjectArr = []
        let createCount = 0;
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

            init_view() {
                rootPath = "images/"
                weekArray = [
                    rootPath + "week/1.png",
                    rootPath + "week/2.png",
                    rootPath + "week/3.png",
                    rootPath + "week/4.png",
                    rootPath + "week/5.png",
                    rootPath + "week/6.png",
                    rootPath + "week/7.png",
                ]
                heartArr = [
                    rootPath + "hearRate/0.png",
                    rootPath + "hearRate/1.png",
                    rootPath + "hearRate/2.png",
                    rootPath + "hearRate/3.png",
                    rootPath + "hearRate/4.png",
                    rootPath + "hearRate/5.png",
                    rootPath + "hearRate/6.png",
                    rootPath + "hearRate/7.png",
                    rootPath + "hearRate/8.png",
                    rootPath + "hearRate/9.png",
                ]
                paiArr = [
                    rootPath + "paiData/0.png",
                    rootPath + "paiData/1.png",
                    rootPath + "paiData/2.png",
                    rootPath + "paiData/3.png",
                    rootPath + "paiData/4.png",
                    rootPath + "paiData/5.png",
                    rootPath + "paiData/6.png",
                    rootPath + "paiData/7.png",
                    rootPath + "paiData/8.png",
                    rootPath + "paiData/9.png",
                ]
                dateWhiteArr = [
                    rootPath + "dateWhite/0.png",
                    rootPath + "dateWhite/1.png",
                    rootPath + "dateWhite/2.png",
                    rootPath + "dateWhite/3.png",
                    rootPath + "dateWhite/4.png",
                    rootPath + "dateWhite/5.png",
                    rootPath + "dateWhite/6.png",
                    rootPath + "dateWhite/7.png",
                    rootPath + "dateWhite/8.png",
                    rootPath + "dateWhite/9.png",
                ]
                dateGreyArr = [
                    rootPath + "dateGrey/0.png",
                    rootPath + "dateGrey/1.png",
                    rootPath + "dateGrey/2.png",
                    rootPath + "dateGrey/3.png",
                    rootPath + "dateGrey/4.png",
                    rootPath + "dateGrey/5.png",
                    rootPath + "dateGrey/6.png",
                    rootPath + "dateGrey/7.png",
                    rootPath + "dateGrey/8.png",
                    rootPath + "dateGrey/9.png",
                ]
                timeArray = [
                    rootPath + "time/0.png",
                    rootPath + "time/1.png",
                    rootPath + "time/2.png",
                    rootPath + "time/3.png",
                    rootPath + "time/4.png",
                    rootPath + "time/5.png",
                    rootPath + "time/6.png",
                    rootPath + "time/7.png",
                    rootPath + "time/8.png",
                    rootPath + "time/9.png",
                ]
                monthArray = [
                    rootPath + "month/1.png",
                    rootPath + "month/2.png",
                    rootPath + "month/3.png",
                    rootPath + "month/4.png",
                    rootPath + "month/5.png",
                    rootPath + "month/6.png",
                    rootPath + "month/7.png",
                    rootPath + "month/8.png",
                    rootPath + "month/9.png",
                    rootPath + "month/10.png",
                    rootPath + "month/11.png",
                    rootPath + "month/12.png",
                ]
                // 息屏状态
                var screenType = hmSetting.getScreenType();
                if (screenType == hmSetting.screen_type.AOD) {
                    img_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
                        x: 0,
                        y: 0,
                        w: 390,
                        h: 450,
                        color: 0x000000,
                    });
                } else {
                    // 亮屏状态
                    img_bg = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 0,
                        y: 0,
                        w: 390,
                        h: 450,
                        src: rootPath + "img/bg.png",
                        show_level: hmUI.show_level.ONAL_NORMAL,
                    });
                    // 把当前日期背景层级提高到日历数字生成的最上级 跟随数字一起渲染 (避免遮盖)
                    bgImg = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 0,  //日期图片的 x 位置
                        y: 0,
                        align_h: hmUI.align.CENTER_H,
                        show_level: hmUI.show_level.ONAL_NORMAL,
                    });

                    //  心率
                    creatImg(26, 14, rootPath + "img/heart.png", 28, 40); //
                    creatImg(26, 62, rootPath + "img/pai.png", 48, 30); //
                    let heartTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 62,
                        y: 14,
                        type: hmUI.data_type.HEART,   // 获取心率数字，自动获取
                        font_array: heartArr,   //心率数字图片
                        h_space: 0,  //数字之间的间隔
                        align_h: hmUI.align.LEFT,   //数字的对齐方式
                        padding: false, //是否补零 true为补零
                        isCharacter: true, //true为文字图片
                        show_level: hmUI.show_level.ONAL_NORMAL,   //心率是否在息屏
                        invalid_image: rootPath + "img/invalid.png",
                    });
                    let paiTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 26,
                        y: 98,
                        type: hmUI.data_type.PAI_WEEKLY,
                        font_array: paiArr,
                        h_space: 0,
                        align_h: hmUI.align.LEFT,
                        padding: false,
                        isCharacter: true,
                        show_level: hmUI.show_level.ONAL_NORMAL,
                    });
                    timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                    timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
                        daychange()
                    });
                    daychange()
                    function daychange() {
                        console.log("date change" + timeSensor.day);
                        todyText = timeSensor.day
                        let ypos = 201; // 日历第一层数字距离顶部的距离
                        let monthDaysNum = getMonthDayNum(); // 获取当前月 有多少天。用于循环生成 日历
                        let startNum = 0; // 用于计量距离 每月1日 距离左侧的 间隔数
                        let baseX = 0 // 用于计量距离 每月1日距离左侧的x距离
                        startNum = (7 - (timeSensor.day - (timeSensor.week + 1)) % 7) % 7;
                        // startNum = (7 - (5 - (4 + 1))%7)%7;
                        baseX = startNum * 54
                        var i = 0;
                        var textWord = 0; //声明放到外面 放到里面声明会频繁的申请释放内存
                        var isWhiteColor = true; //声明放到外面 放到里面声明会频繁的申请释放内存
                        var mid = 0; //同上
                        for (; i < monthDaysNum; i++) {
                            isWhiteColor = true;
                            textWord = i + 1;
                            startNum = startNum + 1
                            if (startNum % 7 == 0 || startNum % 7 == 1) {
                                isWhiteColor = false
                            }
                            if (startNum > 7 && (startNum) % 7 == 1 && (i + startNum) > 7) {
                                baseX = 0  // 换行
                                ypos += 37 // 换行
                                startNum = 1

                            }
                            mid = 0
                            if (ypos > 205) {
                                mid = (startNum - 1) % 7
                            } else {
                                mid = i % 7
                            }
                            if (textWord == todyText) {
                                renderBgImg(baseX + mid * 54 + 16 + 1, ypos - 7, rootPath + "img/datebg.png", 36, 36); //
                            }
                            renderDateImg(baseX + (mid * 54) + 18 + 2, ypos, 32, 22, textWord, isWhiteColor, i, monthDaysNum); //创建日期数字， 十位数创\
                        }
                        //把不需要显示的widget全部隐藏
                        for (; i < dateObjectArr.length; i++) {
                            dateObjectArr[i].setProperty(hmUI.prop.VISIBLE, false);
                        }
                    }

                    const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                        resume_call: (function () {
                            daychange()
                        }),
                        pause_call: (function () {
                            console.log('ui pause');
                        }),
                    });

                }
                //当前时间
                timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 108,
                    hour_startY: 54,
                    hour_array: timeArray,
                    hour_space: 8, //两个图片间隔
                    hour_unit_sc: rootPath + "img/colon.png", //单位
                    hour_unit_tc: rootPath + "img/colon.png",
                    hour_unit_en: rootPath + "img/colon.png",
                    hour_align: hmUI.align.LEFT,

                    minute_zero: 1, //是否补零 1为补零
                    minute_startX: 258,
                    minute_startY: 54,
                    minute_array: timeArray,
                    minute_space: 8, //两个图片间隔
                    minute_follow: 0, //是否跟随
                    minute_align: hmUI.align.LEFT,

                    am_x: 150,
                    am_y: 14,
                    am_sc_path: rootPath + "img/am.png",
                    am_en_path: rootPath + "img/am.png",
                    pm_x: 150,
                    pm_y: 14,
                    pm_sc_path: rootPath + "img/pm.png",
                    pm_en_path: rootPath + "img/pm.png",
                    show_level: hmUI.show_level.ALL,

                });
                // 年 月 显示
                let monthTxt1 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    year_startX: 287,
                    year_startY: 14,
                    year_align: hmUI.align.LEFT,
                    year_space: 1,
                    year_zero: 1,
                    year_follow: 1,
                    year_en_array: heartArr,
                    year_sc_array: heartArr,
                    year_tc_array: heartArr,
                    year_is_character: true,

                    month_startX: 210,
                    month_startY: 14,
                    month_align: hmUI.align.LEFT,
                    month_space: 1,
                    month_zero: 1,
                    month_follow: 1,
                    month_en_array: monthArray,
                    month_sc_array: monthArray,
                    month_tc_array: monthArray,
                    month_is_character: true,
                    show_level: hmUI.show_level.ALL,
                })

                var dateObject = null
                function renderDateImg(x, y, w, h, text, isWhiteColor, i, monthDaysNum) {
                    var textColorArr = isWhiteColor ? dateWhiteArr : dateGreyArr
                    if (dateObjectArr.length > i) {
                        dateObjectArr[i].setProperty(hmUI.prop.MORE, { //
                            x: x,
                            y: y,
                            w: w,  //日期图片的宽度
                            h: h,  //日期图片的高度
                            font_array: textColorArr,
                            h_space: 1,
                            align_h: hmUI.align.CENTER_H,
                            text: text,
                        });
                        //显示widget
                        dateObjectArr[i].setProperty(hmUI.prop.VISIBLE, true);
                    } else {
                        createCount++;
                        dateObject = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                            x: x,
                            y: y,
                            w: w,  //日期图片的宽度
                            h: h,  //日期图片的高度
                            font_array: textColorArr,
                            h_space: 1,
                            align_h: hmUI.align.CENTER_H,
                            text: text,
                        })
                        dateObjectArr.push(dateObject);
                    }
                    textColorArr = null
                }
                function renderBgImg(x, y, path, w, h) {
                    bgImg.setProperty(hmUI.prop.MORE, {
                        x: x,  //日期图片的 x 位置
                        y: y,
                        w: w,  //日期图片的宽度
                        h: h,  //日期图片的高度
                        align_h: hmUI.align.CENTER_H,
                        src: path,
                        show_level: hmUI.show_level.ONAL_NORMAL,
                    });

                }
                function creatImg(x, y, path, w, h) {
                    var dateImg = hmUI.createWidget(hmUI.widget.IMG, {
                        x: x,  //日期图片的 x 位置
                        y: y,
                        w: w,  //日期图片的宽度
                        h: h,  //日期图片的高度
                        align_h: hmUI.align.CENTER_H,
                        src: path,
                        show_level: hmUI.show_level.ONAL_NORMAL,
                    });
                    return dateImg
                }
                function getMonthDayNum() {
                    var date = new Date();
                    var year = date.getFullYear();
                    var month = date.getMonth() + 1;
                    var d = new Date(year, month, 0);
                    return d.getDate();
                }
            },


            onInit() {
                console.log('index page.js on init invoke')
                this.init_view();

            },

            onReady() {
                console.log('index page.js on ready invoke')
            },

            onShow() {
                console.log('index page.js on show invoke')
            },

            onHide() {
                console.log('index page.js on hide invoke')
            },

            onDestory() {
                console.log('index page.js on destory invoke')
            },
        });
        /*
        * end js
        */
    })()
} catch (e) {
    console.log(e)
}
