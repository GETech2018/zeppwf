/*
 ** huamiOS bundle tool v1.0.17
 * *huamiOS watchface js version v1.0.1
 * *Copyright © Huami. All Rights Reserved
 */

try {

  (() => {

    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
    var __$$module$$__ = __$$app$$__.current;
    //drink is a name,can modify
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

    'use strict';
    let bg = null;
    let calLevle = null;
    let batLevel = null;
    let calIcon = null;
    let batIcon = null;
    let calorie = null

    let timePointer = null;
    let rootPath = "images/";
    let fontArray = [
      rootPath + "data/0.png",
      rootPath + "data/1.png",
      rootPath + "data/2.png",
      rootPath + "data/3.png",
      rootPath + "data/4.png",
      rootPath + "data/5.png",
      rootPath + "data/6.png",
      rootPath + "data/7.png",
      rootPath + "data/8.png",
      rootPath + "data/9.png",
    ];
    let weekArr_en = [
      rootPath + "week/en/1.png",
      rootPath + "week/en/2.png",
      rootPath + "week/en/3.png",
      rootPath + "week/en/4.png",
      rootPath + "week/en/5.png",
      rootPath + "week/en/6.png",
      rootPath + "week/en/7.png",
    ];
    let weekArr_sc = [
      rootPath + "week/sc/1.png",
      rootPath + "week/sc/2.png",
      rootPath + "week/sc/3.png",
      rootPath + "week/sc/4.png",
      rootPath + "week/sc/5.png",
      rootPath + "week/sc/6.png",
      rootPath + "week/sc/7.png",
    ];
    let weekArr_tc = [
      rootPath + "week/tc/1.png",
      rootPath + "week/tc/2.png",
      rootPath + "week/tc/3.png",
      rootPath + "week/tc/4.png",
      rootPath + "week/tc/5.png",
      rootPath + "week/tc/6.png",
      rootPath + "week/tc/7.png",
    ];
    let progressArr = [
      rootPath + "progress/1.png",
      rootPath + "progress/2.png",
      rootPath + "progress/3.png",
      rootPath + "progress/4.png",
      rootPath + "progress/5.png",
      rootPath + "progress/6.png",
      rootPath + "progress/7.png",
      rootPath + "progress/8.png",
      rootPath + "progress/9.png",
      rootPath + "progress/10.png",
    ];

    const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      getCal() {
        calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
        if (calorie.current == 0) {
          cai_bg.setProperty(hmUI.prop.VISIBLE, true)
        } else {
          cai_bg.setProperty(hmUI.prop.VISIBLE, false)
        }
      },

      init_view() {

        var screenType = hmSetting.getScreenType();
        var nomalModel = screenType == hmSetting.screen_type.APP || screenType == hmSetting.screen_type.WATCHFACE;
        var aodModel = screenType == hmSetting.screen_type.AOD;
        if (nomalModel) {
          bg = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
            x: 0,
            y: 0,
            w: 390,
            h: 450,
            align_h: hmUI.align.CENTER_H,
            align_v: hmUI.align.CENTER_V,
            anim_path: rootPath + "animate_gradual",
            anim_prefix: "gradual",
            anim_ext: "png",
            anim_fps: 12,
            anim_size: 80,
            anim_repeat: true,
            repeat_count: 0,
            anim_status: 1,
          });
          // hmUI.createWidget(hmUI.widget.FILL_RECT,{
          //   x:0,
          //   y:0,
          //   w:390,
          //   h:450,
          //   color:0xffffff,
          // });


          weekLevel = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
            x: 29,
            y: 389,
            week_sc: weekArr_sc,
            week_tc: weekArr_tc,
            week_en: weekArr_en,
            show_level: hmUI.show_level.ONAL_NORMAL,
          });

          day_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
            day_startX: 29,
            day_startY: 355,
            day_en_array: fontArray,
            day_space: 0,
            day_zero: 1,
            show_level: hmUI.show_level.ONAL_NORMAL,
          });

          calorie = hmSensor.createSensor(hmSensor.id.CALORIE);

          cai_bg = hmUI.createWidget(hmUI.widget.IMG, {
            x: 25, //日期图片的 x 位置
            y: 23,
            w: 76, //日期图片的宽度
            h: 76, //日期图片的高度
            src: rootPath + "progress/0.png",
          });

          hmUI.createWidget(hmUI.widget.IMG, {
            x: 25, //日期图片的 x 位置
            y: 23,
            w: 76, //日期图片的宽度
            h: 76, //日期图片的高度
            src: rootPath + "progress/10.png",
          });

          var clockTimer = timer.createTimer(
              0, 10000, (() => {
                this.getCal()
              })),


            calLevle = hmUI.createWidget(hmUI.widget.IMG_LEVEL);
          batLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL);
          calIcon = hmUI.createWidget(hmUI.widget.IMG);
          batIcon = hmUI.createWidget(hmUI.widget.IMG);
          showNomalTime();
          showIcon();

        } else if (aodModel) {

          // } else {      
          bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
            x: 0,
            y: 0,
            w: 390,
            h: 450,
            color: 0x000000,
          });
          showAodTime();
        }

        function showNomalTime() {
          timePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
            hour_centerX: 195,
            hour_centerY: 225,
            hour_posX: 20,
            hour_posY: 202,
            hour_path: rootPath + "img/hour.png",

            minute_centerX: 195,
            minute_centerY: 225,
            minute_posX: 20,
            minute_posY: 202,
            minute_path: rootPath + "img/min.png",
            second_centerX: 195,
            second_centerY: 225,
            second_posX: 20,
            second_posY: 202,
            second_path: rootPath + "img/sec.png",
            show_level: hmUI.show_level.ONAL_NORMAL,
          });
        }

        function showAodTime() {
          timePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
            hour_centerX: 195,
            hour_centerY: 225,
            hour_posX: 20,
            hour_posY: 202,
            hour_path: rootPath + "img/hour_xp.png",

            minute_centerX: 195,
            minute_centerY: 225,
            minute_posX: 20,
            minute_posY: 202,
            minute_path: rootPath + "img/min_xp.png",
            show_level: hmUI.show_level.AOD,
          });
        }

        function showIcon() {
          let txt = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
            x: 301,
            y: 390,
            type: hmUI.data_type.HEART, // 获取心率数字，自动获取
            font_array: fontArray, //心率数字图片
            h_space: 0, //数字之间的间隔
            align_h: hmUI.align.CENTER_H, //数字的对齐方式
            padding: true, //是否补零 true为补零
            isCharacter: true, //true为文字图片
            invalid_image: rootPath + "img/invalid.png", // 无数据时显示的图片
            show_level: hmUI.show_level.ONAL_NORMAL, //心率是否在息屏
          });
          var img = hmUI.createWidget(hmUI.widget.IMG, {
            x: 313, //日期图片的 x 位置
            y: 357,
            w: 36, //日期图片的宽度
            h: 36, //日期图片的高度
            src: rootPath + "img/heart.png",
            show_level: hmUI.show_level.ONAL_NORMAL,
          });

          batIcon.setProperty(hmUI.prop.MORE, {
            x: 310,
            y: 44,
            w: 36,
            h: 36,
            src: rootPath + "img/battery.png",
          });
          calIcon.setProperty(hmUI.prop.MORE, {
            x: 45,
            y: 44,
            w: 36,
            h: 36,
            src: rootPath + "img/calIcon.png",
          });

          calLevle.setProperty(hmUI.prop.MORE, {
            x: 25,
            y: 22,
            w: 76,
            h: 76,
            image_array: progressArr,
            image_length: 10,
            type: hmUI.data_type.CAL,
          });
          batLevel.setProperty(hmUI.prop.MORE, {
            x: 290,
            y: 22,
            w: 76, //宽高可省略
            h: 76,
            image_array: progressArr,
            image_length: 10,
            type: hmUI.data_type.BATTERY,
          });
        }
        const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: (()=> {
           this.getCal()
          }),
          pause_call: (function () {
            timer.stopTimer(clockTimer)
          }),

        });

      },

      onInit() {
        console.log('index page.js on init invoke')

        this.init_view()

      },

      onReady() {
        console.log('index page.js on ready invoke')
      },

      onShow() {
        console.log('index page.js on show invoke')
      },

      onHide() {
        console.log('index page.js on hide invoke')
      },

      onDestory() {
        console.log('index page.js on destory invoke')
      },
    });

  })()
} catch (e) {
  console.log(e)
}