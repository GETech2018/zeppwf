try {
    (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;

        var __$$module$$__ = __$$app$$__.current;
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        /*
    * huamiOS bundle tool v1.0.17
    * Copyright © Huami. All Rights Reserved
    */
        'use strict';

        console.log("----->>>current")
        console.log(__$$hmAppManager$$__.currentApp.pid)
        console.log(__$$hmAppManager$$__.currentApp.current)

        const ROOTPATH = "images/";

        const batteryPath = ROOTPATH + "battery/"
        const batteryszPath = ROOTPATH + "batterysz/"


        const clhourPath = ROOTPATH + "clhour/"

        const stepPath = ROOTPATH + "step/"
        const xphourPath = ROOTPATH + "xphour/"


        const battery_array = [
            batteryPath + "0.png",
            batteryPath + "1.png",
            batteryPath + "2.png",
            batteryPath + "3.png",
            batteryPath + "4.png",
            batteryPath + "5.png",
            batteryPath + "6.png",
            batteryPath + "7.png",
            batteryPath + "8.png",
            batteryPath + "9.png",


        ]
        const batterysz_array = [
            batteryszPath + "0.png",
            batteryszPath + "1.png",
            batteryszPath + "2.png",
            batteryszPath + "3.png",
            batteryszPath + "4.png",
            batteryszPath + "5.png",
            batteryszPath + "6.png",
            batteryszPath + "7.png",
            batteryszPath + "8.png",
            batteryszPath + "9.png",


        ]
       
        const clhour_array = [
            clhourPath + "0.png",
            clhourPath + "1.png",
            clhourPath + "2.png",
            clhourPath + "3.png",
            clhourPath + "4.png",
            clhourPath + "5.png",
            clhourPath + "6.png",
            clhourPath + "7.png",
            clhourPath + "8.png",
            clhourPath + "9.png",
        ]

        const step_array = [
            stepPath + "0.png",
            stepPath + "1.png",
            stepPath + "2.png",
            stepPath + "3.png",
            stepPath + "4.png",
            stepPath + "5.png",
            stepPath + "6.png",
            stepPath + "7.png",
            stepPath + "8.png",
            stepPath + "9.png",
        ]

        const xphour_array = [
            xphourPath + "0.png",
            xphourPath + "1.png",
            xphourPath + "2.png",
            xphourPath + "3.png",
            xphourPath + "4.png",
            xphourPath + "5.png",
            xphourPath + "6.png",
            xphourPath + "7.png",
            xphourPath + "8.png",
            xphourPath + "9.png",
        ]
       


        let animResident = null
        let animCreate = null
        const logger = DeviceRuntimeCore.HmLogger.getLogger("sanjiao");
        __$$module$$__.module = DeviceRuntimeCore.Page({


            _animNext() {
                animResident.setProperty(hmUI.prop.ANIM_STATUS, 1);
                animCreate.setProperty(hmUI.prop.VISIBLE, false);

            },

            init_view() {

                let bg = hmUI.createWidget(hmUI.widget.IMG, { //beijing
                    x: 0,
                    y: 0,
                    w: 390,
                    h: 450,
                    src: ROOTPATH + "bg/bg.png",
                    show_level: hmUI.show_level.ONLY_NORMAL
                });


                let step = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 178,
                    y: 416,
                    type: hmUI.data_type.STEP,
                    font_array: step_array,
                    h_space: -2,
                    //图片间隔
                    align_h: hmUI.align.LEFT,
                    padding: false,
                    //是否补零 true为补零   
                    show_level: hmUI.show_level.ONLY_NORMAL


                });
                //===================================动画========================================

                var screenType = hmSetting.getScreenType();
                var nomalModel = screenType == hmSetting.screen_type.APP || screenType == hmSetting.screen_type.WATCHFACE;
                var aodModel = screenType == hmSetting.screen_type.AOD;
                if (nomalModel) {
                    
                    animResident = hmUI.createWidget(hmUI.widget.IMG_ANIM);
                    animResident.setProperty(hmUI.prop.MORE, {
                      
                        x:0,
                        y:0,
                        w: 390,
                        h: 450,
                        align_h: hmUI.align.CENTER_H, // 横轴  
                        align_v: hmUI.align.CENTER_V,// 竖轴
                        anim_path: ROOTPATH + "anims", //文件路径   文件夹的名称
                        anim_prefix: "Madrid", //相当于图片的前缀
                        anim_ext: "png", //图片的后缀以或者图片的格式
                        anim_fps: 15, //图片的播放速度
                        anim_size: 51,//图片的数量
                        anim_repeat: true, //开启循环播放

                        // repeat_count: 210,
                        repeat_count: 1,//0位无限重复
                        anim_status: 1, //  1  开启动画   0  //  关闭动画

                    });

                }


                //===========================================================================



                let batteryevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {  //获取电量图多张图片会选择其中一张
                    x: 134,
                    y: 18,
                    // w: 48,
                    // //宽高可省略
                    // h: 23,
                    image_array: battery_array,
                    image_length: battery_array.length,//长度
                    type:hmUI.data_type.BATTERY,
                    show_level:hmUI.show_level.ONLY_NORMAL
                });



                let battery = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 182,
                    y: 20,
                    type: hmUI.data_type.BATTERY,
                    font_array: batterysz_array,
                    h_space: 0,
                    //图片间隔
                    align_h: hmUI.align.LEFT,
                    unit_sc: "images/batterysz/unit.png",
                    // //单位
                    unit_tc: "images/batterysz/unit.png",
                    // //单位
                    unit_en: "images/batterysz/unit.png",

                    // invalid_image: "images/sky/number/none.png",
                    // // 无数据时显示的图片
                    padding: false,
                    //是否补零 true为补零                   
                    show_level: hmUI.show_level.ONLY_NORMAL
                });

                let time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1, //是否补零
                    hour_startX: 56,
                    hour_startY: 60,
                    hour_array: clhour_array,
                    hour_space: 0, //每个数组间的间隔
                    minute_zero: 1, //是否补零
                    minute_startX: 202,
                    minute_startY: 60,
                    minute_array: clhour_array,
                    minute_space: 0, //每个数组间的间隔
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                let maohao_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 176,
                    y: 60,
                    src: "images/clhour/maohao.png",
                    show_level: hmUI.show_level.ONLY_NORMAL
                })
                let AOD_timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1, //是否补零
                    hour_startX: 56,
                    hour_startY: 60,
                    hour_array: xphour_array,
                    hour_space: 0, //每个数组间的间隔
                    minute_zero: 1, //是否补零
                    minute_startX: 202,
                    minute_startY: 60,
                    minute_array: xphour_array,
                    minute_space: 0, //每个数组间的间隔
                    show_level: hmUI.show_level.ONAL_AOD
                });

                let AOD_maohao_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 176,
                    y: 60,
                    src: "images/xphour/maohao.png",
                    show_level: hmUI.show_level.ONAL_AOD
                })
            },

            onInit() {
                console.log('index page.js on init invoke')
                this.init_view();
            },

            onReady() {
                console.log('index page.js on ready invoke')
            },

            onShow() {
                console.log('index page.js on show invoke')
            },

            onHide() {
                console.log('index page.js on hide invoke')
            },

            onDestory() {
                console.log('index page.js on destory invoke')
            },
        });
        /*
        * end js
        */
    })()
} catch (e) {
    console.log(e)
}
