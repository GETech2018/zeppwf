try {
    (() => {
    
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
  
    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');
  
      /*
    * huamiOS bundle tool v1.0.17
    * Copyright © Huami. All Rights Reserved
    */
    'use strict';
  
    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    const ROOTPATH = "images/"

    let dateArray = []


    const logger = DeviceRuntimeCore.HmLogger.getLogger("defult");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
        
        init_view() {

            for(let i=0;i<10;i++)
            {
                dateArray.push(ROOTPATH +  "date/time_"+i+".png");
            }
            var screenType = hmSetting.getScreenType();
            var aodModel = screenType == hmSetting.screen_type.AOD;
            if(aodModel){
               let bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
                    x: 0,
                    y: 0,
                    w: 390,
                    h: 450,
                    color: 0x000000, 
                });
            }else {
               let bg = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 390,
                    h: 450,
                    src: ROOTPATH+"img/bg.png",
                    show_level:hmUI.show_level.ONLY_NOMAL,
                });
            }
          let  dateImg = hmUI.createWidget(hmUI.widget.IMG_DATE,{
                month_startX:131,
                month_startY:346,
    
                month_align: hmUI.align.LEFT,
                month_space: 1,
                month_zero: 1,
                month_follow: 0,
                month_is_character: false, 

                month_en_array: dateArray,
                month_sc_array: dateArray,
                month_tc_array: dateArray,
                month_unit_sc: ROOTPATH+"img/line.png",
                month_unit_tc: ROOTPATH+"img/line.png",
                month_unit_en: ROOTPATH+"img/line.png",

                // day_startX: 251,
                // day_startY: 364 ,
                day_align: hmUI.align.LEFT,
                day_space: 1,
                day_zero: 1,
                day_follow: 1,
                day_en_array: dateArray,
                day_sc_array: dateArray,
                day_tc_array: dateArray,
            });
            // let dateLineImg = hmUI.createWidget(hmUI.widget.IMG, {
            //     x: 228,
            //     y: 364,
            //     w: 27,
            //     h: 30,
            //     src: ROOTPATH+"img/line.png",
            //    // show_level:hmUI.show_level.ONLY_NOMAL,
            // });
           if(aodModel){
                let  timePointerAod = hmUI.createWidget(hmUI.widget.TIME_POINTER,{
                    hour_centerX: 195,
                    hour_centerY: 225,
                    hour_posX: 22,
                    hour_posY: 157,
                    hour_path: ROOTPATH + "img/hour.png",
                    minute_centerX: 195,
                    minute_centerY: 225,
                    minute_posX: 20,
                    minute_posY: 191,
                    minute_path: ROOTPATH + "img/minute.png",
             
                    //指针圆心图片
                    minute_cover_path: ROOTPATH + "img/cover.png",
                    minute_cover_x: 170,
                    minute_cover_y: 200,
                });
            }else {
                let  timePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER,{
                    hour_centerX: 195,
                    hour_centerY: 225,
                    hour_posX: 22,
                    hour_posY: 157,
                    hour_path: ROOTPATH + "img/hour.png",
                    minute_centerX: 195,
                    minute_centerY: 225,
                    minute_posX: 20,
                    minute_posY: 191,
                    minute_path: ROOTPATH + "img/minute.png",
            
                    second_centerX: 195,
                    second_centerY: 225,
                    second_posX: 13,
                    second_posY: 195,
                    second_path: ROOTPATH + "img/second.png", 

                    //指针圆心图片
                    second_cover_path: ROOTPATH + "img/cover.png",
                    second_cover_x: 170,
                    second_cover_y: 200,
                      
                });     
            }
        },

        onInit() {
            console.log('index page.js on init invoke');

            this.init_view();

            
        },

        onReady() {
            console.log('index page.js on ready invoke')
        },

        onShow() {
            console.log('index page.js on show invoke')
        },

        onHide() {
            console.log('index page.js on hide invoke')
        },

        onDestory() {
            console.log('index page.js on destory invoke')
        },
    });
    /*
    * end js
    */
        })()
    } catch (e) {
        console.log(e+"");
    }