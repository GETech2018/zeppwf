try {
    (() => {

    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        /*
    * huamiOS bundle tool v1.0.17
    * Copyright © Huami. All Rights Reserved
    * 天气 271F
    */
    'use strict';

    console.log("----->>>current")
    console.log(__$$hmAppManager$$__.currentApp.pid)
    console.log(__$$hmAppManager$$__.currentApp.current)
    
    let rootPath = null 
    let batProgressNorArray=[]
    let batProgressAodArray=[]
    let batNumNorArray=[]
    let batNumAodArray=[]
    let stepIcon=null
    let batProgress = null
    let stepTxt= null
    let batTxt=null
    let stepNumNorArray=[]
    let stepNumAodArray=[]
    let timeArray=[]
    let img_bg =null
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
        
        init_view(){ 
            rootPath = "images/"
            for(let i=0;i<10;i++)
            {
                batProgressNorArray.push(rootPath+"batProgress_nor/"+i+".png");
                batProgressAodArray.push(rootPath+"batProgress_aod/"+i+".png");
                batNumNorArray.push(rootPath+"batNum_nor/"+i+".png");
                batNumAodArray.push(rootPath+"batNum_aod/"+i+".png");
                stepNumNorArray.push(rootPath+"stepNum_nor/"+i+".png");
                stepNumAodArray.push(rootPath+"stepNum_aod/"+i+".png");
                timeArray.push(rootPath+"time/"+i+".png");

        
            }
           
           // 息屏状态
            var screenType = hmSetting.getScreenType();
            img_bg = hmUI.createWidget(hmUI.widget.IMG,{
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                // src: rootPath + "img/bg.png",
                 show_level: hmUI.show_level.ALL,
            });
            stepIcon = hmUI.createWidget(hmUI.widget.IMG,{
                x: 139,
                y: 389,
                w: 34,
                h: 34,
                // src: rootPath + "img/bg.png",
                 show_level: hmUI.show_level.ALL,
            });
           
            batProgress = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                x: 132,
                y: 38,
                w:44,
                h:24,
                image_array: batProgressNorArray,
                image_length: 10,
                type:hmUI.data_type.BATTERY,
            });
             stepTxt  = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                x: 179,
                y: 388,
                type: hmUI.data_type.STEP,   // 获取心率数字，自动获取
                font_array: stepNumNorArray,   
                h_space: 0,  //数字之间的间隔
                align_h: hmUI.align.LEFT,   //数字的对齐方式
                padding:false, //是否补零 true为补零
                isCharacter:true, //true为文字图片
               // show_level:hmUI.show_level.ONLY_NORML,   //心率是否在息屏
                
            });
            batTxt  = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                x: 184,
                y: 31,
                type: hmUI.data_type.BATTERY,   // 获取心率数字，自动获取
               // font_array: batNumNorArray,   
                h_space: 0,  //数字之间的间隔
                align_h: hmUI.align.LEFT,   //数字的对齐方式
                padding:false, //是否补零 true为补零
                isCharacter:true, //true为文字图片
                // unit_sc: rootPath + "batNum_nor/percent.png",
                // unit_tc: rootPath + "batNum_nor/percent.png",
                // unit_en: rootPath + "batNum_nor/percent.png",
               // show_level:hmUI.show_level.ONLY_NORML,   //心率是否在息屏
                
            }); 
            if(screenType == hmSetting.screen_type.AOD){ 
                img_bg.setProperty(hmUI.prop.SRC, rootPath + "img/bg_aod.png");
                stepIcon.setProperty(hmUI.prop.SRC, rootPath + "img/stepIcon_aod.png");
                stepTxt.setProperty(hmUI.prop.MORE, {
                    x: 179,
                    y: 388,
                    type: hmUI.data_type.STEP,   // 获取心率数字，自动获取
                    font_array: stepNumAodArray,   
                    h_space: 0,  
                    align_h: hmUI.align.LEFT,   
                    padding:false, 
                    isCharacter:true, 
                });
               
                batTxt.setProperty(hmUI.prop.MORE, {
                    x: 184,
                    y: 31,
                    type: hmUI.data_type.BATTERY,   // 获取心率数字，自动获取
                    font_array: batNumAodArray,   
                    h_space: 0,  //数字之间的间隔
                    align_h: hmUI.align.LEFT,   //数字的对齐方式
                    padding:false, //是否补零 true为补零
                    isCharacter:true, //true为文字图片
                    unit_sc: rootPath + "batNum_aod/percent.png",
                    unit_tc: rootPath + "batNum_aod/percent.png",
                    unit_en: rootPath + "batNum_aod/percent.png",
                }); 
                batProgress.setProperty(hmUI.prop.MORE, {
                    x: 132,
                    y: 38,
                    w:44,
                    h:24,
                    image_array: batProgressAodArray,
                    image_length: 10,
                    type:hmUI.data_type.BATTERY,
                });
                let  timeTextAod = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 20,
                    hour_startY: 108,
                    hour_array: timeArray,
                    hour_space: 0,
                    hour_align: hmUI.align.LEFT,
                    hour_unit_sc: rootPath+"img/colon.png", 
                    hour_unit_tc: rootPath+"img/colon.png",
                    hour_unit_en: rootPath+"img/colon.png",
                    minute_zero: 1, //是否补零 1为补零
                    minute_startX: 214,
                    minute_startY: 108,
                    minute_array: timeArray,
                    minute_space: 0, //两个图片间隔 对应GT2的interval
                    minute_follow: 0, //是否跟随
                    minute_align: hmUI.align.LEFT,
                    show_level: hmUI.show_level.ONLY_AOD,

    
                    am_x: 171,
                    am_y: 87,
                    am_sc_path: rootPath + "img/am_aod.png",
                    am_en_path: rootPath + "img/am_aod.png",
                    am_tc_path: rootPath + "img/am_aod.png",
    
                    pm_x: 171,
                    pm_y: 87,
                    pm_sc_path: rootPath + "img/pm_aod.png",
                    pm_en_path: rootPath + "img/pm_aod.png",
                    pm_tc_path: rootPath + "img/pm_aod.png",
                });       
            }else{ 

                // 亮屏状态
                img_bg.setProperty(hmUI.prop.SRC, rootPath + "img/bg.png");
                stepIcon.setProperty(hmUI.prop.SRC, rootPath + "img/stepIcon_nor.png");
                stepTxt .setProperty(hmUI.prop.MORE, {
                    x: 179,
                    y: 388,
                    type: hmUI.data_type.STEP,   // 获取心率数字，自动获取
                    font_array: stepNumNorArray,   
                    h_space: 0,  //数字之间的间隔
                    align_h: hmUI.align.LEFT,   //数字的对齐方式
                    padding:false, //是否补零 true为补零
                    isCharacter:true, //true为文字图片
                });
                batTxt.setProperty(hmUI.prop.MORE, {
                    x: 184,
                    y: 31,
                    type: hmUI.data_type.BATTERY,   // 获取心率数字，自动获取
                    font_array: batNumNorArray,   
                    h_space: 0,  //数字之间的间隔
                    align_h: hmUI.align.LEFT,   //数字的对齐方式
                    padding:false, //是否补零 true为补零
                    isCharacter:true, //true为文字图片
                    unit_sc: rootPath + "batNum_nor/percent.png",
                    unit_tc: rootPath + "batNum_nor/percent.png",
                    unit_en: rootPath + "batNum_nor/percent.png",
                }); 
                batProgress.setProperty(hmUI.prop.MORE, {
                    x: 132,
                    y: 38,
                    image_array: batProgressNorArray,
                    image_length: 10,
                    type:hmUI.data_type.BATTERY,
                });
            }
              let  timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 20,
                    hour_startY: 108,
                    hour_array: timeArray,
                    hour_space: 0,
                    hour_align: hmUI.align.LEFT,
                    hour_unit_sc: rootPath+"img/colon.png", 
                    hour_unit_tc: rootPath+"img/colon.png",
                    hour_unit_en: rootPath+"img/colon.png",
                    minute_zero: 1, //是否补零 1为补零
                    minute_startX: 214,
                    minute_startY: 108,
                    minute_array: timeArray,
                    minute_space: 0, //两个图片间隔 对应GT2的interval
                    minute_follow: 0, //是否跟随
                    minute_align: hmUI.align.LEFT,
                    show_level: hmUI.show_level.ONLY_NORMAL,

    
                    am_x: 171,
                    am_y: 87,
                    am_sc_path: rootPath + "img/am.png",
                    am_en_path: rootPath + "img/am.png",
                    am_tc_path: rootPath + "img/am.png",
    
                    pm_x: 171,
                    pm_y: 87,
                    pm_sc_path: rootPath + "img/pm.png",
                    pm_en_path: rootPath + "img/pm.png",
                    pm_tc_path: rootPath + "img/pm.png",
                });       
            
            
          
        
        },

        onInit() {
            console.log('index page.js on init invoke') 
            this.init_view();

        }, 
        
        onReady() {
            console.log('index page.js on ready invoke')
        },

        onShow() {
            console.log('index page.js on show invoke')
        },

        onHide() {
            console.log('index page.js on hide invoke')
        },

        onDestory() {
            console.log('index page.js on destory invoke')
        },
});
/*
* end js
*/
    })()
} catch (e) {
    console.log(e)
}
