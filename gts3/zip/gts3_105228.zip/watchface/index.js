try {
  (() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__),
      "drink"
    );

    /*
     * huamiOS bundle tool v1.0.17
     * Copyright © Huami. All Rights Reserved
     */
    ("use strict");

    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    const ROOTPATH = "images/";

    const batteryPath = ROOTPATH + "battery/";
    const dayPath = ROOTPATH + "Day/";

    const hourPath = ROOTPATH + "hour/";
    const xphourPath = ROOTPATH + "xphour/";

    const stepPath = ROOTPATH + "step/";
    const minutePath = ROOTPATH + "minute/";
    const weekPath = ROOTPATH + "week/";
    const weatherPath = ROOTPATH + "weather/";

    // const weather_array = [
    //     weatherPath + "0.png",
    //     weatherPath + "1.png",
    //     weatherPath + "2.png",
    //     weatherPath + "3.png",
    //     weatherPath + "4.png",
    //     weatherPath + "5.png",
    //     weatherPath + "6.png",
    //     weatherPath + "7.png",
    //     weatherPath + "8.png",
    //     weatherPath + "9.png",
    //     weatherPath + "10.png",
    //     weatherPath + "11.png",
    //     weatherPath + "12.png",
    //     weatherPath + "13.png",
    //     weatherPath + "14.png",
    //     weatherPath + "15.png",
    //     weatherPath + "16.png",
    //     weatherPath + "17.png",
    //     weatherPath + "18.png",
    //     weatherPath + "19.png",
    //     weatherPath + "20.png",
    //     weatherPath + "21.png",
    //     weatherPath + "22.png",
    //     weatherPath + "23.png",
    //     weatherPath + "24.png",
    //     weatherPath + "25.png",
    //     weatherPath + "26.png",
    //     weatherPath + "27.png",
    //     weatherPath + "28.png",
    // ]
    const weather_array = [
      weatherPath + "0.png",
      weatherPath + "1.png",
      weatherPath + "2.png",
      weatherPath + "3.png",
      weatherPath + "4.png",
      weatherPath + "5.png",
      weatherPath + "6.png",
      weatherPath + "7.png",
      weatherPath + "8.png",
      weatherPath + "9.png",
      weatherPath + "10.png",
      weatherPath + "11.png",
      weatherPath + "12.png",
      weatherPath + "13.png",
      weatherPath + "14.png",
      weatherPath + "15.png",
      weatherPath + "16.png",
      weatherPath + "17.png",
      weatherPath + "18.png",
      weatherPath + "19.png",
      weatherPath + "20.png",
      weatherPath + "21.png",
      weatherPath + "22.png",
      weatherPath + "23.png",
      weatherPath + "24.png",
      weatherPath + "25.png",
      weatherPath + "26.png",
      weatherPath + "27.png",
      weatherPath + "28.png",
    ];
    const week_array = [
      weekPath + "1.png",
      weekPath + "2.png",
      weekPath + "3.png",
      weekPath + "4.png",
      weekPath + "5.png",
      weekPath + "6.png",
      weekPath + "7.png",
    ];

    const day_array = [
      dayPath + "0.png",
      dayPath + "1.png",
      dayPath + "2.png",
      dayPath + "3.png",
      dayPath + "4.png",
      dayPath + "5.png",
      dayPath + "6.png",
      dayPath + "7.png",
      dayPath + "8.png",
      dayPath + "9.png",
    ];

    const hour_array = [
      hourPath + "0.png",
      hourPath + "1.png",
      hourPath + "2.png",
      hourPath + "3.png",
      hourPath + "4.png",
      hourPath + "5.png",
      hourPath + "6.png",
      hourPath + "7.png",
      hourPath + "8.png",
      hourPath + "9.png",
    ];
    const xphour_array = [
      xphourPath + "0.png",
      xphourPath + "1.png",
      xphourPath + "2.png",
      xphourPath + "3.png",
      xphourPath + "4.png",
      xphourPath + "5.png",
      xphourPath + "6.png",
      xphourPath + "7.png",
      xphourPath + "8.png",
      xphourPath + "9.png",
    ];

    const logger = DeviceRuntimeCore.HmLogger.getLogger("sanjiao");
    __$$module$$__.module = DeviceRuntimeCore.Page({
      init_view() {
        let bg = hmUI.createWidget(hmUI.widget.IMG, {
          //beijing
          x: 0,
          y: 0,
          w: 390,
          h: 450,
          src: ROOTPATH + "bg/bg.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        //===================================动画========================================

        //===========================================================================

        let YTD = hmUI.createWidget(hmUI.widget.IMG_DATE, {
          year_startX: 31,
          year_startY: 127,

          year_align: hmUI.align.CENTER_H,
          year_space: 0, //文字间隔
          year_zero: 1, //补零
          year_follow: 0, //是否跟随   不跟随
          year_en_array: day_array,
          year_sc_array: day_array,
          year_tc_array: day_array,

          month_startX: 125,
          month_startY: 127,

          month_align: hmUI.align.CENTER_H,
          month_space: 0, //文字间隔
          month_zero: 1, //补零
          month_follow: 0, //是否跟随  不跟随
          // month_follow: 1,//是否跟随  跟随
          month_en_array: day_array,
          month_sc_array: day_array,
          month_tc_array: day_array,
          //  month_is_character: true,  //会影响补零   为true时 传入的图片为月份12张

          day_startX: 176,
          day_startY: 127,

          day_align: hmUI.align.CENTER_H,
          day_space: -1, //文字间隔
          day_zero: 1, //补零
          day_follow: 0, //是否跟随 不跟随
          day_en_array: day_array,
          day_sc_array: day_array,
          day_tc_array: day_array,
          // day_is_character: true,   //会影响补零   为true时 传入的图片为日31张
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        let dian_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 110,
          y: 127,
          src: "images/Day/dian.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        let dian_img_1 = hmUI.createWidget(hmUI.widget.IMG, {
          x: 160,
          y: 127,
          src: "images/Day/dian.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
          //zhoushu
          x: 220,
          y: 125,
          week_en: week_array,
          week_tc: week_array,
          week_sc: week_array,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let maohao_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 110,
          y: 42,
          src: "images/hour/maohao.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          hour_zero: 1, //是否补零
          hour_startX: 20,
          hour_startY: 42,
          hour_array: hour_array,
          hour_space: 0, //每个数组间的间隔
          minute_zero: 1, //是否补零
          minute_startX: 145,
          minute_startY: 42,
          minute_array: hour_array,
          minute_space: 0, //每个数组间的间隔

          am_x: 253,
          am_y: 73,
          am_sc_path: "images/hour/am.png", //上午图片
          am_en_path: "images/hour/am.png",
          pm_x: 251,
          pm_y: 73,
          pm_sc_path: "images/hour/pm.png", // 下午图片
          pm_en_path: "images/hour/pm.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        const weather_img = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 144,
          y: 217,
          image_array: weather_array,
          image_length: weather_array.length,
          type: hmUI.data_type.WEATHER,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        let AOD_timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          hour_zero: 1, //是否补零
          hour_startX: 20,
          hour_startY: 42,
          hour_array: xphour_array,
          hour_space: 0, //每个数组间的间隔
          minute_zero: 1, //是否补零
          minute_startX: 143,
          minute_startY: 42,
          minute_array: xphour_array,
          minute_space: 0, //每个数组间的间隔

          am_x: 251,
          am_y: 73,
          am_sc_path: "images/xphour/am.png", //上午图片
          am_en_path: "images/xphour/am.png",
          pm_x: 251,
          pm_y: 73,
          pm_sc_path: "images/xphour/pm.png", // 下午图片
          pm_en_path: "images/xphour/pm.png",
          show_level: hmUI.show_level.ONAL_AOD,
        });

        let AOD_maohao_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 108,
          y: 42,
          src: "images/xphour/maohao.png",
          show_level: hmUI.show_level.ONAL_AOD,
        });
      },

      onInit() {
        console.log("index page.js on init invoke");
        this.init_view();
      },

      onReady() {
        console.log("index page.js on ready invoke");
      },

      onShow() {
        console.log("index page.js on show invoke");
      },

      onHide() {
        console.log("index page.js on hide invoke");
      },

      onDestory() {
        console.log("index page.js on destory invoke");
      },
    });
    /*
     * end js
     */
  })();
} catch (e) {
  console.log(e);
}
