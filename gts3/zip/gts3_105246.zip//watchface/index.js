
    /*
    ** huamiOS bundle tool v1.0.17
    * *huamiOS watchface js version v1.0.1
    * *Copyright © Huami. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start
        let normal$_$background$_$bg = ''
        let normal$_$battery$_$pointer_progress$_$img_pointer = ''
        let normal$_$week$_$week = ''
        let normal$_$analog_clock$_$time_pointer = ''
        let idle$_$idle_background$_$bg = ''
        let idle$_$analog_clock$_$time_pointer = ''
        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            normal$_$background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$battery$_$pointer_progress$_$img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '2.png',
              center_x: 195,
              center_y: 143,
              x: 9,
              y: 76,
              type: hmUI.data_type.BATTERY,
              start_angle: -120,
              end_angle: 120,
              cover_path: '',
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$week$_$week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 121,
              y: 242,
              week_en: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              week_tc: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              week_sc: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$analog_clock$_$time_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_centerX: 195,
              hour_centerY: 225,
              hour_posX: 16,
              hour_posY: 154,
              hour_path: '11.png',
              hour_cover_path: '10.png',
              hour_cover_x: 176,
              hour_cover_y: 206,
              minute_centerX: 195,
              minute_centerY: 225,
              minute_posX: 16,
              minute_posY: 174,
              minute_path: '13.png',
              minute_cover_path: '12.png',
              minute_cover_x: 182,
              minute_cover_y: 212,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            idle$_$idle_background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: '14.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

                    
            idle$_$analog_clock$_$time_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_centerX: 195,
              hour_centerY: 225,
              hour_posX: 17,
              hour_posY: 154,
              hour_path: '15.png',
              hour_cover_path: '',
              hour_cover_x: 0,
              hour_cover_y: 0,
              minute_centerX: 195,
              minute_centerY: 225,
              minute_posX: 17,
              minute_posY: 180,
              minute_path: '17.png',
              minute_cover_path: '16.png',
              minute_cover_x: 181,
              minute_cover_y: 211,
              show_level: hmUI.show_level.ONAL_AOD,
            });
  
            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  