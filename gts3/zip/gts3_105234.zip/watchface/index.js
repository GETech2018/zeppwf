
/*
** huamiOS bundle tool v1.0.17
* *huamiOS watchface js version v1.0.1
* *Copyright © Huami. All Rights Reserved
*/

try {

  (() => {

    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
    var __$$module$$__ = __$$app$$__.current;
    //drink is a name,can modify
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

    'use strict';
    let bg = null;
    let editGroup = null;
    let topText = null;
    let timePointer = null;
    let maskFg = null;
    let maskCover = null;
    let rootPath = "images/"; 
    let topNum = null 
    let bottomNum = null
    let dataArr = null 
    let dataSmallArr = null
    let  clockTimer = null
    let secTimer = null 
    let currentSec = null
    let nextSec = null 
    let line = null
    let lineTimer = null 
    let topY = 74
    let bottomY = 134
    let lineX= 102
    let lineRunCount =0;
    let goback = false;
    let timeNumArr =[
      rootPath + 'ffffffnum/0.png',
      rootPath + 'ffffffnum/1.png',
      rootPath + 'ffffffnum/2.png',
      rootPath + 'ffffffnum/3.png',
      rootPath + 'ffffffnum/4.png',
      rootPath + 'ffffffnum/5.png',
      rootPath + 'ffffffnum/6.png',
      rootPath + 'ffffffnum/7.png',
      rootPath + 'ffffffnum/8.png',
      rootPath + 'ffffffnum/9.png', 
    ]
     dataArr =[
      rootPath + '0000Num/0.png',
      rootPath + '0000Num/1.png',
      rootPath + '0000Num/2.png',
      rootPath + '0000Num/3.png',
      rootPath + '0000Num/4.png',
      rootPath + '0000Num/5.png',
      rootPath + '0000Num/6.png',
      rootPath + '0000Num/7.png',
      rootPath + '0000Num/8.png',
      rootPath + '0000Num/9.png', 
    ]
     dataSmallArr =[
      rootPath + 'small0000Num/0.png',
      rootPath + 'small0000Num/1.png',
      rootPath + 'small0000Num/2.png',
      rootPath + 'small0000Num/3.png',
      rootPath + 'small0000Num/4.png',
      rootPath + 'small0000Num/5.png',
      rootPath + 'small0000Num/6.png',
      rootPath + 'small0000Num/7.png',
      rootPath + 'small0000Num/8.png',
      rootPath + 'small0000Num/9.png', 
    ]
    let redNumArr = [] 
    for(let i=0 ; i<10; i++){
      redNumArr.push(rootPath + "redNum/"+ i +".png")
    } 

    const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang"); 
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({ 
      init_view() {
        var screenType = hmSetting.getScreenType();
        var nomalModel = screenType == hmSetting.screen_type.APP || screenType == hmSetting.screen_type.WATCHFACE;
        var aodModel = screenType == hmSetting.screen_type.AOD;
        if (nomalModel) {
          topNum = hmUI.createWidget(hmUI.widget.IMG, {
            x: 292,
            y: 74,
            w: 45,
            h: 62, 
            //src: rootPath + "redNum/"+ currentSec + '.png', 
            show_level:hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD,
      });
      bottomNum = hmUI.createWidget(hmUI.widget.IMG, {
            x: 292,
            y: 134,
            w: 45,
            h: 62, 
           // src: rootPath + "redNum/"+ nextSec + '.png', 
            show_level:hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD,
        }); 
          getsecond();
         let secMask= hmUI.createWidget(hmUI.widget.IMG, {
            x: 292,
            y: 72,
            w: 46,
            h: 63, 
            src: rootPath + "bg/timeMask.png", 
            show_level:hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD 
            });
          hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450, 
                src: rootPath + "bg/bg.png", 
                show_level:hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD 
          });
          line = hmUI.createWidget(hmUI.widget.IMG, {
            x: 102,
            y: 245,
            w: 4,
            h: 7, 
            src: rootPath + "mask/split.png", 
            show_level:hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD 
            });
            line.setProperty(hmUI.prop.VISIBLE,false);
          let lineMask= hmUI.createWidget(hmUI.widget.IMG, {
            x: 98,
            y: 244,
            w: 194,
            h: 9, 
            src: rootPath + "mask/lineMask.png", 
            show_level:hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD 
            });
          let dataImg = hmUI.createWidget(hmUI.widget.IMG_DATE,{
            year_startX: 128,
            year_startY: 368 ,
            year_align: hmUI.align.LEFT,
            year_space: 0,
            year_zero: 1,
            year_follow: 1,
            year_unit_sc: rootPath+"0000Num/sp.png",
            year_unit_tc: rootPath+"0000Num/sp.png",
            year_unit_en: rootPath+"0000Num/sp.png",
            year_en_array: dataArr,
            year_sc_array: dataArr,
            year_tc_array: dataArr,

            month_startX: 223,
            month_startY: 368 ,
            month_align: hmUI.align.LEFT,
            month_space: 0,
            month_zero: 1,
            month_follow: 0,
            month_is_character: false, 
            month_unit_sc: rootPath+"0000Num/sp.png",
            month_unit_tc: rootPath+"0000Num/sp.png",
            month_unit_en: rootPath+"0000Num/sp.png",
            month_en_array: dataArr,
            month_sc_array: dataArr,
            month_tc_array: dataArr,

            day_startX: 280,
            day_startY: 368 ,
            day_align: hmUI.align.LEFT,
            day_space: 0,
            day_zero: 1,
            day_follow: 0,
            day_en_array: dataArr,
            day_sc_array: dataArr,
            day_tc_array: dataArr,
           // day_is_character: true, 
           show_level: hmUI.show_level.ONAL_NORMAL,
          });
          let batTxt =  hmUI.createWidget(hmUI.widget.TEXT_IMG, {
            x: 255,
            y: 210,
            type: hmUI.data_type.BATTERY, 
            font_array: dataSmallArr,   
            h_space: 2,  
            //align_h: hmUI.align.LEFT,
            align_h: hmUI.align.RIGHT,
            padding: false, //是否补零 true为补零
            show_level: hmUI.show_level.ONAL_NORMAL,   
          });
          let batPer= hmUI.createWidget(hmUI.widget.IMG, {
            x: 285,
            y: 210,
            w: 14,
            h: 15, 
            src:  rootPath + "small0000Num/per.png",
            show_level:hmUI.show_level.ONLY_NORMAL, 
            });
          let stepTxt =  hmUI.createWidget(hmUI.widget.TEXT_IMG, {
            x: 50,
            y: 322,
            type: hmUI.data_type.STEP, 
            font_array: dataArr,   
            h_space: 0,  
            align_h: hmUI.align.LEFT,
            padding: false, //是否补零 true为补零
            show_level: hmUI.show_level.ONAL_NORMAL,   
          });
          let calTxt =  hmUI.createWidget(hmUI.widget.TEXT_IMG, {
            x: 260,
            y: 322,
            font_array: dataArr,   
            h_space: 0,  
            align_h: hmUI.align.RIGHT,
            padding: false, //是否补零 true为补零
            type: hmUI.data_type.CAL,   
            show_level: hmUI.show_level.ONAL_NORMAL,   
          });
        let heartTxt =  hmUI.createWidget(hmUI.widget.TEXT_IMG, {
            x: 166,
            y: 322,
            font_array: dataArr,   
            h_space: 0,  
            align_h: hmUI.align.CENTER_H,
            padding: false, //是否补零 true为补零 
            isCharacter: true, //true为文字图片
            type: hmUI.data_type.HEART, 
            invalid_image:    rootPath+"0000Num/none.png",
            show_level: hmUI.show_level.ONAL_NORMAL,   
          });
          
          startsecTimer();
        } else if (aodModel) {
          hmUI.createWidget(hmUI.widget.IMG, {
            x: 0,
            y: 0,
            w: 390,
            h: 450, 
            src: rootPath + "bg/bg_xp.png", 
            show_level:hmUI.show_level.ONAL_AOD, 
           });
          timer.stopTimer(clockTimer);
          timer.stopTimer(lineTimer);
          timer.stopTimer(secTimer);
        }
        let hourAndMinText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          hour_zero:1,  
          hour_startX:69,
          hour_startY:91,
          hour_array:timeNumArr,
          hour_space:34,  

          minute_zero:1, 
          minute_startX:177,
          minute_startY:91,
          minute_array:timeNumArr,
          minute_space:34, 
        });
        function getsecond (){ 
          var  jstime = hmSensor.createSensor(hmSensor.id.TIME);
          currentSec = jstime.second ;
          if(currentSec == 59){
            nextSec = 0
          } else {
            nextSec = currentSec + 1;
          }
          topNum.setProperty(hmUI.prop.Y,34);
          bottomNum.setProperty(hmUI.prop.Y,134); 
          topNum.setProperty(hmUI.prop.SRC,rootPath + "redNum/"+ currentSec + '.png');
          bottomNum.setProperty(hmUI.prop.SRC,rootPath + "redNum/"+ nextSec + '.png');
          startClock();
        }
        function startClock()
        {
            topY=74;
            bottomY=134;
            clockTimer = timer.createTimer(10, 100, (function (option) {
              //回调
             // console.log(bottomY+"==bottomY   timer callback++++++++++++++++++topY:"+topY);
              topY-= 10;
              bottomY-=10;
              topNum.setProperty(hmUI.prop.Y,topY);
              bottomNum.setProperty(hmUI.prop.Y,bottomY); 
              if(bottomY <= 74 || topY <=4 ){
                console.log("stopTimer@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
               // console.log(bottomY+"==bottomY   timer callback++++++++++++++++++topY:"+topY);
                timer.stopTimer(clockTimer);
                topY=74;
                bottomY=134;
                topNum.setProperty(hmUI.prop.SRC,rootPath + "redNum/"+ nextSec + '.png');
                topNum.setProperty(hmUI.prop.Y,topY);
                bottomNum.setProperty(hmUI.prop.Y,bottomY); 
              }
            }));
        }

        function startsecTimer()
        {
          secTimer = timer.createTimer(1000, 1000, (function (option) {
            var jstime = hmSensor.createSensor(hmSensor.id.TIME);
            //var topPath = rootPath + "redNum/"+ nextSec + '.png';
            var bottomPath = rootPath + "redNum/"+ jstime.second + '.png';
            //topNum.setProperty(hmUI.prop.Y,74);
            //bottomNum.setProperty(hmUI.prop.Y,134);
            //topNum.setProperty(hmUI.prop.SRC,topPath);
            bottomNum.setProperty(hmUI.prop.SRC,bottomPath);
            nextSec = jstime.second;
            timer.stopTimer(clockTimer);
            if(Math.random()>0.5 && lineX==102)
            {
              line.setProperty(hmUI.prop.X,lineX);
              line.setProperty(hmUI.prop.VISIBLE,true); 
              timer.stopTimer(lineTimer);
              createLineTime();
            }
            startClock();
          }));
        }
          function  createLineTime()
          {
            lineTimer = timer.createTimer(100, 10, (function (option) {
                  lineX+=10;
                  line.setProperty(hmUI.prop.X,lineX); 
                  if(lineX>=292){ 
                    lineX=102;
                    line.setProperty(hmUI.prop.VISIBLE,false); 
                    timer.stopTimer(lineTimer);
                  }
              }));
            }

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('ui resume');
                if(goback)
                {
                  lineX=102;
                  topNum.setProperty(hmUI.prop.VISIBLE,true); 
                  bottomNum.setProperty(hmUI.prop.VISIBLE,true);
                  goback =false;
                  var jstime = hmSensor.createSensor(hmSensor.id.TIME);
                  var topPath = rootPath + "redNum/"+ jstime.second + '.png';
                  topNum.setProperty(hmUI.prop.SRC,topPath);
                  startsecTimer();
                }
              }),
              pause_call: (function () {
                console.log('ui pause');
                // timer.stopTimer(lineTimer);
                // timer.stopTimer(clockTimer);
                // timer.stopTimer(secTimer);
                // goback =true;
                
                // line.setProperty(hmUI.prop.VISIBLE,false); 
                // topNum.setProperty(hmUI.prop.Y,74);
                // bottomNum.setProperty(hmUI.prop.Y,134); 
              }),

            });

        },

      onInit() {
        console.log('index page.js on init invoke') 
        this.init_view() 
      },

      onReady() {
        console.log('index page.js on ready invoke')
      },

      onShow() {
        console.log('index page.js on show invoke')
      },

      onHide() {
        console.log('index page.js on hide invoke')
      },

      onDestory() {
        console.log('index page.js on destory invoke')
      },
    });

  })()
} catch (e) {
  console.log(e)
}
