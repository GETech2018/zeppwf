try {
    (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;

        var __$$module$$__ = __$$app$$__.current;
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        /*
      * huamiOS bundle tool v1.0.17
      * Copyright © Huami. All Rights Reserved
      */
        'use strict';

        console.log("----->>>current");
        console.log(__$$hmAppManager$$__.currentApp.pid);
        console.log(__$$hmAppManager$$__.currentApp.current);

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

            init_view() {
                let rootPath = "images/";
                let screenType = hmSetting.getScreenType()
                let timeArr = []
                let interestArr = []
                let batteryArr = []
                let paiArr = []
                let weekArr = []
                let week_aod_arr = []
                for (let i = 0; i < 10; i++) {
                    if (i >= 1 && i <= 7) {
                        weekArr.push(rootPath + "week/" + i + ".png")
                        week_aod_arr.push(rootPath + "week_aod/" + i + ".png")
                    }
                    batteryArr.push(rootPath + "battery/" + i + ".png")
                    paiArr.push(rootPath + "PAI/" + i + ".png")
                    timeArr.push(rootPath + "time/" + i + ".png")
                    interestArr.push(rootPath + "interest/" + i + ".png")
                }
                if (screenType == hmSetting.screen_type.AOD) {
                    let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                        hour_zero: 1,
                        hour_startX: 99,
                        hour_startY: 122,
                        hour_array: interestArr,
                        hour_space: 0,
                        hour_align: hmUI.align.LEFT,

                        minute_zero: 1,
                        minute_startX: 183,
                        minute_startY: 122,
                        minute_array: interestArr,
                        minute_space: 0,
                        minute_align: hmUI.align.LEFT,
                    });
                    //week
                    hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                        x: 100,
                        y: 168,
                        week_en:week_aod_arr,
                        week_tc:week_aod_arr,
                        week_sc:week_aod_arr,
                    });
                } else {
                    //background
                    let bg = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 0,
                        y: 0,
                        w: 390,
                        h: 450,
                        src: rootPath + "background/bg.png",
                    });
                    // animate
                    let animate = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                        x: 0,
                        y: 0,
                        anim_path: rootPath + "animate", //必须从0开始 可以询问君成 张莉
                        anim_prefix: "anim",
                        anim_ext: "png",
                        anim_fps: 25,
                        anim_size: 25,
                        repeat_count: 1, //0位无限重复
                        anim_repeat: false,//是否重复
                        anim_status: hmUI.anim_status.START,
                        display_on_restart: false,//从息屏到亮屏是否自动重复播放
                    });
                    //time
                    let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                        hour_zero: 1,
                        hour_startX: 99,
                        hour_startY: 122,
                        hour_array: timeArr,
                        hour_space: -3,
                        hour_align: hmUI.align.LEFT,

                        minute_zero: 1,
                        minute_startX: 183,
                        minute_startY: 122,
                        minute_array: timeArr,
                        minute_space: -3,
                        minute_align: hmUI.align.LEFT,

                        am_x: 303,
                        am_y: 46,
                        am_sc_path: rootPath + "AP/AM.png",
                        am_en_path: rootPath + "AP/AM.png",

                        pm_x: 303,
                        pm_y: 46,
                        pm_sc_path: rootPath + "AP/PM.png",
                        pm_en_path: rootPath + "AP/PM.png",
                    });
                    //battery 
                    let powerText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 254,
                        y: 300,
                        type: hmUI.data_type.BATTERY,
                        font_array: batteryArr,
                        h_space: 0,
                        align_h: hmUI.align.CENTER_H,
                        padding: false,
                        isCharacter: true,
                    });
                    //pai
                    let PAIText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 75,
                        y: 63,
                        type: hmUI.data_type.PAI_DAILY,
                        font_array: paiArr,
                        h_space: 0,
                        align_h: hmUI.align.CENTER_H,
                        padding: false,
                        isCharacter: true,
                    });
                    //heart
                    let heartText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 171,
                        y: 76,
                        type: hmUI.data_type.HEART,
                        font_array: paiArr,
                        h_space: 0,
                        align_h: hmUI.align.LEFT,
                        invalid_image:rootPath + 'PAI/none.png',
                        padding: false,
                        isCharacter: true,
                    });
                    //week
                    hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                        x: 100,
                        y: 168,
                        week_en:weekArr,
                        week_tc:weekArr,
                        week_sc:weekArr,
                    });
                }

            },

            onInit() {
                console.log('index page.js on init invoke')

                this.init_view();
            },

            onReady() {
                console.log('index page.js on ready invoke')
            },

            onShow() {
                console.log('index page.js on show invoke')
            },

            onHide() {
                console.log('index page.js on hide invoke')
            },

            onDestory() {
                console.log('index page.js on destory invoke')
                timer.stopTimer(timerSupport)
            },
        });
        /*
        * end js
        */
    })()
} catch (e) {
    console.log(e)
}