
/*
** huamiOS bundle tool v1.0.17
* *huamiOS watchface js version v1.0.1
* *Copyright © Huami. All Rights Reserved
*/

try {

  (() => {

    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
    var __$$module$$__ = __$$app$$__.current;
    //drink is a name,can modify
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

    'use strict';
    let bg = null;
  
    
    let timePointer = null;
    let rootPath = "images/";
    let fontArray = [
      rootPath + "data/0.png",
      rootPath + "data/1.png",
      rootPath + "data/2.png",
      rootPath + "data/3.png",
      rootPath + "data/4.png",
      rootPath + "data/5.png",
      rootPath + "data/6.png",
      rootPath + "data/7.png",
      rootPath + "data/8.png",
      rootPath + "data/9.png",
    ];
    let weekArr_en = [
      rootPath + "week/en/1.png",
      rootPath + "week/en/2.png",
      rootPath + "week/en/3.png",
      rootPath + "week/en/4.png",
      rootPath + "week/en/5.png",
      rootPath + "week/en/6.png",
      rootPath + "week/en/7.png",
    ];
    let weekArr_sc = [
      rootPath + "week/cn/1.png",
      rootPath + "week/cn/2.png",
      rootPath + "week/cn/3.png",
      rootPath + "week/cn/4.png",
      rootPath + "week/cn/5.png",
      rootPath + "week/cn/6.png",
      rootPath + "week/cn/7.png",
    ];
    let monthArr_en = [
      rootPath + "month/en/1.png",
      rootPath + "month/en/2.png",
      rootPath + "month/en/3.png",
      rootPath + "month/en/4.png",
      rootPath + "month/en/5.png",
      rootPath + "month/en/6.png",
      rootPath + "month/en/7.png",
      rootPath + "month/en/8.png",
      rootPath + "month/en/9.png",
      rootPath + "month/en/10.png",
      rootPath + "month/en/11.png",
      rootPath + "month/en/12.png",
    ];
    let monthArr_sc = [
      rootPath + "month/cn/1.png",
      rootPath + "month/cn/2.png",
      rootPath + "month/cn/3.png",
      rootPath + "month/cn/4.png",
      rootPath + "month/cn/5.png",
      rootPath + "month/cn/6.png",
      rootPath + "month/cn/7.png",
      rootPath + "month/cn/8.png",
      rootPath + "month/cn/9.png",
      rootPath + "month/cn/10.png",
      rootPath + "month/cn/11.png",
      rootPath + "month/cn/12.png",
    ];
    const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({

      init_view() {

        var screenType = hmSetting.getScreenType();
        var nomalModel = screenType == hmSetting.screen_type.APP || screenType == hmSetting.screen_type.WATCHFACE;
        var aodModel = screenType == hmSetting.screen_type.AOD;
        if (nomalModel) {
          bg = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
            x: 0,
            y: 30,
            w: 390,
            h: 390,
            align_h: hmUI.align.CENTER_H,
            align_v: hmUI.align.CENTER_V,
            anim_path: rootPath + "breath_animate",
            anim_prefix: "breath",
            anim_ext: "png",
            anim_fps: 20,
            anim_size: 200,
            anim_repeat: true,
            repeat_count: 0,
            anim_status: 1,
            display_on_restart:true,
          });
          let maskImg = hmUI.createWidget(hmUI.widget.IMG,{
            x: 0,  //日期图片的 x 位置
            y: 0,
            w: 390,  //日期图片的宽度
            h: 450,  //日期图片的高度
            src:  rootPath + "img/mask.png", 
            show_level: hmUI.show_level.ONAL_NORMAL,
          });
          showHeart();
          showStep();
        } else if (aodModel) {
          bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
            x: 0,
            y: 0,
            w: 390,
            h: 450,
            color: 0x000000,
          });
        }
        weekLevel = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
          x: 220,
          y: 402,
          week_sc: weekArr_sc,
          week_tc: weekArr_sc,
          week_en: weekArr_en,
          show_level: hmUI.show_level.ALL,
      });

      day_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
        month_startX: 73,
        month_startY: 402,
        month_en_array: monthArr_en,
        month_sc_array: monthArr_sc,
        month_tc_array: monthArr_sc,
        month_space: 0,
        month_zero: 1,
        month_is_character:true,

        day_startX: 166,
        day_startY: 402,
        day_en_array: fontArray,
        day_space: 0,
        day_zero: 1,
        day_unit_sc: rootPath+"img/comma.png",
        day_unit_tc: rootPath+"img/comma.png",
        day_unit_en: rootPath+"img/comma.png",
        show_level: hmUI.show_level.ALL,
      });
      showAodTime();
      showNomalTime(); 
        function showNomalTime() {
          timePointer  = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
            hour_centerX: 195,
            hour_centerY: 225,
            hour_posX: 17,
            hour_posY: 225,
            hour_path: rootPath+"img/hour.png",

            minute_centerX: 195,
            minute_centerY: 225,
            minute_posX: 17,
            minute_posY: 225,
            minute_path: rootPath+"img/min.png",

            second_centerX: 195,
            second_centerY: 225,
            second_posX: 10,
            second_posY: 225,
            second_path: rootPath + "img/sec.png",
            show_level:hmUI.show_level.ONAL_NORMAL,
          });
         }
         function showAodTime() {
          timePointer  = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
            hour_centerX: 195,
            hour_centerY: 225,
            hour_posX: 17,
            hour_posY: 225,
            hour_path: rootPath+"img/hour_xp.png",

            minute_centerX: 195,
            minute_centerY: 225,
            minute_posX: 17,
            minute_posY: 225,
            minute_path: rootPath+"img/min_xp.png",
            show_level:hmUI.show_level.AOD,
          });
         }
       
      function showHeart()
      {
        let heartTxt  = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 272,
          y: 18,
          type: hmUI.data_type.HEART,   // 获取心率数字，自动获取
          font_array: fontArray,   //心率数字图片
          h_space: 0,  //数字之间的间隔
          align_h: hmUI.align.RIGHT,   //数字的对齐方式
          padding:false, //是否补零 true为补零
          isCharacter:true, //true为文字图片
          invalid_image: rootPath + "img/invalid.png",// 无数据时显示的图片
          show_level: hmUI.show_level.ONAL_NORMAL,   //心率是否在息屏
        });
        var heartImg = hmUI.createWidget(hmUI.widget.IMG,{
          x: 334,  //日期图片的 x 位置
          y: 18,
          w: 32,  //日期图片的宽度
          h: 32,  //日期图片的高度
          src:  rootPath + "img/heart.png", 
          show_level: hmUI.show_level.ONAL_NORMAL,
        });
      }
      function showStep()
      {
        let stepTxt  = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 64,
          y: 18,
          type: hmUI.data_type.STEP,   // 获取心率数字，自动获取
          font_array: fontArray,   //心率数字图片
          h_space: 0,  //数字之间的间隔
          align_h: hmUI.align.LEFT,   //数字的对齐方式
          padding:false, //是否补零 true为补零
          isCharacter:true, //true为文字图片
          show_level: hmUI.show_level.ONAL_NORMAL,   //心率是否在息屏
        });
        var stepImg = hmUI.createWidget(hmUI.widget.IMG,{
          x: 24,  //日期图片的 x 位置
          y: 18,
          w: 32,  //日期图片的宽度
          h: 32,  //日期图片的高度
          src:  rootPath + "img/step.png", 
          show_level: hmUI.show_level.ONAL_NORMAL,
        });
        var test = 1111111;
        console.log("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%======" + test);
        console.log("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%======", test);
      }
      },

      onInit() {
        console.log('index page.js on init invoke')

        this.init_view()

      },

      onReady() {
        console.log('index page.js on ready invoke')
      },

      onShow() {
        console.log('index page.js on show invoke')
      },

      onHide() {
        console.log('index page.js on hide invoke')
      },

      onDestory() {
        console.log('index page.js on destory invoke')
      },
    });

  })()
} catch (e) {
  console.log(e)
}
