try {
    (() => {
    
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
  
    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');
  
      /*
    * hugray_small_numiOS bundle tool v1.0.17
    * Copyright © Hugray_small_numi. All Rights Reserved
    */
    'use strict';
  
    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let rootPath = null
 
    let timeArray = null
    let monthArray =null 
    let dateArray = null
    let bg = null
    let animCreate = null
    let weekArr = null

    

    let clock_timer = null
    let monthImg = null
    let dayImg = null
    let  sunArray = null
   
    const logger = DeviceRuntimeCore.HmLogger.getLogger("default2");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({

     

        init_view() {
           
            rootPath = "images/",
            timeArray = [
                rootPath +  "time/time_0.png",
                rootPath +  "time/time_1.png",
                rootPath +  "time/time_2.png",
                rootPath +  "time/time_3.png",
                rootPath +  "time/time_4.png",
                rootPath +  "time/time_5.png",
                rootPath +  "time/time_6.png",
                rootPath +  "time/time_7.png",
                rootPath +  "time/time_8.png",
                rootPath +  "time/time_9.png",
            ]
            monthArray = [
                rootPath +  "month/month_1.png",
                rootPath +  "month/month_2.png",
                rootPath +  "month/month_3.png",
                rootPath +  "month/month_4.png",
                rootPath +  "month/month_5.png",
                rootPath +  "month/month_6.png",
                rootPath +  "month/month_7.png",
                rootPath +  "month/month_8.png",
                rootPath +  "month/month_9.png",
                rootPath +  "month/month_10.png",
                rootPath +  "month/month_11.png",
                rootPath +  "month/month_12.png",
            ]
            dateArray = [
                rootPath + "date/day_0.png",
                rootPath + "date/day_1.png",
                rootPath + "date/day_2.png",
                rootPath + "date/day_3.png",
                rootPath + "date/day_4.png",
                rootPath + "date/day_5.png",
                rootPath + "date/day_6.png",
                rootPath + "date/day_7.png",
                rootPath + "date/day_8.png",
                rootPath + "date/day_9.png",
            ]
            weekArr = [
                
                rootPath + "week/week_1.png",
                rootPath + "week/week_2.png",
                rootPath + "week/week_3.png",
                rootPath + "week/week_4.png",
                rootPath + "week/week_5.png",
                rootPath + "week/week_6.png",
                rootPath + "week/week_7.png",
               
            ]
           
            sunArray = [
                rootPath + "sunNum/st_0.png",
                rootPath + "sunNum/st_1.png",
                rootPath + "sunNum/st_2.png",
                rootPath + "sunNum/st_3.png",
                rootPath + "sunNum/st_4.png",
                rootPath + "sunNum/st_5.png",
                rootPath + "sunNum/st_6.png",
                rootPath + "sunNum/st_7.png",
                rootPath + "sunNum/st_8.png",
                rootPath + "sunNum/st_9.png",
            ]
            var screenType = hmSetting.getScreenType();
                if(screenType == hmSetting.screen_type.AOD){
        
                    bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
                        x: 0,
                        y: 0,
                        w: 390,
                        h: 450,
                        color: 0x000000,
                    });
                }else{
                    bg = hmUI.createWidget(hmUI.widget.IMG,{
                        x: 0,
                        y: 0,
                        w: 390,
                        h: 450,
                        src:  rootPath + "img/bg.png",
                    });
                    playSunMotion();
                    
                    let stepIcon = hmUI.createWidget(hmUI.widget.IMG,{
                        x: 184,
                        y: 13,
                        w: 22,
                        h: 22,
                        src:  rootPath + "img/step.png",
                    });
                    let stepTxt =  hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 162,
                        y: 48,
                        // w: 13,
                        // h: 21,
                        font_array: sunArray,   
                        h_space: 0,  
                        align_h: hmUI.align.CENTER_H,
                        padding: false, //是否补零 true为补零
                        isCharacter: true, //true为文字图片
                        type: hmUI.data_type.STEP,   
                        show_level: hmUI.show_level.ONAL_NORMAL,   
                      });
                      
                }
                let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 61,
                    hour_startY: 115,
                    hour_array: timeArray,
                    hour_space: 0,
                    hour_unit_sc: rootPath+"img/colon.png", //单位
                    hour_unit_tc: rootPath+"img/colon.png",
                    hour_unit_en: rootPath+"img/colon.png",
                    hour_align: hmUI.align.LEFT,

                    minute_zero: 1, //是否补零 1为补零
                    minute_startX: 213,
                    minute_startY: 115,
                    minute_array: timeArray,
                    minute_space: 0, //两个图片间隔 对应GT2的interval
                    minute_follow: 1, //是否跟随
                    minute_align: hmUI.align.LEFT,
                    show_level: hmUI.show_level.ALL,

                    am_x: 330,
                    am_y: 114,
                    am_sc_path:  rootPath+"img/am.png",
                    am_en_path:  rootPath+"img/am.png",

                    pm_x: 330,
                    pm_y: 114,
                    pm_sc_path:  rootPath+"img/pm.png",
                    pm_en_path:  rootPath+"img/pm.png",
                    });

                    let week = hmUI.createWidget(hmUI.widget.IMG_WEEK,{
                        x: 71,
                        y: 216,
                        week_en: weekArr,
                        week_tc: weekArr,
                        week_sc: weekArr,
                        show_level: hmUI.show_level.ALL,
                    });

                    monthImg = hmUI.createWidget(hmUI.widget.IMG_DATE,{
                        month_startX: 178,
                        month_startY: 216 ,
                        month_align: hmUI.align.LEFT,
                        month_space: 0,
                        month_zero: 1,
                        month_follow: 0,
                        month_is_character: true, 
                        month_en_array: monthArray,
                        month_sc_array: monthArray,
                        month_tc_array: monthArray,

                        day_startX: 269,
                        day_startY: 216 ,
                        day_align: hmUI.align.LEFT,
                        day_space: 0,
                        day_zero: 1,
                        day_follow: 0,
                        day_en_array: dateArray,
                        day_sc_array: dateArray,
                        day_tc_array: dateArray,
                       // day_is_character: true, 
                       show_level: hmUI.show_level.ALL,
                    });
                function playSunMotion()
                {
                    animCreate = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                        x: 0,
                        y: 0,
                        anim_path: rootPath + "animate",
                        anim_prefix: "sun",
                        anim_ext: "png",
                        anim_fps: 25,
                        anim_size: 59, //0-60
                        anim_repeat: false,
                        repeat_count: 1,
                        anim_status: 1,
                        display_on_restart: true,//从息屏到亮屏是否自动重复播放
                    });
            } 
            // 
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                resume_call: (function () {
                  //  animCreate.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.START);
                }),
                pause_call: (function () {
                    console.log('ui pause');

                }),

            });

        },

        onInit() {
            console.log('index page.js on init invoke');

            this.init_view();
       
            


        },

        onReady() {
            console.log('index page.js on ready invoke')
        },

        onShow() {
            console.log('index page.js on show invoke')
        },

        onHide() {
            console.log('index page.js on hide invoke')
        },

        onDestory() {
            console.log('index page.js on destory invoke')
            timer.stopTimer(clock_timer);
        },
    });
    /*
    * end js
    */
        })()
    } catch (e) {
        console.log(e)
    }
