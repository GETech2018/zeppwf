try {
    (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;

        var __$$module$$__ = __$$app$$__.current;
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        /*
    * huamiOS bundle tool v1.0.17
    * Copyright © Huami. All Rights Reserved
    */
        'use strict';

        console.log("----->>>current")
        console.log(__$$hmAppManager$$__.currentApp.pid)
        console.log(__$$hmAppManager$$__.currentApp.current)

        const ROOTPATH = "images/";

        const batteryPath = ROOTPATH + "battery/"
        const dayPath = ROOTPATH + "Day/"


        const hourPath = ROOTPATH + "hour/"
        const xphourPath = ROOTPATH + "xphour/"

        const stepPath = ROOTPATH + "step/"
        const minutePath = ROOTPATH + "minute/"
        const weekPath = ROOTPATH + "week/"


        const battery_array = [
            // batteryPath + "0.png",
            batteryPath + "1.png",
            batteryPath + "2.png",
            batteryPath + "3.png",
            batteryPath + "4.png",
            batteryPath + "5.png",
            batteryPath + "6.png",
            batteryPath + "7.png",
            batteryPath + "8.png",
            batteryPath + "9.png",


        ]
        const day_array = [
            dayPath + "0.png",
            dayPath + "1.png",
            dayPath + "2.png",
            dayPath + "3.png",
            dayPath + "4.png",
            dayPath + "5.png",
            dayPath + "6.png",
            dayPath + "7.png",
            dayPath + "8.png",
            dayPath + "9.png",


        ]

        const hour_array = [
            hourPath + "0.png",
            hourPath + "1.png",
            hourPath + "2.png",
            hourPath + "3.png",
            hourPath + "4.png",
            hourPath + "5.png",
            hourPath + "6.png",
            hourPath + "7.png",
            hourPath + "8.png",
            hourPath + "9.png",
        ]
        const xphour_array = [
            xphourPath + "0.png",
            xphourPath + "1.png",
            xphourPath + "2.png",
            xphourPath + "3.png",
            xphourPath + "4.png",
            xphourPath + "5.png",
            xphourPath + "6.png",
            xphourPath + "7.png",
            xphourPath + "8.png",
            xphourPath + "9.png",
        ]

        const step_array = [
            stepPath + "0.png",
            stepPath + "1.png",
            stepPath + "2.png",
            stepPath + "3.png",
            stepPath + "4.png",
            stepPath + "5.png",
            stepPath + "6.png",
            stepPath + "7.png",
            stepPath + "8.png",
            stepPath + "9.png",
        ]

        const minute_array = [
            minutePath + "0.png",
            minutePath + "1.png",
            minutePath + "2.png",
            minutePath + "3.png",
            minutePath + "4.png",
            minutePath + "5.png",
            minutePath + "6.png",
            minutePath + "7.png",
            minutePath + "8.png",
            minutePath + "9.png",
        ]

        const week_array = [

            weekPath + "1.png",
            weekPath + "2.png",
            weekPath + "3.png",
            weekPath + "4.png",
            weekPath + "5.png",
            weekPath + "6.png",
            weekPath + "7.png",

        ]

        let animResident = null  //动画
        let animCreate = null //动画
        const logger = DeviceRuntimeCore.HmLogger.getLogger("sanjiao");
        __$$module$$__.module = DeviceRuntimeCore.Page({


            _animNext() {  //动画
                animResident.setProperty(hmUI.prop.ANIM_STATUS, 1);
                animCreate.setProperty(hmUI.prop.VISIBLE, false);

            },

            init_view() {

                let bg = hmUI.createWidget(hmUI.widget.IMG, { //beijing
                    x: 0,
                    y: 0,
                    w: 390,
                    h: 450,
                    src: ROOTPATH + "bg/bg.png",
                    show_level: hmUI.show_level.ONLY_NORMAL
                });


                let step = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 127,
                    y: 264,
                    // w: 16,
                    // h: 35,
                    type: hmUI.data_type.STEP,
                    font_array: step_array,
                    h_space: 1,
                    //图片间隔
                    align_h: hmUI.align.LEFT, //需要右对齐，否则文字和背景会混乱
                    // padding: true,
                    //是否补零 true为补零   
                    show_level: hmUI.show_level.ONLY_NORMAL


                });

                let batteryevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {  //获取电量图多张图片会选择其中一张
                    x: 213.5,
                    y: 264,
                    // w: 48,
                    // //宽高可省略
                    // h: 23,
                    image_array: battery_array,
                    image_length: battery_array.length,//长度
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                let heart = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 245,
                    y: 318,
                    type: hmUI.data_type.HEART,
                    font_array: step_array,
                    h_space: -1, //图片间隔
                    align_h: hmUI.align.LEFT,
                    // align_h: hmUI.align.CENTER_H,
                    padding: false, //不补零  //是否补零 true为补零 

                    invalid_image: "images/step/none.png", // 无数据时显示的图片

                    show_level: hmUI.show_level.ONLY_NORMAL
                });

                let cal = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 129,
                    y: 318,
                    type: hmUI.data_type.CAL,
                    font_array: step_array,
                    h_space: 0,
                    //图片间隔
                    align_h: hmUI.align.LEFT,
                    // align_h: hmUI.align.CENTER_H,
                    padding: false,
                    //是否补零 true为补零   
                    show_level: hmUI.show_level.ONLY_NORMAL


                });
                //===================================动画========================================

                var screenType = hmSetting.getScreenType();
                var nomalModel = screenType == hmSetting.screen_type.APP || screenType == hmSetting.screen_type.WATCHFACE;
                var aodModel = screenType == hmSetting.screen_type.AOD;
                if (nomalModel) {

                    animResident = hmUI.createWidget(hmUI.widget.IMG_ANIM);
                    animResident.setProperty(hmUI.prop.MORE, {

                        x: 18,
                        y: 14,
                        w: 348,
                        h: 242,
                        align_h: hmUI.align.CENTER_H, // 横轴  
                        align_v: hmUI.align.CENTER_V,// 竖轴
                        anim_path: ROOTPATH + "anims", //文件路径   文件夹的名称
                        anim_prefix: "Madrid", //相当于图片的前缀
                        anim_ext: "png", //图片的后缀以或者图片的格式
                        anim_fps: 10, //图片的播放速度
                        anim_size: 42,//图片的数量
                        anim_repeat: true, //开启循环播放

                        // repeat_count: 210,
                        repeat_count: 1,//0位无限重复
                        anim_status: 1, //  1  开启动画   0  //  关闭动画

                    });

                }


                //===========================================================================

                let week = hmUI.createWidget(hmUI.widget.IMG_WEEK, { //zhoushu
                    x: 188,
                    y: 119,
                    week_en: week_array,
                    week_tc: week_array,
                    week_sc: week_array,
                    show_level: hmUI.show_level.ONLY_NORMAL

                });


                let YTD = hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    year_startX: 85,
                    year_startY: 119,

                    year_align: hmUI.align.CENTER_H,
                    year_space: 0,//文字间隔
                    year_zero: 1,//补零 
                    year_follow: 0,//是否跟随   不跟随
                    year_en_array: day_array,
                    year_sc_array: day_array,
                    year_tc_array: day_array,
                    year_unit_sc: dayPath + "dian.png", //单位
                    year_unit_tc: dayPath + "dian.png",
                    year_unit_en: dayPath + "dian.png",
                    // year_is_character: true, //年份此字段无效 默认为false  
                    //月日同上 需要替换前缀为month/day
                    month_startX: 133,
                    month_startY: 119,
                    month_unit_sc: dayPath + "dian.png", //单位
                    month_unit_tc: dayPath + "dian.png",
                    month_unit_en: dayPath + "dian.png",
                    month_align: hmUI.align.CENTER_H,
                    month_space: 0,//文字间隔
                    month_zero: 1,//补零
                    month_follow: 0,//是否跟随  不跟随
                    // month_follow: 1,//是否跟随  跟随
                    month_en_array: day_array,
                    month_sc_array: day_array,
                    month_tc_array: day_array,
                    //  month_is_character: true,  //会影响补零   为true时 传入的图片为月份12张

                    day_startX: 159,
                    day_startY: 119,

                    day_align: hmUI.align.CENTER_H,
                    day_space: 0,//文字间隔
                    day_zero: 1,//补零 
                    day_follow: 0,//是否跟随 不跟随
                    day_en_array: day_array,
                    day_sc_array: day_array,
                    day_tc_array: day_array,
                    // day_is_character: true,   //会影响补零   为true时 传入的图片为日31张
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });



                let time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1, //是否补零
                    hour_startX: 83,
                    hour_startY: 142,
                    hour_array: hour_array,
                    hour_space: 0, //每个数组间的间隔
                    minute_zero: 1, //是否补零
                    minute_startX: 182,
                    minute_startY: 142,
                    minute_array: hour_array,
                    minute_space: 0, //每个数组间的间隔
                    second_zero: 1, //是否补零
                    second_startX: 268,
                    second_startY: 176,
                    second_array: minute_array,
                    second_space: 0, //每个数组间的间隔
                    am_x: 229,
                    am_y: 119,
                    am_sc_path: "images/sunam/1.png", //上午图片  
                    am_en_path: "images/sunam/1.png",
                    pm_x: 229,
                    pm_y: 119,
                    pm_sc_path: "images/sunpm/1.png", // 下午图片
                    pm_en_path: "images/sunpm/1.png",
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                let maohao_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 167,
                    y: 142,
                    src: "images/hour/maohao.png",
                    show_level: hmUI.show_level.ONLY_NORMAL
                })
                let AOD_timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1, //是否补零
                    hour_startX: 83,
                    hour_startY: 142,
                    hour_array: xphour_array,
                    hour_space: 0, //每个数组间的间隔
                    minute_zero: 1, //是否补零
                    minute_startX: 182,
                    minute_startY: 142,
                    minute_array: xphour_array,
                    minute_space: 0, //每个数组间的间隔
                    show_level: hmUI.show_level.ONAL_AOD
                });

                let AOD_maohao_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 167,
                    y: 142,
                    src: "images/xphour/maohao.png",
                    show_level: hmUI.show_level.ONAL_AOD
                })
            },

            onInit() {
                console.log('index page.js on init invoke')
                this.init_view();
            },

            onReady() {
                console.log('index page.js on ready invoke')
            },

            onShow() {
                console.log('index page.js on show invoke')
            },

            onHide() {
                console.log('index page.js on hide invoke')
            },

            onDestory() {
                console.log('index page.js on destory invoke')
            },
        });
        /*
        * end js
        */
    })()
} catch (e) {
    console.log(e)
}
