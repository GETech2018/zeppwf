try {
    (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;

        var __$$module$$__ = __$$app$$__.current;
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        /*
      * huamiOS bundle tool v1.0.17
      * Copyright © Huami. All Rights Reserved
      */
        'use strict';

        console.log("----->>>current");
        console.log(__$$hmAppManager$$__.currentApp.pid);
        console.log(__$$hmAppManager$$__.currentApp.current);

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

            init_view() {
                let rootPath = "images/";
                let screenType = hmSetting.getScreenType()
                let weekArr = []
                let dayArr = []
                let heartArr = []
                let powerArr = []
                let calArr = []
                let fontArr = []
                let aod_day = []
                let color = ''
                const editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
                    edit_id: 103,
                    x: 0,
                    y: 0,
                    bg_config: [
                        { id: 1, preview: rootPath + 'bg/1.png', path: rootPath + 'bg/blue.png' },
                        { id: 2, preview: rootPath + 'bg/2.png', path: rootPath + 'bg/green.png' },
                        { id: 3, preview: rootPath + 'bg/3.png', path: rootPath + 'bg/red.png' },
                    ],
                    count: 3,
                    default_id: 1,
                    fg: rootPath + 'mask/mask.png',
                    tips_x: 143,
                    tips_y: 410,
                    tips_bg: rootPath + 'tip/tag.png',
                });
                let bg_type = editBg.getProperty(hmUI.prop.CURRENT_TYPE);
                if (bg_type == 1) {
                    color = 'blue'
                } else if (bg_type == 2) {
                    color = 'green'
                } else if (bg_type == 3) {
                    color = 'red'
                }
                for (let i = 1; i < 8; i++) {
                    weekArr.push(rootPath + 'week/' + i + '.png')
                    heartArr.push(rootPath + color + '/heart/progressbar/' + i + '.png')
                }
                for (let i = 0; i < 10; i++) {
                    dayArr.push(rootPath + color + '/date/' + i + '.png')
                    fontArr.push(rootPath + 'font/' + i + '.png')
                    aod_day.push(rootPath + 'aodDate/' + i + '.png')
                }
                for (let i = 0; i < 11; i++) {
                    powerArr.push(rootPath + color + '/battery/progressbar/' + i + '.png')
                    calArr.push(rootPath + color + '/kcal/progressbar/' + i + '.png')
i                }
                if (screenType == hmSetting.screen_type.AOD) {
                    var fill_rect = hmUI.createWidget(hmUI.widget.FILL_RECT, {
                        x: 0,
                        y: 0,
                        w: 390,
                        h: 450,
                        color: 0x000000,
                    });
                    let day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
                        day_startX: 163,
                        day_startY: 294,
                        day_align: hmUI.align.LEFT,
                        day_space: 0,
                        day_zero: 1,
                        day_en_array: aod_day,
                        day_sc_array: aod_day,
                        day_tc_array: aod_day,
                        day_is_character: false,
                    });
                    let week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                        x: 96,
                        y: 350,
                        week_en: weekArr,
                        week_tc: weekArr,
                        week_sc: weekArr,
                    });
                    let timePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                        hour_centerX: 195,
                        hour_centerY: 225,
                        hour_posX: 16,
                        hour_posY: 225,
                        hour_path: rootPath + 'aodHand/hour.png',

                        minute_centerX: 195,
                        minute_centerY: 225,
                        minute_posX: 13,
                        minute_posY: 225,
                        minute_path: rootPath + 'aodHand/minute.png',
                    });
                } else {
                    let day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
                        day_startX: 163,
                        day_startY: 294,
                        day_align: hmUI.align.LEFT,
                        day_space: 0,
                        day_zero: 1,
                        day_en_array: dayArr,
                        day_sc_array: dayArr,
                        day_tc_array: dayArr,
                        day_is_character: false,
                         show_level: hmUI.show_level.ONLY_NORMAL  
                    });
                    let week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                        x: 96,
                        y: 350,
                        week_en: weekArr,
                        week_tc: weekArr,
                        week_sc: weekArr, 
                        show_level: hmUI.show_level.ONLY_NORMAL  ,
                        
                    });
                    let heartBg = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 145,
                        y: 60,
                        w: 100,
                        h: 100,
                        src: rootPath + color + '/heart/progressbar/1.png',
                        show_level: hmUI.show_level.ONLY_NORMAL  
                    });
                    let heartLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                        x: 145,
                        y: 60,
                        w: 100,
                        h: 100,
                        image_array: heartArr,
                        image_length: heartArr.length,
                        type: hmUI.data_type.HEART,
                         show_level: hmUI.show_level.ONLY_NORMAL  
                    });
                    let heartIcon = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 179,
                        y: 128,
                        src: rootPath + color + '/icon/Heart.png',
                         show_level: hmUI.show_level.ONLY_NORMAL  
                    });
                    let heartText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 165,
                        y: 92,
                        type: hmUI.data_type.HEART,
                        font_array: fontArr,
                        h_space: 0,
                        align_h: hmUI.align.CENTER_H,
                        invalid_image: rootPath + 'font/none.png',
                        padding: false,
                         show_level: hmUI.show_level.ONLY_NORMAL  
                    });
                    let powerBg = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 54,
                        y: 174,
                        w: 100,
                        h: 100,
                        src: rootPath + color + '/basebg/bat.png',
                        show_level: hmUI.show_level.ONLY_NORMAL  
                    });
                    let powerLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                        x: 54,
                        y: 174,
                        w: 100,
                        h: 100,
                        image_array: powerArr,
                        image_length: powerArr.length,
                        type: hmUI.data_type.BATTERY,
                         show_level: hmUI.show_level.ONLY_NORMAL  
                    });
                    let powerIcon = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 58,
                        y: 238,
                        src: rootPath + color + '/icon/Battery.png',
                         show_level: hmUI.show_level.ONLY_NORMAL  
                    });
                    let powerText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 72,
                        y: 205,
                        type: hmUI.data_type.BATTERY,
                        font_array: fontArr,
                        h_space: 0,
                        align_h: hmUI.align.CENTER_H,
                        invalid_image: rootPath + 'font/none.png',
                        padding: false,
                         show_level: hmUI.show_level.ONLY_NORMAL  
                    });
                     let calBg = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 236,
                        y: 174,
                        w: 100,
                        h: 100,
                        src: rootPath + color + '/basebg/cal.png',
                        show_level: hmUI.show_level.ONLY_NORMAL  
                    });
                    let calLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                        x: 236,
                        y: 174,
                        w: 100,
                        h: 100,
                        image_array: calArr,
                        image_length: calArr.length,
                        type: hmUI.data_type.CAL,
                         show_level: hmUI.show_level.ONLY_NORMAL  
                    });
                    let calIcon = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 300,
                        y: 238,
                        src: rootPath + color + '/icon/Calories.png',
                         show_level: hmUI.show_level.ONLY_NORMAL  
                    });
                    let calText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 246,
                        y: 205,
                        type: hmUI.data_type.CAL,
                        font_array: fontArr,
                        h_space: 0,
                        align_h: hmUI.align.CENTER_H,
                        invalid_image: rootPath + 'font/none.png',
                        padding: false,
                         show_level: hmUI.show_level.ONLY_NORMAL  
                    });
                    let timePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                        hour_centerX: 195,
                        hour_centerY: 225,
                        hour_posX: 16,
                        hour_posY: 225,
                        hour_path: rootPath + 'hand/hour.png',

                        minute_centerX: 195,
                        minute_centerY: 225,
                        minute_posX: 13,
                        minute_posY: 225,
                        minute_path: rootPath + 'hand/minute.png',

                        second_centerX: 195,
                        second_centerY: 225,
                        second_posX: 9,
                        second_posY: 225,
                        second_path: rootPath + 'hand/second.png',
                        show_level: hmUI.show_level.ONLY_NORMAL  
                    });
                }

            },

            onInit() {
                console.log('index page.js on init invoke')

                this.init_view();
            },

            onReady() {
                console.log('index page.js on ready invoke')
            },

            onShow() {
                console.log('index page.js on show invoke')
            },

            onHide() {
                console.log('index page.js on hide invoke')
            },

            onDestory() {
                console.log('index page.js on destory invoke')
                timer.stopTimer(timerSupport)
            },
        });
        /*
        * end js
        */
    })()
} catch (e) {
    console.log(e)
}