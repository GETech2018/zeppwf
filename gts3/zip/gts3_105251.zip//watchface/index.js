
    /*
    ** huamiOS bundle tool v1.0.17
    * *huamiOS watchface js version v1.0.1
    * *Copyright © Huami. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start
        let normal$_$background$_$bg = ''
        let normal$_$digital_clock$_$img_time = ''
        let normal$_$date$_$img_date = ''
        let normal$_$week$_$week = ''
        let normal$_$heart_rate$_$text$_$text_img = ''
        let normal$_$calorie$_$current$_$text_img = ''
        let normal$_$pai$_$weekly$_$text_img = ''
        let normal$_$step$_$current$_$text_img = ''
        let normal$_$step$_$image_progress$_$img_level = ''
        let normal$_$distance$_$text$_$text_img = ''
        let normal$_$temperature$_$current$_$text_img = ''
        let normal$_$battery$_$text$_$text_img = ''
        let normal$_$battery$_$image_progress$_$img_level = ''
        let normal$_$humidity$_$text$_$text_img = ''
        let idle$_$idle_background$_$bg = ''
        let idle$_$digital_clock$_$img_time = ''
        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            normal$_$background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$digital_clock$_$img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_zero: 1,
              hour_startX: 43,
              hour_startY: 68,
              hour_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              hour_space: 0,
              hour_align: hmUI.align.LEFT,
              minute_zero: 1,
              minute_startX: 166,
              minute_startY: 68,
              minute_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              minute_space: 0,
              minute_align: hmUI.align.LEFT,
              minute_follow: 0,
              second_zero: 1,
              second_startX: 287,
              second_startY: 71,
              second_array: ["22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png"],
              second_space: 0,
              second_align: hmUI.align.LEFT,
              second_follow: 0,
              am_x: 295,
              am_y: 110,
              am_en_path: '32.png',
              pm_x: 295,
              pm_y: 110,
              pm_en_path: '33.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$date$_$img_date = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 126,
              month_startY: 190,
              month_sc_array: ["34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png"],
              month_tc_array: ["34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png"],
              month_en_array: ["34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png"],
              month_align: hmUI.align.LEFT,
              month_zero: 0,
              month_follow: 0,
              month_space: 0,
              month_is_character: true,
              day_startX: 45,
              day_startY: 167,
              day_sc_array: ["46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png"],
              day_tc_array: ["46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png"],
              day_en_array: ["46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png"],
              day_align: hmUI.align.LEFT,
              day_zero: 1,
              day_follow: 0,
              day_space: 0,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$week$_$week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 129,
              y: 168,
              week_en: ["56.png","57.png","58.png","59.png","60.png","61.png","62.png"],
              week_tc: ["56.png","57.png","58.png","59.png","60.png","61.png","62.png"],
              week_sc: ["56.png","57.png","58.png","59.png","60.png","61.png","62.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$heart_rate$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 151,
              y: 249,
              type: hmUI.data_type.HEART,
              font_array: ["63.png","64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png"],
              align_h: hmUI.align.LEFT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: '73.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$calorie$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 151,
              y: 301,
              type: hmUI.data_type.CAL,
              font_array: ["74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png"],
              align_h: hmUI.align.LEFT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: '84.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$pai$_$weekly$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 171,
              y: 413,
              type: hmUI.data_type.PAI_WEEKLY,
              font_array: ["85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png","93.png","94.png"],
              align_h: hmUI.align.LEFT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: '95.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$step$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 252,
              y: 252,
              type: hmUI.data_type.STEP,
              font_array: ["96.png","97.png","98.png","99.png","100.png","101.png","102.png","103.png","104.png","105.png"],
              align_h: hmUI.align.LEFT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: '106.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$step$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 250,
              y: 295,
              image_array: ["107.png","108.png","109.png","110.png","111.png","112.png","113.png","114.png","115.png","116.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$distance$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 149,
              y: 357,
              type: hmUI.data_type.DISTANCE,
              font_array: ["117.png","118.png","119.png","120.png","121.png","122.png","123.png","124.png","125.png","126.png"],
              align_h: hmUI.align.LEFT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              dot_image: '128.png', //小数点图片
              invalid_image: '127.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$temperature$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 255,
              y: 192,
              type: hmUI.data_type.WEATHER_CURRENT,
              font_array: ["129.png","130.png","131.png","132.png","133.png","134.png","135.png","136.png","137.png","138.png"],
              align_h: hmUI.align.RIGHT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: '141.png',//单位
              unit_en: '142.png',//单位
              negative_image: '140.png', //负号图片
              invalid_image: '139.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$battery$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 71,
              y: 252,
              type: hmUI.data_type.BATTERY,
              font_array: ["143.png","144.png","145.png","146.png","147.png","148.png","149.png","150.png","151.png","152.png"],
              align_h: hmUI.align.LEFT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: '154.png',//单位
              unit_tc: '154.png',//单位
              unit_en: '154.png',//单位
              invalid_image: '153.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$battery$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 51,
              y: 295,
              image_array: ["155.png","156.png","157.png","158.png","159.png","160.png","161.png","162.png","163.png","164.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$humidity$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 255,
              y: 49,
              type: hmUI.data_type.HUMIDITY,
              font_array: ["165.png","166.png","167.png","168.png","169.png","170.png","171.png","172.png","173.png","174.png"],
              align_h: hmUI.align.LEFT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: '176.png',//单位
              unit_tc: '176.png',//单位
              unit_en: '176.png',//单位
              invalid_image: '175.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            idle$_$idle_background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: '177.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

                    
            idle$_$digital_clock$_$img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_zero: 1,
              hour_startX: 43,
              hour_startY: 68,
              hour_array: ["178.png","179.png","180.png","181.png","182.png","183.png","184.png","185.png","186.png","187.png"],
              hour_space: 0,
              hour_align: hmUI.align.LEFT,
              minute_zero: 1,
              minute_startX: 166,
              minute_startY: 68,
              minute_array: ["188.png","189.png","190.png","191.png","192.png","193.png","194.png","195.png","196.png","197.png"],
              minute_space: 0,
              minute_align: hmUI.align.LEFT,
              minute_follow: 0,
              am_x: 295,
              am_y: 110,
              am_en_path: '198.png',
              pm_x: 295,
              pm_y: 110,
              pm_en_path: '199.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  