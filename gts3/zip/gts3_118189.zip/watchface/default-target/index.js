try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_8de93cd6209b4e858d472c4699ab7361 = '';
        let normal$_$text_845263f828994daf80d8fb35310b9f8b = '';
        let stepSensor = '';
        let calorieSensor = '';
        const logger = Logger.getLogger('watchface6');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
                    edit_id: 1,
                    x: 0,
                    y: 0,
                    bg_config: [
                        {
                            'id': 1,
                            'path': '4.png',
                            'preview': '4.png'
                        },
                        {
                            'id': 2,
                            'path': '5.png',
                            'preview': '5.png'
                        },
                        {
                            'id': 3,
                            'path': '6.png',
                            'preview': '6.png'
                        },
                        {
                            'id': 4,
                            'path': '7.png',
                            'preview': '7.png'
                        }
                    ],
                    count: 4,
                    default_id: 1,
                    fg: '3.png',
                    tips_x: 0,
                    tips_y: 0,
                    tips_bg: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 80,
                    hour_startY: 75,
                    hour_array: [
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png'
                    ],
                    hour_space: 0,
                    hour_align: hmUI.align.RIGHT,
                    minute_zero: 1,
                    minute_startX: 211,
                    minute_startY: 75,
                    minute_array: [
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png'
                    ],
                    minute_space: 0,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    am_x: 174,
                    am_y: 396,
                    am_en_path: '28.png',
                    pm_x: 174,
                    pm_y: 397,
                    pm_en_path: '29.png',
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 186,
                    y: 85,
                    w: 18,
                    h: 55,
                    src: '30.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 115,
                    month_startY: 40,
                    month_en_array: [
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png'
                    ],
                    month_align: hmUI.align.LEFT,
                    month_zero: 0,
                    month_follow: 0,
                    month_space: 0,
                    month_is_character: true,
                    day_startX: 182,
                    day_startY: 40,
                    day_sc_array: [
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png'
                    ],
                    day_tc_array: [
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png'
                    ],
                    day_en_array: [
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png'
                    ],
                    day_align: hmUI.align.LEFT,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 0,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 232,
                    y: 40,
                    week_en: [
                        '53.png',
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png',
                        '58.png',
                        '59.png'
                    ],
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 35,
                    y: 392,
                    src: '60.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_8de93cd6209b4e858d472c4699ab7361 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 72,
                    y: 397,
                    w: 65,
                    h: 25,
                    text: '[SC]',
                    color: '0xFFbbbbbb',
                    text_size: 20,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 321,
                    y: 392,
                    src: '61.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_845263f828994daf80d8fb35310b9f8b = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 264,
                    y: 397,
                    w: 50,
                    h: 25,
                    text: '[CAL]',
                    color: '0xFFbbbbbb',
                    text_size: 20,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.RIGHT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 80,
                    hour_startY: 75,
                    hour_array: [
                        '62.png',
                        '63.png',
                        '64.png',
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png',
                        '71.png'
                    ],
                    hour_space: 0,
                    hour_align: hmUI.align.RIGHT,
                    minute_zero: 1,
                    minute_startX: 211,
                    minute_startY: 75,
                    minute_array: [
                        '62.png',
                        '63.png',
                        '64.png',
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png',
                        '71.png'
                    ],
                    minute_space: 0,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    am_x: 174,
                    am_y: 397,
                    am_en_path: '28.png',
                    pm_x: 174,
                    pm_y: 397,
                    pm_en_path: '29.png',
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 115,
                    month_startY: 40,
                    month_en_array: [
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png'
                    ],
                    month_align: hmUI.align.LEFT,
                    month_zero: 0,
                    month_follow: 0,
                    month_space: 0,
                    month_is_character: true,
                    day_startX: 182,
                    day_startY: 40,
                    day_sc_array: [
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png'
                    ],
                    day_tc_array: [
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png'
                    ],
                    day_en_array: [
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png'
                    ],
                    day_align: hmUI.align.LEFT,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 0,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 232,
                    y: 40,
                    week_en: [
                        '53.png',
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png',
                        '58.png',
                        '59.png'
                    ],
                    show_level: hmUI.show_level.ONLY_AOD
                });
                if (!stepSensor) {
                    stepSensor = hmSensor.createSensor(hmSensor.id.STEP);
                }
                if (!calorieSensor) {
                    calorieSensor = hmSensor.createSensor(hmSensor.id.CALORIE);
                }
                stepSensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_8de93cd6209b4e858d472c4699ab7361.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                }), calorieSensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_845263f828994daf80d8fb35310b9f8b.setProperty(hmUI.prop.MORE, { text: `${ calorieSensor.current }` });
                });
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        normal$_$text_8de93cd6209b4e858d472c4699ab7361.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                        normal$_$text_845263f828994daf80d8fb35310b9f8b.setProperty(hmUI.prop.MORE, { text: `${ calorieSensor.current }` });
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}