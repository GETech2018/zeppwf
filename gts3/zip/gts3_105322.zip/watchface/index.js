try {
  (() => {

    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

    /*
  * huamiOS bundle tool v1.0.17
  * Copyright © Huami. All Rights Reserved
  */
    'use strict';

    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let rootPath = null
    let bgPath = null
    let dayPath = null
    let monthPath = null
    let numPath = null
    let timePath = null
    let weekPath = null
    let zhizhenPath = null

    let day_array = null
    let month_array_en = null
    let month_array_sc = null
    let num_array = null
    let time_array = null
    let week_array_en = null
    let week_array_sc = null
    const logger = DeviceRuntimeCore.HmLogger.getLogger("defult");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({


      init_view() {
        rootPath = "images/";
        bgPath = rootPath + "bg/"
        dayPath = rootPath + "day/"
        monthPath = rootPath + "month/"
        numPath = rootPath + "num/"
        timePath = rootPath + "time/"
        weekPath = rootPath + "week/"
        zhizhenPath = rootPath + "zhizhen/"

        day_array = [
          dayPath + "date_n_0.png",
          dayPath + "date_n_1.png",
          dayPath + "date_n_2.png",
          dayPath + "date_n_3.png",
          dayPath + "date_n_4.png",
          dayPath + "date_n_5.png",
          dayPath + "date_n_6.png",
          dayPath + "date_n_7.png",
          dayPath + "date_n_8.png",
          dayPath + "date_n_9.png"
        ]

        month_array_en = [
          rootPath + "month_en/month_1.png",
          rootPath + "month_en/month_2.png",
          rootPath + "month_en/month_3.png",
          rootPath + "month_en/month_4.png",
          rootPath + "month_en/month_5.png",
          rootPath + "month_en/month_6.png",
          rootPath + "month_en/month_7.png",
          rootPath + "month_en/month_8.png",
          rootPath + "month_en/month_9.png",
          rootPath + "month_en/month_10.png",
          rootPath + "month_en/month_11.png",
          rootPath + "month_en/month_12.png",
        ]
        month_array_sc = [
          rootPath + "month_sc/month_1.png",
          rootPath + "month_sc/month_2.png",
          rootPath + "month_sc/month_3.png",
          rootPath + "month_sc/month_4.png",
          rootPath + "month_sc/month_5.png",
          rootPath + "month_sc/month_6.png",
          rootPath + "month_sc/month_7.png",
          rootPath + "month_sc/month_8.png",
          rootPath + "month_sc/month_9.png",
          rootPath + "month_sc/month_10.png",
          rootPath + "month_sc/month_11.png",
          rootPath + "month_sc/month_12.png",
        ]
        num_array = [
          numPath + "d_n_0.png",
          numPath + "d_n_1.png",
          numPath + "d_n_2.png",
          numPath + "d_n_3.png",
          numPath + "d_n_4.png",
          numPath + "d_n_5.png",
          numPath + "d_n_6.png",
          numPath + "d_n_7.png",
          numPath + "d_n_8.png",
          numPath + "d_n_9.png"
        ]

        time_array = [
          timePath + "time_n_0.png",
          timePath + "time_n_1.png",
          timePath + "time_n_2.png",
          timePath + "time_n_3.png",
          timePath + "time_n_4.png",
          timePath + "time_n_5.png",
          timePath + "time_n_6.png",
          timePath + "time_n_7.png",
          timePath + "time_n_8.png",
          timePath + "time_n_9.png"
        ]

        week_array_en = [
          rootPath + "week_en/week_1.png",
          rootPath + "week_en/week_2.png",
          rootPath + "week_en/week_3.png",
          rootPath + "week_en/week_4.png",
          rootPath + "week_en/week_5.png",
          rootPath + "week_en/week_6.png",
          rootPath + "week_en/week_7.png",
        ]
        week_array_sc = [
          rootPath + "week_sc/week_1.png",
          rootPath + "week_sc/week_2.png",
          rootPath + "week_sc/week_3.png",
          rootPath + "week_sc/week_4.png",
          rootPath + "week_sc/week_5.png",
          rootPath + "week_sc/week_6.png",
          rootPath + "week_sc/week_7.png",
        ]

        let editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
          edit_id: 103,
          x: 0,
          y: 0,
          bg_config: [
            { id: 1, preview: bgPath + "1.png", path: bgPath + "1.png" },
            { id: 2, preview: bgPath + "2.png", path: bgPath + "2.png" },
            { id: 3, preview: bgPath + "3.png", path: bgPath + "3.png" },
            { id: 4, preview: bgPath + "4.png", path: bgPath + "4.png" },
            { id: 5, preview: bgPath + "5.png", path: bgPath + "5.png" },
          ],
          count: 5,
          default_id: 1,
          fg: rootPath + "select/fg.png",
          tips_x: 143,
          tips_y: 408,
          tips_bg: rootPath + "select/tag.png",
          show_level:hmUI.show_level.ONLY_NORMAL |  hmUI.show_level.ONLY_EDIT
        })

        let stepText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 32,
          y: 379,
          type: hmUI.data_type.STEP,
          font_array: num_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NORMAL,
          // invalid_image: number_sPath + "null.png",
          // padding:true
        });

        let calText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 300,
          y: 48,
          type: hmUI.data_type.CAL,
          font_array: num_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NORMAL,
          // invalid_image: number_sPath + "null.png",
          // padding:true
        });

        let batteryText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 40,
          y: 48,
          type: hmUI.data_type.BATTERY,
          font_array: num_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          unit_sc: numPath + "baifen.png",
          unit_tc: numPath + "baifen.png",
          unit_en: numPath + "baifen.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
          // invalid_image: number_sPath + "null.png",
          // padding:true
        });

        let heartText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 310,
          y: 379,
          type: hmUI.data_type.HEART,
          font_array: num_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NORMAL,
          invalid_image: numPath + "d_n_gg.png",
          // padding:true
        });

        let timePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_centerX: 195, //指针旋转中心 对应centerX
          hour_centerY: 225, //指针旋转中心 对应centerY
          hour_posX: 22, //指针自身旋转中心 对应positioin中的x
          hour_posY: 146, //指针自身旋转中心 对应positioin中的y
          hour_path: zhizhenPath + "h.png",

          minute_centerX: 195, //指针旋转中心 对应centerX
          minute_centerY: 225, //指针旋转中心 对应centerY
          minute_posX: 22, //指针自身旋转中心 对应positioin中的x
          minute_posY: 194, //指针自身旋转中心 对应positioin中的y
          minute_path: zhizhenPath + "m.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          hour_zero: 1, //是否补零
          hour_startX: 116,
          hour_startY: 162,
          hour_array: time_array,
          hour_space: -2, //每个数组间的间隔
          hour_unit_sc: timePath + "time_n_d.png",
          hour_unit_tc: timePath + "time_n_d.png",
          hour_unit_en: timePath + "time_n_d.png",
          minute_zero: 1, //是否补零
          minute_startX: 206,
          minute_startY: 162,
          minute_array: time_array,
          minute_space: -2, //每个数组间的间隔
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD,
        });

        let weekText = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
          x: 99,
          y: 262,
          week_en: week_array_en,
          week_tc: week_array_sc,
          week_sc: week_array_sc,
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD,
        });

        let dataText = hmUI.createWidget(hmUI.widget.IMG_DATE, {

          month_startX: 142,
          month_startY: 221,
          // month_align: hmUI.align.LEFT,
          month_en_array: month_array_en,
          month_sc_array: month_array_sc,
          month_tc_array: month_array_sc,
          month_is_character:true,
          day_startX: 209,
          day_startY: 220,
          // day_align: hmUI.align.LEFT,
          day_en_array: day_array,
          day_sc_array: day_array,
          day_tc_array: day_array,
          day_zero : 1,
          // day_follow: 1,//是否跟随
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD,
          //月日同上 需要替换前缀为month/day
        });
      },

      onInit() {
        console.log('index page.js on init invoke');

        this.init_view();


      },

      onReady() {
        console.log('index page.js on ready invoke')
      },

      onShow() {
        console.log('index page.js on show invoke')
      },

      onHide() {
        console.log('index page.js on hide invoke')
      },

      onDestory() {
        console.log('index page.js on destory invoke')
      },
    });
    /*
    * end js
    */
  })()
} catch (e) {
  console.log(e)
}